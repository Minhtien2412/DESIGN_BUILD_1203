import { Logger } from '@nestjs/common';
import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { MetricsService } from '../metrics/metrics.service';

/**
 * WebSocket Gateway for real-time progress updates
 * Emits events when task or project progress changes
 *
 * Events:
 * - task:progress:<taskId> - Emitted when task progress updates
 * - project:progress:<projectId> - Emitted when project progress updates
 *
 * Client subscription example:
 * socket.on('task:progress:1', (data) => { ... })
 * socket.on('project:progress:1', (data) => { ... })
 */
@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/progress',
})
export class ProgressGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(ProgressGateway.name);

  // Track subscribed clients: Map<roomName, Set<socketId>>
  private subscriptions: Map<string, Set<string>> = new Map();

  constructor(private metricsService: MetricsService) {}

  handleConnection(client: Socket) {
    this.logger.log(`Client connected: ${client.id}`);
    this.metricsService.recordWsConnect('progress');

    // Extract userId from handshake (if authentication is implemented)
    const userId = client.handshake.query.userId as string;
    if (userId) {
      this.logger.log(`User ${userId} connected via socket ${client.id}`);
    }
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
    this.metricsService.recordWsDisconnect('progress');

    // Clean up subscriptions
    this.subscriptions.forEach((clients, room) => {
      clients.delete(client.id);
      if (clients.size === 0) {
        this.subscriptions.delete(room);
      }
    });
  }

  /**
   * Subscribe to task progress updates
   * Client sends: { taskId: number }
   */
  @SubscribeMessage('subscribe:task')
  handleSubscribeTask(
    @MessageBody() data: { taskId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `task:${data.taskId}`;
    client.join(room);

    // Track subscription
    if (!this.subscriptions.has(room)) {
      this.subscriptions.set(room, new Set());
    }
    this.subscriptions.get(room)!.add(client.id);

    this.logger.log(`Client ${client.id} subscribed to ${room}`);
    return { success: true, room };
  }

  /**
   * Subscribe to project progress updates
   * Client sends: { projectId: number }
   */
  @SubscribeMessage('subscribe:project')
  handleSubscribeProject(
    @MessageBody() data: { projectId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `project:${data.projectId}`;
    client.join(room);

    // Track subscription
    if (!this.subscriptions.has(room)) {
      this.subscriptions.set(room, new Set());
    }
    this.subscriptions.get(room)!.add(client.id);

    this.logger.log(`Client ${client.id} subscribed to ${room}`);
    return { success: true, room };
  }

  /**
   * Unsubscribe from task progress updates
   * Client sends: { taskId: number }
   */
  @SubscribeMessage('unsubscribe:task')
  handleUnsubscribeTask(
    @MessageBody() data: { taskId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `task:${data.taskId}`;
    client.leave(room);

    const subscribers = this.subscriptions.get(room);
    if (subscribers) {
      subscribers.delete(client.id);
      if (subscribers.size === 0) {
        this.subscriptions.delete(room);
      }
    }

    this.logger.log(`Client ${client.id} unsubscribed from ${room}`);
    return { success: true, room };
  }

  /**
   * Unsubscribe from project progress updates
   * Client sends: { projectId: number }
   */
  @SubscribeMessage('unsubscribe:project')
  handleUnsubscribeProject(
    @MessageBody() data: { projectId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `project:${data.projectId}`;
    client.leave(room);

    const subscribers = this.subscriptions.get(room);
    if (subscribers) {
      subscribers.delete(client.id);
      if (subscribers.size === 0) {
        this.subscriptions.delete(room);
      }
    }

    this.logger.log(`Client ${client.id} unsubscribed from ${room}`);
    return { success: true, room };
  }

  /**
   * Emit task progress update to all subscribed clients
   * Called by TasksService when task is updated
   */
  emitTaskProgress(taskId: number, progress: any) {
    const room = `task:${taskId}`;
    const eventName = `task:progress:${taskId}`;

    this.server.to(room).emit(eventName, {
      taskId,
      progress,
      timestamp: new Date(),
    });

    const subscriberCount = this.subscriptions.get(room)?.size || 0;
    this.logger.log(`Emitted ${eventName} to ${subscriberCount} subscribers`);
  }

  /**
   * Emit project progress update to all subscribed clients
   * Called by ProjectsService when project is updated
   */
  emitProjectProgress(projectId: number, progress: any) {
    const room = `project:${projectId}`;
    const eventName = `project:progress:${projectId}`;

    this.server.to(room).emit(eventName, {
      projectId,
      progress,
      timestamp: new Date(),
    });

    const subscriberCount = this.subscriptions.get(room)?.size || 0;
    this.logger.log(`Emitted ${eventName} to ${subscriberCount} subscribers`);
  }

  /**
   * Get current subscription stats (for debugging)
   */
  getStats() {
    const stats = {
      totalRooms: this.subscriptions.size,
      rooms: [] as any[],
    };

    this.subscriptions.forEach((clients, room) => {
      stats.rooms.push({
        room,
        subscribers: clients.size,
      });
    });

    return stats;
  }
}
