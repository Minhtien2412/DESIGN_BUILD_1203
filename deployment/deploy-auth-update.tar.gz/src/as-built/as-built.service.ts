import {
    BadRequestException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import {
    AddCommentDto,
    ApproveDrawingDto,
    CreateDrawingDto,
    CreateExportPackageDto,
    QueryDrawingDto,
    QueryExportDto,
    ResolveCommentDto,
    ReviewDrawingDto,
    UpdateDrawingDto,
    UploadRevisionDto,
} from './dto';
import {
    AsBuiltDashboard,
    AsBuiltDrawing,
    DrawingComment,
    DrawingRevision,
    DrawingStatus,
    DrawingType,
    ExportFormat,
    ExportPackage,
    PackageStatus,
} from './entities';

@Injectable()
export class AsBuiltService {
  private drawings: Map<number, AsBuiltDrawing> = new Map();
  private revisions: Map<number, DrawingRevision> = new Map();
  private exports: Map<number, ExportPackage> = new Map();
  private comments: Map<number, DrawingComment> = new Map();

  private drawingIdCounter = 1;
  private revisionIdCounter = 1;
  private exportIdCounter = 1;
  private commentIdCounter = 1;

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const now = new Date();
    const users = [
      { id: 1, name: 'KTS. Nguyễn Văn Kiến' },
      { id: 2, name: 'KS. Trần Văn Kết Cấu' },
      { id: 3, name: 'KS. Lê Văn MEP' },
    ];

    const drawingTypes = Object.values(DrawingType);
    const statuses = Object.values(DrawingStatus);

    for (let i = 0; i < 15; i++) {
      const user = users[i % users.length];
      const type = drawingTypes[i % drawingTypes.length];
      const status = statuses[i % statuses.length];

      const drawing: AsBuiltDrawing = {
        id: this.drawingIdCounter++,
        projectId: (i % 3) + 1,
        title: `Bản vẽ ${type} - Sheet ${i + 1}`,
        description: `Bản vẽ hoàn công ${type} tầng ${(i % 5) + 1}`,
        drawingNumber: `AB-${type.toUpperCase().substring(0, 3)}-${String(i + 1).padStart(3, '0')}`,
        drawingType: type,
        status,
        version: 1,
        revision: String.fromCharCode(65 + (i % 4)), // A, B, C, D
        scale: '1:100',
        size: 'A1',
        originalFile: `/uploads/drawings/drawing_${i + 1}.dwg`,
        thumbnailUrl: `/uploads/thumbnails/thumb_${i + 1}.png`,
        previewUrl: `/uploads/previews/preview_${i + 1}.pdf`,
        fileSize: 1024 * 1024 * (1 + Math.random() * 10), // 1-11 MB
        uploadedBy: user.id,
        uploadedByName: user.name,
        reviewedBy:
          status !== DrawingStatus.DRAFT
            ? users[(i + 1) % users.length].id
            : undefined,
        reviewedByName:
          status !== DrawingStatus.DRAFT
            ? users[(i + 1) % users.length].name
            : undefined,
        reviewedAt:
          status !== DrawingStatus.DRAFT
            ? new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000)
            : undefined,
        approvedBy:
          status === DrawingStatus.APPROVED
            ? users[(i + 2) % users.length].id
            : undefined,
        approvedByName:
          status === DrawingStatus.APPROVED
            ? users[(i + 2) % users.length].name
            : undefined,
        approvedAt:
          status === DrawingStatus.APPROVED
            ? new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000)
            : undefined,
        tags: [type, `tầng-${(i % 5) + 1}`, 'hoàn-công'],
        createdAt: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      };

      this.drawings.set(drawing.id, drawing);

      // Add sample revisions for some drawings
      if (i < 5) {
        for (let r = 0; r < 2; r++) {
          const revision: DrawingRevision = {
            id: this.revisionIdCounter++,
            drawingId: drawing.id,
            revision: String.fromCharCode(65 + r),
            changes: `Cập nhật chi tiết kết cấu revision ${String.fromCharCode(65 + r)}`,
            changedBy: user.id,
            changedByName: user.name,
            fileUrl: `/uploads/revisions/rev_${drawing.id}_${r}.dwg`,
            createdAt: new Date(now.getTime() - (i + r) * 24 * 60 * 60 * 1000),
          };
          this.revisions.set(revision.id, revision);
        }
      }

      // Add sample comments
      if (i < 3) {
        const comment: DrawingComment = {
          id: this.commentIdCounter++,
          drawingId: drawing.id,
          userId: users[(i + 1) % users.length].id,
          userName: users[(i + 1) % users.length].name,
          comment: 'Cần kiểm tra lại kích thước cột tại vị trí này',
          x: 150 + i * 50,
          y: 200 + i * 30,
          resolved: i === 0,
          resolvedBy: i === 0 ? user.id : undefined,
          resolvedAt: i === 0 ? new Date() : undefined,
          createdAt: new Date(),
        };
        this.comments.set(comment.id, comment);
      }
    }

    // Sample export packages
    for (let i = 0; i < 3; i++) {
      const user = users[i % users.length];
      const exportPkg: ExportPackage = {
        id: this.exportIdCounter++,
        projectId: (i % 3) + 1,
        title: `Gói xuất bản vẽ ${i + 1}`,
        description: `Xuất toàn bộ bản vẽ kiến trúc tầng ${i + 1}`,
        format: Object.values(ExportFormat)[i % 5],
        status: Object.values(PackageStatus)[i % 4],
        drawings: [1, 2, 3].map((d) => d + i * 3),
        includeMetadata: true,
        includeRevisions: i < 2,
        downloadUrl: i < 2 ? `/exports/package_${i + 1}.zip` : undefined,
        fileSize: i < 2 ? 1024 * 1024 * 50 : undefined, // 50 MB
        requestedBy: user.id,
        requestedByName: user.name,
        completedAt: i < 2 ? new Date() : undefined,
        expiresAt:
          i < 2 ? new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000) : undefined,
        createdAt: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
      };
      this.exports.set(exportPkg.id, exportPkg);
    }
  }

  // ========== DASHBOARD ==========

  async getDashboard(projectId?: number): Promise<AsBuiltDashboard> {
    let drawings = Array.from(this.drawings.values());

    if (projectId) {
      drawings = drawings.filter((d) => d.projectId === projectId);
    }

    const drawingsByStatus = Object.values(DrawingStatus).reduce(
      (acc, status) => {
        acc[status] = drawings.filter((d) => d.status === status).length;
        return acc;
      },
      {} as Record<DrawingStatus, number>,
    );

    const drawingsByType = Object.values(DrawingType).reduce(
      (acc, type) => {
        acc[type] = drawings.filter((d) => d.drawingType === type).length;
        return acc;
      },
      {} as Record<DrawingType, number>,
    );

    const totalFileSize = drawings.reduce(
      (sum, d) => sum + (d.fileSize || 0),
      0,
    );

    return {
      totalDrawings: drawings.length,
      drawingsByStatus,
      drawingsByType,
      recentDrawings: drawings
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, 5),
      pendingReviews: drawings.filter((d) => d.status === DrawingStatus.REVIEW)
        .length,
      totalExports: this.exports.size,
      totalFileSize: Math.round(totalFileSize / (1024 * 1024)), // MB
    };
  }

  // ========== DRAWINGS ==========

  async getDrawings(
    query: QueryDrawingDto,
  ): Promise<{ data: AsBuiltDrawing[]; total: number }> {
    let drawings = Array.from(this.drawings.values());

    if (query.projectId) {
      drawings = drawings.filter((d) => d.projectId === query.projectId);
    }
    if (query.status) {
      drawings = drawings.filter((d) => d.status === query.status);
    }
    if (query.drawingType) {
      drawings = drawings.filter((d) => d.drawingType === query.drawingType);
    }
    if (query.search) {
      const search = query.search.toLowerCase();
      drawings = drawings.filter(
        (d) =>
          d.title.toLowerCase().includes(search) ||
          d.drawingNumber.toLowerCase().includes(search) ||
          d.description?.toLowerCase().includes(search),
      );
    }
    if (query.tags && query.tags.length > 0) {
      drawings = drawings.filter((d) =>
        d.tags?.some((t) => query.tags!.includes(t)),
      );
    }

    const total = drawings.length;
    const offset = query.offset || 0;
    const limit = query.limit || 50;

    return {
      data: drawings
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(offset, offset + limit),
      total,
    };
  }

  async getDrawingById(id: number): Promise<AsBuiltDrawing> {
    const drawing = this.drawings.get(id);
    if (!drawing) throw new NotFoundException(`Drawing ${id} not found`);
    return drawing;
  }

  async createDrawing(dto: CreateDrawingDto): Promise<AsBuiltDrawing> {
    const drawing: AsBuiltDrawing = {
      id: this.drawingIdCounter++,
      projectId: dto.projectId,
      title: dto.title,
      description: dto.description,
      drawingNumber: dto.drawingNumber,
      drawingType: dto.drawingType,
      status: DrawingStatus.DRAFT,
      version: 1,
      revision: 'A',
      scale: dto.scale,
      size: dto.size,
      originalFile: dto.originalFile,
      fileSize: dto.fileSize || 0,
      uploadedBy: dto.uploadedBy,
      uploadedByName: `User ${dto.uploadedBy}`,
      tags: dto.tags,
      metadata: dto.metadata,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.drawings.set(drawing.id, drawing);
    return drawing;
  }

  async updateDrawing(
    id: number,
    dto: UpdateDrawingDto,
  ): Promise<AsBuiltDrawing> {
    const drawing = await this.getDrawingById(id);

    if (dto.title) drawing.title = dto.title;
    if (dto.description) drawing.description = dto.description;
    if (dto.status) drawing.status = dto.status;
    if (dto.scale) drawing.scale = dto.scale;
    if (dto.size) drawing.size = dto.size;
    if (dto.tags) drawing.tags = dto.tags;
    if (dto.metadata)
      drawing.metadata = { ...drawing.metadata, ...dto.metadata };

    drawing.updatedAt = new Date();
    this.drawings.set(id, drawing);
    return drawing;
  }

  async uploadRevision(
    id: number,
    dto: UploadRevisionDto,
  ): Promise<DrawingRevision> {
    const drawing = await this.getDrawingById(id);

    const revision: DrawingRevision = {
      id: this.revisionIdCounter++,
      drawingId: id,
      revision: String.fromCharCode(65 + drawing.version),
      changes: dto.changes,
      changedBy: dto.changedBy,
      changedByName: `User ${dto.changedBy}`,
      fileUrl: dto.fileUrl,
      createdAt: new Date(),
    };

    drawing.version++;
    drawing.revision = revision.revision;
    drawing.originalFile = dto.fileUrl;
    drawing.status = DrawingStatus.DRAFT;
    drawing.updatedAt = new Date();

    this.revisions.set(revision.id, revision);
    this.drawings.set(id, drawing);

    return revision;
  }

  async getRevisions(drawingId: number): Promise<DrawingRevision[]> {
    await this.getDrawingById(drawingId);
    return Array.from(this.revisions.values())
      .filter((r) => r.drawingId === drawingId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async submitForReview(id: number): Promise<AsBuiltDrawing> {
    const drawing = await this.getDrawingById(id);

    if (drawing.status !== DrawingStatus.DRAFT) {
      throw new BadRequestException(
        'Only draft drawings can be submitted for review',
      );
    }

    drawing.status = DrawingStatus.REVIEW;
    drawing.updatedAt = new Date();
    this.drawings.set(id, drawing);
    return drawing;
  }

  async reviewDrawing(
    id: number,
    dto: ReviewDrawingDto,
  ): Promise<AsBuiltDrawing> {
    const drawing = await this.getDrawingById(id);

    if (drawing.status !== DrawingStatus.REVIEW) {
      throw new BadRequestException(
        'Only drawings in review status can be reviewed',
      );
    }

    drawing.reviewedBy = dto.reviewedBy;
    drawing.reviewedByName = `User ${dto.reviewedBy}`;
    drawing.reviewedAt = new Date();

    if (dto.approved) {
      drawing.status = DrawingStatus.APPROVED;
      drawing.approvedBy = dto.reviewedBy;
      drawing.approvedByName = `User ${dto.reviewedBy}`;
      drawing.approvedAt = new Date();
    } else {
      drawing.status = DrawingStatus.DRAFT;
    }

    drawing.updatedAt = new Date();
    this.drawings.set(id, drawing);
    return drawing;
  }

  async approveDrawing(
    id: number,
    dto: ApproveDrawingDto,
  ): Promise<AsBuiltDrawing> {
    const drawing = await this.getDrawingById(id);

    drawing.status = DrawingStatus.APPROVED;
    drawing.approvedBy = dto.approvedBy;
    drawing.approvedByName = `User ${dto.approvedBy}`;
    drawing.approvedAt = new Date();
    drawing.updatedAt = new Date();

    this.drawings.set(id, drawing);
    return drawing;
  }

  // ========== EXPORTS ==========

  async getExports(query: QueryExportDto): Promise<ExportPackage[]> {
    let exports = Array.from(this.exports.values());

    if (query.projectId) {
      exports = exports.filter((e) => e.projectId === query.projectId);
    }
    if (query.requestedBy) {
      exports = exports.filter((e) => e.requestedBy === query.requestedBy);
    }

    return exports.sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
  }

  async getExportById(id: number): Promise<ExportPackage> {
    const exportPkg = this.exports.get(id);
    if (!exportPkg)
      throw new NotFoundException(`Export package ${id} not found`);
    return exportPkg;
  }

  async createExportPackage(
    dto: CreateExportPackageDto,
  ): Promise<ExportPackage> {
    // Validate drawings exist
    for (const drawingId of dto.drawings) {
      await this.getDrawingById(drawingId);
    }

    const exportPkg: ExportPackage = {
      id: this.exportIdCounter++,
      projectId: dto.projectId,
      title: dto.title,
      description: dto.description,
      format: dto.format,
      status: PackageStatus.PENDING,
      drawings: dto.drawings,
      includeMetadata: dto.includeMetadata ?? true,
      includeRevisions: dto.includeRevisions ?? false,
      requestedBy: dto.requestedBy,
      requestedByName: `User ${dto.requestedBy}`,
      createdAt: new Date(),
    };

    this.exports.set(exportPkg.id, exportPkg);

    // Simulate async processing
    setTimeout(() => this.processExport(exportPkg.id), 2000);

    return exportPkg;
  }

  private async processExport(id: number) {
    const exportPkg = this.exports.get(id);
    if (!exportPkg) return;

    exportPkg.status = PackageStatus.PROCESSING;
    this.exports.set(id, exportPkg);

    // Simulate processing time
    setTimeout(() => {
      exportPkg.status = PackageStatus.COMPLETED;
      exportPkg.downloadUrl = `/exports/package_${id}.zip`;
      exportPkg.fileSize = 1024 * 1024 * Math.floor(10 + Math.random() * 90); // 10-100 MB
      exportPkg.completedAt = new Date();
      exportPkg.expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
      this.exports.set(id, exportPkg);
    }, 3000);
  }

  // ========== COMMENTS ==========

  async getComments(drawingId: number): Promise<DrawingComment[]> {
    await this.getDrawingById(drawingId);
    return Array.from(this.comments.values())
      .filter((c) => c.drawingId === drawingId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async addComment(
    drawingId: number,
    dto: AddCommentDto,
  ): Promise<DrawingComment> {
    await this.getDrawingById(drawingId);

    const comment: DrawingComment = {
      id: this.commentIdCounter++,
      drawingId,
      userId: dto.userId,
      userName: `User ${dto.userId}`,
      comment: dto.comment,
      x: dto.x,
      y: dto.y,
      resolved: false,
      createdAt: new Date(),
    };

    this.comments.set(comment.id, comment);
    return comment;
  }

  async resolveComment(
    drawingId: number,
    commentId: number,
    dto: ResolveCommentDto,
  ): Promise<DrawingComment> {
    const comment = this.comments.get(commentId);
    if (!comment || comment.drawingId !== drawingId) {
      throw new NotFoundException(`Comment ${commentId} not found`);
    }

    comment.resolved = true;
    comment.resolvedBy = dto.resolvedBy;
    comment.resolvedAt = new Date();

    this.comments.set(commentId, comment);
    return comment;
  }
}
