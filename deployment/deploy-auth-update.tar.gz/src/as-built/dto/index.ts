import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';
import { DrawingStatus, DrawingType, ExportFormat } from '../entities';

// ========== DRAWING DTOs ==========

export class CreateDrawingDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty()
  @IsString()
  drawingNumber: string;

  @ApiProperty({ enum: DrawingType })
  @IsEnum(DrawingType)
  drawingType: DrawingType;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scale?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  size?: string;

  @ApiProperty()
  @IsString()
  originalFile: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  fileSize?: number;

  @ApiProperty()
  @IsNumber()
  uploadedBy: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;
}

export class UpdateDrawingDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: DrawingStatus })
  @IsOptional()
  @IsEnum(DrawingStatus)
  status?: DrawingStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scale?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  size?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;
}

export class UploadRevisionDto {
  @ApiProperty()
  @IsString()
  changes: string;

  @ApiProperty()
  @IsString()
  fileUrl: string;

  @ApiProperty()
  @IsNumber()
  changedBy: number;
}

export class ReviewDrawingDto {
  @ApiProperty()
  @IsNumber()
  reviewedBy: number;

  @ApiProperty()
  @IsBoolean()
  approved: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;
}

export class ApproveDrawingDto {
  @ApiProperty()
  @IsNumber()
  approvedBy: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;
}

// ========== EXPORT DTOs ==========

export class CreateExportPackageDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ enum: ExportFormat })
  @IsEnum(ExportFormat)
  format: ExportFormat;

  @ApiProperty({ type: [Number] })
  @IsArray()
  @IsNumber({}, { each: true })
  drawings: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  includeMetadata?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  includeRevisions?: boolean;

  @ApiProperty()
  @IsNumber()
  requestedBy: number;
}

// ========== COMMENT DTOs ==========

export class AddCommentDto {
  @ApiProperty()
  @IsNumber()
  userId: number;

  @ApiProperty()
  @IsString()
  comment: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  x?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  y?: number;
}

export class ResolveCommentDto {
  @ApiProperty()
  @IsNumber()
  resolvedBy: number;
}

// ========== QUERY DTOs ==========

export class QueryDrawingDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: DrawingStatus })
  @IsOptional()
  @IsEnum(DrawingStatus)
  status?: DrawingStatus;

  @ApiPropertyOptional({ enum: DrawingType })
  @IsOptional()
  @IsEnum(DrawingType)
  drawingType?: DrawingType;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  offset?: number;
}

export class QueryExportDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  requestedBy?: number;
}
