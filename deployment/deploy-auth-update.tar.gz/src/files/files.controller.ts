/**
 * File Management Controller
 * REST API for file versioning, trash, and management
 *
 * @module files/files.controller
 * @created 2026-01-23
 */

import {
    Body,
    Controller,
    DefaultValuePipe,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    UseGuards
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Request } from 'express';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { FilesService } from './files.service';

interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    email: string;
  };
}

// DTOs
class CreateFileDto {
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  path: string;
  url?: string;
  folderId?: string;
  metadata?: Record<string, any>;
  tags?: string[];
}

class UpdateFileDto {
  filename?: string;
  folderId?: string;
  metadata?: Record<string, any>;
  tags?: string[];
}

class CreateVersionDto {
  filename: string;
  mimeType: string;
  size: number;
  path: string;
  url?: string;
  changeNote?: string;
}

class CreateFolderDto {
  name: string;
  parentId?: string;
}

@ApiTags('files')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('files')
export class FilesController {
  constructor(private readonly filesService: FilesService) {}

  private getAuditContext(req: AuthenticatedRequest) {
    return {
      userId: req.user.id,
      userEmail: req.user.email,
      ipAddress: req.ip || req.connection?.remoteAddress,
      userAgent: req.headers['user-agent'],
    };
  }

  // ===================== FILES =====================

  @Post()
  @ApiOperation({ summary: 'Create file record' })
  @ApiResponse({ status: 201, description: 'File created successfully' })
  async createFile(
    @Req() req: AuthenticatedRequest,
    @Body() dto: CreateFileDto,
  ) {
    return this.filesService.createFile(
      req.user.id,
      dto,
      this.getAuditContext(req),
    );
  }

  @Get()
  @ApiOperation({ summary: 'List files' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'folderId', required: false, type: String })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'tags', required: false, type: String, isArray: true })
  async listFiles(
    @Req() req: AuthenticatedRequest,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
    @Query('folderId') folderId?: string,
    @Query('search') search?: string,
    @Query('tags') tags?: string[],
  ) {
    return this.filesService.listFiles(req.user.id, {
      page,
      limit,
      folderId,
      search,
      tags: typeof tags === 'string' ? [tags] : tags,
    });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get file by ID' })
  @ApiResponse({ status: 200, description: 'File details' })
  @ApiResponse({ status: 404, description: 'File not found' })
  async getFile(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    const file = await this.filesService.getFile(id);
    await this.filesService.logView(id, this.getAuditContext(req));
    return file;
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update file metadata' })
  @ApiResponse({ status: 200, description: 'File updated' })
  async updateFile(
    @Param('id') id: string,
    @Body() dto: UpdateFileDto,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.updateFile(id, dto, this.getAuditContext(req));
  }

  @Post(':id/download-log')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Log file download' })
  async logDownload(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    await this.filesService.logDownload(id, this.getAuditContext(req));
    return { logged: true };
  }

  // ===================== VERSIONING =====================

  @Post(':id/versions')
  @ApiOperation({ summary: 'Create new file version' })
  @ApiResponse({ status: 201, description: 'Version created' })
  async createVersion(
    @Param('id') id: string,
    @Body() dto: CreateVersionDto,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.createVersion(id, dto, this.getAuditContext(req));
  }

  @Get(':id/versions')
  @ApiOperation({ summary: 'List file versions' })
  @ApiResponse({ status: 200, description: 'List of versions' })
  async getVersions(@Param('id') id: string) {
    return this.filesService.getVersions(id);
  }

  @Get(':id/versions/:version')
  @ApiOperation({ summary: 'Get specific version' })
  @ApiResponse({ status: 200, description: 'Version details' })
  @ApiResponse({ status: 404, description: 'Version not found' })
  async getVersion(
    @Param('id') id: string,
    @Param('version', ParseIntPipe) version: number,
  ) {
    return this.filesService.getVersion(id, version);
  }

  @Post(':id/versions/:version/restore')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Restore a previous version' })
  @ApiResponse({ status: 200, description: 'Version restored' })
  async restoreVersion(
    @Param('id') id: string,
    @Param('version', ParseIntPipe) version: number,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.restoreVersion(
      id,
      version,
      this.getAuditContext(req),
    );
  }

  // ===================== TRASH =====================

  @Delete(':id')
  @ApiOperation({ summary: 'Move file to trash (soft delete)' })
  @ApiResponse({ status: 200, description: 'File moved to trash' })
  async moveToTrash(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.filesService.moveToTrash(id, this.getAuditContext(req));
  }

  @Post(':id/restore')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Restore file from trash' })
  @ApiResponse({ status: 200, description: 'File restored' })
  async restoreFromTrash(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.restoreFromTrash(id, this.getAuditContext(req));
  }

  @Delete(':id/permanent')
  @ApiOperation({ summary: 'Permanently delete file' })
  @ApiResponse({ status: 200, description: 'File permanently deleted' })
  async permanentDelete(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.permanentDelete(id, this.getAuditContext(req));
  }

  @Get('trash')
  @ApiOperation({ summary: 'Get trash contents' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getTrash(
    @Req() req: AuthenticatedRequest,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
  ) {
    return this.filesService.getTrash(req.user.id, page, limit);
  }

  @Delete('trash/empty')
  @ApiOperation({ summary: 'Empty trash' })
  @ApiResponse({ status: 200, description: 'Trash emptied' })
  async emptyTrash(@Req() req: AuthenticatedRequest) {
    return this.filesService.emptyTrash(req.user.id, this.getAuditContext(req));
  }

  // ===================== FOLDERS =====================

  @Post('folders')
  @ApiOperation({ summary: 'Create folder' })
  @ApiResponse({ status: 201, description: 'Folder created' })
  async createFolder(
    @Req() req: AuthenticatedRequest,
    @Body() dto: CreateFolderDto,
  ) {
    return this.filesService.createFolder(req.user.id, dto.name, dto.parentId);
  }

  @Get('folders/:id/contents')
  @ApiOperation({ summary: 'Get folder contents' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getFolderContents(
    @Req() req: AuthenticatedRequest,
    @Param('id') id: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
  ) {
    const folderId = id === 'root' ? null : id;
    return this.filesService.getFolderContents(req.user.id, folderId, {
      page,
      limit,
    });
  }

  @Delete('folders/:id')
  @ApiOperation({ summary: 'Delete folder (soft delete)' })
  @ApiResponse({ status: 200, description: 'Folder moved to trash' })
  async deleteFolder(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.deleteFolder(id, this.getAuditContext(req));
  }

  // ===================== AUDIT LOGS =====================

  @Get(':id/audit-logs')
  @ApiOperation({ summary: 'Get file audit logs' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getAuditLogs(
    @Param('id') id: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
  ) {
    return this.filesService.getAuditLogs(id, page, limit);
  }
}
