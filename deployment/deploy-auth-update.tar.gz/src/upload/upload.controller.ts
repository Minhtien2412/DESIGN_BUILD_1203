import {
    BadRequestException,
    Body,
    Controller,
    Delete,
    Post,
    Query,
    UploadedFile,
    UploadedFiles,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import {
    ApiBearerAuth,
    ApiBody,
    ApiConsumes,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { StorageProvider, UploadOptions, UploadService } from './upload.service';

@ApiTags('Upload')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'upload', version: '1' })
export class UploadController {
  constructor(private readonly uploadService: UploadService) {}

  @Post('single')
  @ApiOperation({ summary: 'Upload a single file (supports local, S3, Cloudinary)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiQuery({ name: 'provider', enum: StorageProvider, required: false })
  @ApiQuery({ name: 'folder', type: 'string', required: false })
  @ApiResponse({ 
    status: 201, 
    description: 'File uploaded successfully',
    schema: {
      type: 'object',
      properties: {
        url: { type: 'string' },
        publicId: { type: 'string' },
        filename: { type: 'string' },
        size: { type: 'number' },
        mimetype: { type: 'string' },
        provider: { type: 'string' },
      },
    },
  })
  @UseInterceptors(FileInterceptor('file'))
  async uploadSingle(
    @UploadedFile() file: Express.Multer.File,
    @Query('provider') provider?: StorageProvider,
    @Query('folder') folder?: string,
  ) {
    const options: UploadOptions = { provider, folder };
    return this.uploadService.uploadFile(file, options);
  }

  @Post('multiple')
  @ApiOperation({ summary: 'Upload multiple files (max 10)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @ApiQuery({ name: 'provider', enum: StorageProvider, required: false })
  @ApiQuery({ name: 'folder', type: 'string', required: false })
  @ApiResponse({ 
    status: 201, 
    description: 'Files uploaded successfully',
    schema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          url: { type: 'string' },
          publicId: { type: 'string' },
          filename: { type: 'string' },
          size: { type: 'number' },
          mimetype: { type: 'string' },
          provider: { type: 'string' },
        },
      },
    },
  })
  @UseInterceptors(FilesInterceptor('files', 10))
  async uploadMultiple(
    @UploadedFiles() files: Express.Multer.File[],
    @Query('provider') provider?: StorageProvider,
    @Query('folder') folder?: string,
  ) {
    const options: UploadOptions = { provider, folder };
    return this.uploadService.uploadFiles(files, options);
  }

  @Delete('file')
  @ApiOperation({ summary: 'Delete a file from storage' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'File URL or public ID' },
        provider: { 
          type: 'string', 
          enum: ['local', 's3', 'cloudinary'],
          description: 'Storage provider',
        },
      },
      required: ['url', 'provider'],
    },
  })
  @ApiResponse({ status: 200, description: 'File deleted successfully' })
  async deleteFile(
    @Body('url') url: string,
    @Body('provider') provider: StorageProvider,
  ) {
    await this.uploadService.deleteFile(url, provider);
    return { message: 'File deleted successfully' };
  }

  @Post('presigned-url')
  @ApiOperation({ summary: 'Generate presigned URL for S3 upload (private files)' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'S3 object key' },
        expiresIn: { type: 'number', description: 'URL expiration in seconds (default: 3600)' },
      },
      required: ['key'],
    },
  })
  @ApiResponse({ 
    status: 201, 
    description: 'Presigned URL generated',
    schema: {
      type: 'object',
      properties: {
        url: { type: 'string' },
        expiresIn: { type: 'number' },
      },
    },
  })
  async generatePresignedUrl(
    @Body('key') key: string,
    @Body('expiresIn') expiresIn?: number,
  ) {
    const url = await this.uploadService.generatePresignedUrl(key, expiresIn);
    return { url, expiresIn: expiresIn || 3600 };
  }

  // ====================================================================
  // SPECIFIC ENDPOINTS FOR APP
  // ====================================================================

  @Post('documents')
  @ApiOperation({ summary: 'Upload document files (PDF, DOC, DOCX, XLS, etc)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Document uploaded successfully' })
  @UseInterceptors(FileInterceptor('file'))
  async uploadDocument(
    @UploadedFile() file: Express.Multer.File,
  ) {
    const options: UploadOptions = {
      folder: 'documents',
      maxSize: 50 * 1024 * 1024, // 50MB
      allowedMimeTypes: [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain',
        'application/zip',
        'application/x-rar-compressed',
      ],
    };
    return this.uploadService.uploadFile(file, options);
  }

  @Post('projects/photos')
  @ApiOperation({ summary: 'Upload project photos' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Project photos uploaded successfully' })
  @UseInterceptors(FilesInterceptor('files', 20))
  async uploadProjectPhotos(
    @UploadedFiles() files: Express.Multer.File[],
  ) {
    const options: UploadOptions = {
      folder: 'projects/photos',
      maxSize: 10 * 1024 * 1024, // 10MB per image
      allowedMimeTypes: [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/gif',
      ],
    };
    return this.uploadService.uploadFiles(files, options);
  }

  @Post('files')
  @ApiOperation({ summary: 'Generic file upload endpoint' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
        folder: {
          type: 'string',
          description: 'Optional folder path',
        },
      },
    },
  })
  @ApiQuery({ name: 'folder', type: 'string', required: false })
  @ApiResponse({ status: 201, description: 'File uploaded successfully' })
  @UseInterceptors(FileInterceptor('file'))
  async uploadGenericFile(
    @UploadedFile() file: Express.Multer.File,
    @Query('folder') folder?: string,
  ) {
    const options: UploadOptions = {
      folder: folder || 'general',
      maxSize: 100 * 1024 * 1024, // 100MB
    };
    return this.uploadService.uploadFile(file, options);
  }

  @Delete('files')
  @ApiOperation({ summary: 'Delete files by URLs' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        urls: {
          type: 'array',
          items: { type: 'string' },
          description: 'Array of file URLs to delete',
        },
        provider: {
          type: 'string',
          enum: ['local', 's3', 'cloudinary'],
          description: 'Storage provider',
        },
      },
      required: ['urls', 'provider'],
    },
  })
  @ApiResponse({ status: 200, description: 'Files deleted successfully' })
  async deleteFiles(
    @Body('urls') urls: string[],
    @Body('provider') provider: StorageProvider,
  ) {
    if (!Array.isArray(urls) || urls.length === 0) {
      throw new BadRequestException('urls must be a non-empty array');
    }

    const results = await Promise.allSettled(
      urls.map(url => this.uploadService.deleteFile(url, provider))
    );

    const succeeded = results.filter(r => r.status === 'fulfilled').length;
    const failed = results.filter(r => r.status === 'rejected').length;

    return {
      message: `Deleted ${succeeded} file(s), ${failed} failed`,
      succeeded,
      failed,
      total: urls.length,
    };
  }
}
