import {
    AbortMultipartUploadCommand,
    CompleteMultipartUploadCommand,
    CreateMultipartUploadCommand,
    HeadObjectCommand,
    PutObjectCommand,
    S3Client,
    UploadPartCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { v4 as uuidv4 } from 'uuid';
import { PrismaService } from '../prisma/prisma.service';
import {
    CompleteMultipartUploadDto,
    CompletePresignedUploadDto,
    CompleteUploadResponseDto,
    FileContext,
    InitiateMultipartResponseDto,
    InitiateMultipartUploadDto,
    MultipartUploadStatusDto,
    PartUploadInfo,
    PresignedUploadRequestDto,
    PresignedUploadResponseDto
} from './dto/presigned-upload.dto';

interface PendingUpload {
  uploadId: string;
  s3Key: string;
  filename: string;
  contentType: string;
  size: number;
  checksum?: string;
  checksumAlgorithm?: 'sha256' | 'md5';
  context?: FileContext;
  contextId?: number;
  userId: number;
  expiresAt: Date;
  createdAt: Date;
}

interface PendingMultipartUpload extends PendingUpload {
  s3UploadId: string;
  totalParts: number;
  chunkSize: number;
  completedParts: Map<number, { etag: string; size: number }>;
  status: 'pending' | 'in-progress' | 'completed' | 'aborted' | 'expired';
}

@Injectable()
export class PresignedUploadService {
  private readonly logger = new Logger(PresignedUploadService.name);
  private s3Client: S3Client | null = null;
  private bucket: string;

  // In-memory store for pending uploads (production: use Redis)
  private pendingUploads = new Map<string, PendingUpload>();
  private pendingMultipartUploads = new Map<string, PendingMultipartUpload>();

  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
  ) {
    this.initializeS3();
    this.startCleanupJob();
  }

  private initializeS3() {
    const awsRegion = this.configService.get<string>('AWS_REGION');
    const awsAccessKeyId = this.configService.get<string>('AWS_ACCESS_KEY_ID');
    const awsSecretAccessKey = this.configService.get<string>(
      'AWS_SECRET_ACCESS_KEY',
    );
    this.bucket = this.configService.get<string>('AWS_S3_BUCKET') || '';

    if (awsRegion && awsAccessKeyId && awsSecretAccessKey) {
      this.s3Client = new S3Client({
        region: awsRegion,
        credentials: {
          accessKeyId: awsAccessKeyId,
          secretAccessKey: awsSecretAccessKey,
        },
      });
      this.logger.log('S3 client initialized for presigned uploads');
    } else {
      this.logger.warn(
        'S3 not configured - presigned uploads will use local fallback',
      );
    }
  }

  /**
   * Clean up expired uploads periodically
   */
  private startCleanupJob() {
    setInterval(() => {
      const now = new Date();

      for (const [id, upload] of this.pendingUploads) {
        if (upload.expiresAt < now) {
          this.pendingUploads.delete(id);
          this.logger.debug(`Cleaned up expired upload: ${id}`);
        }
      }

      for (const [id, upload] of this.pendingMultipartUploads) {
        if (upload.expiresAt < now && upload.status !== 'completed') {
          upload.status = 'expired';
          this.abortMultipartUploadInternal(id).catch(() => {});
          this.logger.debug(`Cleaned up expired multipart upload: ${id}`);
        }
      }
    }, 60 * 1000); // Every minute
  }

  // =====================================================================
  // PERMISSION CHECKS
  // =====================================================================

  /**
   * Check if user has permission to upload in given context
   */
  private async checkUploadPermission(
    userId: number,
    context?: FileContext,
    contextId?: number,
  ): Promise<void> {
    if (!context || context === FileContext.GENERAL) {
      return; // General uploads allowed for all authenticated users
    }

    if (!contextId) {
      throw new BadRequestException(
        'contextId required for non-general uploads',
      );
    }

    switch (context) {
      case FileContext.PROJECT:
        // Check if user is owner (client or engineer) of project
        const project = await this.prisma.project.findFirst({
          where: {
            id: contextId,
            OR: [{ clientId: userId }, { engineerId: userId }],
          },
        });
        if (!project) {
          throw new ForbiddenException('Not authorized for this project');
        }
        break;

      case FileContext.CONVERSATION:
        // Check if user is member of conversation (when implemented)
        // For now, allow all
        break;

      case FileContext.PROFILE:
        // Only allow uploading to own profile
        if (contextId !== userId) {
          throw new ForbiddenException('Can only upload to own profile');
        }
        break;
    }
  }

  // =====================================================================
  // PRESIGNED SINGLE UPLOAD
  // =====================================================================

  /**
   * Generate presigned URL for single file upload
   */
  async requestPresignedUpload(
    userId: number,
    dto: PresignedUploadRequestDto,
  ): Promise<PresignedUploadResponseDto> {
    // Check permissions
    await this.checkUploadPermission(userId, dto.context, dto.contextId);

    // Validate content type
    this.validateContentType(dto.contentType);

    // Generate upload ID and S3 key
    const uploadId = uuidv4();
    const fileExtension = dto.filename.split('.').pop() || '';
    const folder = dto.folder || this.getDefaultFolder(dto.context);
    const s3Key = `${folder}/${uploadId}.${fileExtension}`;

    // Create expiration (1 hour)
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    // Store pending upload info
    const pendingUpload: PendingUpload = {
      uploadId,
      s3Key,
      filename: dto.filename,
      contentType: dto.contentType,
      size: dto.size,
      checksum: dto.checksum,
      checksumAlgorithm: dto.checksumAlgorithm,
      context: dto.context,
      contextId: dto.contextId,
      userId,
      expiresAt,
      createdAt: new Date(),
    };
    this.pendingUploads.set(uploadId, pendingUpload);

    // Generate presigned URL
    let uploadUrl: string;
    let headers: Record<string, string> = {};

    if (this.s3Client && this.bucket) {
      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: s3Key,
        ContentType: dto.contentType,
        ContentLength: dto.size,
      });
      uploadUrl = await getSignedUrl(this.s3Client, command, {
        expiresIn: 3600,
      });
      headers = {
        'Content-Type': dto.contentType,
        'Content-Length': dto.size.toString(),
      };
    } else {
      // Local fallback - return upload endpoint
      const baseUrl = this.configService.get<string>(
        'APP_URL',
        'http://localhost:3000',
      );
      uploadUrl = `${baseUrl}/api/v1/upload/presign/upload/${uploadId}`;
      headers = {
        'Content-Type': dto.contentType,
      };
    }

    // Final URL
    const fileUrl =
      this.s3Client && this.bucket
        ? `https://${this.bucket}.s3.${this.configService.get('AWS_REGION')}.amazonaws.com/${s3Key}`
        : `uploads/${s3Key}`;

    return {
      uploadId,
      uploadUrl,
      expiresAt,
      fileUrl,
      headers,
    };
  }

  /**
   * Complete presigned upload and save to database
   */
  async completePresignedUpload(
    userId: number,
    dto: CompletePresignedUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    const pending = this.pendingUploads.get(dto.uploadId);
    if (!pending) {
      throw new NotFoundException('Upload not found or expired');
    }

    if (pending.userId !== userId) {
      throw new ForbiddenException('Not your upload');
    }

    if (pending.expiresAt < new Date()) {
      this.pendingUploads.delete(dto.uploadId);
      throw new BadRequestException('Upload expired');
    }

    // Verify checksum if provided during presign
    let checksumVerified = true;
    if (pending.checksum) {
      checksumVerified = dto.checksum === pending.checksum;
      if (!checksumVerified) {
        throw new BadRequestException(
          'Checksum mismatch - file may be corrupted',
        );
      }
    }

    // Verify file exists in S3 (if using S3)
    if (this.s3Client && this.bucket) {
      try {
        await this.s3Client.send(
          new HeadObjectCommand({
            Bucket: this.bucket,
            Key: pending.s3Key,
          }),
        );
      } catch (error: unknown) {
        throw new BadRequestException(
          'File not found in storage - upload may have failed',
        );
      }
    }

    // Save to database
    const file = await this.prisma.file.create({
      data: {
        filename: pending.filename,
        url: pending.s3Key,
        mimeType: pending.contentType,
        size: pending.size,
        projectId:
          pending.context === FileContext.PROJECT
            ? pending.contextId
            : undefined,
        // Add more fields as needed
      },
    });

    // Clean up pending upload
    this.pendingUploads.delete(dto.uploadId);

    this.logger.log(
      `Completed presigned upload: ${dto.uploadId} -> file ID ${file.id}`,
    );

    return {
      fileId: file.id,
      url: pending.s3Key,
      filename: pending.filename,
      size: pending.size,
      contentType: pending.contentType,
      checksumVerified,
    };
  }

  // =====================================================================
  // MULTIPART (CHUNKED) UPLOAD
  // =====================================================================

  /**
   * Initiate multipart upload
   */
  async initiateMultipartUpload(
    userId: number,
    dto: InitiateMultipartUploadDto,
  ): Promise<InitiateMultipartResponseDto> {
    // Check permissions
    await this.checkUploadPermission(userId, dto.context, dto.contextId);

    // Validate content type
    this.validateContentType(dto.contentType);

    const uploadId = uuidv4();
    const fileExtension = dto.filename.split('.').pop() || '';
    const folder = dto.folder || this.getDefaultFolder(dto.context);
    const s3Key = `${folder}/${uploadId}.${fileExtension}`;

    // Calculate chunk size and total parts
    const chunkSize = dto.chunkSize || 10 * 1024 * 1024; // 10MB default
    const totalParts = Math.ceil(dto.totalSize / chunkSize);

    if (totalParts > 10000) {
      throw new BadRequestException('Too many parts - increase chunk size');
    }

    // Expiration: 24 hours for multipart
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    let s3UploadId = '';
    const partUrls: PartUploadInfo[] = [];

    if (this.s3Client && this.bucket) {
      // Initiate S3 multipart upload
      const createCommand = new CreateMultipartUploadCommand({
        Bucket: this.bucket,
        Key: s3Key,
        ContentType: dto.contentType,
      });
      const createResult = await this.s3Client.send(createCommand);
      s3UploadId = createResult.UploadId || '';

      // Generate presigned URLs for each part
      for (let partNumber = 1; partNumber <= totalParts; partNumber++) {
        const uploadPartCommand = new UploadPartCommand({
          Bucket: this.bucket,
          Key: s3Key,
          UploadId: s3UploadId,
          PartNumber: partNumber,
        });
        const partUrl = await getSignedUrl(this.s3Client, uploadPartCommand, {
          expiresIn: 24 * 60 * 60, // 24 hours
        });

        const startByte = (partNumber - 1) * chunkSize;
        const endByte = Math.min(partNumber * chunkSize - 1, dto.totalSize - 1);

        partUrls.push({
          partNumber,
          uploadUrl: partUrl,
          startByte,
          endByte,
          size: endByte - startByte + 1,
        });
      }
    } else {
      // Local fallback
      const baseUrl = this.configService.get<string>(
        'APP_URL',
        'http://localhost:3000',
      );
      for (let partNumber = 1; partNumber <= totalParts; partNumber++) {
        const startByte = (partNumber - 1) * chunkSize;
        const endByte = Math.min(partNumber * chunkSize - 1, dto.totalSize - 1);

        partUrls.push({
          partNumber,
          uploadUrl: `${baseUrl}/api/v1/upload/multipart/part`,
          startByte,
          endByte,
          size: endByte - startByte + 1,
        });
      }
    }

    // Store pending multipart upload
    const pendingUpload: PendingMultipartUpload = {
      uploadId,
      s3Key,
      s3UploadId,
      filename: dto.filename,
      contentType: dto.contentType,
      size: dto.totalSize,
      context: dto.context,
      contextId: dto.contextId,
      userId,
      expiresAt,
      createdAt: new Date(),
      totalParts,
      chunkSize,
      completedParts: new Map(),
      status: 'pending',
    };
    this.pendingMultipartUploads.set(uploadId, pendingUpload);

    this.logger.log(
      `Initiated multipart upload: ${uploadId}, ${totalParts} parts`,
    );

    return {
      uploadId,
      s3UploadId: s3UploadId || undefined,
      totalParts,
      chunkSize,
      expiresAt,
      partUrls,
    };
  }

  /**
   * Record completed part (called after client uploads to presigned URL)
   */
  async recordCompletedPart(
    userId: number,
    uploadId: string,
    partNumber: number,
    etag: string,
    size: number,
  ): Promise<void> {
    const pending = this.pendingMultipartUploads.get(uploadId);
    if (!pending) {
      throw new NotFoundException('Multipart upload not found');
    }

    if (pending.userId !== userId) {
      throw new ForbiddenException('Not your upload');
    }

    pending.completedParts.set(partNumber, { etag, size });
    pending.status = 'in-progress';

    this.logger.debug(`Recorded part ${partNumber} for upload ${uploadId}`);
  }

  /**
   * Complete multipart upload
   */
  async completeMultipartUpload(
    userId: number,
    dto: CompleteMultipartUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    const pending = this.pendingMultipartUploads.get(dto.uploadId);
    if (!pending) {
      throw new NotFoundException('Multipart upload not found or expired');
    }

    if (pending.userId !== userId) {
      throw new ForbiddenException('Not your upload');
    }

    if (pending.status === 'completed') {
      throw new BadRequestException('Upload already completed');
    }

    if (pending.status === 'aborted') {
      throw new BadRequestException('Upload was aborted');
    }

    // Verify all parts
    if (dto.parts.length !== pending.totalParts) {
      throw new BadRequestException(
        `Expected ${pending.totalParts} parts, got ${dto.parts.length}`,
      );
    }

    // Complete S3 multipart upload
    if (this.s3Client && this.bucket && pending.s3UploadId) {
      const completeCommand = new CompleteMultipartUploadCommand({
        Bucket: this.bucket,
        Key: pending.s3Key,
        UploadId: pending.s3UploadId,
        MultipartUpload: {
          Parts: dto.parts
            .sort((a, b) => a.partNumber - b.partNumber)
            .map((p) => ({
              PartNumber: p.partNumber,
              ETag: p.etag,
            })),
        },
      });
      await this.s3Client.send(completeCommand);
    }

    // Calculate total uploaded size
    const uploadedSize = dto.parts.reduce((sum, p) => sum + p.size, 0);

    // Save to database
    const file = await this.prisma.file.create({
      data: {
        filename: pending.filename,
        url: pending.s3Key,
        mimeType: pending.contentType,
        size: uploadedSize,
        projectId:
          pending.context === FileContext.PROJECT
            ? pending.contextId
            : undefined,
      },
    });

    // Update status and clean up
    pending.status = 'completed';

    // Keep completed upload info for a while for idempotency
    setTimeout(
      () => {
        this.pendingMultipartUploads.delete(dto.uploadId);
      },
      60 * 60 * 1000,
    ); // 1 hour

    this.logger.log(
      `Completed multipart upload: ${dto.uploadId} -> file ID ${file.id}`,
    );

    return {
      fileId: file.id,
      url: pending.s3Key,
      filename: pending.filename,
      size: uploadedSize,
      contentType: pending.contentType,
      checksumVerified: !!dto.finalChecksum,
    };
  }

  /**
   * Abort multipart upload
   */
  async abortMultipartUpload(userId: number, uploadId: string): Promise<void> {
    const pending = this.pendingMultipartUploads.get(uploadId);
    if (!pending) {
      throw new NotFoundException('Multipart upload not found');
    }

    if (pending.userId !== userId) {
      throw new ForbiddenException('Not your upload');
    }

    await this.abortMultipartUploadInternal(uploadId);
    this.logger.log(`Aborted multipart upload: ${uploadId}`);
  }

  private async abortMultipartUploadInternal(uploadId: string): Promise<void> {
    const pending = this.pendingMultipartUploads.get(uploadId);
    if (!pending) return;

    // Abort S3 multipart upload
    if (this.s3Client && this.bucket && pending.s3UploadId) {
      try {
        const abortCommand = new AbortMultipartUploadCommand({
          Bucket: this.bucket,
          Key: pending.s3Key,
          UploadId: pending.s3UploadId,
        });
        await this.s3Client.send(abortCommand);
      } catch (error: unknown) {
        this.logger.warn(`Failed to abort S3 multipart upload: ${uploadId}`);
      }
    }

    pending.status = 'aborted';
    this.pendingMultipartUploads.delete(uploadId);
  }

  /**
   * Get multipart upload status
   */
  async getMultipartUploadStatus(
    userId: number,
    uploadId: string,
  ): Promise<MultipartUploadStatusDto> {
    const pending = this.pendingMultipartUploads.get(uploadId);
    if (!pending) {
      throw new NotFoundException('Multipart upload not found');
    }

    if (pending.userId !== userId) {
      throw new ForbiddenException('Not your upload');
    }

    const completedPartNumbers = Array.from(pending.completedParts.keys());
    const uploadedSize = Array.from(pending.completedParts.values()).reduce(
      (sum, p) => sum + p.size,
      0,
    );

    return {
      uploadId: pending.uploadId,
      status: pending.status,
      filename: pending.filename,
      totalSize: pending.size,
      uploadedSize,
      totalParts: pending.totalParts,
      completedParts: completedPartNumbers,
      progress: Math.round(
        (completedPartNumbers.length / pending.totalParts) * 100,
      ),
      createdAt: pending.createdAt,
      expiresAt: pending.expiresAt,
    };
  }

  /**
   * List user's pending uploads
   */
  async listPendingUploads(
    userId: number,
  ): Promise<MultipartUploadStatusDto[]> {
    const uploads: MultipartUploadStatusDto[] = [];

    for (const [uploadId, pending] of this.pendingMultipartUploads) {
      if (pending.userId === userId && pending.status !== 'completed') {
        uploads.push({
          uploadId,
          status: pending.status,
          filename: pending.filename,
          totalSize: pending.size,
          uploadedSize: Array.from(pending.completedParts.values()).reduce(
            (sum, p) => sum + p.size,
            0,
          ),
          totalParts: pending.totalParts,
          completedParts: Array.from(pending.completedParts.keys()),
          progress: Math.round(
            (pending.completedParts.size / pending.totalParts) * 100,
          ),
          createdAt: pending.createdAt,
          expiresAt: pending.expiresAt,
        });
      }
    }

    return uploads;
  }

  // =====================================================================
  // HELPERS
  // =====================================================================

  private validateContentType(contentType: string): void {
    const allowed = [
      // Images
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/svg+xml',
      // Videos
      'video/mp4',
      'video/webm',
      'video/quicktime',
      'video/x-msvideo',
      // Audio
      'audio/mpeg',
      'audio/wav',
      'audio/ogg',
      'audio/webm',
      // Documents
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      // Archives
      'application/zip',
      'application/x-rar-compressed',
      'application/x-7z-compressed',
      // Text
      'text/plain',
      'text/csv',
      // Others
      'application/json',
      'application/octet-stream',
    ];

    if (!allowed.includes(contentType)) {
      throw new BadRequestException(`Content type not allowed: ${contentType}`);
    }
  }

  private getDefaultFolder(context?: FileContext): string {
    switch (context) {
      case FileContext.PROJECT:
        return 'projects';
      case FileContext.CONVERSATION:
        return 'conversations';
      case FileContext.PROFILE:
        return 'profiles';
      default:
        return 'general';
    }
  }
}
