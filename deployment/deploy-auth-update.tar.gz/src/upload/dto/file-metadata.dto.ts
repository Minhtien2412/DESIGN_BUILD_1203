import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsOptional,
    IsString,
    MaxLength,
    Min,
} from 'class-validator';

/**
 * File status enum
 */
export enum FileStatus {
  ACTIVE = 'active',
  DELETED = 'deleted',
  ARCHIVED = 'archived',
}

/**
 * File access type
 */
export enum FileAccessType {
  VIEW = 'view',
  DOWNLOAD = 'download',
  EDIT = 'edit',
  DELETE = 'delete',
  SHARE = 'share',
}

/**
 * Create file metadata
 */
export class CreateFileMetadataDto {
  @ApiProperty({ description: 'Original filename' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  filename: string;

  @ApiProperty({ description: 'File URL/path' })
  @IsString()
  @IsNotEmpty()
  url: string;

  @ApiProperty({ description: 'MIME type' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  mimeType: string;

  @ApiProperty({ description: 'File size in bytes' })
  @IsInt()
  @Min(0)
  size: number;

  @ApiPropertyOptional({ description: 'Checksum (SHA256)' })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  checksum?: string;

  @ApiPropertyOptional({ description: 'Thumbnail URL' })
  @IsOptional()
  @IsString()
  thumbnailUrl?: string;

  @ApiPropertyOptional({ description: 'Project ID' })
  @IsOptional()
  @IsInt()
  projectId?: number;

  @ApiPropertyOptional({ description: 'Task ID' })
  @IsOptional()
  @IsInt()
  taskId?: number;

  @ApiPropertyOptional({ description: 'Conversation ID' })
  @IsOptional()
  @IsInt()
  conversationId?: number;

  @ApiPropertyOptional({ description: 'Additional metadata' })
  @IsOptional()
  metadata?: Record<string, any>;
}

/**
 * Update file metadata
 */
export class UpdateFileMetadataDto {
  @ApiPropertyOptional({ description: 'New filename' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  filename?: string;

  @ApiPropertyOptional({ description: 'File status' })
  @IsOptional()
  @IsEnum(FileStatus)
  status?: FileStatus;

  @ApiPropertyOptional({ description: 'Additional metadata' })
  @IsOptional()
  metadata?: Record<string, any>;
}

/**
 * File response DTO
 */
export class FileResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  filename: string;

  @ApiProperty()
  url: string;

  @ApiProperty()
  mimeType: string;

  @ApiProperty()
  size: number;

  @ApiPropertyOptional()
  checksum?: string;

  @ApiPropertyOptional()
  thumbnailUrl?: string;

  @ApiProperty()
  status: FileStatus;

  @ApiProperty()
  version: number;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;

  @ApiPropertyOptional()
  deletedAt?: Date;

  @ApiPropertyOptional()
  ownerId?: number;

  @ApiPropertyOptional()
  projectId?: number;

  @ApiPropertyOptional()
  taskId?: number;
}

/**
 * File version response
 */
export class FileVersionResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  fileId: number;

  @ApiProperty()
  version: number;

  @ApiProperty()
  url: string;

  @ApiProperty()
  size: number;

  @ApiPropertyOptional()
  checksum?: string;

  @ApiProperty()
  createdAt: Date;

  @ApiPropertyOptional()
  createdById?: number;

  @ApiPropertyOptional()
  comment?: string;
}

/**
 * File access log response
 */
export class FileAccessLogDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  fileId: number;

  @ApiProperty()
  userId: number;

  @ApiProperty({ enum: FileAccessType })
  accessType: FileAccessType;

  @ApiProperty()
  accessedAt: Date;

  @ApiPropertyOptional()
  ipAddress?: string;

  @ApiPropertyOptional()
  userAgent?: string;
}

/**
 * List files query params
 */
export class ListFilesQueryDto {
  @ApiPropertyOptional({ description: 'Page number' })
  @IsOptional()
  @IsInt()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ description: 'Items per page' })
  @IsOptional()
  @IsInt()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Project ID filter' })
  @IsOptional()
  @IsInt()
  projectId?: number;

  @ApiPropertyOptional({ description: 'Task ID filter' })
  @IsOptional()
  @IsInt()
  taskId?: number;

  @ApiPropertyOptional({ description: 'File status filter' })
  @IsOptional()
  @IsEnum(FileStatus)
  status?: FileStatus;

  @ApiPropertyOptional({ description: 'MIME type filter (e.g., image/*)' })
  @IsOptional()
  @IsString()
  mimeType?: string;

  @ApiPropertyOptional({ description: 'Search by filename' })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({ description: 'Include deleted files' })
  @IsOptional()
  includeDeleted?: boolean;

  @ApiPropertyOptional({ description: 'Sort by field' })
  @IsOptional()
  @IsString()
  sortBy?: 'filename' | 'size' | 'createdAt' | 'updatedAt';

  @ApiPropertyOptional({ description: 'Sort direction' })
  @IsOptional()
  @IsString()
  sortOrder?: 'asc' | 'desc';
}

/**
 * Restore file DTO
 */
export class RestoreFileDto {
  @ApiPropertyOptional({ description: 'Specific version to restore to' })
  @IsOptional()
  @IsInt()
  @Min(1)
  version?: number;
}

/**
 * Create new version DTO
 */
export class CreateFileVersionDto {
  @ApiProperty({ description: 'New file URL' })
  @IsString()
  @IsNotEmpty()
  url: string;

  @ApiProperty({ description: 'New file size' })
  @IsInt()
  @Min(0)
  size: number;

  @ApiPropertyOptional({ description: 'Checksum' })
  @IsOptional()
  @IsString()
  checksum?: string;

  @ApiPropertyOptional({ description: 'Version comment' })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  comment?: string;
}
