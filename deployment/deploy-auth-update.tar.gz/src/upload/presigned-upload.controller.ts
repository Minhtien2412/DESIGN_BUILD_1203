import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Request,
    UseGuards
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    AbortMultipartUploadDto,
    CompleteMultipartUploadDto,
    CompletePresignedUploadDto,
    CompleteUploadResponseDto,
    InitiateMultipartResponseDto,
    InitiateMultipartUploadDto,
    MultipartUploadStatusDto,
    PresignedUploadRequestDto,
    PresignedUploadResponseDto,
} from './dto/presigned-upload.dto';
import { PresignedUploadService } from './presigned-upload.service';

interface AuthRequest extends Request {
  user: { id: number; email: string };
}

@ApiTags('Presigned Upload')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'upload', version: '1' })
export class PresignedUploadController {
  constructor(
    private readonly presignedUploadService: PresignedUploadService,
  ) {}

  // =====================================================================
  // PRESIGNED SINGLE UPLOAD
  // =====================================================================

  @Post('presign')
  @ApiOperation({
    summary: 'Request presigned URL for file upload',
    description:
      'Get a presigned URL to upload a file directly to storage. Client uploads to the URL, then calls /complete.',
  })
  @ApiResponse({
    status: 201,
    description: 'Presigned URL generated',
    type: PresignedUploadResponseDto,
  })
  async requestPresignedUpload(
    @Request() req: AuthRequest,
    @Body() dto: PresignedUploadRequestDto,
  ): Promise<PresignedUploadResponseDto> {
    return this.presignedUploadService.requestPresignedUpload(req.user.id, dto);
  }

  @Post('presign/complete')
  @ApiOperation({
    summary: 'Complete presigned upload',
    description:
      'Confirm upload completion, verify checksum, and save file metadata to database.',
  })
  @ApiResponse({
    status: 201,
    description: 'Upload completed and saved',
    type: CompleteUploadResponseDto,
  })
  async completePresignedUpload(
    @Request() req: AuthRequest,
    @Body() dto: CompletePresignedUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    return this.presignedUploadService.completePresignedUpload(
      req.user.id,
      dto,
    );
  }

  // =====================================================================
  // MULTIPART (CHUNKED) UPLOAD
  // =====================================================================

  @Post('multipart/initiate')
  @ApiOperation({
    summary: 'Initiate multipart upload',
    description:
      'Start a chunked upload for large files. Returns presigned URLs for each part.',
  })
  @ApiResponse({
    status: 201,
    description: 'Multipart upload initiated',
    type: InitiateMultipartResponseDto,
  })
  async initiateMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: InitiateMultipartUploadDto,
  ): Promise<InitiateMultipartResponseDto> {
    return this.presignedUploadService.initiateMultipartUpload(
      req.user.id,
      dto,
    );
  }

  @Post('multipart/part/complete')
  @ApiOperation({
    summary: 'Record completed part',
    description:
      'Record that a part was successfully uploaded (called after uploading to presigned URL).',
  })
  @ApiResponse({ status: 200, description: 'Part recorded' })
  @HttpCode(HttpStatus.OK)
  async recordCompletedPart(
    @Request() req: AuthRequest,
    @Body()
    body: { uploadId: string; partNumber: number; etag: string; size: number },
  ): Promise<{ success: boolean }> {
    await this.presignedUploadService.recordCompletedPart(
      req.user.id,
      body.uploadId,
      body.partNumber,
      body.etag,
      body.size,
    );
    return { success: true };
  }

  @Post('multipart/complete')
  @ApiOperation({
    summary: 'Complete multipart upload',
    description: 'Finalize the multipart upload after all parts are uploaded.',
  })
  @ApiResponse({
    status: 201,
    description: 'Multipart upload completed',
    type: CompleteUploadResponseDto,
  })
  async completeMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: CompleteMultipartUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    return this.presignedUploadService.completeMultipartUpload(
      req.user.id,
      dto,
    );
  }

  @Post('multipart/abort')
  @ApiOperation({
    summary: 'Abort multipart upload',
    description:
      'Cancel an in-progress multipart upload and clean up uploaded parts.',
  })
  @ApiResponse({ status: 200, description: 'Upload aborted' })
  @HttpCode(HttpStatus.OK)
  async abortMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: AbortMultipartUploadDto,
  ): Promise<{ success: boolean }> {
    await this.presignedUploadService.abortMultipartUpload(
      req.user.id,
      dto.uploadId,
    );
    return { success: true };
  }

  @Get('multipart/:uploadId/status')
  @ApiOperation({
    summary: 'Get multipart upload status',
    description: 'Get the current status and progress of a multipart upload.',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload status',
    type: MultipartUploadStatusDto,
  })
  async getMultipartUploadStatus(
    @Request() req: AuthRequest,
    @Param('uploadId') uploadId: string,
  ): Promise<MultipartUploadStatusDto> {
    return this.presignedUploadService.getMultipartUploadStatus(
      req.user.id,
      uploadId,
    );
  }

  @Get('multipart/pending')
  @ApiOperation({
    summary: 'List pending uploads',
    description:
      'Get all pending/in-progress multipart uploads for the current user.',
  })
  @ApiResponse({
    status: 200,
    description: 'List of pending uploads',
    type: [MultipartUploadStatusDto],
  })
  async listPendingUploads(
    @Request() req: AuthRequest,
  ): Promise<MultipartUploadStatusDto[]> {
    return this.presignedUploadService.listPendingUploads(req.user.id);
  }
}
