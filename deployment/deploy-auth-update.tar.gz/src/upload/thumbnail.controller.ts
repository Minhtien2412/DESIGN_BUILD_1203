import {
    Body,
    Controller,
    Delete,
    Post,
    Query,
    UploadedFile,
    UseGuards,
    UseInterceptors
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
    ApiBearerAuth,
    ApiBody,
    ApiConsumes,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    ThumbnailOptions,
    ThumbnailService,
    ThumbnailSize,
} from './thumbnail.service';

@ApiTags('Thumbnails')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'thumbnails', version: '1' })
export class ThumbnailController {
  constructor(private readonly thumbnailService: ThumbnailService) {}

  @Post('generate')
  @ApiOperation({ summary: 'Generate thumbnail from uploaded image' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  @ApiQuery({ name: 'width', required: false, type: 'number' })
  @ApiQuery({ name: 'height', required: false, type: 'number' })
  @ApiQuery({ name: 'format', required: false, enum: ['jpeg', 'png', 'webp'] })
  @ApiQuery({ name: 'quality', required: false, type: 'number' })
  @ApiResponse({ status: 201, description: 'Thumbnail generated' })
  @UseInterceptors(FileInterceptor('file'))
  async generateThumbnail(
    @UploadedFile() file: Express.Multer.File,
    @Query('width') width?: number,
    @Query('height') height?: number,
    @Query('format') format?: 'jpeg' | 'png' | 'webp',
    @Query('quality') quality?: number,
  ) {
    const options: ThumbnailOptions = {
      width: width ? Number(width) : undefined,
      height: height ? Number(height) : undefined,
      format,
      quality: quality ? Number(quality) : undefined,
    };

    return this.thumbnailService.generateImageThumbnail(
      file.buffer,
      file.originalname,
      options,
    );
  }

  @Post('generate-multiple')
  @ApiOperation({ summary: 'Generate multiple thumbnail sizes' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  @ApiQuery({
    name: 'sizes',
    required: false,
    type: 'string',
    description: 'Comma-separated sizes: small,medium,large',
  })
  @ApiResponse({ status: 201, description: 'Thumbnails generated' })
  @UseInterceptors(FileInterceptor('file'))
  async generateMultipleSizes(
    @UploadedFile() file: Express.Multer.File,
    @Query('sizes') sizesParam?: string,
  ) {
    let sizes: ThumbnailSize[] = [
      ThumbnailSize.SMALL,
      ThumbnailSize.MEDIUM,
      ThumbnailSize.LARGE,
    ];

    if (sizesParam) {
      sizes = sizesParam
        .split(',')
        .filter((s) =>
          Object.values(ThumbnailSize).includes(s as ThumbnailSize),
        ) as ThumbnailSize[];
    }

    return this.thumbnailService.generateMultipleSizes(
      file.buffer,
      file.originalname,
      sizes,
    );
  }

  @Post('video')
  @ApiOperation({ summary: 'Generate video poster thumbnail' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        videoPath: { type: 'string', description: 'Path to video file' },
        timestamp: {
          type: 'number',
          description: 'Timestamp in seconds (default: 1)',
        },
        width: { type: 'number' },
        height: { type: 'number' },
      },
      required: ['videoPath'],
    },
  })
  @ApiResponse({ status: 201, description: 'Video thumbnail generated' })
  async generateVideoThumbnail(
    @Body('videoPath') videoPath: string,
    @Body('timestamp') timestamp?: number,
    @Body('width') width?: number,
    @Body('height') height?: number,
  ) {
    return this.thumbnailService.generateVideoThumbnail(
      videoPath,
      timestamp || 1,
      { width, height },
    );
  }

  @Post('pdf')
  @ApiOperation({ summary: 'Generate PDF first page thumbnail' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        pdfPath: { type: 'string', description: 'Path to PDF file' },
        width: { type: 'number' },
        height: { type: 'number' },
      },
      required: ['pdfPath'],
    },
  })
  @ApiResponse({ status: 201, description: 'PDF thumbnail generated' })
  async generatePdfThumbnail(
    @Body('pdfPath') pdfPath: string,
    @Body('width') width?: number,
    @Body('height') height?: number,
  ) {
    return this.thumbnailService.generatePdfThumbnail(pdfPath, {
      width,
      height,
    });
  }

  @Delete()
  @ApiOperation({ summary: 'Delete thumbnail by URL' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'Thumbnail URL to delete' },
      },
      required: ['url'],
    },
  })
  @ApiResponse({ status: 200, description: 'Thumbnail deleted' })
  async deleteThumbnail(@Body('url') url: string) {
    await this.thumbnailService.deleteThumbnail(url);
    return { success: true };
  }
}
