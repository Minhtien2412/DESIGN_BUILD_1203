/**
 * Messages Controller
 * ===================
 *
 * REST API endpoints cho messages
 *
 * Endpoints:
 * - POST   /conversations/:id/messages       - Gửi tin nhắn
 * - GET    /conversations/:id/messages       - Lấy danh sách tin nhắn
 * - GET    /conversations/:id/messages/:msgId - Lấy tin nhắn cụ thể
 * - PATCH  /conversations/:id/messages/:msgId - Sửa tin nhắn
 * - DELETE /conversations/:id/messages/:msgId - Xóa tin nhắn
 * - POST   /conversations/:id/messages/:msgId/reactions - Thêm reaction
 * - DELETE /conversations/:id/messages/:msgId/reactions/:emoji - Xóa reaction
 * - GET    /conversations/:id/messages/search - Tìm kiếm tin nhắn
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Patch,
    Post,
    Query,
    Request,
} from '@nestjs/common';
import {
    AddReactionDto,
    DeleteMessageDto,
    GetMessagesQueryDto,
    MarkAsReadDto,
    MessageListResponseDto,
    MessageResponseDto,
    ReadReceiptsResponseDto,
    SearchMessagesQueryDto,
    SendMessageDto,
    UpdateMessageDto
} from './dto';
import { MessagesService } from './messages.service';

// TODO: Import JwtAuthGuard from your auth module
// import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('conversations/:conversationId/messages')
// @UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  // ============================================
  // SEND MESSAGE
  // ============================================

  /**
   * Gửi tin nhắn qua REST API
   *
   * POST /conversations/:conversationId/messages
   *
   * Body:
   * {
   *   "clientMessageId": "uuid-v4", // Required for idempotency
   *   "type": "TEXT",
   *   "content": "Hello world",
   *   "attachments": [...],
   *   "replyToMessageId": "msg-id"
   * }
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async sendMessage(
    @Param('conversationId') conversationId: string,
    @Body() dto: SendMessageDto,
    @Request() req: any,
  ): Promise<MessageResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1; // TODO: Get from JWT
    return this.messagesService.sendMessage(conversationId, userId, dto);
  }

  // ============================================
  // GET MESSAGES
  // ============================================

  /**
   * Lấy danh sách tin nhắn với cursor-based pagination
   *
   * GET /conversations/:conversationId/messages
   *
   * Query params:
   * - cursor: messageId để load từ đó
   * - direction: 'before' (older) hoặc 'after' (newer)
   * - limit: số lượng (default 50, max 100)
   * - aroundSeq: load messages xung quanh seq number
   */
  @Get()
  async getMessages(
    @Param('conversationId') conversationId: string,
    @Query() query: GetMessagesQueryDto,
    @Request() req: any,
  ): Promise<MessageListResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.getMessages(conversationId, userId, query);
  }

  // ============================================
  // GET SINGLE MESSAGE
  // ============================================

  /**
   * Lấy chi tiết một tin nhắn
   *
   * GET /conversations/:conversationId/messages/:messageId
   */
  @Get(':messageId')
  async getMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Request() req: any,
  ): Promise<MessageResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.getMessage(conversationId, messageId, userId);
  }

  // ============================================
  // UPDATE MESSAGE
  // ============================================

  /**
   * Sửa nội dung tin nhắn (chỉ sender, trong 15 phút)
   *
   * PATCH /conversations/:conversationId/messages/:messageId
   *
   * Body:
   * {
   *   "content": "Updated message"
   * }
   */
  @Patch(':messageId')
  async updateMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Body() dto: UpdateMessageDto,
    @Request() req: any,
  ): Promise<MessageResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.updateMessage(
      conversationId,
      messageId,
      userId,
      dto,
    );
  }

  // ============================================
  // DELETE MESSAGE
  // ============================================

  /**
   * Xóa tin nhắn
   *
   * DELETE /conversations/:conversationId/messages/:messageId
   *
   * Query:
   * - deleteForAll: true để xóa cho tất cả (chỉ sender)
   */
  @Delete(':messageId')
  @HttpCode(HttpStatus.OK)
  async deleteMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Query() query: DeleteMessageDto,
    @Request() req: any,
  ): Promise<{ success: boolean }> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.deleteMessage(
      conversationId,
      messageId,
      userId,
      query.deleteForAll,
    );
  }

  // ============================================
  // REACTIONS
  // ============================================

  /**
   * Thêm reaction vào tin nhắn
   *
   * POST /conversations/:conversationId/messages/:messageId/reactions
   *
   * Body:
   * {
   *   "emoji": "👍"
   * }
   */
  @Post(':messageId/reactions')
  @HttpCode(HttpStatus.OK)
  async addReaction(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Body() dto: AddReactionDto,
    @Request() req: any,
  ): Promise<{ success: boolean }> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.addReaction(
      conversationId,
      messageId,
      userId,
      dto.emoji,
    );
  }

  /**
   * Xóa reaction khỏi tin nhắn
   *
   * DELETE /conversations/:conversationId/messages/:messageId/reactions/:emoji
   */
  @Delete(':messageId/reactions/:emoji')
  @HttpCode(HttpStatus.OK)
  async removeReaction(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Param('emoji') emoji: string,
    @Request() req: any,
  ): Promise<{ success: boolean }> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.removeReaction(
      conversationId,
      messageId,
      userId,
      emoji,
    );
  }

  // ============================================
  // SEARCH
  // ============================================

  /**
   * Tìm kiếm tin nhắn trong conversation
   *
   * GET /conversations/:conversationId/messages/search?q=keyword
   */
  @Get('search')
  async searchMessages(
    @Param('conversationId') conversationId: string,
    @Query() query: SearchMessagesQueryDto,
    @Request() req: any,
  ): Promise<MessageListResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.searchMessages(
      conversationId,
      userId,
      query.q,
      query.limit,
    );
  }

  // ============================================
  // READ RECEIPTS (MSG-004)
  // ============================================

  /**
   * Đánh dấu đã đọc tin nhắn
   *
   * POST /conversations/:conversationId/messages/read
   *
   * Body:
   * {
   *   "messageId": "optional-msg-id" // Nếu không có, mark all as read
   * }
   */
  @Post('read')
  @HttpCode(HttpStatus.OK)
  async markAsRead(
    @Param('conversationId') conversationId: string,
    @Body() dto: MarkAsReadDto,
    @Request() req: any,
  ): Promise<ReadReceiptsResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.markAsRead(conversationId, userId, dto);
  }

  /**
   * Lấy danh sách người đã đọc tin nhắn
   *
   * GET /conversations/:conversationId/messages/:messageId/read-receipts
   */
  @Get(':messageId/read-receipts')
  async getReadReceipts(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Request() req: any,
  ): Promise<ReadReceiptsResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.getReadReceipts(
      conversationId,
      messageId,
      userId,
    );
  }
}
