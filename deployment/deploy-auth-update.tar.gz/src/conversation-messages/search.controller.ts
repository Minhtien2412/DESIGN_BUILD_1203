/**
 * Global Search Controller
 * ========================
 *
 * Global search endpoints across all user's conversations
 *
 * Endpoints:
 * - GET /messages/search - Search messages globally
 * - GET /messages/unread-counts - Get unread counts
 */

import { Controller, Get, Query, Request } from '@nestjs/common';
import { GlobalSearchQueryDto, GlobalSearchResponseDto } from './dto';
import { MessagesService } from './messages.service';

@Controller('messages')
export class SearchController {
  constructor(private readonly messagesService: MessagesService) {}

  /**
   * Global search tin nhắn trong tất cả conversations của user
   *
   * GET /messages/search
   *
   * Query params:
   * - q: Search query (required)
   * - limit: Max results (default 20)
   * - conversationId: Filter by specific conversation
   * - type: Filter by message type (TEXT, IMAGE, etc.)
   * - fromDate: Filter from date (ISO string)
   * - toDate: Filter to date (ISO string)
   * - senderId: Filter by sender
   */
  @Get('search')
  async globalSearch(
    @Query() query: GlobalSearchQueryDto,
    @Request() req: any,
  ): Promise<GlobalSearchResponseDto> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.globalSearchMessages(userId, query);
  }

  /**
   * Get unread counts for all conversations
   *
   * GET /messages/unread-counts
   */
  @Get('unread-counts')
  async getUnreadCounts(
    @Request() req: any,
  ): Promise<{ conversationId: string; unreadCount: number }[]> {
    const userId = req.user?.id || req.user?.sub || 1;
    return this.messagesService.getUnreadCounts(userId);
  }
}
