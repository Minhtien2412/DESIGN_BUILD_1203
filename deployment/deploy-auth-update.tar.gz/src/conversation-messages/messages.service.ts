/**
 * Messages Service
 * ================
 *
 * Business logic cho tin nhắn (REST API backup)
 *
 * WebSocket là primary, REST là backup khi:
 * - Client mất kết nối WS
 * - Batch operations
 * - Initial sync
 */

import {
  ForbiddenException,
  Inject,
  Injectable,
  NotFoundException,
  forwardRef,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ConversationsMessagingGateway } from './conversations-messaging.gateway';
import {
  GetMessagesQueryDto,
  GlobalSearchQueryDto,
  GlobalSearchResponseDto,
  MarkAsReadDto,
  MessageListResponseDto,
  MessageResponseDto,
  ReadReceiptsResponseDto,
  SendMessageDto,
  UpdateMessageDto,
} from './dto';

@Injectable()
export class MessagesService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(forwardRef(() => ConversationsMessagingGateway))
    private readonly messagingGateway: ConversationsMessagingGateway,
  ) {}

  // ============================================
  // SEND MESSAGE (REST backup)
  // ============================================

  /**
   * Gửi tin nhắn qua REST API
   * - Dùng khi client mất kết nối WebSocket
   * - Idempotent via clientMessageId
   */
  async sendMessage(
    conversationId: string,
    userId: number,
    dto: SendMessageDto,
  ): Promise<MessageResponseDto> {
    // 1. Validate participant
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant || participant.leftAt || participant.removedAt) {
      throw new ForbiddenException(
        'Bạn không phải thành viên của conversation này',
      );
    }

    // 2. Idempotency check
    const existingMessage = await this.prisma.conversationMessage.findUnique({
      where: {
        conversationId_clientMessageId: {
          conversationId,
          clientMessageId: dto.clientMessageId,
        },
      },
      include: {
        sender: {
          select: { id: true, name: true, avatar: true },
        },
      },
    });

    if (existingMessage) {
      // Return existing message (idempotent)
      return this.formatMessageResponse(existingMessage);
    }

    // 3. Get next sequence
    const lastMessage = await this.prisma.conversationMessage.findFirst({
      where: { conversationId },
      orderBy: { seq: 'desc' },
      select: { seq: true },
    });
    const seq = (lastMessage?.seq || 0) + 1;

    // 4. Create message
    const message = await this.prisma.$transaction(async (tx) => {
      const msg = await tx.conversationMessage.create({
        data: {
          conversationId,
          senderId: userId,
          clientMessageId: dto.clientMessageId,
          seq,
          type: (dto.type || 'TEXT') as any,
          content: dto.content || '',
          attachments: dto.attachments as any,
          replyToMessageId: dto.replyToMessageId,
        },
        include: {
          sender: {
            select: { id: true, name: true, avatar: true },
          },
        },
      });

      // Update conversation
      await tx.conversation.update({
        where: { id: conversationId },
        data: {
          lastMessageId: msg.id,
          lastMessageAt: new Date(),
          lastMessagePreview: this.getMessagePreview(msg.type, msg.content),
          version: { increment: 1 },
        },
      });

      // Update unread counts
      await tx.conversationParticipant.updateMany({
        where: {
          conversationId,
          userId: { not: userId },
          leftAt: null,
          removedAt: null,
        },
        data: {
          unreadCount: { increment: 1 },
        },
      });

      return msg;
    });

    // 5. Realtime fanout - emit to all participants
    const formattedMessage = this.formatMessageResponse(message);
    this.messagingGateway.emitNewMessage(conversationId, formattedMessage);

    return formattedMessage;
  }

  // ============================================
  // GET MESSAGES (Cursor pagination)
  // ============================================

  /**
   * Lấy danh sách tin nhắn với cursor-based pagination
   *
   * - cursor: messageId để load từ đó
   * - direction: 'before' (older) hoặc 'after' (newer)
   * - limit: số lượng messages
   */
  async getMessages(
    conversationId: string,
    userId: number,
    query: GetMessagesQueryDto,
  ): Promise<MessageListResponseDto> {
    // Validate access
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant) {
      throw new ForbiddenException('Không có quyền truy cập conversation này');
    }

    const {
      cursor,
      direction = 'before',
      limit = 50,
      aroundSeq,
      includeDeleted,
    } = query;

    // Build where clause
    const where: any = {
      conversationId,
    };

    if (!includeDeleted) {
      where.deletedAt = null;
    }

    // Handle cursor
    let cursorMessage: any = null;
    if (cursor) {
      cursorMessage = await this.prisma.conversationMessage.findUnique({
        where: { id: cursor },
        select: { seq: true },
      });

      if (!cursorMessage) {
        throw new NotFoundException('Cursor message không tồn tại');
      }

      if (direction === 'before') {
        where.seq = { lt: cursorMessage.seq };
      } else {
        where.seq = { gt: cursorMessage.seq };
      }
    }

    // Handle aroundSeq (load messages around a specific seq)
    if (aroundSeq && !cursor) {
      const halfLimit = Math.floor(limit / 2);

      const [beforeMessages, afterMessages] = await Promise.all([
        this.prisma.conversationMessage.findMany({
          where: {
            conversationId,
            seq: { lt: aroundSeq },
            ...(includeDeleted ? {} : { deletedAt: null }),
          },
          orderBy: { seq: 'desc' },
          take: halfLimit,
          include: {
            sender: { select: { id: true, name: true, avatar: true } },
            reactions: {
              include: {
                user: { select: { id: true, name: true } },
              },
            },
          },
        }),
        this.prisma.conversationMessage.findMany({
          where: {
            conversationId,
            seq: { gte: aroundSeq },
            ...(includeDeleted ? {} : { deletedAt: null }),
          },
          orderBy: { seq: 'asc' },
          take: halfLimit + 1,
          include: {
            sender: { select: { id: true, name: true, avatar: true } },
            reactions: {
              include: {
                user: { select: { id: true, name: true } },
              },
            },
          },
        }),
      ]);

      const messages = [...beforeMessages.reverse(), ...afterMessages];

      return {
        messages: messages.map((m) => this.formatMessageResponse(m)),
        hasMore: beforeMessages.length === halfLimit,
        hasNewer: afterMessages.length > halfLimit,
      };
    }

    // Standard pagination
    const messages = await this.prisma.conversationMessage.findMany({
      where,
      orderBy: { seq: direction === 'before' ? 'desc' : 'asc' },
      take: limit + 1, // Extra for hasMore
      include: {
        sender: {
          select: { id: true, name: true, avatar: true },
        },
        reactions: {
          include: {
            user: { select: { id: true, name: true } },
          },
        },
        replyToMessage: {
          select: {
            id: true,
            content: true,
            type: true,
            sender: {
              select: { id: true, name: true },
            },
          },
        },
      },
    });

    const hasMore = messages.length > limit;
    if (hasMore) {
      messages.pop();
    }

    // Reverse if loading older messages
    if (direction === 'before') {
      messages.reverse();
    }

    return {
      messages: messages.map((m) => this.formatMessageResponse(m)),
      hasMore,
      cursor:
        messages.length > 0
          ? messages[direction === 'before' ? 0 : messages.length - 1].id
          : undefined,
    };
  }

  // ============================================
  // GET SINGLE MESSAGE
  // ============================================

  async getMessage(
    conversationId: string,
    messageId: string,
    userId: number,
  ): Promise<MessageResponseDto> {
    // Validate access
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant) {
      throw new ForbiddenException('Không có quyền truy cập conversation này');
    }

    const message = await this.prisma.conversationMessage.findUnique({
      where: { id: messageId },
      include: {
        sender: {
          select: { id: true, name: true, avatar: true },
        },
        reactions: {
          include: {
            user: { select: { id: true, name: true } },
          },
        },
        replyToMessage: {
          select: {
            id: true,
            content: true,
            type: true,
            sender: {
              select: { id: true, name: true },
            },
          },
        },
      },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message không tồn tại');
    }

    return this.formatMessageResponse(message);
  }

  // ============================================
  // UPDATE MESSAGE (Edit)
  // ============================================

  async updateMessage(
    conversationId: string,
    messageId: string,
    userId: number,
    dto: UpdateMessageDto,
  ): Promise<MessageResponseDto> {
    const message = await this.prisma.conversationMessage.findUnique({
      where: { id: messageId },
      include: {
        sender: { select: { id: true, name: true, avatar: true } },
      },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message không tồn tại');
    }

    if (message.senderId !== userId) {
      throw new ForbiddenException('Chỉ người gửi mới được sửa tin nhắn');
    }

    if (message.deletedAt) {
      throw new ForbiddenException('Không thể sửa tin nhắn đã xóa');
    }

    // Check edit time window (15 minutes)
    const editWindow = 15 * 60 * 1000;
    if (Date.now() - message.createdAt.getTime() > editWindow) {
      throw new ForbiddenException('Đã quá thời gian cho phép sửa tin nhắn');
    }

    const updated = await this.prisma.conversationMessage.update({
      where: { id: messageId },
      data: {
        content: dto.content,
        editedAt: new Date(),
      },
      include: {
        sender: { select: { id: true, name: true, avatar: true } },
        reactions: {
          include: {
            user: { select: { id: true, name: true } },
          },
        },
      },
    });

    // Notify participants - emit message.updated
    const formattedMessage = this.formatMessageResponse(updated);
    this.messagingGateway.emitMessageUpdated(conversationId, formattedMessage);

    return formattedMessage;
  }

  // ============================================
  // DELETE MESSAGE (Soft delete)
  // ============================================

  async deleteMessage(
    conversationId: string,
    messageId: string,
    userId: number,
    deleteForAll: boolean = false,
  ): Promise<{ success: boolean }> {
    const message = await this.prisma.conversationMessage.findUnique({
      where: { id: messageId },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message không tồn tại');
    }

    // Check permissions
    if (deleteForAll) {
      // Only sender can delete for all
      if (message.senderId !== userId) {
        throw new ForbiddenException('Chỉ người gửi mới được xóa cho tất cả');
      }

      // Delete for all
      await this.prisma.conversationMessage.update({
        where: { id: messageId },
        data: {
          deletedAt: new Date(),
          content: '[Tin nhắn đã bị xóa]', // Clear content with placeholder
          attachments: undefined, // Use undefined instead of null for JSON fields
        },
      });

      // Notify participants - emit message.deleted
      this.messagingGateway.emitMessageDeleted(conversationId, messageId);
    } else {
      // Delete for me only - store in separate table or use JSON field
      // For now, we'll just mark it
      // In production, use MessageDeletedFor table
    }

    return { success: true };
  }

  // ============================================
  // REACTIONS
  // ============================================

  async addReaction(
    conversationId: string,
    messageId: string,
    userId: number,
    emoji: string,
  ): Promise<{ success: boolean }> {
    // Validate access
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant || participant.leftAt) {
      throw new ForbiddenException('Không có quyền thực hiện');
    }

    const message = await this.prisma.conversationMessage.findUnique({
      where: { id: messageId },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message không tồn tại');
    }

    // Upsert reaction
    await this.prisma.messageReaction.upsert({
      where: {
        messageId_userId_emoji: {
          messageId,
          userId,
          emoji,
        },
      },
      create: {
        messageId,
        userId,
        emoji,
      },
      update: {
        createdAt: new Date(),
      },
    });

    // Notify
    // TODO: Restore realtime notification
    // this.realtimeGateway.notifyConversation(
    //   conversationId,
    //   'message.reaction',
    //   {
    //     messageId,
    //     conversationId,
    //     userId,
    //     emoji,
    //     action: 'add',
    //   },
    // );

    return { success: true };
  }

  async removeReaction(
    conversationId: string,
    messageId: string,
    userId: number,
    emoji: string,
  ): Promise<{ success: boolean }> {
    await this.prisma.messageReaction.deleteMany({
      where: {
        messageId,
        userId,
        emoji,
      },
    });

    // Notify
    // TODO: Restore realtime notification
    // this.realtimeGateway.notifyConversation(
    //   conversationId,
    //   'message.reaction',
    //   {
    //     messageId,
    //     conversationId,
    //     userId,
    //     emoji,
    //     action: 'remove',
    //   },
    // );

    return { success: true };
  }

  // ============================================
  // READ RECEIPTS (MSG-004)
  // ============================================

  /**
   * Mark messages as read
   * - If messageId provided: mark that message and all before it as read
   * - If no messageId: mark all messages in conversation as read
   */
  async markAsRead(
    conversationId: string,
    userId: number,
    dto: MarkAsReadDto,
  ): Promise<ReadReceiptsResponseDto> {
    // Validate participant
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: { conversationId, userId },
      },
    });

    if (!participant || participant.leftAt || participant.removedAt) {
      throw new ForbiddenException(
        'Không phải thành viên của conversation này',
      );
    }

    // Get target message or latest
    let targetSeq = participant.lastReadSeq || 0;
    let targetMessageId = dto.messageId;

    if (dto.messageId) {
      const message = await this.prisma.conversationMessage.findUnique({
        where: { id: dto.messageId },
        select: { seq: true, conversationId: true },
      });

      if (!message || message.conversationId !== conversationId) {
        throw new NotFoundException('Message không tồn tại');
      }

      targetSeq = Math.max(targetSeq, message.seq);
    } else {
      // Get latest message
      const latestMsg = await this.prisma.conversationMessage.findFirst({
        where: { conversationId },
        orderBy: { seq: 'desc' },
        select: { id: true, seq: true },
      });

      if (latestMsg) {
        targetSeq = latestMsg.seq;
        targetMessageId = latestMsg.id;
      }
    }

    // Transaction: update participant + create read receipt
    await this.prisma.$transaction(async (tx) => {
      // Update participant's last read
      await tx.conversationParticipant.update({
        where: {
          conversationId_userId: { conversationId, userId },
        },
        data: {
          lastReadSeq: targetSeq,
          unreadCount: 0,
        },
      });

      // Create/update read receipt for the specific message
      if (targetMessageId) {
        await tx.conversationReadReceipt.upsert({
          where: {
            messageId_userId: { messageId: targetMessageId, userId },
          },
          create: {
            messageId: targetMessageId,
            userId,
          },
          update: {
            readAt: new Date(),
          },
        });
      }
    });

    // Get user info for response
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, avatar: true },
    });

    // Emit read receipt via WebSocket
    this.messagingGateway.emitReadReceipt(conversationId, {
      userId,
      userName: user?.name || '',
      avatar: user?.avatar,
      lastReadSeq: targetSeq,
      readAt: new Date(),
    });

    return {
      conversationId,
      messageId: targetMessageId,
      lastReadSeq: targetSeq,
      receipts: [
        {
          userId,
          userName: user?.name || '',
          avatar: user?.avatar,
          readAt: new Date(),
        },
      ],
    };
  }

  /**
   * Get read receipts for a message
   */
  async getReadReceipts(
    conversationId: string,
    messageId: string,
    userId: number,
  ): Promise<ReadReceiptsResponseDto> {
    // Validate access
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: { conversationId, userId },
      },
    });

    if (!participant) {
      throw new ForbiddenException('Không có quyền truy cập');
    }

    const message = await this.prisma.conversationMessage.findUnique({
      where: { id: messageId },
      select: { seq: true, conversationId: true },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message không tồn tại');
    }

    // Get all participants who have read this message (lastReadSeq >= message.seq)
    const readers = await this.prisma.conversationParticipant.findMany({
      where: {
        conversationId,
        lastReadSeq: { gte: message.seq },
        userId: { not: userId }, // Exclude self
        leftAt: null,
        removedAt: null,
      },
      include: {
        user: { select: { id: true, name: true, avatar: true } },
      },
    });

    return {
      conversationId,
      messageId,
      lastReadSeq: message.seq,
      receipts: readers.map((r) => ({
        userId: r.userId,
        userName: r.user.name || '',
        avatar: r.user.avatar,
        readAt: r.updatedAt, // Approximate read time
      })),
    };
  }

  /**
   * Get unread count for user across all conversations
   */
  async getUnreadCounts(
    userId: number,
  ): Promise<{ conversationId: string; unreadCount: number }[]> {
    const participants = await this.prisma.conversationParticipant.findMany({
      where: {
        userId,
        unreadCount: { gt: 0 },
        leftAt: null,
        removedAt: null,
      },
      select: {
        conversationId: true,
        unreadCount: true,
      },
    });

    return participants;
  }

  // ============================================
  // SEARCH MESSAGES (MSG-006 Enhanced)
  // ============================================

  async searchMessages(
    conversationId: string,
    userId: number,
    searchQuery: string,
    limit: number = 20,
  ): Promise<MessageListResponseDto> {
    // Validate access
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant) {
      throw new ForbiddenException('Không có quyền truy cập');
    }

    const messages = await this.prisma.conversationMessage.findMany({
      where: {
        conversationId,
        type: 'TEXT',
        content: {
          contains: searchQuery,
          mode: 'insensitive',
        },
        deletedAt: null,
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        sender: { select: { id: true, name: true, avatar: true } },
      },
    });

    return {
      messages: messages.map((m) => this.formatMessageResponse(m)),
      hasMore: false,
    };
  }

  /**
   * Global search across all user's conversations
   * Enhanced with filters: type, date range, sender
   */
  async globalSearchMessages(
    userId: number,
    query: GlobalSearchQueryDto,
  ): Promise<GlobalSearchResponseDto> {
    const {
      q: searchQuery,
      limit = 20,
      conversationId,
      type,
      fromDate,
      toDate,
      senderId,
    } = query;

    // Get user's conversations
    const userConversations =
      await this.prisma.conversationParticipant.findMany({
        where: {
          userId,
          leftAt: null,
          removedAt: null,
        },
        select: { conversationId: true },
      });

    const conversationIds = userConversations.map((c) => c.conversationId);

    // Build where clause
    const where: any = {
      conversationId: conversationId ? conversationId : { in: conversationIds },
      deletedAt: null,
    };

    // Text search - search in both TEXT and filename for files
    if (searchQuery) {
      where.OR = [
        {
          type: 'TEXT',
          content: { contains: searchQuery, mode: 'insensitive' },
        },
        {
          mediaFilename: { contains: searchQuery, mode: 'insensitive' },
        },
      ];
    }

    // Type filter
    if (type) {
      where.type = type;
    }

    // Date range
    if (fromDate || toDate) {
      where.createdAt = {};
      if (fromDate) {
        where.createdAt.gte = new Date(fromDate);
      }
      if (toDate) {
        where.createdAt.lte = new Date(toDate);
      }
    }

    // Sender filter
    if (senderId) {
      where.senderId = senderId;
    }

    // Execute search
    const [messages, total] = await Promise.all([
      this.prisma.conversationMessage.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit + 1,
        include: {
          sender: { select: { id: true, name: true, avatar: true } },
          conversation: {
            select: {
              title: true,
              type: true,
              participants: {
                where: { leftAt: null, removedAt: null },
                take: 2,
                include: {
                  user: { select: { name: true } },
                },
              },
            },
          },
        },
      }),
      this.prisma.conversationMessage.count({ where }),
    ]);

    const hasMore = messages.length > limit;
    if (hasMore) {
      messages.pop();
    }

    return {
      results: messages.map((m) => ({
        message: this.formatMessageResponse(m),
        highlight: this.createHighlight(m.content, searchQuery),
        conversationName: this.getConversationName(m.conversation),
      })),
      total,
      hasMore,
    };
  }

  // ============================================
  // HELPERS
  // ============================================

  private formatMessageResponse(message: any): MessageResponseDto {
    return {
      id: message.id,
      conversationId: message.conversationId,
      seq: message.seq,
      clientMessageId: message.clientMessageId,
      sender: message.sender,
      type: message.type,
      content: message.content,
      attachments: message.attachments,
      replyTo: message.replyToMessage
        ? {
            id: message.replyToMessage.id,
            content: message.replyToMessage.content,
            type: message.replyToMessage.type,
            senderName: message.replyToMessage.sender?.name,
          }
        : undefined,
      reactions: message.reactions?.map((r: any) => ({
        emoji: r.emoji,
        userId: r.userId,
        userName: r.user?.name,
      })),
      editedAt: message.editedAt,
      deletedAt: message.deletedAt,
      createdAt: message.createdAt,
    };
  }

  private getMessagePreview(type: string, content?: string | null): string {
    if (type === 'TEXT' && content) {
      return content.substring(0, 100);
    }

    const typeLabels: Record<string, string> = {
      IMAGE: '📷 Hình ảnh',
      VIDEO: '🎬 Video',
      FILE: '📎 Tệp đính kèm',
      AUDIO: '🎵 Audio',
      VOICE: '🎤 Tin nhắn thoại',
      STICKER: '😀 Sticker',
      LOCATION: '📍 Vị trí',
    };

    return typeLabels[type] || content || '';
  }

  /**
   * Create highlighted snippet around search match
   */
  private createHighlight(
    content: string | null,
    query: string,
  ): string | undefined {
    if (!content || !query) return undefined;

    const lowerContent = content.toLowerCase();
    const lowerQuery = query.toLowerCase();
    const index = lowerContent.indexOf(lowerQuery);

    if (index === -1) return content.substring(0, 100);

    const start = Math.max(0, index - 30);
    const end = Math.min(content.length, index + query.length + 30);

    let snippet = content.substring(start, end);
    if (start > 0) snippet = '...' + snippet;
    if (end < content.length) snippet = snippet + '...';

    return snippet;
  }

  /**
   * Get display name for conversation
   */
  private getConversationName(conversation: any): string {
    if (conversation.title) return conversation.title;

    if (conversation.type === 'DIRECT' && conversation.participants) {
      const names = conversation.participants
        .map((p: any) => p.user?.name)
        .filter(Boolean);
      return names.join(', ') || 'Conversation';
    }

    return 'Group';
  }
}
