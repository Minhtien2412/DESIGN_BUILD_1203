/**
 * Messages Module
 * ===============
 *
 * Module quản lý tin nhắn trong conversations
 */

import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConversationsModule } from '../conversations/conversations.module';
import { PrismaModule } from '../prisma/prisma.module';
import { ConversationsMessagingGateway } from './conversations-messaging.gateway';
import { MessagesController } from './messages.controller';
import { MessagesService } from './messages.service';
import { SearchController } from './search.controller';

@Module({
  imports: [
    PrismaModule,
    ConversationsModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'default-secret',
      signOptions: { expiresIn: '7d' },
    }),
  ],
  controllers: [MessagesController, SearchController],
  providers: [MessagesService, ConversationsMessagingGateway],
  exports: [MessagesService, ConversationsMessagingGateway],
})
export class ConversationMessagesModule {}
