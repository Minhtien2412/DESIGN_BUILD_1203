import { Controller, Get, Post, Patch, Param, Query, Body, UseGuards, Request, HttpCode, HttpStatus, ParseIntPipe } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateMessageDto } from './dto/create-message.dto';
import { MessageQueryDto } from './dto/message-query.dto';

@Controller('messages')
@UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  // Get all conversations for current user
  @Get('conversations')
  async getConversations(@Request() req) {
    const userId = req.user.id;
    return this.messagesService.getConversations(userId);
  }

  // Get messages in a conversation
  @Get('conversations/:id')
  async getMessages(
    @Request() req,
    @Param('id', ParseIntPipe) conversationId: number,
    @Query() query: MessageQueryDto,
  ) {
    const userId = req.user.id;
    return this.messagesService.getMessages(conversationId, userId, query);
  }

  // Send a message (creates conversation if doesn't exist)
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async sendMessage(@Request() req, @Body() dto: CreateMessageDto) {
    const senderId = req.user.id;
    return this.messagesService.sendMessage(senderId, dto);
  }

  // Mark message as read
  @Patch(':id/read')
  @HttpCode(HttpStatus.OK)
  async markAsRead(@Request() req, @Param('id', ParseIntPipe) id: number) {
    const userId = req.user.id;
    return this.messagesService.markAsRead(id, userId);
  }

  // Mark all messages in conversation as read
  @Patch('conversations/:id/read-all')
  @HttpCode(HttpStatus.OK)
  async markAllAsRead(
    @Request() req,
    @Param('id', ParseIntPipe) conversationId: number,
  ) {
    const userId = req.user.id;
    return this.messagesService.markAllAsRead(conversationId, userId);
  }

  // Get unread count
  @Get('unread-count')
  async getUnreadCount(@Request() req) {
    const userId = req.user.id;
    return this.messagesService.getUnreadCount(userId);
  }
}
