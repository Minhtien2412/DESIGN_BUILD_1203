import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { QCService } from './qc.service';
import {
  CreateQCCategoryDto,
  UpdateQCCategoryDto,
  CreateQCChecklistDto,
  UpdateQCChecklistDto,
  CreateInspectionDto,
  UpdateInspectionDto,
  UpdateInspectionItemDto,
  CompleteInspectionDto,
  CreateBugDto,
  UpdateBugDto,
  BugFilterDto,
  QCStatus,
  BugStatus,
  BugSeverity,
} from './dto';

@ApiTags('QC - Quality Control')
@Controller({ path: 'qc', version: '1' })
export class QCController {
  constructor(private readonly qcService: QCService) {}

  // ==================== Category Endpoints ====================

  @Post('categories')
  @ApiOperation({ summary: 'Tạo hạng mục QC mới' })
  @ApiResponse({ status: 201, description: 'Tạo thành công' })
  async createCategory(@Body() dto: CreateQCCategoryDto) {
    return this.qcService.createCategory(dto);
  }

  @Get('categories')
  @ApiOperation({ summary: 'Lấy danh sách hạng mục QC' })
  @ApiQuery({ name: 'includeInactive', required: false, type: Boolean })
  @ApiResponse({ status: 200, description: 'Danh sách hạng mục QC' })
  async getCategories(@Query('includeInactive') includeInactive?: string) {
    return this.qcService.getCategories(includeInactive === 'true');
  }

  @Get('categories/:id')
  @ApiOperation({ summary: 'Lấy chi tiết hạng mục QC' })
  @ApiResponse({ status: 200, description: 'Chi tiết hạng mục' })
  async getCategoryById(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.getCategoryById(id);
  }

  @Patch('categories/:id')
  @ApiOperation({ summary: 'Cập nhật hạng mục QC' })
  @ApiResponse({ status: 200, description: 'Cập nhật thành công' })
  async updateCategory(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateQCCategoryDto,
  ) {
    return this.qcService.updateCategory(id, dto);
  }

  @Delete('categories/:id')
  @ApiOperation({ summary: 'Xóa hạng mục QC' })
  @ApiResponse({ status: 200, description: 'Xóa thành công' })
  async deleteCategory(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.deleteCategory(id);
  }

  // ==================== Checklist Endpoints ====================

  @Post('checklists')
  @ApiOperation({ summary: 'Tạo checklist QC mới' })
  @ApiResponse({ status: 201, description: 'Tạo checklist thành công' })
  async createChecklist(@Body() dto: CreateQCChecklistDto) {
    return this.qcService.createChecklist(dto);
  }

  @Get('checklists')
  @ApiOperation({ summary: 'Lấy danh sách checklist' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'categoryId', required: false, type: Number })
  @ApiQuery({ name: 'isTemplate', required: false, type: Boolean })
  @ApiResponse({ status: 200, description: 'Danh sách checklist' })
  async getChecklists(
    @Query('projectId') projectId?: string,
    @Query('categoryId') categoryId?: string,
    @Query('isTemplate') isTemplate?: string,
  ) {
    return this.qcService.getChecklists(
      projectId ? parseInt(projectId) : undefined,
      categoryId ? parseInt(categoryId) : undefined,
      isTemplate === 'true' ? true : isTemplate === 'false' ? false : undefined,
    );
  }

  @Get('checklists/:id')
  @ApiOperation({ summary: 'Lấy chi tiết checklist' })
  @ApiResponse({
    status: 200,
    description: 'Chi tiết checklist với lịch sử inspections',
  })
  async getChecklistById(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.getChecklistById(id);
  }

  @Patch('checklists/:id')
  @ApiOperation({ summary: 'Cập nhật checklist' })
  @ApiResponse({ status: 200, description: 'Cập nhật thành công' })
  async updateChecklist(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateQCChecklistDto,
  ) {
    return this.qcService.updateChecklist(id, dto);
  }

  @Delete('checklists/:id')
  @ApiOperation({ summary: 'Xóa checklist' })
  @ApiResponse({ status: 200, description: 'Xóa thành công' })
  async deleteChecklist(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.deleteChecklist(id);
  }

  // ==================== Inspection Endpoints ====================

  @Post('inspections')
  @ApiOperation({ summary: 'Tạo đợt kiểm tra QC mới' })
  @ApiResponse({
    status: 201,
    description: 'Tạo inspection với checklist items',
  })
  async createInspection(@Body() dto: CreateInspectionDto) {
    return this.qcService.createInspection(dto);
  }

  @Get('inspections')
  @ApiOperation({ summary: 'Lấy danh sách inspections' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'phaseId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: QCStatus })
  @ApiResponse({ status: 200, description: 'Danh sách inspections' })
  async getInspections(
    @Query('projectId') projectId?: string,
    @Query('phaseId') phaseId?: string,
    @Query('status') status?: QCStatus,
  ) {
    return this.qcService.getInspections(
      projectId ? parseInt(projectId) : undefined,
      phaseId ? parseInt(phaseId) : undefined,
      status,
    );
  }

  @Get('inspections/:id')
  @ApiOperation({ summary: 'Lấy chi tiết inspection' })
  @ApiResponse({
    status: 200,
    description:
      'Chi tiết inspection với checklist items, bugs, hình ảnh/video',
  })
  async getInspectionById(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.getInspectionById(id);
  }

  @Patch('inspections/:id')
  @ApiOperation({ summary: 'Cập nhật thông tin inspection' })
  @ApiResponse({ status: 200, description: 'Cập nhật thành công' })
  async updateInspection(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateInspectionDto,
  ) {
    return this.qcService.updateInspection(id, dto);
  }

  @Delete('inspections/:id')
  @ApiOperation({ summary: 'Xóa inspection' })
  @ApiResponse({ status: 200, description: 'Xóa thành công' })
  async deleteInspection(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.deleteInspection(id);
  }

  @Patch('inspections/:id/complete')
  @ApiOperation({
    summary: 'Hoàn thành inspection và tự động tạo bugs cho items FAIL',
  })
  @ApiResponse({
    status: 200,
    description: 'Hoàn thành inspection, tự động tạo bugs nếu có items FAIL',
  })
  async completeInspection(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CompleteInspectionDto,
  ) {
    return this.qcService.completeInspection(id, dto);
  }

  // ==================== Inspection Item Endpoints ====================

  @Patch('inspection-items/:id')
  @ApiOperation({
    summary: 'Cập nhật item trong inspection (Pass/Fail, upload hình/video)',
  })
  @ApiResponse({
    status: 200,
    description:
      'Cập nhật item với before/after images/videos, measurements, notes. Tự động cập nhật status inspection.',
  })
  async updateInspectionItem(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateInspectionItemDto,
  ) {
    return this.qcService.updateInspectionItem(id, dto);
  }

  // ==================== Bug Tracking Endpoints ====================

  @Post('bugs')
  @ApiOperation({ summary: 'Tạo bug QC mới' })
  @ApiResponse({ status: 201, description: 'Tạo bug thành công' })
  async createBug(@Body() dto: CreateBugDto) {
    return this.qcService.createBug(dto);
  }

  @Get('projects/:projectId/bugs')
  @ApiOperation({ summary: 'Lấy danh sách bugs của project' })
  @ApiQuery({ name: 'status', required: false, enum: BugStatus })
  @ApiQuery({ name: 'severity', required: false, enum: BugSeverity })
  @ApiQuery({ name: 'assigneeId', required: false, type: Number })
  @ApiQuery({ name: 'reporterId', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'Danh sách bugs với filter' })
  async getProjectBugs(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('status') status?: BugStatus,
    @Query('severity') severity?: BugSeverity,
    @Query('assigneeId') assigneeId?: string,
    @Query('reporterId') reporterId?: string,
  ) {
    const filters: BugFilterDto = {
      status,
      severity,
      assigneeId: assigneeId ? parseInt(assigneeId) : undefined,
      reporterId: reporterId ? parseInt(reporterId) : undefined,
    };
    return this.qcService.getBugs(projectId, filters);
  }

  @Get('bugs/:id')
  @ApiOperation({ summary: 'Lấy chi tiết bug' })
  @ApiResponse({
    status: 200,
    description:
      'Chi tiết bug với hình ảnh/video, assignee, reporter, resolution',
  })
  async getBugById(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.getBugById(id);
  }

  @Patch('bugs/:id')
  @ApiOperation({ summary: 'Cập nhật bug (assign, resolve, verify, close)' })
  @ApiResponse({
    status: 200,
    description:
      'Cập nhật bug status, resolution với hình ảnh/video sau khi sửa',
  })
  async updateBug(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateBugDto,
  ) {
    return this.qcService.updateBug(id, dto);
  }

  @Delete('bugs/:id')
  @ApiOperation({ summary: 'Xóa bug' })
  @ApiResponse({ status: 200, description: 'Xóa thành công' })
  async deleteBug(@Param('id', ParseIntPipe) id: number) {
    return this.qcService.deleteBug(id);
  }

  // ==================== QC Reports & Statistics ====================

  @Get('projects/:projectId/report')
  @ApiOperation({
    summary: 'Lấy báo cáo QC tổng hợp của project (cho khách hàng xem)',
  })
  @ApiResponse({
    status: 200,
    description:
      'Báo cáo QC: tổng số inspections, pass rate, bugs, recent inspections với hình ảnh/video',
  })
  async getProjectQCReport(
    @Param('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.qcService.getProjectQCReport(projectId);
  }

  @Get('phases/:phaseId/qc-stats')
  @ApiOperation({
    summary: 'Lấy thống kê QC của phase (Timeline Gantt Chart integration)',
  })
  @ApiResponse({
    status: 200,
    description: 'Thống kê QC của phase: số inspections, pass rate, bugs',
  })
  async getPhaseQCStats(@Param('phaseId', ParseIntPipe) phaseId: number) {
    return this.qcService.getPhaseQCStats(phaseId);
  }
}
