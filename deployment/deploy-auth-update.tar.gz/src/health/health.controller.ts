import { Controller, Get } from '@nestjs/common';
import { getErrorMessage, getAxiosErrorData, getErrorStatus, isAxiosError, logError } from '../utils/error-helpers';

import { PrismaService } from '../prisma/prisma.service';

@Controller('health')
export class HealthController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async check() {
    try {
      // Check database connection
      await this.prisma.$queryRaw`SELECT 1`;
      
      return {
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        info: {
          database: { status: 'up' },
          memory: {
            status: 'up',
            heap: process.memoryUsage(),
          },
          disk: { status: 'up' },
        },
      };
    } catch (error: unknown) {
      return {
        status: 'error',
        timestamp: new Date().toISOString(),
        error: getErrorMessage(error),
      };
    }
  }

  @Get('db')
  async checkDatabase() {
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return { status: 'ok', database: 'connected' };
    } catch (error: unknown) {
      return { status: 'error', error: getErrorMessage(error) };
    }
  }

  @Get('metrics')
  getMetrics() {
    return {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      cpu: process.cpuUsage(),
      timestamp: new Date().toISOString(),
      node: process.version,
    };
  }
}
