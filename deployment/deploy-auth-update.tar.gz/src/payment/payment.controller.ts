import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  UseGuards,
  ParseIntPipe,
  Headers,
  Req,
  BadRequestException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiExcludeEndpoint,
} from '@nestjs/swagger';
import type { Request } from 'express';
import { PaymentService } from './payment.service';
import {
  CreatePaymentDto,
  CreateSubscriptionDto,
  PaymentResponseDto,
  SubscriptionResponseDto,
  PaymentIntentResponseDto,
} from './dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@ApiTags('Payment')
@Controller({ path: 'payment', version: '1' })
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('intent')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo Payment Intent (one-time payment)' })
  @ApiResponse({
    status: 201,
    description: 'Payment Intent đã được tạo',
    type: PaymentIntentResponseDto,
  })
  async createPaymentIntent(
    @Body() createPaymentDto: CreatePaymentDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.createPaymentIntent(createPaymentDto, userId);
  }

  @Post('intent/:paymentIntentId/confirm')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Confirm payment sau khi client hoàn thành trên Stripe',
  })
  @ApiResponse({
    status: 200,
    description: 'Payment đã được confirm',
    type: PaymentResponseDto,
  })
  async confirmPayment(@Param('paymentIntentId') paymentIntentId: string) {
    return this.paymentService.confirmPayment(paymentIntentId);
  }

  @Post('subscription')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo subscription (recurring payment)' })
  @ApiResponse({
    status: 201,
    description: 'Subscription đã được tạo',
    type: SubscriptionResponseDto,
  })
  async createSubscription(
    @Body() createSubscriptionDto: CreateSubscriptionDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.createSubscription(
      createSubscriptionDto,
      userId,
    );
  }

  @Delete('subscription/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy subscription' })
  @ApiResponse({ status: 200, description: 'Subscription đã được hủy' })
  async cancelSubscription(
    @Param('id', ParseIntPipe) subscriptionId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.cancelSubscription(subscriptionId, userId);
  }

  @Get('history')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy lịch sử thanh toán của user' })
  @ApiResponse({
    status: 200,
    description: 'Lịch sử thanh toán',
    type: [PaymentResponseDto],
  })
  async getPaymentHistory(@CurrentUser('id') userId: number) {
    return this.paymentService.getPaymentHistory(userId);
  }

  @Get('subscriptions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách subscriptions của user' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách subscriptions',
    type: [SubscriptionResponseDto],
  })
  async getUserSubscriptions(@CurrentUser('id') userId: number) {
    return this.paymentService.getUserSubscriptions(userId);
  }

  @Post('refund/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Refund payment' })
  @ApiResponse({
    status: 200,
    description: 'Payment đã được refund',
    type: PaymentResponseDto,
  })
  async refundPayment(
    @Param('id', ParseIntPipe) paymentId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.refundPayment(paymentId, userId);
  }

  @Post('webhook')
  @ApiExcludeEndpoint()
  async handleWebhook(
    @Headers('stripe-signature') signature: string,
    @Req() req: Request & { rawBody?: Buffer },
  ) {
    if (!req.rawBody) {
      throw new BadRequestException('Raw body is required for webhook');
    }
    return this.paymentService.handleWebhook(signature, req.rawBody);
  }
}
