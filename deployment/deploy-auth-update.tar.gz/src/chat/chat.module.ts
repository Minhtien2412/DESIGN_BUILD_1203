import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { UploadModule } from '../upload/upload.module';
import { ChatAttachmentController } from './chat-attachment.controller';
import { ChatAttachmentService } from './chat-attachment.service';
import { ChatController } from './chat.controller';
import { ChatGateway } from './chat.gateway';
import { ChatService } from './chat.service';
import { MessageSearchController } from './message-search.controller';
import { MessageSearchService } from './message-search.service';

@Module({
  imports: [PrismaModule, UploadModule],
  controllers: [
    ChatController,
    ChatAttachmentController,
    MessageSearchController,
  ],
  providers: [
    ChatGateway,
    ChatService,
    ChatAttachmentService,
    MessageSearchService,
  ],
  exports: [ChatService, ChatAttachmentService, MessageSearchService],
})
export class ChatModule {}
