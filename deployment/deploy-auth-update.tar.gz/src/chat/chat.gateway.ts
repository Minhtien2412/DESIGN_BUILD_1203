import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import {
    getErrorMessage
} from '../utils/error-helpers';

import { MetricsService } from '../metrics/metrics.service';
import { ChatService } from './chat.service';
import { SendMessageDto } from './dto';

@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/chat',
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  // Track online users: Map<userId, Set<socketId>>
  private onlineUsers: Map<number, Set<string>> = new Map();
  // Track typing users: Map<roomId, Set<userId>>
  private typingUsers: Map<number, Set<number>> = new Map();

  constructor(
    private chatService: ChatService,
    private metricsService: MetricsService,
  ) {}

  // Khi client kết nối
  handleConnection(client: Socket) {
    console.log(`Client connected: ${client.id}`);
    this.metricsService.recordWsConnect('chat');

    // Extract userId from handshake query (optional)
    const userId = client.handshake.query.userId as string;
    if (userId) {
      const userIdNum = parseInt(userId);
      this.addOnlineUser(userIdNum, client.id);

      // Broadcast online status to all connected clients
      this.server.emit('userOnline', {
        userId: userIdNum,
        timestamp: new Date(),
      });
    }
  }

  // Khi client ngắt kết nối
  handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
    this.metricsService.recordWsDisconnect('chat');

    // Find and remove user from online users
    const userId = this.findUserBySocketId(client.id);
    if (userId !== null) {
      this.removeOnlineUser(userId, client.id);

      // If user has no more active connections, broadcast offline status
      if (!this.isUserOnline(userId)) {
        this.server.emit('userOffline', {
          userId,
          timestamp: new Date(),
        });
      }
    }
  }

  // Join room (client gửi roomId để tham gia room)
  @SubscribeMessage('joinRoom')
  async handleJoinRoom(
    @MessageBody() data: { roomId: number; userId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const roomName = `room_${data.roomId}`;
    client.join(roomName);

    console.log(`User ${data.userId} joined room ${data.roomId}`);

    // Thông báo cho các thành viên khác
    client.to(roomName).emit('userJoined', {
      userId: data.userId,
      roomId: data.roomId,
      timestamp: new Date(),
    });

    return { success: true, roomId: data.roomId };
  }

  // Leave room
  @SubscribeMessage('leaveRoom')
  async handleLeaveRoom(
    @MessageBody() data: { roomId: number; userId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const roomName = `room_${data.roomId}`;
    client.leave(roomName);

    console.log(`User ${data.userId} left room ${data.roomId}`);

    // Thông báo cho các thành viên khác
    client.to(roomName).emit('userLeft', {
      userId: data.userId,
      roomId: data.roomId,
      timestamp: new Date(),
    });

    return { success: true, roomId: data.roomId };
  }

  // Gửi tin nhắn
  @SubscribeMessage('sendMessage')
  async handleSendMessage(
    @MessageBody() data: SendMessageDto & { senderId: number },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const message = await this.chatService.sendMessage(
        {
          roomId: data.roomId,
          content: data.content,
          attachments: data.attachments,
        },
        data.senderId,
      );

      const roomName = `room_${data.roomId}`;

      // Gửi tin nhắn đến tất cả thành viên trong room (bao gồm người gửi)
      this.server.to(roomName).emit('newMessage', message);

      return { success: true, message };
    } catch (error: unknown) {
      return { success: false, error: getErrorMessage(error) };
    }
  }

  // Đánh dấu đang nhập (typing indicator)
  @SubscribeMessage('typing')
  async handleTyping(
    @MessageBody() data: { roomId: number; userId: number; isTyping: boolean },
    @ConnectedSocket() client: Socket,
  ) {
    const roomName = `room_${data.roomId}`;

    // Track typing status
    if (data.isTyping) {
      if (!this.typingUsers.has(data.roomId)) {
        this.typingUsers.set(data.roomId, new Set());
      }
      this.typingUsers.get(data.roomId)?.add(data.userId);
    } else {
      const roomTypingUsers = this.typingUsers.get(data.roomId);
      if (roomTypingUsers) {
        roomTypingUsers.delete(data.userId);
      }
    }

    // Gửi đến các thành viên khác (không gửi lại cho người gửi)
    client.to(roomName).emit('userTyping', {
      userId: data.userId,
      roomId: data.roomId,
      isTyping: data.isTyping,
      typingUsers: Array.from(this.typingUsers.get(data.roomId) || []),
    });

    return { success: true };
  }

  // Đánh dấu đã đọc tin nhắn
  @SubscribeMessage('markAsRead')
  async handleMarkAsRead(
    @MessageBody() data: { messageId: number; userId: number; roomId: number },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const readStatus = await this.chatService.markAsRead(
        data.messageId,
        data.userId,
      );

      const roomName = `room_${data.roomId}`;

      // Thông báo cho các thành viên khác
      this.server.to(roomName).emit('messageRead', {
        messageId: data.messageId,
        userId: data.userId,
        readAt: readStatus.readAt,
      });

      return { success: true, readStatus };
    } catch (error: unknown) {
      return { success: false, error: getErrorMessage(error) };
    }
  }

  // Get online users
  @SubscribeMessage('getOnlineUsers')
  async handleGetOnlineUsers() {
    return {
      success: true,
      onlineUserIds: Array.from(this.onlineUsers.keys()),
    };
  }

  // Get typing users in a room
  @SubscribeMessage('getTypingUsers')
  async handleGetTypingUsers(@MessageBody() data: { roomId: number }) {
    const typingUsers = this.typingUsers.get(data.roomId) || new Set();
    return {
      success: true,
      roomId: data.roomId,
      typingUserIds: Array.from(typingUsers),
    };
  }

  // Helper methods for online user tracking
  private addOnlineUser(userId: number, socketId: string) {
    if (!this.onlineUsers.has(userId)) {
      this.onlineUsers.set(userId, new Set());
    }
    this.onlineUsers.get(userId)?.add(socketId);
  }

  private removeOnlineUser(userId: number, socketId: string) {
    const userSockets = this.onlineUsers.get(userId);
    if (userSockets) {
      userSockets.delete(socketId);
      if (userSockets.size === 0) {
        this.onlineUsers.delete(userId);
      }
    }
  }

  private findUserBySocketId(socketId: string): number | null {
    for (const [userId, sockets] of this.onlineUsers.entries()) {
      if (sockets.has(socketId)) {
        return userId;
      }
    }
    return null;
  }

  private isUserOnline(userId: number): boolean {
    const userSockets = this.onlineUsers.get(userId);
    return userSockets ? userSockets.size > 0 : false;
  }
}
