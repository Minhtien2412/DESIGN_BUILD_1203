import { Module } from '@nestjs/common';
import { CrmService } from './crm.service';
import { CrmController } from './crm.controller';

@Module({
  controllers: [CrmController],
  providers: [CrmService],
  exports: [CrmService], // Export để các module khác có thể dùng
})
export class CrmModule {}
