import {
    Injectable,
    Logger,
    OnModuleDestroy,
    OnModuleInit,
} from '@nestjs/common';
// Note: In production, CRM uses MySQL and requires separate Prisma client
// For now, using a mock/stub client since Prisma CRM client is generated separately
// import { PrismaClient as CrmPrismaClient } from '../../generated/prisma-crm';

@Injectable()
export class CrmService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(CrmService.name);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private crmClient: any = null;
  private isConnected = false;

  constructor() {
    // CRM client initialization - requires separate MySQL database setup
    // Will be initialized when CRM_DATABASE_URL is properly configured
    if (process.env.CRM_DATABASE_URL) {
      try {
        // Dynamic import or initialization would go here in production
        this.logger.log('CRM Database URL configured');
      } catch {
        this.logger.warn('CRM client not available - CRM features disabled');
      }
    }
  }

  async onModuleInit() {
    if (!process.env.CRM_DATABASE_URL) {
      this.logger.warn(
        '⚠️ CRM Database not configured (CRM_DATABASE_URL not set)',
      );
      return;
    }
    try {
      // In production, connect to CRM MySQL database
      this.isConnected = true;
      this.logger.log('✅ CRM Service initialized');
    } catch (error: unknown) {
      this.logger.error('❌ Failed to connect to CRM Database:', error);
    }
  }

  async onModuleDestroy() {
    if (this.crmClient) {
      await this.crmClient.$disconnect?.();
    }
  }

  // Check if CRM is available
  private ensureCrmConnected() {
    if (!this.crmClient && !process.env.CRM_DATABASE_URL) {
      throw new Error(
        'CRM Database not configured. Please set CRM_DATABASE_URL.',
      );
    }
  }

  // Getter for CRM client (for use in other services like DashboardService)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getCrmClient(): any {
    return this.crmClient;
  }

  // ==========================================
  // STAFF METHODS
  // ==========================================
  async getAllStaff() {
    this.ensureCrmConnected();
    return (
      this.crmClient?.tblstaff?.findMany?.({
        where: { active: 1 },
        select: {
          staffid: true,
          email: true,
          firstname: true,
          lastname: true,
          phonenumber: true,
          admin: true,
          profile_image: true,
          last_login: true,
          datecreated: true,
        },
      }) || []
    );
  }

  async getStaffById(staffid: number) {
    return this.crmClient.tblstaff.findUnique({
      where: { staffid },
    });
  }

  async getStaffByEmail(email: string) {
    return this.crmClient.tblstaff.findUnique({
      where: { email },
    });
  }

  // ==========================================
  // CLIENTS METHODS
  // ==========================================
  async getAllClients() {
    return this.crmClient.tblclients.findMany({
      where: { active: 1 },
    });
  }

  async getClientById(userid: number) {
    return this.crmClient.tblclients.findUnique({
      where: { userid },
    });
  }

  async getClientContacts(userid: number) {
    return this.crmClient.tblcontacts.findMany({
      where: { userid, active: 1 },
    });
  }

  async getPrimaryContact(userid: number) {
    return this.crmClient.tblcontacts.findFirst({
      where: { userid, is_primary: 1, active: 1 },
    });
  }

  // ==========================================
  // PROJECTS METHODS
  // ==========================================
  async getAllProjects() {
    return this.crmClient.tblprojects.findMany({
      orderBy: { project_created: 'desc' },
    });
  }

  async getProjectById(id: number) {
    return this.crmClient.tblprojects.findUnique({
      where: { id },
    });
  }

  async getProjectsByClient(clientid: number) {
    return this.crmClient.tblprojects.findMany({
      where: { clientid },
      orderBy: { project_created: 'desc' },
    });
  }

  async getActiveProjects() {
    return this.crmClient.tblprojects.findMany({
      where: {
        status: {
          in: [1, 2, 3], // In Progress, On Hold, Not Started
        },
      },
      orderBy: { project_created: 'desc' },
    });
  }

  // ==========================================
  // TASKS METHODS
  // ==========================================
  async getAllTasks() {
    return this.crmClient.tbltasks.findMany({
      orderBy: { dateadded: 'desc' },
    });
  }

  async getTaskById(id: number) {
    return this.crmClient.tbltasks.findUnique({
      where: { id },
    });
  }

  async getTasksByProject(rel_id: number) {
    return this.crmClient.tbltasks.findMany({
      where: { rel_id, rel_type: 'project' },
      orderBy: { dateadded: 'desc' },
    });
  }

  async getOpenTasks() {
    return this.crmClient.tbltasks.findMany({
      where: {
        status: {
          in: [1, 4], // Not Started, In Progress
        },
      },
      orderBy: { dateadded: 'desc' },
    });
  }

  // ==========================================
  // INVOICES METHODS
  // ==========================================
  async getAllInvoices() {
    return this.crmClient.tblinvoices.findMany({
      orderBy: { datecreated: 'desc' },
    });
  }

  async getInvoiceById(id: number) {
    return this.crmClient.tblinvoices.findUnique({
      where: { id },
    });
  }

  async getInvoicesByClient(clientid: number) {
    return this.crmClient.tblinvoices.findMany({
      where: { clientid },
      orderBy: { datecreated: 'desc' },
    });
  }

  async getUnpaidInvoices() {
    return this.crmClient.tblinvoices.findMany({
      where: {
        status: {
          in: [1, 4], // Unpaid, Overdue
        },
      },
      orderBy: { datecreated: 'desc' },
    });
  }

  async getInvoicesByProject(project_id: number) {
    return this.crmClient.tblinvoices.findMany({
      where: { project_id },
      orderBy: { datecreated: 'desc' },
    });
  }

  // ==========================================
  // TICKETS METHODS
  // ==========================================
  async getAllTickets() {
    return this.crmClient.tbltickets.findMany({
      orderBy: { date: 'desc' },
    });
  }

  async getTicketById(ticketid: number) {
    return this.crmClient.tbltickets.findUnique({
      where: { ticketid },
    });
  }

  async getOpenTickets() {
    return this.crmClient.tbltickets.findMany({
      where: {
        status: {
          in: [1, 2], // Open, In Progress
        },
      },
      orderBy: { date: 'desc' },
    });
  }

  async getTicketsByClient(userid: number) {
    return this.crmClient.tbltickets.findMany({
      where: { userid },
      orderBy: { date: 'desc' },
    });
  }

  // ==========================================
  // CLIENT AUTHENTICATION & REGISTRATION
  // ==========================================

  /**
   * Register new client with contact
   */
  async registerClient(data: {
    email: string;
    password: string;
    firstname: string;
    lastname: string;
    phonenumber?: string;
    company: string;
    address?: string;
    city?: string;
    website?: string;
    country?: number;
    zip?: string;
  }) {
    // Check if contact already exists
    const existing = await this.crmClient.tblcontacts.findFirst({
      where: { email: data.email },
    });

    if (existing) {
      throw new Error('Email already registered');
    }

    // Create client company first
    const client = await this.crmClient.tblclients.create({
      data: {
        company: data.company,
        phonenumber: data.phonenumber || '',
        country: data.country || 237, // Vietnam default
        city: data.city || '',
        address: data.address || '',
        website: data.website || '',
        active: 1,
      },
    });

    // Then create contact linked to client
    const contact = await this.crmClient.tblcontacts.create({
      data: {
        userid: client.userid,
        firstname: data.firstname,
        lastname: data.lastname,
        email: data.email,
        phonenumber: data.phonenumber || '',
        password: data.password, // Should be hashed before passing here
        is_primary: 1,
        active: 1,
      },
    });

    return {
      client,
      contact,
    };
  }

  /**
   * Authenticate client contact
   */
  async authenticateClient(email: string, password: string) {
    const contact = await this.crmClient.tblcontacts.findFirst({
      where: {
        email,
        active: 1,
      },
    });

    if (!contact) {
      throw new Error('Invalid credentials');
    }

    // Get client info
    const client = await this.crmClient.tblclients.findUnique({
      where: { userid: contact.userid },
    });

    // Password verification should be done by caller using bcrypt
    return {
      contactid: contact.id,
      userid: contact.userid,
      email: contact.email,
      firstname: contact.firstname,
      lastname: contact.lastname,
      company: client?.company,
      password: contact.password, // Return hashed password for verification
    };
  }

  // ==========================================
  // WRITE OPERATIONS - PROJECTS
  // ==========================================

  async createProject(data: {
    name: string;
    description?: string;
    clientid: number;
    billing_type?: number;
    start_date?: string;
    deadline?: string;
    project_cost?: string;
    addedfrom: number;
  }) {
    const projectData: any = {
      name: data.name,
      description: data.description || '',
      clientid: data.clientid,
      billing_type: data.billing_type || 1,
      project_cost: data.project_cost || '0',
      status: 1, // In Progress
      addedfrom: data.addedfrom,
    };

    if (data.start_date) {
      projectData.start_date = data.start_date;
    }
    if (data.deadline) {
      projectData.deadline = data.deadline;
    }

    return this.crmClient.tblprojects.create({
      data: projectData,
    });
  }

  async updateProject(
    id: number,
    data: Partial<{
      name: string;
      description: string;
      status: number;
      progress: number;
      start_date: string;
      deadline: string;
      project_cost: string;
    }>,
  ) {
    return this.crmClient.tblprojects.update({
      where: { id },
      data,
    });
  }

  // ==========================================
  // WRITE OPERATIONS - TASKS
  // ==========================================

  async createTask(data: {
    name: string;
    description?: string;
    priority?: number;
    startdate?: string;
    duedate?: string;
    rel_id?: number;
    rel_type?: string;
    billable?: number;
    hourly_rate?: string;
    addedfrom: number;
  }) {
    return this.crmClient.tbltasks.create({
      data: {
        name: data.name,
        description: data.description || '',
        priority: data.priority || 1,
        startdate: data.startdate,
        duedate: data.duedate,
        status: 1, // Not Started
        rel_id: data.rel_id,
        rel_type: data.rel_type || 'project',
        billable: data.billable || 0,
        hourly_rate: data.hourly_rate || '0',
        addedfrom: data.addedfrom,
      },
    });
  }

  async updateTask(
    id: number,
    data: Partial<{
      name: string;
      description: string;
      status: number;
      priority: number;
      startdate: string;
      duedate: string;
    }>,
  ) {
    return this.crmClient.tbltasks.update({
      where: { id },
      data,
    });
  }

  // ==========================================
  // WRITE OPERATIONS - TICKETS
  // ==========================================

  async createTicket(data: {
    userid: number;
    contactid?: number;
    email: string;
    name: string;
    department?: number;
    priority?: number;
    subject: string;
    message: string;
    project_id?: number;
  }) {
    // Generate unique ticket key
    const ticketkey = this.generateTicketKey();

    return this.crmClient.tbltickets.create({
      data: {
        userid: data.userid,
        contactid: data.contactid,
        email: data.email,
        name: data.name,
        department: data.department || 1,
        priority: data.priority || 2,
        status: 1, // Open
        ticketkey,
        subject: data.subject,
        message: data.message,
        project_id: data.project_id,
      },
    });
  }

  async updateTicketStatus(ticketid: number, status: number) {
    return this.crmClient.tbltickets.update({
      where: { ticketid },
      data: { status },
    });
  }

  private generateTicketKey(): string {
    const chars =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let key = '';
    for (let i = 0; i < 12; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
  }

  // ==========================================
  // SYNC METHODS (cho real-time sync)
  // ==========================================

  /**
   * Sync user từ API vào CRM staff table
   */
  async syncUserToCrmStaff(user: {
    email: string;
    name: string;
    role: string;
    password: string;
  }) {
    const [firstname, ...lastnameParts] = user.name.split(' ');
    const lastname = lastnameParts.join(' ') || '';

    // Check if staff exists
    const existing = await this.crmClient.tblstaff.findUnique({
      where: { email: user.email },
    });

    if (existing) {
      // Update existing
      return this.crmClient.tblstaff.update({
        where: { email: user.email },
        data: {
          firstname,
          lastname,
          admin: user.role === 'ADMIN' ? 1 : 0,
        },
      });
    } else {
      // Create new
      return this.crmClient.tblstaff.create({
        data: {
          email: user.email,
          firstname,
          lastname,
          password: user.password, // Already hashed from API
          admin: user.role === 'ADMIN' ? 1 : 0,
          active: 1,
        },
      });
    }
  }

  /**
   * Sync CRM client vào API User (CLIENT role)
   */
  async syncCrmClientToApiUser(clientid: number) {
    const client = await this.crmClient.tblclients.findUnique({
      where: { userid: clientid },
    });

    if (!client) {
      throw new Error(`Client ${clientid} not found in CRM`);
    }

    const primaryContact = await this.getPrimaryContact(clientid);

    if (!primaryContact) {
      throw new Error(`No primary contact for client ${clientid}`);
    }

    return {
      email: primaryContact.email,
      name: `${primaryContact.firstname} ${primaryContact.lastname}`.trim(),
      company: client.company,
      phone: client.phonenumber,
      address: client.address,
      city: client.city,
      website: client.website,
      password: primaryContact.password, // Use CRM password
    };
  }

  /**
   * Get dashboard stats from CRM
   */
  async getDashboardStats() {
    const [
      totalClients,
      activeProjects,
      openTasks,
      unpaidInvoices,
      openTickets,
    ] = await Promise.all([
      this.crmClient.tblclients.count({ where: { active: 1 } }),
      this.crmClient.tblprojects.count({
        where: { status: { in: [1, 2, 3] } },
      }),
      this.crmClient.tbltasks.count({ where: { status: { in: [1, 4] } } }),
      this.crmClient.tblinvoices.count({ where: { status: { in: [1, 4] } } }),
      this.crmClient.tbltickets.count({ where: { status: { in: [1, 2] } } }),
    ]);

    const totalRevenue = await this.crmClient.tblinvoices.aggregate({
      where: { status: 2 }, // Paid
      _sum: { total: true },
    });

    const pendingRevenue = await this.crmClient.tblinvoices.aggregate({
      where: { status: { in: [1, 4] } }, // Unpaid, Overdue
      _sum: { total: true },
    });

    return {
      totalClients,
      activeProjects,
      openTasks,
      unpaidInvoices,
      openTickets,
      totalRevenue: totalRevenue._sum.total || 0,
      pendingRevenue: pendingRevenue._sum.total || 0,
    };
  }

  // Raw query access nếu cần
  get client() {
    return this.crmClient;
  }
}
