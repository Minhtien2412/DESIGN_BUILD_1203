import { Body, Controller, Headers, Logger, Post, UnauthorizedException } from '@nestjs/common';
import { getErrorMessage, getAxiosErrorData, getErrorStatus, getErrorStack, isAxiosError, logError } from '../utils/error-helpers';

import { ProductsService } from '../products/products.service';
import { ProjectsService } from '../projects/projects.service';
import { ServicesService } from '../services/services.service';
import { TasksService } from '../tasks/tasks.service';

interface SyncPayload {
  operation: 'create' | 'update' | 'delete';
  data: any;
}

@Controller('strapi-sync')
export class StrapiSyncController {
  private readonly logger = new Logger(StrapiSyncController.name);
  private readonly STRAPI_TOKEN = process.env.STRAPI_SYNC_TOKEN || 'strapi-sync-token-secret-change-this';

  constructor(
    private readonly productsService: ProductsService,
    private readonly projectsService: ProjectsService,
    private readonly servicesService: ServicesService,
    private readonly tasksService: TasksService,
  ) {}

  /**
   * Verify token từ Strapi
   */
  private verifyToken(authHeader: string): boolean {
    if (!authHeader) {
      return false;
    }
    const token = authHeader.replace('Bearer ', '');
    return token === this.STRAPI_TOKEN;
  }

  /**
   * Nhận sync từ Strapi cho Products
   * POST /api/v1/strapi-sync/products
   */
  @Post('products')
  async syncProduct(
    @Body() payload: SyncPayload,
    @Headers('authorization') auth: string,
  ) {
    if (!this.verifyToken(auth)) {
      this.logger.warn('Unauthorized sync attempt for products');
      throw new UnauthorizedException('Invalid sync token');
    }

    const { operation, data } = payload;
    this.logger.log(`[Strapi → Backend] Syncing product: ${operation} - ${data.strapiId || data.id}`);

    try {
      let result;

      switch (operation) {
        case 'create':
          // Tạo product mới, hoặc update nếu đã tồn tại
          const existing = await this.productsService.findByStrapiId(data.strapiId);
          if (existing) {
            result = await this.productsService.updateFromStrapi(existing.id, data);
            this.logger.log(`Updated existing product: ${existing.id}`);
          } else {
            result = await this.productsService.createFromStrapi(data);
            this.logger.log(`Created new product: ${result.id}`);
          }
          break;

        case 'update':
          // Update product by strapiId
          const productToUpdate = await this.productsService.findByStrapiId(data.strapiId);
          if (productToUpdate) {
            result = await this.productsService.updateFromStrapi(productToUpdate.id, data);
            this.logger.log(`Updated product: ${productToUpdate.id}`);
          } else {
            // Nếu không tìm thấy, tạo mới
            result = await this.productsService.createFromStrapi(data);
            this.logger.log(`Product not found, created new: ${result.id}`);
          }
          break;

        case 'delete':
          // Xóa product by strapiId
          const productToDelete = await this.productsService.findByStrapiId(data.strapiId);
          if (productToDelete) {
            await this.productsService.removeById(productToDelete.id);
            this.logger.log(`Deleted product: ${productToDelete.id}`);
            result = { deleted: true, id: productToDelete.id };
          } else {
            this.logger.warn(`Product not found for deletion: ${data.strapiId}`);
            result = { deleted: false, message: 'Product not found' };
          }
          break;

        default:
          throw new Error(`Unknown operation: ${operation}`);
      }

      return {
        success: true,
        message: `Product ${operation}d successfully`,
        data: result
      };

    } catch (error: unknown) {
      this.logger.error(`Failed to sync product: ${getErrorMessage(error)}`, getErrorStack(error));
      throw error;
    }
  }

  /**
   * Nhận sync từ Strapi cho Projects
   * POST /api/v1/strapi-sync/projects
   */
  @Post('projects')
  async syncProject(
    @Body() payload: SyncPayload,
    @Headers('authorization') auth: string,
  ) {
    if (!this.verifyToken(auth)) {
      this.logger.warn('Unauthorized sync attempt for projects');
      throw new UnauthorizedException('Invalid sync token');
    }

    const { operation, data } = payload;
    this.logger.log(`[Strapi → Backend] Syncing project: ${operation} - ${data.strapiId || data.id}`);

    try {
      let result;

      switch (operation) {
        case 'create':
          const existing = await this.projectsService.findByStrapiId(data.strapiId);
          if (existing) {
            result = await this.projectsService.updateFromStrapi(existing.id, data);
            this.logger.log(`Updated existing project: ${existing.id}`);
          } else {
            result = await this.projectsService.createFromStrapi(data);
            this.logger.log(`Created new project: ${result.id}`);
          }
          break;

        case 'update':
          const projectToUpdate = await this.projectsService.findByStrapiId(data.strapiId);
          if (projectToUpdate) {
            result = await this.projectsService.updateFromStrapi(projectToUpdate.id, data);
            this.logger.log(`Updated project: ${projectToUpdate.id}`);
          } else {
            result = await this.projectsService.createFromStrapi(data);
            this.logger.log(`Project not found, created new: ${result.id}`);
          }
          break;

        case 'delete':
          const projectToDelete = await this.projectsService.findByStrapiId(data.strapiId);
          if (projectToDelete) {
            await this.projectsService.removeById(projectToDelete.id);
            this.logger.log(`Deleted project: ${projectToDelete.id}`);
            result = { deleted: true, id: projectToDelete.id };
          } else {
            this.logger.warn(`Project not found for deletion: ${data.strapiId}`);
            result = { deleted: false, message: 'Project not found' };
          }
          break;

        default:
          throw new Error(`Unknown operation: ${operation}`);
      }

      return {
        success: true,
        message: `Project ${operation}d successfully`,
        data: result
      };

    } catch (error: unknown) {
      this.logger.error(`Failed to sync project: ${getErrorMessage(error)}`, getErrorStack(error));
      throw error;
    }
  }

  /**
   * Health check endpoint
   * GET /api/v1/strapi-sync/health
   */
  @Post('health')
  async health(@Headers('authorization') auth: string) {
    if (!this.verifyToken(auth)) {
      throw new UnauthorizedException('Invalid sync token');
    }

    return {
      success: true,
      message: 'Strapi sync endpoint is healthy',
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Nhận sync từ Strapi cho Services
   * POST /api/v1/strapi-sync/services
   */
  @Post('services')
  async syncService(
    @Body() payload: SyncPayload,
    @Headers('authorization') auth: string,
  ) {
    if (!this.verifyToken(auth)) {
      this.logger.warn('Unauthorized sync attempt for services');
      throw new UnauthorizedException('Invalid sync token');
    }

    const { operation, data } = payload;
    this.logger.log(`[Strapi → Backend] Syncing service: ${operation} - ${data.strapiId || data.id}`);

    try {
      let result;

      switch (operation) {
        case 'create':
          const existingService = await this.servicesService.findByStrapiId(data.strapiId);
          if (existingService) {
            result = await this.servicesService.updateFromStrapi(existingService.id, data);
            this.logger.log(`Updated existing service: ${existingService.id}`);
          } else {
            result = await this.servicesService.createFromStrapi(data);
            this.logger.log(`Created new service: ${result.id}`);
          }
          break;

        case 'update':
          const serviceToUpdate = await this.servicesService.findByStrapiId(data.strapiId);
          if (serviceToUpdate) {
            result = await this.servicesService.updateFromStrapi(serviceToUpdate.id, data);
            this.logger.log(`Updated service: ${serviceToUpdate.id}`);
          } else {
            result = await this.servicesService.createFromStrapi(data);
            this.logger.log(`Service not found, created new: ${result.id}`);
          }
          break;

        case 'delete':
          const serviceToDelete = await this.servicesService.findByStrapiId(data.strapiId);
          if (serviceToDelete) {
            await this.servicesService.removeById(serviceToDelete.id);
            this.logger.log(`Deleted service: ${serviceToDelete.id}`);
            result = { deleted: true, id: serviceToDelete.id };
          } else {
            this.logger.warn(`Service not found for deletion: ${data.strapiId}`);
            result = { deleted: false, message: 'Service not found' };
          }
          break;

        default:
          throw new Error(`Unknown operation: ${operation}`);
      }

      return {
        success: true,
        message: `Service ${operation}d successfully`,
        data: result
      };

    } catch (error: unknown) {
      this.logger.error(`Failed to sync service: ${getErrorMessage(error)}`, getErrorStack(error));
      throw error;
    }
  }

  /**
   * Nhận sync từ Strapi cho Tasks
   * POST /api/v1/strapi-sync/tasks
   */
  @Post('tasks')
  async syncTask(
    @Body() payload: SyncPayload,
    @Headers('authorization') auth: string,
  ) {
    if (!this.verifyToken(auth)) {
      this.logger.warn('Unauthorized sync attempt for tasks');
      throw new UnauthorizedException('Invalid sync token');
    }

    const { operation, data } = payload;
    this.logger.log(`[Strapi → Backend] Syncing task: ${operation} - ${data.strapiId || data.id}`);

    try {
      let result;

      switch (operation) {
        case 'create':
          const existingTask = await this.tasksService.findByStrapiId(data.strapiId);
          if (existingTask) {
            result = await this.tasksService.updateFromStrapi(existingTask.id, data);
            this.logger.log(`Updated existing task: ${existingTask.id}`);
          } else {
            result = await this.tasksService.createFromStrapi(data);
            this.logger.log(`Created new task: ${result.id}`);
          }
          break;

        case 'update':
          const taskToUpdate = await this.tasksService.findByStrapiId(data.strapiId);
          if (taskToUpdate) {
            result = await this.tasksService.updateFromStrapi(taskToUpdate.id, data);
            this.logger.log(`Updated task: ${taskToUpdate.id}`);
          } else {
            result = await this.tasksService.createFromStrapi(data);
            this.logger.log(`Task not found, created new: ${result.id}`);
          }
          break;

        case 'delete':
          const taskToDelete = await this.tasksService.findByStrapiId(data.strapiId);
          if (taskToDelete) {
            await this.tasksService.removeById(taskToDelete.id);
            this.logger.log(`Deleted task: ${taskToDelete.id}`);
            result = { deleted: true, id: taskToDelete.id };
          } else {
            this.logger.warn(`Task not found for deletion: ${data.strapiId}`);
            result = { deleted: false, message: 'Task not found' };
          }
          break;

        default:
          throw new Error(`Unknown operation: ${operation}`);
      }

      return {
        success: true,
        message: `Task ${operation}d successfully`,
        data: result
      };

    } catch (error: unknown) {
      this.logger.error(`Failed to sync task: ${getErrorMessage(error)}`, getErrorStack(error));
      throw error;
    }
  }
}
