import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { UpdateProductDto } from './dto/update-product.dto';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  async findAll(query: ProductQueryDto) {
    const {
      page = 1,
      limit = 20,
      category,
      search,
      status,
      minPrice,
      maxPrice,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = query;

    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = {};

    if (category) {
      where.category = category;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (status) {
      where.status = status;
    }

    if (minPrice !== undefined || maxPrice !== undefined) {
      where.price = {};
      if (minPrice !== undefined) {
        where.price.gte = minPrice;
      }
      if (maxPrice !== undefined) {
        where.price.lte = maxPrice;
      }
    }

    // Get total count
    const total = await this.prisma.product.count({ where });

    // Get products
    const products = await this.prisma.product.findMany({
      where,
      skip,
      take: limit,
      orderBy: {
        [sortBy]: sortOrder,
      },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    // Transform to match API contract (rename createdBy user to seller)
    const transformedProducts = products.map((product) => ({
      ...product,
      seller: product.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    }));

    return {
      data: transformedProducts,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: number) {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Transform to match API contract
    return {
      ...product,
      seller: product.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    };
  }

  async create(createProductDto: CreateProductDto, createdBy: number) {
    // Validate price
    if (createProductDto.price <= 0) {
      throw new BadRequestException('Price must be greater than 0');
    }

    // Validate stock if provided
    if (
      createProductDto.stock !== undefined &&
      createProductDto.stock < 0
    ) {
      throw new BadRequestException('Stock cannot be negative');
    }

    const product = await this.prisma.product.create({
      data: {
        name: createProductDto.name,
        description: createProductDto.description || '',
        price: createProductDto.price,
        category: createProductDto.category,
        stock: createProductDto.stock || 0,
        createdBy,
        status: 'PENDING',
        updatedAt: new Date(),
      },
    });

    // Fetch product with relations
    const productWithRelations = await this.prisma.product.findUnique({
      where: { id: product.id },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    if (!productWithRelations) {
      throw new NotFoundException('Product created but could not be retrieved');
    }

    return {
      ...productWithRelations,
      seller: productWithRelations.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    };
  }

  async update(id: number, updateProductDto: UpdateProductDto, user: any) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Check permissions: only owner or ADMIN can update
    if (product.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException(
        'You do not have permission to update this product',
      );
    }

    // Validate price if provided
    if (
      updateProductDto.price !== undefined &&
      updateProductDto.price <= 0
    ) {
      throw new BadRequestException('Price must be greater than 0');
    }

    // Validate stock if provided
    if (
      updateProductDto.stock !== undefined &&
      updateProductDto.stock < 0
    ) {
      throw new BadRequestException('Stock cannot be negative');
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: {
        ...(updateProductDto.name && { name: updateProductDto.name }),
        ...(updateProductDto.description && { description: updateProductDto.description }),
        ...(updateProductDto.price !== undefined && { price: updateProductDto.price }),
        ...(updateProductDto.category && { category: updateProductDto.category }),
        ...(updateProductDto.stock !== undefined && { stock: updateProductDto.stock }),
        ...(updateProductDto.status && { status: updateProductDto.status }),
        updatedAt: new Date(),
      },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    return {
      ...updated,
      seller: updated.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    };
  }

  async remove(id: number, user: any) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Check permissions: only owner or ADMIN can delete
    if (product.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException(
        'You do not have permission to delete this product',
      );
    }

    await this.prisma.product.delete({
      where: { id },
    });
  }

  async updateStatus(
    id: number,
    status: 'APPROVED' | 'REJECTED' | 'PENDING',
  ) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: { 
        status,
        updatedAt: new Date(),
      },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    return {
      ...updated,
      seller: updated.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    };
  }

  // ==================== STRAPI SYNC METHODS ====================

  /**
   * Find product by Strapi ID
   */
  async findByStrapiId(strapiId: string) {
    return this.prisma.product.findUnique({
      where: { strapiId },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });
  }

  /**
   * Create product from Strapi sync (without user requirement)
   */
  async createFromStrapi(data: any) {
    return this.prisma.product.create({
      data: {
        name: data.name,
        description: data.description || '',
        price: data.price,
        category: data.category,
        stock: data.stock || 0,
        status: data.status || 'PENDING',
        viewCount: data.viewCount || 0,
        soldCount: data.soldCount || 0,
        isBestseller: data.isBestseller || false,
        isNew: data.isNew || true,
        strapiId: data.strapiId,
        createdBy: data.createdBy || 1, // Default to admin
        updatedAt: new Date(),
      },
    });
  }

  /**
   * Update product from Strapi sync
   */
  async updateFromStrapi(id: number, data: any) {
    return this.prisma.product.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        price: data.price,
        category: data.category,
        stock: data.stock,
        status: data.status,
        viewCount: data.viewCount,
        soldCount: data.soldCount,
        isBestseller: data.isBestseller,
        isNew: data.isNew,
        updatedAt: new Date(),
      },
    });
  }

  /**
   * Delete product by ID (without user requirement for sync)
   */
  async removeById(id: number) {
    await this.prisma.product.delete({ where: { id } });
    return { deleted: true, id };
  }
}
