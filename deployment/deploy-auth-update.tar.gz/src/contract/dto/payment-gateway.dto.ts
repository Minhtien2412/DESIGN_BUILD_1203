import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsInt, IsNumber, IsOptional, IsString } from 'class-validator';

export enum PaymentGatewayType {
  MOMO = 'MOMO',
  VNPAY = 'VNPAY',
  STRIPE = 'STRIPE',
}

export class ContractPaymentDto {
  @ApiProperty({ description: 'ID lịch thanh toán' })
  @IsInt()
  scheduleId: number;

  @ApiProperty({ description: 'Số tiền thanh toán', example: 50000000 })
  @IsNumber()
  amount: number;

  @ApiProperty({ description: 'Cổng thanh toán', enum: PaymentGatewayType })
  @IsEnum(PaymentGatewayType)
  gateway: PaymentGatewayType;

  @ApiPropertyOptional({
    description: 'URL return sau khi thanh toán',
    example: 'https://app.com/payment/success',
  })
  @IsString()
  @IsOptional()
  returnUrl?: string;

  @ApiPropertyOptional({
    description: 'URL notify webhook',
    example: 'https://api.com/payment/notify',
  })
  @IsString()
  @IsOptional()
  notifyUrl?: string;
}

export class PaymentCallbackDto {
  @ApiProperty({ description: 'Reference ID từ payment gateway' })
  @IsString()
  paymentRef: string;

  @ApiProperty({ description: 'Trạng thái', example: 'SUCCESS' })
  @IsString()
  status: string;

  @ApiPropertyOptional({ description: 'Dữ liệu callback (JSON)' })
  @IsOptional()
  data?: any;
}
