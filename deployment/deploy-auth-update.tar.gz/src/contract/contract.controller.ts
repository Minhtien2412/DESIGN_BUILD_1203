import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ContractService } from './contract.service';
import {
    ContractPaymentDto,
    CreateContractDto,
    CreateMaterialDto,
    CreateQuotationDto,
    SignContractDto,
    UpdateMaterialDto,
    UpdateQuotationDto,
} from './dto';
import { MaterialService } from './material.service';
import { PaymentGatewayService } from './payment-gateway.service';

@ApiTags('Contract & Quotation')
@Controller({ path: 'contract', version: '1' })
// @UseGuards(JwtAuthGuard) // Uncomment when auth is ready
export class ContractController {
  constructor(
    private readonly contractService: ContractService,
    private readonly materialService: MaterialService,
    private readonly paymentGatewayService: PaymentGatewayService,
  ) {}

  // ==================== MATERIALS ====================

  @Post('materials')
  @ApiOperation({ summary: 'Tạo vật tư mới trong catalog' })
  // @ApiBearerAuth()
  async createMaterial(@Body() dto: CreateMaterialDto) {
    return this.materialService.createMaterial(dto);
  }

  @Get('materials')
  @ApiOperation({ summary: 'Lấy danh sách vật tư' })
  async getMaterials(
    @Query('category') category?: string,
    @Query('isActive') isActive?: string,
  ) {
    const active =
      isActive === 'true' ? true : isActive === 'false' ? false : undefined;
    return this.materialService.getMaterials(category, active);
  }

  @Get('materials/categories')
  @ApiOperation({ summary: 'Lấy danh sách category' })
  async getCategories() {
    return this.materialService.getCategories();
  }

  @Get('materials/:id')
  @ApiOperation({ summary: 'Lấy chi tiết vật tư' })
  async getMaterialById(@Param('id', ParseIntPipe) id: number) {
    return this.materialService.getMaterialById(id);
  }

  @Patch('materials/:id')
  @ApiOperation({ summary: 'Cập nhật vật tư' })
  // @ApiBearerAuth()
  async updateMaterial(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateMaterialDto,
  ) {
    return this.materialService.updateMaterial(id, dto);
  }

  // ==================== QUOTATIONS ====================

  @Post('quotations')
  @ApiOperation({ summary: 'Tạo báo giá tự động từ bảng vật tư' })
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  async createQuotation(
    @Body() dto: CreateQuotationDto,
    @CurrentUser() user: any,
  ) {
    return this.contractService.createQuotation(user.id, dto);
  }

  @Get('quotations')
  @ApiOperation({ summary: 'Lấy danh sách báo giá' })
  async getQuotations(@Query('projectId', ParseIntPipe) projectId?: number) {
    return this.contractService.getQuotations(projectId);
  }

  @Get('quotations/:id')
  @ApiOperation({ summary: 'Lấy chi tiết báo giá' })
  async getQuotationById(@Param('id', ParseIntPipe) id: number) {
    return this.contractService.getQuotationById(id);
  }

  @Patch('quotations/:id')
  @ApiOperation({ summary: 'Cập nhật báo giá (lưu lịch sử thay đổi giá)' })
  // @ApiBearerAuth()
  async updateQuotation(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateQuotationDto,
  ) {
    return this.contractService.updateQuotation(id, dto);
  }

  @Post('quotations/:id/send')
  @ApiOperation({ summary: 'Gửi báo giá cho khách hàng' })
  // @ApiBearerAuth()
  async sendQuotation(@Param('id', ParseIntPipe) id: number) {
    return this.contractService.sendQuotation(id);
  }

  @Post('quotations/:id/approve')
  @ApiOperation({ summary: 'Khách hàng phê duyệt báo giá' })
  // @ApiBearerAuth()
  async approveQuotation(
    @Param('id', ParseIntPipe) id: number,
    // @CurrentUser() user: User,
  ) {
    const userId = 1; // Mock
    return this.contractService.approveQuotation(id, userId);
  }

  @Post('quotations/:id/reject')
  @ApiOperation({ summary: 'Từ chối báo giá' })
  // @ApiBearerAuth()
  async rejectQuotation(@Param('id', ParseIntPipe) id: number) {
    return this.contractService.rejectQuotation(id);
  }

  // ==================== CONTRACTS ====================

  @Post('contracts')
  @ApiOperation({
    summary: 'Tạo hợp đồng từ báo giá (tự động tạo lịch thanh toán)',
  })
  // @ApiBearerAuth()
  async createContract(
    @Body() dto: CreateContractDto,
    // @CurrentUser() user: User,
  ) {
    const userId = 1; // Mock
    return this.contractService.createContract(userId, dto);
  }

  @Get('contracts')
  @ApiOperation({ summary: 'Lấy danh sách hợp đồng' })
  async getContracts(
    @Query('projectId', ParseIntPipe) projectId?: number,
    @Query('clientId', ParseIntPipe) clientId?: number,
  ) {
    return this.contractService.getContracts(projectId, clientId);
  }

  @Get('contracts/:id')
  @ApiOperation({ summary: 'Lấy chi tiết hợp đồng' })
  async getContractById(@Param('id', ParseIntPipe) id: number) {
    return this.contractService.getContractById(id);
  }

  @Post('contracts/:id/sign')
  @ApiOperation({ summary: 'Khách hàng ký hợp đồng điện tử (e-sign)' })
  // @ApiBearerAuth()
  async signContract(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: SignContractDto,
    // @CurrentUser() user: User,
  ) {
    const userId = 1; // Mock
    return this.contractService.signContract(id, userId, dto);
  }

  @Post('contracts/:id/company-sign')
  @ApiOperation({ summary: 'Công ty ký hợp đồng (admin only)' })
  // @ApiBearerAuth()
  async companySignContract(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: SignContractDto,
  ) {
    return this.contractService.companySignContract(id, dto.signature);
  }

  @Get('contracts/:id/payment-schedules')
  @ApiOperation({ summary: 'Lấy lịch thanh toán của hợp đồng' })
  async getPaymentSchedules(@Param('id', ParseIntPipe) id: number) {
    return this.contractService.getPaymentSchedules(id);
  }

  // ==================== PAYMENTS ====================

  @Post('payments/initiate')
  @ApiOperation({ summary: 'Khởi tạo thanh toán qua Momo/VNPAY/Stripe' })
  // @ApiBearerAuth()
  async initiatePayment(@Body() dto: ContractPaymentDto) {
    return this.paymentGatewayService.initiatePayment(dto);
  }

  @Post('payments/callback/momo')
  @ApiOperation({ summary: 'Webhook callback từ Momo' })
  async momoCallback(@Body() data: any) {
    return this.paymentGatewayService.handlePaymentCallback('MOMO', data);
  }

  @Post('payments/callback/vnpay')
  @ApiOperation({ summary: 'Webhook callback từ VNPay' })
  async vnpayCallback(@Body() data: any) {
    return this.paymentGatewayService.handlePaymentCallback('VNPAY', data);
  }

  @Post('payments/callback/stripe')
  @ApiOperation({ summary: 'Webhook callback từ Stripe' })
  async stripeCallback(@Body() data: any) {
    return this.paymentGatewayService.handlePaymentCallback('STRIPE', data);
  }

  // ==================== COST TRACKING ====================

  @Get('cost-tracking/:projectId')
  @ApiOperation({ summary: 'Tracking chi phí: Dự toán vs Thực tế' })
  async trackCosts(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.contractService.trackCosts(projectId);
  }

  @Post('cost-tracking')
  @ApiOperation({ summary: 'Thêm tracking chi phí' })
  // @ApiBearerAuth()
  async addCostTracking(
    @Body()
    data: {
      projectId: number;
      itemName: string;
      category: string;
      budgetCost: number;
      actualCost: number;
      notes?: string;
    },
  ) {
    return this.contractService.addCostTracking(data.projectId, data);
  }
}
