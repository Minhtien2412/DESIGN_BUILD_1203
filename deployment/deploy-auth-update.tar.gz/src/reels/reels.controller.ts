/**
 * Reels Controller - API endpoints cho video reels
 * 
 * Hệ thống Video Cache thông minh:
 * - Lưu trữ ~2GB video từ Pexels trên server
 * - Auto-cleanup video cũ khi người dùng lướt
 * - Random display, không trùng lặp cho mỗi user/session
 * - Stream video từ local storage
 * 
 * Endpoints:
 * - GET /api/v1/reels - Lấy danh sách reels (có pagination, filter by category)
 * - GET /api/v1/reels/feed - Feed random cho mỗi user (MAIN API)
 * - GET /api/v1/reels/stream/:id - Stream video file
 * - GET /api/v1/reels/stats - Storage statistics
 * - POST /api/v1/reels/:id/view - Record view
 * 
 * @author AI Assistant
 * @date 16/01/2026
 */

import {
    Body,
    Controller,
    Get,
    Headers,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Query,
    Res,
    StreamableFile,
} from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import * as fs from 'fs';
import { ReelsService } from './reels.service';
import { VideoCacheService } from './video-cache.service';

@ApiTags('Reels')
@Controller('reels')
export class ReelsController {
  constructor(
    private readonly reelsService: ReelsService,
    private readonly videoCacheService: VideoCacheService,
  ) {}

  /**
   * GET /api/v1/reels/feed
   * MAIN API - Lấy video random cho user, không trùng lặp
   */
  @Get('feed')
  @ApiOperation({ summary: 'Lấy video feed random cho user (MAIN API)' })
  @ApiQuery({ name: 'limit', required: false, description: 'Số video (mặc định 10)' })
  @ApiResponse({ status: 200, description: 'Trả về danh sách video random' })
  async getFeed(
    @Headers('x-session-id') sessionId: string,
    @Headers('x-user-id') userId: string,
    @Query('limit') limit?: string,
  ) {
    // Generate session ID if not provided
    const session = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const userIdNum = userId ? parseInt(userId, 10) : null;
    const limitNum = Math.min(20, Math.max(1, parseInt(limit || '10', 10)));

    const videos = await this.videoCacheService.getRandomVideosForUser(
      session,
      userIdNum,
      limitNum,
    );

    // Get session stats
    const stats = await this.videoCacheService.getSessionStats(session);

    return {
      statusCode: 200,
      message: 'Success',
      data: {
        videos,
        sessionId: session,
        stats: {
          watched: stats.watched,
          remaining: stats.remaining,
        },
      },
      hasMore: stats.remaining > 0,
    };
  }

  /**
   * GET /api/v1/reels/stream/:id
   * Stream video file từ local storage
   */
  @Get('stream/:id')
  @ApiOperation({ summary: 'Stream video file' })
  @ApiResponse({ status: 200, description: 'Video stream' })
  @ApiResponse({ status: 404, description: 'Video not found' })
  async streamVideo(
    @Param('id') id: string,
    @Res({ passthrough: true }) res: Response,
    @Headers('range') range?: string,
  ): Promise<StreamableFile | void> {
    const videoId = parseInt(id, 10);
    const filePath = await this.videoCacheService.getVideoFilePath(videoId);

    if (!filePath || !fs.existsSync(filePath)) {
      res.status(404).json({ message: 'Video not found' });
      return;
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;

    // Support range requests for video seeking
    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunkSize = end - start + 1;

      res.status(206);
      res.set({
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': 'video/mp4',
      });

      const stream = fs.createReadStream(filePath, { start, end });
      return new StreamableFile(stream);
    }

    // Full file
    res.set({
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
      'Accept-Ranges': 'bytes',
    });

    const stream = fs.createReadStream(filePath);
    return new StreamableFile(stream);
  }

  /**
   * GET /api/v1/reels/stats
   * Lấy thống kê storage
   */
  @Get('stats')
  @ApiOperation({ summary: 'Lấy thống kê storage' })
  @ApiResponse({ status: 200, description: 'Storage statistics' })
  async getStorageStats() {
    const stats = await this.videoCacheService.getStorageStats();
    
    return {
      statusCode: 200,
      message: 'Success',
      data: {
        ...stats,
        totalSizeFormatted: this.formatBytes(stats.totalSize),
        maxSizeFormatted: this.formatBytes(stats.maxSize),
        freeSpaceFormatted: this.formatBytes(stats.freeSpace),
      },
    };
  }

  /**
   * POST /api/v1/reels/refresh
   * Force refresh video cache (admin only)
   */
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Force refresh video cache (admin)' })
  @ApiResponse({ status: 200, description: 'Refresh completed' })
  async forceRefresh() {
    const result = await this.videoCacheService.forceRefresh();
    
    return {
      statusCode: 200,
      message: 'Refresh completed',
      data: result,
    };
  }

  /**
   * GET /api/v1/reels
   * Legacy API - Lấy danh sách reels với pagination và filter
   */
  @Get()
  @ApiOperation({ summary: 'Lấy danh sách video reels (legacy)' })
  @ApiQuery({ name: 'category', required: false, description: 'Filter theo category' })
  @ApiQuery({ name: 'page', required: false, description: 'Số trang (mặc định 1)' })
  @ApiQuery({ name: 'limit', required: false, description: 'Số items/trang (mặc định 15)' })
  @ApiResponse({ status: 200, description: 'Trả về danh sách reels' })
  async getReels(
    @Query('category') category?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const categoryVal = category || 'all';
    const pageNum = Math.max(1, parseInt(page || '1', 10));
    const limitNum = Math.min(50, Math.max(1, parseInt(limit || '15', 10)));

    const result = await this.reelsService.getReels(categoryVal, pageNum, limitNum);

    return {
      ...result,
      page: pageNum,
      limit: limitNum,
      source: 'server',
    };
  }

  /**
   * GET /api/v1/reels/categories
   * Lấy danh sách categories có sẵn
   */
  @Get('categories')
  @ApiOperation({ summary: 'Lấy danh sách categories' })
  @ApiResponse({ status: 200, description: 'Trả về danh sách categories' })
  getCategories() {
    return {
      categories: [
        { id: 'all', name: 'Tất cả', icon: 'apps' },
        { id: 'kientruc', name: 'Kiến trúc', icon: 'business' },
        { id: 'noithat', name: 'Nội thất', icon: 'bed' },
        { id: 'thicong', name: 'Thi công', icon: 'construct' },
        { id: 'vatlieu', name: 'Vật liệu', icon: 'cube' },
        { id: 'phongthuy', name: 'Phong thủy', icon: 'compass' },
        { id: 'diennuoc', name: 'Điện nước', icon: 'water' },
        { id: 'sanvuon', name: 'Sân vườn', icon: 'leaf' },
      ],
    };
  }

  /**
   * GET /api/v1/reels/feed/trending
   * Lấy video trending (nhiều view/like nhất)
   */
  @Get('feed/trending')
  @ApiOperation({ summary: 'Lấy video trending' })
  @ApiResponse({ status: 200, description: 'Trả về video trending' })
  async getTrending(@Query('limit') limit?: string) {
    const limitNum = Math.min(30, Math.max(1, parseInt(limit || '10', 10)));
    
    const result = await this.reelsService.getReels('all', 1, limitNum);
    
    return {
      ...result,
      type: 'trending',
    };
  }

  /**
   * GET /api/v1/reels/feed/following
   * Lấy video từ những người đang follow
   */
  @Get('feed/following')
  @ApiOperation({ summary: 'Lấy video từ người đang follow' })
  @ApiResponse({ status: 200, description: 'Trả về video từ following' })
  async getFollowing(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const pageNum = Math.max(1, parseInt(page || '1', 10));
    const limitNum = Math.min(50, Math.max(1, parseInt(limit || '15', 10)));
    
    const result = await this.reelsService.getReels('all', pageNum, limitNum);
    
    return {
      ...result,
      type: 'following',
    };
  }

  /**
   * GET /api/v1/reels/:id
   * Lấy chi tiết 1 reel theo ID
   */
  @Get(':id')
  @ApiOperation({ summary: 'Lấy chi tiết 1 reel' })
  @ApiResponse({ status: 200, description: 'Trả về chi tiết reel' })
  @ApiResponse({ status: 404, description: 'Không tìm thấy reel' })
  async getReelById(@Param('id') id: string) {
    // Try cache first
    const videoId = parseInt(id, 10);
    if (!isNaN(videoId)) {
      const cachedVideo = await this.videoCacheService.getVideoById(videoId);
      if (cachedVideo) {
        return {
          statusCode: 200,
          message: 'Success',
          data: cachedVideo,
        };
      }
    }

    // Fallback to pexels service
    const reel = await this.reelsService.getReelById(id);
    
    if (!reel) {
      return {
        statusCode: 404,
        message: 'Reel not found',
        data: null,
      };
    }

    return {
      statusCode: 200,
      message: 'Success',
      data: reel,
    };
  }

  /**
   * POST /api/v1/reels/:id/view
   * Record view cho video
   */
  @Post(':id/view')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Ghi nhận view cho reel' })
  @ApiResponse({ status: 200, description: 'View đã được ghi nhận' })
  async recordView(
    @Param('id') id: string,
    @Headers('x-session-id') sessionId: string,
    @Body() body: { watchDuration?: number; completed?: boolean },
  ) {
    const videoId = parseInt(id, 10);
    const session = sessionId || 'anonymous';
    
    if (!isNaN(videoId)) {
      await this.videoCacheService.recordView(
        videoId,
        session,
        body.watchDuration || 0,
        body.completed || false,
      );
    }

    // Also call legacy service
    await this.reelsService.incrementView(id);
    
    return {
      statusCode: 200,
      message: 'View recorded',
      reelId: id,
    };
  }

  // Helper
  private formatBytes(bytes: number): string {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
  }
}
