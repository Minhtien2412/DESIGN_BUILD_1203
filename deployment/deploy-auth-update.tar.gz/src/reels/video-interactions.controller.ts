/**
 * Video Interactions Controller
 *
 * API Endpoints cho tương tác video kiểu TikTok:
 * - POST /interactions/:videoId/like - Like/Unlike
 * - GET /interactions/:videoId/comments - Lấy comments
 * - POST /interactions/:videoId/comments - Thêm comment
 * - POST /interactions/:videoId/share - Record share
 * - POST /interactions/:videoId/view - Record view
 * - POST /interactions/:videoId/save - Save/Bookmark
 * - POST /interactions/:videoId/download - Record download
 * - GET /interactions/:videoId/stats - Get full stats
 * - GET /interactions/:videoId/status - Get user interaction status
 *
 * @author AI Assistant
 * @date 16/01/2026
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Logger,
    Param,
    ParseIntPipe,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import { VideoInteractionsService } from './video-interactions.service';

// ==================== DTOs ====================

interface CreateCommentDto {
  content: string;
  parentId?: number;
}

interface RecordViewDto {
  watchDuration: number;
  completed?: boolean;
}

interface RecordShareDto {
  platform: string; // facebook, twitter, whatsapp, copy_link, etc.
}

// ==================== CONTROLLER ====================

@Controller('interactions')
export class VideoInteractionsController {
  private readonly logger = new Logger(VideoInteractionsController.name);

  constructor(private readonly interactionsService: VideoInteractionsService) {}

  // ==================== LIKES ====================

  /**
   * Toggle like for a video
   * POST /api/v1/interactions/:videoId/like
   */
  @Post(':videoId/like')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async toggleLike(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    this.logger.log(`User ${userId} toggling like for video ${videoId}`);

    const result = await this.interactionsService.toggleLike(videoId, userId);

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Get users who liked video
   * GET /api/v1/interactions/:videoId/likes
   */
  @Get(':videoId/likes')
  @UseGuards(OptionalAuthGuard)
  async getLikes(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Query('limit') limit = 50,
    @Query('offset') offset = 0,
  ) {
    const users = await this.interactionsService.getLikedUsers(
      videoId,
      limit,
      offset,
    );

    return {
      success: true,
      users,
      count: users.length,
    };
  }

  // ==================== COMMENTS ====================

  /**
   * Get comments for video
   * GET /api/v1/interactions/:videoId/comments
   */
  @Get(':videoId/comments')
  @UseGuards(OptionalAuthGuard)
  async getComments(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
    @Query('sortBy') sortBy: 'newest' | 'popular' = 'newest',
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;

    const result = await this.interactionsService.getComments(
      videoId,
      userId,
      +page,
      +limit,
      sortBy,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Add a comment
   * POST /api/v1/interactions/:videoId/comments
   */
  @Post(':videoId/comments')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.CREATED)
  async createComment(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Body() dto: CreateCommentDto,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    this.logger.log(`User ${userId} commenting on video ${videoId}`);

    const comment = await this.interactionsService.createComment(
      videoId,
      userId,
      dto.content,
      dto.parentId,
    );

    return {
      success: true,
      comment,
    };
  }

  /**
   * Get replies for a comment
   * GET /api/v1/interactions/comments/:commentId/replies
   */
  @Get('comments/:commentId/replies')
  @UseGuards(OptionalAuthGuard)
  async getReplies(
    @Param('commentId', ParseIntPipe) commentId: number,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;

    const result = await this.interactionsService.getReplies(
      commentId,
      userId,
      +page,
      +limit,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Delete a comment
   * DELETE /api/v1/interactions/comments/:commentId
   */
  @Delete('comments/:commentId')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteComment(
    @Param('commentId', ParseIntPipe) commentId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    await this.interactionsService.deleteComment(commentId, userId);
  }

  /**
   * Toggle like for a comment
   * POST /api/v1/interactions/comments/:commentId/like
   */
  @Post('comments/:commentId/like')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async toggleCommentLike(
    @Param('commentId', ParseIntPipe) commentId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    const result = await this.interactionsService.toggleCommentLike(
      commentId,
      userId,
    );

    return {
      success: true,
      ...result,
    };
  }

  // ==================== VIEWS ====================

  /**
   * Record a video view
   * POST /api/v1/interactions/:videoId/view
   */
  @Post(':videoId/view')
  @UseGuards(OptionalAuthGuard)
  @HttpCode(HttpStatus.OK)
  async recordView(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Body() dto: RecordViewDto,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;

    const result = await this.interactionsService.recordView(
      videoId,
      userId,
      dto.watchDuration || 0,
      dto.completed || false,
    );

    return {
      success: true,
      ...result,
    };
  }

  // ==================== SHARES ====================

  /**
   * Record a share
   * POST /api/v1/interactions/:videoId/share
   */
  @Post(':videoId/share')
  @UseGuards(OptionalAuthGuard)
  @HttpCode(HttpStatus.OK)
  async recordShare(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Body() dto: RecordShareDto,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;
    this.logger.log(`Share recorded for video ${videoId} via ${dto.platform}`);

    const result = await this.interactionsService.recordShare(
      videoId,
      userId,
      dto.platform,
    );

    return {
      success: true,
      ...result,
    };
  }

  // ==================== SAVES ====================

  /**
   * Toggle save/bookmark
   * POST /api/v1/interactions/:videoId/save
   */
  @Post(':videoId/save')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async toggleSave(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    this.logger.log(`User ${userId} toggling save for video ${videoId}`);

    const result = await this.interactionsService.toggleSave(videoId, userId);

    return {
      success: true,
      ...result,
    };
  }

  // ==================== DOWNLOADS ====================

  /**
   * Record a download
   * POST /api/v1/interactions/:videoId/download
   */
  @Post(':videoId/download')
  @UseGuards(OptionalAuthGuard)
  @HttpCode(HttpStatus.OK)
  async recordDownload(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;
    this.logger.log(`Download recorded for video ${videoId}`);

    const result = await this.interactionsService.recordDownload(
      videoId,
      userId,
    );

    return {
      success: true,
      ...result,
    };
  }

  // ==================== STATS ====================

  /**
   * Get full video stats
   * GET /api/v1/interactions/:videoId/stats
   */
  @Get(':videoId/stats')
  async getStats(@Param('videoId', ParseIntPipe) videoId: number) {
    const stats = await this.interactionsService.getVideoStats(videoId);

    return {
      success: true,
      stats,
    };
  }

  /**
   * Get user's interaction status with video
   * GET /api/v1/interactions/:videoId/status
   */
  @Get(':videoId/status')
  @UseGuards(JwtAuthGuard)
  async getInteractionStatus(
    @Param('videoId', ParseIntPipe) videoId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    const status = await this.interactionsService.getUserInteractionStatus(
      videoId,
      userId,
    );

    return {
      success: true,
      status,
    };
  }

  /**
   * Get batch stats for multiple videos
   * POST /api/v1/interactions/batch-stats
   */
  @Post('batch-stats')
  @HttpCode(HttpStatus.OK)
  async getBatchStats(@Body() body: { videoIds: number[] }) {
    const stats = await this.interactionsService.getBatchStats(body.videoIds);

    return {
      success: true,
      stats,
    };
  }
}
