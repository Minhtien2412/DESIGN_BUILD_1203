import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { ScheduleModule } from '@nestjs/schedule';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import { PrismaModule } from '../prisma/prisma.module';
import { ReelsController } from './reels.controller';
import { ReelsService } from './reels.service';
import { VideoCacheService } from './video-cache.service';
import { VideoInteractionsController } from './video-interactions.controller';
import { VideoInteractionsService } from './video-interactions.service';

@Module({
  imports: [
    HttpModule.register({
      timeout: 60000, // Increase for video downloads
      maxRedirects: 5,
    }),
    ConfigModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: '7d' },
      }),
      inject: [ConfigService],
    }),
    PrismaModule,
    ScheduleModule.forRoot(), // For cron jobs
  ],
  controllers: [ReelsController, VideoInteractionsController],
  providers: [
    ReelsService,
    VideoCacheService,
    VideoInteractionsService,
    OptionalAuthGuard,
  ],
  exports: [ReelsService, VideoCacheService, VideoInteractionsService],
})
export class ReelsModule {}
