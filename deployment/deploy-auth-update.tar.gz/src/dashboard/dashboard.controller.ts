import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiResponse,
} from '@nestjs/swagger';
import { DashboardService } from './dashboard.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
  AdminDashboardDto,
  EngineerDashboardDto,
  ClientDashboardDto,
  MasterDashboardDto,
} from './dto';

@ApiTags('Dashboard')
@Controller({ path: 'dashboard', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Get('admin')
  @ApiOperation({
    summary:
      'Dashboard Admin - Tổng quan doanh thu, dự án, tiến độ, lỗi, nhân sự',
    description:
      'Chỉ ADMIN mới truy cập được. Hiển thị toàn bộ thống kê hệ thống.',
  })
  @ApiResponse({ status: 200, type: AdminDashboardDto })
  async getAdminDashboard(@Request() req): Promise<AdminDashboardDto> {
    return this.dashboardService.getAdminDashboard(req.user.id);
  }

  @Get('engineer')
  @ApiOperation({
    summary: 'Dashboard Kỹ sư - Dự án, Task hôm nay, Checklist, Báo cáo',
    description:
      'Chỉ ENGINEER truy cập. Quản lý công việc và gửi báo cáo hàng ngày.',
  })
  @ApiResponse({ status: 200, type: EngineerDashboardDto })
  async getEngineerDashboard(@Request() req): Promise<EngineerDashboardDto> {
    return this.dashboardService.getEngineerDashboard(req.user.id);
  }

  @Get('client')
  @ApiOperation({
    summary: 'Dashboard Khách hàng - Tiến độ, Tài liệu, Chat, Video call',
    description:
      'Chỉ CLIENT truy cập. Xem tiến độ thực tế, bản vẽ, hợp đồng, nhắn tin kỹ sư.',
  })
  @ApiResponse({ status: 200, type: ClientDashboardDto })
  async getClientDashboard(@Request() req): Promise<ClientDashboardDto> {
    return this.dashboardService.getClientDashboard(req.user.id);
  }

  @Get('master')
  @ApiOperation({
    summary:
      'Master Dashboard - Tổng quan TOÀN BỘ hệ thống (All modules)',
    description:
      'Chỉ ADMIN truy cập. Quản lý dashboard tổng thể: Users, Projects, Tasks, Products, Payments, CRM, AI, Chat, Video, Uploads, Attendance, Contracts, Timeline, QC và các hoạt động gần đây.',
  })
  @ApiResponse({ status: 200, type: MasterDashboardDto })
  async getMasterDashboard(@Request() req): Promise<MasterDashboardDto> {
    return this.dashboardService.getMasterDashboard(req.user.id);
  }
}
