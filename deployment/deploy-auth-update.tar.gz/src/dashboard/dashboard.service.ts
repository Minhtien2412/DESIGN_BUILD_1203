import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    AdminDashboardDto,
    ClientDashboardDto,
    EngineerDashboardDto,
    MasterDashboardDto,
} from './dto';
// DISABLED: CRM requires separate Prisma client
// import { CrmService } from '../crm/crm.service';

@Injectable()
export class DashboardService {
  constructor(
    private prisma: PrismaService,
    // private crmService: CrmService, // DISABLED
  ) {}

  /**
   * ADMIN DASHBOARD
   * Tổng quan: Doanh thu, Dự án, Tiến độ, Lỗi, Nhân sự
   */
  async getAdminDashboard(userId: number): Promise<AdminDashboardDto> {
    // Kiểm tra role
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.role !== 'ADMIN') {
      throw new ForbiddenException('Only admin can access admin dashboard');
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

    // 1. Thống kê doanh thu
    const totalRevenue = await this.prisma.revenue.aggregate({
      _sum: { amount: true },
    });

    const thisMonthRevenue = await this.prisma.revenue.aggregate({
      where: { date: { gte: startOfMonth } },
      _sum: { amount: true },
    });

    const lastMonthRevenue = await this.prisma.revenue.aggregate({
      where: {
        date: {
          gte: startOfLastMonth,
          lte: endOfLastMonth,
        },
      },
      _sum: { amount: true },
    });

    const thisMonthAmount = Number(thisMonthRevenue._sum.amount || 0);
    const lastMonthAmount = Number(lastMonthRevenue._sum.amount || 0);
    const growth =
      lastMonthAmount > 0
        ? ((thisMonthAmount - lastMonthAmount) / lastMonthAmount) * 100
        : 0;

    // Doanh thu 6 tháng gần nhất
    const revenueByMonth = await this.getRevenueByMonth(6);

    // 2. Thống kê dự án
    const projectStats = await this.prisma.project.groupBy({
      by: ['status'],
      _count: true,
    });

    const projectStatsMap = projectStats.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const totalProjects = await this.prisma.project.count();

    // 3. Thống kê tiến độ
    const projects = await this.prisma.project.findMany({
      where: { status: 'IN_PROGRESS' },
      include: {
        tasks: true,
      },
    });

    const projectProgress = projects.map((project) => {
      const totalTasks = project.tasks.length;
      const completedTasks = project.tasks.filter(
        (t) => t.status === 'DONE',
      ).length;
      const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

      return {
        projectId: project.id,
        projectName: project.title,
        progress: Math.round(progress),
      };
    });

    const averageProgress =
      projectProgress.length > 0
        ? projectProgress.reduce((sum, p) => sum + p.progress, 0) /
          projectProgress.length
        : 0;

    const onTrack = projectProgress.filter((p) => p.progress >= 70).length;
    const delayed = projectProgress.filter((p) => p.progress < 70).length;

    // 4. Thống kê vấn đề (từ tasks và comments)
    const urgentTasks = await this.prisma.task.count({
      where: { priority: 'URGENT', status: { not: 'DONE' } },
    });

    const highPriorityTasks = await this.prisma.task.count({
      where: { priority: 'HIGH', status: { not: 'DONE' } },
    });

    const totalIssues = urgentTasks + highPriorityTasks;

    // Vấn đề gần đây
    const recentIssues = await this.prisma.task.findMany({
      where: {
        priority: { in: ['URGENT', 'HIGH'] },
        status: { not: 'DONE' },
      },
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        project: { select: { title: true } },
      },
    });

    // 5. Thống kê nhân sự & chấm công
    const totalStaff = await this.prisma.user.count({
      where: { role: { in: ['ENGINEER', 'ADMIN'] } },
    });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendanceToday = await this.prisma.attendance.groupBy({
      where: { date: { gte: today } },
      by: ['status'],
      _count: true,
    });

    const attendanceMap = attendanceToday.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const todayAttendanceDetails = await this.prisma.attendance.findMany({
      where: { date: { gte: today } },
      include: {
        user: { select: { id: true, name: true, role: true } },
        project: { select: { id: true, title: true } },
      },
      orderBy: { checkIn: 'asc' },
    });

    // Hoạt động gần đây
    const recentActivities = await this.prisma.timeline.findMany({
      take: 10,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true } },
        project: { select: { title: true } },
      },
    });

    return {
      revenue: {
        total: Number(totalRevenue._sum.amount || 0),
        thisMonth: thisMonthAmount,
        lastMonth: lastMonthAmount,
        growth: Math.round(growth * 10) / 10,
        byMonth: revenueByMonth,
      },
      projects: {
        total: totalProjects,
        inProgress: projectStatsMap.in_progress || 0,
        completed: projectStatsMap.completed || 0,
        planning: projectStatsMap.planning || 0,
        onHold: projectStatsMap.on_hold || 0,
        cancelled: projectStatsMap.cancelled || 0,
      },
      progress: {
        averageProgress: Math.round(averageProgress),
        onTrack,
        delayed,
        projectProgress,
      },
      issues: {
        total: totalIssues,
        critical: urgentTasks,
        pending: highPriorityTasks,
        resolved: 0, // Có thể tính từ DONE tasks
        recentIssues: recentIssues.map((issue) => ({
          id: issue.id,
          title: issue.title,
          priority: issue.priority,
          projectName: issue.project.title,
          createdAt: issue.createdAt,
        })),
      },
      attendance: {
        totalStaff,
        presentToday: attendanceMap.present || 0,
        absent: attendanceMap.absent || 0,
        late: attendanceMap.late || 0,
        onLeave: attendanceMap.leave || 0,
        todayAttendance: todayAttendanceDetails.map((att) => ({
          userId: att.userId,
          userName: att.user.name,
          status: att.status,
          checkIn: att.checkIn,
          checkOut: att.checkOut,
          projectName: att.project?.title,
        })),
      },
      recentActivities: recentActivities.map((act) => ({
        id: act.id,
        event: act.eventType,
        description: act.description,
        userName: act.user?.name || 'Unknown',
        projectName: act.project.title,
        createdAt: act.createdAt,
      })),
    };
  }

  /**
   * ENGINEER DASHBOARD
   * Dự án phân công, Task theo ngày, Checklist, Báo cáo hình/video
   */
  async getEngineerDashboard(userId: number): Promise<EngineerDashboardDto> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.role !== 'ENGINEER') {
      throw new ForbiddenException(
        'Only engineers can access engineer dashboard',
      );
    }

    // 1. Dự án được phân công
    const assignedProjects = await this.prisma.project.findMany({
      where: { engineerId: userId },
      include: {
        tasks: true,
        client: { select: { name: true } },
      },
    });

    const projectsData = assignedProjects.map((project) => {
      const totalTasks = project.tasks.length;
      const completedTasks = project.tasks.filter(
        (t) => t.status === 'DONE',
      ).length;
      const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

      return {
        id: project.id,
        title: project.title,
        status: project.status,
        progress: Math.round(progress),
        dueDate: project.endDate || undefined,
        tasksTotal: totalTasks,
        tasksCompleted: completedTasks,
        clientName: project.client?.name || undefined,
      };
    });

    // 2. Task hôm nay (dueDate = today hoặc IN_PROGRESS)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todayTasks = await this.prisma.task.findMany({
      where: {
        assigneeId: userId,
        OR: [
          { dueDate: { gte: today, lt: tomorrow } },
          { status: 'IN_PROGRESS' },
        ],
      },
      include: {
        project: { select: { title: true } },
      },
      orderBy: [{ priority: 'desc' }, { dueDate: 'asc' }],
    });

    const tasksData = todayTasks.map((task) => ({
      id: task.id,
      title: task.title,
      status: task.status,
      priority: task.priority,
      dueDate: task.dueDate || undefined,
      projectName: task.project.title,
      estimatedHours: undefined, // Có thể thêm field này vào Task model
    }));

    // 3. Checklist (tất cả tasks chưa hoàn thành)
    const checklist = await this.prisma.task.findMany({
      where: {
        assigneeId: userId,
        status: { not: 'DONE' },
      },
      orderBy: [{ priority: 'desc' }, { dueDate: 'asc' }],
      take: 20,
    });

    const checklistData = checklist.map((task) => ({
      id: task.id,
      title: task.title,
      completed: task.status === 'DONE',
      priority: task.priority,
      dueDate: task.dueDate || undefined,
    }));

    // 4. Báo cáo gần đây
    const recentReports = await this.prisma.dailyReport.findMany({
      where: { engineerId: userId },
      orderBy: { createdAt: 'desc' },
      take: 7,
      include: {
        project: { select: { title: true } },
      },
    });

    const reportsData = recentReports.map((report) => ({
      id: report.id,
      title: report.title,
      date: report.date,
      projectName: report.project.title,
      imageCount: report.imageUrls.length,
      videoCount: report.videoUrls.length,
    }));

    // 5. Thống kê
    const totalTasks = await this.prisma.task.count({
      where: { assigneeId: userId },
    });

    const completedTasks = await this.prisma.task.count({
      where: { assigneeId: userId, status: 'DONE' },
    });

    const pendingTasks = await this.prisma.task.count({
      where: { assigneeId: userId, status: { in: ['TODO', 'IN_PROGRESS'] } },
    });

    const todayCheckIns = await this.prisma.attendance.count({
      where: {
        userId,
        date: { gte: today },
      },
    });

    return {
      assignedProjects: projectsData,
      todayTasks: tasksData,
      checklist: checklistData,
      recentReports: reportsData,
      stats: {
        totalTasks,
        completedTasks,
        pendingTasks,
        todayCheckIns,
      },
    };
  }

  /**
   * CLIENT DASHBOARD
   * Tiến độ thực tế, Bản vẽ/Hợp đồng/Báo giá, Chat, Video call
   */
  async getClientDashboard(userId: number): Promise<ClientDashboardDto> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.role !== 'CLIENT') {
      throw new ForbiddenException('Only clients can access client dashboard');
    }

    // 1. Tiến độ dự án
    const projects = await this.prisma.project.findMany({
      where: { clientId: userId },
      include: {
        tasks: true,
        engineer: { select: { name: true } },
        payments: true,
        dailyReports: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });

    const projectProgressData = projects.map((project) => {
      const totalTasks = project.tasks.length;
      const completedTasks = project.tasks.filter(
        (t) => t.status === 'DONE',
      ).length;
      const actualProgress =
        totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

      // Tiến độ kế hoạch (theo thời gian)
      let plannedProgress = 0;
      if (project.startDate && project.endDate) {
        const now = new Date();
        const start = new Date(project.startDate);
        const end = new Date(project.endDate);
        const totalDuration = end.getTime() - start.getTime();
        const elapsed = now.getTime() - start.getTime();
        plannedProgress = Math.min(
          100,
          Math.max(0, (elapsed / totalDuration) * 100),
        );
      }

      const totalPaid = project.payments
        .filter((p) => p.status === 'COMPLETED')
        .reduce((sum, p) => sum + Number(p.amount), 0);

      const latestReport = project.dailyReports[0];

      return {
        id: project.id,
        title: project.title,
        status: project.status,
        actualProgress: Math.round(actualProgress),
        plannedProgress: Math.round(plannedProgress),
        startDate: project.startDate || undefined,
        endDate: project.endDate || undefined,
        engineerName: project.engineer?.name || undefined,
        budget: project.budget ? Number(project.budget) : undefined,
        spent: totalPaid,
        images: latestReport?.imageUrls || project.images || [],
      };
    });

    // 2. Tài liệu (bản vẽ, hợp đồng, báo giá)
    const documents = await this.prisma.document.findMany({
      where: {
        projectId: { in: projects.map((p) => p.id) },
        isPublic: true, // Chỉ khách hàng xem được documents public
      },
      include: {
        uploadedBy: { select: { name: true } },
        project: { select: { title: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    const documentsData = documents.map((doc) => ({
      id: doc.id,
      title: doc.title,
      type: doc.type,
      fileUrl: doc.fileUrl,
      fileName: doc.fileName,
      fileSize: doc.fileSize || undefined,
      version: doc.version || undefined,
      uploadedAt: doc.createdAt,
      uploadedByName: doc.uploadedBy.name || undefined,
    }));

    // 3. Tin nhắn chưa đọc
    const chatRooms = await this.prisma.chatRoomMember.findMany({
      where: { userId },
      select: { roomId: true },
    });

    const roomIds = chatRooms.map((r) => r.roomId);

    const unreadMessages = await this.prisma.chatMessage.findMany({
      where: {
        roomId: { in: roomIds },
        senderId: { not: userId },
        readStatus: {
          none: { userId },
        },
      },
      include: {
        sender: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    const messagesData = unreadMessages.map((msg) => ({
      id: msg.id,
      message: msg.content,
      senderName: msg.sender.name || 'Unknown',
      sentAt: msg.createdAt,
      isRead: false,
      roomId: msg.roomId,
    }));

    // 4. Trạng thái video call
    let videoCallStatus: any = {
      available: false,
    };

    if (projects.length > 0 && projects[0].engineer) {
      const engineerOnline = await this.checkEngineerOnline(
        projects[0].engineerId!,
      );
      const lastVideoRoom = await this.prisma.videoRoom.findFirst({
        where: { projectId: projects[0].id },
        orderBy: { createdAt: 'desc' },
      });

      videoCallStatus = {
        available: true,
        engineerName: projects[0].engineer.name,
        engineerOnline,
        lastCall: lastVideoRoom?.createdAt,
      };
    }

    // 5. Báo cáo gần đây
    const recentReports = await this.prisma.dailyReport.findMany({
      where: {
        projectId: { in: projects.map((p) => p.id) },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
      include: {
        project: { select: { title: true } },
        engineer: { select: { name: true } },
      },
    });

    const reportsData = recentReports.map((report) => ({
      id: report.id,
      title: report.title,
      date: report.date,
      projectName: report.project.title,
      engineerName: report.engineer.name,
      imageCount: report.imageUrls.length,
      videoCount: report.videoUrls.length,
      workDone: report.workDone,
    }));

    // 6. Thống kê
    const totalProjects = projects.length;
    const activeProjects = projects.filter(
      (p) => p.status === 'IN_PROGRESS',
    ).length;
    const completedProjects = projects.filter(
      (p) => p.status === 'COMPLETED',
    ).length;

    const totalBudget = projects.reduce(
      (sum, p) => sum + (p.budget ? Number(p.budget) : 0),
      0,
    );

    const totalSpent = projects.reduce((sum, project) => {
      const paid = project.payments
        .filter((p) => p.status === 'COMPLETED')
        .reduce((s, p) => s + Number(p.amount), 0);
      return sum + paid;
    }, 0);

    return {
      projectProgress: projectProgressData,
      documents: documentsData,
      unreadMessages: messagesData,
      videoCallStatus,
      recentReports: reportsData,
      stats: {
        totalProjects,
        activeProjects,
        completedProjects,
        totalSpent,
        totalBudget,
      },
    };
  }

  /**
   * Helper: Lấy doanh thu theo tháng
   */
  private async getRevenueByMonth(months: number) {
    const result: { month: string; amount: number }[] = [];
    const now = new Date();

    for (let i = months - 1; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

      const revenue = await this.prisma.revenue.aggregate({
        where: {
          date: {
            gte: date,
            lt: nextMonth,
          },
        },
        _sum: { amount: true },
      });

      const monthName = date.toLocaleDateString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
      });

      result.push({
        month: monthName,
        amount: Number(revenue._sum.amount || 0),
      });
    }

    return result;
  }

  /**
   * Helper: Kiểm tra engineer có online không
   */
  private async checkEngineerOnline(engineerId: number): Promise<boolean> {
    // Có thể tích hợp với Socket.IO để check real-time
    // Tạm thời return true
    return true;
  }

  /**
   * MASTER DASHBOARD
   * Tổng quan toàn bộ hệ thống - Quản lý TẤT CẢ modules
   * Admin + System Manager sử dụng
   */
  async getMasterDashboard(userId: number): Promise<MasterDashboardDto> {
    // Kiểm tra role - chỉ ADMIN được truy cập
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (user?.role !== 'ADMIN') {
      throw new ForbiddenException(
        'Only admin can access master dashboard',
      );
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());

    // =====================
    // 1. USERS
    // =====================
    const totalUsers = await this.prisma.user.count();
    const usersByRole = await this.prisma.user.groupBy({
      by: ['role'],
      _count: true,
    });

    const roleMap = usersByRole.reduce((acc, item) => {
      acc[item.role.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const newThisMonth = await this.prisma.user.count({
      where: { createdAt: { gte: startOfMonth } },
    });

    // Active today - users with activities (timeline, messages, attendance)
    const activeUserIds = new Set<number>();
    
    const todayTimeline = await this.prisma.timeline.findMany({
      where: { createdAt: { gte: today } },
      select: { userId: true },
    });
    todayTimeline.forEach((t) => {
      if (t.userId) activeUserIds.add(t.userId);
    });

    const todayAttendance = await this.prisma.attendance.findMany({
      where: { date: { gte: today } },
      select: { userId: true },
    });
    todayAttendance.forEach((a) => activeUserIds.add(a.userId));

    // =====================
    // 2. PROJECTS
    // =====================
    const totalProjects = await this.prisma.project.count();
    const projectsByStatus = await this.prisma.project.groupBy({
      by: ['status'],
      _count: true,
    });

    const projectStatsMap = projectsByStatus.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const completedProjects = projectStatsMap.completed || 0;
    const completionRate =
      totalProjects > 0 ? (completedProjects / totalProjects) * 100 : 0;

    // =====================
    // 3. TASKS
    // =====================
    const totalTasks = await this.prisma.task.count();
    const tasksByStatus = await this.prisma.task.groupBy({
      by: ['status'],
      _count: true,
    });

    const taskStatsMap = tasksByStatus.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const urgentTasks = await this.prisma.task.count({
      where: { priority: 'URGENT', status: { not: 'DONE' } },
    });

    const highTasks = await this.prisma.task.count({
      where: { priority: 'HIGH', status: { not: 'DONE' } },
    });

    const doneTasks = taskStatsMap.done || 0;
    const taskCompletionRate =
      totalTasks > 0 ? (doneTasks / totalTasks) * 100 : 0;

    // =====================
    // 4. PRODUCTS
    // =====================
    const totalProducts = await this.prisma.product.count();
    
    const inStock = await this.prisma.product.count({
      where: { stock: { gt: 0 } },
    });

    const outOfStock = await this.prisma.product.count({
      where: { stock: 0 },
    });

    const lowStock = await this.prisma.product.count({
      where: { stock: { gt: 0, lte: 10 } },
    });

    const productsValue = await this.prisma.product.aggregate({
      _sum: {
        price: true,
      },
    });

    const categories = await this.prisma.product.findMany({
      select: { category: true },
      distinct: ['category'],
    });

    // =====================
    // 5. PAYMENTS
    // =====================
    const totalRevenue = await this.prisma.payment.aggregate({
      where: { status: 'COMPLETED' },
      _sum: { amount: true },
    });

    const thisMonthRevenue = await this.prisma.payment.aggregate({
      where: {
        status: 'COMPLETED',
        createdAt: { gte: startOfMonth },
      },
      _sum: { amount: true },
    });

    const lastMonthRevenue = await this.prisma.payment.aggregate({
      where: {
        status: 'COMPLETED',
        createdAt: {
          gte: startOfLastMonth,
          lte: endOfLastMonth,
        },
      },
      _sum: { amount: true },
    });

    const pendingPayments = await this.prisma.payment.aggregate({
      where: { status: 'PENDING' },
      _sum: { amount: true },
    });

    const failedPayments = await this.prisma.payment.aggregate({
      where: { status: 'FAILED' },
      _sum: { amount: true },
    });

    const thisMonthAmount = Number(thisMonthRevenue._sum.amount || 0);
    const lastMonthAmount = Number(lastMonthRevenue._sum.amount || 0);
    const paymentGrowth =
      lastMonthAmount > 0
        ? ((thisMonthAmount - lastMonthAmount) / lastMonthAmount) * 100
        : 0;

    // =====================
    // 6. CRM (Perfex CRM) - DISABLED
    // =====================
    /* const crmClient = this.crmService.getCrmClient();
    
    const totalCrmClients = await crmClient.tblclients.count();
    
    const activeCrmClients = await crmClient.tblclients.count({
      where: { active: 1 },
    });

    const totalCrmProjects = await crmClient.tblprojects.count();
    
    const activeCrmProjects = await crmClient.tblprojects.count({
      where: {
        status: {
          in: [1, 2, 3], // 1=Not Started, 2=In Progress, 3=On Hold
        },
      },
    });

    const totalInvoices = await crmClient.tblinvoices.count();
    
    const paidInvoices = await crmClient.tblinvoices.count({
      where: { status: 2 }, // 2 = Paid
    });

    const unpaidInvoices = await crmClient.tblinvoices.count({
      where: { status: { not: 2 } },
    });

    const totalTickets = await crmClient.tbltickets.count();
    
    const openTickets = await crmClient.tbltickets.count({
      where: {
        status: {
          in: [1, 2], // 1=Open, 2=In Progress
        },
      },
    });

    const resolvedTickets = await crmClient.tbltickets.count({
      where: { status: 5 }, // 5=Closed
    });
    */ // END CRM DISABLED BLOCK

    // CRM data set to null while disabled
    const totalCrmClients = 0;
    const activeCrmClients = 0;
    const totalCrmProjects = 0;
    const activeCrmProjects = 0;
    const totalInvoices = 0;
    const paidInvoices = 0;
    const unpaidInvoices = 0;
    const totalTickets = 0;
    const openTickets = 0;
    const resolvedTickets = 0;

    // =====================
    // 7. AI
    // =====================
    const totalAiRequests =
      (await this.prisma.aIAnalysis.count()) +
      (await this.prisma.aIReport.count()) +
      (await this.prisma.aIChatHistory.count());

    const thisMonthAi =
      (await this.prisma.aIAnalysis.count({
        where: { createdAt: { gte: startOfMonth } },
      })) +
      (await this.prisma.aIReport.count({
        where: { createdAt: { gte: startOfMonth } },
      })) +
      (await this.prisma.aIChatHistory.count({
        where: { createdAt: { gte: startOfMonth } },
      }));

    // Top features - mock data (analysisType field doesn't exist in schema)
    const topFeatures = [
      { feature: 'Construction Analysis', count: 0 },
      { feature: 'Material Calculation', count: 0 },
      { feature: 'Cost Estimation', count: 0 },
    ];

    // Count AI types
    const aiAnalysisCount = await this.prisma.aIAnalysis.count();
    const aiReportCount = await this.prisma.aIReport.count();
    const aiChatCount = await this.prisma.aIChatHistory.count();
    
    if (aiAnalysisCount > 0) topFeatures[0].count = aiAnalysisCount;
    if (aiReportCount > 0) topFeatures[1].count = aiReportCount;
    if (aiChatCount > 0) topFeatures[2].count = aiChatCount;

    // =====================
    // 8. CHAT
    // =====================
    const totalRooms = await this.prisma.chatRoom.count();
    
    // ChatRoom doesn't have isActive field, assume all rooms are active
    const activeRooms = totalRooms;

    const totalMessages = await this.prisma.chatMessage.count();
    
    const todayMessages = await this.prisma.chatMessage.count({
      where: { createdAt: { gte: today } },
    });

    // Unread messages for all users
    const allUnreadMessages = await this.prisma.chatMessage.findMany({
      where: {
        readStatus: {
          none: {},
        },
      },
      select: { id: true },
    });

    // =====================
    // 9. VIDEO CALLS
    // =====================
    const totalCalls = await this.prisma.videoRoom.count();
    
    const thisMonthCalls = await this.prisma.videoRoom.count({
      where: { createdAt: { gte: startOfMonth } },
    });

    const callsWithDuration = await this.prisma.videoRoom.findMany({
      where: {
        startedAt: { not: undefined },
        endedAt: { not: undefined },
      },
      select: {
        startedAt: true,
        endedAt: true,
      },
    });

    let totalMinutes = 0;
    callsWithDuration.forEach((call) => {
      if (call.startedAt && call.endedAt) {
        const duration =
          (call.endedAt.getTime() - call.startedAt.getTime()) / 1000 / 60;
        totalMinutes += duration;
      }
    });

    const avgDuration =
      callsWithDuration.length > 0
        ? totalMinutes / callsWithDuration.length
        : 0;

    // =====================
    // 10. UPLOADS
    // =====================
    const totalFiles = await this.prisma.document.count();
    
    const filesThisMonth = await this.prisma.document.count({
      where: { createdAt: { gte: startOfMonth } },
    });

    const totalSize = await this.prisma.document.aggregate({
      _sum: { fileSize: true },
    });

    const filesByType = await this.prisma.document.groupBy({
      by: ['type'],
      _count: true,
    });

    const typeMap = filesByType.reduce((acc, item) => {
      const type = item.type.toLowerCase();
      if (type.includes('image') || type.includes('photo')) {
        acc.images = (acc.images || 0) + item._count;
      } else if (type.includes('video')) {
        acc.videos = (acc.videos || 0) + item._count;
      } else if (
        type.includes('doc') ||
        type.includes('pdf') ||
        type.includes('contract')
      ) {
        acc.documents = (acc.documents || 0) + item._count;
      } else {
        acc.others = (acc.others || 0) + item._count;
      }
      return acc;
    }, {} as any);

    // =====================
    // 11. ATTENDANCE
    // =====================
    const totalStaff = await this.prisma.user.count({
      where: { role: { in: ['ENGINEER', 'ADMIN'] } },
    });

    const attendanceToday = await this.prisma.attendance.groupBy({
      where: { date: { gte: today } },
      by: ['status'],
      _count: true,
    });

    const attendanceMap = attendanceToday.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    // Calculate average attendance rate for last 30 days
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(today.getDate() - 30);

    const last30DaysAttendance = await this.prisma.attendance.groupBy({
      where: {
        date: { gte: thirtyDaysAgo },
        status: 'PRESENT',
      },
      by: ['date'],
      _count: true,
    });

    const avgAttendanceRate =
      last30DaysAttendance.length > 0 && totalStaff > 0
        ? (last30DaysAttendance.reduce((sum, a) => sum + a._count, 0) /
            (30 * totalStaff)) *
          100
        : 0;

    // =====================
    // 12. CONTRACTS
    // =====================
    const totalContracts = await this.prisma.contract.count();
    
    const contractsByStatus = await this.prisma.contract.groupBy({
      by: ['status'],
      _count: true,
    });

    const contractStatsMap = contractsByStatus.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    // Contract doesn't have totalValue field, use contractValue instead
    const contractValue = await this.prisma.contract.aggregate({
      _sum: { contractValue: true },
    });

    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    const expiringThisMonth = await this.prisma.contract.count({
      where: {
        endDate: {
          gte: startOfMonth,
          lte: endOfMonth,
        },
        status: 'ACTIVE',
      },
    });

    // =====================
    // 13. TIMELINE
    // =====================
    const totalEvents = await this.prisma.timeline.count();
    
    const thisWeekEvents = await this.prisma.timeline.count({
      where: { createdAt: { gte: startOfWeek } },
    });

    const todayActivities = await this.prisma.timeline.count({
      where: { createdAt: { gte: today } },
    });

    // Upcoming milestones from TimelinePhase
    const upcomingMilestones = await this.prisma.timelinePhase.count({
      where: {
        endDate: { gte: now },
        status: { not: 'COMPLETED' },
      },
    });

    // =====================
    // 14. QC (Quality Control)
    // =====================
    const totalInspections = await this.prisma.qCInspection.count();
    
    const qcByStatus = await this.prisma.qCInspection.groupBy({
      by: ['status'],
      _count: true,
    });

    const qcStatsMap = qcByStatus.reduce((acc, item) => {
      acc[item.status.toLowerCase()] = item._count;
      return acc;
    }, {} as any);

    const passedQc = qcStatsMap.passed || 0;
    const passRate = totalInspections > 0 ? (passedQc / totalInspections) * 100 : 0;

    // =====================
    // 15. RECENT ACTIVITIES
    // =====================
    const recentActivities = await this.prisma.timeline.findMany({
      take: 20,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true } },
        project: { select: { title: true } },
      },
    });

    const activitiesData = recentActivities.map((act) => ({
      id: act.id,
      module: this.getModuleFromEventType(act.eventType),
      event: act.eventType,
      description: act.description || `${act.user?.name || 'Unknown'} - ${act.project?.title || 'Unknown'}`,
      createdAt: act.createdAt,
    }));

    // =====================
    // 16. SYSTEM ALERTS
    // =====================
    const systemAlerts: any[] = [];

    // Low stock alert
    if (lowStock > 0) {
      systemAlerts.push({
        type: 'warning',
        module: 'Products',
        message: `${lowStock} products have low stock (≤10 units)`,
        severity: 'medium',
      });
    }

    // Failed payments alert
    const failedCount = await this.prisma.payment.count({
      where: { status: 'FAILED' },
    });
    if (failedCount > 0) {
      systemAlerts.push({
        type: 'error',
        module: 'Payments',
        message: `${failedCount} payments failed`,
        severity: 'high',
      });
    }

    // Urgent tasks alert
    if (urgentTasks > 0) {
      systemAlerts.push({
        type: 'warning',
        module: 'Tasks',
        message: `${urgentTasks} urgent tasks pending`,
        severity: 'high',
      });
    }

    // Expiring contracts alert
    if (expiringThisMonth > 0) {
      systemAlerts.push({
        type: 'info',
        module: 'Contracts',
        message: `${expiringThisMonth} contracts expiring this month`,
        severity: 'medium',
      });
    }

    // Open tickets alert
    if (openTickets > 10) {
      systemAlerts.push({
        type: 'warning',
        module: 'CRM',
        message: `${openTickets} support tickets are open`,
        severity: 'medium',
      });
    }

    // =====================
    // 17. MONTHLY OVERVIEW (Last 6 months)
    // =====================
    const monthlyOverview = await this.getMonthlyOverview(6);

    // =====================
    // RETURN MASTER DASHBOARD
    // =====================
    return {
      users: {
        totalUsers,
        admins: roleMap.admin || 0,
        engineers: roleMap.engineer || 0,
        clients: roleMap.client || 0,
        activeToday: activeUserIds.size,
        newThisMonth,
      },
      projects: {
        total: totalProjects,
        planning: projectStatsMap.planning || 0,
        inProgress: projectStatsMap.in_progress || 0,
        completed: completedProjects,
        onHold: projectStatsMap.on_hold || 0,
        cancelled: projectStatsMap.cancelled || 0,
        completionRate: Math.round(completionRate * 10) / 10,
      },
      tasks: {
        total: totalTasks,
        todo: taskStatsMap.todo || 0,
        inProgress: taskStatsMap.in_progress || 0,
        done: doneTasks,
        urgent: urgentTasks,
        high: highTasks,
        completionRate: Math.round(taskCompletionRate * 10) / 10,
      },
      products: {
        totalProducts,
        inStock,
        outOfStock,
        lowStock,
        totalValue: Number(productsValue._sum.price || 0),
        categories: categories.length,
      },
      payments: {
        totalRevenue: Number(totalRevenue._sum.amount || 0),
        thisMonth: thisMonthAmount,
        lastMonth: lastMonthAmount,
        growth: Math.round(paymentGrowth * 10) / 10,
        pending: Number(pendingPayments._sum.amount || 0),
        completed: Number(totalRevenue._sum.amount || 0),
        failed: Number(failedPayments._sum.amount || 0),
      },
      crm: {
        totalClients: totalCrmClients,
        activeClients: activeCrmClients,
        totalProjects: totalCrmProjects,
        activeProjects: activeCrmProjects,
        totalInvoices,
        paidInvoices,
        unpaidInvoices,
        totalTickets,
        openTickets,
        resolvedTickets,
      },
      ai: {
        totalRequests: totalAiRequests,
        thisMonth: thisMonthAi,
        avgResponseTime: 2.3, // Mock - có thể tính từ AI logs
        successRate: 98.5, // Mock - có thể tính từ AI error reports
        topFeatures,
      },
      chat: {
        totalRooms,
        activeRooms,
        totalMessages,
        todayMessages,
        unreadMessages: allUnreadMessages.length,
      },
      video: {
        totalCalls,
        thisMonth: thisMonthCalls,
        avgDuration: Math.round(avgDuration * 10) / 10,
        totalMinutes: Math.round(totalMinutes),
      },
      uploads: {
        totalFiles,
        totalSize: Number(totalSize._sum.fileSize || 0),
        thisMonth: filesThisMonth,
        byType: {
          images: typeMap.images || 0,
          videos: typeMap.videos || 0,
          documents: typeMap.documents || 0,
          others: typeMap.others || 0,
        },
      },
      attendance: {
        totalStaff,
        presentToday: attendanceMap.present || 0,
        absent: attendanceMap.absent || 0,
        late: attendanceMap.late || 0,
        onLeave: attendanceMap.leave || 0,
        avgAttendanceRate: Math.round(avgAttendanceRate * 10) / 10,
      },
      contracts: {
        total: totalContracts,
        draft: contractStatsMap.draft || 0,
        active: contractStatsMap.active || 0,
        expired: contractStatsMap.expired || 0,
        totalValue: Number(contractValue._sum?.contractValue || 0),
        expiringThisMonth,
      },
      timeline: {
        totalEvents,
        thisWeek: thisWeekEvents,
        todayActivities,
        upcomingMilestones,
      },
      qc: {
        totalInspections,
        passed: passedQc,
        failed: qcStatsMap.failed || 0,
        pending: qcStatsMap.pending || 0,
        passRate: Math.round(passRate * 10) / 10,
      },
      recentActivities: activitiesData,
      systemAlerts,
      monthlyOverview,
    };
  }

  /**
   * Helper: Lấy module từ eventType
   */
  private getModuleFromEventType(eventType: string): string {
    const type = eventType.toLowerCase();
    if (type.includes('project')) return 'Projects';
    if (type.includes('task')) return 'Tasks';
    if (type.includes('payment')) return 'Payments';
    if (type.includes('contract')) return 'Contracts';
    if (type.includes('qc') || type.includes('quality')) return 'QC';
    if (type.includes('chat') || type.includes('message')) return 'Chat';
    if (type.includes('video') || type.includes('call')) return 'Video';
    if (type.includes('document') || type.includes('upload')) return 'Documents';
    if (type.includes('ai')) return 'AI';
    if (type.includes('attendance')) return 'Attendance';
    return 'System';
  }

  /**
   * Helper: Lấy overview theo tháng (Revenue, Projects, New Clients)
   */
  private async getMonthlyOverview(months: number) {
    const result: Array<{
      month: string;
      revenue: number;
      projects: number;
      newClients: number;
    }> = [];
    const now = new Date();

    for (let i = months - 1; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

      // Revenue from payments
      const revenue = await this.prisma.payment.aggregate({
        where: {
          status: 'COMPLETED',
          createdAt: {
            gte: date,
            lt: nextMonth,
          },
        },
        _sum: { amount: true },
      });

      // Projects created
      const projectsCount = await this.prisma.project.count({
        where: {
          createdAt: {
            gte: date,
            lt: nextMonth,
          },
        },
      });

      // New clients (users with role CLIENT)
      const newClientsCount = await this.prisma.user.count({
        where: {
          role: 'CLIENT',
          createdAt: {
            gte: date,
            lt: nextMonth,
          },
        },
      });

      // Plus CRM clients - DISABLED
      // const crmClient = this.crmService.getCrmClient();
      // const newCrmClients = await crmClient.tblclients.count({
      //   where: {
      //     datecreated: {
      //       gte: date,
      //       lt: nextMonth,
      //     },
      //   },
      // });
      const newCrmClients = 0; // CRM disabled

      const monthName = date.toLocaleDateString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
      });

      result.push({
        month: monthName,
        revenue: Number(revenue._sum.amount || 0),
        projects: projectsCount,
        newClients: newClientsCount + newCrmClients,
      });
    }

    return result;
  }
}
