import {
    Injectable,
    NotFoundException
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreatePhaseDto,
    ReorderPhasesDto,
    TimelineUpdateTaskDto,
    UpdatePhaseDto,
    UpdateProgressDto,
} from './dto';

@Injectable()
export class TimelineService {
  constructor(private prisma: PrismaService) {}

  /**
   * Tạo phase mới cho timeline
   */
  async createPhase(dto: CreatePhaseDto) {
    const phase = await this.prisma.timelinePhase.create({
      data: {
        name: dto.name,
        description: dto.description,
        projectId: dto.projectId,
        order: dto.order,
        startDate: new Date(dto.startDate),
        endDate: new Date(dto.endDate),
        color: dto.color || '#3B82F6',
        icon: dto.icon,
        notes: dto.notes,
        tasks: dto.tasks
          ? {
              create: dto.tasks.map((task, index) => ({
                name: task.name,
                description: task.description,
                isCompleted: task.isCompleted || false,
                order: task.order || index + 1,
                dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
                assignee: task.assignee,
                notes: task.notes,
              })),
            }
          : undefined,
      },
      include: {
        tasks: {
          orderBy: { order: 'asc' },
        },
      },
    });

    return phase;
  }

  /**
   * Lấy tất cả phases của project (Gantt Chart)
   */
  async getProjectTimeline(projectId: number) {
    const phases = await this.prisma.timelinePhase.findMany({
      where: { projectId },
      include: {
        tasks: {
          orderBy: { order: 'asc' },
        },
        progressUpdates: {
          orderBy: { createdAt: 'desc' },
          take: 5, // Lấy 5 updates gần nhất
        },
      },
      orderBy: { order: 'asc' },
    });

    // Tính toán tổng tiến độ project
    const overallProgress =
      phases.length > 0
        ? phases.reduce((sum, phase) => sum + Number(phase.progress), 0) /
          phases.length
        : 0;

    return {
      phases,
      overallProgress: Math.round(overallProgress * 10) / 10, // Round to 1 decimal
      totalPhases: phases.length,
      completedPhases: phases.filter((p) => p.status === 'COMPLETED').length,
      inProgressPhases: phases.filter((p) => p.status === 'IN_PROGRESS').length,
    };
  }

  /**
   * Lấy chi tiết phase
   */
  async getPhaseById(id: number) {
    const phase = await this.prisma.timelinePhase.findUnique({
      where: { id },
      include: {
        tasks: {
          orderBy: { order: 'asc' },
        },
        progressUpdates: {
          orderBy: { createdAt: 'desc' },
        },
        project: {
          select: { id: true, title: true },
        },
      },
    });

    if (!phase) {
      throw new NotFoundException('Phase not found');
    }

    return phase;
  }

  /**
   * Cập nhật phase
   */
  async updatePhase(id: number, dto: UpdatePhaseDto) {
    const existing = await this.getPhaseById(id);

    // Kiểm tra nếu status thay đổi
    const statusChanged = dto.status && dto.status !== existing.status;

    const updated = await this.prisma.timelinePhase.update({
      where: { id },
      data: {
        name: dto.name,
        description: dto.description,
        status: dto.status as any,
        order: dto.order,
        startDate: dto.startDate ? new Date(dto.startDate) : undefined,
        endDate: dto.endDate ? new Date(dto.endDate) : undefined,
        actualStartDate: dto.actualStartDate
          ? new Date(dto.actualStartDate)
          : undefined,
        actualEndDate: dto.actualEndDate
          ? new Date(dto.actualEndDate)
          : undefined,
        progress: dto.progress,
        color: dto.color,
        icon: dto.icon,
        notes: dto.notes,
      },
      include: {
        tasks: true,
      },
    });

    // Nếu status thay đổi → tạo notification
    if (statusChanged) {
      await this.createNotification(existing.projectId, {
        type: dto.status === 'COMPLETED' ? 'PHASE_COMPLETED' : 'PHASE_STARTED',
        title: `Phase "${updated.name}" ${dto.status === 'COMPLETED' ? 'đã hoàn thành' : 'đã bắt đầu'}`,
        message: `Giai đoạn "${updated.name}" đã chuyển sang trạng thái: ${dto.status}`,
        phaseId: id,
        metadata: {
          phaseId: id,
          status: dto.status,
          progress: updated.progress,
        },
      });
    }

    return updated;
  }

  /**
   * Drag & Drop: Reorder phases
   */
  async reorderPhases(projectId: number, dto: ReorderPhasesDto) {
    // Update order cho từng phase
    const updates = dto.phases.map((item) =>
      this.prisma.timelinePhase.update({
        where: { id: item.phaseId },
        data: { order: item.newOrder },
      }),
    );

    await this.prisma.$transaction(updates);

    // Tạo notification
    await this.createNotification(projectId, {
      type: 'TIMELINE_REORDERED',
      title: 'Timeline đã được sắp xếp lại',
      message: `Thứ tự các giai đoạn đã được thay đổi`,
      metadata: { phases: dto.phases },
    });

    return this.getProjectTimeline(projectId);
  }

  /**
   * Cập nhật tiến độ phase (realtime progress)
   */
  async updateProgress(phaseId: number, dto: UpdateProgressDto) {
    const phase = await this.getPhaseById(phaseId);

    // Lưu progress update history
    const progressUpdate = await this.prisma.phaseProgressUpdate.create({
      data: {
        phaseId,
        oldProgress: Number(phase.progress),
        newProgress: dto.newProgress,
        notes: dto.notes,
        imageUrls: dto.imageUrls || [],
        videoUrls: dto.videoUrls || [],
        updatedBy: dto.updatedBy,
      },
    });

    // Cập nhật progress của phase
    const updated = await this.prisma.timelinePhase.update({
      where: { id: phaseId },
      data: {
        progress: dto.newProgress,
        status:
          dto.newProgress === 100
            ? 'COMPLETED'
            : dto.newProgress > 0
              ? 'IN_PROGRESS'
              : 'NOT_STARTED',
        actualStartDate:
          dto.newProgress > 0 && !phase.actualStartDate
            ? new Date()
            : phase.actualStartDate,
        actualEndDate: dto.newProgress === 100 ? new Date() : undefined,
      },
    });

    // Gửi notification cho khách hàng (nếu được yêu cầu)
    if (dto.sendNotification !== false) {
      await this.createNotification(phase.projectId, {
        type: 'PROGRESS_UPDATE',
        title: `Tiến độ "${phase.name}" cập nhật: ${dto.newProgress}%`,
        message:
          dto.notes ||
          `Tiến độ giai đoạn "${phase.name}" đã đạt ${dto.newProgress}%`,
        phaseId,
        metadata: {
          phaseId,
          oldProgress: Number(phase.progress),
          newProgress: dto.newProgress,
          imageUrls: dto.imageUrls,
          videoUrls: dto.videoUrls,
        },
      });
    }

    return {
      phase: updated,
      progressUpdate,
    };
  }

  /**
   * Tạo task cho phase
   */
  async createPhaseTask(phaseId: number, task: any) {
    const phase = await this.getPhaseById(phaseId);

    const maxOrder = await this.prisma.phaseTask.findFirst({
      where: { phaseId },
      orderBy: { order: 'desc' },
      select: { order: true },
    });

    return this.prisma.phaseTask.create({
      data: {
        phaseId,
        name: task.name,
        description: task.description,
        isCompleted: task.isCompleted || false,
        order: task.order || (maxOrder ? maxOrder.order + 1 : 1),
        dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
        assignee: task.assignee,
        notes: task.notes,
      },
    });
  }

  /**
   * Cập nhật task
   */
  async updatePhaseTask(taskId: number, dto: TimelineUpdateTaskDto) {
    const task = await this.prisma.phaseTask.findUnique({
      where: { id: taskId },
      include: { phase: true },
    });

    if (!task) {
      throw new NotFoundException('Task not found');
    }

    const updated = await this.prisma.phaseTask.update({
      where: { id: taskId },
      data: {
        name: dto.name,
        description: dto.description,
        isCompleted: dto.isCompleted,
        order: dto.order,
        dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
        assignee: dto.assignee,
        notes: dto.notes,
        completedAt:
          dto.isCompleted === true && !task.completedAt
            ? new Date()
            : undefined,
      },
    });

    // Auto-update phase progress dựa trên tasks
    if (dto.isCompleted !== undefined) {
      await this.recalculatePhaseProgress(task.phaseId);
    }

    return updated;
  }

  /**
   * Xóa task
   */
  async deletePhaseTask(taskId: number) {
    const task = await this.prisma.phaseTask.findUnique({
      where: { id: taskId },
    });

    if (!task) {
      throw new NotFoundException('Task not found');
    }

    await this.prisma.phaseTask.delete({
      where: { id: taskId },
    });

    // Recalculate phase progress
    await this.recalculatePhaseProgress(task.phaseId);

    return { success: true };
  }

  /**
   * Tự động tính lại tiến độ phase dựa trên tasks
   */
  private async recalculatePhaseProgress(phaseId: number) {
    const tasks = await this.prisma.phaseTask.findMany({
      where: { phaseId },
    });

    if (tasks.length === 0) return;

    const completedTasks = tasks.filter((t) => t.isCompleted).length;
    const progress = (completedTasks / tasks.length) * 100;

    await this.prisma.timelinePhase.update({
      where: { id: phaseId },
      data: {
        progress: Math.round(progress * 10) / 10,
        status:
          progress === 100
            ? 'COMPLETED'
            : progress > 0
              ? 'IN_PROGRESS'
              : 'NOT_STARTED',
      },
    });
  }

  /**
   * Lấy notifications cho project
   */
  async getProjectNotifications(projectId: number, unreadOnly = false) {
    return this.prisma.phaseNotification.findMany({
      where: {
        projectId,
        ...(unreadOnly && { isRead: false }),
      },
      include: {
        phase: {
          select: { id: true, name: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  /**
   * Đánh dấu notifications đã đọc
   */
  async markNotificationsAsRead(notificationIds: number[]) {
    await this.prisma.phaseNotification.updateMany({
      where: { id: { in: notificationIds } },
      data: { isRead: true },
    });

    return { success: true, count: notificationIds.length };
  }

  /**
   * Tạo notification (internal method)
   */
  private async createNotification(
    projectId: number,
    data: {
      type: string;
      title: string;
      message: string;
      phaseId?: number;
      metadata?: any;
    },
  ) {
    return this.prisma.phaseNotification.create({
      data: {
        projectId,
        phaseId: data.phaseId,
        type: data.type as any,
        title: data.title,
        message: data.message,
        metadata: data.metadata,
      },
    });
  }

  /**
   * Xóa phase
   */
  async deletePhase(id: number) {
    await this.prisma.timelinePhase.delete({
      where: { id },
    });

    return { success: true };
  }

  /**
   * Check phase delayed (quá hạn)
   */
  async checkDelayedPhases(projectId: number) {
    const now = new Date();
    const phases = await this.prisma.timelinePhase.findMany({
      where: {
        projectId,
        status: { in: ['NOT_STARTED', 'IN_PROGRESS'] },
        endDate: { lt: now },
      },
    });

    // Update status to DELAYED
    const updates = phases.map((phase) =>
      this.prisma.timelinePhase.update({
        where: { id: phase.id },
        data: { status: 'DELAYED' },
      }),
    );

    await this.prisma.$transaction(updates);

    // Create notifications
    for (const phase of phases) {
      await this.createNotification(projectId, {
        type: 'PHASE_DELAYED',
        title: `Giai đoạn "${phase.name}" bị trễ hạn`,
        message: `Giai đoạn "${phase.name}" đã quá thời gian dự kiến (${phase.endDate.toLocaleDateString('vi-VN')})`,
        phaseId: phase.id,
        metadata: { phaseId: phase.id, endDate: phase.endDate },
      });
    }

    return { delayedPhases: phases.length };
  }
}
