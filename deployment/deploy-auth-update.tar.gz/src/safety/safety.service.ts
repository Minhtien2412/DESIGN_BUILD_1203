import { Injectable, NotFoundException } from '@nestjs/common';
import {
    AddFindingDto,
    CreateAuditDto,
    CreateIncidentDto,
    CreateTrainingDto,
    DistributePPEDto,
    QueryAuditDto,
    QueryIncidentDto,
    RecordAttendanceDto,
    ReturnPPEDto,
    UpdateAuditDto,
    UpdateIncidentDto,
    UpdateTrainingDto,
} from './dto';
import {
    AuditFinding,
    AuditStatus,
    AuditType,
    IncidentSeverity,
    IncidentStatus,
    PPEDistribution,
    PPEType,
    SafetyAudit,
    SafetyDashboard,
    SafetyIncident,
    SafetyTraining,
    TrainingAttendee,
    TrainingStatus,
} from './entities';

@Injectable()
export class SafetyService {
  private audits: Map<number, SafetyAudit> = new Map();
  private incidents: Map<number, SafetyIncident> = new Map();
  private ppeDistributions: Map<number, PPEDistribution> = new Map();
  private trainings: Map<number, SafetyTraining> = new Map();

  private auditIdCounter = 1;
  private incidentIdCounter = 1;
  private ppeIdCounter = 1;
  private trainingIdCounter = 1;
  private findingIdCounter = 1;

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const now = new Date();

    // Sample audits
    const auditors = [
      { id: 1, name: 'Nguyễn Văn An' },
      { id: 2, name: 'Trần Thị Bình' },
    ];

    for (let i = 0; i < 5; i++) {
      const auditor = auditors[i % auditors.length];
      const audit: SafetyAudit = {
        id: this.auditIdCounter++,
        title: `Kiểm tra an toàn định kỳ ${i + 1}`,
        description: `Đợt kiểm tra an toàn lao động tại công trường`,
        projectId: (i % 3) + 1,
        auditorId: auditor.id,
        auditorName: auditor.name,
        auditType: Object.values(AuditType)[i % 5],
        status: Object.values(AuditStatus)[i % 4],
        scheduledDate: new Date(
          now.getTime() + (i - 2) * 7 * 24 * 60 * 60 * 1000,
        ),
        completedDate: i < 3 ? new Date() : undefined,
        findings: [],
        score: i < 3 ? 80 + Math.floor(Math.random() * 20) : undefined,
        maxScore: 100,
        recommendations: [
          'Tăng cường kiểm tra PPE',
          'Đào tạo thêm về an toàn điện',
        ],
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      if (i < 3) {
        audit.findings = [
          {
            id: this.findingIdCounter++,
            category: 'PPE',
            description: 'Một số công nhân thiếu mũ bảo hộ',
            severity: IncidentSeverity.MEDIUM,
            correctiveAction: 'Cấp phát mũ bảo hộ mới',
            deadline: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
            resolved: i === 0,
            resolvedDate: i === 0 ? new Date() : undefined,
          },
        ];
      }

      this.audits.set(audit.id, audit);
    }

    // Sample incidents
    const reporters = [
      { id: 3, name: 'Lê Văn Cường' },
      { id: 4, name: 'Phạm Thị Dung' },
    ];

    for (let i = 0; i < 4; i++) {
      const reporter = reporters[i % reporters.length];
      const incident: SafetyIncident = {
        id: this.incidentIdCounter++,
        title: `Sự cố ${i + 1}`,
        description: `Mô tả chi tiết về sự cố an toàn lao động`,
        projectId: (i % 3) + 1,
        location: `Tầng ${i + 1}, khu vực ${String.fromCharCode(65 + i)}`,
        incidentDate: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
        reportedBy: reporter.id,
        reportedByName: reporter.name,
        severity: Object.values(IncidentSeverity)[i % 4],
        status: Object.values(IncidentStatus)[i % 4],
        injuriesCount: i < 2 ? 0 : 1,
        injuryDetails: i >= 2 ? 'Trầy xước nhẹ' : undefined,
        witnesses: ['Nguyễn Văn X', 'Trần Văn Y'],
        rootCause: i > 0 ? 'Thiếu cảnh báo an toàn' : undefined,
        correctiveActions: i > 0 ? ['Lắp thêm biển cảnh báo'] : undefined,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.incidents.set(incident.id, incident);
    }

    // Sample PPE distributions
    const workers = [
      { id: 5, name: 'Hoàng Văn Em' },
      { id: 6, name: 'Vũ Thị Phương' },
      { id: 7, name: 'Đặng Văn Giang' },
    ];

    const ppeTypes = Object.values(PPEType);
    for (let i = 0; i < 10; i++) {
      const worker = workers[i % workers.length];
      const ppe: PPEDistribution = {
        id: this.ppeIdCounter++,
        workerId: worker.id,
        workerName: worker.name,
        projectId: (i % 3) + 1,
        ppeType: ppeTypes[i % ppeTypes.length],
        quantity: 1 + Math.floor(Math.random() * 3),
        distributedDate: new Date(now.getTime() - i * 3 * 24 * 60 * 60 * 1000),
        distributedBy: 1,
        expiryDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000),
        condition: 'new',
        createdAt: new Date(),
      };
      this.ppeDistributions.set(ppe.id, ppe);
    }

    // Sample trainings
    const trainers = [
      { id: 8, name: 'TS. Nguyễn Văn Hùng' },
      { id: 9, name: 'ThS. Lê Thị Hoa' },
    ];

    const trainingTypes = [
      'An toàn điện',
      'Làm việc trên cao',
      'Phòng cháy chữa cháy',
      'Sơ cấp cứu',
    ];
    for (let i = 0; i < 4; i++) {
      const trainer = trainers[i % trainers.length];
      const training: SafetyTraining = {
        id: this.trainingIdCounter++,
        title: `Khóa đào tạo: ${trainingTypes[i]}`,
        description: `Chương trình đào tạo ${trainingTypes[i]} cho công nhân`,
        projectId: i < 3 ? (i % 3) + 1 : undefined,
        trainerId: trainer.id,
        trainerName: trainer.name,
        trainingType: trainingTypes[i],
        status: Object.values(TrainingStatus)[i % 4],
        scheduledDate: new Date(
          now.getTime() + (i - 1) * 7 * 24 * 60 * 60 * 1000,
        ),
        completedDate: i === 0 ? new Date() : undefined,
        duration: 4 + i * 2,
        attendees: workers.map((w) => ({
          workerId: w.id,
          workerName: w.name,
          attended: i === 0,
          score: i === 0 ? 75 + Math.floor(Math.random() * 25) : undefined,
          certified: i === 0 && Math.random() > 0.3,
          certificationExpiry:
            i === 0
              ? new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
              : undefined,
        })),
        materials: ['Slide bài giảng', 'Video hướng dẫn', 'Tài liệu tham khảo'],
        passingScore: 70,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.trainings.set(training.id, training);
    }
  }

  // ========== DASHBOARD ==========

  async getDashboard(projectId?: number): Promise<SafetyDashboard> {
    let audits = Array.from(this.audits.values());
    let incidents = Array.from(this.incidents.values());
    let ppes = Array.from(this.ppeDistributions.values());
    let trainings = Array.from(this.trainings.values());

    if (projectId) {
      audits = audits.filter((a) => a.projectId === projectId);
      incidents = incidents.filter((i) => i.projectId === projectId);
      ppes = ppes.filter((p) => p.projectId === projectId);
      trainings = trainings.filter((t) => t.projectId === projectId);
    }

    const completedAudits = audits.filter(
      (a) => a.status === AuditStatus.COMPLETED,
    );
    const scores = completedAudits.filter((a) => a.score).map((a) => a.score!);
    const avgScore =
      scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

    const incidentsBySeverity = Object.values(IncidentSeverity).reduce(
      (acc, sev) => {
        acc[sev] = incidents.filter((i) => i.severity === sev).length;
        return acc;
      },
      {} as Record<IncidentSeverity, number>,
    );

    const ppeByType = Object.values(PPEType).reduce(
      (acc, type) => {
        acc[type] = ppes
          .filter((p) => p.ppeType === type)
          .reduce((sum, p) => sum + p.quantity, 0);
        return acc;
      },
      {} as Record<PPEType, number>,
    );

    const completedTrainings = trainings.filter(
      (t) => t.status === TrainingStatus.COMPLETED,
    );
    const certifiedWorkers = new Set(
      completedTrainings.flatMap((t) =>
        t.attendees.filter((a) => a.certified).map((a) => a.workerId),
      ),
    ).size;

    return {
      totalAudits: audits.length,
      completedAudits: completedAudits.length,
      averageScore: Math.round(avgScore * 10) / 10,
      totalIncidents: incidents.length,
      openIncidents: incidents.filter(
        (i) =>
          i.status !== IncidentStatus.CLOSED &&
          i.status !== IncidentStatus.RESOLVED,
      ).length,
      incidentsBySeverity,
      totalPPEDistributed: ppes.reduce((sum, p) => sum + p.quantity, 0),
      ppeByType,
      totalTrainings: trainings.length,
      completedTrainings: completedTrainings.length,
      certifiedWorkers,
    };
  }

  // ========== AUDITS ==========

  async getAudits(query: QueryAuditDto): Promise<SafetyAudit[]> {
    let audits = Array.from(this.audits.values());

    if (query.projectId) {
      audits = audits.filter((a) => a.projectId === query.projectId);
    }
    if (query.status) {
      audits = audits.filter((a) => a.status === query.status);
    }
    if (query.auditType) {
      audits = audits.filter((a) => a.auditType === query.auditType);
    }
    if (query.fromDate) {
      const from = new Date(query.fromDate);
      audits = audits.filter((a) => a.scheduledDate >= from);
    }
    if (query.toDate) {
      const to = new Date(query.toDate);
      audits = audits.filter((a) => a.scheduledDate <= to);
    }

    return audits.sort(
      (a, b) => b.scheduledDate.getTime() - a.scheduledDate.getTime(),
    );
  }

  async getAuditById(id: number): Promise<SafetyAudit> {
    const audit = this.audits.get(id);
    if (!audit) throw new NotFoundException(`Audit ${id} not found`);
    return audit;
  }

  async createAudit(dto: CreateAuditDto): Promise<SafetyAudit> {
    const audit: SafetyAudit = {
      id: this.auditIdCounter++,
      title: dto.title,
      description: dto.description,
      projectId: dto.projectId,
      auditorId: dto.auditorId,
      auditorName: `Auditor ${dto.auditorId}`,
      auditType: dto.auditType,
      status: AuditStatus.SCHEDULED,
      scheduledDate: new Date(dto.scheduledDate),
      findings: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.audits.set(audit.id, audit);
    return audit;
  }

  async updateAudit(id: number, dto: UpdateAuditDto): Promise<SafetyAudit> {
    const audit = await this.getAuditById(id);

    if (dto.title) audit.title = dto.title;
    if (dto.description) audit.description = dto.description;
    if (dto.status) audit.status = dto.status;
    if (dto.scheduledDate) audit.scheduledDate = new Date(dto.scheduledDate);
    if (dto.completedDate) audit.completedDate = new Date(dto.completedDate);
    if (dto.score !== undefined) audit.score = dto.score;
    if (dto.maxScore !== undefined) audit.maxScore = dto.maxScore;
    if (dto.recommendations) audit.recommendations = dto.recommendations;

    audit.updatedAt = new Date();
    this.audits.set(id, audit);
    return audit;
  }

  async addFinding(auditId: number, dto: AddFindingDto): Promise<AuditFinding> {
    const audit = await this.getAuditById(auditId);

    const finding: AuditFinding = {
      id: this.findingIdCounter++,
      category: dto.category,
      description: dto.description,
      severity: dto.severity,
      correctiveAction: dto.correctiveAction,
      deadline: dto.deadline ? new Date(dto.deadline) : undefined,
      resolved: false,
    };

    audit.findings.push(finding);
    audit.updatedAt = new Date();
    this.audits.set(auditId, audit);
    return finding;
  }

  async resolveFinding(
    auditId: number,
    findingId: number,
  ): Promise<AuditFinding> {
    const audit = await this.getAuditById(auditId);
    const finding = audit.findings.find((f) => f.id === findingId);
    if (!finding) throw new NotFoundException(`Finding ${findingId} not found`);

    finding.resolved = true;
    finding.resolvedDate = new Date();
    audit.updatedAt = new Date();
    this.audits.set(auditId, audit);
    return finding;
  }

  // ========== INCIDENTS ==========

  async getIncidents(query: QueryIncidentDto): Promise<SafetyIncident[]> {
    let incidents = Array.from(this.incidents.values());

    if (query.projectId) {
      incidents = incidents.filter((i) => i.projectId === query.projectId);
    }
    if (query.status) {
      incidents = incidents.filter((i) => i.status === query.status);
    }
    if (query.severity) {
      incidents = incidents.filter((i) => i.severity === query.severity);
    }
    if (query.fromDate) {
      const from = new Date(query.fromDate);
      incidents = incidents.filter((i) => i.incidentDate >= from);
    }
    if (query.toDate) {
      const to = new Date(query.toDate);
      incidents = incidents.filter((i) => i.incidentDate <= to);
    }

    return incidents.sort(
      (a, b) => b.incidentDate.getTime() - a.incidentDate.getTime(),
    );
  }

  async getIncidentById(id: number): Promise<SafetyIncident> {
    const incident = this.incidents.get(id);
    if (!incident) throw new NotFoundException(`Incident ${id} not found`);
    return incident;
  }

  async createIncident(dto: CreateIncidentDto): Promise<SafetyIncident> {
    const incident: SafetyIncident = {
      id: this.incidentIdCounter++,
      title: dto.title,
      description: dto.description,
      projectId: dto.projectId,
      location: dto.location,
      incidentDate: new Date(dto.incidentDate),
      reportedBy: dto.reportedBy,
      reportedByName: `Reporter ${dto.reportedBy}`,
      severity: dto.severity,
      status: IncidentStatus.REPORTED,
      injuriesCount: dto.injuriesCount || 0,
      injuryDetails: dto.injuryDetails,
      witnesses: dto.witnesses,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.incidents.set(incident.id, incident);
    return incident;
  }

  async updateIncident(
    id: number,
    dto: UpdateIncidentDto,
  ): Promise<SafetyIncident> {
    const incident = await this.getIncidentById(id);

    if (dto.title) incident.title = dto.title;
    if (dto.description) incident.description = dto.description;
    if (dto.status) incident.status = dto.status;
    if (dto.investigatorId) incident.investigatorId = dto.investigatorId;
    if (dto.rootCause) incident.rootCause = dto.rootCause;
    if (dto.correctiveActions)
      incident.correctiveActions = dto.correctiveActions;
    if (dto.preventiveMeasures)
      incident.preventiveMeasures = dto.preventiveMeasures;
    if (dto.investigationNotes)
      incident.investigationNotes = dto.investigationNotes;

    if (
      dto.status === IncidentStatus.CLOSED ||
      dto.status === IncidentStatus.RESOLVED
    ) {
      incident.closedDate = new Date();
    }

    incident.updatedAt = new Date();
    this.incidents.set(id, incident);
    return incident;
  }

  // ========== PPE ==========

  async getPPEDistributions(
    projectId?: number,
    workerId?: number,
  ): Promise<PPEDistribution[]> {
    let ppes = Array.from(this.ppeDistributions.values());

    if (projectId) {
      ppes = ppes.filter((p) => p.projectId === projectId);
    }
    if (workerId) {
      ppes = ppes.filter((p) => p.workerId === workerId);
    }

    return ppes.sort(
      (a, b) => b.distributedDate.getTime() - a.distributedDate.getTime(),
    );
  }

  async distributePPE(dto: DistributePPEDto): Promise<PPEDistribution> {
    const ppe: PPEDistribution = {
      id: this.ppeIdCounter++,
      workerId: dto.workerId,
      workerName: `Worker ${dto.workerId}`,
      projectId: dto.projectId,
      ppeType: dto.ppeType,
      quantity: dto.quantity,
      distributedDate: new Date(),
      distributedBy: dto.distributedBy,
      expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
      condition: 'new',
      notes: dto.notes,
      createdAt: new Date(),
    };
    this.ppeDistributions.set(ppe.id, ppe);
    return ppe;
  }

  async returnPPE(id: number, dto: ReturnPPEDto): Promise<PPEDistribution> {
    const ppe = this.ppeDistributions.get(id);
    if (!ppe) throw new NotFoundException(`PPE distribution ${id} not found`);

    ppe.returnDate = new Date(dto.returnDate);
    ppe.condition = dto.condition;
    if (dto.notes) ppe.notes = dto.notes;

    this.ppeDistributions.set(id, ppe);
    return ppe;
  }

  // ========== TRAININGS ==========

  async getTrainings(
    projectId?: number,
    status?: TrainingStatus,
  ): Promise<SafetyTraining[]> {
    let trainings = Array.from(this.trainings.values());

    if (projectId) {
      trainings = trainings.filter((t) => t.projectId === projectId);
    }
    if (status) {
      trainings = trainings.filter((t) => t.status === status);
    }

    return trainings.sort(
      (a, b) => b.scheduledDate.getTime() - a.scheduledDate.getTime(),
    );
  }

  async getTrainingById(id: number): Promise<SafetyTraining> {
    const training = this.trainings.get(id);
    if (!training) throw new NotFoundException(`Training ${id} not found`);
    return training;
  }

  async createTraining(dto: CreateTrainingDto): Promise<SafetyTraining> {
    const training: SafetyTraining = {
      id: this.trainingIdCounter++,
      title: dto.title,
      description: dto.description,
      projectId: dto.projectId,
      trainerId: dto.trainerId,
      trainerName: `Trainer ${dto.trainerId}`,
      trainingType: dto.trainingType,
      status: TrainingStatus.SCHEDULED,
      scheduledDate: new Date(dto.scheduledDate),
      duration: dto.duration,
      attendees: (dto.attendeeIds || []).map((id) => ({
        workerId: id,
        workerName: `Worker ${id}`,
        attended: false,
        certified: false,
      })),
      passingScore: dto.passingScore,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.trainings.set(training.id, training);
    return training;
  }

  async updateTraining(
    id: number,
    dto: UpdateTrainingDto,
  ): Promise<SafetyTraining> {
    const training = await this.getTrainingById(id);

    if (dto.title) training.title = dto.title;
    if (dto.description) training.description = dto.description;
    if (dto.status) training.status = dto.status;
    if (dto.scheduledDate) training.scheduledDate = new Date(dto.scheduledDate);
    if (dto.completedDate) training.completedDate = new Date(dto.completedDate);
    if (dto.duration) training.duration = dto.duration;

    training.updatedAt = new Date();
    this.trainings.set(id, training);
    return training;
  }

  async recordAttendance(
    trainingId: number,
    dto: RecordAttendanceDto,
  ): Promise<TrainingAttendee> {
    const training = await this.getTrainingById(trainingId);
    let attendee = training.attendees.find((a) => a.workerId === dto.workerId);

    if (!attendee) {
      attendee = {
        workerId: dto.workerId,
        workerName: `Worker ${dto.workerId}`,
        attended: false,
        certified: false,
      };
      training.attendees.push(attendee);
    }

    attendee.attended = dto.attended;
    if (dto.score !== undefined) attendee.score = dto.score;
    if (dto.certified !== undefined) {
      attendee.certified = dto.certified;
      if (dto.certified) {
        attendee.certificationExpiry = new Date(
          Date.now() + 365 * 24 * 60 * 60 * 1000,
        );
      }
    }

    training.updatedAt = new Date();
    this.trainings.set(trainingId, training);
    return attendee;
  }
}
