import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { TerminusModule } from '@nestjs/terminus';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AIModule } from './ai/ai.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuditLogModule } from './audit/audit-log.module';
import { AuthModule } from './auth/auth.module';
import { RedisCacheModule } from './cache';
import { CallModule } from './call/call.module';
import { ChatModule } from './chat/chat.module';
import { CommentsModule } from './comments/comments.module';
import { ContractModule } from './contract/contract.module';
// DISABLED: Messaging modules require prisma migrate first
// import { ConversationMessagesModule } from './conversation-messages/conversation-messages.module';
// import { ConversationsModule } from './conversations/conversations.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { MetricsInterceptor, MetricsModule } from './metrics';
import { PaymentModule } from './payment/payment.module';
import { PrismaModule } from './prisma/prisma.module';
import { ProgressModule } from './progress/progress.module';
import { ProjectsModule } from './projects/projects.module';
import { TasksModule } from './tasks/tasks.module';
import { UploadModule } from './upload/upload.module';
import { UsersModule } from './users/users.module';
import { VideoModule } from './video/video.module';

// TEMPORARILY DISABLED: CRM module requires separate Prisma client (prisma-crm)
// import { CrmModule } from './crm/crm.module';
import { EmailModule } from './email/email.module';
import { FleetModule } from './fleet/fleet.module';
import { HealthModule } from './health/health.module';
import { LivestreamModule } from './livestream/livestream.module';
import { MessagesModule } from './messages/messages.module';
import { NotificationsModule } from './notifications/notifications.module';
import { ProductsModule } from './products/products.module';
import { ProfileModule } from './profile/profile.module';
import { QCModule } from './qc/qc.module';
// import { RealtimeModule } from './realtime/realtime.module'; // DISABLED
import { ReelsModule } from './reels/reels.module';
import { ServicesModule } from './services/services.module';
// TEMPORARILY DISABLED: SocialModule requires prisma migrate first
// import { SocialModule } from './social/social.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { AsBuiltModule } from './as-built/as-built.module';
import { ConstructionMapModule } from './construction-map/construction-map.module';
import { DocumentControlModule } from './document-control/document-control.module';
import { EnvironmentalModule } from './environmental/environmental.module';
import { FilesModule } from './files/files.module';
import { LaborModule } from './labor/labor.module';
import { SafetyModule } from './safety/safety.module';
import { StrapiSyncModule } from './strapi-sync/strapi-sync.module';
import { TimelineModule } from './timeline/timeline.module';
import { UtilitiesModule } from './utilities/utilities.module';
import { ZaloModule } from './zalo/zalo.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000, // 60 seconds
        limit: 100, // 100 requests per minute
      },
    ]),
    TerminusModule,
    PrismaModule,
    RedisCacheModule, // Redis caching for API responses
    MetricsModule, // Prometheus metrics endpoint
    AuditLogModule, // Global audit logging for security events
    EmailModule,
    UsersModule,
    AuthModule,
    CallModule,
    ProgressModule, // WebSocket real-time progress updates
    ProjectsModule,
    TasksModule,
    CommentsModule,
    ChatModule,
    UploadModule,
    // ConversationsModule, // DISABLED: Messaging requires prisma migrate
    // ConversationMessagesModule, // DISABLED: Messaging requires prisma migrate
    // RealtimeModule, // DISABLED: WebSocket messaging requires prisma migrate
    VideoModule,
    PaymentModule,
    AIModule,
    DashboardModule,
    ContractModule,
    TimelineModule,
    QCModule,
    HealthModule,
    LivestreamModule,
    ProductsModule,
    ProfileModule,
    NotificationsModule,
    MessagesModule,
    FleetModule,
    // CrmModule, // DISABLED: Missing prisma-crm generator
    ServicesModule,
    StrapiSyncModule, // Strapi CMS sync integration
    UtilitiesModule,
    ZaloModule, // Zalo OTP, ZNS notifications, OA integration
    ReelsModule, // Video reels từ Pexels API (proxy qua server)
    ConstructionMapModule, // Construction map with tasks, stages
    LaborModule, // Labor provider management
    AnalyticsModule, // Analytics dashboard, events, reports
    SafetyModule, // Safety audits, incidents, PPE, trainings
    AsBuiltModule, // As-built drawings, exports, comments
    EnvironmentalModule, // Environmental monitoring, emissions, waste, permits
    DocumentControlModule, // Document control, transmittals, revisions
    FilesModule, // File versioning, trash, audit logging
    // SocialModule, // DISABLED: Run prisma migrate first
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: MetricsInterceptor,
    },
  ],
})
export class AppModule {}
