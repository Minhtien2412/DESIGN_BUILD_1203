import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  ParseIntPipe,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiResponse,
  ApiQuery,
} from '@nestjs/swagger';
import { AIService } from './ai.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
  CreateAIAnalysisDto,
  CreateAIReportDto,
  AIAnalysisResponseDto,
  AIReportResponseDto,
  AIMonitoringResultDto,
  AnalyzeProgressDto,
  GenerateDailyReportDto,
  GenerateWeeklyReportDto,
  ChatWithAIDto,
  CheckMaterialsDto,
} from './dto';

@ApiTags('AI Agent')
@Controller({ path: 'ai', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class AIController {
  constructor(private readonly aiService: AIService) {}

  @Post('analyze')
  @ApiOperation({
    summary: 'Phân tích công trình bằng AI (với/không hình ảnh)',
  })
  @ApiResponse({ status: 201, type: AIAnalysisResponseDto })
  async analyzeConstructionSite(
    @Request() req: { user: { userId: number } },
    @Body() dto: CreateAIAnalysisDto,
  ): Promise<AIAnalysisResponseDto> {
    return this.aiService.analyzeConstructionSite(req.user.userId, dto);
  }

  @Post('report')
  @ApiOperation({ summary: 'Tạo báo cáo tiến độ tự động bằng AI' })
  @ApiResponse({ status: 201, type: AIReportResponseDto })
  async generateProgressReport(
    @Request() req: { user: { userId: number } },
    @Body() dto: CreateAIReportDto,
  ): Promise<AIReportResponseDto> {
    return this.aiService.generateProgressReport(req.user.userId, dto);
  }

  @Post('monitor/:projectId')
  @ApiOperation({ summary: 'Giám sát công trình real-time với hình ảnh' })
  @ApiResponse({ status: 201, type: AIMonitoringResultDto })
  async monitorProject(
    @Request() req: { user: { userId: number } },
    @Param('projectId', ParseIntPipe) projectId: number,
    @Body('imageUrl') imageUrl: string,
  ): Promise<AIMonitoringResultDto> {
    return this.aiService.monitorProject(req.user.userId, projectId, imageUrl);
  }

  @Get('analyses')
  @ApiOperation({ summary: 'Lấy lịch sử phân tích AI' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiResponse({ status: 200, type: [AIAnalysisResponseDto] })
  async getAnalysisHistory(
    @Request() req: { user: { userId: number } },
    @Query('projectId', ParseIntPipe) projectId?: number,
  ): Promise<AIAnalysisResponseDto[]> {
    return this.aiService.getAnalysisHistory(req.user.userId, projectId);
  }

  @Get('reports')
  @ApiOperation({ summary: 'Lấy danh sách báo cáo AI' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiResponse({ status: 200, type: [AIReportResponseDto] })
  async getReports(
    @Request() req: { user: { userId: number } },
    @Query('projectId', ParseIntPipe) projectId?: number,
  ): Promise<AIReportResponseDto[]> {
    return this.aiService.getReports(req.user.userId, projectId);
  }

  @Delete('analyses/:id')
  @ApiOperation({ summary: 'Xóa phân tích AI' })
  @ApiResponse({ status: 200 })
  async deleteAnalysis(
    @Request() req: { user: { userId: number } },
    @Param('id', ParseIntPipe) id: number,
  ): Promise<{ message: string }> {
    await this.aiService.deleteAnalysis(req.user.userId, id);
    return { message: 'Analysis deleted successfully' };
  }

  // ========================================
  // AI CONSTRUCTION ASSISTANT ENDPOINTS
  // ========================================

  @Post('progress/analyze')
  @ApiOperation({ summary: 'AI: Phân tích tiến độ từ hình ảnh công trường' })
  @ApiResponse({ status: 201, description: 'Progress analysis completed' })
  async analyzeProgress(
    @Request() req: { user: { userId: number } },
    @Body() dto: AnalyzeProgressDto,
  ) {
    return this.aiService.analyzeProgressFromImages(req.user.userId, dto);
  }

  @Get('progress/:projectId')
  @ApiOperation({ summary: 'Lấy danh sách phân tích tiến độ' })
  @ApiQuery({ name: 'phaseId', required: false, type: Number })
  async getProgressAnalyses(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('phaseId', ParseIntPipe) phaseId?: number,
  ) {
    return this.aiService.getProgressAnalyses(projectId, phaseId);
  }

  @Post('reports/daily')
  @ApiOperation({ summary: 'AI: Tạo báo cáo ngày tự động' })
  @ApiResponse({ status: 201, description: 'Daily report generated' })
  async generateDailyReport(
    @Request() req: { user: { userId: number } },
    @Body() dto: GenerateDailyReportDto,
  ) {
    return this.aiService.generateDailyReport(req.user.userId, dto);
  }

  @Get('reports/daily/:projectId')
  @ApiOperation({ summary: 'Lấy danh sách báo cáo ngày' })
  @ApiQuery({ name: 'startDate', required: false, type: String })
  @ApiQuery({ name: 'endDate', required: false, type: String })
  async getDailyReports(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.aiService.getDailyReports(projectId, startDate, endDate);
  }

  @Post('reports/weekly')
  @ApiOperation({ summary: 'AI: Tạo báo cáo tuần tự động' })
  @ApiResponse({ status: 201, description: 'Weekly report generated' })
  async generateWeeklyReport(
    @Request() req: { user: { userId: number } },
    @Body() dto: GenerateWeeklyReportDto,
  ) {
    return this.aiService.generateWeeklyReport(req.user.userId, dto);
  }

  @Get('reports/weekly/:projectId')
  @ApiOperation({ summary: 'Lấy danh sách báo cáo tuần' })
  @ApiQuery({ name: 'year', required: false, type: Number })
  async getWeeklyReports(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('year') year?: number,
  ) {
    return this.aiService.getWeeklyReports(projectId, year);
  }

  @Post('chat')
  @ApiOperation({ summary: 'AI: Chat với AI Construction Assistant' })
  @ApiResponse({ status: 201, description: 'AI response generated' })
  async chatWithAI(
    @Request() req: { user: { userId: number } },
    @Body() dto: ChatWithAIDto,
  ) {
    return this.aiService.chatWithAssistant(req.user.userId, dto);
  }

  @Get('chat/:projectId/history')
  @ApiOperation({ summary: 'Lấy lịch sử chat với AI' })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getChatHistory(
    @Request() req: { user: { userId: number } },
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('limit') limit?: number,
  ) {
    return this.aiService.getChatHistory(projectId, req.user.userId, limit);
  }

  @Post('materials/check')
  @ApiOperation({ summary: 'AI: Kiểm tra vật liệu xây dựng' })
  @ApiResponse({ status: 201, description: 'Material check completed' })
  async checkMaterials(
    @Request() req: { user: { userId: number } },
    @Body() dto: CheckMaterialsDto,
  ) {
    return this.aiService.checkMaterials(req.user.userId, dto);
  }

  @Get('materials/:projectId')
  @ApiOperation({ summary: 'Lấy danh sách báo cáo kiểm tra vật liệu' })
  async getMaterialReports(
    @Param('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.aiService.getMaterialReports(projectId);
  }
}
