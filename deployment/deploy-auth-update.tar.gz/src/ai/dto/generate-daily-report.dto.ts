import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsDateString,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

export class GenerateDailyReportDto {
  @ApiProperty({
    description: 'Project ID',
    example: 1,
  })
  @Type(() => Number)
  @IsNumber()
  projectId: number;

  @ApiProperty({
    description: 'Report date',
    example: '2024-12-15',
  })
  @IsDateString()
  reportDate: string;

  @ApiPropertyOptional({
    description: 'Array of site image URLs',
    example: ['https://example.com/site1.jpg', 'https://example.com/site2.jpg'],
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  imageUrls?: string[];

  @ApiPropertyOptional({
    description: 'Number of workers on site',
    example: 12,
    minimum: 0,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  workersCount?: number;

  @ApiPropertyOptional({
    description: 'Weather condition',
    example: 'Nắng, nhiệt độ 32°C',
  })
  @IsOptional()
  @IsString()
  weatherCondition?: string;
}
