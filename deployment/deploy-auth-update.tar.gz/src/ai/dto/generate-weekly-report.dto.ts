import { IsString, IsNumber, IsDateString, Min, Max } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class GenerateWeeklyReportDto {
  @ApiProperty({
    description: 'Project ID',
    example: 1,
  })
  @IsNumber()
  projectId: number;

  @ApiProperty({
    description: 'Week number (1-53)',
    example: 50,
    minimum: 1,
    maximum: 53,
  })
  @IsNumber()
  @Min(1)
  @Max(53)
  weekNumber: number;

  @ApiProperty({
    description: 'Year',
    example: 2024,
    minimum: 2020,
    maximum: 2100,
  })
  @IsNumber()
  @Min(2020)
  @Max(2100)
  year: number;

  @ApiProperty({
    description: 'Week start date',
    example: '2024-12-09',
  })
  @IsDateString()
  startDate: string;

  @ApiProperty({
    description: 'Week end date',
    example: '2024-12-15',
  })
  @IsDateString()
  endDate: string;
}
