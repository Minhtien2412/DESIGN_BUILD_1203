import { IsNotEmpty, IsOptional, IsString, IsInt } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateAIReportDto {
  @ApiProperty({
    description: 'Tiêu đề báo cáo',
    example: 'Báo cáo tiến độ tháng 11/2024',
  })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({ description: 'ID dự án cần báo cáo' })
  @IsInt()
  @IsNotEmpty()
  projectId: number;

  @ApiPropertyOptional({ description: 'Kỳ báo cáo', example: '2024-11' })
  @IsString()
  @IsOptional()
  period?: string;

  @ApiPropertyOptional({
    description: 'Nội dung bổ sung cho AI',
    example: 'Tập trung vào chất lượng và an toàn',
  })
  @IsString()
  @IsOptional()
  additionalContext?: string;
}
