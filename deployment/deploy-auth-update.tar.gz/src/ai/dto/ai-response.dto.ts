import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class AIAnalysisResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  type: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  prompt: string;

  @ApiPropertyOptional()
  response?: string;

  @ApiPropertyOptional({ type: [String] })
  imageUrls?: string[];

  @ApiPropertyOptional()
  insights?: any;

  @ApiPropertyOptional()
  suggestions?: any;

  @ApiPropertyOptional()
  score?: number;

  @ApiPropertyOptional()
  metadata?: any;

  @ApiPropertyOptional()
  error?: string;

  @ApiPropertyOptional()
  processingTime?: number;

  @ApiProperty()
  userId: number;

  @ApiPropertyOptional()
  projectId?: number;

  @ApiPropertyOptional()
  taskId?: number;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class AIReportResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  summary: string;

  @ApiProperty()
  detailedAnalysis: string;

  @ApiPropertyOptional()
  recommendations?: any;

  @ApiPropertyOptional()
  metrics?: any;

  @ApiPropertyOptional()
  period?: string;

  @ApiProperty()
  generatedBy: string;

  @ApiProperty()
  userId: number;

  @ApiProperty()
  projectId: number;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class AIMonitoringResultDto {
  @ApiProperty()
  status: string;

  @ApiProperty()
  analysis: string;

  @ApiPropertyOptional()
  safetyScore?: number;

  @ApiPropertyOptional()
  qualityScore?: number;

  @ApiPropertyOptional()
  progressScore?: number;

  @ApiPropertyOptional()
  issues?: string[];

  @ApiPropertyOptional()
  recommendations?: string[];
}
