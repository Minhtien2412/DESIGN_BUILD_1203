import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsNumber, IsOptional, IsString } from 'class-validator';

export class MaterialToCheck {
  @ApiProperty({
    description: 'Material name',
    example: 'Xi măng PCB40',
  })
  @IsString()
  name: string;

  @ApiProperty({
    description: 'Material specification',
    example: 'Bao 50kg, xuất xứ Hà Nội',
  })
  @IsString()
  specification: string;

  @ApiPropertyOptional({
    description: 'Expected quantity',
    example: '100 bao',
  })
  @IsOptional()
  @IsString()
  expectedQuantity?: string;
}

export class CheckMaterialsDto {
  @ApiProperty({
    description: 'Project ID',
    example: 1,
  })
  @Type(() => Number)
  @IsNumber()
  projectId: number;

  @ApiProperty({
    description: 'Materials to check',
    type: [MaterialToCheck],
    example: [
      {
        name: 'Xi măng PCB40',
        specification: 'Bao 50kg, xuất xứ Hà Nội',
        expectedQuantity: '100 bao',
      },
      {
        name: 'Cát vàng',
        specification: 'Hạt vừa, độ ẩm < 5%',
        expectedQuantity: '5m³',
      },
    ],
  })
  @IsArray()
  materialsToCheck: MaterialToCheck[];

  @ApiPropertyOptional({
    description: 'Array of material image URLs',
    example: [
      'https://example.com/material1.jpg',
      'https://example.com/material2.jpg',
    ],
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  imageUrls?: string[];
}
