import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export enum ChatIntent {
  PROGRESS_INQUIRY = 'progress_inquiry',
  CONSTRUCTION_SUGGESTION = 'construction_suggestion',
  MATERIAL_CHECK = 'material_check',
  GENERAL = 'general',
}

export class ChatWithAIDto {
  @ApiProperty({
    description: 'User message',
    example: 'Tiến độ thi công hiện tại đang như thế nào?',
  })
  @IsString()
  message: string;

  @ApiProperty({
    description: 'Project ID for context',
    example: 1,
  })
  @Type(() => Number)
  @IsNumber()
  projectId: number;

  @ApiPropertyOptional({
    description: 'Additional context (phase, task info)',
    example: { phaseId: 'cm3o5...', taskId: 'cm3o6...' },
  })
  @IsOptional()
  context?: any;

  @ApiPropertyOptional({
    description: 'Array of attached image URLs',
    example: ['https://example.com/image1.jpg'],
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  imageUrls?: string[];

  @ApiPropertyOptional({
    description: 'Chat intent',
    enum: ChatIntent,
    example: ChatIntent.PROGRESS_INQUIRY,
  })
  @IsOptional()
  @IsEnum(ChatIntent)
  intent?: ChatIntent;
}
