import {
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsArray,
  IsInt,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export enum AIAnalysisType {
  CONSTRUCTION_MONITORING = 'CONSTRUCTION_MONITORING',
  PROGRESS_REPORT = 'PROGRESS_REPORT',
  SAFETY_INSPECTION = 'SAFETY_INSPECTION',
  QUALITY_CHECK = 'QUALITY_CHECK',
  COST_ANALYSIS = 'COST_ANALYSIS',
  RISK_ASSESSMENT = 'RISK_ASSESSMENT',
}

export class CreateAIAnalysisDto {
  @ApiProperty({ enum: AIAnalysisType, description: 'Loại phân tích AI' })
  @IsEnum(AIAnalysisType)
  @IsNotEmpty()
  type: AIAnalysisType;

  @ApiProperty({
    description: 'Câu hỏi hoặc yêu cầu phân tích',
    example: 'Đánh giá tiến độ thi công công trình hiện tại',
  })
  @IsString()
  @IsNotEmpty()
  prompt: string;

  @ApiPropertyOptional({
    description: 'Danh sách URL hình ảnh để phân tích',
    type: [String],
  })
  @IsArray()
  @IsOptional()
  imageUrls?: string[];

  @ApiPropertyOptional({ description: 'ID dự án liên quan' })
  @IsInt()
  @IsOptional()
  projectId?: number;

  @ApiPropertyOptional({ description: 'ID task liên quan' })
  @IsInt()
  @IsOptional()
  taskId?: number;
}
