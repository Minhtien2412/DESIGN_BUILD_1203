import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsDateString,
    IsNumber,
    IsOptional,
    IsString,
    Max,
    Min,
} from 'class-validator';

export class AnalyzeProgressDto {
  @ApiProperty({
    description: 'Project ID',
    example: 1,
  })
  @Type(() => Number)
  @IsNumber()
  projectId: number;

  @ApiPropertyOptional({
    description: 'Timeline phase ID (optional)',
    example: 2,
  })
  @IsOptional()
  @IsNumber()
  phaseId?: number;

  @ApiProperty({
    description: 'Analysis date',
    example: '2024-12-15',
  })
  @IsDateString()
  analysisDate: string;

  @ApiProperty({
    description: 'Array of site image URLs',
    example: ['https://example.com/site1.jpg', 'https://example.com/site2.jpg'],
    type: [String],
  })
  @IsArray()
  @IsString({ each: true })
  imageUrls: string[];

  @ApiPropertyOptional({
    description: 'Array of drawing/blueprint URLs for comparison',
    example: [
      'https://example.com/drawing1.pdf',
      'https://example.com/drawing2.pdf',
    ],
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  drawingUrls?: string[];

  @ApiPropertyOptional({
    description: 'Expected progress percentage (0-100)',
    example: 75,
    minimum: 0,
    maximum: 100,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  expectedProgress?: number;
}
