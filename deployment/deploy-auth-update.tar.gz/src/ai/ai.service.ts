import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { getErrorMessage, getErrorStack } from '../utils/error-helpers';

import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import {
    AIAnalysisResponseDto,
    AIMonitoringResultDto,
    AIReportResponseDto,
    AnalyzeProgressDto,
    ChatWithAIDto,
    CheckMaterialsDto,
    CreateAIAnalysisDto,
    CreateAIReportDto,
    GenerateDailyReportDto,
    GenerateWeeklyReportDto,
} from './dto';

// Type guards for OpenAI responses
interface OpenAIProgressAnalysis {
  detectedProgress: number;
  expectedProgress: number;
  progressDelta: number;
  isDelayed: boolean;
  delayReason?: string;
  comparisonResult: string;
  detectedIssues: string[];
  aiInsights: Record<string, unknown>;
  recommendations: string[];
  confidence: number;
}

interface OpenAIReportData {
  summary: string;
  detailedContent?: string;
  detailedAnalysis?: string;
  workCompleted?: Record<string, unknown>;
  workInProgress?: Record<string, unknown>;
  workPlanned?: Record<string, unknown>;
  issues?: string[];
  safetyNotes?: string;
  executiveSummary?: string;
  progressOverview?: Record<string, unknown>;
  achievements?: string[];
  challenges?: string[];
  nextWeekPlan?: string[];
  budgetStatus?: Record<string, unknown>;
  recommendations?: string[];
  kpis?: Record<string, number>;
  metrics?: Record<string, unknown>;
}

interface OpenAIMaterialCheck {
  summary: string;
  materialsChecked: Array<{
    name: string;
    specification: string;
    status: string;
  }>;
  correctMaterials: number;
  incorrectMaterials: number;
  missingMaterials: string[];
  excessMaterials: string[];
  qualityIssues: string[];
  recommendations: string[];
  estimatedCost: number;
}

interface ParsedAIResponse {
  insights: string[];
  suggestions: string[];
  score: number;
}

@Injectable()
export class AIService {
  private readonly logger = new Logger(AIService.name);
  private openai: OpenAI | null = null;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    const apiKey = this.configService.get<string>('OPENAI_API_KEY');
    if (!apiKey) {
      this.logger.warn(
        '⚠️ OPENAI_API_KEY not configured - AI features disabled',
      );
    } else {
      this.openai = new OpenAI({ apiKey });
    }
  }

  private ensureAIConfigured() {
    if (!this.openai) {
      throw new BadRequestException(
        'AI service not configured. Please set OPENAI_API_KEY.',
      );
    }
  }

  /**
   * Phân tích công trình bằng AI với hình ảnh
   */
  async analyzeConstructionSite(
    userId: number,
    dto: CreateAIAnalysisDto,
  ): Promise<AIAnalysisResponseDto> {
    const startTime = Date.now();

    // Tạo bản ghi phân tích với trạng thái PROCESSING
    const analysis = await this.prisma.aIAnalysis.create({
      data: {
        type: dto.type,
        status: 'PROCESSING',
        prompt: dto.prompt,
        imageUrls: dto.imageUrls || [],
        userId,
        projectId: dto.projectId,
        taskId: dto.taskId,
      },
    });

    try {
      // Xây dựng messages cho OpenAI
      const messages: any[] = [
        {
          role: 'system',
          content: this.getSystemPromptByType(dto.type),
        },
      ];

      // Nếu có hình ảnh, sử dụng GPT-4 Vision
      if (dto.imageUrls && dto.imageUrls.length > 0) {
        const imageContent = dto.imageUrls.map((url) => ({
          type: 'image_url',
          image_url: { url },
        }));

        messages.push({
          role: 'user',
          content: [{ type: 'text', text: dto.prompt }, ...imageContent],
        });
      } else {
        messages.push({
          role: 'user',
          content: dto.prompt,
        });
      }

      // Gọi OpenAI API
      const completion = await this.openai!.chat.completions.create({
        model:
          dto.imageUrls && dto.imageUrls.length > 0 ? 'gpt-4o' : 'gpt-4o-mini',
        messages,
        temperature: 0.7,
        max_tokens: 2000,
      });

      const response = completion.choices[0].message.content;
      if (!response) {
        throw new Error('Empty response from OpenAI');
      }

      const processingTime = Date.now() - startTime;

      // Parse insights và suggestions từ response
      const { insights, suggestions, score } = this.parseAIResponse(
        response,
        dto.type,
      );

      // Cập nhật kết quả
      const updatedAnalysis = await this.prisma.aIAnalysis.update({
        where: { id: analysis.id },
        data: {
          status: 'COMPLETED',
          response,
          insights,
          suggestions,
          score,
          processingTime,
          metadata: {
            model: completion.model,
            tokens: completion.usage?.total_tokens,
          },
        },
      });

      return updatedAnalysis as AIAnalysisResponseDto;
    } catch (error: unknown) {
      this.logger.error(
        `AI analysis failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );

      // Cập nhật lỗi
      await this.prisma.aIAnalysis.update({
        where: { id: analysis.id },
        data: {
          status: 'FAILED',
          error: getErrorMessage(error),
          processingTime: Date.now() - startTime,
        },
      });

      throw new BadRequestException(
        `AI analysis failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Tạo báo cáo tiến độ tự động
   */
  async generateProgressReport(
    userId: number,
    dto: CreateAIReportDto,
  ): Promise<AIReportResponseDto> {
    // Lấy dữ liệu dự án
    const project = await this.prisma.project.findUnique({
      where: { id: dto.projectId },
      include: {
        tasks: {
          include: {
            assignee: { select: { id: true, name: true } },
            comments: true,
          },
        },
        timeline: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
        comments: true,
        payments: true,
      },
    });

    if (!project) {
      throw new BadRequestException('Project not found');
    }

    // Phân tích dữ liệu
    const totalTasks = project.tasks?.length || 0;
    const completedTasks =
      project.tasks?.filter((t) => t.status === 'DONE').length || 0;
    const inProgressTasks =
      project.tasks?.filter((t) => t.status === 'IN_PROGRESS').length || 0;
    const completionRate =
      totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    // Tạo context cho AI
    const context = `
Project: ${project.title}
Description: ${project.description || 'N/A'}
Status: ${project.status}
Budget: ${project.budget ? `${project.budget} VND` : 'N/A'}
Period: ${dto.period || 'Current'}

Tasks Summary:
- Total: ${totalTasks}
- Completed: ${completedTasks}
- In Progress: ${inProgressTasks}
- Completion Rate: ${completionRate.toFixed(1)}%

Recent Activities:
${
  project.timeline
    ?.slice(0, 10)
    .map((t) => `- ${t.eventType}: ${t.description}`)
    .join('\n') || 'No recent activities'
}

${dto.additionalContext ? `Additional Context: ${dto.additionalContext}` : ''}
`;

    try {
      const completion = await this.openai!.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `Bạn là chuyên gia quản lý dự án xây dựng. Hãy tạo báo cáo chi tiết về tiến độ dự án.
            
Báo cáo phải bao gồm:
1. Tóm tắt ngắn gọn (2-3 câu)
2. Phân tích chi tiết về:
   - Tiến độ thi công
   - Chất lượng công việc
   - Vấn đề cần lưu ý
   - Rủi ro và cơ hội
3. Đề xuất cải thiện cụ thể

Trả về JSON với format:
{
  "summary": "Tóm tắt ngắn gọn",
  "detailedAnalysis": "Phân tích chi tiết (markdown format)",
  "recommendations": ["Đề xuất 1", "Đề xuất 2", ...],
  "metrics": {
    "completion": 75,
    "quality": 85,
    "safety": 90,
    "budget": 80
  }
}`,
          },
          {
            role: 'user',
            content: `Tạo báo cáo cho dự án sau:\n\n${context}`,
          },
        ],
        temperature: 0.8,
        max_tokens: 3000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const aiResponse = JSON.parse(content);

      // Lưu báo cáo vào database
      const report = await this.prisma.aIReport.create({
        data: {
          title: dto.title,
          summary: aiResponse.summary,
          detailedAnalysis: aiResponse.detailedAnalysis,
          recommendations: aiResponse.recommendations,
          metrics: aiResponse.metrics,
          period: dto.period,
          generatedBy: `OpenAI ${completion.model}`,
          userId,
          projectId: dto.projectId,
        },
      });

      return report as AIReportResponseDto;
    } catch (error: unknown) {
      this.logger.error(
        `Failed to generate report: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Failed to generate report: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Giám sát công trình real-time
   */
  async monitorProject(
    userId: number,
    projectId: number,
    imageUrl: string,
  ): Promise<AIMonitoringResultDto> {
    const prompt = `Phân tích hình ảnh công trình này và đánh giá:
1. Tình trạng an toàn lao động (0-100)
2. Chất lượng thi công (0-100)
3. Tiến độ công việc (0-100)
4. Các vấn đề cần chú ý
5. Đề xuất cải thiện

Trả về JSON format.`;

    try {
      const completion = await this.openai!.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `Bạn là chuyên gia giám sát công trình xây dựng. Phân tích hình ảnh và đưa ra đánh giá chính xác.
            
Trả về JSON:
{
  "status": "GOOD/WARNING/CRITICAL",
  "analysis": "Phân tích tổng quan",
  "safetyScore": 85,
  "qualityScore": 90,
  "progressScore": 75,
  "issues": ["Vấn đề 1", "Vấn đề 2"],
  "recommendations": ["Đề xuất 1", "Đề xuất 2"]
}`,
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          },
        ],
        temperature: 0.5,
        max_tokens: 1500,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const result = JSON.parse(content);

      // Lưu phân tích
      await this.prisma.aIAnalysis.create({
        data: {
          type: 'CONSTRUCTION_MONITORING',
          status: 'COMPLETED',
          prompt,
          response: JSON.stringify(result),
          imageUrls: [imageUrl],
          insights: result,
          score:
            (result.safetyScore + result.qualityScore + result.progressScore) /
            3,
          userId,
          projectId,
        },
      });

      return result;
    } catch (error: unknown) {
      this.logger.error(
        `Monitoring failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Monitoring failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Lấy lịch sử phân tích AI
   */
  async getAnalysisHistory(
    userId: number,
    projectId?: number,
  ): Promise<AIAnalysisResponseDto[]> {
    const analyses = await this.prisma.aIAnalysis.findMany({
      where: {
        userId,
        ...(projectId && { projectId }),
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return analyses as AIAnalysisResponseDto[];
  }

  /**
   * Lấy danh sách báo cáo
   */
  async getReports(
    userId: number,
    projectId?: number,
  ): Promise<AIReportResponseDto[]> {
    const reports = await this.prisma.aIReport.findMany({
      where: {
        userId,
        ...(projectId && { projectId }),
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    return reports as AIReportResponseDto[];
  }

  /**
   * Xóa phân tích
   */
  async deleteAnalysis(userId: number, analysisId: number): Promise<void> {
    const analysis = await this.prisma.aIAnalysis.findFirst({
      where: { id: analysisId, userId },
    });

    if (!analysis) {
      throw new BadRequestException('Analysis not found or unauthorized');
    }

    await this.prisma.aIAnalysis.delete({
      where: { id: analysisId },
    });
  }

  /**
   * Lấy system prompt theo loại phân tích
   */
  private getSystemPromptByType(type: string): string {
    const prompts = {
      CONSTRUCTION_MONITORING: `Bạn là chuyên gia giám sát công trình xây dựng. Phân tích hình ảnh và đưa ra đánh giá về an toàn, chất lượng, tiến độ.`,
      PROGRESS_REPORT: `Bạn là chuyên gia quản lý dự án xây dựng. Đánh giá tiến độ và đưa ra báo cáo chi tiết.`,
      SAFETY_INSPECTION: `Bạn là chuyên gia an toàn lao động trong xây dựng. Kiểm tra và đánh giá các yếu tố an toàn.`,
      QUALITY_CHECK: `Bạn là kỹ sư chất lượng xây dựng. Kiểm tra chất lượng thi công và vật liệu.`,
      COST_ANALYSIS: `Bạn là chuyên gia phân tích chi phí xây dựng. Đánh giá và tối ưu hóa ngân sách.`,
      RISK_ASSESSMENT: `Bạn là chuyên gia quản lý rủi ro dự án. Nhận diện và đánh giá các rủi ro tiềm ẩn.`,
    };

    return prompts[type] || prompts.CONSTRUCTION_MONITORING;
  }

  /**
   * Parse response từ AI
   */
  private parseAIResponse(
    response: string,
    type: string,
  ): { insights: any; suggestions: any; score: number } {
    try {
      // Cố gắng parse JSON nếu có
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          insights: parsed,
          suggestions: parsed.recommendations || parsed.suggestions || [],
          score: this.calculateScore(parsed),
        };
      }
    } catch (e) {
      // Nếu không parse được JSON, trích xuất thông tin từ text
    }

    // Fallback: extract insights từ text
    const lines = response.split('\n');
    const insights = { summary: response.substring(0, 500) };
    const suggestions = lines
      .filter((line) => line.includes('đề xuất') || line.includes('nên'))
      .slice(0, 5);

    return {
      insights,
      suggestions,
      score: 75, // Default score
    };
  }

  /**
   * Tính điểm tổng hợp
   */
  private calculateScore(data: any): number {
    if (data.safetyScore && data.qualityScore && data.progressScore) {
      return (data.safetyScore + data.qualityScore + data.progressScore) / 3;
    }
    if (data.score) {
      return data.score;
    }
    if (data.metrics) {
      const values = Object.values(data.metrics).filter(
        (v) => typeof v === 'number',
      );
      return values.length > 0
        ? values.reduce((a: number, b: number) => a + b, 0) / values.length
        : 75;
    }
    return 75;
  }

  // ========================================
  // AI CONSTRUCTION ASSISTANT METHODS
  // ========================================

  /**
   * Phân tích tiến độ từ hình ảnh
   */
  async analyzeProgressFromImages(userId: number, dto: AnalyzeProgressDto) {
    const startTime = Date.now();

    try {
      // Xây dựng prompt cho AI
      const prompt = `Phân tích hình ảnh công trường xây dựng và đánh giá tiến độ thi công.

${dto.drawingUrls && dto.drawingUrls.length > 0 ? 'So sánh với bản vẽ thiết kế để đánh giá mức độ hoàn thành.' : ''}
${dto.expectedProgress ? `Tiến độ dự kiến: ${dto.expectedProgress}%` : ''}

Trả về JSON với format:
{
  "detectedProgress": 75, // Tiến độ thực tế phát hiện (0-100)
  "progressDelta": -5, // Chênh lệch so với dự kiến (âm = chậm, dương = vượt)
  "isDelayed": true, // Có bị trễ không?
  "delayReason": "Mưa kéo dài 3 ngày", // Lý do nếu có
  "comparisonResult": "Phần móng đã hoàn thành 90%, tường bao chưa bắt đầu",
  "detectedIssues": ["Vật liệu chưa được sắp xếp gọn gàng", "Thiếu biển báo an toàn"],
  "aiInsights": {
    "summary": "Tổng quan ngắn gọn",
    "details": "Chi tiết phân tích",
    "workCompleted": ["Công việc 1", "Công việc 2"],
    "workInProgress": ["Công việc đang làm"],
    "nextSteps": ["Bước tiếp theo"]
  },
  "recommendations": [
    {
      "priority": "HIGH",
      "action": "Bổ sung biển báo an toàn",
      "reason": "Đảm bảo tuân thủ quy định"
    }
  ],
  "confidence": 0.85 // Độ tin cậy (0-1)
}`;

      // Xây dựng messages cho OpenAI
      const messages: any[] = [
        {
          role: 'system',
          content: `Bạn là chuyên gia giám sát tiến độ xây dựng với kinh nghiệm 20 năm. 
Nhiệm vụ: Phân tích hình ảnh công trường, so sánh với bản vẽ (nếu có), và đánh giá tiến độ chính xác.
Lưu ý: Phân tích kỹ lưỡng, nhận diện các vấn đề tiềm ẩn, đưa ra đề xuất cụ thể.`,
        },
      ];

      // Thêm hình ảnh công trường
      const imageContent = dto.imageUrls.map((url) => ({
        type: 'image_url',
        image_url: { url },
      }));

      // Thêm bản vẽ nếu có
      if (dto.drawingUrls && dto.drawingUrls.length > 0) {
        const drawingContent = dto.drawingUrls.map((url) => ({
          type: 'image_url',
          image_url: { url },
        }));
        imageContent.push(...drawingContent);
      }

      messages.push({
        role: 'user',
        content: [{ type: 'text', text: prompt }, ...imageContent],
      });

      // Gọi OpenAI API với GPT-4 Vision
      const completion = await this.openai!.chat.completions.create({
        model: 'gpt-4o',
        messages,
        temperature: 0.5,
        max_tokens: 3000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const aiResponse = JSON.parse(content);
      const processingTime = Date.now() - startTime;

      // Tính toán progressDelta nếu có expectedProgress
      let progressDelta = aiResponse.progressDelta;
      let isDelayed = aiResponse.isDelayed;

      if (dto.expectedProgress !== undefined) {
        progressDelta = aiResponse.detectedProgress - dto.expectedProgress;
        isDelayed = progressDelta < -5; // Chậm hơn 5%
      }

      // Lưu vào database
      const analysis = await this.prisma.aIProgressAnalysis.create({
        data: {
          projectId: dto.projectId,
          phaseId: dto.phaseId,
          analyzedBy: userId,
          analysisDate: new Date(dto.analysisDate),
          imageUrls: dto.imageUrls,
          drawingUrls: dto.drawingUrls || [],
          detectedProgress: aiResponse.detectedProgress,
          expectedProgress: dto.expectedProgress || aiResponse.detectedProgress,
          progressDelta,
          isDelayed,
          delayReason: aiResponse.delayReason,
          comparisonResult: aiResponse.comparisonResult,
          detectedIssues: aiResponse.detectedIssues || [],
          aiInsights: aiResponse.aiInsights,
          recommendations: aiResponse.recommendations,
          confidence: aiResponse.confidence || 0.8,
          processingTime,
        },
      });

      return analysis;
    } catch (error: unknown) {
      this.logger.error(
        `Progress analysis failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Progress analysis failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Tạo báo cáo ngày tự động
   */
  async generateDailyReport(userId: number, dto: GenerateDailyReportDto) {
    try {
      // Lấy thông tin dự án
      const project = await this.prisma.project.findUnique({
        where: { id: dto.projectId },
        include: {
          tasks: {
            where: {
              OR: [{ status: 'IN_PROGRESS' }, { status: 'DONE' }],
            },
            orderBy: { updatedAt: 'desc' },
            take: 20,
          },
          timelinePhases: {
            include: {
              tasks: true,
            },
          },
        },
      });

      if (!project) {
        throw new BadRequestException('Project not found');
      }

      // Xây dựng context
      const context = `
Dự án: ${project.title}
Ngày: ${dto.reportDate}
${dto.weatherCondition ? `Thời tiết: ${dto.weatherCondition}` : ''}
${dto.workersCount ? `Số công nhân: ${dto.workersCount}` : ''}

Công việc gần đây:
${project.tasks
  ?.slice(0, 10)
  .map((t) => `- ${t.title} (${t.status})`)
  .join('\n')}

Giai đoạn thi công:
${project.timelinePhases?.map((p) => `- ${p.name} (${p.status})`).join('\n')}
`;

      const prompt = `Tạo báo cáo ngày chi tiết cho dự án xây dựng.

${context}

${dto.imageUrls && dto.imageUrls.length > 0 ? 'Phân tích hình ảnh công trường ngày hôm nay.' : ''}

Trả về JSON:
{
  "summary": "Tóm tắt ngắn gọn tình hình ngày hôm nay",
  "detailedContent": "Nội dung báo cáo chi tiết (markdown format)",
  "workCompleted": [
    { "task": "Công việc hoàn thành", "quantity": "100m²", "quality": "Tốt" }
  ],
  "workInProgress": [
    { "task": "Công việc đang làm", "progress": "50%", "expectedCompletion": "2024-12-16" }
  ],
  "workPlanned": [
    { "task": "Công việc kế hoạch", "startDate": "2024-12-16" }
  ],
  "issues": [
    { "type": "SAFETY", "severity": "MEDIUM", "description": "Thiếu thiết bị bảo hộ" }
  ],
  "safetyNotes": "Ghi chú an toàn"
}`;

      const messages: any[] = [
        {
          role: 'system',
          content: `Bạn là chuyên gia quản lý dự án xây dựng. Tạo báo cáo ngày chính xác, chi tiết, chuyên nghiệp.`,
        },
      ];

      if (dto.imageUrls && dto.imageUrls.length > 0) {
        const imageContent = dto.imageUrls.map((url) => ({
          type: 'image_url',
          image_url: { url },
        }));
        messages.push({
          role: 'user',
          content: [{ type: 'text', text: prompt }, ...imageContent],
        });
      } else {
        messages.push({
          role: 'user',
          content: prompt,
        });
      }

      const completion = await this.openai!.chat.completions.create({
        model:
          dto.imageUrls && dto.imageUrls.length > 0 ? 'gpt-4o' : 'gpt-4o-mini',
        messages,
        temperature: 0.7,
        max_tokens: 3000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const aiResponse = JSON.parse(content);

      // Lưu báo cáo
      const report = await this.prisma.aIDailyReport.create({
        data: {
          projectId: dto.projectId,
          reportDate: new Date(dto.reportDate),
          title: `Báo cáo ngày ${new Date(dto.reportDate).toLocaleDateString('vi-VN')}`,
          summary: aiResponse.summary,
          detailedContent: aiResponse.detailedContent,
          workCompleted: aiResponse.workCompleted || [],
          workInProgress: aiResponse.workInProgress || [],
          workPlanned: aiResponse.workPlanned || [],
          issues: aiResponse.issues || [],
          safetyNotes: aiResponse.safetyNotes,
          weatherCondition: dto.weatherCondition,
          workersCount: dto.workersCount,
          imageUrls: dto.imageUrls || [],
          generatedBy: `OpenAI ${completion.model}`,
        },
      });

      return report;
    } catch (error: unknown) {
      this.logger.error(
        `Daily report generation failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Daily report generation failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Tạo báo cáo tuần
   */
  async generateWeeklyReport(userId: number, dto: GenerateWeeklyReportDto) {
    try {
      // Lấy dữ liệu dự án và báo cáo ngày trong tuần
      const [project, dailyReports, progressAnalyses] = await Promise.all([
        this.prisma.project.findUnique({
          where: { id: dto.projectId },
          include: {
            tasks: true,
            timelinePhases: {
              include: {
                tasks: true,
              },
            },
            payments: true,
          },
        }),
        this.prisma.aIDailyReport.findMany({
          where: {
            projectId: dto.projectId,
            reportDate: {
              gte: new Date(dto.startDate),
              lte: new Date(dto.endDate),
            },
          },
          orderBy: { reportDate: 'asc' },
        }),
        this.prisma.aIProgressAnalysis.findMany({
          where: {
            projectId: dto.projectId,
            analysisDate: {
              gte: new Date(dto.startDate),
              lte: new Date(dto.endDate),
            },
          },
          orderBy: { analysisDate: 'asc' },
        }),
      ]);

      if (!project) {
        throw new BadRequestException('Project not found');
      }

      // Tổng hợp dữ liệu tuần
      const totalTasks = project.tasks?.length || 0;
      const completedTasks =
        project.tasks?.filter((t) => t.status === 'DONE').length || 0;
      const overallProgress =
        totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

      const context = `
Dự án: ${project.title}
Tuần ${dto.weekNumber}/${dto.year} (${dto.startDate} - ${dto.endDate})

Tiến độ tổng thể: ${overallProgress.toFixed(1)}%
Tổng số công việc: ${totalTasks}
Hoàn thành: ${completedTasks}

Báo cáo ngày trong tuần:
${dailyReports.map((r) => `- ${r.reportDate.toLocaleDateString('vi-VN')}: ${r.summary}`).join('\n')}

Phân tích tiến độ:
${progressAnalyses.map((a) => `- ${a.analysisDate.toLocaleDateString('vi-VN')}: ${a.detectedProgress}% ${a.isDelayed ? '(TRỄ)' : ''}`).join('\n')}

Giai đoạn thi công:
${project.timelinePhases?.map((p) => `- ${p.name}: ${p.status} (${p.startDate?.toLocaleDateString('vi-VN')} - ${p.endDate?.toLocaleDateString('vi-VN')})`).join('\n')}
`;

      const prompt = `Tạo báo cáo tổng kết tuần chi tiết cho dự án xây dựng.

${context}

Trả về JSON:
{
  "executiveSummary": "Tóm tắt điều hành ngắn gọn (2-3 câu)",
  "detailedAnalysis": "Phân tích chi tiết (markdown format)",
  "progressOverview": {
    "overall": 75,
    "phases": [
      { "name": "Móng", "progress": 100, "status": "COMPLETED" },
      { "name": "Tường", "progress": 60, "status": "IN_PROGRESS" }
    ]
  },
  "achievements": [
    { "title": "Thành tựu 1", "impact": "Tác động tích cực" }
  ],
  "challenges": [
    { "title": "Thách thức 1", "impact": "HIGH", "mitigation": "Giải pháp" }
  ],
  "nextWeekPlan": [
    { "activity": "Hoạt động tuần sau", "resources": "Nguồn lực cần" }
  ],
  "budgetStatus": {
    "planned": 1000000000,
    "actual": 950000000,
    "variance": -50000000,
    "status": "ON_TRACK"
  },
  "recommendations": [
    { "priority": "HIGH", "action": "Hành động", "reason": "Lý do" }
  ],
  "kpis": {
    "quality": 85,
    "safety": 90,
    "time": 75,
    "cost": 95
  }
}`;

      const completion = await this.openai!.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `Bạn là chuyên gia quản lý dự án xây dựng cấp cao. Tạo báo cáo tuần toàn diện với phân tích sâu sắc và đề xuất chiến lược.`,
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 4000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const aiResponse = JSON.parse(content);

      // Lưu báo cáo tuần
      const report = await this.prisma.aIWeeklyReport.create({
        data: {
          projectId: dto.projectId,
          weekNumber: dto.weekNumber,
          year: dto.year,
          startDate: new Date(dto.startDate),
          endDate: new Date(dto.endDate),
          title: `Báo cáo tuần ${dto.weekNumber}/${dto.year}`,
          executiveSummary: aiResponse.executiveSummary,
          detailedAnalysis: aiResponse.detailedAnalysis,
          progressOverview: aiResponse.progressOverview,
          achievements: aiResponse.achievements || [],
          challenges: aiResponse.challenges || [],
          nextWeekPlan: aiResponse.nextWeekPlan || [],
          budgetStatus: aiResponse.budgetStatus,
          recommendations: aiResponse.recommendations || [],
          kpis: aiResponse.kpis,
          generatedBy: `OpenAI ${completion.model}`,
        },
      });

      return report;
    } catch (error: unknown) {
      this.logger.error(
        `Weekly report generation failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Weekly report generation failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Chat với AI Assistant
   */
  async chatWithAssistant(userId: number, dto: ChatWithAIDto) {
    try {
      // Lấy context dự án
      const project = await this.prisma.project.findUnique({
        where: { id: dto.projectId },
        include: {
          tasks: {
            orderBy: { updatedAt: 'desc' },
            take: 10,
          },
          timelinePhases: {
            include: {
              tasks: true,
            },
          },
          aiProgressAnalyses: {
            orderBy: { analysisDate: 'desc' },
            take: 5,
          },
          aiDailyReports: {
            orderBy: { reportDate: 'desc' },
            take: 3,
          },
        },
      });

      if (!project) {
        throw new BadRequestException('Project not found');
      }

      // Lấy lịch sử chat gần nhất
      const chatHistory = await this.prisma.aIChatHistory.findMany({
        where: {
          projectId: dto.projectId,
          userId,
        },
        orderBy: { createdAt: 'desc' },
        take: 5,
      });

      // Xây dựng context
      let systemPrompt = `Bạn là AI Construction Assistant của Nhà Xinh, chuyên gia tư vấn xây dựng thông minh.

Thông tin dự án:
- Tên: ${project.title}
- Mô tả: ${project.description || 'N/A'}
- Trạng thái: ${project.status}
- Ngân sách: ${project.budget ? Number(project.budget).toLocaleString('vi-VN') + ' VND' : 'N/A'}

Tiến độ gần nhất:
${project.aiProgressAnalyses?.map((a) => `- ${a.analysisDate.toLocaleDateString('vi-VN')}: ${a.detectedProgress}% ${a.isDelayed ? '(TRỄ)' : ''}`).join('\n') || 'Chưa có dữ liệu'}

Công việc gần đây:
${project.tasks?.map((t) => `- ${t.title} (${t.status})`).join('\n') || 'Chưa có công việc'}

Nhiệm vụ của bạn:
`;

      // Tùy chỉnh prompt theo intent
      switch (dto.intent) {
        case 'progress_inquiry':
          systemPrompt += `- Trả lời câu hỏi về tiến độ thi công
- Cung cấp thông tin chi tiết, chính xác
- Cảnh báo nếu có chậm tiến độ`;
          break;
        case 'construction_suggestion':
          systemPrompt += `- Đưa ra gợi ý phương án xây dựng
- Phân tích ưu nhược điểm
- Đề xuất giải pháp tối ưu`;
          break;
        case 'material_check':
          systemPrompt += `- Kiểm tra vật liệu xây dựng
- Xác nhận chất lượng
- Cảnh báo nếu không đúng quy cách`;
          break;
        default:
          systemPrompt += `- Trả lời mọi câu hỏi liên quan đến dự án
- Hỗ trợ khách hàng tận tình
- Cung cấp thông tin chính xác, hữu ích`;
      }

      // Xây dựng messages
      const messages: any[] = [
        {
          role: 'system',
          content: systemPrompt,
        },
      ];

      // Thêm lịch sử chat
      chatHistory.reverse().forEach((chat) => {
        messages.push({
          role: chat.role,
          content: chat.message,
        });
      });

      // Thêm tin nhắn người dùng
      if (dto.imageUrls && dto.imageUrls.length > 0) {
        const imageContent = dto.imageUrls.map((url) => ({
          type: 'image_url',
          image_url: { url },
        }));
        messages.push({
          role: 'user',
          content: [{ type: 'text', text: dto.message }, ...imageContent],
        });
      } else {
        messages.push({
          role: 'user',
          content: dto.message,
        });
      }

      // Gọi OpenAI
      const completion = await this.openai!.chat.completions.create({
        model:
          dto.imageUrls && dto.imageUrls.length > 0 ? 'gpt-4o' : 'gpt-4o-mini',
        messages,
        temperature: 0.8,
        max_tokens: 2000,
      });

      const response = completion.choices[0].message.content;
      if (!response) {
        throw new Error('Empty response from OpenAI');
      }

      // Lưu tin nhắn người dùng
      await this.prisma.aIChatHistory.create({
        data: {
          projectId: dto.projectId,
          userId,
          role: 'user',
          message: dto.message,
          context: dto.context,
          imageUrls: dto.imageUrls || [],
          intent: dto.intent,
          metadata: {
            model: completion.model,
            tokens: completion.usage?.total_tokens,
          },
        },
      });

      // Lưu phản hồi AI
      const chatResponse = await this.prisma.aIChatHistory.create({
        data: {
          projectId: dto.projectId,
          userId,
          role: 'assistant',
          message: response,
          context: dto.context,
          intent: dto.intent,
          response,
          confidence: 0.9,
          metadata: {
            model: completion.model,
            tokens: completion.usage?.total_tokens,
          },
        },
      });

      return chatResponse;
    } catch (error: unknown) {
      this.logger.error(
        `AI chat failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `AI chat failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Kiểm tra vật liệu
   */
  async checkMaterials(userId: number, dto: CheckMaterialsDto) {
    try {
      const prompt = `Kiểm tra vật liệu xây dựng dựa trên danh sách và hình ảnh.

Danh sách vật liệu cần kiểm tra:
${dto.materialsToCheck
  .map(
    (m, i) => `${i + 1}. ${m.name}
   - Quy cách: ${m.specification}
   ${m.expectedQuantity ? `- Số lượng dự kiến: ${m.expectedQuantity}` : ''}`,
  )
  .join('\n')}

${dto.imageUrls && dto.imageUrls.length > 0 ? 'Phân tích hình ảnh vật liệu thực tế.' : ''}

Trả về JSON:
{
  "summary": "Tóm tắt kết quả kiểm tra",
  "materialsChecked": [
    {
      "name": "Xi măng PCB40",
      "specification": "Bao 50kg",
      "status": "CORRECT",
      "isCorrect": true,
      "actualQuantity": "100 bao",
      "notes": "Đúng quy cách, chất lượng tốt"
    }
  ],
  "correctMaterials": 5,
  "incorrectMaterials": 1,
  "missingMaterials": [
    { "name": "Cát vàng", "quantity": "2m³", "urgency": "HIGH" }
  ],
  "excessMaterials": [
    { "name": "Gạch", "quantity": "500 viên", "action": "Trả về nhà cung cấp" }
  ],
  "qualityIssues": [
    { "material": "Xi măng", "issue": "Một số bao bị ẩm", "severity": "MEDIUM" }
  ],
  "recommendations": [
    { "action": "Bổ sung cát vàng 2m³", "priority": "HIGH", "timeline": "Trong 2 ngày" }
  ],
  "estimatedCost": 5000000
}`;

      const messages: any[] = [
        {
          role: 'system',
          content: `Bạn là chuyên gia kiểm định vật liệu xây dựng với 15 năm kinh nghiệm.
Nhiệm vụ: Kiểm tra vật liệu, xác nhận chất lượng, phát hiện sai lệch.`,
        },
      ];

      if (dto.imageUrls && dto.imageUrls.length > 0) {
        const imageContent = dto.imageUrls.map((url) => ({
          type: 'image_url',
          image_url: { url },
        }));
        messages.push({
          role: 'user',
          content: [{ type: 'text', text: prompt }, ...imageContent],
        });
      } else {
        messages.push({
          role: 'user',
          content: prompt,
        });
      }

      const completion = await this.openai!.chat.completions.create({
        model:
          dto.imageUrls && dto.imageUrls.length > 0 ? 'gpt-4o' : 'gpt-4o-mini',
        messages,
        temperature: 0.5,
        max_tokens: 3000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0].message.content;
      if (!content) {
        throw new Error('Empty response from OpenAI');
      }

      const aiResponse = JSON.parse(content);

      // Lưu báo cáo vật liệu
      const report = await this.prisma.aIMaterialReport.create({
        data: {
          projectId: dto.projectId,
          reportDate: new Date(),
          title: `Báo cáo kiểm tra vật liệu - ${new Date().toLocaleDateString('vi-VN')}`,
          summary: aiResponse.summary,
          materialsChecked: aiResponse.materialsChecked || [],
          correctMaterials: aiResponse.correctMaterials || 0,
          incorrectMaterials: aiResponse.incorrectMaterials || 0,
          missingMaterials: aiResponse.missingMaterials || [],
          excessMaterials: aiResponse.excessMaterials || [],
          qualityIssues: aiResponse.qualityIssues || [],
          recommendations: aiResponse.recommendations || [],
          estimatedCost: aiResponse.estimatedCost,
          imageUrls: dto.imageUrls || [],
          generatedBy: `OpenAI ${completion.model}`,
        },
      });

      return report;
    } catch (error: unknown) {
      this.logger.error(
        `Material check failed: ${getErrorMessage(error)}`,
        getErrorStack(error),
      );
      throw new BadRequestException(
        `Material check failed: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Lấy lịch sử phân tích tiến độ
   */
  async getProgressAnalyses(projectId: number, phaseId?: number) {
    return this.prisma.aIProgressAnalysis.findMany({
      where: {
        projectId,
        ...(phaseId && { phaseId }),
      },
      orderBy: { analysisDate: 'desc' },
      take: 50,
    });
  }

  /**
   * Lấy báo cáo ngày
   */
  async getDailyReports(
    projectId: number,
    startDate?: string,
    endDate?: string,
  ) {
    return this.prisma.aIDailyReport.findMany({
      where: {
        projectId,
        ...(startDate &&
          endDate && {
            reportDate: {
              gte: new Date(startDate),
              lte: new Date(endDate),
            },
          }),
      },
      orderBy: { reportDate: 'desc' },
      take: 30,
    });
  }

  /**
   * Lấy báo cáo tuần
   */
  async getWeeklyReports(projectId: number, year?: number) {
    return this.prisma.aIWeeklyReport.findMany({
      where: {
        projectId,
        ...(year && { year }),
      },
      orderBy: [{ year: 'desc' }, { weekNumber: 'desc' }],
      take: 20,
    });
  }

  /**
   * Lấy lịch sử chat
   */
  async getChatHistory(projectId: number, userId: number, limit = 50) {
    return this.prisma.aIChatHistory.findMany({
      where: {
        projectId,
        userId,
      },
      orderBy: { createdAt: 'asc' },
      take: limit,
    });
  }

  /**
   * Lấy báo cáo vật liệu
   */
  async getMaterialReports(projectId: number) {
    return this.prisma.aIMaterialReport.findMany({
      where: {
        projectId,
      },
      orderBy: { reportDate: 'desc' },
      take: 20,
    });
  }
}
