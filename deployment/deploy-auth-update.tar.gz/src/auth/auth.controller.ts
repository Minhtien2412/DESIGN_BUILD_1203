import {
    Body,
    Controller,
    Get,
    Headers,
    HttpCode,
    HttpStatus,
    Post,
    Req,
    UseGuards,
    ValidationPipe,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import type { Request } from 'express';
import { AuthService } from './auth.service';
import { CurrentUser } from './decorators';
import { DeviceInfo, DeviceSessionService } from './device-session.service';
import {
    AuthResponseDto,
    ForgotPasswordDto,
    LoginDto,
    RegisterDto,
    ResetPasswordWithOtpDto,
    ResetPasswordWithTokenDto,
    TokensDto,
    VerifyResetOtpDto,
} from './dto';
import { JwtAuthGuard, JwtRefreshAuthGuard } from './guards';

@ApiTags('Authentication')
@Controller({ path: 'auth', version: '1' })
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly deviceSessionService: DeviceSessionService,
  ) {}

  /**
   * Extract device info from request headers
   */
  private extractDeviceInfo(
    req: Request,
    headers: Record<string, string> = {},
  ): DeviceInfo {
    const userAgent = req.headers['user-agent'] as string;
    const parsedInfo = this.deviceSessionService.parseUserAgent(userAgent);

    return {
      ...parsedInfo,
      deviceName: headers['x-device-name'] || parsedInfo.deviceType,
      ipAddress:
        (req.headers['x-forwarded-for'] as string)?.split(',')[0] ||
        req.socket?.remoteAddress ||
        'unknown',
    };
  }

  @Post('register')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Register a new user' })
  @ApiBody({ type: RegisterDto })
  @ApiResponse({
    status: 201,
    description: 'User registered successfully',
    type: AuthResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 409, description: 'Email already exists' })
  async register(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    registerDto: RegisterDto,
    @Req() req: Request,
    @Headers('x-device-name') deviceName?: string,
  ): Promise<AuthResponseDto> {
    const deviceInfo = this.extractDeviceInfo(req, {
      'x-device-name': deviceName || '',
    });
    return this.authService.register(registerDto, deviceInfo);
  }

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Login user' })
  @ApiBody({ type: LoginDto })
  @ApiResponse({
    status: 200,
    description: 'User logged in successfully',
    type: AuthResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Invalid credentials' })
  async login(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    loginDto: LoginDto,
    @Req() req: Request,
    @Headers('x-device-name') deviceName?: string,
  ): Promise<AuthResponseDto> {
    const deviceInfo = this.extractDeviceInfo(req, {
      'x-device-name': deviceName || '',
    });
    return this.authService.login(loginDto, deviceInfo);
  }

  @Post('refresh')
  @UseGuards(JwtRefreshAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Refresh access token (with rotation)' })
  @ApiResponse({
    status: 200,
    description: 'Tokens refreshed successfully',
    type: TokensDto,
  })
  @ApiResponse({ status: 401, description: 'Invalid refresh token' })
  async refresh(
    @CurrentUser() user: any,
    @Req() req: Request,
  ): Promise<TokensDto> {
    const deviceInfo = this.extractDeviceInfo(req);
    return this.authService.refreshTokens(
      user.id,
      user.refreshToken,
      deviceInfo,
    );
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Logout user (revokes current session)' })
  @ApiResponse({ status: 200, description: 'User logged out successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async logout(@CurrentUser() user: any, @Body() body: { sessionId?: string }) {
    return this.authService.logout(user.id, body?.sessionId || user.sessionId);
  }

  @Post('logout-all')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Logout from all devices' })
  @ApiResponse({ status: 200, description: 'Logged out from all devices' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async logoutAll(@CurrentUser() user: any) {
    return this.authService.logoutAllDevices(user.id);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current user profile' })
  @ApiResponse({
    status: 200,
    description: 'User profile retrieved successfully',
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async getCurrentUser(@CurrentUser() user: any) {
    return user;
  }

  @Post('google')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Login/Register with Google OAuth' })
  @ApiResponse({
    status: 200,
    description: 'User authenticated via Google',
    type: AuthResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid Google token' })
  async googleAuth(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: false }))
    body: { token: string; email: string; name?: string; picture?: string },
    @Req() req: Request,
    @Headers('x-device-name') deviceName?: string,
  ): Promise<AuthResponseDto> {
    const deviceInfo = this.extractDeviceInfo(req, {
      'x-device-name': deviceName || '',
    });
    return this.authService.googleLogin(body, deviceInfo);
  }

  @Post('social')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Login/Register with Social OAuth (Google, Facebook)',
  })
  @ApiResponse({
    status: 200,
    description: 'User authenticated via social provider',
    type: AuthResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid token or provider' })
  async socialAuth(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: false }))
    body: {
      provider: string;
      token: string;
      email: string;
      name?: string;
      picture?: string;
    },
    @Req() req: Request,
    @Headers('x-device-name') deviceName?: string,
  ): Promise<AuthResponseDto> {
    const deviceInfo = this.extractDeviceInfo(req, {
      'x-device-name': deviceName || '',
    });
    if (body.provider === 'google') {
      return this.authService.googleLogin(body, deviceInfo);
    }
    // Future: Add Facebook, Apple support
    return this.authService.googleLogin(body, deviceInfo);
  }

  // ============================================
  // SESSION MANAGEMENT ENDPOINTS (AUTH-001)
  // ============================================

  @Get('sessions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'List all active sessions for current user' })
  @ApiResponse({ status: 200, description: 'List of active sessions' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async listSessions(@CurrentUser() user: any) {
    const sessions = await this.deviceSessionService.getUserSessions(user.id);
    return {
      success: true,
      data: {
        sessions,
        currentSessionId: user.sessionId,
      },
    };
  }

  @Post('sessions/:sessionId/revoke')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Revoke a specific session' })
  @ApiResponse({ status: 200, description: 'Session revoked successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async revokeSession(@CurrentUser() user: any, @Req() req: Request) {
    const sessionId = req.params.sessionId;

    // Verify session belongs to user
    const sessions = await this.deviceSessionService.getUserSessions(user.id);
    const targetSession = sessions.find((s) => s.id === sessionId);

    if (!targetSession) {
      return { success: false, message: 'Session not found' };
    }

    await this.deviceSessionService.revokeSession(sessionId, 'Revoked by user');

    return {
      success: true,
      message: 'Session revoked successfully',
    };
  }

  @Post('sessions/revoke-others')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Revoke all sessions except current' })
  @ApiResponse({ status: 200, description: 'Other sessions revoked' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async revokeOtherSessions(@CurrentUser() user: any) {
    const count = await this.deviceSessionService.revokeAllUserSessions(
      user.id,
      'Revoked by user - keep current only',
      user.sessionId,
    );

    return {
      success: true,
      message: `Revoked ${count} other sessions`,
      revokedCount: count,
    };
  }

  // ============================================
  // PASSWORD RESET ENDPOINTS
  // ============================================

  @Post('forgot-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Request password reset - sends OTP to email' })
  @ApiBody({ type: ForgotPasswordDto })
  @ApiResponse({
    status: 200,
    description: 'OTP sent to email if account exists',
  })
  @ApiResponse({
    status: 400,
    description: 'Invalid input or email sending failed',
  })
  async forgotPassword(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    dto: ForgotPasswordDto,
  ) {
    return this.authService.forgotPassword(dto.email);
  }

  @Post('verify-reset-otp')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify OTP for password reset' })
  @ApiBody({ type: VerifyResetOtpDto })
  @ApiResponse({
    status: 200,
    description: 'OTP verified successfully, returns reset token',
  })
  @ApiResponse({ status: 400, description: 'Invalid or expired OTP' })
  async verifyResetOtp(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    dto: VerifyResetOtpDto,
  ) {
    return this.authService.verifyPasswordResetOTP(dto.email, dto.otp);
  }

  @Post('reset-password-otp')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Reset password with email and OTP (one-step flow)',
  })
  @ApiBody({ type: ResetPasswordWithOtpDto })
  @ApiResponse({ status: 200, description: 'Password reset successfully' })
  @ApiResponse({ status: 400, description: 'Invalid OTP or weak password' })
  async resetPasswordWithOtp(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    dto: ResetPasswordWithOtpDto,
  ) {
    return this.authService.resetPasswordWithOTP(
      dto.email,
      dto.otp,
      dto.newPassword,
    );
  }

  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Reset password with token (two-step flow)' })
  @ApiBody({ type: ResetPasswordWithTokenDto })
  @ApiResponse({ status: 200, description: 'Password reset successfully' })
  @ApiResponse({ status: 400, description: 'Invalid token or weak password' })
  async resetPassword(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    dto: ResetPasswordWithTokenDto,
  ) {
    return this.authService.resetPasswordWithToken(dto.token, dto.newPassword);
  }
}
