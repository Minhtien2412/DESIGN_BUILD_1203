/**
 * RBAC Service (AUTH-005)
 * ========================
 *
 * Role-Based Access Control with granular permissions:
 * - Role to permission mapping
 * - Permission checking
 * - Resource-based permissions
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import { Injectable, Logger } from '@nestjs/common';
import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

// ============================================================================
// PERMISSION DEFINITIONS
// ============================================================================

export enum Permission {
  // User Management
  USER_READ = 'user:read',
  USER_CREATE = 'user:create',
  USER_UPDATE = 'user:update',
  USER_DELETE = 'user:delete',
  USER_MANAGE_ROLES = 'user:manage_roles',

  // Project Management
  PROJECT_READ = 'project:read',
  PROJECT_CREATE = 'project:create',
  PROJECT_UPDATE = 'project:update',
  PROJECT_DELETE = 'project:delete',
  PROJECT_ASSIGN = 'project:assign',

  // Task Management
  TASK_READ = 'task:read',
  TASK_CREATE = 'task:create',
  TASK_UPDATE = 'task:update',
  TASK_DELETE = 'task:delete',
  TASK_ASSIGN = 'task:assign',

  // File Management
  FILE_READ = 'file:read',
  FILE_UPLOAD = 'file:upload',
  FILE_DELETE = 'file:delete',
  FILE_SHARE = 'file:share',

  // Chat/Messaging
  CHAT_READ = 'chat:read',
  CHAT_SEND = 'chat:send',
  CHAT_DELETE = 'chat:delete',
  CHAT_CREATE_GROUP = 'chat:create_group',
  CHAT_MANAGE_GROUP = 'chat:manage_group',

  // Products/Marketplace
  PRODUCT_READ = 'product:read',
  PRODUCT_CREATE = 'product:create',
  PRODUCT_UPDATE = 'product:update',
  PRODUCT_DELETE = 'product:delete',
  PRODUCT_APPROVE = 'product:approve',

  // Contracts
  CONTRACT_READ = 'contract:read',
  CONTRACT_CREATE = 'contract:create',
  CONTRACT_UPDATE = 'contract:update',
  CONTRACT_DELETE = 'contract:delete',
  CONTRACT_SIGN = 'contract:sign',

  // Reports & Analytics
  REPORT_READ = 'report:read',
  REPORT_CREATE = 'report:create',
  REPORT_EXPORT = 'report:export',
  ANALYTICS_VIEW = 'analytics:view',

  // Admin
  ADMIN_DASHBOARD = 'admin:dashboard',
  ADMIN_AUDIT_LOGS = 'admin:audit_logs',
  ADMIN_SETTINGS = 'admin:settings',
  ADMIN_SYSTEM = 'admin:system',

  // Moderation
  CONTENT_MODERATE = 'content:moderate',
  CONTENT_BAN_USER = 'content:ban_user',

  // API
  API_FULL_ACCESS = 'api:full_access',
  API_RATE_LIMIT_EXEMPT = 'api:rate_limit_exempt',
}

// ============================================================================
// ROLE-PERMISSION MAPPING
// ============================================================================

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  [Role.CLIENT]: [
    // Basic user permissions
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.TASK_READ,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.PRODUCT_READ,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_SIGN,
    Permission.REPORT_READ,
  ],

  [Role.ENGINEER]: [
    // Client permissions +
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.PROJECT_UPDATE,
    Permission.TASK_READ,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.FILE_DELETE,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.CHAT_CREATE_GROUP,
    Permission.PRODUCT_READ,
    Permission.CONTRACT_READ,
    Permission.REPORT_READ,
    Permission.REPORT_CREATE,
  ],

  [Role.CONTRACTOR]: [
    // Engineer permissions + project management
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.PROJECT_ASSIGN,
    Permission.TASK_READ,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.TASK_DELETE,
    Permission.TASK_ASSIGN,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.FILE_DELETE,
    Permission.FILE_SHARE,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.CHAT_CREATE_GROUP,
    Permission.CHAT_MANAGE_GROUP,
    Permission.PRODUCT_READ,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_CREATE,
    Permission.CONTRACT_UPDATE,
    Permission.CONTRACT_SIGN,
    Permission.REPORT_READ,
    Permission.REPORT_CREATE,
    Permission.REPORT_EXPORT,
  ],

  [Role.ARCHITECT]: [
    // Design focused permissions
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.TASK_READ,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.FILE_DELETE,
    Permission.FILE_SHARE,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.CHAT_CREATE_GROUP,
    Permission.PRODUCT_READ,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_CREATE,
    Permission.CONTRACT_SIGN,
    Permission.REPORT_READ,
    Permission.REPORT_CREATE,
  ],

  [Role.DESIGNER]: [
    // Similar to architect
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.PROJECT_UPDATE,
    Permission.TASK_READ,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.FILE_DELETE,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.CHAT_CREATE_GROUP,
    Permission.PRODUCT_READ,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_SIGN,
    Permission.REPORT_READ,
  ],

  [Role.SUPPLIER]: [
    // Product/marketplace focused
    Permission.USER_READ,
    Permission.PROJECT_READ,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.PRODUCT_READ,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE,
    Permission.PRODUCT_DELETE,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_CREATE,
    Permission.CONTRACT_SIGN,
    Permission.REPORT_READ,
    Permission.ANALYTICS_VIEW,
  ],

  [Role.STAFF]: [
    // Office staff - moderate permissions
    Permission.USER_READ,
    Permission.USER_CREATE,
    Permission.PROJECT_READ,
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.TASK_READ,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.FILE_READ,
    Permission.FILE_UPLOAD,
    Permission.FILE_DELETE,
    Permission.CHAT_READ,
    Permission.CHAT_SEND,
    Permission.CHAT_CREATE_GROUP,
    Permission.CHAT_MANAGE_GROUP,
    Permission.PRODUCT_READ,
    Permission.PRODUCT_UPDATE,
    Permission.CONTRACT_READ,
    Permission.CONTRACT_CREATE,
    Permission.CONTRACT_UPDATE,
    Permission.REPORT_READ,
    Permission.REPORT_CREATE,
    Permission.REPORT_EXPORT,
    Permission.ANALYTICS_VIEW,
    Permission.CONTENT_MODERATE,
  ],

  [Role.ADMIN]: [
    // Full access
    ...Object.values(Permission),
  ],
};

// ============================================================================
// SERVICE
// ============================================================================

@Injectable()
export class RbacService {
  private readonly logger = new Logger(RbacService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Check if a role has a specific permission
   */
  hasPermission(role: Role, permission: Permission): boolean {
    const permissions = ROLE_PERMISSIONS[role] || [];
    return permissions.includes(permission);
  }

  /**
   * Check if a role has any of the specified permissions
   */
  hasAnyPermission(role: Role, permissions: Permission[]): boolean {
    return permissions.some((p) => this.hasPermission(role, p));
  }

  /**
   * Check if a role has all of the specified permissions
   */
  hasAllPermissions(role: Role, permissions: Permission[]): boolean {
    return permissions.every((p) => this.hasPermission(role, p));
  }

  /**
   * Get all permissions for a role
   */
  getPermissions(role: Role): Permission[] {
    return ROLE_PERMISSIONS[role] || [];
  }

  /**
   * Check if user can perform action on resource
   */
  async canAccess(
    userId: number,
    permission: Permission,
    resourceType?: string,
    resourceId?: string,
  ): Promise<boolean> {
    // Get user with role
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { role: true },
    });

    if (!user) return false;

    // Check role permission first
    if (!this.hasPermission(user.role, permission)) {
      return false;
    }

    // If no resource specified, role permission is enough
    if (!resourceType || !resourceId) {
      return true;
    }

    // Check resource-level access (ownership, membership, etc.)
    return this.checkResourceAccess(userId, resourceType, resourceId);
  }

  /**
   * Check resource-level access
   */
  private async checkResourceAccess(
    userId: number,
    resourceType: string,
    resourceId: string,
  ): Promise<boolean> {
    try {
      switch (resourceType) {
        case 'project':
          return this.checkProjectAccess(userId, parseInt(resourceId, 10));
        case 'task':
          return this.checkTaskAccess(userId, parseInt(resourceId, 10));
        case 'file':
          return this.checkFileAccess(userId, parseInt(resourceId, 10));
        case 'conversation':
          return this.checkConversationAccess(userId, resourceId);
        default:
          return true; // No specific check needed
      }
    } catch (error) {
      this.logger.error(`Resource access check failed: ${error.message}`);
      return false;
    }
  }

  private async checkProjectAccess(
    userId: number,
    projectId: number,
  ): Promise<boolean> {
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        OR: [{ clientId: userId }, { engineerId: userId }],
      },
    });
    return !!project;
  }

  private async checkTaskAccess(
    userId: number,
    taskId: number,
  ): Promise<boolean> {
    const task = await this.prisma.task.findFirst({
      where: {
        id: taskId,
        OR: [
          { assigneeId: userId },
          { project: { clientId: userId } },
          { project: { engineerId: userId } },
        ],
      },
    });
    return !!task;
  }

  private async checkFileAccess(
    userId: number,
    fileId: number,
  ): Promise<boolean> {
    // Files don't have direct user ownership in current schema
    // Check if user has access through project or task
    const file = await this.prisma.file.findFirst({
      where: {
        id: fileId,
        OR: [
          { project: { clientId: userId } },
          { project: { engineerId: userId } },
          { task: { assigneeId: userId } },
        ],
      },
    });
    return !!file;
  }

  private async checkConversationAccess(
    userId: number,
    conversationId: string,
  ): Promise<boolean> {
    const participant = await this.prisma.conversationParticipant.findFirst({
      where: {
        conversationId,
        userId,
        leftAt: null,
        removedAt: null,
      },
    });
    return !!participant;
  }

  /**
   * Get role hierarchy level (higher = more permissions)
   */
  getRoleLevel(role: Role): number {
    const levels: Record<Role, number> = {
      [Role.CLIENT]: 1,
      [Role.DESIGNER]: 2,
      [Role.ARCHITECT]: 3,
      [Role.ENGINEER]: 3,
      [Role.SUPPLIER]: 3,
      [Role.CONTRACTOR]: 4,
      [Role.STAFF]: 5,
      [Role.ADMIN]: 10,
    };
    return levels[role] || 0;
  }

  /**
   * Check if role A can manage role B
   */
  canManageRole(managerRole: Role, targetRole: Role): boolean {
    // Only ADMIN can manage other ADMINs
    if (targetRole === Role.ADMIN) {
      return managerRole === Role.ADMIN;
    }

    // Otherwise, higher level can manage lower level
    return this.getRoleLevel(managerRole) > this.getRoleLevel(targetRole);
  }
}
