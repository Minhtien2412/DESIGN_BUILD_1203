interface TokenPayload {
  sub: number;
  email: string;
  role: string; // luôn stringify
  tokenFamily?: string;
  sessionId?: string;
}

import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

import { Role } from '@prisma/client';
// DISABLED: Messaging requires prisma migrate
// import { WelcomeMessageService } from '../conversations/welcome-message.service';
import { EmailService } from '../email/email.service';
import { PrismaService } from '../prisma/prisma.service';
import { DeviceInfo, DeviceSessionService } from './device-session.service';
import { LoginDto, RegisterDto } from './dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  // In-memory OTP storage (consider Redis for production)
  private passwordResetOtps = new Map<
    string,
    { otp: string; expiresAt: Date }
  >();

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly deviceSessionService: DeviceSessionService,
    private readonly emailService: EmailService,
    // private readonly welcomeMessageService: WelcomeMessageService, // DISABLED
  ) {}

  /* ========================
      REGISTER
  ========================== */
  async register(registerDto: RegisterDto, deviceInfo?: DeviceInfo) {
    const { email, password, name, role } = registerDto;

    const existingUser = await this.prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      throw new ConflictException('Email already exists');
    }

    const hashedPassword = await this.hash(password);

    const user = await this.prisma.user.create({
      data: {
        email,
        name,
        password: hashedPassword,
        role: role || Role.CLIENT,
      },
    });

    // Create device session with token rotation support
    const tokens = await this.deviceSessionService.createSession(
      user.id,
      user.email,
      user.role,
      deviceInfo,
    );

    // Legacy: Also store hashed refresh token on user (backwards compatibility)
    await this.updateRefreshToken(user.id, tokens.refreshToken);

    this.logger.log(
      `User registered: ${user.email}, session: ${tokens.sessionId}`,
    );

    // 🎉 Gửi tin nhắn chào mừng từ ADMIN DESIGN BUILD
    // DISABLED: Messaging requires prisma migrate
    // this.welcomeMessageService
    //   .sendWelcomeMessage(user.id, user.name)
    //   .catch((err) => console.error('Failed to send welcome message:', err));

    return {
      ...tokens,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    };
  }

  /* ========================
      LOGIN
  ========================== */
  async login(loginDto: LoginDto, deviceInfo?: DeviceInfo) {
    const { email, password } = loginDto;

    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user) throw new UnauthorizedException('Invalid credentials');

    const valid = await this.compare(password, user.password);

    if (!valid) throw new UnauthorizedException('Invalid credentials');

    // Create device session with token rotation support
    const tokens = await this.deviceSessionService.createSession(
      user.id,
      user.email,
      user.role,
      deviceInfo,
    );

    // Legacy: Also store hashed refresh token on user (backwards compatibility)
    await this.updateRefreshToken(user.id, tokens.refreshToken);

    this.logger.log(
      `User logged in: ${user.email}, session: ${tokens.sessionId}`,
    );

    return {
      ...tokens,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    };
  }

  /* ========================
      REFRESH TOKENS (with rotation)
  ========================== */
  async refreshTokens(
    userId: number,
    refreshToken: string,
    deviceInfo?: DeviceInfo,
  ) {
    try {
      // Try new session-based rotation first
      const tokens = await this.deviceSessionService.refreshWithRotation(
        refreshToken,
        deviceInfo,
      );

      this.logger.log(`Tokens refreshed with rotation for user ${userId}`);
      return tokens;
    } catch (error) {
      // Fallback to legacy refresh for existing tokens without session
      this.logger.warn(
        `Falling back to legacy refresh for user ${userId}: ${error.message}`,
      );
      return this.legacyRefreshTokens(userId, refreshToken);
    }
  }

  /**
   * Legacy refresh token method (backwards compatibility)
   */
  private async legacyRefreshTokens(userId: number, refreshToken: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user || !user.refreshToken)
      throw new UnauthorizedException('Access denied');

    const valid = await this.compare(refreshToken, user.refreshToken);

    if (!valid) throw new UnauthorizedException('Invalid refresh token');

    const tokens = await this.generateTokens(user.id, user.email, user.role);

    await this.updateRefreshToken(user.id, tokens.refreshToken);

    return tokens;
  }

  /* ========================
      LOGOUT
  ========================== */
  async logout(userId: number, sessionId?: string) {
    // If session ID provided, revoke that specific session
    if (sessionId) {
      await this.deviceSessionService.revokeSession(sessionId, 'User logout');
    }

    // Also clear legacy refresh token
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: null },
    });

    this.logger.log(
      `User ${userId} logged out${sessionId ? `, session: ${sessionId}` : ''}`,
    );

    return { message: 'Logged out successfully' };
  }

  /**
   * Logout from all devices
   */
  async logoutAllDevices(userId: number) {
    const count = await this.deviceSessionService.revokeAllUserSessions(
      userId,
      'User logged out from all devices',
    );

    // Also clear legacy refresh token
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: null },
    });

    this.logger.log(
      `User ${userId} logged out from all devices, ${count} sessions revoked`,
    );

    return { message: `Logged out from all devices (${count} sessions)` };
  }

  /* ========================
      TOKEN GENERATOR (FIXED)
  ========================== */
  private async generateTokens(userId: number, email: string, role: Role) {
    const payload = {
      sub: userId,
      email,
      role: role.toString(),
    };

    const accessToken = await this.jwtService.signAsync(payload, {
      secret: this.config.get<string>('JWT_SECRET'),
      expiresIn: this.config.get<string>('JWT_EXPIRES_IN') || '7d',
    } as any);

    const refreshToken = await this.jwtService.signAsync(payload, {
      secret:
        this.config.get<string>('JWT_REFRESH_SECRET') ||
        this.config.get<string>('JWT_SECRET'),
      expiresIn: this.config.get<string>('JWT_REFRESH_EXPIRES_IN') || '30d',
    } as any);

    return { accessToken, refreshToken };
  }

  /* ========================
      REFRESH TOKEN HASHING
  ========================== */
  private async updateRefreshToken(userId: number, refreshToken: string) {
    const hashedRT = await this.hash(refreshToken);

    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: hashedRT },
    });
  }

  /* ========================
      PASSWORD METHODS
  ========================== */
  private hash(data: string) {
    return bcrypt.hash(data, 10);
  }

  private compare(data: string, hashed: string) {
    return bcrypt.compare(data, hashed);
  }

  /* ========================
      GET PROFILE
  ========================== */
  async validateUser(userId: number) {
    return this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });
  }

  /* ========================
      GOOGLE LOGIN
  ========================== */
  async googleLogin(
    body: {
      token: string;
      email: string;
      name?: string;
      picture?: string;
    },
    deviceInfo?: DeviceInfo,
  ) {
    const { email, name, picture } = body;

    // Check if user exists
    let user = await this.prisma.user.findUnique({
      where: { email },
    });

    const isNewUser = !user;

    if (!user) {
      // Create new user with Google info
      const randomPassword = await this.hash(
        `google_${Date.now()}_${Math.random()}`,
      );

      user = await this.prisma.user.create({
        data: {
          email,
          name: name || email.split('@')[0],
          password: randomPassword,
          role: Role.CLIENT,
          // picture field can be added to User model if needed
        },
      });
    }

    // Create device session with token rotation support
    const tokens = await this.deviceSessionService.createSession(
      user.id,
      user.email,
      user.role,
      deviceInfo,
    );

    // Legacy: Also store hashed refresh token
    await this.updateRefreshToken(user.id, tokens.refreshToken);

    this.logger.log(
      `Google login: ${user.email}, new: ${isNewUser}, session: ${tokens.sessionId}`,
    );

    // 🎉 Gửi tin nhắn chào mừng cho user mới từ ADMIN DESIGN BUILD
    // DISABLED: Messaging requires prisma migrate
    // if (isNewUser) {
    //   this.welcomeMessageService
    //     .sendWelcomeMessage(user.id, user.name)
    //     .catch((err) => console.error('Failed to send welcome message:', err));
    // }

    return {
      ...tokens,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    };
  }

  /* ========================
      FORGOT PASSWORD
  ========================== */

  /**
   * Generate 6-digit OTP code
   */
  private generateOTP(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  /**
   * Request password reset - sends OTP to email
   */
  async forgotPassword(
    email: string,
  ): Promise<{ success: boolean; message: string }> {
    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    // Don't reveal if user exists or not for security
    if (!user) {
      this.logger.warn(
        `Password reset requested for non-existent email: ${email}`,
      );
      // Still return success to prevent email enumeration
      return {
        success: true,
        message:
          'Nếu email tồn tại trong hệ thống, bạn sẽ nhận được mã xác nhận.',
      };
    }

    // Generate OTP
    const otp = this.generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP
    this.passwordResetOtps.set(email.toLowerCase(), { otp, expiresAt });

    // Send email
    const emailSent = await this.emailService.sendPasswordResetOTP(
      email,
      otp,
      10,
    );

    if (!emailSent) {
      this.logger.error(`Failed to send password reset email to: ${email}`);
      throw new BadRequestException(
        'Không thể gửi email. Vui lòng thử lại sau.',
      );
    }

    this.logger.log(`Password reset OTP sent to: ${email}`);

    return {
      success: true,
      message: 'Mã xác nhận đã được gửi đến email của bạn.',
    };
  }

  /**
   * Verify OTP and reset password
   */
  async resetPasswordWithOTP(
    email: string,
    otp: string,
    newPassword: string,
  ): Promise<{ success: boolean; message: string }> {
    const stored = this.passwordResetOtps.get(email.toLowerCase());

    if (!stored) {
      throw new BadRequestException(
        'Mã xác nhận không hợp lệ hoặc đã hết hạn.',
      );
    }

    if (new Date() > stored.expiresAt) {
      this.passwordResetOtps.delete(email.toLowerCase());
      throw new BadRequestException(
        'Mã xác nhận đã hết hạn. Vui lòng yêu cầu mã mới.',
      );
    }

    if (stored.otp !== otp) {
      throw new BadRequestException('Mã xác nhận không chính xác.');
    }

    // Find user
    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      throw new NotFoundException('Không tìm thấy tài khoản.');
    }

    // Validate password strength
    if (newPassword.length < 6) {
      throw new BadRequestException('Mật khẩu phải có ít nhất 6 ký tự.');
    }

    // Hash new password
    const hashedPassword = await this.hash(newPassword);

    // Update password
    await this.prisma.user.update({
      where: { id: user.id },
      data: { password: hashedPassword },
    });

    // Clear OTP
    this.passwordResetOtps.delete(email.toLowerCase());

    // Revoke all sessions for security
    await this.deviceSessionService.revokeAllUserSessions(
      user.id,
      'Password reset - all sessions revoked',
    );

    // Send confirmation email
    await this.emailService.sendPasswordResetConfirmation(email);

    this.logger.log(`Password reset successful for: ${email}`);

    return {
      success: true,
      message: 'Mật khẩu đã được đặt lại thành công. Vui lòng đăng nhập lại.',
    };
  }

  /**
   * Verify OTP only (for step-by-step flow)
   */
  async verifyPasswordResetOTP(
    email: string,
    otp: string,
  ): Promise<{ success: boolean; message: string; token?: string }> {
    const stored = this.passwordResetOtps.get(email.toLowerCase());

    if (!stored) {
      throw new BadRequestException(
        'Mã xác nhận không hợp lệ hoặc đã hết hạn.',
      );
    }

    if (new Date() > stored.expiresAt) {
      this.passwordResetOtps.delete(email.toLowerCase());
      throw new BadRequestException(
        'Mã xác nhận đã hết hạn. Vui lòng yêu cầu mã mới.',
      );
    }

    if (stored.otp !== otp) {
      throw new BadRequestException('Mã xác nhận không chính xác.');
    }

    // Generate a temporary token for password reset
    const resetToken = await this.jwtService.signAsync(
      { email, purpose: 'password-reset' },
      {
        secret: this.config.get<string>('JWT_SECRET'),
        expiresIn: '10m',
      },
    );

    return {
      success: true,
      message: 'Xác nhận OTP thành công.',
      token: resetToken,
    };
  }

  /**
   * Reset password with token (from verify OTP)
   */
  async resetPasswordWithToken(
    token: string,
    newPassword: string,
  ): Promise<{ success: boolean; message: string }> {
    try {
      const payload = await this.jwtService.verifyAsync(token, {
        secret: this.config.get<string>('JWT_SECRET'),
      });

      if (payload.purpose !== 'password-reset') {
        throw new BadRequestException('Token không hợp lệ.');
      }

      const email = payload.email;

      // Find user
      const user = await this.prisma.user.findUnique({
        where: { email },
      });

      if (!user) {
        throw new NotFoundException('Không tìm thấy tài khoản.');
      }

      // Validate password strength
      if (newPassword.length < 6) {
        throw new BadRequestException('Mật khẩu phải có ít nhất 6 ký tự.');
      }

      // Hash new password
      const hashedPassword = await this.hash(newPassword);

      // Update password
      await this.prisma.user.update({
        where: { id: user.id },
        data: { password: hashedPassword },
      });

      // Clear any stored OTP
      this.passwordResetOtps.delete(email.toLowerCase());

      // Revoke all sessions for security
      await this.deviceSessionService.revokeAllUserSessions(
        user.id,
        'Password reset - all sessions revoked',
      );

      // Send confirmation email
      await this.emailService.sendPasswordResetConfirmation(email);

      this.logger.log(`Password reset with token successful for: ${email}`);

      return {
        success: true,
        message: 'Mật khẩu đã được đặt lại thành công. Vui lòng đăng nhập lại.',
      };
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new BadRequestException(
          'Token đã hết hạn. Vui lòng yêu cầu mã mới.',
        );
      }
      throw error;
    }
  }
}
