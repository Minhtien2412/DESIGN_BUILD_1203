/**
 * OTP Authentication Controller
 * REST API for OTP-based login and registration
 *
 * @module auth/otp.controller
 * @created 2026-01-22
 */

import {
    Body,
    Controller,
    Headers,
    HttpCode,
    HttpStatus,
    Post,
    Req,
} from '@nestjs/common';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { OtpChannel, OtpPurpose, OtpService } from './otp.service';

// =====================
// DTOs
// =====================

class SendOtpDto {
  /**
   * Phone number or email
   * @example '+84912345678' or 'user@example.com'
   */
  identifier: string;

  /**
   * Delivery channel
   * @example 'SMS'
   */
  channel: OtpChannel;

  /**
   * Purpose of OTP
   * @example 'LOGIN'
   */
  purpose: OtpPurpose;
}

class VerifyOtpDto {
  /**
   * Phone number or email
   * @example '+84912345678'
   */
  identifier: string;

  /**
   * OTP code
   * @example '123456'
   */
  otp: string;

  /**
   * Delivery channel
   * @example 'SMS'
   */
  channel: OtpChannel;

  /**
   * Purpose of OTP
   * @example 'LOGIN'
   */
  purpose: OtpPurpose;
}

// =====================
// Controller
// =====================

@ApiTags('OTP Auth')
@Controller('auth/otp')
export class OtpController {
  constructor(private readonly otpService: OtpService) {}

  /**
   * Request OTP code
   */
  @Post('send')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Send OTP',
    description:
      'Request an OTP code via SMS, Email, or WhatsApp for login/registration',
  })
  @ApiBody({ type: SendOtpDto })
  @ApiResponse({
    status: 200,
    description: 'OTP sent successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean' },
        message: { type: 'string' },
        expiresIn: { type: 'number', description: 'Seconds until OTP expires' },
        cooldownSeconds: {
          type: 'number',
          description: 'Seconds until next OTP can be requested',
        },
      },
    },
  })
  @ApiResponse({ status: 429, description: 'Too many requests' })
  async sendOtp(@Body() body: SendOtpDto) {
    return this.otpService.sendOtp(body.identifier, body.channel, body.purpose);
  }

  /**
   * Verify OTP and authenticate
   */
  @Post('verify')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Verify OTP',
    description:
      'Verify OTP code and login/register. Creates account if first time login.',
  })
  @ApiBody({ type: VerifyOtpDto })
  @ApiResponse({
    status: 200,
    description: 'OTP verified, login successful',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean' },
        message: { type: 'string' },
        accessToken: { type: 'string' },
        refreshToken: { type: 'string' },
        sessionId: { type: 'string' },
        user: {
          type: 'object',
          properties: {
            id: { type: 'number' },
            email: { type: 'string' },
            name: { type: 'string' },
            role: { type: 'string' },
            isNewUser: { type: 'boolean' },
          },
        },
      },
    },
  })
  @ApiResponse({ status: 400, description: 'Invalid or expired OTP' })
  @ApiResponse({ status: 401, description: 'Wrong OTP code' })
  @ApiResponse({ status: 429, description: 'Too many failed attempts' })
  async verifyOtp(
    @Body() body: VerifyOtpDto,
    @Headers('user-agent') userAgent: string,
    @Headers('x-forwarded-for') forwardedFor: string,
    @Req() req: any,
  ) {
    const deviceInfo = {
      userAgent,
      ipAddress: forwardedFor || req.ip,
      deviceName: this.parseDeviceName(userAgent),
    };

    return this.otpService.verifyOtp(
      body.identifier,
      body.otp,
      body.channel,
      body.purpose,
      deviceInfo,
    );
  }

  // =====================
  // Helper Methods
  // =====================

  private parseDeviceName(userAgent?: string): string {
    if (!userAgent) return 'Unknown Device';

    if (userAgent.includes('iPhone')) return 'iPhone';
    if (userAgent.includes('iPad')) return 'iPad';
    if (userAgent.includes('Android')) return 'Android Device';
    if (userAgent.includes('Windows')) return 'Windows PC';
    if (userAgent.includes('Macintosh')) return 'Mac';
    if (userAgent.includes('Linux')) return 'Linux PC';

    return 'Unknown Device';
  }
}
