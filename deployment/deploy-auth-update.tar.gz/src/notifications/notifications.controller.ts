import { Controller, Get, Post, Body, Patch, Param, Query, UseGuards, Request, HttpCode, HttpStatus, ParseIntPipe } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { NotificationQueryDto } from './dto/notification-query.dto';

@Controller('notifications')
@UseGuards(JwtAuthGuard)
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Request() req, @Body() body: any) {
    const userId = req.user.id;
    const { type, title, body: message, priority, metadata } = body;

    // Parse metadata if string
    let parsedMetadata = metadata;
    if (typeof metadata === 'string') {
      try {
        parsedMetadata = JSON.parse(metadata);
      } catch (e) {
        parsedMetadata = {};
      }
    }

    return this.notificationsService.create({
      userId,
      type: type || 'IN_APP',
      title,
      message,
      priority: priority || 'MEDIUM',
      data: parsedMetadata,
    });
  }

  @Get()
  async findAll(@Request() req, @Query() query: NotificationQueryDto) {
    const userId = req.user.id;
    return this.notificationsService.findAll(userId, query);
  }

  @Get('unread-count')
  async getUnreadCount(@Request() req) {
    const userId = req.user.id;
    return this.notificationsService.getUnreadCount(userId);
  }

  @Patch(':id/read')
  @HttpCode(HttpStatus.OK)
  async markAsRead(@Request() req, @Param('id', ParseIntPipe) id: number) {
    const userId = req.user.id;
    return this.notificationsService.markAsRead(id, userId);
  }

  @Patch('read-all')
  @HttpCode(HttpStatus.OK)
  async markAllAsRead(@Request() req) {
    const userId = req.user.id;
    return this.notificationsService.markAllAsRead(userId);
  }

  @Patch(':id/archive')
  @HttpCode(HttpStatus.NO_CONTENT)
  async archive(@Request() req, @Param('id', ParseIntPipe) id: number) {
    const userId = req.user.id;
    await this.notificationsService.delete(id, userId);
  }
}
