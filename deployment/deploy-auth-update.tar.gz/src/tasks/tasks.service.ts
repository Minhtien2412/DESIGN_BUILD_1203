import { Injectable, NotFoundException } from '@nestjs/common';
import { TimelineEventType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ProgressGateway } from '../progress/progress.gateway';
import { CreateTaskDto, UpdateTaskDto } from './dto';

@Injectable()
export class TasksService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly progressGateway: ProgressGateway,
  ) {}

  async create(createTaskDto: CreateTaskDto, userId: number) {
    const { dueDate, ...taskData } = createTaskDto;

    const task = await this.prisma.task.create({
      data: {
        ...taskData,
        dueDate: dueDate ? new Date(dueDate) : null,
      },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    // Create timeline event
    await this.prisma.timeline.create({
      data: {
        projectId: task.projectId,
        eventType: TimelineEventType.TASK_CREATED,
        description: `Task "${task.title}" was created`,
        userId,
      },
    });

    return task;
  }

  async findAll(projectId?: number) {
    return this.prisma.task.findMany({
      where: projectId ? { projectId } : undefined,
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
        _count: { select: { comments: true, files: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    const task = await this.prisma.task.findUnique({
      where: { id },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
        comments: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { comments: true, files: true } },
      },
    });

    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }

    return task;
  }

  async update(id: number, updateTaskDto: UpdateTaskDto, userId: number) {
    await this.findOne(id);

    const { dueDate, status: newStatus, ...updateData } = updateTaskDto;

    const task = await this.prisma.task.update({
      where: { id },
      data: {
        ...updateData,
        ...(dueDate && { dueDate: new Date(dueDate) }),
        ...(newStatus && { status: newStatus }),
      },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    // Create timeline event
    if (newStatus) {
      await this.prisma.timeline.create({
        data: {
          projectId: task.projectId,
          eventType: TimelineEventType.TASK_UPDATED,
          description: `Task "${task.title}" status changed to ${newStatus}`,
          userId,
          metadata: { taskId: task.id, newStatus },
        },
      });
    }

    // Emit real-time progress update via WebSocket
    try {
      const progress = await this.getProgress(id);
      this.progressGateway.emitTaskProgress(id, progress);
    } catch (error: unknown) {
      // Log error but don't fail the update
      console.error('Failed to emit task progress update:', error);
    }

    return task;
  }

  async remove(id: number) {
    const task = await this.findOne(id);

    await this.prisma.task.delete({
      where: { id },
    });

    return { message: `Task with ID ${id} has been deleted` };
  }

  async getProgress(id: number) {
    const task = await this.prisma.task.findUnique({
      where: { id },
      include: {
        assignee: { 
          select: { 
            id: true, 
            name: true, 
            email: true
          } 
        },
        project: { 
          select: { 
            id: true, 
            title: true,
            status: true 
          } 
        },
        comments: {
          select: { id: true }
        },
        files: {
          select: { id: true }
        }
      },
    });

    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }

    // Calculate progress based on task status
    let progress = 0;
    switch (task.status) {
      case 'TODO':
        progress = 0;
        break;
      case 'IN_PROGRESS':
        progress = 50;
        break;
      case 'DONE':
        progress = 100;
        break;
      default:
        progress = 0;
    }

    // Calculate subtask completion (if you have subtasks in your schema)
    // For now, using comments and files as progress indicators
    const totalActivity = task.comments.length + task.files.length;
    const activityProgress = Math.min(totalActivity * 5, 50); // Max 50% from activity

    const finalProgress = task.status === 'DONE' ? 100 : 
                          task.status === 'IN_PROGRESS' ? Math.max(progress, activityProgress) : 
                          activityProgress;

    return {
      taskId: task.id,
      name: task.title,
      description: task.description,
      status: task.status,
      progress: Math.min(finalProgress, 100),
      priority: task.priority,
      completedSubtasks: task.status === 'DONE' ? 1 : 0,
      totalSubtasks: 1,
      activityCount: {
        comments: task.comments.length,
        files: task.files.length,
      },
      startDate: task.createdAt,
      dueDate: task.dueDate,
      assignees: task.assignee ? [
        {
          id: task.assignee.id,
          name: task.assignee.name,
          email: task.assignee.email,
        }
      ] : [],
      project: task.project,
      lastUpdate: task.updatedAt,
    };
  }

  // ==================== STRAPI SYNC METHODS ====================

  /**
   * Find task by Strapi ID
   */
  async findByStrapiId(strapiId: string) {
    return this.prisma.task.findUnique({
      where: { strapiId },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });
  }

  /**
   * Create task from Strapi sync (without userId requirement)
   */
  async createFromStrapi(data: any) {
    return this.prisma.task.create({
      data: {
        title: data.title,
        description: data.description,
        status: data.status || 'TODO',
        priority: data.priority || 'MEDIUM',
        dueDate: data.dueDate ? new Date(data.dueDate) : null,
        projectId: data.projectId,
        assigneeId: data.assigneeId,
        strapiId: data.strapiId,
      },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });
  }

  /**
   * Update task from Strapi sync
   */
  async updateFromStrapi(id: number, data: any) {
    return this.prisma.task.update({
      where: { id },
      data: {
        title: data.title,
        description: data.description,
        status: data.status,
        priority: data.priority,
        dueDate: data.dueDate ? new Date(data.dueDate) : null,
        assigneeId: data.assigneeId,
      },
      include: {
        assignee: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });
  }

  /**
   * Delete task by ID (without userId requirement for sync)
   */
  async removeById(id: number) {
    await this.prisma.task.delete({ where: { id } });
    return { deleted: true, id };
  }
}
