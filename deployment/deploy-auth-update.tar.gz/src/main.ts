import { ValidationPipe, VersioningType } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { join } from 'path';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Serve static files from public directory
  app.useStaticAssets(join(__dirname, '..', 'public'));

  // Enable global validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Enable CORS
  app.enableCors();

  // API Versioning
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
    prefix: 'api/v',
  });

  // Swagger configuration
  const config = new DocumentBuilder()
    .setTitle('Baotienweb API')
    .setDescription(
      'API documentation for Baotienweb backend - Project Management System',
    )
    .setVersion('1.0')
    .addServer('https://baotienweb.cloud', 'Production')
    .addServer('http://localhost:3000', 'Development')
    .addTag('Users')
    .addTag('Authentication')
    .addTag('Projects')
    .addTag('Tasks')
    .addTag('Comments')
    .addTag('Chat')
    .addTag('Upload')
    .addTag('Video Call')
    .addTag('Payment')
    .addTag('AI Agent')
    .addTag('Dashboard')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  await app.listen(process.env.PORT ?? 3000);
  console.log(
    `Application is running on: http://localhost:${process.env.PORT ?? 3000}`,
  );
  console.log(
    `Swagger docs available at: http://localhost:${process.env.PORT ?? 3000}/api/docs`,
  );
  console.log(
    `API v1 endpoints: http://localhost:${process.env.PORT ?? 3000}/api/v1/`,
  );
}
bootstrap();
