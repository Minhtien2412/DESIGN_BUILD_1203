/**
 * Audit Log Service (Simplified)
 * Provides comprehensive audit logging for security-critical operations
 * Uses raw SQL to work without Prisma model
 *
 * Features:
 * - Structured JSON console logging
 * - Database logging via raw SQL (after migration)
 * - Auth events (login, logout, password change, 2FA)
 * - Admin events (user management, role changes)
 * - File events (upload, download, delete, share)
 */

import {
    Injectable,
    Logger,
    OnModuleDestroy,
    OnModuleInit,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { Request } from 'express';

import { PrismaService } from '../prisma/prisma.service';

// ============= Types & Enums =============

export enum AuditCategory {
  AUTH = 'auth',
  ADMIN = 'admin',
  FILE = 'file',
  RESOURCE = 'resource',
  SECURITY = 'security',
  SYSTEM = 'system',
}

export enum AuditAction {
  // Auth events
  LOGIN_SUCCESS = 'login_success',
  LOGIN_FAILED = 'login_failed',
  LOGOUT = 'logout',
  PASSWORD_CHANGE = 'password_change',
  PASSWORD_RESET_REQUEST = 'password_reset_request',
  PASSWORD_RESET_COMPLETE = 'password_reset_complete',
  TOTP_ENABLED = 'totp_enabled',
  TOTP_DISABLED = 'totp_disabled',
  TOTP_VERIFY_SUCCESS = 'totp_verify_success',
  TOTP_VERIFY_FAILED = 'totp_verify_failed',
  SESSION_CREATED = 'session_created',
  SESSION_REVOKED = 'session_revoked',
  TOKEN_REFRESHED = 'token_refreshed',
  OTP_SENT = 'otp_sent',
  OTP_VERIFIED = 'otp_verified',
  OTP_FAILED = 'otp_failed',

  // Admin events
  USER_CREATED = 'user_created',
  USER_UPDATED = 'user_updated',
  USER_DELETED = 'user_deleted',
  USER_SUSPENDED = 'user_suspended',
  USER_ACTIVATED = 'user_activated',
  ROLE_ASSIGNED = 'role_assigned',
  ROLE_REVOKED = 'role_revoked',
  PERMISSION_GRANTED = 'permission_granted',
  PERMISSION_REVOKED = 'permission_revoked',
  SETTINGS_CHANGED = 'settings_changed',

  // File events
  FILE_UPLOADED = 'file_uploaded',
  FILE_DOWNLOADED = 'file_downloaded',
  FILE_DELETED = 'file_deleted',
  FILE_SHARED = 'file_shared',
  FILE_UNSHARED = 'file_unshared',
  FILE_RESTORED = 'file_restored',
  FILE_VERSION_CREATED = 'file_version_created',

  // Resource events
  RESOURCE_CREATED = 'resource_created',
  RESOURCE_UPDATED = 'resource_updated',
  RESOURCE_DELETED = 'resource_deleted',
  RESOURCE_VIEWED = 'resource_viewed',
  RESOURCE_EXPORTED = 'resource_exported',

  // Security events
  SUSPICIOUS_ACTIVITY = 'suspicious_activity',
  RATE_LIMIT_EXCEEDED = 'rate_limit_exceeded',
  UNAUTHORIZED_ACCESS = 'unauthorized_access',
  IP_BLOCKED = 'ip_blocked',
  ACCOUNT_LOCKED = 'account_locked',
}

export enum AuditSeverity {
  INFO = 'info',
  WARNING = 'warning',
  ERROR = 'error',
  CRITICAL = 'critical',
}

export interface AuditLogEntry {
  id?: string;
  timestamp: Date;
  category: AuditCategory;
  action: AuditAction | string;
  severity: AuditSeverity;
  userId?: number;
  userEmail?: string;
  targetUserId?: number;
  targetResourceType?: string;
  targetResourceId?: string;
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
  requestId?: string;
  requestPath?: string;
  requestMethod?: string;
  details?: Record<string, unknown>;
  outcome: 'success' | 'failure';
  errorMessage?: string;
}

export interface AuditLogFilter {
  category?: AuditCategory;
  action?: AuditAction | string;
  severity?: AuditSeverity;
  userId?: number;
  targetUserId?: number;
  ipAddress?: string;
  startDate?: Date;
  endDate?: Date;
  outcome?: 'success' | 'failure';
  limit?: number;
  offset?: number;
}

// ============= Service =============

@Injectable()
export class AuditLogService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(AuditLogService.name);
  private readonly logToConsole: boolean;
  private readonly logToDatabase: boolean;
  private tableExists = false;

  // Buffer for batch inserts
  private logBuffer: AuditLogEntry[] = [];
  private readonly bufferSize: number = 50;
  private readonly flushIntervalMs: number = 5000;
  private flushTimer: NodeJS.Timeout | null = null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.logToConsole = this.config.get('AUDIT_LOG_CONSOLE') !== 'false';
    this.logToDatabase = this.config.get('AUDIT_LOG_DATABASE') !== 'false';
  }

  async onModuleInit() {
    // Check if table exists
    await this.checkTableExists();

    // Start periodic flush
    this.flushTimer = setInterval(() => {
      this.flushBuffer();
    }, this.flushIntervalMs);

    this.logger.log(
      `AuditLogService initialized. Table exists: ${this.tableExists}`,
    );
  }

  onModuleDestroy() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
    }
    // Final flush
    this.flushBuffer();
  }

  /**
   * Check if audit_logs table exists
   */
  private async checkTableExists(): Promise<boolean> {
    try {
      const result = await this.prisma.$queryRaw<{ exists: boolean }[]>`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_name = 'audit_logs'
        ) as exists
      `;
      this.tableExists = result[0]?.exists ?? false;
      return this.tableExists;
    } catch {
      this.tableExists = false;
      return false;
    }
  }

  /**
   * Log an audit event
   */
  async log(entry: Omit<AuditLogEntry, 'timestamp'>): Promise<void> {
    const fullEntry: AuditLogEntry = {
      ...entry,
      timestamp: new Date(),
    };

    // Console logging with structured format
    if (this.logToConsole) {
      this.logToConsoleFormatted(fullEntry);
    }

    // Database logging (buffered)
    if (this.logToDatabase && this.tableExists) {
      this.logBuffer.push(fullEntry);

      if (this.logBuffer.length >= this.bufferSize) {
        await this.flushBuffer();
      }
    }
  }

  /**
   * Quick helper for auth events
   */
  async logAuth(
    action: AuditAction,
    userId: number | undefined,
    outcome: 'success' | 'failure',
    req?: Request,
    details?: Record<string, unknown>,
    errorMessage?: string,
  ): Promise<void> {
    const severity = this.getSeverityForAction(action, outcome);

    await this.log({
      category: AuditCategory.AUTH,
      action,
      severity,
      userId,
      outcome,
      details,
      errorMessage,
      ...(req && this.extractRequestInfo(req)),
    });
  }

  /**
   * Quick helper for admin events
   */
  async logAdmin(
    action: AuditAction,
    adminUserId: number,
    targetUserId: number | undefined,
    outcome: 'success' | 'failure',
    details?: Record<string, unknown>,
    req?: Request,
  ): Promise<void> {
    await this.log({
      category: AuditCategory.ADMIN,
      action,
      severity: AuditSeverity.WARNING,
      userId: adminUserId,
      targetUserId,
      outcome,
      details,
      ...(req && this.extractRequestInfo(req)),
    });
  }

  /**
   * Quick helper for file events
   */
  async logFile(
    action: AuditAction,
    userId: number,
    fileId: string,
    outcome: 'success' | 'failure',
    details?: Record<string, unknown>,
    req?: Request,
  ): Promise<void> {
    await this.log({
      category: AuditCategory.FILE,
      action,
      severity: AuditSeverity.INFO,
      userId,
      targetResourceType: 'file',
      targetResourceId: fileId,
      outcome,
      details,
      ...(req && this.extractRequestInfo(req)),
    });
  }

  /**
   * Log security event (always high priority)
   */
  async logSecurity(
    action: AuditAction,
    severity: AuditSeverity,
    details: Record<string, unknown>,
    req?: Request,
    userId?: number,
  ): Promise<void> {
    await this.log({
      category: AuditCategory.SECURITY,
      action,
      severity,
      userId,
      outcome: 'failure',
      details,
      ...(req && this.extractRequestInfo(req)),
    });

    // Also log to console immediately for security events
    if (severity === AuditSeverity.CRITICAL) {
      this.logger.error(`SECURITY ALERT: ${action}`, JSON.stringify(details));
    }
  }

  /**
   * Query audit logs (requires table to exist)
   */
  async query(filter: AuditLogFilter): Promise<{
    logs: AuditLogEntry[];
    total: number;
  }> {
    if (!this.tableExists) {
      await this.checkTableExists();
      if (!this.tableExists) {
        this.logger.warn(
          'audit_logs table does not exist. Run migration first.',
        );
        return { logs: [], total: 0 };
      }
    }

    // Build WHERE conditions
    const conditions: string[] = [];
    const params: unknown[] = [];
    let paramIndex = 1;

    if (filter.category) {
      conditions.push(`category = $${paramIndex++}`);
      params.push(filter.category);
    }
    if (filter.action) {
      conditions.push(`action = $${paramIndex++}`);
      params.push(filter.action);
    }
    if (filter.severity) {
      conditions.push(`severity = $${paramIndex++}`);
      params.push(filter.severity);
    }
    if (filter.userId) {
      conditions.push(`user_id = $${paramIndex++}`);
      params.push(filter.userId);
    }
    if (filter.targetUserId) {
      conditions.push(`target_user_id = $${paramIndex++}`);
      params.push(filter.targetUserId);
    }
    if (filter.ipAddress) {
      conditions.push(`ip_address = $${paramIndex++}`);
      params.push(filter.ipAddress);
    }
    if (filter.outcome) {
      conditions.push(`outcome = $${paramIndex++}`);
      params.push(filter.outcome);
    }
    if (filter.startDate) {
      conditions.push(`timestamp >= $${paramIndex++}`);
      params.push(filter.startDate);
    }
    if (filter.endDate) {
      conditions.push(`timestamp <= $${paramIndex++}`);
      params.push(filter.endDate);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const limit = filter.limit || 100;
    const offset = filter.offset || 0;

    try {
      // Count total
      const countResult = await this.prisma.$queryRawUnsafe<
        { count: bigint }[]
      >(`SELECT COUNT(*) as count FROM audit_logs ${whereClause}`, ...params);
      const total = Number(countResult[0]?.count ?? 0);

      // Get logs
      const logs = await this.prisma.$queryRawUnsafe<AuditLogEntry[]>(
        `SELECT * FROM audit_logs ${whereClause} ORDER BY timestamp DESC LIMIT ${limit} OFFSET ${offset}`,
        ...params,
      );

      return { logs, total };
    } catch (error) {
      this.logger.error('Failed to query audit logs', error);
      return { logs: [], total: 0 };
    }
  }

  /**
   * Get audit logs for a specific user
   */
  async getUserLogs(userId: number, limit = 50): Promise<AuditLogEntry[]> {
    const result = await this.query({ userId, limit });
    return result.logs;
  }

  /**
   * Get recent security events
   */
  async getSecurityEvents(hours = 24): Promise<AuditLogEntry[]> {
    const startDate = new Date(Date.now() - hours * 60 * 60 * 1000);
    const result = await this.query({
      category: AuditCategory.SECURITY,
      startDate,
      limit: 100,
    });
    return result.logs;
  }

  // ============= Private Methods =============

  private async flushBuffer(): Promise<void> {
    if (this.logBuffer.length === 0 || !this.tableExists) return;

    const entries = [...this.logBuffer];
    this.logBuffer = [];

    try {
      // Batch insert using raw SQL
      for (const entry of entries) {
        await this.prisma.$executeRaw`
          INSERT INTO audit_logs (
            timestamp, category, action, severity, outcome,
            user_id, user_email, target_user_id,
            target_resource_type, target_resource_id,
            ip_address, user_agent, session_id,
            request_id, request_path, request_method,
            details, error_message
          ) VALUES (
            ${entry.timestamp}, ${entry.category}, ${entry.action}, ${entry.severity}, ${entry.outcome},
            ${entry.userId ?? null}, ${entry.userEmail ?? null}, ${entry.targetUserId ?? null},
            ${entry.targetResourceType ?? null}, ${entry.targetResourceId ?? null},
            ${entry.ipAddress ?? null}, ${entry.userAgent ?? null}, ${entry.sessionId ?? null},
            ${entry.requestId ?? null}, ${entry.requestPath ?? null}, ${entry.requestMethod ?? null},
            ${entry.details ? JSON.stringify(entry.details) : null}::jsonb, ${entry.errorMessage ?? null}
          )
        `;
      }
    } catch (error) {
      // Put entries back in buffer on failure
      this.logBuffer.push(...entries);
      this.logger.error('Failed to flush audit log buffer', error);
    }
  }

  private logToConsoleFormatted(entry: AuditLogEntry): void {
    const logObj = {
      '@timestamp': entry.timestamp.toISOString(),
      category: entry.category,
      action: entry.action,
      severity: entry.severity,
      outcome: entry.outcome,
      userId: entry.userId,
      ip: entry.ipAddress,
      path: entry.requestPath,
      ...(entry.details && { details: entry.details }),
      ...(entry.errorMessage && { error: entry.errorMessage }),
    };

    const logLine = JSON.stringify(logObj);

    switch (entry.severity) {
      case AuditSeverity.CRITICAL:
      case AuditSeverity.ERROR:
        this.logger.error(`[AUDIT] ${logLine}`);
        break;
      case AuditSeverity.WARNING:
        this.logger.warn(`[AUDIT] ${logLine}`);
        break;
      default:
        this.logger.log(`[AUDIT] ${logLine}`);
    }
  }

  private extractRequestInfo(req: Request): Partial<AuditLogEntry> {
    return {
      ipAddress: this.getClientIp(req),
      userAgent: req.headers['user-agent'],
      requestPath: req.path,
      requestMethod: req.method,
      requestId: req.headers['x-request-id'] as string,
    };
  }

  private getClientIp(req: Request): string {
    const forwardedFor = req.headers['x-forwarded-for'];
    if (forwardedFor) {
      const ips = (
        typeof forwardedFor === 'string' ? forwardedFor : forwardedFor[0]
      ).split(',');
      return ips[0].trim();
    }
    return req.ip || req.socket?.remoteAddress || 'unknown';
  }

  private getSeverityForAction(
    action: AuditAction,
    outcome: 'success' | 'failure',
  ): AuditSeverity {
    // Failed auth attempts are warnings
    if (outcome === 'failure') {
      if (
        [
          AuditAction.LOGIN_FAILED,
          AuditAction.TOTP_VERIFY_FAILED,
          AuditAction.OTP_FAILED,
        ].includes(action)
      ) {
        return AuditSeverity.WARNING;
      }
      return AuditSeverity.ERROR;
    }

    // Security-related successful actions
    if (
      [
        AuditAction.PASSWORD_CHANGE,
        AuditAction.TOTP_ENABLED,
        AuditAction.TOTP_DISABLED,
        AuditAction.SESSION_REVOKED,
      ].includes(action)
    ) {
      return AuditSeverity.WARNING;
    }

    return AuditSeverity.INFO;
  }
}
