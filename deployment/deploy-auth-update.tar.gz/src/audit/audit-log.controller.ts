/**
 * Audit Log Controller
 * REST API endpoints for querying audit logs (admin only)
 */

import {
    Controller,
    DefaultValuePipe,
    Get,
    ParseIntPipe,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';

import { Role } from '@prisma/client';
import { CurrentUser } from '../auth/decorators';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import {
    AuditCategory,
    AuditLogService,
    AuditSeverity,
} from './audit-log.service';

@ApiTags('Audit Logs')
@Controller('admin/audit-logs')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.ADMIN)
@ApiBearerAuth()
export class AuditLogController {
  constructor(private readonly auditLogService: AuditLogService) {}

  @Get()
  @ApiOperation({ summary: 'Query audit logs (admin only)' })
  @ApiQuery({ name: 'category', required: false, enum: AuditCategory })
  @ApiQuery({ name: 'action', required: false, type: String })
  @ApiQuery({ name: 'severity', required: false, enum: AuditSeverity })
  @ApiQuery({ name: 'userId', required: false, type: Number })
  @ApiQuery({ name: 'targetUserId', required: false, type: Number })
  @ApiQuery({ name: 'ipAddress', required: false, type: String })
  @ApiQuery({ name: 'outcome', required: false, enum: ['success', 'failure'] })
  @ApiQuery({ name: 'startDate', required: false, type: String })
  @ApiQuery({ name: 'endDate', required: false, type: String })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 100 })
  @ApiQuery({ name: 'offset', required: false, type: Number, example: 0 })
  @ApiResponse({
    status: 200,
    description: 'List of audit logs',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        data: {
          type: 'object',
          properties: {
            logs: { type: 'array', items: { type: 'object' } },
            total: { type: 'number', example: 150 },
            limit: { type: 'number', example: 100 },
            offset: { type: 'number', example: 0 },
          },
        },
      },
    },
  })
  async queryLogs(
    @Query('category') category?: AuditCategory,
    @Query('action') action?: string,
    @Query('severity') severity?: AuditSeverity,
    @Query('userId') userId?: string,
    @Query('targetUserId') targetUserId?: string,
    @Query('ipAddress') ipAddress?: string,
    @Query('outcome') outcome?: 'success' | 'failure',
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('limit', new DefaultValuePipe(100), ParseIntPipe) limit?: number,
    @Query('offset', new DefaultValuePipe(0), ParseIntPipe) offset?: number,
  ) {
    const result = await this.auditLogService.query({
      category,
      action,
      severity,
      userId: userId ? parseInt(userId, 10) : undefined,
      targetUserId: targetUserId ? parseInt(targetUserId, 10) : undefined,
      ipAddress,
      outcome,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      limit,
      offset,
    });

    return {
      success: true,
      data: {
        logs: result.logs,
        total: result.total,
        limit,
        offset,
      },
    };
  }

  @Get('security')
  @ApiOperation({ summary: 'Get recent security events (admin only)' })
  @ApiQuery({ name: 'hours', required: false, type: Number, example: 24 })
  @ApiResponse({
    status: 200,
    description: 'List of security events',
  })
  async getSecurityEvents(
    @Query('hours', new DefaultValuePipe(24), ParseIntPipe) hours: number,
  ) {
    const events = await this.auditLogService.getSecurityEvents(hours);

    return {
      success: true,
      data: {
        events,
        count: events.length,
        hours,
      },
    };
  }

  @Get('user/:userId')
  @ApiOperation({ summary: 'Get audit logs for a specific user (admin only)' })
  @ApiResponse({
    status: 200,
    description: 'User audit logs',
  })
  async getUserLogs(
    @Query('userId', ParseIntPipe) userId: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
  ) {
    const logs = await this.auditLogService.getUserLogs(userId, limit);

    return {
      success: true,
      data: {
        logs,
        count: logs.length,
        userId,
      },
    };
  }

  @Get('my-activity')
  @ApiOperation({ summary: 'Get audit logs for current user' })
  async getMyActivity(
    @CurrentUser('id') userId: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
  ) {
    const logs = await this.auditLogService.getUserLogs(userId, limit);

    // Filter out sensitive details for non-admin users
    const sanitizedLogs = logs.map((log) => ({
      timestamp: log.timestamp,
      action: log.action,
      outcome: log.outcome,
      ipAddress: log.ipAddress,
      userAgent: log.userAgent,
    }));

    return {
      success: true,
      data: {
        logs: sanitizedLogs,
        count: sanitizedLogs.length,
      },
    };
  }
}
