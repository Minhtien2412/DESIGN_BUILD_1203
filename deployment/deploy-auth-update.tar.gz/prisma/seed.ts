import { PrismaClient, TaskStatus } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log(' Seeding database...');

  // Create test users
  const hashedPassword = await bcrypt.hash('Test123!@#', 10);
  
  const engineer = await prisma.user.upsert({
    where: { email: 'engineer@baotienweb.com' },
    update: {},
    create: {
      email: 'engineer@baotienweb.com',
      password: hashedPassword,
      name: 'Engineer User',
      role: 'ENGINEER',
    },
  });

  const client = await prisma.user.upsert({
    where: { email: 'client@baotienweb.com' },
    update: {},
    create: {
      email: 'client@baotienweb.com',
      password: hashedPassword,
      name: 'Client User',
      role: 'CLIENT',
    },
  });

  // Create projects
  const project1 = await prisma.project.create({
    data: {
      title: 'Project Demo 1',
      description: 'M� t? d? �n demo s? 1',
      budget: 100000000,
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      status: 'PLANNING',
      clientId: client.id,
      engineerId: engineer.id,
    },
  });

  const project2 = await prisma.project.create({
    data: {
      title: 'Project Demo 2',
      description: 'M� t? d? �n demo s? 2',
      budget: 200000000,
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      status: 'IN_PROGRESS',
      clientId: client.id,
      engineerId: engineer.id,
    },
  });

  const project3 = await prisma.project.create({
    data: {
      title: 'Project Demo 3',
      description: 'M� t? d? �n demo s? 3',
      budget: 300000000,
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      status: 'COMPLETED',
      clientId: client.id,
      engineerId: engineer.id,
    },
  });

  // Create tasks for first project
  await prisma.task.create({
    data: {
      title: 'Task 1 - Planning',
      description: 'L?p k? ho?ch d? �n',
      status: TaskStatus.DONE,
      priority: 'HIGH',
      projectId: project1.id,
      assigneeId: engineer.id,
    },
  });

  await prisma.task.create({
    data: {
      title: 'Task 2 - Design',
      description: 'Thi?t k? giao di?n',
      status: TaskStatus.IN_PROGRESS,
      priority: 'MEDIUM',
      projectId: project1.id,
      assigneeId: engineer.id,
    },
  });

  await prisma.task.create({
    data: {
      title: 'Task 3 - Development',
      description: 'Ph�t tri?n t�nh nang',
      status: TaskStatus.TODO,
      priority: 'HIGH',
      projectId: project1.id,
      assigneeId: engineer.id,
    },
  });

  console.log('? Seeding completed!');
  console.log(`Created: 3 projects, 3 tasks, 2 users`);
}

main()
  .catch((e) => {
    console.error(' Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
