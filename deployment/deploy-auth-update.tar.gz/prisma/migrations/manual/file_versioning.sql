-- ============================================================================
-- File Metadata & Versioning Schema Additions
-- ============================================================================
-- Run this migration to add versioning support to File model
-- Author: ThietKeResort Team
-- Date: 2026-01-22

-- Add metadata columns to File
ALTER TABLE files ADD COLUMN IF NOT EXISTS checksum VARCHAR(64);
ALTER TABLE files ADD COLUMN IF NOT EXISTS original_name VARCHAR(255);
ALTER TABLE files ADD COLUMN IF NOT EXISTS metadata JSONB;
ALTER TABLE files ADD COLUMN IF NOT EXISTS thumbnail_url VARCHAR(512);
ALTER TABLE files ADD COLUMN IF NOT EXISTS uploaded_by INTEGER REFERENCES users(id);
ALTER TABLE files ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP WITH TIME ZONE;

-- Create index for soft delete queries
CREATE INDEX IF NOT EXISTS idx_files_deleted_at ON files(deleted_at);
CREATE INDEX IF NOT EXISTS idx_files_uploaded_by ON files(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_files_checksum ON files(checksum);

-- ============================================================================
-- FileVersion Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS file_versions (
  id SERIAL PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL DEFAULT 1,
  url VARCHAR(512) NOT NULL,
  size INTEGER NOT NULL,
  checksum VARCHAR(64),
  comment TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT unique_file_version UNIQUE (file_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_file_versions_file_id ON file_versions(file_id);
CREATE INDEX IF NOT EXISTS idx_file_versions_created_at ON file_versions(created_at);

-- ============================================================================
-- FileAccessLog Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS file_access_logs (
  id SERIAL PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id),
  action VARCHAR(20) NOT NULL, -- 'view', 'download', 'share', 'edit', 'delete', 'restore'
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_file_access_logs_file_id ON file_access_logs(file_id);
CREATE INDEX IF NOT EXISTS idx_file_access_logs_user_id ON file_access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_file_access_logs_created_at ON file_access_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_file_access_logs_action ON file_access_logs(action);

-- ============================================================================
-- FileShare Table (for shareable links)
-- ============================================================================
CREATE TABLE IF NOT EXISTS file_shares (
  id SERIAL PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  share_token VARCHAR(64) NOT NULL UNIQUE,
  created_by INTEGER NOT NULL REFERENCES users(id),
  password_hash VARCHAR(255),
  max_downloads INTEGER,
  download_count INTEGER DEFAULT 0,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  revoked_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_file_shares_token ON file_shares(share_token);
CREATE INDEX IF NOT EXISTS idx_file_shares_file_id ON file_shares(file_id);
CREATE INDEX IF NOT EXISTS idx_file_shares_expires_at ON file_shares(expires_at);

-- ============================================================================
-- FileTag Table (for organizing files)
-- ============================================================================
CREATE TABLE IF NOT EXISTS file_tags (
  id SERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  color VARCHAR(7) DEFAULT '#6366f1',
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT unique_tag_name_per_user UNIQUE (name, created_by)
);

CREATE TABLE IF NOT EXISTS file_tag_relations (
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  tag_id INTEGER NOT NULL REFERENCES file_tags(id) ON DELETE CASCADE,
  
  PRIMARY KEY (file_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_file_tag_relations_file_id ON file_tag_relations(file_id);
CREATE INDEX IF NOT EXISTS idx_file_tag_relations_tag_id ON file_tag_relations(tag_id);
