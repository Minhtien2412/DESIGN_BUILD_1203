-- Migration: add_device_sessions_and_conversation_models
-- Created: 2025-01-XX
-- Description: Add DeviceSession for token rotation, Conversation models for messaging

-- =====================================================
-- DEVICE SESSIONS (for refresh token rotation AUTH-001)
-- =====================================================

CREATE TABLE IF NOT EXISTS "device_sessions" (
    "id" TEXT NOT NULL,
    "userId" INTEGER NOT NULL,
    "deviceName" TEXT,
    "deviceType" TEXT,
    "platform" TEXT,
    "browser" TEXT,
    "userAgent" TEXT,
    "tokenFamily" TEXT NOT NULL,
    "refreshTokenHash" TEXT,
    "ipAddress" TEXT,
    "location" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "revokedAt" TIMESTAMP(3),
    "revokedReason" TEXT,
    "lastUsedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "expiresAt" TIMESTAMP(3),

    CONSTRAINT "device_sessions_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "device_sessions_tokenFamily_key" ON "device_sessions"("tokenFamily");
CREATE INDEX IF NOT EXISTS "device_sessions_userId_idx" ON "device_sessions"("userId");
CREATE INDEX IF NOT EXISTS "device_sessions_tokenFamily_idx" ON "device_sessions"("tokenFamily");
CREATE INDEX IF NOT EXISTS "device_sessions_isActive_idx" ON "device_sessions"("isActive");
CREATE INDEX IF NOT EXISTS "device_sessions_lastUsedAt_idx" ON "device_sessions"("lastUsedAt");

ALTER TABLE "device_sessions" ADD CONSTRAINT "device_sessions_userId_fkey" 
    FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- =====================================================
-- CONVERSATION ENUMS
-- =====================================================

DO $$ BEGIN
    CREATE TYPE "ConversationType" AS ENUM ('DIRECT', 'GROUP');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE "ParticipantRole" AS ENUM ('OWNER', 'ADMIN', 'MEMBER');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE "MessageType" AS ENUM ('TEXT', 'IMAGE', 'FILE', 'VIDEO', 'VOICE', 'SYSTEM');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- =====================================================
-- CONVERSATIONS (MSG-001)
-- =====================================================

CREATE TABLE IF NOT EXISTS "conversations" (
    "id" TEXT NOT NULL,
    "type" "ConversationType" NOT NULL DEFAULT 'DIRECT',
    "title" TEXT,
    "description" TEXT,
    "avatarUrl" TEXT,
    "directKey" TEXT,
    "lastMessageId" TEXT,
    "lastMessageAt" TIMESTAMP(3),
    "lastMessagePreview" TEXT,
    "isArchived" BOOLEAN NOT NULL DEFAULT false,
    "version" INTEGER NOT NULL DEFAULT 0,
    "createdBy" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "conversations_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "conversations_directKey_key" ON "conversations"("directKey");
CREATE INDEX IF NOT EXISTS "conversations_type_idx" ON "conversations"("type");
CREATE INDEX IF NOT EXISTS "conversations_lastMessageAt_idx" ON "conversations"("lastMessageAt");
CREATE INDEX IF NOT EXISTS "conversations_createdBy_idx" ON "conversations"("createdBy");

-- =====================================================
-- CONVERSATION PARTICIPANTS
-- =====================================================

CREATE TABLE IF NOT EXISTS "conversation_participants" (
    "id" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "userId" INTEGER NOT NULL,
    "role" "ParticipantRole" NOT NULL DEFAULT 'MEMBER',
    "lastReadMessageId" TEXT,
    "lastReadAt" TIMESTAMP(3),
    "lastReadSeq" INTEGER NOT NULL DEFAULT 0,
    "unreadCount" INTEGER NOT NULL DEFAULT 0,
    "isMuted" BOOLEAN NOT NULL DEFAULT false,
    "isPinned" BOOLEAN NOT NULL DEFAULT false,
    "nickname" TEXT,
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "leftAt" TIMESTAMP(3),
    "removedAt" TIMESTAMP(3),
    "removedBy" INTEGER,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "conversation_participants_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "conversation_participants_conversationId_userId_key" 
    ON "conversation_participants"("conversationId", "userId");
CREATE INDEX IF NOT EXISTS "conversation_participants_userId_idx" ON "conversation_participants"("userId");
CREATE INDEX IF NOT EXISTS "conversation_participants_conversationId_idx" ON "conversation_participants"("conversationId");

ALTER TABLE "conversation_participants" ADD CONSTRAINT "conversation_participants_conversationId_fkey" 
    FOREIGN KEY ("conversationId") REFERENCES "conversations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "conversation_participants" ADD CONSTRAINT "conversation_participants_userId_fkey" 
    FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- =====================================================
-- CONVERSATION MESSAGES
-- =====================================================

CREATE TABLE IF NOT EXISTS "conversation_messages" (
    "id" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "senderId" INTEGER NOT NULL,
    "seq" INTEGER NOT NULL DEFAULT 0,
    "content" TEXT NOT NULL,
    "type" "MessageType" NOT NULL DEFAULT 'TEXT',
    "mediaUrl" TEXT,
    "thumbnailUrl" TEXT,
    "mediaSize" INTEGER,
    "mediaDuration" INTEGER,
    "mediaFilename" TEXT,
    "attachments" JSONB,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "isEdited" BOOLEAN NOT NULL DEFAULT false,
    "editedAt" TIMESTAMP(3),
    "deletedAt" TIMESTAMP(3),
    "replyToMessageId" TEXT,
    "clientMessageId" TEXT,
    "sentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "conversation_messages_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "conversation_messages_conversationId_clientMessageId_key" 
    ON "conversation_messages"("conversationId", "clientMessageId");
CREATE INDEX IF NOT EXISTS "conversation_messages_conversationId_idx" ON "conversation_messages"("conversationId");
CREATE INDEX IF NOT EXISTS "conversation_messages_senderId_idx" ON "conversation_messages"("senderId");
CREATE INDEX IF NOT EXISTS "conversation_messages_sentAt_idx" ON "conversation_messages"("sentAt");
CREATE INDEX IF NOT EXISTS "conversation_messages_seq_idx" ON "conversation_messages"("seq");

ALTER TABLE "conversation_messages" ADD CONSTRAINT "conversation_messages_conversationId_fkey" 
    FOREIGN KEY ("conversationId") REFERENCES "conversations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "conversation_messages" ADD CONSTRAINT "conversation_messages_senderId_fkey" 
    FOREIGN KEY ("senderId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "conversation_messages" ADD CONSTRAINT "conversation_messages_replyToMessageId_fkey" 
    FOREIGN KEY ("replyToMessageId") REFERENCES "conversation_messages"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- =====================================================
-- CONVERSATION READ RECEIPTS
-- =====================================================

CREATE TABLE IF NOT EXISTS "conversation_read_receipts" (
    "id" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "userId" INTEGER NOT NULL,
    "readAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "conversation_read_receipts_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "conversation_read_receipts_messageId_userId_key" 
    ON "conversation_read_receipts"("messageId", "userId");
CREATE INDEX IF NOT EXISTS "conversation_read_receipts_messageId_idx" ON "conversation_read_receipts"("messageId");
CREATE INDEX IF NOT EXISTS "conversation_read_receipts_userId_idx" ON "conversation_read_receipts"("userId");

ALTER TABLE "conversation_read_receipts" ADD CONSTRAINT "conversation_read_receipts_messageId_fkey" 
    FOREIGN KEY ("messageId") REFERENCES "conversation_messages"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- =====================================================
-- MESSAGE REACTIONS
-- =====================================================

CREATE TABLE IF NOT EXISTS "message_reactions" (
    "id" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "userId" INTEGER NOT NULL,
    "emoji" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "message_reactions_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "message_reactions_messageId_userId_emoji_key" 
    ON "message_reactions"("messageId", "userId", "emoji");
CREATE INDEX IF NOT EXISTS "message_reactions_messageId_idx" ON "message_reactions"("messageId");
CREATE INDEX IF NOT EXISTS "message_reactions_userId_idx" ON "message_reactions"("userId");

ALTER TABLE "message_reactions" ADD CONSTRAINT "message_reactions_messageId_fkey" 
    FOREIGN KEY ("messageId") REFERENCES "conversation_messages"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "message_reactions" ADD CONSTRAINT "message_reactions_userId_fkey" 
    FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- =====================================================
-- DONE
-- =====================================================
