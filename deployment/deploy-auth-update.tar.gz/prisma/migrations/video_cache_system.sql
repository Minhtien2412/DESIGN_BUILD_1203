-- Video Cache System Migration
-- Hệ thống lưu trữ video ~2GB với auto-cleanup
-- Created: 16/01/2026

-- ==================== CACHED VIDEOS ====================
CREATE TABLE IF NOT EXISTS "cached_videos" (
    "id" SERIAL PRIMARY KEY,
    "externalId" VARCHAR(255) NOT NULL UNIQUE,
    "sourceType" VARCHAR(50) DEFAULT 'pexels',
    
    -- File info
    "localPath" TEXT NOT NULL,
    "fileName" VARCHAR(255) NOT NULL,
    "fileSize" INTEGER NOT NULL,
    "mimeType" VARCHAR(100) DEFAULT 'video/mp4',
    
    -- Video metadata
    "title" TEXT,
    "description" TEXT,
    "thumbnailUrl" TEXT,
    "thumbnailPath" TEXT,
    "duration" INTEGER DEFAULT 0,
    "width" INTEGER DEFAULT 0,
    "height" INTEGER DEFAULT 0,
    
    -- Fake user info (Vietnamese)
    "userName" VARCHAR(255) NOT NULL,
    "userAvatar" TEXT NOT NULL,
    "userVerified" BOOLEAN DEFAULT false,
    "userFollowers" VARCHAR(50) DEFAULT '0',
    
    -- Stats
    "likesCount" INTEGER DEFAULT 0,
    "commentsCount" INTEGER DEFAULT 0,
    "sharesCount" INTEGER DEFAULT 0,
    "savesCount" INTEGER DEFAULT 0,
    "viewsCount" INTEGER DEFAULT 0,
    
    -- Category & Tags
    "category" VARCHAR(100) DEFAULT 'general',
    "tags" TEXT[] DEFAULT '{}',
    "musicTrack" TEXT,
    
    -- Tracking
    "displayOrder" INTEGER DEFAULT 0,
    "lastDisplayedAt" TIMESTAMP,
    "downloadedAt" TIMESTAMP DEFAULT NOW(),
    "expiresAt" TIMESTAMP,
    "isActive" BOOLEAN DEFAULT true,
    
    "createdAt" TIMESTAMP DEFAULT NOW(),
    "updatedAt" TIMESTAMP DEFAULT NOW()
);

-- Indexes for cached_videos
CREATE INDEX IF NOT EXISTS "cached_videos_sourceType_idx" ON "cached_videos"("sourceType");
CREATE INDEX IF NOT EXISTS "cached_videos_category_idx" ON "cached_videos"("category");
CREATE INDEX IF NOT EXISTS "cached_videos_displayOrder_idx" ON "cached_videos"("displayOrder");
CREATE INDEX IF NOT EXISTS "cached_videos_lastDisplayedAt_idx" ON "cached_videos"("lastDisplayedAt");
CREATE INDEX IF NOT EXISTS "cached_videos_downloadedAt_idx" ON "cached_videos"("downloadedAt");
CREATE INDEX IF NOT EXISTS "cached_videos_isActive_idx" ON "cached_videos"("isActive");
CREATE INDEX IF NOT EXISTS "cached_videos_fileSize_idx" ON "cached_videos"("fileSize");

-- ==================== USER VIDEO HISTORY ====================
CREATE TABLE IF NOT EXISTS "user_video_history" (
    "id" SERIAL PRIMARY KEY,
    "userId" INTEGER,
    "sessionId" VARCHAR(255) NOT NULL,
    "videoId" INTEGER NOT NULL,
    
    -- Tracking
    "displayedAt" TIMESTAMP DEFAULT NOW(),
    "watchDuration" INTEGER DEFAULT 0,
    "completed" BOOLEAN DEFAULT false,
    "liked" BOOLEAN DEFAULT false,
    "saved" BOOLEAN DEFAULT false,
    "shared" BOOLEAN DEFAULT false,
    
    -- Position
    "feedPosition" INTEGER DEFAULT 0,
    
    "createdAt" TIMESTAMP DEFAULT NOW(),
    
    -- Foreign key
    FOREIGN KEY ("videoId") REFERENCES "cached_videos"("id") ON DELETE CASCADE,
    
    -- Unique constraint
    UNIQUE("sessionId", "videoId")
);

-- Indexes for user_video_history
CREATE INDEX IF NOT EXISTS "user_video_history_userId_idx" ON "user_video_history"("userId");
CREATE INDEX IF NOT EXISTS "user_video_history_sessionId_idx" ON "user_video_history"("sessionId");
CREATE INDEX IF NOT EXISTS "user_video_history_videoId_idx" ON "user_video_history"("videoId");
CREATE INDEX IF NOT EXISTS "user_video_history_displayedAt_idx" ON "user_video_history"("displayedAt");

-- ==================== VIDEO CACHE CONFIG ====================
CREATE TABLE IF NOT EXISTS "video_cache_config" (
    "id" SERIAL PRIMARY KEY,
    "key" VARCHAR(100) UNIQUE NOT NULL,
    "value" TEXT NOT NULL,
    "description" TEXT,
    "updatedAt" TIMESTAMP DEFAULT NOW()
);

-- Default config values
INSERT INTO "video_cache_config" ("key", "value", "description") VALUES
    ('maxStorageBytes', '2147483648', 'Max storage size in bytes (2GB)'),
    ('targetVideoCount', '200', 'Target number of videos in cache'),
    ('cleanupThreshold', '0.9', 'Storage percentage to trigger cleanup')
ON CONFLICT ("key") DO NOTHING;

-- ==================== VIDEO CACHE LOGS ====================
CREATE TABLE IF NOT EXISTS "video_cache_logs" (
    "id" SERIAL PRIMARY KEY,
    "action" VARCHAR(50) NOT NULL,
    "videoId" INTEGER,
    "externalId" VARCHAR(255),
    "details" JSONB,
    "fileSize" INTEGER,
    "success" BOOLEAN DEFAULT true,
    "errorMsg" TEXT,
    "createdAt" TIMESTAMP DEFAULT NOW()
);

-- Indexes for logs
CREATE INDEX IF NOT EXISTS "video_cache_logs_action_idx" ON "video_cache_logs"("action");
CREATE INDEX IF NOT EXISTS "video_cache_logs_createdAt_idx" ON "video_cache_logs"("createdAt");

-- ==================== CREATE VIDEO STORAGE DIRECTORY ====================
-- Run this command on server:
-- mkdir -p /var/www/video-cache && chmod 755 /var/www/video-cache

SELECT 'Video Cache tables created successfully!' as message;
