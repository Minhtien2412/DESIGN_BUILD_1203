-- CreateTable
CREATE TABLE "live_streams" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "description" TEXT,
    "streamKey" VARCHAR(64) NOT NULL,
    "streamUrl" VARCHAR(500) NOT NULL,
    "playbackUrl" VARCHAR(500) NOT NULL,
    "status" VARCHAR(20) NOT NULL DEFAULT 'pending',
    "viewerCount" INTEGER NOT NULL DEFAULT 0,
    "startedAt" TIMESTAMP(3),
    "endedAt" TIMESTAMP(3),
    "duration" INTEGER,
    "thumbnailUrl" VARCHAR(500),
    "recordingUrl" VARCHAR(500),
    "isRecording" BOOLEAN NOT NULL DEFAULT false,
    "settings" JSONB,
    "hostId" INTEGER NOT NULL,
    "projectId" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "live_streams_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stream_viewers" (
    "id" SERIAL NOT NULL,
    "streamId" INTEGER NOT NULL,
    "userId" INTEGER NOT NULL,
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "leftAt" TIMESTAMP(3),

    CONSTRAINT "stream_viewers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stream_comments" (
    "id" SERIAL NOT NULL,
    "streamId" INTEGER NOT NULL,
    "userId" INTEGER NOT NULL,
    "text" VARCHAR(500) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "stream_comments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stream_reactions" (
    "id" SERIAL NOT NULL,
    "streamId" INTEGER NOT NULL,
    "userId" INTEGER NOT NULL,
    "type" VARCHAR(20) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "stream_reactions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "live_streams_streamKey_key" ON "live_streams"("streamKey");

-- CreateIndex
CREATE INDEX "live_streams_hostId_idx" ON "live_streams"("hostId");

-- CreateIndex
CREATE INDEX "live_streams_projectId_idx" ON "live_streams"("projectId");

-- CreateIndex
CREATE INDEX "live_streams_status_idx" ON "live_streams"("status");

-- CreateIndex
CREATE INDEX "live_streams_createdAt_idx" ON "live_streams"("createdAt");

-- CreateIndex
CREATE INDEX "stream_viewers_streamId_idx" ON "stream_viewers"("streamId");

-- CreateIndex
CREATE INDEX "stream_viewers_userId_idx" ON "stream_viewers"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "stream_viewers_streamId_userId_key" ON "stream_viewers"("streamId", "userId");

-- CreateIndex
CREATE INDEX "stream_comments_streamId_idx" ON "stream_comments"("streamId");

-- CreateIndex
CREATE INDEX "stream_comments_userId_idx" ON "stream_comments"("userId");

-- CreateIndex
CREATE INDEX "stream_comments_createdAt_idx" ON "stream_comments"("createdAt");

-- CreateIndex
CREATE INDEX "stream_reactions_streamId_idx" ON "stream_reactions"("streamId");

-- CreateIndex
CREATE INDEX "stream_reactions_userId_idx" ON "stream_reactions"("userId");

-- CreateIndex
CREATE INDEX "stream_reactions_type_idx" ON "stream_reactions"("type");

-- AddForeignKey
ALTER TABLE "live_streams" ADD CONSTRAINT "live_streams_hostId_fkey" FOREIGN KEY ("hostId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "live_streams" ADD CONSTRAINT "live_streams_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "projects"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_viewers" ADD CONSTRAINT "stream_viewers_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES "live_streams"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_viewers" ADD CONSTRAINT "stream_viewers_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_comments" ADD CONSTRAINT "stream_comments_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES "live_streams"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_comments" ADD CONSTRAINT "stream_comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_reactions" ADD CONSTRAINT "stream_reactions_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES "live_streams"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stream_reactions" ADD CONSTRAINT "stream_reactions_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
