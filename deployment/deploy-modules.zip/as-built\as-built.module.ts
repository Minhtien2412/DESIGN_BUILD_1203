import { Module } from '@nestjs/common';
import { AsBuiltController } from './as-built.controller';
import { AsBuiltService } from './as-built.service';

@Module({
  controllers: [AsBuiltController],
  providers: [AsBuiltService],
  exports: [AsBuiltService],
})
export class AsBuiltModule {}
