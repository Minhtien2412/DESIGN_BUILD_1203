// As-Built Module Entities

export enum DrawingStatus {
  DRAFT = 'draft',
  REVIEW = 'review',
  APPROVED = 'approved',
  SUPERSEDED = 'superseded',
}

export enum DrawingType {
  ARCHITECTURAL = 'architectural',
  STRUCTURAL = 'structural',
  MEP = 'mep',
  CIVIL = 'civil',
  LANDSCAPE = 'landscape',
  INTERIOR = 'interior',
  DETAIL = 'detail',
}

export enum ExportFormat {
  PDF = 'pdf',
  DWG = 'dwg',
  DXF = 'dxf',
  IFC = 'ifc',
  ZIP = 'zip',
}

export enum PackageStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
}

export interface AsBuiltDrawing {
  id: number;
  projectId: number;
  title: string;
  description?: string;
  drawingNumber: string;
  drawingType: DrawingType;
  status: DrawingStatus;
  version: number;
  revision: string;
  scale?: string;
  size?: string;
  originalFile: string;
  thumbnailUrl?: string;
  previewUrl?: string;
  fileSize: number;
  uploadedBy: number;
  uploadedByName: string;
  reviewedBy?: number;
  reviewedByName?: string;
  reviewedAt?: Date;
  approvedBy?: number;
  approvedByName?: string;
  approvedAt?: Date;
  tags?: string[];
  metadata?: Record<string, any>;
  previousVersionId?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface DrawingRevision {
  id: number;
  drawingId: number;
  revision: string;
  changes: string;
  changedBy: number;
  changedByName: string;
  fileUrl: string;
  createdAt: Date;
}

export interface ExportPackage {
  id: number;
  projectId: number;
  title: string;
  description?: string;
  format: ExportFormat;
  status: PackageStatus;
  drawings: number[]; // Drawing IDs
  includeMetadata: boolean;
  includeRevisions: boolean;
  downloadUrl?: string;
  fileSize?: number;
  requestedBy: number;
  requestedByName: string;
  completedAt?: Date;
  expiresAt?: Date;
  errorMessage?: string;
  createdAt: Date;
}

export interface DrawingComment {
  id: number;
  drawingId: number;
  userId: number;
  userName: string;
  comment: string;
  x?: number;
  y?: number;
  resolved: boolean;
  resolvedBy?: number;
  resolvedAt?: Date;
  createdAt: Date;
}

export interface AsBuiltDashboard {
  totalDrawings: number;
  drawingsByStatus: Record<DrawingStatus, number>;
  drawingsByType: Record<DrawingType, number>;
  recentDrawings: AsBuiltDrawing[];
  pendingReviews: number;
  totalExports: number;
  totalFileSize: number;
}
