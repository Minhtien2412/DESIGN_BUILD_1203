// Analytics entity interfaces
// Currently using in-memory storage

export enum EventType {
  PAGE_VIEW = 'page_view',
  CLICK = 'click',
  FORM_SUBMIT = 'form_submit',
  ERROR = 'error',
  CUSTOM = 'custom',
}

export interface AnalyticsEvent {
  id: number;
  userId?: number;
  sessionId: string;
  eventType: EventType;
  eventName: string;
  page?: string;
  referrer?: string;
  properties?: Record<string, any>;
  userAgent?: string;
  ip?: string;
  country?: string;
  city?: string;
  device?: string;
  browser?: string;
  os?: string;
  createdAt: Date;
}

export interface AnalyticsSession {
  id: string;
  userId?: number;
  startTime: Date;
  endTime?: Date;
  pageViews: number;
  events: number;
  duration?: number;
  entryPage?: string;
  exitPage?: string;
  device?: string;
  browser?: string;
  country?: string;
}

export interface DashboardMetrics {
  totalUsers: number;
  activeUsers: number;
  totalSessions: number;
  totalPageViews: number;
  totalEvents: number;
  avgSessionDuration: number;
  bounceRate: number;
  topPages: { page: string; views: number }[];
  topEvents: { event: string; count: number }[];
  usersByDevice: { device: string; count: number }[];
  usersByCountry: { country: string; count: number }[];
}

export interface AnalyticsQuery {
  startDate?: Date;
  endDate?: Date;
  userId?: number;
  eventType?: EventType;
  page?: string;
  limit?: number;
  offset?: number;
}

export interface ComparePeriodsResult {
  current: DashboardMetrics;
  previous: DashboardMetrics;
  changes: {
    users: number;
    sessions: number;
    pageViews: number;
    avgDuration: number;
  };
}

export interface UserFlowStep {
  page: string;
  count: number;
  percentage: number;
  nextPages: { page: string; count: number }[];
}

export interface ReportTemplate {
  id: number;
  name: string;
  description?: string;
  metrics: string[];
  filters?: Record<string, any>;
  schedule?: string;
  createdAt: Date;
  updatedAt: Date;
}
