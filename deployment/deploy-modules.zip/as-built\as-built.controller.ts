import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Body,
  Param,
  Query,
  HttpStatus,
  ParseIntPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';
import { AsBuiltService } from './as-built.service';
import {
  CreateDrawingDto,
  UpdateDrawingDto,
  UploadRevisionDto,
  ReviewDrawingDto,
  ApproveDrawingDto,
  CreateExportPackageDto,
  AddCommentDto,
  ResolveCommentDto,
  QueryDrawingDto,
  QueryExportDto,
} from './dto';
import { DrawingStatus, DrawingType } from './entities';

@ApiTags('As-Built')
@Controller('as-built')
export class AsBuiltController {
  constructor(private readonly asBuiltService: AsBuiltService) {}

  // ========== DASHBOARD ==========

  @Get('dashboard')
  @ApiOperation({ summary: 'Get as-built dashboard metrics' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Dashboard metrics retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getDashboard(@Query('projectId') projectId?: string) {
    return this.asBuiltService.getDashboard(projectId ? parseInt(projectId) : undefined);
  }

  // ========== DRAWINGS ==========

  @Get('drawings')
  @ApiOperation({ summary: 'Get as-built drawings with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawings retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: DrawingStatus })
  @ApiQuery({ name: 'drawingType', required: false, enum: DrawingType })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'offset', required: false, type: Number })
  async getDrawings(@Query() query: QueryDrawingDto) {
    return this.asBuiltService.getDrawings(query);
  }

  @Get('drawings/:id')
  @ApiOperation({ summary: 'Get drawing by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawing retrieved' })
  async getDrawingById(@Param('id', ParseIntPipe) id: number) {
    return this.asBuiltService.getDrawingById(id);
  }

  @Post('drawings')
  @ApiOperation({ summary: 'Create a new as-built drawing' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Drawing created' })
  async createDrawing(@Body() dto: CreateDrawingDto) {
    return this.asBuiltService.createDrawing(dto);
  }

  @Put('drawings/:id')
  @ApiOperation({ summary: 'Update an as-built drawing' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawing updated' })
  async updateDrawing(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateDrawingDto) {
    return this.asBuiltService.updateDrawing(id, dto);
  }

  @Post('drawings/:id/revisions')
  @ApiOperation({ summary: 'Upload a new revision for a drawing' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Revision uploaded' })
  async uploadRevision(@Param('id', ParseIntPipe) id: number, @Body() dto: UploadRevisionDto) {
    return this.asBuiltService.uploadRevision(id, dto);
  }

  @Get('drawings/:id/revisions')
  @ApiOperation({ summary: 'Get revisions for a drawing' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Revisions retrieved' })
  async getRevisions(@Param('id', ParseIntPipe) id: number) {
    return this.asBuiltService.getRevisions(id);
  }

  @Patch('drawings/:id/submit-review')
  @ApiOperation({ summary: 'Submit drawing for review' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawing submitted for review' })
  async submitForReview(@Param('id', ParseIntPipe) id: number) {
    return this.asBuiltService.submitForReview(id);
  }

  @Patch('drawings/:id/review')
  @ApiOperation({ summary: 'Review a drawing' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawing reviewed' })
  async reviewDrawing(@Param('id', ParseIntPipe) id: number, @Body() dto: ReviewDrawingDto) {
    return this.asBuiltService.reviewDrawing(id, dto);
  }

  @Patch('drawings/:id/approve')
  @ApiOperation({ summary: 'Approve a drawing' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Drawing approved' })
  async approveDrawing(@Param('id', ParseIntPipe) id: number, @Body() dto: ApproveDrawingDto) {
    return this.asBuiltService.approveDrawing(id, dto);
  }

  // ========== COMMENTS ==========

  @Get('drawings/:id/comments')
  @ApiOperation({ summary: 'Get comments for a drawing' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Comments retrieved' })
  async getComments(@Param('id', ParseIntPipe) id: number) {
    return this.asBuiltService.getComments(id);
  }

  @Post('drawings/:id/comments')
  @ApiOperation({ summary: 'Add comment to a drawing' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Comment added' })
  async addComment(@Param('id', ParseIntPipe) id: number, @Body() dto: AddCommentDto) {
    return this.asBuiltService.addComment(id, dto);
  }

  @Patch('drawings/:drawingId/comments/:commentId/resolve')
  @ApiOperation({ summary: 'Resolve a comment' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Comment resolved' })
  async resolveComment(
    @Param('drawingId', ParseIntPipe) drawingId: number,
    @Param('commentId', ParseIntPipe) commentId: number,
    @Body() dto: ResolveCommentDto,
  ) {
    return this.asBuiltService.resolveComment(drawingId, commentId, dto);
  }

  // ========== EXPORTS ==========

  @Get('exports')
  @ApiOperation({ summary: 'Get export packages' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Export packages retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'requestedBy', required: false, type: Number })
  async getExports(@Query() query: QueryExportDto) {
    return this.asBuiltService.getExports(query);
  }

  @Get('exports/:id')
  @ApiOperation({ summary: 'Get export package by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Export package retrieved' })
  async getExportById(@Param('id', ParseIntPipe) id: number) {
    return this.asBuiltService.getExportById(id);
  }

  @Post('exports')
  @ApiOperation({ summary: 'Create an export package' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Export package created' })
  async createExportPackage(@Body() dto: CreateExportPackageDto) {
    return this.asBuiltService.createExportPackage(dto);
  }

  // ========== HEALTH ==========

  @Get('health')
  @ApiOperation({ summary: 'As-built module health check' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Service is healthy' })
  async health() {
    return {
      status: 'ok',
      service: 'as-built',
      timestamp: new Date().toISOString(),
    };
  }
}
