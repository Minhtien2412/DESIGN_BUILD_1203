import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsDateString,
    IsEnum,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
} from 'class-validator';
import { EventType } from '../entities';

export class TrackEventDto {
  @ApiProperty({ description: 'Session ID', example: 'sess_abc123' })
  @IsString()
  sessionId: string;

  @ApiProperty({ enum: EventType, example: EventType.PAGE_VIEW })
  @IsEnum(EventType)
  eventType: EventType;

  @ApiProperty({ description: 'Event name', example: 'button_click' })
  @IsString()
  eventName: string;

  @ApiPropertyOptional({ description: 'Page URL' })
  @IsOptional()
  @IsString()
  page?: string;

  @ApiPropertyOptional({ description: 'Referrer URL' })
  @IsOptional()
  @IsString()
  referrer?: string;

  @ApiPropertyOptional({ description: 'Event properties' })
  @IsOptional()
  @IsObject()
  properties?: Record<string, any>;

  @ApiPropertyOptional({ description: 'User ID' })
  @IsOptional()
  @IsNumber()
  userId?: number;
}

export class QueryAnalyticsDto {
  @ApiPropertyOptional({ description: 'Start date', example: '2026-01-01' })
  @IsOptional()
  @IsDateString()
  startDate?: string;

  @ApiPropertyOptional({ description: 'End date', example: '2026-01-31' })
  @IsOptional()
  @IsDateString()
  endDate?: string;

  @ApiPropertyOptional({ description: 'User ID' })
  @IsOptional()
  @IsNumber()
  userId?: number;

  @ApiPropertyOptional({ enum: EventType })
  @IsOptional()
  @IsEnum(EventType)
  eventType?: EventType;

  @ApiPropertyOptional({ description: 'Page filter' })
  @IsOptional()
  @IsString()
  page?: string;

  @ApiPropertyOptional({ description: 'Limit results', default: 100 })
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional({ description: 'Offset for pagination', default: 0 })
  @IsOptional()
  @IsNumber()
  offset?: number;
}

export class ComparePeriodsDto {
  @ApiProperty({ description: 'Current period start', example: '2026-01-15' })
  @IsDateString()
  currentStart: string;

  @ApiProperty({ description: 'Current period end', example: '2026-01-21' })
  @IsDateString()
  currentEnd: string;

  @ApiProperty({ description: 'Previous period start', example: '2026-01-08' })
  @IsDateString()
  previousStart: string;

  @ApiProperty({ description: 'Previous period end', example: '2026-01-14' })
  @IsDateString()
  previousEnd: string;
}

export class ExportAnalyticsDto {
  @ApiProperty({ description: 'Start date', example: '2026-01-01' })
  @IsDateString()
  startDate: string;

  @ApiProperty({ description: 'End date', example: '2026-01-31' })
  @IsDateString()
  endDate: string;

  @ApiPropertyOptional({
    description: 'Export format',
    enum: ['json', 'csv'],
    default: 'json',
  })
  @IsOptional()
  @IsString()
  format?: 'json' | 'csv';

  @ApiPropertyOptional({ description: 'Metrics to include', type: [String] })
  @IsOptional()
  metrics?: string[];
}

export class CreateReportTemplateDto {
  @ApiProperty({ description: 'Template name', example: 'Weekly Report' })
  @IsString()
  name: string;

  @ApiPropertyOptional({ description: 'Template description' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    description: 'Metrics to include',
    type: [String],
    example: ['pageViews', 'sessions', 'users'],
  })
  metrics: string[];

  @ApiPropertyOptional({ description: 'Default filters' })
  @IsOptional()
  @IsObject()
  filters?: Record<string, any>;

  @ApiPropertyOptional({
    description: 'Cron schedule',
    example: '0 9 * * 1',
  })
  @IsOptional()
  @IsString()
  schedule?: string;
}
