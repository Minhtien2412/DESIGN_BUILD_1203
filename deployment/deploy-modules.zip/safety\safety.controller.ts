import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Body,
  Param,
  Query,
  HttpStatus,
  ParseIntPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';
import { SafetyService } from './safety.service';
import {
  CreateAuditDto,
  UpdateAuditDto,
  AddFindingDto,
  CreateIncidentDto,
  UpdateIncidentDto,
  DistributePPEDto,
  ReturnPPEDto,
  CreateTrainingDto,
  UpdateTrainingDto,
  RecordAttendanceDto,
  QueryAuditDto,
  QueryIncidentDto,
} from './dto';
import { AuditStatus, AuditType, IncidentSeverity, IncidentStatus, TrainingStatus } from './entities';

@ApiTags('Safety')
@Controller('safety')
export class SafetyController {
  constructor(private readonly safetyService: SafetyService) {}

  // ========== DASHBOARD ==========

  @Get('dashboard')
  @ApiOperation({ summary: 'Get safety dashboard metrics' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Dashboard metrics retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getDashboard(@Query('projectId') projectId?: string) {
    return this.safetyService.getDashboard(projectId ? parseInt(projectId) : undefined);
  }

  // ========== AUDITS ==========

  @Get('audits')
  @ApiOperation({ summary: 'Get safety audits with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Audits retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: AuditStatus })
  @ApiQuery({ name: 'auditType', required: false, enum: AuditType })
  @ApiQuery({ name: 'fromDate', required: false, type: String })
  @ApiQuery({ name: 'toDate', required: false, type: String })
  async getAudits(@Query() query: QueryAuditDto) {
    return this.safetyService.getAudits(query);
  }

  @Get('audits/:id')
  @ApiOperation({ summary: 'Get audit by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Audit retrieved' })
  async getAuditById(@Param('id', ParseIntPipe) id: number) {
    return this.safetyService.getAuditById(id);
  }

  @Post('audits')
  @ApiOperation({ summary: 'Create a new safety audit' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Audit created' })
  async createAudit(@Body() dto: CreateAuditDto) {
    return this.safetyService.createAudit(dto);
  }

  @Put('audits/:id')
  @ApiOperation({ summary: 'Update a safety audit' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Audit updated' })
  async updateAudit(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateAuditDto) {
    return this.safetyService.updateAudit(id, dto);
  }

  @Post('audits/:id/findings')
  @ApiOperation({ summary: 'Add finding to an audit' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Finding added' })
  async addFinding(@Param('id', ParseIntPipe) id: number, @Body() dto: AddFindingDto) {
    return this.safetyService.addFinding(id, dto);
  }

  @Patch('audits/:auditId/findings/:findingId/resolve')
  @ApiOperation({ summary: 'Resolve an audit finding' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Finding resolved' })
  async resolveFinding(
    @Param('auditId', ParseIntPipe) auditId: number,
    @Param('findingId', ParseIntPipe) findingId: number,
  ) {
    return this.safetyService.resolveFinding(auditId, findingId);
  }

  // ========== INCIDENTS ==========

  @Get('incidents')
  @ApiOperation({ summary: 'Get safety incidents with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incidents retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: IncidentStatus })
  @ApiQuery({ name: 'severity', required: false, enum: IncidentSeverity })
  @ApiQuery({ name: 'fromDate', required: false, type: String })
  @ApiQuery({ name: 'toDate', required: false, type: String })
  async getIncidents(@Query() query: QueryIncidentDto) {
    return this.safetyService.getIncidents(query);
  }

  @Get('incidents/:id')
  @ApiOperation({ summary: 'Get incident by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incident retrieved' })
  async getIncidentById(@Param('id', ParseIntPipe) id: number) {
    return this.safetyService.getIncidentById(id);
  }

  @Post('incidents')
  @ApiOperation({ summary: 'Report a new safety incident' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Incident created' })
  async createIncident(@Body() dto: CreateIncidentDto) {
    return this.safetyService.createIncident(dto);
  }

  @Put('incidents/:id')
  @ApiOperation({ summary: 'Update a safety incident' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incident updated' })
  async updateIncident(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateIncidentDto) {
    return this.safetyService.updateIncident(id, dto);
  }

  // ========== PPE ==========

  @Get('ppe')
  @ApiOperation({ summary: 'Get PPE distributions' })
  @ApiResponse({ status: HttpStatus.OK, description: 'PPE distributions retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'workerId', required: false, type: Number })
  async getPPEDistributions(
    @Query('projectId') projectId?: string,
    @Query('workerId') workerId?: string,
  ) {
    return this.safetyService.getPPEDistributions(
      projectId ? parseInt(projectId) : undefined,
      workerId ? parseInt(workerId) : undefined,
    );
  }

  @Post('ppe/distribute')
  @ApiOperation({ summary: 'Distribute PPE to a worker' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'PPE distributed' })
  async distributePPE(@Body() dto: DistributePPEDto) {
    return this.safetyService.distributePPE(dto);
  }

  @Patch('ppe/:id/return')
  @ApiOperation({ summary: 'Record PPE return' })
  @ApiResponse({ status: HttpStatus.OK, description: 'PPE return recorded' })
  async returnPPE(@Param('id', ParseIntPipe) id: number, @Body() dto: ReturnPPEDto) {
    return this.safetyService.returnPPE(id, dto);
  }

  // ========== TRAININGS ==========

  @Get('trainings')
  @ApiOperation({ summary: 'Get safety trainings' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Trainings retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: TrainingStatus })
  async getTrainings(
    @Query('projectId') projectId?: string,
    @Query('status') status?: TrainingStatus,
  ) {
    return this.safetyService.getTrainings(
      projectId ? parseInt(projectId) : undefined,
      status,
    );
  }

  @Get('trainings/:id')
  @ApiOperation({ summary: 'Get training by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Training retrieved' })
  async getTrainingById(@Param('id', ParseIntPipe) id: number) {
    return this.safetyService.getTrainingById(id);
  }

  @Post('trainings')
  @ApiOperation({ summary: 'Create a new safety training' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Training created' })
  async createTraining(@Body() dto: CreateTrainingDto) {
    return this.safetyService.createTraining(dto);
  }

  @Put('trainings/:id')
  @ApiOperation({ summary: 'Update a safety training' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Training updated' })
  async updateTraining(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateTrainingDto) {
    return this.safetyService.updateTraining(id, dto);
  }

  @Post('trainings/:id/attendance')
  @ApiOperation({ summary: 'Record training attendance' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Attendance recorded' })
  async recordAttendance(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RecordAttendanceDto,
  ) {
    return this.safetyService.recordAttendance(id, dto);
  }

  // ========== HEALTH ==========

  @Get('health')
  @ApiOperation({ summary: 'Safety module health check' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Service is healthy' })
  async health() {
    return {
      status: 'ok',
      service: 'safety',
      timestamp: new Date().toISOString(),
    };
  }
}
