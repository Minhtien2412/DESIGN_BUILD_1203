import { Injectable } from '@nestjs/common';
import {
    ComparePeriodsDto,
    CreateReportTemplateDto,
    ExportAnalyticsDto,
    QueryAnalyticsDto,
    TrackEventDto,
} from './dto';
import {
    AnalyticsEvent,
    AnalyticsSession,
    DashboardMetrics,
    EventType,
    ReportTemplate,
    UserFlowStep,
} from './entities';

@Injectable()
export class AnalyticsService {
  private events: Map<number, AnalyticsEvent> = new Map();
  private sessions: Map<string, AnalyticsSession> = new Map();
  private templates: Map<number, ReportTemplate> = new Map();
  private eventIdCounter = 1;
  private templateIdCounter = 1;

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const now = new Date();
    const pages = [
      '/home',
      '/products',
      '/cart',
      '/checkout',
      '/profile',
      '/settings',
    ];
    const devices = ['mobile', 'desktop', 'tablet'];
    const browsers = ['Chrome', 'Safari', 'Firefox', 'Edge'];
    const countries = ['Vietnam', 'USA', 'Japan', 'Singapore'];

    // Generate sample sessions
    for (let i = 0; i < 50; i++) {
      const sessionId = `sess_${Date.now()}_${i}`;
      const startTime = new Date(
        now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000,
      );

      this.sessions.set(sessionId, {
        id: sessionId,
        userId:
          Math.random() > 0.3 ? Math.floor(Math.random() * 100) + 1 : undefined,
        startTime,
        endTime: new Date(startTime.getTime() + Math.random() * 30 * 60 * 1000),
        pageViews: Math.floor(Math.random() * 10) + 1,
        events: Math.floor(Math.random() * 20) + 1,
        duration: Math.floor(Math.random() * 1800) + 60,
        entryPage: pages[Math.floor(Math.random() * pages.length)],
        exitPage: pages[Math.floor(Math.random() * pages.length)],
        device: devices[Math.floor(Math.random() * devices.length)],
        browser: browsers[Math.floor(Math.random() * browsers.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
      });

      // Generate events for each session
      const eventCount = Math.floor(Math.random() * 10) + 1;
      for (let j = 0; j < eventCount; j++) {
        const eventTypes = Object.values(EventType);
        this.events.set(this.eventIdCounter, {
          id: this.eventIdCounter++,
          sessionId,
          eventType: eventTypes[Math.floor(Math.random() * eventTypes.length)],
          eventName: `event_${j}`,
          page: pages[Math.floor(Math.random() * pages.length)],
          device: devices[Math.floor(Math.random() * devices.length)],
          browser: browsers[Math.floor(Math.random() * browsers.length)],
          country: countries[Math.floor(Math.random() * countries.length)],
          createdAt: new Date(startTime.getTime() + j * 60000),
        });
      }
    }

    // Sample templates
    this.templates.set(1, {
      id: 1,
      name: 'Weekly Performance',
      description: 'Weekly analytics summary',
      metrics: ['pageViews', 'sessions', 'users', 'bounceRate'],
      schedule: '0 9 * * 1',
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    this.templateIdCounter = 2;
  }

  // ============ DASHBOARD ============

  async getDashboard(
    startDate?: Date,
    endDate?: Date,
  ): Promise<DashboardMetrics> {
    const events = this.filterEventsByDate(startDate, endDate);
    const sessions = this.filterSessionsByDate(startDate, endDate);

    const uniqueUsers = new Set(
      [...events, ...Array.from(sessions.values())]
        .filter((e) => 'userId' in e && e.userId)
        .map((e) => ('userId' in e ? e.userId : null)),
    );

    const pageViewEvents = events.filter(
      (e) => e.eventType === EventType.PAGE_VIEW,
    );
    const pageViewCounts: Record<string, number> = {};
    pageViewEvents.forEach((e) => {
      if (e.page) {
        pageViewCounts[e.page] = (pageViewCounts[e.page] || 0) + 1;
      }
    });

    const eventCounts: Record<string, number> = {};
    events.forEach((e) => {
      eventCounts[e.eventName] = (eventCounts[e.eventName] || 0) + 1;
    });

    const deviceCounts: Record<string, number> = {};
    const countryCounts: Record<string, number> = {};
    sessions.forEach((s) => {
      if (s.device) deviceCounts[s.device] = (deviceCounts[s.device] || 0) + 1;
      if (s.country)
        countryCounts[s.country] = (countryCounts[s.country] || 0) + 1;
    });

    const totalDuration = Array.from(sessions.values()).reduce(
      (sum, s) => sum + (s.duration || 0),
      0,
    );
    const bouncedSessions = Array.from(sessions.values()).filter(
      (s) => s.pageViews === 1,
    ).length;

    return {
      totalUsers: uniqueUsers.size,
      activeUsers: Math.floor(uniqueUsers.size * 0.7),
      totalSessions: sessions.size,
      totalPageViews: pageViewEvents.length,
      totalEvents: events.length,
      avgSessionDuration:
        sessions.size > 0 ? Math.round(totalDuration / sessions.size) : 0,
      bounceRate:
        sessions.size > 0
          ? Math.round((bouncedSessions / sessions.size) * 100)
          : 0,
      topPages: Object.entries(pageViewCounts)
        .map(([page, views]) => ({ page, views }))
        .sort((a, b) => b.views - a.views)
        .slice(0, 10),
      topEvents: Object.entries(eventCounts)
        .map(([event, count]) => ({ event, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      usersByDevice: Object.entries(deviceCounts)
        .map(([device, count]) => ({ device, count }))
        .sort((a, b) => b.count - a.count),
      usersByCountry: Object.entries(countryCounts)
        .map(([country, count]) => ({ country, count }))
        .sort((a, b) => b.count - a.count),
    };
  }

  // ============ EVENTS ============

  async trackEvent(dto: TrackEventDto, request?: any): Promise<AnalyticsEvent> {
    const event: AnalyticsEvent = {
      id: this.eventIdCounter++,
      ...dto,
      userAgent: request?.headers?.['user-agent'],
      ip: request?.ip,
      createdAt: new Date(),
    };

    this.events.set(event.id, event);

    // Update or create session
    let session = this.sessions.get(dto.sessionId);
    if (!session) {
      session = {
        id: dto.sessionId,
        userId: dto.userId,
        startTime: new Date(),
        pageViews: 0,
        events: 0,
      };
      this.sessions.set(dto.sessionId, session);
    }

    session.events++;
    if (dto.eventType === EventType.PAGE_VIEW) {
      session.pageViews++;
      if (!session.entryPage) session.entryPage = dto.page;
      session.exitPage = dto.page;
    }
    session.endTime = new Date();
    session.duration = Math.floor(
      (session.endTime.getTime() - session.startTime.getTime()) / 1000,
    );

    return event;
  }

  async getEvents(
    query: QueryAnalyticsDto,
  ): Promise<{ data: AnalyticsEvent[]; total: number }> {
    let events = Array.from(this.events.values());

    if (query.startDate) {
      const start = new Date(query.startDate);
      events = events.filter((e) => e.createdAt >= start);
    }
    if (query.endDate) {
      const end = new Date(query.endDate);
      events = events.filter((e) => e.createdAt <= end);
    }
    if (query.userId) {
      events = events.filter((e) => e.userId === query.userId);
    }
    if (query.eventType) {
      events = events.filter((e) => e.eventType === query.eventType);
    }
    if (query.page) {
      events = events.filter((e) => e.page?.includes(query.page!));
    }

    const total = events.length;
    const offset = query.offset || 0;
    const limit = query.limit || 100;

    return {
      data: events.slice(offset, offset + limit),
      total,
    };
  }

  // ============ COMPARE PERIODS ============

  async comparePeriods(dto: ComparePeriodsDto) {
    const current = await this.getDashboard(
      new Date(dto.currentStart),
      new Date(dto.currentEnd),
    );
    const previous = await this.getDashboard(
      new Date(dto.previousStart),
      new Date(dto.previousEnd),
    );

    const calcChange = (curr: number, prev: number) =>
      prev > 0 ? Math.round(((curr - prev) / prev) * 100) : 0;

    return {
      current,
      previous,
      changes: {
        users: calcChange(current.totalUsers, previous.totalUsers),
        sessions: calcChange(current.totalSessions, previous.totalSessions),
        pageViews: calcChange(current.totalPageViews, previous.totalPageViews),
        avgDuration: calcChange(
          current.avgSessionDuration,
          previous.avgSessionDuration,
        ),
      },
    };
  }

  // ============ USER FLOW ============

  async getUserFlow(startPage?: string): Promise<UserFlowStep[]> {
    const sessions = Array.from(this.sessions.values());
    const pageCounts: Record<string, number> = {};
    const nextPageCounts: Record<string, Record<string, number>> = {};

    sessions.forEach((session) => {
      const sessionEvents = Array.from(this.events.values())
        .filter(
          (e) =>
            e.sessionId === session.id &&
            e.eventType === EventType.PAGE_VIEW &&
            e.page,
        )
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

      for (let i = 0; i < sessionEvents.length; i++) {
        const page = sessionEvents[i].page!;
        if (startPage && i === 0 && page !== startPage) continue;

        pageCounts[page] = (pageCounts[page] || 0) + 1;

        if (i < sessionEvents.length - 1) {
          const nextPage = sessionEvents[i + 1].page!;
          if (!nextPageCounts[page]) nextPageCounts[page] = {};
          nextPageCounts[page][nextPage] =
            (nextPageCounts[page][nextPage] || 0) + 1;
        }
      }
    });

    const totalViews = Object.values(pageCounts).reduce((a, b) => a + b, 0);

    return Object.entries(pageCounts)
      .map(([page, count]) => ({
        page,
        count,
        percentage: totalViews > 0 ? Math.round((count / totalViews) * 100) : 0,
        nextPages: Object.entries(nextPageCounts[page] || {})
          .map(([p, c]) => ({ page: p, count: c }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5),
      }))
      .sort((a, b) => b.count - a.count);
  }

  // ============ EXPORT ============

  async exportAnalytics(dto: ExportAnalyticsDto) {
    const dashboard = await this.getDashboard(
      new Date(dto.startDate),
      new Date(dto.endDate),
    );

    const data = {
      period: { start: dto.startDate, end: dto.endDate },
      generatedAt: new Date().toISOString(),
      metrics: dashboard,
    };

    if (dto.format === 'csv') {
      return this.convertToCSV(data);
    }

    return data;
  }

  private convertToCSV(data: any): string {
    const metrics = data.metrics;
    let csv = 'Metric,Value\n';
    csv += `Total Users,${metrics.totalUsers}\n`;
    csv += `Active Users,${metrics.activeUsers}\n`;
    csv += `Total Sessions,${metrics.totalSessions}\n`;
    csv += `Total Page Views,${metrics.totalPageViews}\n`;
    csv += `Total Events,${metrics.totalEvents}\n`;
    csv += `Avg Session Duration,${metrics.avgSessionDuration}s\n`;
    csv += `Bounce Rate,${metrics.bounceRate}%\n`;
    return csv;
  }

  // ============ TEMPLATES ============

  async getTemplates(): Promise<ReportTemplate[]> {
    return Array.from(this.templates.values());
  }

  async createTemplate(dto: CreateReportTemplateDto): Promise<ReportTemplate> {
    const template: ReportTemplate = {
      id: this.templateIdCounter++,
      ...dto,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.templates.set(template.id, template);
    return template;
  }

  // ============ HELPERS ============

  private filterEventsByDate(
    startDate?: Date,
    endDate?: Date,
  ): AnalyticsEvent[] {
    let events = Array.from(this.events.values());
    if (startDate) {
      events = events.filter((e) => e.createdAt >= startDate);
    }
    if (endDate) {
      events = events.filter((e) => e.createdAt <= endDate);
    }
    return events;
  }

  private filterSessionsByDate(
    startDate?: Date,
    endDate?: Date,
  ): Map<string, AnalyticsSession> {
    const filtered = new Map<string, AnalyticsSession>();
    this.sessions.forEach((session, id) => {
      let include = true;
      if (startDate && session.startTime < startDate) include = false;
      if (endDate && session.startTime > endDate) include = false;
      if (include) filtered.set(id, session);
    });
    return filtered;
  }
}
