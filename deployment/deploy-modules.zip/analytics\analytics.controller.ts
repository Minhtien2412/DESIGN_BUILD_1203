import {
    Body,
    Controller,
    Get,
    HttpStatus,
    Post,
    Query,
    Req,
} from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AnalyticsService } from './analytics.service';
import {
    ComparePeriodsDto,
    CreateReportTemplateDto,
    ExportAnalyticsDto,
    QueryAnalyticsDto,
    TrackEventDto,
} from './dto';

@ApiTags('Analytics')
@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  // ============ DASHBOARD ============

  @Get('dashboard')
  @ApiOperation({ summary: 'Get analytics dashboard metrics' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Dashboard metrics retrieved',
  })
  @ApiQuery({ name: 'startDate', required: false, type: String })
  @ApiQuery({ name: 'endDate', required: false, type: String })
  async getDashboard(
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.analyticsService.getDashboard(
      startDate ? new Date(startDate) : undefined,
      endDate ? new Date(endDate) : undefined,
    );
  }

  // ============ EVENTS ============

  @Post('events/track')
  @ApiOperation({ summary: 'Track an analytics event' })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Event tracked successfully',
  })
  async trackEvent(@Body() dto: TrackEventDto, @Req() request: any) {
    return this.analyticsService.trackEvent(dto, request);
  }

  @Get('events')
  @ApiOperation({ summary: 'Get analytics events with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Events retrieved' })
  async getEvents(@Query() query: QueryAnalyticsDto) {
    return this.analyticsService.getEvents(query);
  }

  // ============ COMPARE PERIODS ============

  @Post('compare')
  @ApiOperation({ summary: 'Compare metrics between two periods' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Period comparison completed',
  })
  async comparePeriods(@Body() dto: ComparePeriodsDto) {
    return this.analyticsService.comparePeriods(dto);
  }

  // ============ USER FLOW ============

  @Get('user-flow')
  @ApiOperation({ summary: 'Get user flow analytics' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User flow data retrieved',
  })
  @ApiQuery({ name: 'startPage', required: false, type: String })
  async getUserFlow(@Query('startPage') startPage?: string) {
    return this.analyticsService.getUserFlow(startPage);
  }

  // ============ EXPORT ============

  @Post('export')
  @ApiOperation({ summary: 'Export analytics data' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Analytics data exported',
  })
  async exportAnalytics(@Body() dto: ExportAnalyticsDto) {
    return this.analyticsService.exportAnalytics(dto);
  }

  // ============ TEMPLATES ============

  @Get('templates')
  @ApiOperation({ summary: 'Get report templates' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Templates retrieved' })
  async getTemplates() {
    return this.analyticsService.getTemplates();
  }

  @Post('templates')
  @ApiOperation({ summary: 'Create a report template' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Template created' })
  async createTemplate(@Body() dto: CreateReportTemplateDto) {
    return this.analyticsService.createTemplate(dto);
  }

  // ============ HEALTH ============

  @Get('health')
  @ApiOperation({ summary: 'Analytics service health check' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Service is healthy' })
  async health() {
    return {
      status: 'ok',
      service: 'analytics',
      timestamp: new Date().toISOString(),
    };
  }
}
