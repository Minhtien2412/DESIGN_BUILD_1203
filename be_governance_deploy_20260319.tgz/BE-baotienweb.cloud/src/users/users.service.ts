import {
    ConflictException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

/** Fields safe to return from user queries */
const USER_SAFE_SELECT = {
  id: true,
  email: true,
  name: true,
  avatar: true,
  avatarThumbnail: true,
  role: true,
  phone: true,
  emailVerified: true,
  isActive: true,
  bannedAt: true,
  banReason: true,
  createdAt: true,
  updatedAt: true,
} as const;

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  // ========================================
  // ADMIN: Paginated user list with filters
  // ========================================
  async findAllPaginated(
    options: {
      page?: number;
      limit?: number;
      role?: Role;
      isActive?: boolean;
      search?: string;
      sortBy?: string;
      sortOrder?: 'asc' | 'desc';
    } = {},
  ) {
    const {
      page = 1,
      limit = 20,
      role,
      isActive,
      search,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = options;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (role) where.role = role;
    if (isActive !== undefined) where.isActive = isActive;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        select: USER_SAFE_SELECT,
        orderBy: { [sortBy]: sortOrder },
        skip,
        take: limit,
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      users,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasMore: skip + users.length < total,
    };
  }

  // ========================================
  // ADMIN: Update user role
  // ========================================
  async updateRole(id: number, role: Role, adminId: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    // Prevent changing own role
    if (id === adminId) {
      throw new ForbiddenException('Cannot change your own role');
    }

    // Prevent demoting SUPER_ADMIN
    if (user.role === 'SUPER_ADMIN' && role !== 'SUPER_ADMIN') {
      throw new ForbiddenException('Cannot demote a SUPER_ADMIN');
    }

    return this.prisma.user.update({
      where: { id },
      data: { role },
      select: USER_SAFE_SELECT,
    });
  }

  // ========================================
  // ADMIN: Ban / Unban user
  // ========================================
  async toggleBan(id: number, ban: boolean, reason?: string, adminId?: number) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    if (id === adminId) {
      throw new ForbiddenException('Cannot ban yourself');
    }
    if (user.role === 'SUPER_ADMIN') {
      throw new ForbiddenException('Cannot ban a SUPER_ADMIN');
    }

    return this.prisma.user.update({
      where: { id },
      data: {
        isActive: !ban,
        bannedAt: ban ? new Date() : null,
        banReason: ban ? reason || 'Banned by administrator' : null,
      },
      select: USER_SAFE_SELECT,
    });
  }

  // ========================================
  // ADMIN: Dashboard stats
  // ========================================
  async getStats() {
    const [total, active, banned, roleStats] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.user.count({ where: { isActive: true } }),
      this.prisma.user.count({ where: { isActive: false } }),
      this.prisma.user.groupBy({
        by: ['role'],
        _count: { id: true },
      }),
    ]);

    // New users this month
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    const newThisMonth = await this.prisma.user.count({
      where: { createdAt: { gte: startOfMonth } },
    });

    return {
      total,
      active,
      banned,
      newThisMonth,
      byRole: roleStats.reduce(
        (acc, r) => {
          acc[r.role] = r._count.id;
          return acc;
        },
        {} as Record<string, number>,
      ),
    };
  }

  async findAll() {
    return this.prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      select: USER_SAFE_SELECT,
    });
  }

  async findOne(id: number) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        avatarThumbnail: true,
        role: true,
        phone: true,
        emailVerified: true,
        createdAt: true,
        updatedAt: true,
        // SECURITY: Never expose password or refreshToken
      },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return user;
  }

  /**
   * Search users by phone, email, name or username
   * Facebook-style search supporting multiple criteria
   */
  async search(
    query: string,
    type: 'all' | 'phone' | 'email' | 'name' | 'username' = 'all',
    options: {
      limit?: number;
      page?: number;
      friendsOnly?: boolean;
      userId?: number;
    } = {},
  ) {
    const { limit = 20, page = 1, friendsOnly = false, userId } = options;
    const skip = (page - 1) * limit;

    // Build search conditions based on type
    let whereCondition: any = {};

    const normalizedQuery = query.trim().toLowerCase();

    switch (type) {
      case 'phone':
        // Normalize phone number (remove non-digits, handle VN prefixes)
        const phoneQuery = query.replace(/\D/g, '').replace(/^(84|0)/, '');
        whereCondition = {
          phone: {
            contains: phoneQuery,
          },
        };
        break;

      case 'email':
        whereCondition = {
          email: {
            contains: normalizedQuery,
            mode: 'insensitive',
          },
        };
        break;

      case 'username':
        const usernameQuery = query.startsWith('@')
          ? query.substring(1)
          : query;
        whereCondition = {
          OR: [
            { username: { contains: usernameQuery, mode: 'insensitive' } },
            { name: { contains: usernameQuery, mode: 'insensitive' } },
          ],
        };
        break;

      case 'name':
      default:
        // Search across multiple fields
        whereCondition = {
          OR: [
            { name: { contains: normalizedQuery, mode: 'insensitive' } },
            { email: { contains: normalizedQuery, mode: 'insensitive' } },
            { phone: { contains: query.replace(/\D/g, '') } },
            { username: { contains: normalizedQuery, mode: 'insensitive' } },
          ],
        };
    }

    // Get total count
    const total = await this.prisma.user.count({
      where: whereCondition,
    });

    // Get users with pagination
    const users = await this.prisma.user.findMany({
      where: whereCondition,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatar: true,
        role: true,
        emailVerified: true,
        createdAt: true,
      },
      orderBy: [
        { emailVerified: 'desc' }, // Verified users first
        { name: 'asc' }, // Then alphabetically
      ],
      skip,
      take: limit,
    });

    // Map results with additional info
    const results = users.map((user) => ({
      ...user,
      isFriend: false, // TODO: Implement friend check
      isFollowing: false, // TODO: Implement following check
      mutualFriends: 0, // TODO: Implement mutual friends count
      matchType: type,
    }));

    return {
      users: results,
      total,
      page,
      limit,
      hasMore: skip + users.length < total,
    };
  }

  /**
   * Find user by exact phone number
   */
  async findByPhone(phone: string) {
    // Normalize phone
    const normalized = phone.replace(/\D/g, '').replace(/^(84|0)/, '');

    const user = await this.prisma.user.findFirst({
      where: {
        phone: {
          endsWith: normalized,
        },
      },
    });

    return user;
  }

  /**
   * Find user by exact email
   */
  async findByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });
  }

  /**
   * Get people you may know (based on mutual connections)
   */
  async getPeopleYouMayKnow(userId: number, limit = 20) {
    // For now, return users not connected with current user
    // TODO: Implement actual mutual friends logic
    const users = await this.prisma.user.findMany({
      where: {
        id: { not: userId },
      },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatar: true,
        role: true,
        emailVerified: true,
      },
      take: limit,
      orderBy: { createdAt: 'desc' },
    });

    return users.map((user) => ({
      ...user,
      mutualFriends: Math.floor(Math.random() * 10), // Mock for now
    }));
  }

  async create(createUserDto: CreateUserDto) {
    try {
      // Create user with a default password (users should register through auth instead)
      return await this.prisma.user.create({
        data: {
          ...createUserDto,
          password: 'default-password-use-auth-register', // Placeholder
        },
      });
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ConflictException('Email already exists');
      }
      throw error;
    }
  }

  async update(id: number, updateUserDto: UpdateUserDto) {
    await this.findOne(id); // Check if user exists

    try {
      return await this.prisma.user.update({
        where: { id },
        data: updateUserDto,
      });
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ConflictException('Email already exists');
      }
      throw error;
    }
  }

  async remove(id: number) {
    await this.findOne(id); // Check if user exists

    await this.prisma.user.delete({
      where: { id },
    });

    return { message: `User with ID ${id} has been deleted` };
  }

  // ==================== Notification Preferences ====================

  async getNotificationPreferences(userId: number) {
    let prefs = await this.prisma.notificationPreference.findUnique({
      where: { userId },
    });
    if (!prefs) {
      prefs = await this.prisma.notificationPreference.create({
        data: { userId },
      });
    }
    return prefs;
  }

  async updateNotificationPreferences(
    userId: number,
    data: Record<string, any>,
  ) {
    return this.prisma.notificationPreference.upsert({
      where: { userId },
      update: {
        ...(data.emailEnabled !== undefined
          ? { emailEnabled: data.emailEnabled }
          : {}),
        ...(data.pushEnabled !== undefined
          ? { pushEnabled: data.pushEnabled }
          : {}),
        ...(data.smsEnabled !== undefined
          ? { smsEnabled: data.smsEnabled }
          : {}),
        ...(data.inAppEnabled !== undefined
          ? { inAppEnabled: data.inAppEnabled }
          : {}),
        ...(data.quietHoursStart !== undefined
          ? { quietHoursStart: data.quietHoursStart }
          : {}),
        ...(data.quietHoursEnd !== undefined
          ? { quietHoursEnd: data.quietHoursEnd }
          : {}),
        ...(data.grouping !== undefined ? { grouping: data.grouping } : {}),
        ...(data.categories !== undefined
          ? { categories: data.categories }
          : {}),
      },
      create: {
        userId,
        ...(data.emailEnabled !== undefined
          ? { emailEnabled: data.emailEnabled }
          : {}),
        ...(data.pushEnabled !== undefined
          ? { pushEnabled: data.pushEnabled }
          : {}),
        ...(data.smsEnabled !== undefined
          ? { smsEnabled: data.smsEnabled }
          : {}),
        ...(data.inAppEnabled !== undefined
          ? { inAppEnabled: data.inAppEnabled }
          : {}),
      },
    });
  }

  // ==================== Online Status ====================

  async getOnlineStatus(userId: number) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, isActive: true, updatedAt: true },
    });
    if (!user) throw new NotFoundException('User not found');
    return {
      userId: user.id,
      status: user.isActive ? 'ONLINE' : 'OFFLINE',
      lastSeen: user.updatedAt,
    };
  }

  async updateOnlineStatus(userId: number, status: string, customStatus?: any) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { isActive: status === 'ONLINE' },
      select: { id: true, isActive: true },
    });
  }
}
