import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
    Request,
    UseGuards,
    ValidationPipe,
} from '@nestjs/common';
import {
    ApiBody,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { CreateUserDto, UpdateUserDto, UserResponseDto } from './dto';
import { UsersService } from './users.service';

@ApiTags('Users')
@Controller({ path: 'users', version: '1' })
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  /**
   * Search users by phone, email, name or username (Facebook-style)
   */
  @Get('search')
  @ApiOperation({ summary: 'Search users by phone, email, name or username' })
  @ApiQuery({ name: 'q', description: 'Search query', required: false })
  @ApiQuery({
    name: 'type',
    description: 'Search type: all, phone, email, name, username',
    required: false,
  })
  @ApiQuery({ name: 'limit', description: 'Results per page', required: false })
  @ApiQuery({ name: 'page', description: 'Page number', required: false })
  @ApiResponse({
    status: 200,
    description: 'Search results',
  })
  async search(
    @Query('q') query?: string,
    @Query('type')
    type: 'all' | 'phone' | 'email' | 'name' | 'username' = 'all',
    @Query('limit') limit?: string,
    @Query('page') page?: string,
  ) {
    // Return empty results if no query provided
    if (!query || query.trim() === '') {
      return {
        users: [],
        total: 0,
        page: 1,
        limit: 20,
        hasMore: false,
        message: 'Please provide a search query',
      };
    }
    return this.usersService.search(query, type, {
      limit: limit ? parseInt(limit, 10) : 20,
      page: page ? parseInt(page, 10) : 1,
    });
  }

  /**
   * Get people you may know
   */
  @Get('people-you-may-know')
  @ApiOperation({
    summary: 'Get people you may know based on mutual connections',
  })
  @ApiQuery({
    name: 'limit',
    description: 'Number of suggestions',
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'List of suggested users',
  })
  async getPeopleYouMayKnow(@Query('limit') limit?: string) {
    // TODO: Get actual user ID from JWT token
    const userId = 1; // Placeholder
    return this.usersService.getPeopleYouMayKnow(
      userId,
      limit ? parseInt(limit, 10) : 20,
    );
  }

  /**
   * Find user by phone number
   */
  @Get('by-phone/:phone')
  @ApiOperation({ summary: 'Find user by phone number' })
  @ApiParam({ name: 'phone', description: 'Phone number', type: String })
  @ApiResponse({
    status: 200,
    description: 'User found',
    type: UserResponseDto,
  })
  @ApiResponse({ status: 404, description: 'User not found' })
  async findByPhone(@Param('phone') phone: string) {
    const user = await this.usersService.findByPhone(phone);
    if (!user) {
      return { found: false, user: null };
    }
    return { found: true, user };
  }

  /**
   * Find user by email
   */
  @Get('by-email/:email')
  @ApiOperation({ summary: 'Find user by email' })
  @ApiParam({ name: 'email', description: 'Email address', type: String })
  @ApiResponse({
    status: 200,
    description: 'User found',
    type: UserResponseDto,
  })
  async findByEmail(@Param('email') email: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user) {
      return { found: false, user: null };
    }
    return { found: true, user };
  }

  // ========================================
  // ADMIN ENDPOINTS
  // ========================================

  @Get('admin/list')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: '[Admin] Paginated user list with filters' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'role', required: false, enum: Role })
  @ApiQuery({ name: 'isActive', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'sortBy', required: false })
  @ApiQuery({ name: 'sortOrder', required: false, enum: ['asc', 'desc'] })
  async adminListUsers(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('role') role?: Role,
    @Query('isActive') isActive?: string,
    @Query('search') search?: string,
    @Query('sortBy') sortBy?: string,
    @Query('sortOrder') sortOrder?: 'asc' | 'desc',
  ) {
    return this.usersService.findAllPaginated({
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20,
      role,
      isActive: isActive !== undefined ? isActive === 'true' : undefined,
      search,
      sortBy,
      sortOrder,
    });
  }

  @Get('admin/stats')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: '[Admin] User statistics' })
  async adminUserStats() {
    return this.usersService.getStats();
  }

  @Patch(':id/role')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: '[Admin] Change user role' })
  @ApiParam({ name: 'id', description: 'User ID', type: Number })
  @ApiBody({
    schema: {
      properties: { role: { type: 'string', enum: Object.values(Role) } },
    },
  })
  async updateRole(
    @Param('id', ParseIntPipe) id: number,
    @Body('role') role: Role,
    @Request() req: any,
  ) {
    const adminId = req.user?.id || req.user?.userId || 0;
    return this.usersService.updateRole(id, role, adminId);
  }

  @Patch(':id/ban')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: '[Admin] Ban or unban a user' })
  @ApiParam({ name: 'id', description: 'User ID', type: Number })
  @ApiBody({
    schema: {
      properties: { ban: { type: 'boolean' }, reason: { type: 'string' } },
    },
  })
  async toggleBan(
    @Param('id', ParseIntPipe) id: number,
    @Body('ban') ban: boolean,
    @Body('reason') reason: string,
    @Request() req: any,
  ) {
    const adminId = req.user?.id || req.user?.userId || 0;
    return this.usersService.toggleBan(id, ban, reason, adminId);
  }

  @Get()
  @ApiOperation({ summary: 'Get all users' })
  @ApiResponse({
    status: 200,
    description: 'List of all users',
    type: [UserResponseDto],
  })
  async findAll(): Promise<UserResponseDto[]> {
    return this.usersService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a user by ID' })
  @ApiParam({ name: 'id', description: 'User ID', type: Number })
  @ApiResponse({
    status: 200,
    description: 'User found',
    type: UserResponseDto,
  })
  @ApiResponse({ status: 404, description: 'User not found' })
  async findOne(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<UserResponseDto> {
    return this.usersService.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new user' })
  @ApiBody({ type: CreateUserDto })
  @ApiResponse({
    status: 201,
    description: 'User created successfully',
    type: UserResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 409, description: 'Email already exists' })
  async create(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    createUserDto: CreateUserDto,
  ): Promise<UserResponseDto> {
    return this.usersService.create(createUserDto);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a user' })
  @ApiParam({ name: 'id', description: 'User ID', type: Number })
  @ApiBody({ type: UpdateUserDto })
  @ApiResponse({
    status: 200,
    description: 'User updated successfully',
    type: UserResponseDto,
  })
  @ApiResponse({ status: 404, description: 'User not found' })
  @ApiResponse({ status: 409, description: 'Email already exists' })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    updateUserDto: UpdateUserDto,
  ): Promise<UserResponseDto> {
    return this.usersService.update(id, updateUserDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete a user' })
  @ApiParam({ name: 'id', description: 'User ID', type: Number })
  @ApiResponse({ status: 200, description: 'User deleted successfully' })
  @ApiResponse({ status: 404, description: 'User not found' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.usersService.remove(id);
  }

  // ==================== Notification Preferences ====================

  @Get('me/notification-preferences')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get notification preferences for current user' })
  @ApiResponse({ status: 200, description: 'Notification preferences' })
  async getNotificationPreferences(@Request() req: any) {
    return this.usersService.getNotificationPreferences(req.user.id);
  }

  @Put('me/notification-preferences')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Update notification preferences' })
  @ApiResponse({ status: 200, description: 'Updated preferences' })
  async updateNotificationPreferences(
    @Request() req: any,
    @Body() body: Record<string, any>,
  ) {
    return this.usersService.updateNotificationPreferences(req.user.id, body);
  }

  // ==================== Online Status ====================

  @Get(':id/status')
  @ApiOperation({ summary: 'Get user online status' })
  async getOnlineStatus(@Param('id', ParseIntPipe) id: number) {
    return this.usersService.getOnlineStatus(id);
  }

  @Put('me/status')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Update online status' })
  async updateOnlineStatus(
    @Request() req: any,
    @Body() body: { status: string; customStatus?: any },
  ) {
    return this.usersService.updateOnlineStatus(
      req.user.id,
      body.status,
      body.customStatus,
    );
  }
}
