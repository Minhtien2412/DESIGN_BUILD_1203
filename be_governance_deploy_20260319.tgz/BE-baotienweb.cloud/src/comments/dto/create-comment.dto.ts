import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsNumber, IsOptional } from 'class-validator';

export class CreateCommentDto {
  @ApiProperty({
    description: 'Comment content',
    example: 'This looks great! Please proceed with this design.',
  })
  @IsString()
  @IsNotEmpty()
  content: string;

  @ApiProperty({
    description: 'Project ID (required if taskId not provided)',
    required: false,
  })
  @IsNumber()
  @IsOptional()
  projectId?: number;

  @ApiProperty({
    description: 'Task ID (required if projectId not provided)',
    required: false,
  })
  @IsNumber()
  @IsOptional()
  taskId?: number;
}
