import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCommentDto } from './dto';
import { TimelineEventType } from '@prisma/client';

@Injectable()
export class CommentsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(createCommentDto: CreateCommentDto, userId: number) {
    const { projectId, taskId, content } = createCommentDto;

    if (!projectId && !taskId) {
      throw new BadRequestException(
        'Either projectId or taskId must be provided',
      );
    }

    const comment = await this.prisma.comment.create({
      data: {
        content,
        userId,
        projectId,
        taskId,
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
        task: { select: { id: true, title: true } },
      },
    });

    // Create timeline event if comment is for a project
    if (projectId) {
      await this.prisma.timeline.create({
        data: {
          projectId,
          eventType: TimelineEventType.COMMENT_ADDED,
          description: `Comment added by ${comment.user.name || comment.user.email}`,
          userId,
          metadata: { commentId: comment.id },
        },
      });
    }

    return comment;
  }

  async findAll(filters?: { projectId?: number; taskId?: number }) {
    return this.prisma.comment.findMany({
      where: {
        ...(filters?.projectId && { projectId: filters.projectId }),
        ...(filters?.taskId && { taskId: filters.taskId }),
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
        task: { select: { id: true, title: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async remove(id: number, userId: number) {
    const comment = await this.prisma.comment.findUnique({
      where: { id },
    });

    if (!comment) {
      throw new NotFoundException(`Comment with ID ${id} not found`);
    }

    // Only comment owner can delete
    if (comment.userId !== userId) {
      throw new BadRequestException('You can only delete your own comments');
    }

    await this.prisma.comment.delete({
      where: { id },
    });

    return { message: `Comment with ID ${id} has been deleted` };
  }
}
