import { Injectable } from '@nestjs/common';

import {
    AuditCategory,
    AuditLogService,
    AuditSeverity,
} from '../audit/audit-log.service';
import { CheckPriceAnomalyDto } from './dto/check-price-anomaly.dto';
import { CreateProductMasterDto } from './dto/create-product-master.dto';
import { ModerateMessageDto } from './dto/moderate-message.dto';
import { ReviewSellerOfferDto } from './dto/review-seller-offer.dto';
import { AutomationBoundaryService } from './services/automation-boundary.service';
import { MessageModerationService } from './services/message-moderation.service';
import { PriceAnomalyService } from './services/price-anomaly.service';
import { ProductMatchingService } from './services/product-matching.service';
import { ReviewQueueService } from './services/review-queue.service';
import { SellerComplianceService } from './services/seller-compliance.service';
import {
    AdminReviewQueuePreview,
    MatchResult,
    ModerationDecision,
    ModerationResult,
    PricingCheckResult,
    ProductMasterInput,
    ProductMasterStatus,
} from './types/marketplace-governance.types';

export interface ProductMasterNormalizationResult {
  canonicalTitle: string;
  fingerprint: string;
  recommendedStatus: ProductMasterStatus;
  reviewReasons: string[];
  normalizedPayload: ProductMasterInput;
}

export interface SellerOfferAssessmentResult {
  topMatch?: MatchResult;
  allMatches: MatchResult[];
  pricing: PricingCheckResult;
  compliance: ReturnType<SellerComplianceService['evaluateSubmission']>;
  reviewQueue: AdminReviewQueuePreview[];
  automationBoundary: ReturnType<
    AutomationBoundaryService['forOfferAssessment']
  >;
  autoPublishEligible: boolean;
}

export interface ModerateMessageResponse {
  moderation: ModerationResult;
  reviewQueue: AdminReviewQueuePreview[];
  automationBoundary: ReturnType<
    AutomationBoundaryService['forMessageModeration']
  >;
  allowSend: boolean;
}

@Injectable()
export class MarketplaceGovernanceService {
  constructor(
    private readonly auditLogService: AuditLogService,
    private readonly productMatchingService: ProductMatchingService,
    private readonly priceAnomalyService: PriceAnomalyService,
    private readonly sellerComplianceService: SellerComplianceService,
    private readonly messageModerationService: MessageModerationService,
    private readonly reviewQueueService: ReviewQueueService,
    private readonly automationBoundaryService: AutomationBoundaryService,
  ) {}

  async normalizeProductMaster(
    dto: CreateProductMasterDto,
  ): Promise<ProductMasterNormalizationResult> {
    const reviewReasons: string[] = [];

    if (!dto.brand || !dto.model) {
      reviewReasons.push(
        'Brand and model must both be present for strong catalog normalization.',
      );
    }
    if (Object.keys(dto.variantAttributes).length === 0) {
      reviewReasons.push(
        'Variant attributes are empty, reducing dedupe confidence.',
      );
    }
    if (dto.images.length === 0) {
      reviewReasons.push('At least one canonical image should be attached.');
    }

    const canonicalTitle = this.buildCanonicalTitle(dto);
    const normalizedPayload: ProductMasterInput = {
      ...dto,
      title: canonicalTitle,
      status:
        reviewReasons.length > 0
          ? ProductMasterStatus.REVIEW_REQUIRED
          : ProductMasterStatus.ACTIVE,
    };

    const result: ProductMasterNormalizationResult = {
      canonicalTitle,
      fingerprint: this.buildFingerprint(dto),
      recommendedStatus: normalizedPayload.status ?? ProductMasterStatus.DRAFT,
      reviewReasons,
      normalizedPayload,
    };

    await this.auditLogService.log({
      category: AuditCategory.RESOURCE,
      action: 'marketplace_product_master_normalized',
      severity:
        reviewReasons.length > 0 ? AuditSeverity.WARNING : AuditSeverity.INFO,
      targetResourceType: 'product_master',
      targetResourceId: dto.productMasterCode,
      outcome: 'success',
      details: {
        canonicalTitle: result.canonicalTitle,
        fingerprint: result.fingerprint,
        recommendedStatus: result.recommendedStatus,
        reviewReasons: result.reviewReasons,
        normalizedPayload: result.normalizedPayload,
      },
    });

    return result;
  }

  assessPriceAnomaly(dto: CheckPriceAnomalyDto): PricingCheckResult {
    return this.priceAnomalyService.analyze(dto);
  }

  async assessSellerOffer(
    dto: ReviewSellerOfferDto,
  ): Promise<SellerOfferAssessmentResult> {
    const allMatches =
      this.productMatchingService.evaluateOfferAgainstCandidates(
        dto.offer,
        dto.candidates,
        dto.autoMapThreshold,
        dto.reviewThreshold,
      );
    const submittedOfferId = `submitted-${dto.offer.sellerSku}`;
    const pricing = this.priceAnomalyService.analyze({
      productMasterId:
        dto.offer.productMasterId ??
        allMatches[0]?.productMasterId ??
        'unmapped',
      category: dto.offer.declaredCategory,
      offers: [
        {
          offerId: submittedOfferId,
          sellerId: dto.offer.sellerId,
          salePrice: dto.offer.salePrice,
          verifiedFlags: dto.offer.verifiedFlags,
          premiumReason: dto.offer.premiumReason,
        },
        ...dto.marketOffers,
      ],
      targetOfferId: submittedOfferId,
      thresholdOverride: dto.thresholdOverride,
      platformFeeRatio: dto.platformFeeRatio,
    });
    const compliance = this.sellerComplianceService.evaluateSubmission(
      dto.offer,
    );
    const reviewQueue = this.reviewQueueService.buildOfferReviewQueue({
      offer: dto.offer,
      matchResults: allMatches,
      pricing,
      compliance,
    });
    const automationBoundary =
      this.automationBoundaryService.forOfferAssessment(reviewQueue.length > 0);

    const autoPublishEligible =
      reviewQueue.length === 0 &&
      compliance.recommendedStatus === 'ACTIVE' &&
      allMatches[0]?.disposition === 'AUTO_MAP';

    const result: SellerOfferAssessmentResult = {
      topMatch: allMatches[0],
      allMatches,
      pricing,
      compliance,
      reviewQueue,
      automationBoundary,
      autoPublishEligible,
    };

    await this.auditLogService.log({
      category: AuditCategory.RESOURCE,
      action: 'marketplace_offer_assessed',
      severity:
        reviewQueue.length > 0 ? AuditSeverity.WARNING : AuditSeverity.INFO,
      userId: dto.offer.sellerId,
      targetResourceType: 'seller_offer',
      targetResourceId: dto.offer.sellerSku,
      outcome: 'success',
      details: {
        autoPublishEligible,
        topDisposition: allMatches[0]?.disposition,
        pricingSeverity: pricing.severity,
        complianceStatus: compliance.recommendedStatus,
      },
    });

    return result;
  }

  async moderateMessage(
    dto: ModerateMessageDto,
  ): Promise<ModerateMessageResponse> {
    const moderation = this.messageModerationService.moderate({
      message: dto.message,
      recentMessages: dto.recentMessages,
      senderIsTrusted: dto.senderIsTrusted,
    });
    const reviewQueue = this.reviewQueueService.buildMessageModerationQueue({
      senderId: dto.senderId,
      message: dto.message,
      moderation,
    });
    const automationBoundary =
      this.automationBoundaryService.forMessageModeration(moderation.decision);

    await this.auditLogService.log({
      category: AuditCategory.SECURITY,
      action: 'marketplace_message_moderated',
      severity:
        moderation.decision === ModerationDecision.ALLOW
          ? AuditSeverity.INFO
          : AuditSeverity.WARNING,
      userId: dto.senderId,
      targetResourceType: 'chat_message',
      outcome: 'success',
      details: {
        decision: moderation.decision,
        riskScore: moderation.riskScore,
        hitRules: moderation.ruleHits.map((hit) => hit.ruleCode),
      },
    });

    return {
      moderation,
      reviewQueue,
      automationBoundary,
      allowSend: moderation.decision === ModerationDecision.ALLOW,
    };
  }

  getAutomationBoundaries() {
    return {
      sellerOfferAssessment:
        this.automationBoundaryService.forOfferAssessment(false),
      messageModeration: this.automationBoundaryService.forMessageModeration(
        ModerationDecision.WARN,
      ),
    };
  }

  private buildCanonicalTitle(dto: CreateProductMasterDto): string {
    const variantSummary = Object.entries(dto.variantAttributes)
      .slice(0, 3)
      .map(([key, value]) => `${key} ${value}`)
      .join(' ')
      .trim();

    return [dto.brand, dto.model, variantSummary || dto.title]
      .filter(Boolean)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  private buildFingerprint(dto: CreateProductMasterDto): string {
    const raw = [
      dto.brand,
      dto.model,
      dto.category,
      JSON.stringify(dto.variantAttributes),
      JSON.stringify(dto.technicalSpecs),
    ]
      .join('|')
      .toLowerCase();

    return Buffer.from(raw).toString('base64url').slice(0, 48);
  }
}
