import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum, IsInt, IsOptional } from 'class-validator';

export enum ReviewQueueStatusDto {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  RESOLVED = 'RESOLVED',
}

export enum ReviewQueueSourceDto {
  PRODUCT_MATCH = 'PRODUCT_MATCH',
  PRICE_ANOMALY = 'PRICE_ANOMALY',
  SELLER_COMPLIANCE = 'SELLER_COMPLIANCE',
  MESSAGE_MODERATION = 'MESSAGE_MODERATION',
  AUTOMATION_ESCALATION = 'AUTOMATION_ESCALATION',
}

export class ReviewQueueQueryDto {
  @ApiPropertyOptional({ enum: ReviewQueueStatusDto })
  @IsOptional()
  @IsEnum(ReviewQueueStatusDto)
  status?: ReviewQueueStatusDto;

  @ApiPropertyOptional({ enum: ReviewQueueSourceDto })
  @IsOptional()
  @IsEnum(ReviewQueueSourceDto)
  source?: ReviewQueueSourceDto;

  @ApiPropertyOptional({ example: 12 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  assignedToId?: number;
}
