import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsInt,
    IsOptional,
    IsString,
} from 'class-validator';

export class ModerateMessageDto {
  @ApiProperty({ example: 1001 })
  @IsInt()
  senderId!: number;

  @ApiPropertyOptional({ example: 2001 })
  @IsOptional()
  @IsInt()
  receiverId?: number;

  @ApiPropertyOptional({ example: 'seller_support' })
  @IsOptional()
  @IsString()
  roomType?: string;

  @ApiProperty({ example: 'Anh cho em số Zalo để trao đổi nhanh nhé' })
  @IsString()
  message!: string;

  @ApiPropertyOptional({
    type: [String],
    example: ['Tin nhắn cũ 1', 'Tin nhắn cũ 2'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  recentMessages?: string[];

  @ApiPropertyOptional({ example: 'electronics' })
  @IsOptional()
  @IsString()
  categoryPolicy?: string;

  @ApiPropertyOptional({ example: false })
  @IsOptional()
  @IsBoolean()
  senderIsTrusted?: boolean;
}
