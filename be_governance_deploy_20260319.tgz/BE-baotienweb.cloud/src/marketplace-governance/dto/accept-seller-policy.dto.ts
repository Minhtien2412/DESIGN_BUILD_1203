import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class AcceptSellerPolicyDto {
  @ApiPropertyOptional({
    example: 'marketplace-seller-liability-v1',
    description: 'Policy version being accepted for this product',
  })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  policyVersion?: string;

  @ApiPropertyOptional({
    example: 'android-13-device-fingerprint',
    description: 'Optional device fingerprint for auditability',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  deviceFingerprint?: string;
}
