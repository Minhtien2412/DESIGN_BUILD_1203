import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

import { CreateSellerOfferDto } from './create-seller-offer.dto';

export class EvaluateComplianceDto extends CreateSellerOfferDto {
  @ApiProperty({ example: 'seller-liability-v1' })
  @IsString()
  liabilityPolicyVersion!: string;

  @ApiPropertyOptional({ example: '203.113.25.8' })
  @IsOptional()
  @IsString()
  ipAddress?: string;

  @ApiPropertyOptional({ example: 'ios-iphone15pro-app-54' })
  @IsOptional()
  @IsString()
  deviceFingerprint?: string;
}
