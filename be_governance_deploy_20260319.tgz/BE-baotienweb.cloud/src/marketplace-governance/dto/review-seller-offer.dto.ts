import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsInt,
    IsNumber,
    IsObject,
    IsOptional,
    Min,
    ValidateNested,
} from 'class-validator';

import { PricingOfferInputDto } from './check-price-anomaly.dto';
import { EvaluateComplianceDto } from './evaluate-compliance.dto';
import { MatchCandidateDto } from './match-offer.dto';

export class ReviewSellerOfferDto {
  @ValidateNested()
  @Type(() => EvaluateComplianceDto)
  offer!: EvaluateComplianceDto;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MatchCandidateDto)
  candidates!: MatchCandidateDto[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PricingOfferInputDto)
  marketOffers!: PricingOfferInputDto[];

  @ApiPropertyOptional({ example: 85 })
  @IsOptional()
  @IsInt()
  @Min(0)
  autoMapThreshold?: number;

  @ApiPropertyOptional({ example: 60 })
  @IsOptional()
  @IsInt()
  @Min(0)
  reviewThreshold?: number;

  @ApiPropertyOptional({
    type: Object,
    example: { warningPct: 10, reviewPct: 15, highRiskPct: 20 },
  })
  @IsOptional()
  @IsObject()
  thresholdOverride?: {
    warningPct: number;
    reviewPct: number;
    highRiskPct: number;
  };

  @ApiPropertyOptional({ example: 0.12 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  platformFeeRatio?: number;
}
