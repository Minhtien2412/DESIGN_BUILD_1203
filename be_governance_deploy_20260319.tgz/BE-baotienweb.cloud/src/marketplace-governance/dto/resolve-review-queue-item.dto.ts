import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export enum ReviewQueueResolutionStatusDto {
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  RESOLVED = 'RESOLVED',
}

export class ResolveReviewQueueItemDto {
  @ApiProperty({ enum: ReviewQueueResolutionStatusDto })
  @IsEnum(ReviewQueueResolutionStatusDto)
  status: ReviewQueueResolutionStatusDto;

  @ApiPropertyOptional({
    example: 'Reviewed manually by catalog QC and approved for publishing.',
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  note?: string;
}
