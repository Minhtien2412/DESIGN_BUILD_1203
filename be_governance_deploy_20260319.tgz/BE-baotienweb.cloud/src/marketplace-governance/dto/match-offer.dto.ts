import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsInt,
    IsObject,
    IsOptional,
    IsString,
    Min,
    ValidateNested,
} from 'class-validator';

import { CreateSellerOfferDto } from './create-seller-offer.dto';

export class MatchCandidateDto {
  @ApiProperty({ example: 'pm_thermo_001' })
  @IsString()
  productMasterId!: string;

  @ApiProperty({ example: 'Philips' })
  @IsString()
  brand!: string;

  @ApiProperty({ example: 'HD9350' })
  @IsString()
  model!: string;

  @ApiProperty({ example: 'Ấm siêu tốc Philips 1.8L inox' })
  @IsString()
  title!: string;

  @ApiProperty({ type: Object })
  @IsObject()
  variantAttributes!: Record<string, string | number | boolean | null>;

  @ApiProperty({ type: Object })
  @IsObject()
  technicalSpecs!: Record<string, string | number | boolean | null>;

  @ApiPropertyOptional({ example: 'PHILIPS-HD9350-1.8L' })
  @IsOptional()
  @IsString()
  canonicalSku?: string;
}

export class MatchOfferDto {
  @ApiProperty({ type: CreateSellerOfferDto })
  @ValidateNested()
  @Type(() => CreateSellerOfferDto)
  offer!: CreateSellerOfferDto;

  @ApiProperty({ type: [MatchCandidateDto] })
  @ValidateNested({ each: true })
  @Type(() => MatchCandidateDto)
  @IsArray()
  candidates!: MatchCandidateDto[];

  @ApiPropertyOptional({ example: 85 })
  @IsOptional()
  @IsInt()
  @Min(0)
  autoMapThreshold?: number;

  @ApiPropertyOptional({ example: 60 })
  @IsOptional()
  @IsInt()
  @Min(0)
  reviewThreshold?: number;
}
