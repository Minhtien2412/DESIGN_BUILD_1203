import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsInt,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Max,
    Min,
    ValidateNested,
} from 'class-validator';

export class PricingOfferInputDto {
  @ApiProperty({ example: 'offer_001' })
  @IsString()
  offerId!: string;

  @ApiProperty({ example: 321 })
  @IsInt()
  sellerId!: number;

  @ApiProperty({ example: 790000 })
  @IsNumber()
  salePrice!: number;

  @ApiPropertyOptional({
    type: [String],
    example: ['OFFICIAL_STORE', 'FAST_SHIP'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  verifiedFlags?: string[];

  @ApiPropertyOptional({ example: 4 })
  @IsOptional()
  @IsNumber()
  shippingSlaHours?: number;

  @ApiPropertyOptional({ example: 24 })
  @IsOptional()
  @IsNumber()
  warrantyMonths?: number;

  @ApiPropertyOptional({ example: 'Official invoice + installation support' })
  @IsOptional()
  @IsString()
  premiumReason?: string;
}

export class CheckPriceAnomalyDto {
  @ApiProperty({ example: 'pm_thermo_001' })
  @IsString()
  productMasterId!: string;

  @ApiProperty({ example: 'small-home-appliances' })
  @IsString()
  category!: string;

  @ApiProperty({ type: [PricingOfferInputDto] })
  @ValidateNested({ each: true })
  @Type(() => PricingOfferInputDto)
  offers!: PricingOfferInputDto[];

  @ApiPropertyOptional({
    type: Object,
    example: { warningPct: 10, reviewPct: 15, highRiskPct: 20 },
  })
  @IsOptional()
  @IsObject()
  thresholdOverride?: {
    warningPct: number;
    reviewPct: number;
    highRiskPct: number;
  };

  @ApiPropertyOptional({ example: 'offer_003' })
  @IsOptional()
  @IsString()
  targetOfferId?: string;

  @ApiPropertyOptional({
    example: 0.12,
    description: 'Optional platform fee ratio for margin-aware analysis',
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(1)
  platformFeeRatio?: number;
}
