import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsNotEmpty,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
} from 'class-validator';

export class CreateProductMasterDto {
  @ApiProperty({ example: 'PM-THERMO-1.8L-220V' })
  @IsString()
  @MinLength(4)
  productMasterCode!: string;

  @ApiProperty({ example: 'Philips' })
  @IsString()
  @IsNotEmpty()
  brand!: string;

  @ApiProperty({ example: 'HD9350' })
  @IsString()
  @IsNotEmpty()
  model!: string;

  @ApiProperty({ example: 'small-home-appliances' })
  @IsString()
  category!: string;

  @ApiPropertyOptional({ example: 'electric-kettle' })
  @IsOptional()
  @IsString()
  subcategory?: string;

  @ApiProperty({ example: 'Ấm siêu tốc Philips 1.8L inox' })
  @IsString()
  title!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    type: Object,
    example: { color: 'silver', capacity_liter: 1.8, voltage: 220 },
  })
  @IsObject()
  variantAttributes!: Record<string, string | number | boolean | null>;

  @ApiProperty({
    type: Object,
    example: { power_w: 1800, body_material: 'stainless_steel' },
  })
  @IsObject()
  technicalSpecs!: Record<string, string | number | boolean | null>;

  @ApiPropertyOptional({ example: 'VN' })
  @IsOptional()
  @IsString()
  originCountry?: string;

  @ApiPropertyOptional({ example: '24 months official warranty' })
  @IsOptional()
  @IsString()
  warrantyPolicyDefault?: string;

  @ApiPropertyOptional({
    type: Object,
    example: { width_mm: 180, height_mm: 230, depth_mm: 180 },
  })
  @IsOptional()
  @IsObject()
  dimensions?: Record<string, string | number>;

  @ApiPropertyOptional({ example: 1.2 })
  @IsOptional()
  weight?: number;

  @ApiProperty({
    type: [String],
    example: ['https://cdn.example.com/master/kettle-front.jpg'],
  })
  @IsArray()
  @IsString({ each: true })
  images!: string[];
}
