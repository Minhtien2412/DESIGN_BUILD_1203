import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsPositive,
    IsString,
    Min,
} from 'class-validator';

export class CreateSellerOfferDto {
  @ApiProperty({ example: 321 })
  @IsInt()
  sellerId!: number;

  @ApiPropertyOptional({ example: 'pm_thermo_001' })
  @IsOptional()
  @IsString()
  productMasterId?: string;

  @ApiProperty({ example: 'SHOPA-KETTLE-001' })
  @IsString()
  @IsNotEmpty()
  sellerSku!: string;

  @ApiProperty({ example: 'Ấm siêu tốc Philips HD9350 chính hãng' })
  @IsString()
  sellerTitle!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  sellerDescription?: string;

  @ApiProperty({ example: 790000 })
  @IsNumber()
  @IsPositive()
  salePrice!: number;

  @ApiPropertyOptional({ example: 890000 })
  @IsOptional()
  @IsNumber()
  comparePrice?: number;

  @ApiProperty({ example: 18 })
  @IsInt()
  @Min(0)
  stockQuantity!: number;

  @ApiProperty({ example: 'NEW', enum: ['NEW', 'USED', 'REFURBISHED'] })
  @IsString()
  condition!: 'NEW' | 'USED' | 'REFURBISHED';

  @ApiPropertyOptional({ example: '24 tháng tại hãng' })
  @IsOptional()
  @IsString()
  warrantyPolicy?: string;

  @ApiPropertyOptional({ example: 'Giao trong 4 giờ nội thành' })
  @IsOptional()
  @IsString()
  shippingInfo?: string;

  @ApiProperty({
    type: [String],
    example: ['https://cdn.example.com/shop-a/kettle-1.jpg'],
  })
  @IsArray()
  @IsString({ each: true })
  sellerImages!: string[];

  @ApiPropertyOptional({ example: 82 })
  @IsOptional()
  @IsNumber()
  trustScore?: number;

  @ApiPropertyOptional({
    type: [String],
    example: ['OFFICIAL_STORE', 'FAST_SHIP'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  verifiedFlags?: string[];

  @ApiProperty({ example: 'Philips' })
  @IsString()
  declaredBrand!: string;

  @ApiProperty({ example: 'HD9350' })
  @IsString()
  declaredModel!: string;

  @ApiProperty({ example: 'small-home-appliances' })
  @IsString()
  declaredCategory!: string;

  @ApiProperty({
    type: Object,
    example: { color: 'silver', capacity_liter: 1.8, voltage: 220 },
  })
  @IsObject()
  variantAttributes!: Record<string, string | number | boolean | null>;

  @ApiProperty({
    type: Object,
    example: { power_w: 1800, body_material: 'stainless_steel' },
  })
  @IsObject()
  technicalSpecs!: Record<string, string | number | boolean | null>;

  @ApiPropertyOptional({ example: 'Official warranty + same-day delivery' })
  @IsOptional()
  @IsString()
  premiumReason?: string;

  @ApiPropertyOptional({
    example: 'Invoice + authorized distributor certificate',
  })
  @IsOptional()
  @IsString()
  evidenceNotes?: string;

  @ApiProperty({ example: true })
  @IsBoolean()
  liabilityAccepted!: boolean;

  @ApiProperty({ example: 'seller-liability-v1' })
  @IsString()
  liabilityPolicyVersion!: string;
}
