import {
    Body,
    Controller,
    Get,
    Param,
    Patch,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';

import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Permission, RequirePermission } from '../authorization';
import { PermissionGuard } from '../authorization/guards/permission.guard';
import { AcceptSellerPolicyDto } from './dto/accept-seller-policy.dto';
import { CheckPriceAnomalyDto } from './dto/check-price-anomaly.dto';
import { CreateProductMasterDto } from './dto/create-product-master.dto';
import { ModerateMessageDto } from './dto/moderate-message.dto';
import { ResolveReviewQueueItemDto } from './dto/resolve-review-queue-item.dto';
import { ReviewQueueQueryDto } from './dto/review-queue-query.dto';
import { ReviewSellerOfferDto } from './dto/review-seller-offer.dto';
import { MarketplaceGovernanceService } from './governance.service';
import { GovernancePersistenceService } from './services/governance-persistence.service';

@ApiTags('Marketplace Governance')
@Controller('marketplace-governance')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class MarketplaceGovernanceController {
  constructor(
    private readonly marketplaceGovernanceService: MarketplaceGovernanceService,
    private readonly governancePersistenceService: GovernancePersistenceService,
  ) {}

  @Post('product-masters/normalize')
  @ApiOperation({
    summary: 'Normalize Product Master payload before catalog creation',
  })
  normalizeProductMaster(@Body() dto: CreateProductMasterDto) {
    return this.marketplaceGovernanceService.normalizeProductMaster(dto);
  }

  @Post('offers/assess')
  @ApiOperation({
    summary:
      'Evaluate seller offer across matching, pricing, and compliance rules',
  })
  assessSellerOffer(@Body() dto: ReviewSellerOfferDto) {
    return this.marketplaceGovernanceService.assessSellerOffer(dto);
  }

  @Post('offers/price-anomaly')
  @ApiOperation({ summary: 'Run price anomaly analysis on comparable offers' })
  assessPriceAnomaly(@Body() dto: CheckPriceAnomalyDto) {
    return this.marketplaceGovernanceService.assessPriceAnomaly(dto);
  }

  @Post('messages/moderate')
  @ApiOperation({ summary: 'Moderate a chat message before send' })
  moderateMessage(@Body() dto: ModerateMessageDto) {
    return this.marketplaceGovernanceService.moderateMessage(dto);
  }

  @Get('automation-boundaries')
  @ApiOperation({ summary: 'Expose auto-vs-manual control boundaries' })
  getAutomationBoundaries() {
    return this.marketplaceGovernanceService.getAutomationBoundaries();
  }

  @Post('products/:productId/policy-acceptance')
  @ApiOperation({
    summary: 'Accept seller liability policy for a product before publication',
  })
  acceptSellerPolicy(
    @Param('productId') productId: string,
    @Body() dto: AcceptSellerPolicyDto,
    @CurrentUser('id') userId: number,
    @Req() req,
  ) {
    return this.governancePersistenceService.acceptSellerPolicyForProduct({
      productId: Number(productId),
      sellerId: userId,
      policyVersion: dto.policyVersion,
      deviceFingerprint: dto.deviceFingerprint,
      ipAddress: req.ip,
    });
  }

  @Get('review-queue')
  @UseGuards(PermissionGuard)
  @RequirePermission(Permission.PRODUCT_APPROVE, Permission.PRODUCT_REJECT)
  @ApiOperation({ summary: 'List marketplace governance review queue items' })
  listReviewQueue(@Query() query: ReviewQueueQueryDto) {
    return this.governancePersistenceService.listReviewQueue(query);
  }

  @Patch('review-queue/:itemId/resolve')
  @UseGuards(PermissionGuard)
  @RequirePermission(Permission.PRODUCT_APPROVE, Permission.PRODUCT_REJECT)
  @ApiOperation({ summary: 'Resolve a governance review queue item' })
  resolveReviewQueueItem(
    @Param('itemId') itemId: string,
    @Body() dto: ResolveReviewQueueItemDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.governancePersistenceService.resolveReviewQueueItem({
      itemId,
      resolvedById: userId,
      status: dto.status,
      note: dto.note,
    });
  }
}
