export enum ProductMasterStatus {
  DRAFT = 'DRAFT',
  ACTIVE = 'ACTIVE',
  REVIEW_REQUIRED = 'REVIEW_REQUIRED',
  ARCHIVED = 'ARCHIVED',
}

export enum SellerOfferStatus {
  DRAFT = 'DRAFT',
  PENDING_REVIEW = 'PENDING_REVIEW',
  ACTIVE = 'ACTIVE',
  HIDDEN = 'HIDDEN',
  REJECTED = 'REJECTED',
  SUSPENDED = 'SUSPENDED',
}

export enum MatchDisposition {
  AUTO_MAP = 'AUTO_MAP',
  REVIEW = 'REVIEW',
  CREATE_NEW_MASTER = 'CREATE_NEW_MASTER',
}

export enum PricingSeverity {
  OK = 'OK',
  WARNING = 'WARNING',
  REVIEW = 'REVIEW',
  HIGH_RISK = 'HIGH_RISK',
}

export enum ModerationDecision {
  ALLOW = 'allow',
  WARN = 'warn',
  REWRITE_SUGGEST = 'rewrite_suggest',
  BLOCK = 'block',
  MANUAL_REVIEW = 'manual_review',
}

export enum ReviewQueueType {
  PRODUCT_MATCH = 'PRODUCT_MATCH',
  PRICE_ANOMALY = 'PRICE_ANOMALY',
  SELLER_COMPLIANCE = 'SELLER_COMPLIANCE',
  MESSAGE_MODERATION = 'MESSAGE_MODERATION',
  AUTOMATION_ESCALATION = 'AUTOMATION_ESCALATION',
}

export type VariantAttributes = Record<
  string,
  string | number | boolean | null
>;
export type TechnicalSpecs = Record<string, string | number | boolean | null>;

export interface ProductMasterInput {
  productMasterCode: string;
  brand: string;
  model: string;
  category: string;
  subcategory?: string;
  title: string;
  description?: string;
  variantAttributes: VariantAttributes;
  technicalSpecs: TechnicalSpecs;
  originCountry?: string;
  warrantyPolicyDefault?: string;
  dimensions?: Record<string, number | string>;
  weight?: number;
  images: string[];
  status?: ProductMasterStatus;
}

export interface SellerOfferInput {
  sellerId: number;
  productMasterId?: string;
  sellerSku: string;
  sellerTitle: string;
  sellerDescription?: string;
  salePrice: number;
  comparePrice?: number;
  stockQuantity: number;
  condition: 'NEW' | 'USED' | 'REFURBISHED';
  warrantyPolicy?: string;
  shippingInfo?: string;
  sellerImages: string[];
  trustScore?: number;
  verifiedFlags?: string[];
  declaredBrand: string;
  declaredModel: string;
  declaredCategory: string;
  variantAttributes: VariantAttributes;
  technicalSpecs: TechnicalSpecs;
  premiumReason?: string;
  evidenceNotes?: string;
}

export interface MatchCandidate {
  productMasterId: string;
  brand: string;
  model: string;
  title: string;
  variantAttributes: VariantAttributes;
  technicalSpecs: TechnicalSpecs;
  canonicalSku?: string;
}

export interface MatchSignal {
  key: string;
  score: number;
  matched: boolean;
  detail: string;
}

export interface MatchResult {
  productMasterId?: string;
  confidenceScore: number;
  disposition: MatchDisposition;
  signals: MatchSignal[];
  rationale: string[];
}

export interface PricingOfferView {
  offerId: string;
  sellerId: number;
  salePrice: number;
  verifiedFlags?: string[];
  shippingSlaHours?: number;
  warrantyMonths?: number;
  premiumReason?: string;
}

export interface PricingThresholdConfig {
  warningPct: number;
  reviewPct: number;
  highRiskPct: number;
}

export interface PricingCheckResult {
  baselineOfferId?: string;
  baselinePrice: number;
  severity: PricingSeverity;
  deltaPct: number;
  threshold: PricingThresholdConfig;
  rationale: string[];
  recommendedActions: string[];
  manualReviewRequired: boolean;
}

export interface ModerationRuleHit {
  ruleCode: string;
  riskDelta: number;
  matchedText?: string;
  explanation: string;
}

export interface ModerationResult {
  decision: ModerationDecision;
  riskScore: number;
  ruleHits: ModerationRuleHit[];
  suggestedRewrite?: string;
  aiReviewRecommended: boolean;
  recommendedActions: string[];
}

export interface ComplianceEvaluationResult {
  accepted: boolean;
  missingFields: string[];
  liabilityAccepted: boolean;
  riskFlags: string[];
  violationScoreDelta: number;
  recommendedStatus: SellerOfferStatus;
}

export interface AdminReviewQueuePreview {
  queueType: ReviewQueueType;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  title: string;
  reason: string;
  recommendedAssigneeRole:
    | 'admin'
    | 'moderator'
    | 'pricing_analyst'
    | 'catalog_qc';
  payload: Record<string, unknown>;
}

export interface AutomationBoundary {
  automatedSteps: string[];
  manualReviewTriggers: string[];
  forbiddenActions: string[];
}
