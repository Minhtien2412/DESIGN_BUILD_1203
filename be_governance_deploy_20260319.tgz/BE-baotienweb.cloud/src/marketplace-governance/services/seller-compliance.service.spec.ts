import { SellerComplianceService } from './seller-compliance.service';

describe('SellerComplianceService', () => {
  const service = new SellerComplianceService();

  it('rejects publication when liability acceptance is missing', () => {
    const result = service.evaluateSubmission({
      sellerId: 11,
      sellerSku: 'product-11',
      sellerTitle: 'Máy khoan bê tông Bosch',
      salePrice: 2500000,
      stockQuantity: 4,
      condition: 'NEW',
      sellerImages: ['https://img.example/a.jpg', 'https://img.example/b.jpg'],
      declaredBrand: 'Bosch',
      declaredModel: 'GBH 2-26',
      declaredCategory: 'POWER_TOOLS',
      variantAttributes: {},
      technicalSpecs: {},
      liabilityAccepted: false,
      liabilityPolicyVersion: 'marketplace-seller-liability-v1',
    });

    expect(result.accepted).toBe(false);
    expect(result.riskFlags).toContain('liability_not_accepted');
    expect(result.recommendedStatus).toBe('REJECTED');
  });

  it('marks incomplete evidence as pending review instead of active', () => {
    const result = service.evaluateSubmission({
      sellerId: 22,
      sellerSku: 'product-22',
      sellerTitle: 'Máy phát điện mini',
      salePrice: 4500000,
      stockQuantity: 2,
      condition: 'USED',
      warrantyPolicy: undefined,
      sellerImages: ['https://img.example/one.jpg'],
      declaredBrand: 'Honda',
      declaredModel: 'EU10i',
      declaredCategory: 'OTHER',
      variantAttributes: {},
      technicalSpecs: {},
      liabilityAccepted: true,
      liabilityPolicyVersion: 'marketplace-seller-liability-v1',
      premiumReason: 'Full box',
    });

    expect(result.accepted).toBe(true);
    expect(result.riskFlags).toEqual(
      expect.arrayContaining([
        'insufficient_product_images',
        'used_item_without_warranty_context',
        'premium_claim_missing_evidence',
      ]),
    );
    expect(result.recommendedStatus).toBe('PENDING_REVIEW');
  });
});
