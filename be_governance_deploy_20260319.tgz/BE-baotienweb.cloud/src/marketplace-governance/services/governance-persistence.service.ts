import {
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { Prisma, ProductStatus, Role } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import {
    AdminReviewQueuePreview,
    ComplianceEvaluationResult,
    MatchCandidate,
    MatchDisposition,
    MatchResult,
    ModerationDecision,
    ModerationResult,
    PricingCheckResult,
    PricingOfferView,
    PricingSeverity,
    ReviewQueueType,
} from '../types/marketplace-governance.types';

const DEFAULT_POLICY_VERSION = 'marketplace-seller-liability-v1';

@Injectable()
export class GovernancePersistenceService {
  constructor(private readonly prisma: PrismaService) {}

  async listProductMasterCandidates(params: {
    category: string;
    brand?: string;
    model?: string;
  }): Promise<MatchCandidate[]> {
    const where: any = {
      status: 'ACTIVE',
      canonicalCategory: params.category,
    };

    const ors: any[] = [];
    if (params.brand) {
      ors.push({
        canonicalBrand: { equals: params.brand, mode: 'insensitive' },
      });
    }
    if (params.model) {
      ors.push({
        canonicalModel: { equals: params.model, mode: 'insensitive' },
      });
    }
    if (ors.length > 0) {
      where.OR = ors;
    }

    const masters = await this.prisma.productMasterCatalog.findMany({
      where,
      include: {
        variants: {
          orderBy: [{ isDefault: 'desc' }, { createdAt: 'asc' }],
          take: 1,
        },
      },
      orderBy: [{ lastMatchedAt: 'desc' }, { updatedAt: 'desc' }],
      take: 20,
    });

    return masters.map((master) => ({
      productMasterId: master.id,
      brand: master.canonicalBrand,
      model: master.canonicalModel,
      title: master.canonicalTitle,
      variantAttributes: this.asRecord(master.variantAttributes),
      technicalSpecs: this.asRecord(master.technicalSpecs),
      canonicalSku: master.variants[0]?.skuKey,
    }));
  }

  async listComparableOffers(params: {
    productId: number;
    category: string;
    brand?: string | null;
    model?: string | null;
  }): Promise<PricingOfferView[]> {
    const exactWhere: Prisma.ProductWhereInput = {
      id: { not: params.productId },
      status: ProductStatus.APPROVED,
      category: params.category as any,
      ...(params.brand
        ? {
            brand: { equals: params.brand, mode: 'insensitive' },
          }
        : {}),
      ...(params.model
        ? {
            model: { equals: params.model, mode: 'insensitive' },
          }
        : {}),
    };

    let products = await this.prisma.product.findMany({
      where: exactWhere,
      select: {
        id: true,
        createdBy: true,
        price: true,
        tags: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 25,
    });

    if (products.length === 0) {
      products = await this.prisma.product.findMany({
        where: {
          id: { not: params.productId },
          status: ProductStatus.APPROVED,
          category: params.category as any,
        },
        select: {
          id: true,
          createdBy: true,
          price: true,
          tags: true,
        },
        orderBy: { createdAt: 'desc' },
        take: 25,
      });
    }

    return products.map((product) => ({
      offerId: `product-${product.id}`,
      sellerId: product.createdBy,
      salePrice: Number(product.price),
      verifiedFlags: product.tags.includes('official_store')
        ? ['OFFICIAL_STORE']
        : [],
    }));
  }

  async acceptSellerPolicyForProduct(params: {
    productId: number;
    sellerId: number;
    policyVersion?: string;
    ipAddress?: string;
    deviceFingerprint?: string;
  }) {
    const product = await this.prisma.product.findUnique({
      where: { id: params.productId },
      select: { id: true, createdBy: true },
    });

    if (!product) {
      throw new NotFoundException(
        `Product with ID ${params.productId} not found`,
      );
    }

    if (product.createdBy !== params.sellerId) {
      throw new ForbiddenException(
        'You can only accept policy terms for your own product',
      );
    }

    const policyVersion = params.policyVersion ?? DEFAULT_POLICY_VERSION;

    return this.prisma.sellerLiabilityAcceptance.upsert({
      where: {
        productId_sellerId_policyVersion: {
          productId: params.productId,
          sellerId: params.sellerId,
          policyVersion,
        },
      },
      create: {
        productId: params.productId,
        sellerId: params.sellerId,
        policyVersion,
        ipAddress: params.ipAddress,
        deviceFingerprint: params.deviceFingerprint,
        payloadSnapshot: {
          accepted: true,
          policyVersion,
        },
      },
      update: {
        acceptedAt: new Date(),
        ipAddress: params.ipAddress,
        deviceFingerprint: params.deviceFingerprint,
        payloadSnapshot: {
          accepted: true,
          policyVersion,
        },
      },
    });
  }

  async getLatestPolicyAcceptance(productId: number, sellerId: number) {
    return this.prisma.sellerLiabilityAcceptance.findFirst({
      where: {
        productId,
        sellerId,
      },
      orderBy: { acceptedAt: 'desc' },
    });
  }

  async syncProductGovernanceAssessment(params: {
    productId: number;
    sellerId: number;
    topMatch?: MatchResult;
    pricing: PricingCheckResult;
    compliance: ComplianceEvaluationResult;
    reviewQueue: AdminReviewQueuePreview[];
  }) {
    const now = new Date();

    return this.prisma.$transaction(async (tx) => {
      const matchDecision = await tx.productMatchDecision.create({
        data: {
          productId: params.productId,
          productMasterId:
            params.topMatch?.productMasterId &&
            !params.topMatch.productMasterId.startsWith('product-')
              ? params.topMatch.productMasterId
              : undefined,
          decision: this.mapMatchDecision(params.topMatch?.disposition),
          confidenceScore: params.topMatch?.confidenceScore ?? 0,
          ruleSignals: this.toJsonValue(params.topMatch?.signals ?? []),
          rationale: params.topMatch?.rationale ?? [
            'No product-master candidate was available for automatic mapping.',
          ],
        },
      });

      const pricingAlert = await tx.pricingAlert.create({
        data: {
          productId: params.productId,
          productMasterId:
            params.topMatch?.productMasterId &&
            !params.topMatch.productMasterId.startsWith('product-')
              ? params.topMatch.productMasterId
              : undefined,
          severity: this.mapPriority(params.pricing.severity),
          deltaPct: params.pricing.deltaPct,
          baselinePrice: params.pricing.baselinePrice,
          rationale: params.pricing.rationale,
          requiresReview: params.pricing.manualReviewRequired,
        },
      });

      await tx.sellerViolation.updateMany({
        where: {
          productId: params.productId,
          status: { in: ['OPEN', 'IN_PROGRESS'] },
        },
        data: {
          status: 'RESOLVED',
          resolvedAt: now,
        },
      });

      const violations = await Promise.all(
        params.compliance.riskFlags.map((flag) =>
          tx.sellerViolation.create({
            data: {
              sellerId: params.sellerId,
              productId: params.productId,
              violationCode: flag,
              severity: this.mapViolationSeverity(flag),
              description: this.describeViolation(flag),
              points: this.calculateViolationPoints(flag),
              source: 'SELLER_COMPLIANCE',
            },
          }),
        ),
      );

      await tx.adminReviewQueueItem.updateMany({
        where: {
          productId: params.productId,
          status: { in: ['OPEN', 'IN_PROGRESS'] },
          source: {
            in: ['PRODUCT_MATCH', 'PRICE_ANOMALY', 'SELLER_COMPLIANCE'],
          },
        },
        data: {
          status: 'RESOLVED',
          resolvedAt: now,
        },
      });

      const reviewItems = await Promise.all(
        params.reviewQueue.map((item) =>
          tx.adminReviewQueueItem.create({
            data: {
              source: item.queueType,
              priority: this.mapPriority(item.priority),
              title: item.title,
              reason: item.reason,
              productId: params.productId,
              payload: this.toJsonValue(item.payload),
            },
          }),
        ),
      );

      if (
        params.topMatch?.disposition === MatchDisposition.AUTO_MAP &&
        params.topMatch.productMasterId &&
        !params.topMatch.productMasterId.startsWith('product-')
      ) {
        await tx.product.update({
          where: { id: params.productId },
          data: {
            productMasterId: params.topMatch.productMasterId,
          },
        });
      }

      return {
        matchDecision,
        pricingAlert,
        violations,
        reviewItems,
      };
    });
  }

  async ensureSellerEligibleForPublication(
    productId: number,
    sellerId: number,
  ) {
    const [seller, policyAcceptance, openViolations] = await Promise.all([
      this.prisma.user.findUnique({
        where: { id: sellerId },
        select: {
          id: true,
          role: true,
          isActive: true,
          bannedAt: true,
        },
      }),
      this.prisma.sellerLiabilityAcceptance.findFirst({
        where: { productId, sellerId },
        orderBy: { acceptedAt: 'desc' },
      }),
      this.prisma.sellerViolation.findMany({
        where: {
          sellerId,
          status: { in: ['OPEN', 'IN_PROGRESS'] },
          severity: { in: ['HIGH', 'CRITICAL'] },
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),
    ]);

    if (!seller) {
      throw new NotFoundException(`Seller with ID ${sellerId} not found`);
    }

    const blockingReasons: string[] = [];

    if (!seller.isActive || seller.bannedAt) {
      blockingReasons.push('seller_account_inactive');
    }

    if (!policyAcceptance) {
      blockingReasons.push('policy_acceptance_missing');
    }

    if (openViolations.length > 0) {
      blockingReasons.push(
        ...openViolations.map((violation) => violation.violationCode),
      );
    }

    const allowedRoles = new Set<Role>([
      Role.CLIENT,
      Role.SUPPLIER,
      Role.CONTRACTOR,
      Role.STAFF,
      Role.ADMIN,
      Role.SUPER_ADMIN,
    ]);
    if (!allowedRoles.has(seller.role)) {
      blockingReasons.push(`role_not_publishable:${seller.role}`);
    }

    return {
      eligible: blockingReasons.length === 0,
      blockingReasons,
      policyAcceptance,
      openViolations,
      seller,
    };
  }

  async resolveReviewQueueForProduct(params: {
    productId: number;
    resolvedById?: number;
    status: 'APPROVED' | 'REJECTED' | 'RESOLVED';
  }) {
    return this.prisma.adminReviewQueueItem.updateMany({
      where: {
        productId: params.productId,
        status: { in: ['OPEN', 'IN_PROGRESS'] },
      },
      data: {
        status: params.status,
        resolvedAt: new Date(),
        resolvedById: params.resolvedById,
      },
    });
  }

  async listReviewQueue(filters: {
    status?: 'OPEN' | 'IN_PROGRESS' | 'APPROVED' | 'REJECTED' | 'RESOLVED';
    source?:
      | 'PRODUCT_MATCH'
      | 'PRICE_ANOMALY'
      | 'SELLER_COMPLIANCE'
      | 'MESSAGE_MODERATION'
      | 'AUTOMATION_ESCALATION';
    assignedToId?: number;
  }) {
    return this.prisma.adminReviewQueueItem.findMany({
      where: {
        ...(filters.status ? { status: filters.status } : {}),
        ...(filters.source ? { source: filters.source } : {}),
        ...(filters.assignedToId ? { assignedToId: filters.assignedToId } : {}),
      },
      include: {
        product: {
          select: {
            id: true,
            name: true,
            createdBy: true,
            status: true,
          },
        },
        moderationLog: {
          select: {
            id: true,
            senderId: true,
            decision: true,
            riskScore: true,
            messageSnapshot: true,
          },
        },
        assignedTo: {
          select: { id: true, name: true, email: true },
        },
        resolvedBy: {
          select: { id: true, name: true, email: true },
        },
      },
      orderBy: [{ status: 'asc' }, { openedAt: 'desc' }],
    });
  }

  async resolveReviewQueueItem(params: {
    itemId: string;
    resolvedById: number;
    status: 'APPROVED' | 'REJECTED' | 'RESOLVED';
    note?: string;
  }) {
    const updated = await this.prisma.adminReviewQueueItem.update({
      where: { id: params.itemId },
      data: {
        status: params.status,
        resolvedAt: new Date(),
        resolvedById: params.resolvedById,
        payload: params.note
          ? this.toJsonValue({
              resolutionNote: params.note,
            })
          : undefined,
      },
      include: {
        product: {
          select: { id: true, name: true },
        },
        moderationLog: {
          select: { id: true, decision: true, messageSnapshot: true },
        },
        resolvedBy: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    if (updated.moderationLogId) {
      await this.prisma.messageModerationAction.create({
        data: {
          moderationLogId: updated.moderationLogId,
          action: this.mapModerationActionFromReviewStatus(params.status),
          performedById: params.resolvedById,
          reason: params.note,
        },
      });
    }

    return updated;
  }

  async createMessageModerationLog(params: {
    conversationId?: string;
    conversationMessageId?: string;
    senderId: number;
    message: string;
    moderation: ModerationResult;
  }) {
    const log = await this.prisma.messageModerationLog.create({
      data: {
        conversationId: params.conversationId,
        conversationMessageId: params.conversationMessageId,
        senderId: params.senderId,
        messageSnapshot: params.message,
        decision: this.mapModerationAction(params.moderation.decision),
        riskScore: params.moderation.riskScore,
        matchedRuleCodes: params.moderation.ruleHits.map((hit) => hit.ruleCode),
        ruleTrace: this.toJsonValue(params.moderation.ruleHits),
        suggestedRewrite: params.moderation.suggestedRewrite,
      },
    });

    await this.prisma.messageModerationAction.create({
      data: {
        moderationLogId: log.id,
        action: this.mapModerationAction(params.moderation.decision),
        reason: params.moderation.recommendedActions.join(' | '),
      },
    });

    return log;
  }

  async createModerationReviewQueueItems(params: {
    moderationLogId: string;
    reviewQueue: AdminReviewQueuePreview[];
  }) {
    return Promise.all(
      params.reviewQueue.map((item) =>
        this.prisma.adminReviewQueueItem.create({
          data: {
            source: item.queueType,
            priority: this.mapPriority(item.priority),
            title: item.title,
            reason: item.reason,
            moderationLogId: params.moderationLogId,
            payload: this.toJsonValue(item.payload),
          },
        }),
      ),
    );
  }

  async attachConversationMessageModerationLog(
    moderationLogId: string,
    conversationMessageId: string,
  ) {
    return this.prisma.messageModerationLog.update({
      where: { id: moderationLogId },
      data: {
        conversationMessageId,
      },
    });
  }

  private mapMatchDecision(disposition?: MatchDisposition) {
    switch (disposition) {
      case MatchDisposition.AUTO_MAP:
        return 'AUTO_MAP' as const;
      case MatchDisposition.CREATE_NEW_MASTER:
        return 'CREATE_NEW_MASTER' as const;
      case MatchDisposition.REVIEW:
      default:
        return 'MANUAL_REVIEW' as const;
    }
  }

  private mapPriority(
    value:
      | PricingSeverity
      | AdminReviewQueuePreview['priority']
      | ReviewQueueType
      | 'LOW'
      | 'MEDIUM'
      | 'HIGH'
      | 'CRITICAL',
  ) {
    if (value === PricingSeverity.HIGH_RISK || value === 'CRITICAL') {
      return 'CRITICAL' as const;
    }
    if (value === PricingSeverity.REVIEW || value === 'HIGH') {
      return 'HIGH' as const;
    }
    if (value === PricingSeverity.WARNING || value === 'MEDIUM') {
      return 'MEDIUM' as const;
    }
    return 'LOW' as const;
  }

  private mapViolationSeverity(flag: string) {
    if (flag === 'liability_not_accepted') {
      return 'CRITICAL' as const;
    }
    if (flag === 'low_trust_score') {
      return 'HIGH' as const;
    }
    return 'MEDIUM' as const;
  }

  private calculateViolationPoints(flag: string) {
    switch (flag) {
      case 'liability_not_accepted':
        return 70;
      case 'low_trust_score':
        return 25;
      case 'used_item_without_warranty_context':
        return 20;
      default:
        return 10;
    }
  }

  private describeViolation(flag: string) {
    switch (flag) {
      case 'liability_not_accepted':
        return 'Seller has not accepted the marketplace liability policy for this product.';
      case 'policy_version_missing':
        return 'Seller submission is missing a policy version snapshot.';
      case 'low_trust_score':
        return 'Seller trust score is below the publishable threshold.';
      case 'insufficient_product_images':
        return 'Product listing does not include enough supporting images.';
      case 'used_item_without_warranty_context':
        return 'Used or refurbished listing does not include warranty context.';
      case 'premium_claim_missing_evidence':
        return 'Premium pricing claim is missing supporting evidence.';
      default:
        return `Governance flagged seller compliance issue: ${flag}`;
    }
  }

  private mapModerationAction(decision: ModerationDecision) {
    switch (decision) {
      case ModerationDecision.ALLOW:
        return 'ALLOW' as const;
      case ModerationDecision.WARN:
        return 'WARN' as const;
      case ModerationDecision.REWRITE_SUGGEST:
        return 'REWRITE_SUGGEST' as const;
      case ModerationDecision.BLOCK:
        return 'BLOCK' as const;
      case ModerationDecision.MANUAL_REVIEW:
      default:
        return 'MANUAL_REVIEW' as const;
    }
  }

  private mapModerationActionFromReviewStatus(
    status: 'APPROVED' | 'REJECTED' | 'RESOLVED',
  ) {
    switch (status) {
      case 'APPROVED':
        return 'ALLOW' as const;
      case 'REJECTED':
        return 'BLOCK' as const;
      default:
        return 'MANUAL_REVIEW' as const;
    }
  }

  private asRecord(value: Prisma.JsonValue | null | undefined) {
    if (!value || Array.isArray(value) || typeof value !== 'object') {
      return {};
    }

    return value as Record<string, string | number | boolean | null>;
  }

  private toJsonValue(value: unknown): Prisma.InputJsonValue {
    return value as Prisma.InputJsonValue;
  }
}
