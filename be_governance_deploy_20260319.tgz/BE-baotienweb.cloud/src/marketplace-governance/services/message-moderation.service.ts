import { Injectable } from '@nestjs/common';

import {
    ModerationDecision,
    ModerationResult,
    ModerationRuleHit,
} from '../types/marketplace-governance.types';

interface ModerationRuleDefinition {
  ruleCode: string;
  riskDelta: number;
  pattern: RegExp;
  explanation: string;
}

@Injectable()
export class MessageModerationService {
  private readonly rules: ModerationRuleDefinition[] = [
    {
      ruleCode: 'OFF_PLATFORM_CONTACT',
      riskDelta: 65,
      pattern:
        /(zalo|telegram|whatsapp|viber|facebook|fb|sdt|s\.?đ\.?t|phone|hotline|liên hệ riêng|goi truc tiep|gọi trực tiếp|call me|call trực tiếp|@gmail|@yahoo|@outlook)/i,
      explanation:
        'Attempts to move the conversation off-platform or share direct contact info.',
    },
    {
      ruleCode: 'PHONE_NUMBER',
      riskDelta: 70,
      pattern: /((\+?84|0)\d[\d\s.-]{7,12})/i,
      explanation: 'Contains a phone number or phone-like contact token.',
    },
    {
      ruleCode: 'OFF_PLATFORM_PAYMENT',
      riskDelta: 60,
      pattern:
        /(chuyển khoản riêng|ck riêng|bank riêng|thanh toán ngoài app|không qua app|paypal friends|cod ngoài app|tra tien ben ngoai)/i,
      explanation: 'Suggests bypassing the platform payment flow.',
    },
    {
      ruleCode: 'EXTERNAL_LINK',
      riskDelta: 35,
      pattern: /(https?:\/\/|www\.|t\.me\/|zalo\.me\/|m\.me\/)/i,
      explanation:
        'Contains an external link that can route buyers off-platform.',
    },
  ];

  moderate(params: {
    message: string;
    recentMessages?: string[];
    senderIsTrusted?: boolean;
  }): ModerationResult {
    const ruleHits = this.rules
      .map((rule) => this.evaluateRule(rule, params.message))
      .filter((ruleHit): ruleHit is ModerationRuleHit => Boolean(ruleHit));

    let riskScore = ruleHits.reduce((sum, hit) => sum + hit.riskDelta, 0);

    if (
      params.recentMessages?.some((message) =>
        this.containsContactIntent(message),
      )
    ) {
      ruleHits.push({
        ruleCode: 'REPEATED_CONTACT_ESCALATION',
        riskDelta: 15,
        explanation:
          'Recent conversation history shows repeated contact extraction attempts.',
      });
      riskScore += 15;
    }

    if (params.senderIsTrusted) {
      riskScore = Math.max(0, riskScore - 10);
    }

    const decision = this.resolveDecision(riskScore, ruleHits);

    return {
      decision,
      riskScore,
      ruleHits,
      suggestedRewrite:
        decision === ModerationDecision.BLOCK ||
        decision === ModerationDecision.REWRITE_SUGGEST
          ? this.rewriteMessage(params.message)
          : undefined,
      aiReviewRecommended:
        decision === ModerationDecision.MANUAL_REVIEW ||
        ruleHits.filter((hit) => hit.riskDelta >= 60).length >= 2,
      recommendedActions: this.buildActions(decision),
    };
  }

  private evaluateRule(
    rule: ModerationRuleDefinition,
    message: string,
  ): ModerationRuleHit | undefined {
    const matchedText = message.match(rule.pattern)?.[0];
    if (!matchedText) {
      return undefined;
    }

    return {
      ruleCode: rule.ruleCode,
      riskDelta: rule.riskDelta,
      matchedText,
      explanation: rule.explanation,
    };
  }

  private resolveDecision(
    riskScore: number,
    ruleHits: ModerationRuleHit[],
  ): ModerationDecision {
    const hasSevereContactLeak = ruleHits.some(
      (hit) =>
        hit.ruleCode === 'PHONE_NUMBER' ||
        hit.ruleCode === 'OFF_PLATFORM_PAYMENT',
    );

    if (riskScore >= 90 || hasSevereContactLeak) {
      return ModerationDecision.BLOCK;
    }
    if (riskScore >= 60) {
      return ModerationDecision.MANUAL_REVIEW;
    }
    if (riskScore >= 35) {
      return ModerationDecision.REWRITE_SUGGEST;
    }
    if (riskScore >= 15) {
      return ModerationDecision.WARN;
    }
    return ModerationDecision.ALLOW;
  }

  private buildActions(decision: ModerationDecision): string[] {
    switch (decision) {
      case ModerationDecision.BLOCK:
        return [
          'Block send action in client',
          'Show policy reminder and safe in-app alternative',
          'Log incident for trust and safety review',
        ];
      case ModerationDecision.MANUAL_REVIEW:
        return [
          'Delay delivery until moderator review',
          'Capture conversation snippet in review queue',
        ];
      case ModerationDecision.REWRITE_SUGGEST:
        return [
          'Suggest an in-app safe rewrite before sending',
          'Warn the sender that external contact is not allowed',
        ];
      case ModerationDecision.WARN:
        return ['Allow send with a warning banner'];
      default:
        return ['Allow send immediately'];
    }
  }

  private rewriteMessage(message: string): string {
    return message
      .replace(/((\+?84|0)\d[\d\s.-]{7,12})/gi, '[redacted-phone]')
      .replace(/(https?:\/\/\S+|www\.\S+)/gi, '[redacted-link]')
      .replace(
        /(zalo|telegram|whatsapp|viber|facebook|fb)/gi,
        'chat trong ứng dụng',
      );
  }

  private containsContactIntent(message: string): boolean {
    return this.rules.some((rule) => rule.pattern.test(message));
  }
}
