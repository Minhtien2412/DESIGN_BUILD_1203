import { Injectable } from '@nestjs/common';

import {
    AdminReviewQueuePreview,
    ComplianceEvaluationResult,
    MatchDisposition,
    MatchResult,
    ModerationDecision,
    ModerationResult,
    PricingCheckResult,
    PricingSeverity,
    ReviewQueueType,
    SellerOfferInput,
} from '../types/marketplace-governance.types';

@Injectable()
export class ReviewQueueService {
  buildOfferReviewQueue(params: {
    offer: SellerOfferInput;
    matchResults: MatchResult[];
    pricing: PricingCheckResult;
    compliance: ComplianceEvaluationResult;
  }): AdminReviewQueuePreview[] {
    const previews: AdminReviewQueuePreview[] = [];
    const topMatch = params.matchResults[0];

    if (!topMatch) {
      previews.push({
        queueType: ReviewQueueType.PRODUCT_MATCH,
        priority: 'HIGH',
        title: `Review product mapping for ${params.offer.sellerSku}`,
        reason:
          'No sufficiently similar Product Master candidate was found for this offer.',
        recommendedAssigneeRole: 'catalog_qc',
        payload: {
          sellerSku: params.offer.sellerSku,
          candidatesReviewed: 0,
        },
      });
    }

    if (topMatch && topMatch.disposition !== MatchDisposition.AUTO_MAP) {
      previews.push({
        queueType: ReviewQueueType.PRODUCT_MATCH,
        priority:
          topMatch.disposition === MatchDisposition.CREATE_NEW_MASTER
            ? 'HIGH'
            : 'MEDIUM',
        title: `Review product mapping for ${params.offer.sellerSku}`,
        reason:
          topMatch.rationale[0] ??
          'Offer could not be safely auto-mapped to a Product Master.',
        recommendedAssigneeRole: 'catalog_qc',
        payload: {
          sellerSku: params.offer.sellerSku,
          topMatch,
          candidatesReviewed: params.matchResults.length,
        },
      });
    }

    if (params.pricing.manualReviewRequired) {
      previews.push({
        queueType: ReviewQueueType.PRICE_ANOMALY,
        priority: this.mapPricingPriority(params.pricing.severity),
        title: `Review pricing anomaly for ${params.offer.sellerSku}`,
        reason:
          params.pricing.rationale[1] ??
          'Offer price deviates materially from comparable offers.',
        recommendedAssigneeRole: 'pricing_analyst',
        payload: {
          sellerSku: params.offer.sellerSku,
          pricing: params.pricing,
        },
      });
    }

    if (
      !params.compliance.accepted ||
      params.compliance.recommendedStatus !== 'ACTIVE'
    ) {
      previews.push({
        queueType: ReviewQueueType.SELLER_COMPLIANCE,
        priority: params.compliance.liabilityAccepted ? 'MEDIUM' : 'CRITICAL',
        title: `Review seller compliance for ${params.offer.sellerSku}`,
        reason:
          params.compliance.riskFlags[0] ??
          'Offer failed one or more liability or compliance requirements.',
        recommendedAssigneeRole: 'moderator',
        payload: {
          sellerId: params.offer.sellerId,
          compliance: params.compliance,
        },
      });
    }

    return previews;
  }

  buildMessageModerationQueue(params: {
    senderId: number;
    message: string;
    moderation: ModerationResult;
  }): AdminReviewQueuePreview[] {
    if (
      params.moderation.decision !== ModerationDecision.BLOCK &&
      params.moderation.decision !== ModerationDecision.MANUAL_REVIEW
    ) {
      return [];
    }

    return [
      {
        queueType: ReviewQueueType.MESSAGE_MODERATION,
        priority:
          params.moderation.decision === ModerationDecision.BLOCK
            ? 'HIGH'
            : 'MEDIUM',
        title: `Review blocked message from user ${params.senderId}`,
        reason:
          params.moderation.ruleHits[0]?.explanation ??
          'Message hit a high-risk moderation rule.',
        recommendedAssigneeRole: 'moderator',
        payload: {
          senderId: params.senderId,
          message: params.message,
          moderation: params.moderation,
        },
      },
    ];
  }

  private mapPricingPriority(
    severity: PricingSeverity,
  ): AdminReviewQueuePreview['priority'] {
    switch (severity) {
      case PricingSeverity.HIGH_RISK:
        return 'CRITICAL';
      case PricingSeverity.REVIEW:
        return 'HIGH';
      case PricingSeverity.WARNING:
        return 'MEDIUM';
      default:
        return 'LOW';
    }
  }
}
