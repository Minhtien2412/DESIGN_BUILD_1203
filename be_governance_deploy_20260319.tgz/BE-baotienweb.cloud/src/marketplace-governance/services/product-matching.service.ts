import { Injectable } from '@nestjs/common';

import {
    MatchCandidate,
    MatchDisposition,
    MatchResult,
    MatchSignal,
    SellerOfferInput,
} from '../types/marketplace-governance.types';

@Injectable()
export class ProductMatchingService {
  evaluateOfferAgainstCandidates(
    offer: SellerOfferInput,
    candidates: MatchCandidate[],
    autoMapThreshold = 85,
    reviewThreshold = 60,
  ): MatchResult[] {
    return candidates
      .map((candidate) =>
        this.buildMatchResult(
          offer,
          candidate,
          autoMapThreshold,
          reviewThreshold,
        ),
      )
      .sort((a, b) => b.confidenceScore - a.confidenceScore);
  }

  private buildMatchResult(
    offer: SellerOfferInput,
    candidate: MatchCandidate,
    autoMapThreshold: number,
    reviewThreshold: number,
  ): MatchResult {
    const signals: MatchSignal[] = [];

    signals.push(
      this.compareExact('brand', offer.declaredBrand, candidate.brand, 25),
      this.compareExact('model', offer.declaredModel, candidate.model, 25),
      this.compareMaps(
        'variant_attributes',
        offer.variantAttributes,
        candidate.variantAttributes,
        20,
      ),
      this.compareMaps(
        'technical_specs',
        offer.technicalSpecs,
        candidate.technicalSpecs,
        15,
      ),
      this.compareTokenSimilarity(
        'title',
        offer.sellerTitle,
        candidate.title,
        10,
      ),
      this.compareSku(offer.sellerSku, candidate.canonicalSku, 5),
    );

    const confidenceScore = Math.round(
      signals.reduce((sum, signal) => sum + signal.score, 0),
    );

    let disposition = MatchDisposition.CREATE_NEW_MASTER;
    if (confidenceScore >= autoMapThreshold) {
      disposition = MatchDisposition.AUTO_MAP;
    } else if (confidenceScore >= reviewThreshold) {
      disposition = MatchDisposition.REVIEW;
    }

    const rationale = signals.map(
      (signal) => `${signal.key}: ${signal.detail} (+${signal.score})`,
    );

    return {
      productMasterId: candidate.productMasterId,
      confidenceScore,
      disposition,
      signals,
      rationale,
    };
  }

  private compareExact(
    key: string,
    left: string,
    right: string,
    fullScore: number,
  ): MatchSignal {
    const normalizedLeft = this.normalize(left);
    const normalizedRight = this.normalize(right);
    const matched = normalizedLeft === normalizedRight;

    return {
      key,
      matched,
      score: matched ? fullScore : 0,
      detail: matched
        ? `exact match (${normalizedLeft})`
        : `mismatch (${normalizedLeft} vs ${normalizedRight})`,
    };
  }

  private compareMaps(
    key: string,
    left: Record<string, unknown>,
    right: Record<string, unknown>,
    maxScore: number,
  ): MatchSignal {
    const keys = Array.from(
      new Set([...Object.keys(left), ...Object.keys(right)]),
    );
    if (keys.length === 0) {
      return {
        key,
        matched: false,
        score: 0,
        detail: 'no comparable attributes',
      };
    }

    const matches = keys.filter((entry) => {
      const a = left[entry];
      const b = right[entry];
      return (
        a !== undefined &&
        b !== undefined &&
        this.normalize(String(a)) === this.normalize(String(b))
      );
    }).length;

    const ratio = matches / keys.length;
    const score = Math.round(ratio * maxScore);

    return {
      key,
      matched: ratio >= 0.75,
      score,
      detail: `${matches}/${keys.length} attributes aligned`,
    };
  }

  private compareTokenSimilarity(
    key: string,
    left: string,
    right: string,
    maxScore: number,
  ): MatchSignal {
    const leftTokens = new Set(this.normalize(left).split(' ').filter(Boolean));
    const rightTokens = new Set(
      this.normalize(right).split(' ').filter(Boolean),
    );

    const intersection = Array.from(leftTokens).filter((token) =>
      rightTokens.has(token),
    ).length;
    const union = new Set([...leftTokens, ...rightTokens]).size || 1;
    const ratio = intersection / union;
    const score = Math.round(ratio * maxScore);

    return {
      key,
      matched: ratio >= 0.5,
      score,
      detail: `token similarity ${(ratio * 100).toFixed(0)}%`,
    };
  }

  private compareSku(
    sellerSku: string,
    canonicalSku: string | undefined,
    maxScore: number,
  ): MatchSignal {
    if (!canonicalSku) {
      return {
        key: 'sku_mapping',
        matched: false,
        score: 0,
        detail: 'candidate has no canonical sku',
      };
    }

    const matched = this.normalize(sellerSku).includes(
      this.normalize(canonicalSku),
    );
    return {
      key: 'sku_mapping',
      matched,
      score: matched ? maxScore : 0,
      detail: matched
        ? 'seller sku aligns with canonical sku'
        : 'sku mapping not found',
    };
  }

  private normalize(value: string): string {
    return value
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }
}
