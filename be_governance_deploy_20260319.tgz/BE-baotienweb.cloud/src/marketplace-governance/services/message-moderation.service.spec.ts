import { MessageModerationService } from './message-moderation.service';

describe('MessageModerationService', () => {
  const service = new MessageModerationService();

  it('blocks explicit off-platform contact leakage', () => {
    const result = service.moderate({
      message: 'Liên hệ riêng qua Zalo 0901234567 để chuyển khoản nhanh nhé',
    });

    expect(result.decision).toBe('block');
    expect(result.ruleHits.map((hit) => hit.ruleCode)).toEqual(
      expect.arrayContaining(['OFF_PLATFORM_CONTACT', 'PHONE_NUMBER']),
    );
    expect(result.suggestedRewrite).toContain('[redacted-phone]');
  });

  it('suggests a rewrite for lower-risk external link sharing', () => {
    const result = service.moderate({
      message: 'Xem thêm ảnh ở https://example.com/offer nhé',
    });

    expect(result.decision).toBe('rewrite_suggest');
    expect(result.aiReviewRecommended).toBe(false);
    expect(result.recommendedActions).toContain(
      'Suggest an in-app safe rewrite before sending',
    );
  });
});
