import { ProductMatchingService } from './product-matching.service';

describe('ProductMatchingService', () => {
  const service = new ProductMatchingService();

  it('auto-maps a strong exact match', () => {
    const [result] = service.evaluateOfferAgainstCandidates(
      {
        sellerId: 10,
        sellerSku: 'IPHONE-15-PM-256',
        sellerTitle: 'Apple iPhone 15 Pro Max 256GB Titan Tự Nhiên',
        salePrice: 32990000,
        stockQuantity: 5,
        condition: 'NEW',
        sellerImages: ['https://img.example/iphone-front.jpg'],
        declaredBrand: 'Apple',
        declaredModel: 'iPhone 15 Pro Max',
        declaredCategory: 'ELECTRONICS',
        variantAttributes: { storage: '256GB', color: 'Titan Tự Nhiên' },
        technicalSpecs: { chip: 'A17 Pro', display: '6.7' },
      },
      [
        {
          productMasterId: 'pm-apple-iphone-15pm-256',
          brand: 'Apple',
          model: 'iPhone 15 Pro Max',
          title: 'Apple iPhone 15 Pro Max 256GB Titan Tự Nhiên',
          canonicalSku: 'IPHONE-15-PM-256',
          variantAttributes: { storage: '256GB', color: 'Titan Tự Nhiên' },
          technicalSpecs: { chip: 'A17 Pro', display: '6.7' },
        },
      ],
    );

    expect(result.disposition).toBe('AUTO_MAP');
    expect(result.confidenceScore).toBeGreaterThanOrEqual(85);
    expect(result.productMasterId).toBe('pm-apple-iphone-15pm-256');
  });

  it('requests manual review when only a partial match is found', () => {
    const [result] = service.evaluateOfferAgainstCandidates(
      {
        sellerId: 20,
        sellerSku: 'SAMSUNG-S24-ULTRA-512',
        sellerTitle: 'Samsung S24 Ultra 512GB màu đen',
        salePrice: 27990000,
        stockQuantity: 3,
        condition: 'NEW',
        sellerImages: ['https://img.example/s24.jpg'],
        declaredBrand: 'Samsung',
        declaredModel: 'Galaxy S24 Ultra',
        declaredCategory: 'ELECTRONICS',
        variantAttributes: { storage: '512GB' },
        technicalSpecs: { display: '6.8', ram: '12GB' },
      },
      [
        {
          productMasterId: 'pm-samsung-s24u-256',
          brand: 'Samsung',
          model: 'Galaxy S24 Ultra',
          title: 'Samsung Galaxy S24 Ultra 256GB',
          canonicalSku: 'S24U-256',
          variantAttributes: { storage: '256GB' },
          technicalSpecs: { display: '6.8', ram: '12GB' },
        },
      ],
    );

    expect(result.disposition).toBe('REVIEW');
    expect(result.confidenceScore).toBeGreaterThanOrEqual(60);
    expect(result.confidenceScore).toBeLessThan(85);
  });
});
