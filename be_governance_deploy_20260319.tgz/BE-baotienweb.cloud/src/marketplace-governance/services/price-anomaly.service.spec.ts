import { PriceAnomalyService } from './price-anomaly.service';

describe('PriceAnomalyService', () => {
  const service = new PriceAnomalyService();

  it('flags high-risk premium pricing that materially exceeds the baseline', () => {
    const result = service.analyze({
      productMasterId: 'pm-001',
      category: 'ELECTRONICS',
      targetOfferId: 'offer-premium',
      offers: [
        {
          offerId: 'offer-baseline',
          sellerId: 1,
          salePrice: 1000000,
        },
        {
          offerId: 'offer-premium',
          sellerId: 2,
          salePrice: 1350000,
        },
      ],
    });

    expect(result.baselineOfferId).toBe('offer-baseline');
    expect(result.severity).toBe('HIGH_RISK');
    expect(result.manualReviewRequired).toBe(true);
  });

  it('routes deep underpricing to manual review', () => {
    const result = service.analyze({
      productMasterId: 'pm-002',
      category: 'ELECTRONICS',
      targetOfferId: 'offer-low',
      offers: [
        {
          offerId: 'offer-baseline',
          sellerId: 1,
          salePrice: 1000000,
        },
        {
          offerId: 'offer-low',
          sellerId: 3,
          salePrice: 700000,
        },
      ],
    });

    expect(result.severity).toBe('REVIEW');
    expect(result.deltaPct).toBeLessThan(0);
    expect(result.recommendedActions).toContain('Route to manual review queue');
  });
});
