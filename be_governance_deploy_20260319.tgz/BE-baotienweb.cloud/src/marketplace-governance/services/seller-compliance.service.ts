import { Injectable } from '@nestjs/common';

import {
    ComplianceEvaluationResult,
    SellerOfferInput,
    SellerOfferStatus,
} from '../types/marketplace-governance.types';

@Injectable()
export class SellerComplianceService {
  evaluateSubmission(
    offer: SellerOfferInput & {
      liabilityAccepted?: boolean;
      liabilityPolicyVersion?: string;
    },
  ): ComplianceEvaluationResult {
    const missingFields = this.collectMissingFields(offer);
    const riskFlags: string[] = [];
    let violationScoreDelta = 0;

    if (!offer.liabilityAccepted) {
      riskFlags.push('liability_not_accepted');
      violationScoreDelta += 70;
    }

    if (!offer.liabilityPolicyVersion) {
      riskFlags.push('policy_version_missing');
      violationScoreDelta += 15;
    }

    if ((offer.trustScore ?? 100) < 40) {
      riskFlags.push('low_trust_score');
      violationScoreDelta += 20;
    }

    if (offer.sellerImages.length < 2) {
      riskFlags.push('insufficient_product_images');
      violationScoreDelta += 15;
    }

    if (offer.condition !== 'NEW' && !offer.warrantyPolicy) {
      riskFlags.push('used_item_without_warranty_context');
      violationScoreDelta += 20;
    }

    if (offer.premiumReason && !offer.evidenceNotes) {
      riskFlags.push('premium_claim_missing_evidence');
      violationScoreDelta += 15;
    }

    const accepted =
      missingFields.length === 0 && Boolean(offer.liabilityAccepted);
    const recommendedStatus = this.resolveRecommendedStatus(
      accepted,
      violationScoreDelta,
      riskFlags.length,
    );

    return {
      accepted,
      missingFields,
      liabilityAccepted: Boolean(offer.liabilityAccepted),
      riskFlags,
      violationScoreDelta,
      recommendedStatus,
    };
  }

  private collectMissingFields(
    offer: SellerOfferInput & {
      liabilityAccepted?: boolean;
      liabilityPolicyVersion?: string;
    },
  ): string[] {
    const checks: Array<[string, unknown]> = [
      ['sellerSku', offer.sellerSku],
      ['sellerTitle', offer.sellerTitle],
      ['declaredBrand', offer.declaredBrand],
      ['declaredModel', offer.declaredModel],
      ['declaredCategory', offer.declaredCategory],
      ['salePrice', offer.salePrice],
      ['stockQuantity', offer.stockQuantity],
      [
        'sellerImages',
        offer.sellerImages.length > 0 ? offer.sellerImages : undefined,
      ],
      ['liabilityPolicyVersion', offer.liabilityPolicyVersion],
    ];

    return checks
      .filter(
        ([, value]) => value === undefined || value === null || value === '',
      )
      .map(([field]) => field);
  }

  private resolveRecommendedStatus(
    accepted: boolean,
    violationScoreDelta: number,
    riskFlagCount: number,
  ): SellerOfferStatus {
    if (!accepted) {
      return SellerOfferStatus.REJECTED;
    }
    if (violationScoreDelta >= 70) {
      return SellerOfferStatus.SUSPENDED;
    }
    if (violationScoreDelta >= 25 || riskFlagCount > 0) {
      return SellerOfferStatus.PENDING_REVIEW;
    }
    return SellerOfferStatus.ACTIVE;
  }
}
