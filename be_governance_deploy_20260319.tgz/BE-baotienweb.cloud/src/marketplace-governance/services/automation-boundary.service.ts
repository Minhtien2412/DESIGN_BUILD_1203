import { Injectable } from '@nestjs/common';

import {
    AutomationBoundary,
    ModerationDecision,
} from '../types/marketplace-governance.types';

@Injectable()
export class AutomationBoundaryService {
  forOfferAssessment(hasManualReviews: boolean): AutomationBoundary {
    return {
      automatedSteps: [
        'Normalize offer payload and validate required fields',
        'Score Product Master match candidates',
        'Run price anomaly thresholds with premium allowance',
        'Create audit trail and structured review previews',
      ],
      manualReviewTriggers: hasManualReviews
        ? [
            'Top match confidence below auto-map threshold',
            'Price severity warning or higher',
            'Compliance risk flags present',
          ]
        : ['No manual review triggered for this assessment'],
      forbiddenActions: [
        'Auto-approving high-risk price anomalies',
        'Auto-publishing offers without liability acceptance',
        'Auto-creating new Product Masters from low-confidence matches',
      ],
    };
  }

  forMessageModeration(decision: ModerationDecision): AutomationBoundary {
    const escalations =
      decision === ModerationDecision.MANUAL_REVIEW ||
      decision === ModerationDecision.BLOCK
        ? [
            'Potential contact leakage or off-platform payment detected',
            'Moderator must review before the sender can appeal',
          ]
        : ['No manual escalation required'];

    return {
      automatedSteps: [
        'Scan message against policy regex and heuristics',
        'Calculate risk score with trust adjustment',
        'Return client action: allow, warn, rewrite, or block',
      ],
      manualReviewTriggers: escalations,
      forbiddenActions: [
        'Auto-sharing personal phone numbers or external links',
        'Letting automation override a block without human review',
      ],
    };
  }
}
