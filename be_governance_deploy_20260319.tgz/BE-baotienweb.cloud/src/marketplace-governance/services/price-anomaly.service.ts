import { Injectable } from '@nestjs/common';

import {
    PricingCheckResult,
    PricingOfferView,
    PricingSeverity,
    PricingThresholdConfig,
} from '../types/marketplace-governance.types';

interface AnalyzePricingInput {
  productMasterId: string;
  category: string;
  offers: PricingOfferView[];
  targetOfferId?: string;
  thresholdOverride?: Partial<PricingThresholdConfig>;
  platformFeeRatio?: number;
}

@Injectable()
export class PriceAnomalyService {
  private readonly defaultThreshold: PricingThresholdConfig = {
    warningPct: 10,
    reviewPct: 15,
    highRiskPct: 25,
  };

  analyze(input: AnalyzePricingInput): PricingCheckResult {
    const threshold = {
      ...this.defaultThreshold,
      ...input.thresholdOverride,
    };

    if (input.offers.length === 0) {
      return {
        baselinePrice: 0,
        severity: PricingSeverity.REVIEW,
        deltaPct: 0,
        threshold,
        rationale: [
          `No comparable market offers available for ${input.productMasterId}.`,
          'Fallback to manual analyst review because the baseline cannot be established.',
        ],
        recommendedActions: [
          'Collect more comparable offers before publishing',
        ],
        manualReviewRequired: true,
      };
    }

    const rankedOffers = input.offers
      .map((offer) => ({
        ...offer,
        adjustedPrice: this.applyPlatformFee(
          offer.salePrice,
          input.platformFeeRatio,
        ),
        premiumAllowancePct: this.getPremiumAllowancePct(offer),
        trustRank: this.getTrustRank(offer),
      }))
      .sort(
        (left, right) =>
          left.adjustedPrice - right.adjustedPrice ||
          right.trustRank - left.trustRank,
      );

    const target =
      rankedOffers.find((offer) => offer.offerId === input.targetOfferId) ??
      rankedOffers[0];
    const baselineCandidates = input.targetOfferId
      ? rankedOffers.filter((offer) => offer.offerId !== input.targetOfferId)
      : rankedOffers;
    const baseline = baselineCandidates[0] ?? target;

    const rawDeltaPct =
      baseline.adjustedPrice === 0
        ? 0
        : ((target.adjustedPrice - baseline.adjustedPrice) /
            baseline.adjustedPrice) *
          100;
    const toleratedDeltaPct =
      rawDeltaPct > 0 ? rawDeltaPct - target.premiumAllowancePct : rawDeltaPct;
    const severity = this.resolveSeverity(
      Math.abs(toleratedDeltaPct),
      threshold,
    );
    const belowMarketTooFar = rawDeltaPct < threshold.reviewPct * -1;
    const finalSeverity = belowMarketTooFar ? PricingSeverity.REVIEW : severity;

    const rationale = [
      `Baseline offer ${baseline.offerId} establishes a reference price of ${Math.round(baseline.adjustedPrice)}.`,
      `Target offer ${target.offerId} is ${rawDeltaPct.toFixed(2)}% ${rawDeltaPct >= 0 ? 'above' : 'below'} the baseline.`,
    ];

    if (target.premiumAllowancePct > 0) {
      rationale.push(
        `Premium justification reduced the review delta by ${target.premiumAllowancePct.toFixed(2)} percentage points.`,
      );
    }

    if (belowMarketTooFar) {
      rationale.push(
        'Offer is materially cheaper than the market baseline, which may indicate counterfeit, stale stock, or data issues.',
      );
    }

    const recommendedActions = this.buildRecommendedActions(
      finalSeverity,
      rawDeltaPct,
    );

    return {
      baselineOfferId: baseline.offerId,
      baselinePrice: Math.round(baseline.adjustedPrice),
      severity: finalSeverity,
      deltaPct: Number(toleratedDeltaPct.toFixed(2)),
      threshold,
      rationale,
      recommendedActions,
      manualReviewRequired: finalSeverity !== PricingSeverity.OK,
    };
  }

  private resolveSeverity(
    deltaPct: number,
    threshold: PricingThresholdConfig,
  ): PricingSeverity {
    if (deltaPct >= threshold.highRiskPct) {
      return PricingSeverity.HIGH_RISK;
    }
    if (deltaPct >= threshold.reviewPct) {
      return PricingSeverity.REVIEW;
    }
    if (deltaPct >= threshold.warningPct) {
      return PricingSeverity.WARNING;
    }
    return PricingSeverity.OK;
  }

  private buildRecommendedActions(
    severity: PricingSeverity,
    rawDeltaPct: number,
  ): string[] {
    if (severity === PricingSeverity.OK) {
      return ['Allow automated publication'];
    }

    if (severity === PricingSeverity.WARNING) {
      return [
        'Display premium justification to buyers',
        'Monitor conversion and complaint rate after publication',
      ];
    }

    if (severity === PricingSeverity.HIGH_RISK) {
      return rawDeltaPct >= 0
        ? [
            'Block auto publication until pricing analyst approval',
            'Request invoice, warranty, and premium proof from seller',
          ]
        : [
            'Hold offer for fraud or counterfeit screening',
            'Verify stock age, origin, and seller legitimacy',
          ];
    }

    return rawDeltaPct >= 0
      ? [
          'Route to manual review queue',
          'Require seller to justify price premium with evidence',
        ]
      : [
          'Route to manual review queue',
          'Check if underpricing is caused by bad data or risky inventory',
        ];
  }

  private getPremiumAllowancePct(offer: PricingOfferView): number {
    let allowance = 0;

    if (offer.premiumReason) {
      allowance += 5;
    }
    if (offer.verifiedFlags?.includes('OFFICIAL_STORE')) {
      allowance += 4;
    }
    if (offer.verifiedFlags?.includes('FAST_SHIP')) {
      allowance += 2;
    }
    if ((offer.warrantyMonths ?? 0) >= 12) {
      allowance += 2;
    }
    if ((offer.shippingSlaHours ?? Number.MAX_SAFE_INTEGER) <= 4) {
      allowance += 1.5;
    }

    return allowance;
  }

  private getTrustRank(offer: PricingOfferView): number {
    const verifiedBoost = offer.verifiedFlags?.length ?? 0;
    const warrantyBoost = Math.min((offer.warrantyMonths ?? 0) / 12, 2);
    const shippingBoost =
      (offer.shippingSlaHours ?? Number.MAX_SAFE_INTEGER) <= 4 ? 1 : 0;
    return verifiedBoost + warrantyBoost + shippingBoost;
  }

  private applyPlatformFee(price: number, platformFeeRatio = 0): number {
    return price * (1 + platformFeeRatio);
  }
}
