import {
    ForbiddenException,
    UnprocessableEntityException,
} from '@nestjs/common';
import { MessagesService as ConversationMessagesService } from '../conversation-messages/messages.service';
import { ProductsService } from '../products/products.service';
import { MarketplaceGovernanceService } from './governance.service';
import { GovernancePersistenceService } from './services/governance-persistence.service';

describe('Marketplace governance integrations', () => {
  describe('ProductsService integration', () => {
    const createdAt = new Date('2026-03-18T10:00:00Z');

    function createProductPrismaMock() {
      const prisma: Record<string, any> = {
        $transaction: jest.fn(async (cb: (tx: any) => Promise<any>) =>
          cb(prisma),
        ),
        product: {
          create: jest.fn(),
          update: jest.fn(),
          findUnique: jest.fn(),
          count: jest.fn(),
          findMany: jest.fn(),
          delete: jest.fn(),
        },
        productImage: {
          deleteMany: jest.fn().mockResolvedValue({ count: 0 }),
          createMany: jest.fn().mockResolvedValue({ count: 2 }),
        },
        priceHistory: {
          create: jest.fn(),
          findMany: jest.fn().mockResolvedValue([]),
        },
      };

      return prisma;
    }

    function createGovernanceMocks() {
      return {
        governanceService: {
          assessSellerOffer: jest.fn(),
        } as unknown as MarketplaceGovernanceService,
        persistenceService: {
          getLatestPolicyAcceptance: jest.fn(),
          listProductMasterCandidates: jest.fn(),
          listComparableOffers: jest.fn(),
          syncProductGovernanceAssessment: jest.fn(),
          ensureSellerEligibleForPublication: jest.fn(),
          resolveReviewQueueForProduct: jest.fn(),
        } as unknown as GovernancePersistenceService,
      };
    }

    it('persists rich product metadata and governance on create', async () => {
      const prisma = createProductPrismaMock();
      const { governanceService, persistenceService } = createGovernanceMocks();
      const service = new ProductsService(
        prisma as any,
        governanceService,
        persistenceService,
      );

      prisma.product.create.mockResolvedValue({
        id: 501,
        createdBy: 99,
      });
      prisma.product.findUnique.mockResolvedValue({
        id: 501,
        createdBy: 99,
        productMasterId: null,
        name: 'Máy khoan Bosch GBH 2-26',
        description: 'Máy khoan bê tông công suất cao',
        category: 'OTHER',
        price: 2500000,
        stock: 4,
        brand: 'Bosch',
        model: 'GBH 2-26',
        unit: 'cái',
        tags: ['official_store'],
        status: 'PENDING',
        images: [
          { id: 1, url: 'https://img.example/a.jpg', isPrimary: true },
          { id: 2, url: 'https://img.example/b.jpg', isPrimary: false },
        ],
        users_products_createdByTousers: {
          id: 99,
          name: 'Seller A',
          email: 'seller@example.com',
        },
        createdAt,
        updatedAt: createdAt,
      });

      (
        persistenceService.getLatestPolicyAcceptance as jest.Mock
      ).mockResolvedValue({
        id: 'accept-1',
        policyVersion: 'marketplace-seller-liability-v1',
      });
      (
        persistenceService.listProductMasterCandidates as jest.Mock
      ).mockResolvedValue([]);
      (persistenceService.listComparableOffers as jest.Mock).mockResolvedValue(
        [],
      );
      (governanceService.assessSellerOffer as jest.Mock).mockResolvedValue({
        topMatch: undefined,
        allMatches: [],
        pricing: {
          baselinePrice: 0,
          severity: 'REVIEW',
          deltaPct: 0,
          threshold: { warningPct: 10, reviewPct: 15, highRiskPct: 25 },
          rationale: ['No comparable offers'],
          recommendedActions: ['Collect more comparables'],
          manualReviewRequired: true,
        },
        compliance: {
          accepted: true,
          missingFields: [],
          liabilityAccepted: true,
          riskFlags: [],
          violationScoreDelta: 0,
          recommendedStatus: 'ACTIVE',
        },
        reviewQueue: [],
        automationBoundary: {
          automatedSteps: ['persist'],
          manualReviewTriggers: [],
          forbiddenActions: [],
        },
        autoPublishEligible: false,
      });
      (
        persistenceService.syncProductGovernanceAssessment as jest.Mock
      ).mockResolvedValue({
        matchDecision: { id: 'match-1' },
        pricingAlert: { id: 'price-1' },
        violations: [],
        reviewItems: [],
      });

      const result = await service.create(
        {
          name: 'Máy khoan Bosch GBH 2-26',
          description: 'Máy khoan bê tông công suất cao',
          price: 2500000,
          category: 'OTHER' as any,
          brand: 'Bosch',
          model: 'GBH 2-26',
          stock: 4,
          unit: 'cái',
          tags: ['official_store'],
          images: ['https://img.example/a.jpg', 'https://img.example/b.jpg'],
        },
        99,
      );

      expect(prisma.product.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            brand: 'Bosch',
            model: 'GBH 2-26',
            unit: 'cái',
            tags: ['official_store'],
          }),
        }),
      );
      expect(prisma.productImage.createMany).toHaveBeenCalledTimes(1);
      expect(result.governance).toBeDefined();
      expect(result.seller.email).toBe('seller@example.com');
    });

    it('blocks publish when seller is not eligible', async () => {
      const prisma = createProductPrismaMock();
      const { governanceService, persistenceService } = createGovernanceMocks();
      const service = new ProductsService(
        prisma as any,
        governanceService,
        persistenceService,
      );

      prisma.product.findUnique.mockResolvedValue({
        id: 777,
        createdBy: 45,
        productMasterId: null,
        name: 'Máy cắt cũ',
        description: 'Thiết bị đã qua sử dụng',
        category: 'OTHER',
        price: 1500000,
        stock: 1,
        brand: 'Makita',
        model: 'N5900B',
        unit: 'cái',
        tags: ['used'],
        status: 'PENDING',
        images: [
          { id: 1, url: 'https://img.example/used.jpg', isPrimary: true },
        ],
        users_products_createdByTousers: {
          id: 45,
          name: 'Seller B',
          email: 'seller-b@example.com',
        },
      });

      (
        persistenceService.getLatestPolicyAcceptance as jest.Mock
      ).mockResolvedValue(null);
      (
        persistenceService.listProductMasterCandidates as jest.Mock
      ).mockResolvedValue([]);
      (persistenceService.listComparableOffers as jest.Mock).mockResolvedValue(
        [],
      );
      (governanceService.assessSellerOffer as jest.Mock).mockResolvedValue({
        topMatch: undefined,
        allMatches: [],
        pricing: {
          baselinePrice: 0,
          severity: 'REVIEW',
          deltaPct: 0,
          threshold: { warningPct: 10, reviewPct: 15, highRiskPct: 25 },
          rationale: ['No comparable offers'],
          recommendedActions: ['Collect more comparables'],
          manualReviewRequired: true,
        },
        compliance: {
          accepted: false,
          missingFields: [],
          liabilityAccepted: false,
          riskFlags: ['liability_not_accepted'],
          violationScoreDelta: 70,
          recommendedStatus: 'REJECTED',
        },
        reviewQueue: [],
        automationBoundary: {
          automatedSteps: [],
          manualReviewTriggers: ['seller-compliance'],
          forbiddenActions: ['publish'],
        },
        autoPublishEligible: false,
      });
      (
        persistenceService.syncProductGovernanceAssessment as jest.Mock
      ).mockResolvedValue({
        matchDecision: { id: 'match-2' },
        pricingAlert: { id: 'price-2' },
        violations: [],
        reviewItems: [],
      });
      (
        persistenceService.ensureSellerEligibleForPublication as jest.Mock
      ).mockResolvedValue({
        eligible: false,
        blockingReasons: ['policy_acceptance_missing'],
        policyAcceptance: null,
        openViolations: [],
        seller: { id: 45, role: 'SUPPLIER', isActive: true },
      });

      await expect(
        service.updateStatus(777, 'APPROVED', undefined, { id: 1 }),
      ).rejects.toThrow(ForbiddenException);
      expect(prisma.product.update).not.toHaveBeenCalled();
    });
  });

  describe('Conversation messages integration', () => {
    function createConversationPrismaMock() {
      const prisma: Record<string, any> = {
        $transaction: jest.fn(async (cb: (tx: any) => Promise<any>) =>
          cb(prisma),
        ),
        conversationParticipant: {
          findUnique: jest.fn(),
          updateMany: jest.fn().mockResolvedValue({ count: 1 }),
        },
        conversationMessage: {
          findUnique: jest.fn(),
          findMany: jest.fn(),
          findFirst: jest.fn(),
          create: jest.fn(),
        },
        conversation: {
          update: jest.fn().mockResolvedValue({}),
        },
      };

      return prisma;
    }

    function createConversationDependencies() {
      return {
        governanceService: {
          moderateMessage: jest.fn(),
        } as unknown as MarketplaceGovernanceService,
        persistenceService: {
          createMessageModerationLog: jest.fn(),
          createModerationReviewQueueItems: jest.fn(),
          attachConversationMessageModerationLog: jest.fn(),
        } as unknown as GovernancePersistenceService,
        gateway: {
          emitNewMessage: jest.fn(),
        },
      };
    }

    it('blocks a non-ALLOW moderation decision before persistence', async () => {
      const prisma = createConversationPrismaMock();
      const { governanceService, persistenceService, gateway } =
        createConversationDependencies();
      const service = new ConversationMessagesService(
        prisma as any,
        governanceService,
        persistenceService,
        gateway as any,
      );

      prisma.conversationParticipant.findUnique.mockResolvedValue({
        conversationId: 'conv-1',
        userId: 7,
        leftAt: null,
        removedAt: null,
      });
      prisma.conversationMessage.findUnique.mockResolvedValue(null);
      prisma.conversationMessage.findMany.mockResolvedValue([
        { content: 'tin nhắn gần đây' },
      ]);
      (governanceService.moderateMessage as jest.Mock).mockResolvedValue({
        allowSend: false,
        moderation: {
          decision: 'rewrite_suggest',
          riskScore: 35,
          ruleHits: [
            {
              ruleCode: 'EXTERNAL_LINK',
              riskDelta: 35,
              explanation: 'external link',
            },
          ],
          suggestedRewrite: 'Hãy giữ trao đổi trong ứng dụng nhé',
          aiReviewRecommended: false,
          recommendedActions: ['Suggest an in-app safe rewrite before sending'],
        },
        reviewQueue: [],
        automationBoundary: {
          automatedSteps: [],
          manualReviewTriggers: ['rewrite'],
          forbiddenActions: ['persist_message'],
        },
      });
      (
        persistenceService.createMessageModerationLog as jest.Mock
      ).mockResolvedValue({
        id: 'mod-log-1',
      });

      await expect(
        service.sendMessage('conv-1', 7, {
          clientMessageId: 'client-msg-1',
          type: 'TEXT' as any,
          content: 'xem thêm ở https://example.com',
        }),
      ).rejects.toThrow(UnprocessableEntityException);

      expect(prisma.conversationMessage.create).not.toHaveBeenCalled();
      expect(gateway.emitNewMessage).not.toHaveBeenCalled();
    });

    it('persists and fans out an ALLOW decision', async () => {
      const prisma = createConversationPrismaMock();
      const { governanceService, persistenceService, gateway } =
        createConversationDependencies();
      const service = new ConversationMessagesService(
        prisma as any,
        governanceService,
        persistenceService,
        gateway as any,
      );

      prisma.conversationParticipant.findUnique.mockResolvedValue({
        conversationId: 'conv-2',
        userId: 8,
        leftAt: null,
        removedAt: null,
      });
      prisma.conversationMessage.findUnique.mockResolvedValue(null);
      prisma.conversationMessage.findMany.mockResolvedValue([]);
      prisma.conversationMessage.findFirst.mockResolvedValue({ seq: 4 });
      prisma.conversationMessage.create.mockResolvedValue({
        id: 'msg-allow-1',
        conversationId: 'conv-2',
        senderId: 8,
        clientMessageId: 'client-msg-allow',
        seq: 5,
        type: 'TEXT',
        content: 'Tôi sẽ gửi trong ứng dụng.',
        attachments: null,
        editedAt: null,
        deletedAt: null,
        createdAt: new Date('2026-03-18T12:00:00Z'),
        sender: {
          id: 8,
          name: 'User 8',
          avatar: null,
        },
      });
      (governanceService.moderateMessage as jest.Mock).mockResolvedValue({
        allowSend: true,
        moderation: {
          decision: 'allow',
          riskScore: 0,
          ruleHits: [],
          suggestedRewrite: undefined,
          aiReviewRecommended: false,
          recommendedActions: ['Allow send immediately'],
        },
        reviewQueue: [],
        automationBoundary: {
          automatedSteps: ['persist_message'],
          manualReviewTriggers: [],
          forbiddenActions: [],
        },
      });
      (
        persistenceService.createMessageModerationLog as jest.Mock
      ).mockResolvedValue({
        id: 'mod-log-2',
      });

      const result = await service.sendMessage('conv-2', 8, {
        clientMessageId: 'client-msg-allow',
        type: 'TEXT' as any,
        content: 'Tôi sẽ gửi trong ứng dụng.',
      });

      expect(prisma.conversationMessage.create).toHaveBeenCalledTimes(1);
      expect(
        persistenceService.attachConversationMessageModerationLog,
      ).toHaveBeenCalledWith('mod-log-2', 'msg-allow-1');
      expect(gateway.emitNewMessage).toHaveBeenCalledTimes(1);
      expect(result.id).toBe('msg-allow-1');
    });
  });
});
