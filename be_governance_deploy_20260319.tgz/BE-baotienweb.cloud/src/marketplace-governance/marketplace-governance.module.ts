import { Module } from '@nestjs/common';

import { AuditLogModule } from '../audit/audit-log.module';
import { PrismaModule } from '../prisma/prisma.module';
import { MarketplaceGovernanceService } from './governance.service';
import { MarketplaceGovernanceController } from './marketplace-governance.controller';
import { AutomationBoundaryService } from './services/automation-boundary.service';
import { GovernancePersistenceService } from './services/governance-persistence.service';
import { MessageModerationService } from './services/message-moderation.service';
import { PriceAnomalyService } from './services/price-anomaly.service';
import { ProductMatchingService } from './services/product-matching.service';
import { ReviewQueueService } from './services/review-queue.service';
import { SellerComplianceService } from './services/seller-compliance.service';

@Module({
  imports: [AuditLogModule, PrismaModule],
  controllers: [MarketplaceGovernanceController],
  providers: [
    MarketplaceGovernanceService,
    GovernancePersistenceService,
    ProductMatchingService,
    PriceAnomalyService,
    SellerComplianceService,
    MessageModerationService,
    ReviewQueueService,
    AutomationBoundaryService,
  ],
  exports: [MarketplaceGovernanceService, GovernancePersistenceService],
})
export class MarketplaceGovernanceModule {}
