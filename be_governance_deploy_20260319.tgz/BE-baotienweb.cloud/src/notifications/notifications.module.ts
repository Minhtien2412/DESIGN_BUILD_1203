import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { NotificationsController } from './notifications.controller';
import { NotificationsGateway } from './notifications.gateway';
import { NotificationsService } from './notifications.service';
import { PushTokensController } from './push-tokens.controller';
import { PushService } from './push.service';

@Module({
  imports: [PrismaModule],
  controllers: [NotificationsController, PushTokensController],
  providers: [NotificationsService, NotificationsGateway, PushService],
  exports: [NotificationsService, NotificationsGateway, PushService],
})
export class NotificationsModule {}
