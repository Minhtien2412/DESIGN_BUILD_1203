/**
 * Push Tokens Controller
 * Handles device token registration and management for push notifications
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Logger,
    Param,
    Post,
    Request,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RegisterPushTokenDto } from './dto/register-push-token.dto';
import { PushService } from './push.service';

@ApiTags('Push Tokens')
@ApiBearerAuth()
@Controller('push-tokens')
@UseGuards(JwtAuthGuard)
export class PushTokensController {
  private readonly logger = new Logger(PushTokensController.name);

  constructor(private readonly pushService: PushService) {}

  /**
   * Register a new push token for the authenticated user
   * POST /api/v1/push-tokens
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Register a push token for current user' })
  async registerToken(@Request() req, @Body() dto: RegisterPushTokenDto) {
    const userId = req.user.id;
    this.logger.log(
      `📱 User ${userId} registering push token: ${dto.token?.substring(0, 30)}...`,
    );
    return this.pushService.registerToken(userId, dto);
  }

  /**
   * Get all active push tokens for the authenticated user
   * GET /api/v1/push-tokens
   */
  @Get()
  @ApiOperation({ summary: 'Get all push tokens for current user' })
  async getUserTokens(@Request() req) {
    const userId = req.user.id;
    const tokens = await this.pushService.getUserTokens(userId);
    return { data: tokens, count: tokens.length };
  }

  /**
   * Remove a specific push token
   * DELETE /api/v1/push-tokens/:token
   */
  @Delete(':token')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Remove a push token' })
  async removeToken(@Param('token') token: string) {
    return this.pushService.removeToken(decodeURIComponent(token));
  }

  /**
   * Send a test push notification to the authenticated user
   * POST /api/v1/push-tokens/test
   */
  @Post('test')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Send a test push notification' })
  async sendTestPush(
    @Request() req,
    @Body() body: { title?: string; message?: string },
  ): Promise<{
    success: boolean;
    message: string;
    details: { sent: number; failed: number };
  }> {
    const userId = req.user.id;
    const title = body.title || 'Test Notification';
    const message =
      body.message || 'This is a test push notification from DesignBuild app!';

    this.logger.log(`🧪 Sending test push to user ${userId}`);

    const result = await this.pushService.sendToUser(userId, title, message, {
      type: 'test',
      timestamp: new Date().toISOString(),
    });

    return {
      success: result.sent > 0,
      message:
        result.sent > 0
          ? `Test notification sent to ${result.sent} device(s)`
          : 'No active devices found for push notification',
      details: result,
    };
  }
}
