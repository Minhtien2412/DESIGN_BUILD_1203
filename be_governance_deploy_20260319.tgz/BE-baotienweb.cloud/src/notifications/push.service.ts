/**
 * Push Notification Service
 * Handles device token management and push notification sending via Expo
 */

import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    DevicePlatform,
    RegisterPushTokenDto,
} from './dto/register-push-token.dto';

// Types for Expo Push (manual implementation without expo-server-sdk)
interface ExpoPushMessage {
  to: string;
  title?: string;
  body?: string;
  data?: Record<string, any>;
  sound?: 'default' | null;
  badge?: number;
  priority?: 'default' | 'normal' | 'high';
  channelId?: string;
}

interface ExpoPushTicket {
  status: 'ok' | 'error';
  id?: string;
  message?: string;
  details?: any;
}

@Injectable()
export class PushService {
  private readonly logger = new Logger(PushService.name);
  private readonly EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Register or update a device push token
   */
  async registerToken(userId: number, dto: RegisterPushTokenDto) {
    const { token, platform, deviceId, deviceName, appVersion } = dto;

    // Map string platform to enum
    const platformEnum = this.mapPlatform(platform);

    try {
      // Upsert token - update if exists, create if not
      const deviceToken = await this.prisma.device_tokens.upsert({
        where: { token },
        update: {
          userId,
          platform: platformEnum,
          deviceId,
          appVersion,
          isActive: true,
          lastUsed: new Date(),
          updatedAt: new Date(),
        },
        create: {
          userId,
          token,
          platform: platformEnum,
          deviceId,
          appVersion,
          isActive: true,
          updatedAt: new Date(),
        },
      });

      this.logger.log(
        `📱 Registered push token for user ${userId}: ${token.substring(0, 30)}...`,
      );

      return {
        success: true,
        message: 'Push token registered successfully',
        data: {
          id: deviceToken.id,
          platform: deviceToken.platform,
          isActive: deviceToken.isActive,
        },
      };
    } catch (error) {
      this.logger.error(`Failed to register push token: ${error.message}`);
      throw error;
    }
  }

  /**
   * Remove a device token (unregister)
   */
  async removeToken(token: string) {
    try {
      await this.prisma.device_tokens.delete({
        where: { token },
      });
      this.logger.log(`🗑️ Removed push token: ${token.substring(0, 30)}...`);
      return { success: true, message: 'Token removed' };
    } catch (error) {
      this.logger.warn(
        `Token not found for removal: ${token.substring(0, 30)}...`,
      );
      return { success: false, message: 'Token not found' };
    }
  }

  /**
   * Get all active tokens for a user
   */
  async getUserTokens(userId: number) {
    return this.prisma.device_tokens.findMany({
      where: { userId, isActive: true },
      select: {
        id: true,
        token: true,
        platform: true,
        deviceId: true,
        lastUsed: true,
      },
    });
  }

  /**
   * Deactivate old/invalid tokens for a user
   */
  async deactivateToken(token: string) {
    try {
      await this.prisma.device_tokens.update({
        where: { token },
        data: { isActive: false, updatedAt: new Date() },
      });
      this.logger.log(
        `🔇 Deactivated push token: ${token.substring(0, 30)}...`,
      );
    } catch (error) {
      this.logger.warn(`Failed to deactivate token: ${error.message}`);
    }
  }

  /**
   * Send push notification to a specific user
   */
  async sendToUser(
    userId: number,
    title: string,
    body: string,
    data?: Record<string, any>,
  ): Promise<{ sent: number; failed: number; tickets: ExpoPushTicket[] }> {
    const tokens = await this.getUserTokens(userId);

    if (tokens.length === 0) {
      this.logger.log(`📭 No active tokens for user ${userId}`);
      return { sent: 0, failed: 0, tickets: [] };
    }

    const messages: ExpoPushMessage[] = tokens.map((t) => ({
      to: t.token,
      title,
      body,
      data,
      sound: 'default',
      priority: 'high',
    }));

    return this.sendPushNotifications(messages);
  }

  /**
   * Send push notifications via Expo Push API
   */
  private async sendPushNotifications(
    messages: ExpoPushMessage[],
  ): Promise<{ sent: number; failed: number; tickets: ExpoPushTicket[] }> {
    if (messages.length === 0) {
      return { sent: 0, failed: 0, tickets: [] };
    }

    try {
      // Expo accepts max 100 messages per request
      const chunks = this.chunkArray(messages, 100);
      const allTickets: ExpoPushTicket[] = [];
      let sent = 0;
      let failed = 0;

      for (const chunk of chunks) {
        const response = await fetch(this.EXPO_PUSH_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Accept-Encoding': 'gzip, deflate',
          },
          body: JSON.stringify(chunk),
        });

        if (!response.ok) {
          this.logger.error(`Expo Push API error: ${response.status}`);
          failed += chunk.length;
          continue;
        }

        const result = await response.json();
        const tickets: ExpoPushTicket[] = result.data || [];
        allTickets.push(...tickets);

        // Process tickets
        for (let i = 0; i < tickets.length; i++) {
          const ticket = tickets[i];
          if (ticket.status === 'ok') {
            sent++;
          } else {
            failed++;
            // Deactivate invalid tokens
            if (ticket.details?.error === 'DeviceNotRegistered') {
              await this.deactivateToken(chunk[i].to);
            }
          }
        }
      }

      this.logger.log(`📤 Push sent: ${sent} success, ${failed} failed`);
      return { sent, failed, tickets: allTickets };
    } catch (error) {
      this.logger.error(`Push notification error: ${error.message}`);
      return { sent: 0, failed: messages.length, tickets: [] };
    }
  }

  /**
   * Map platform string to enum
   */
  private mapPlatform(platform?: DevicePlatform | string): any {
    if (!platform) return 'ANDROID';
    const p = String(platform).toUpperCase();
    if (p === 'IOS') return 'IOS';
    if (p === 'WEB') return 'WEB';
    return 'ANDROID';
  }

  /**
   * Split array into chunks
   */
  private chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
}
