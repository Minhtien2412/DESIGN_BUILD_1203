import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { NotificationQueryDto } from './dto/notification-query.dto';
import { NotificationsService } from './notifications.service';

@ApiTags('Notifications')
@ApiBearerAuth()
@Controller('notifications')
@UseGuards(JwtAuthGuard)
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  // ========================================
  // ADMIN: Broadcast notification to all users
  // ========================================
  @Post('broadcast')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Broadcast notification to all users' })
  @ApiResponse({ status: 201, description: 'Notification broadcast sent' })
  async broadcast(@Request() req, @Body() body: any) {
    const { type, title, message, priority, metadata } = body;

    let parsedMetadata = metadata;
    if (typeof metadata === 'string') {
      try {
        parsedMetadata = JSON.parse(metadata);
      } catch (e) {
        parsedMetadata = {};
      }
    }

    return this.notificationsService.broadcast({
      type: type || 'IN_APP',
      title,
      message,
      priority: priority || 'HIGH',
      data: parsedMetadata,
    });
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a notification for current user' })
  async create(@Request() req, @Body() body: any) {
    const userId = req.user.id;
    // Support both 'message' (frontend) and 'body' (legacy) field names
    const { type, title, message, body: legacyBody, priority, metadata } = body;
    const notificationMessage = message || legacyBody; // Use 'message' or fallback to 'body'

    // Parse metadata if string
    let parsedMetadata = metadata;
    if (typeof metadata === 'string') {
      try {
        parsedMetadata = JSON.parse(metadata);
      } catch (e) {
        parsedMetadata = {};
      }
    }

    return this.notificationsService.create({
      userId,
      type: type || 'IN_APP',
      title,
      message: notificationMessage,
      priority: priority || 'MEDIUM',
      data: parsedMetadata,
    });
  }

  @Get()
  @ApiOperation({ summary: 'Get all notifications with filters' })
  async findAll(@Request() req, @Query() query: NotificationQueryDto) {
    const userId = req.user.id;
    return this.notificationsService.findAll(userId, query);
  }

  @Get('unread-count')
  @ApiOperation({ summary: 'Get unread notification count' })
  async getUnreadCount(@Request() req) {
    const userId = req.user.id;
    return this.notificationsService.getUnreadCount(userId);
  }

  @Patch(':id/read')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Mark a notification as read' })
  async markAsRead(@Request() req, @Param('id', ParseIntPipe) id: number) {
    const userId = req.user.id;
    return this.notificationsService.markAsRead(id, userId);
  }

  @Patch('read-all')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Mark all notifications as read' })
  async markAllAsRead(@Request() req) {
    const userId = req.user.id;
    return this.notificationsService.markAllAsRead(userId);
  }

  @Patch(':id/archive')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Archive (delete) a notification' })
  async archive(@Request() req, @Param('id', ParseIntPipe) id: number) {
    const userId = req.user.id;
    await this.notificationsService.delete(id, userId);
  }
}
