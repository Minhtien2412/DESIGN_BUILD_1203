import { Logger } from '@nestjs/common';
import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

/**
 * Notifications WebSocket Gateway
 * 
 * Namespace: /notifications
 * Purpose: Real-time notification delivery to connected clients
 * 
 * Features:
 * - Multi-device support (one user can have multiple connections)
 * - Automatic reconnection handling
 * - User registration per socket
 * - Broadcast capabilities
 */
@WebSocketGateway({ 
  namespace: '/notifications',
  cors: { 
    origin: '*', 
    credentials: true 
  }
})
export class NotificationsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() 
  server: Server;
  
  private readonly logger = new Logger(NotificationsGateway.name);
  
  /**
   * Track active user connections
   * Key: userId (number)
   * Value: Set of socketIds (string)
   * 
   * Why Set? A user can be connected from multiple devices simultaneously:
   * - Phone + Web browser
   * - Multiple tabs
   * - Background + Foreground
   */
  private userSockets = new Map<number, Set<string>>();

  /**
   * Connection event handler
   * Called when a client connects to /notifications namespace
   */
  handleConnection(@ConnectedSocket() client: Socket) {
    this.logger.log(`Client connected: ${client.id}`);
    
    // Send connection confirmation
    client.emit('connected', { 
      socketId: client.id, 
      timestamp: new Date().toISOString(),
      namespace: '/notifications'
    });
  }

  /**
   * Disconnection event handler
   * Called when a client disconnects (close tab, network loss, etc.)
   */
  handleDisconnect(@ConnectedSocket() client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
    
    // Remove socket from all user mappings
    this.userSockets.forEach((sockets, userId) => {
      if (sockets.has(client.id)) {
        sockets.delete(client.id);
        this.logger.debug(`Removed socket ${client.id} from user ${userId}`);
        
        // If user has no more connections, remove user entry
        if (sockets.size === 0) {
          this.userSockets.delete(userId);
          this.logger.log(`User ${userId} fully disconnected (all devices offline)`);
        } else {
          this.logger.debug(`User ${userId} still has ${sockets.size} connection(s)`);
        }
      }
    });
  }

  /**
   * Register event handler
   * Client must send this after connecting to associate socket with user
   * 
   * @example
   * socket.emit('register', { userId: 22 })
   */
  @SubscribeMessage('register')
  handleRegister(
    @ConnectedSocket() client: Socket,
    @MessageBody() payload: { userId: number }
  ) {
    const { userId } = payload;
    
    // Validate userId
    if (!userId || typeof userId !== 'number') {
      this.logger.warn(`Invalid userId in register: ${userId}`);
      client.emit('error', { 
        event: 'register',
        message: 'userId must be a valid number' 
      });
      return;
    }

    // Create Set if user doesn't exist
    if (!this.userSockets.has(userId)) {
      this.userSockets.set(userId, new Set());
    }
    
    // Add this socket to user's connections
    this.userSockets.get(userId)!.add(client.id);
    
    const deviceCount = this.userSockets.get(userId)!.size;
    this.logger.log(`User ${userId} registered (socket: ${client.id}, devices: ${deviceCount})`);
    
    // Send confirmation
    client.emit('registered', { 
      success: true, 
      userId,
      socketId: client.id,
      deviceCount,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Ping handler for connection health check
   * Client can use this to verify connection is alive
   */
  @SubscribeMessage('ping')
  handlePing(@ConnectedSocket() client: Socket) {
    client.emit('pong', { 
      socketId: client.id,
      timestamp: new Date().toISOString() 
    });
  }

  /**
   * Send notification to a specific user
   * Called by NotificationsService when creating a notification
   * 
   * @param userId - Target user ID
   * @param notification - Notification object to send
   * @returns boolean - true if sent, false if user offline
   */
  sendToUser(userId: number, notification: any): boolean {
    const socketIds = this.userSockets.get(userId);
    
    // User not connected
    if (!socketIds || socketIds.size === 0) {
      this.logger.debug(`User ${userId} not connected - cannot send real-time notification`);
      return false;
    }

    // Prepare payload
    const payload = {
      ...notification,
      timestamp: new Date().toISOString(),
      delivered: true,
      deliveryMethod: 'websocket'
    };

    // Send to all user's devices
    let sentCount = 0;
    socketIds.forEach(socketId => {
      try {
        this.server.to(socketId).emit('notification', payload);
        sentCount++;
      } catch (error: unknown) {
        this.logger.error(`Error sending to socket ${socketId}:`, error);
      }
    });

    this.logger.log(`Sent notification to user ${userId} (${sentCount}/${socketIds.size} device(s))`);
    return sentCount > 0;
  }

  /**
   * Broadcast notification to all connected users
   * Used for system-wide announcements
   * 
   * @param notification - Notification to broadcast
   */
  broadcast(notification: any): void {
    const payload = {
      ...notification,
      timestamp: new Date().toISOString(),
      type: 'broadcast',
      deliveryMethod: 'websocket'
    };

    this.server.emit('broadcast', payload);

    const totalUsers = this.userSockets.size;
    const totalConnections = Array.from(this.userSockets.values())
      .reduce((sum, sockets) => sum + sockets.size, 0);

    this.logger.log(`Broadcast notification to ${totalUsers} users (${totalConnections} connections)`);
  }

  /**
   * Send notification to multiple users
   * Optimized for bulk sending
   * 
   * @param userIds - Array of user IDs
   * @param notification - Notification to send
   */
  sendToMultipleUsers(userIds: number[], notification: any): void {
    const payload = {
      ...notification,
      timestamp: new Date().toISOString(),
      delivered: true,
      deliveryMethod: 'websocket'
    };

    let sentToUsers = 0;
    let totalDevices = 0;

    userIds.forEach(userId => {
      const socketIds = this.userSockets.get(userId);
      if (socketIds && socketIds.size > 0) {
        socketIds.forEach(socketId => {
          this.server.to(socketId).emit('notification', payload);
          totalDevices++;
        });
        sentToUsers++;
      }
    });

    this.logger.log(`Sent to ${sentToUsers}/${userIds.length} users (${totalDevices} devices)`);
  }

  /**
   * Get statistics about connected clients
   */
  getStats() {
    const totalUsers = this.userSockets.size;
    const totalConnections = Array.from(this.userSockets.values())
      .reduce((sum, sockets) => sum + sockets.size, 0);
    
    const userConnectionCounts = Array.from(this.userSockets.entries()).map(
      ([userId, sockets]) => ({ userId, connectionCount: sockets.size })
    );

    return {
      totalUsers,
      totalConnections,
      averageConnectionsPerUser: totalUsers > 0 ? (totalConnections / totalUsers).toFixed(2) : 0,
      users: userConnectionCounts
    };
  }

  /**
   * Check if a specific user is online
   * 
   * @param userId - User ID to check
   * @returns boolean - true if user has at least one connection
   */
  isUserOnline(userId: number): boolean {
    const sockets = this.userSockets.get(userId);
    return sockets !== undefined && sockets.size > 0;
  }

  /**
   * Get number of connections for a user
   * 
   * @param userId - User ID
   * @returns number - Number of active connections (0 if offline)
   */
  getUserConnectionCount(userId: number): number {
    return this.userSockets.get(userId)?.size ?? 0;
  }

  /**
   * Force disconnect a user (all devices)
   * Useful for security purposes (e.g., password reset, session revoked)
   * 
   * @param userId - User ID to disconnect
   */
  disconnectUser(userId: number): void {
    const socketIds = this.userSockets.get(userId);
    
    if (!socketIds || socketIds.size === 0) {
      this.logger.debug(`User ${userId} not connected - nothing to disconnect`);
      return;
    }

    socketIds.forEach(socketId => {
      const socket = this.server.sockets.sockets.get(socketId);
      if (socket) {
        socket.emit('force_disconnect', { 
          reason: 'Session terminated',
          timestamp: new Date().toISOString()
        });
        socket.disconnect(true);
      }
    });

    this.userSockets.delete(userId);
    this.logger.log(`Force disconnected user ${userId} (${socketIds.size} devices)`);
  }
}
