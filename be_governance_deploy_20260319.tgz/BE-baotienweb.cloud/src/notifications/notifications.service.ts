import {
    Inject,
    Injectable,
    NotFoundException,
    forwardRef,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { NotificationQueryDto } from './dto/notification-query.dto';
import { NotificationsGateway } from './notifications.gateway';
import { PushService } from './push.service';

@Injectable()
export class NotificationsService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(forwardRef(() => NotificationsGateway))
    private readonly notificationsGateway: NotificationsGateway,
    @Inject(forwardRef(() => PushService))
    private readonly pushService: PushService,
  ) {}

  async findAll(userId: number, query: NotificationQueryDto) {
    const {
      page = 1,
      limit = 20,
      type,
      category,
      read,
      priority,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = query;

    const skip = (page - 1) * limit;

    const where: any = { userId };

    // Support both "type" and "category" as filter param
    const filterType = type || category;
    if (filterType) {
      where.type = filterType;
    }

    if (read !== undefined) {
      where.isRead = read;
    }

    if (priority) {
      where.priority = priority;
    }

    const [notifications, total] = await Promise.all([
      this.prisma.notifications.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
      }),
      this.prisma.notifications.count({ where }),
    ]);

    // Transform to match frontend expectations
    const transformed = notifications.map((n) => ({
      id: n.id,
      userId: n.userId,
      title: n.title,
      message: n.body, // Map body to message
      type: n.type,
      priority: n.priority,
      read: n.isRead, // Map isRead to read
      readAt: n.readAt,
      data: n.data,
      createdAt: n.createdAt,
      updatedAt: n.updatedAt,
    }));

    return {
      data: transformed,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getUnreadCount(userId: number) {
    const count = await this.prisma.notifications.count({
      where: { userId, isRead: false },
    });

    return { count };
  }

  async findOne(id: number, userId: number) {
    const notification = await this.prisma.notifications.findFirst({
      where: { id, userId },
    });

    if (!notification) {
      throw new NotFoundException(`Notification with ID ${id} not found`);
    }

    return {
      id: notification.id,
      userId: notification.userId,
      title: notification.title,
      message: notification.body,
      type: notification.type,
      priority: notification.priority,
      read: notification.isRead,
      readAt: notification.readAt,
      data: notification.data,
      createdAt: notification.createdAt,
      updatedAt: notification.updatedAt,
    };
  }

  // Map frontend notification types to Prisma enum
  private mapToPrismaType(frontendType: string): string {
    const typeMap: Record<string, string> = {
      INFO: 'SYSTEM',
      SUCCESS: 'SYSTEM',
      WARNING: 'SYSTEM',
      ERROR: 'SYSTEM',
      CALL: 'MESSAGE',
      MESSAGE: 'MESSAGE',
      TASK: 'TASK_ASSIGNED',
      PROJECT: 'PROJECT_UPDATE',
      PAYMENT: 'PAYMENT',
      SYSTEM: 'SYSTEM',
    };
    return typeMap[frontendType?.toUpperCase()] || 'SYSTEM';
  }

  async create(dto: CreateNotificationDto) {
    console.log(
      '[NotificationsService] Creating notification with DTO:',
      JSON.stringify(dto),
    );
    console.log('[NotificationsService] dto.message:', dto.message);

    const prismaType = this.mapToPrismaType(dto.type);
    console.log(
      '[NotificationsService] Mapped type:',
      dto.type,
      '->',
      prismaType,
    );

    const notification = await this.prisma.notifications.create({
      data: {
        userId: dto.userId,
        title: dto.title,
        body: dto.message, // Map message to body
        type: prismaType as any,
        priority: (dto.priority || 'MEDIUM') as any,
        data: dto.data,
        updatedAt: new Date(),
      },
    });

    // Transform to match frontend expectations - preserve original type
    const transformed = {
      id: notification.id,
      userId: notification.userId,
      title: notification.title,
      message: notification.body,
      type: dto.type, // Return original type for frontend consistency
      priority: notification.priority,
      read: notification.isRead,
      readAt: notification.readAt,
      data: notification.data,
      createdAt: notification.createdAt,
      updatedAt: notification.updatedAt,
    };

    // 🚀 Send via WebSocket in real-time
    try {
      const sent = this.notificationsGateway.sendToUser(
        notification.userId,
        transformed,
      );

      if (sent) {
        console.log(
          `[NotificationsService] Sent real-time notification to user ${notification.userId}`,
        );
      } else {
        console.log(
          `[NotificationsService] User ${notification.userId} offline - notification saved to DB only`,
        );
      }
    } catch (error: unknown) {
      console.error(
        '[NotificationsService] Error sending real-time notification:',
        error,
      );
      // Don't fail the request if WebSocket fails
    }

    // 📱 Send push notification
    try {
      const pushData = {
        notificationId: notification.id,
        type: transformed.type,
        ...(typeof transformed.data === 'object' && transformed.data !== null
          ? transformed.data
          : {}),
      };
      const pushResult = await this.pushService.sendToUser(
        notification.userId,
        transformed.title,
        transformed.message,
        pushData,
      );

      if (pushResult.sent > 0) {
        console.log(
          `[NotificationsService] Sent push notification to ${pushResult.sent} device(s)`,
        );
        // Mark notification as sent
        await this.prisma.notifications.update({
          where: { id: notification.id },
          data: { isSent: true, sentAt: new Date() },
        });
      }
    } catch (error: unknown) {
      console.error(
        '[NotificationsService] Error sending push notification:',
        error,
      );
      // Don't fail the request if push fails
    }

    return transformed;
  }

  async markAsRead(id: number, userId: number) {
    // Verify ownership
    await this.findOne(id, userId);

    const notification = await this.prisma.notifications.update({
      where: { id },
      data: {
        isRead: true,
        readAt: new Date(),
        updatedAt: new Date(),
      },
    });

    return {
      id: notification.id,
      userId: notification.userId,
      title: notification.title,
      message: notification.body,
      type: notification.type,
      priority: notification.priority,
      read: notification.isRead,
      readAt: notification.readAt,
      data: notification.data,
      createdAt: notification.createdAt,
      updatedAt: notification.updatedAt,
    };
  }

  async markAllAsRead(userId: number) {
    const result = await this.prisma.notifications.updateMany({
      where: { userId, isRead: false },
      data: {
        isRead: true,
        readAt: new Date(),
        updatedAt: new Date(),
      },
    });

    return { updatedCount: result.count };
  }

  async delete(id: number, userId: number) {
    // Verify ownership
    await this.findOne(id, userId);

    await this.prisma.notifications.delete({
      where: { id },
    });
  }

  // Admin/System method to broadcast notifications
  async broadcast(dto: Omit<CreateNotificationDto, 'userId'>) {
    // Get all user IDs
    const users = await this.prisma.user.findMany({
      select: { id: true },
    });

    const notifications = users.map((user) => ({
      userId: user.id,
      title: dto.title,
      body: dto.message,
      type: dto.type as any,
      priority: (dto.priority || 'MEDIUM') as any,
      data: dto.data,
      updatedAt: new Date(),
    }));

    await this.prisma.notifications.createMany({
      data: notifications,
    });

    return { sent: notifications.length };
  }
}
