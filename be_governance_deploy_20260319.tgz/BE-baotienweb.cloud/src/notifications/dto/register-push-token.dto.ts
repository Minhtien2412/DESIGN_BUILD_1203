import { Transform } from 'class-transformer';
import { IsOptional, IsString } from 'class-validator';

export enum DevicePlatform {
  IOS = 'IOS',
  ANDROID = 'ANDROID',
  WEB = 'WEB',
}

export class RegisterPushTokenDto {
  @IsString()
  token: string;

  @IsString()
  @IsOptional()
  @Transform(({ value }) => {
    // Accept both lowercase (ios, android) and uppercase (IOS, ANDROID)
    const normalized = String(value || 'android').toUpperCase();
    return Object.values(DevicePlatform).includes(normalized as DevicePlatform)
      ? normalized
      : DevicePlatform.ANDROID;
  })
  platform?: string = DevicePlatform.ANDROID;

  @IsString()
  @IsOptional()
  deviceId?: string;

  @IsString()
  @IsOptional()
  deviceName?: string;

  @IsString()
  @IsOptional()
  appVersion?: string;
}
