import { IsNotEmpty, IsString, IsEnum, IsOptional, IsInt, IsObject } from 'class-validator';

export class CreateNotificationDto {
  @IsInt()
  @IsNotEmpty()
  userId: number;

  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  message: string;

  @IsEnum(['INFO', 'SUCCESS', 'WARNING', 'ERROR', 'CALL', 'MESSAGE'])
  @IsNotEmpty()
  type: string;

  @IsOptional()
  @IsEnum(['SYSTEM', 'EVENT', 'LIVE', 'MESSAGE'])
  category?: string;

  @IsOptional()
  @IsEnum(['LOW', 'NORMAL', 'HIGH', 'URGENT'])
  priority?: string;

  @IsOptional()
  @IsObject()
  data?: any; // JSON metadata (actionUrl, etc.)
}
