import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class CreateVideoRoomDto {
  @ApiProperty({ description: 'ID của project', example: 1 })
  @IsInt()
  @IsNotEmpty()
  projectId: number;

  @ApiProperty({
    description: 'Tên video room',
    example: 'Project Meeting Room',
  })
  @IsString()
  @IsNotEmpty()
  roomName: string;
}
