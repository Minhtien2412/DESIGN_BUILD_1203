import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString, IsOptional } from 'class-validator';

export class JoinVideoRoomDto {
  @ApiProperty({ description: 'ID của video room', example: 1 })
  @IsInt()
  @IsNotEmpty()
  roomId: number;

  @ApiPropertyOptional({
    description: 'Tên hiển thị của người tham gia',
    example: 'John Doe',
  })
  @IsString()
  @IsOptional()
  participantName?: string;
}
