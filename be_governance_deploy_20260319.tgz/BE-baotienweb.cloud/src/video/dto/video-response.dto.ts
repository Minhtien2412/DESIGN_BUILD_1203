import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class VideoRoomResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 'project-meeting-room-abc123' })
  roomName: string;

  @ApiProperty({ example: 'ACTIVE', enum: ['ACTIVE', 'ENDED'] })
  status: string;

  @ApiProperty({ example: 1 })
  projectId: number;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  startedAt: Date;

  @ApiPropertyOptional({ example: '2024-01-01T01:00:00.000Z' })
  endedAt?: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'Danh sách người tham gia',
    example: [
      {
        id: 1,
        name: 'User 1',
        email: 'user1@example.com',
        joinedAt: '2024-01-01T00:00:00.000Z',
      },
    ],
  })
  participants?: Array<{
    id: number;
    name: string | null;
    email: string;
    joinedAt: Date;
    leftAt?: Date;
  }>;
}

export class VideoTokenResponseDto {
  @ApiProperty({ example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' })
  token: string;

  @ApiProperty({ example: 'wss://livekit.example.com' })
  url: string;

  @ApiProperty({ example: 'project-meeting-room-abc123' })
  roomName: string;

  @ApiProperty({ example: 'user_123' })
  identity: string;
}
