/**
 * Video Interactions DTOs
 * DTOs for video likes, comments, views, shares
 */

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsInt, IsOptional, IsString, MaxLength, Min } from 'class-validator';

export class LikeVideoDto {
  @ApiProperty({ description: 'Video ID to like' })
  @IsInt()
  videoId: number;
}

export class CommentVideoDto {
  @ApiProperty({ description: 'Video ID to comment on' })
  @IsInt()
  videoId: number;

  @ApiProperty({ description: 'Comment content', maxLength: 2000 })
  @IsString()
  @MaxLength(2000)
  content: string;

  @ApiPropertyOptional({ description: 'Parent comment ID for replies' })
  @IsOptional()
  @IsInt()
  parentId?: number;
}

export class UpdateCommentDto {
  @ApiProperty({ description: 'Updated comment content', maxLength: 2000 })
  @IsString()
  @MaxLength(2000)
  content: string;
}

export class ShareVideoDto {
  @ApiProperty({ description: 'Video ID to share' })
  @IsInt()
  videoId: number;

  @ApiPropertyOptional({ description: 'Platform to share to' })
  @IsOptional()
  @IsEnum(['facebook', 'twitter', 'zalo', 'telegram', 'copy_link'])
  platform?: string;
}

export class TrackViewDto {
  @ApiProperty({ description: 'Video ID being viewed' })
  @IsInt()
  videoId: number;

  @ApiPropertyOptional({ description: 'Watch duration in seconds' })
  @IsOptional()
  @IsInt()
  @Min(0)
  watchDuration?: number;

  @ApiPropertyOptional({ description: 'Whether watch completed' })
  @IsOptional()
  @IsBoolean()
  completed?: boolean;
}

export class VideoStatsDto {
  @ApiProperty()
  videoId: number;

  @ApiProperty()
  viewsCount: number;

  @ApiProperty()
  likesCount: number;

  @ApiProperty()
  commentsCount: number;

  @ApiProperty()
  sharesCount: number;

  @ApiProperty()
  isLiked: boolean;

  @ApiProperty()
  avgWatchDuration: number;
}

export class VideoCommentResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  videoId: number;

  @ApiProperty()
  content: string;

  @ApiProperty()
  userId: number;

  @ApiProperty()
  userName: string;

  @ApiPropertyOptional()
  userAvatar?: string;

  @ApiPropertyOptional()
  parentId?: number;

  @ApiProperty()
  likesCount: number;

  @ApiProperty()
  repliesCount: number;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class PaginatedCommentsResponseDto {
  @ApiProperty({ type: [VideoCommentResponseDto] })
  comments: VideoCommentResponseDto[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  hasMore: boolean;
}
