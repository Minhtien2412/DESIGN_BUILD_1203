import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  ParseIntPipe,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { VideoService } from './video.service';
import {
  CreateVideoRoomDto,
  JoinVideoRoomDto,
  VideoRoomResponseDto,
  VideoTokenResponseDto,
} from './dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@ApiTags('Video Call')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'video', version: '1' })
export class VideoController {
  constructor(private readonly videoService: VideoService) {}

  @Post('rooms')
  @ApiOperation({ summary: 'Tạo video room mới cho project' })
  @ApiResponse({
    status: 201,
    description: 'Video room đã được tạo',
    type: VideoRoomResponseDto,
  })
  async createRoom(
    @Body() createVideoRoomDto: CreateVideoRoomDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.videoService.createRoom(createVideoRoomDto, userId);
  }

  @Post('rooms/:roomId/token')
  @ApiOperation({ summary: 'Tạo access token để tham gia video room' })
  @ApiResponse({
    status: 200,
    description: 'Access token đã được tạo',
    type: VideoTokenResponseDto,
  })
  async generateToken(
    @Param('roomId', ParseIntPipe) roomId: number,
    @CurrentUser('id') userId: number,
    @Body() joinDto?: JoinVideoRoomDto,
  ) {
    return this.videoService.generateToken(roomId, userId, joinDto);
  }

  @Get('rooms')
  @ApiOperation({ summary: 'Lấy danh sách video rooms đang ACTIVE' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách video rooms',
    type: [VideoRoomResponseDto],
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getActiveRooms(@Query('projectId', ParseIntPipe) projectId?: number) {
    return this.videoService.getActiveRooms(projectId);
  }

  
    @ApiOperation({ summary: 'Kiểm tra cấu hình LiveKit và sức khỏe' })
    @Get('health')
    @ApiResponse({ status: 200, description: 'Trạng thái LiveKit cấu hình' })
    async health() {
      // Trả về thông tin cấu hình hiện tại để hỗ trợ chẩn đoán
      const info = this.videoService.getHealthInfo();
      return {
        livekitUrl: info.url,
        hasApiKey: !!info.apiKey,
        hasApiSecret: !!info.apiSecret,
        warning:
          !info.url || info.url.includes('localhost')
            ? 'LIVEKIT_URL chưa được cấu hình đúng (đang để localhost hoặc rỗng)'
            : undefined,
      };
    }
  @Get('rooms/:roomId')
  @ApiOperation({ summary: 'Lấy thông tin chi tiết video room' })
  @ApiResponse({
    status: 200,
    description: 'Thông tin video room',
    type: VideoRoomResponseDto,
  })
  async getRoomById(@Param('roomId', ParseIntPipe) roomId: number) {
    return this.videoService.getRoomById(roomId);
  }

  @Delete('rooms/:roomId')
  @ApiOperation({ summary: 'Kết thúc video room' })
  @ApiResponse({ status: 200, description: 'Video room đã kết thúc' })
  async endRoom(
    @Param('roomId', ParseIntPipe) roomId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.videoService.endRoom(roomId, userId);
  }

  @Post('rooms/:roomId/leave')
  @ApiOperation({ summary: 'Rời khỏi video room' })
  @ApiResponse({ status: 200, description: 'Đã rời khỏi room' })
  async leaveRoom(
    @Param('roomId', ParseIntPipe) roomId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.videoService.leaveRoom(roomId, userId);
  }
}
