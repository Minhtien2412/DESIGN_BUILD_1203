import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
// import { VideoInteractionsController } from './video-interactions.controller';
// import { VideoInteractionsService } from './video-interactions.service';
import { VideoController } from './video.controller';
import { VideoService } from './video.service';

// NOTE: VideoInteractions requires new Prisma models (VideoLike, VideoComment, etc.)
// After deploying schema.prisma to VPS, run:
// 1. npx prisma migrate dev --name add_video_interactions
// 2. npx prisma generate
// Then uncomment VideoInteractions imports above

@Module({
  imports: [PrismaModule],
  controllers: [VideoController], // VideoInteractionsController - enable after prisma migrate
  providers: [VideoService], // VideoInteractionsService
  exports: [VideoService], // VideoInteractionsService
})
export class VideoModule {}
