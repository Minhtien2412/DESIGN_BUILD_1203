import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AccessToken } from 'livekit-server-sdk';
import { PrismaService } from '../prisma/prisma.service';
import { CreateVideoRoomDto, JoinVideoRoomDto } from './dto';

@Injectable()
export class VideoService {
  private readonly livekitApiKey: string;
  private readonly livekitApiSecret: string;
  private readonly livekitUrl: string;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.livekitApiKey = this.configService.get<string>(
      'LIVEKIT_API_KEY',
      'devkey',
    );
    this.livekitApiSecret = this.configService.get<string>(
      'LIVEKIT_API_SECRET',
      'secret',
    );
    this.livekitUrl = this.configService.get<string>(
      'LIVEKIT_URL',
      'ws://localhost:7880',
    );
  }

  // Tạo video room mới
  async createRoom(createVideoRoomDto: CreateVideoRoomDto, userId: number) {
    const { projectId, roomName } = createVideoRoomDto;

    // Kiểm tra project tồn tại
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { client: true, engineer: true },
    });

    if (!project) {
      throw new NotFoundException(`Project với ID ${projectId} không tồn tại`);
    }

    // Kiểm tra room name đã tồn tại chưa
    const existingRoom = await this.prisma.videoRoom.findUnique({
      where: { roomName },
    });

    if (existingRoom) {
      throw new BadRequestException(
        `Video room với tên "${roomName}" đã tồn tại`,
      );
    }

    // Tạo video room
    const room = await this.prisma.videoRoom.create({
      data: {
        roomName,
        projectId,
        status: 'ACTIVE',
      },
      include: {
        project: {
          select: {
            id: true,
            title: true,
          },
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    return {
      ...room,
      participants: room.participants.map((p) => ({
        ...p.user,
        joinedAt: p.joinedAt,
        leftAt: p.leftAt,
      })),
    };
  }

  // Tạo access token để join room
  async generateToken(
    roomId: number,
    userId: number,
    joinDto?: JoinVideoRoomDto,
  ) {
    // Kiểm tra room tồn tại và đang ACTIVE
    const room = await this.prisma.videoRoom.findUnique({
      where: { id: roomId },
    });

    if (!room) {
      throw new NotFoundException(`Video room với ID ${roomId} không tồn tại`);
    }

    if (room.status !== 'ACTIVE') {
      throw new BadRequestException(`Video room đã kết thúc`);
    }

    // Lấy thông tin user
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException(`User với ID ${userId} không tồn tại`);
    }

    // Ghi nhận tham gia room hoặc reset trạng thái nếu đã có
    await this.prisma.videoRoomParticipant.upsert({
      where: {
        roomId_userId: {
          roomId,
          userId,
        },
      },
      create: {
        roomId,
        userId,
        joinedAt: new Date(),
      },
      update: {
        leftAt: null,
      },
    });

    // Tạo LiveKit access token
    const participantName = joinDto?.participantName || user.name || user.email;
    const identity = `user_${userId}`;

    const token = new AccessToken(this.livekitApiKey, this.livekitApiSecret, {
      identity,
      name: participantName,
    });

    // Grant quyền vào room
    token.addGrant({
      roomJoin: true,
      room: room.roomName,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true,
    });

    return {
      token: await token.toJwt(),
      url: this.livekitUrl,
      roomName: room.roomName,
      identity,
    };
  }

  // Kết thúc video room
  async endRoom(roomId: number, userId: number) {
    const room = await this.prisma.videoRoom.findUnique({
      where: { id: roomId },
      include: {
        project: true,
      },
    });

    if (!room) {
      throw new NotFoundException(`Video room với ID ${roomId} không tồn tại`);
    }

    // Cập nhật status và endedAt
    const updatedRoom = await this.prisma.videoRoom.update({
      where: { id: roomId },
      data: {
        status: 'ENDED',
        endedAt: new Date(),
      },
    });

    // Cập nhật leftAt cho tất cả participants
    await this.prisma.videoRoomParticipant.updateMany({
      where: {
        roomId,
        leftAt: null,
      },
      data: {
        leftAt: new Date(),
      },
    });

    return updatedRoom;
  }

  // Lấy danh sách video rooms đang ACTIVE
  async getActiveRooms(projectId?: number) {
    const rooms = await this.prisma.videoRoom.findMany({
      where: {
        status: 'ACTIVE',
        ...(projectId && { projectId }),
      },
      include: {
        project: {
          select: {
            id: true,
            title: true,
          },
        },
        participants: {
          where: {
            leftAt: null, // Chỉ lấy participants đang online
          },
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
      orderBy: {
        startedAt: 'desc',
      },
    });

    return rooms.map((room) => ({
      ...room,
      participants: room.participants.map((p) => ({
        ...p.user,
        joinedAt: p.joinedAt,
      })),
    }));
  }

  // Lấy thông tin chi tiết 1 room
  async getRoomById(roomId: number) {
    const room = await this.prisma.videoRoom.findUnique({
      where: { id: roomId },
      include: {
        project: {
          select: {
            id: true,
            title: true,
          },
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    if (!room) {
      throw new NotFoundException(`Video room với ID ${roomId} không tồn tại`);
    }

    return {
      ...room,
      participants: room.participants.map((p) => ({
        ...p.user,
        joinedAt: p.joinedAt,
        leftAt: p.leftAt,
      })),
    };
  }

  // Đánh dấu participant rời khỏi room
  async leaveRoom(roomId: number, userId: number) {
    const participant = await this.prisma.videoRoomParticipant.findUnique({
      where: {
        roomId_userId: {
          roomId,
          userId,
        },
      },
    });

    if (!participant) {
      throw new NotFoundException('Participant không tồn tại trong room');
    }

    await this.prisma.videoRoomParticipant.update({
      where: {
        roomId_userId: {
          roomId,
          userId,
        },
      },
      data: {
        leftAt: new Date(),
      },
    });

    return { success: true };
  }

  // Trả về thông tin cấu hình để phục vụ kiểm tra sức khỏe
  getHealthInfo() {
    return {
      url: this.livekitUrl,
      apiKey: this.livekitApiKey,
      apiSecret: this.livekitApiSecret,
    };
  }
}
