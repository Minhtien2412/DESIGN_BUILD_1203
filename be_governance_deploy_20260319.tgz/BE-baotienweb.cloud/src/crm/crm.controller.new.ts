import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    NotFoundException,
    Param,
    Post,
    Put,
    Query,
    UnauthorizedException,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import * as bcrypt from 'bcrypt';
import { JwtAuthGuard } from '../auth/guards';
import { getErrorMessage } from '../utils/error-helpers';
import { CrmService } from './crm.service';
import {
    ClientLoginDto,
    ClientRegisterDto,
    CrmCreateProjectDto,
    CrmCreateTaskDto,
    CrmCreateTicketDto,
} from './dto';

@ApiTags('CRM Integration')
@Controller({ path: 'crm', version: '1' })
export class CrmController {
  constructor(private readonly crmService: CrmService) {}

  // ==========================================
  // ROOT - API INFO
  // ==========================================
  @Get()
  @ApiOperation({ summary: 'Get CRM API information' })
  @ApiResponse({ status: 200, description: 'API info and available endpoints' })
  async getApiInfo() {
    return {
      name: 'BaoTienWeb CRM API',
      version: '2.0.0',
      status: 'active',
      idFormat: 'XX-NNNNN (8-char unique IDs)',
      endpoints: {
        dashboard: '/api/v1/crm/dashboard',
        staff: '/api/v1/crm/staff',
        clients: '/api/v1/crm/clients',
        projects: '/api/v1/crm/projects',
        tasks: '/api/v1/crm/tasks',
        invoices: '/api/v1/crm/invoices',
        tickets: '/api/v1/crm/tickets',
        users: '/api/v1/users/admin/list',
        search: '/api/v1/crm/search?q=...',
      },
      documentation: 'https://baotienweb.cloud/api/docs',
    };
  }

  // ==========================================
  // CLIENT PORTAL - AUTHENTICATION (No Auth Required)
  // ==========================================
  @Post('client/register')
  @ApiOperation({ summary: 'Register new CRM client' })
  @ApiBody({ type: ClientRegisterDto })
  @HttpCode(HttpStatus.CREATED)
  async registerClient(@Body() dto: ClientRegisterDto) {
    try {
      const hashedPassword = await bcrypt.hash(dto.password, 10);
      const result = await this.crmService.registerClient({
        ...dto,
        password: hashedPassword,
      });
      return {
        success: true,
        message: 'Client registered successfully',
        client: {
          userid: result.client.userid,
          company: result.client.company,
          email: result.contact.email,
          contactid: result.contact.id,
        },
      };
    } catch (error: unknown) {
      throw new UnauthorizedException(getErrorMessage(error));
    }
  }

  @Post('client/login')
  @ApiOperation({ summary: 'Login CRM client' })
  @ApiBody({ type: ClientLoginDto })
  @HttpCode(HttpStatus.OK)
  async loginClient(@Body() dto: ClientLoginDto) {
    try {
      const result = await this.crmService.loginClient(dto.email);
      if (!result) throw new UnauthorizedException('Invalid credentials');
      const passwordValid = result.contact.password
        ? await bcrypt.compare(dto.password, result.contact.password)
        : false;
      if (!passwordValid)
        throw new UnauthorizedException('Invalid credentials');
      return { success: true, client: result.client, contact: result.contact };
    } catch (error: unknown) {
      throw new UnauthorizedException('Invalid credentials');
    }
  }

  // CLIENT PORTAL - MY DATA
  @Get('client/my/projects/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getMyProjects(@Param('userid') userid: string) {
    return this.crmService.getProjectsByClient(userid);
  }

  @Get('client/my/invoices/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getMyInvoices(@Param('userid') userid: string) {
    return this.crmService.getInvoicesByClient(userid);
  }

  @Get('client/my/tickets/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getMyTickets(@Param('userid') userid: string) {
    return this.crmService.getTicketsByClient(userid);
  }

  // ==========================================
  // SEARCH (cross-entity)
  // ==========================================
  @Get('search')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Search across CRM entities' })
  @ApiQuery({ name: 'q', required: true, description: 'Search query' })
  async search(@Query('q') q: string) {
    return this.crmService.search(q || '');
  }

  // ==========================================
  // DASHBOARD
  // ==========================================
  @Get('dashboard')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get CRM dashboard statistics' })
  async getDashboard() {
    return this.crmService.getDashboard();
  }

  // ==========================================
  // STAFF (string IDs: NV-NNNNN)
  // ==========================================
  @Get('staff')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllStaff() {
    return this.crmService.getAllStaff();
  }

  @Get('staff/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'NV-00001' })
  async getStaffById(@Param('id') id: string) {
    const staff = await this.crmService.getStaffById(id);
    if (!staff) throw new NotFoundException(`Staff ${id} not found`);
    return staff;
  }

  // ==========================================
  // CLIENTS (string IDs: KH-NNNNN) - Full CRUD
  // ==========================================
  @Get('clients')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllClients() {
    return this.crmService.getAllClients();
  }

  @Get('clients/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'KH-00001' })
  async getClientById(@Param('id') id: string) {
    const client = await this.crmService.getClientById(id);
    if (!client) throw new NotFoundException(`Client ${id} not found`);
    return client;
  }

  @Put('clients/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'KH-00001' })
  async updateClient(@Param('id') id: string, @Body() data: any) {
    const client = await this.crmService.updateClient(id, data);
    if (!client) throw new NotFoundException(`Client ${id} not found`);
    return client;
  }

  @Delete('clients/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'KH-00001' })
  async deleteClient(@Param('id') id: string) {
    const deleted = await this.crmService.deleteClient(id);
    if (!deleted) throw new NotFoundException(`Client ${id} not found`);
    return { success: true, message: `Client ${id} deleted` };
  }

  @Get('clients/:id/contacts')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'KH-00001' })
  async getClientContacts(@Param('id') id: string) {
    return this.crmService.getClientContacts(id);
  }

  // ==========================================
  // PROJECTS (string IDs: DA-NNNNN) - Full CRUD
  // ==========================================
  @Get('projects')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllProjects() {
    return this.crmService.getAllProjects();
  }

  @Get('projects/active')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getActiveProjects() {
    return this.crmService.getActiveProjects();
  }

  @Get('projects/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'DA-00001' })
  async getProjectById(@Param('id') id: string) {
    const project = await this.crmService.getProjectById(id);
    if (!project) throw new NotFoundException(`Project ${id} not found`);
    return project;
  }

  @Post('projects')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiBody({ type: CrmCreateProjectDto })
  @HttpCode(HttpStatus.CREATED)
  async createProject(@Body() dto: CrmCreateProjectDto) {
    return this.crmService.createProject(dto);
  }

  @Put('projects/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'DA-00001' })
  async updateProject(@Param('id') id: string, @Body() data: any) {
    const project = await this.crmService.updateProject(id, data);
    if (!project) throw new NotFoundException(`Project ${id} not found`);
    return project;
  }

  @Put('projects/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'DA-00001' })
  async updateProjectStatus(
    @Param('id') id: string,
    @Body() data: { status?: number; progress?: number },
  ) {
    const project = await this.crmService.updateProjectStatus(
      id,
      data.status || 0,
    );
    if (!project) throw new NotFoundException(`Project ${id} not found`);
    return project;
  }

  @Delete('projects/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'DA-00001' })
  async deleteProject(@Param('id') id: string) {
    const deleted = await this.crmService.deleteProject(id);
    if (!deleted) throw new NotFoundException(`Project ${id} not found`);
    return { success: true, message: `Project ${id} deleted` };
  }

  @Get('projects/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'clientId', type: String, example: 'KH-00001' })
  async getProjectsByClient(@Param('clientId') clientId: string) {
    return this.crmService.getProjectsByClient(clientId);
  }

  // ==========================================
  // TASKS (string IDs: CV-NNNNN) - Full CRUD
  // ==========================================
  @Get('tasks')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllTasks() {
    return this.crmService.getAllTasks();
  }

  @Get('tasks/open')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getOpenTasks() {
    return this.crmService.getOpenTasks();
  }

  @Get('tasks/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'CV-00001' })
  async getTaskById(@Param('id') id: string) {
    const task = await this.crmService.getTaskById(id);
    if (!task) throw new NotFoundException(`Task ${id} not found`);
    return task;
  }

  @Post('tasks')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiBody({ type: CrmCreateTaskDto })
  @HttpCode(HttpStatus.CREATED)
  async createTask(@Body() dto: CrmCreateTaskDto) {
    return this.crmService.createTask(dto);
  }

  @Put('tasks/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'CV-00001' })
  async updateTask(@Param('id') id: string, @Body() data: any) {
    const task = await this.crmService.updateTask(id, data);
    if (!task) throw new NotFoundException(`Task ${id} not found`);
    return task;
  }

  @Put('tasks/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'CV-00001' })
  async updateTaskStatus(
    @Param('id') id: string,
    @Body() data: { status: number },
  ) {
    const task = await this.crmService.updateTaskStatus(id, data.status);
    if (!task) throw new NotFoundException(`Task ${id} not found`);
    return task;
  }

  @Delete('tasks/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'CV-00001' })
  async deleteTask(@Param('id') id: string) {
    const deleted = await this.crmService.deleteTask(id);
    if (!deleted) throw new NotFoundException(`Task ${id} not found`);
    return { success: true, message: `Task ${id} deleted` };
  }

  @Get('tasks/project/:projectId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'projectId', type: String, example: 'DA-00001' })
  async getTasksByProject(@Param('projectId') projectId: string) {
    return this.crmService.getTasksByProject(projectId);
  }

  // ==========================================
  // INVOICES (string IDs: HD-NNNNN) - Full CRUD
  // ==========================================
  @Get('invoices')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllInvoices() {
    return this.crmService.getAllInvoices();
  }

  @Get('invoices/unpaid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getUnpaidInvoices() {
    return this.crmService.getUnpaidInvoices();
  }

  @Get('invoices/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'HD-00001' })
  async getInvoiceById(@Param('id') id: string) {
    const inv = await this.crmService.getInvoiceById(id);
    if (!inv) throw new NotFoundException(`Invoice ${id} not found`);
    return inv;
  }

  @Put('invoices/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'HD-00001' })
  async updateInvoice(@Param('id') id: string, @Body() data: any) {
    const inv = await this.crmService.updateInvoice(id, data);
    if (!inv) throw new NotFoundException(`Invoice ${id} not found`);
    return inv;
  }

  @Get('invoices/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'clientId', type: String, example: 'KH-00001' })
  async getInvoicesByClient(@Param('clientId') clientId: string) {
    return this.crmService.getInvoicesByClient(clientId);
  }

  @Get('invoices/project/:projectId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'projectId', type: String, example: 'DA-00001' })
  async getInvoicesByProject(@Param('projectId') projectId: string) {
    return this.crmService.getInvoicesByProject(projectId);
  }

  // ==========================================
  // TICKETS (string IDs: TC-NNNNN) - Full CRUD
  // ==========================================
  @Get('tickets')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getAllTickets() {
    return this.crmService.getAllTickets();
  }

  @Get('tickets/open')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getOpenTickets() {
    return this.crmService.getOpenTickets();
  }

  @Get('tickets/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'TC-00001' })
  async getTicketById(@Param('id') id: string) {
    const ticket = await this.crmService.getTicketById(id);
    if (!ticket) throw new NotFoundException(`Ticket ${id} not found`);
    return ticket;
  }

  @Post('tickets')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiBody({ type: CrmCreateTicketDto })
  @HttpCode(HttpStatus.CREATED)
  async createTicket(@Body() dto: CrmCreateTicketDto) {
    return this.crmService.createTicket(dto);
  }

  @Put('tickets/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'TC-00001' })
  async updateTicket(@Param('id') id: string, @Body() data: any) {
    const ticket = await this.crmService.updateTicket(id, data);
    if (!ticket) throw new NotFoundException(`Ticket ${id} not found`);
    return ticket;
  }

  @Put('tickets/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'TC-00001' })
  async updateTicketStatus(
    @Param('id') id: string,
    @Body() data: { status: number },
  ) {
    const ticket = await this.crmService.updateTicketStatus(id, data.status);
    if (!ticket) throw new NotFoundException(`Ticket ${id} not found`);
    return ticket;
  }

  @Delete('tickets/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'id', type: String, example: 'TC-00001' })
  async deleteTicket(@Param('id') id: string) {
    const deleted = await this.crmService.deleteTicket(id);
    if (!deleted) throw new NotFoundException(`Ticket ${id} not found`);
    return { success: true, message: `Ticket ${id} deleted` };
  }

  @Get('tickets/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'clientId', type: String, example: 'KH-00001' })
  async getTicketsByClient(@Param('clientId') clientId: string) {
    return this.crmService.getTicketsByClient(clientId);
  }
}
