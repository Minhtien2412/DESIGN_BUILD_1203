import { Injectable, Logger } from '@nestjs/common';

// ==========================================
// ID GENERATOR - 8-char unique readable IDs
// Format: XX-NNNNN (2-letter prefix + dash + 5 digits)
// ==========================================
class IdGenerator {
  private counters: Record<string, number> = {};

  generate(prefix: string, startFrom = 1): string {
    if (!this.counters[prefix]) this.counters[prefix] = startFrom;
    const num = this.counters[prefix]++;
    return `${prefix}-${String(num).padStart(5, '0')}`;
  }

  setCounter(prefix: string, value: number) {
    this.counters[prefix] = value;
  }
}

const idGen = new IdGenerator();

// ==========================================
// MOCK DATA - Realistic Vietnamese construction/architecture CRM
// All IDs use 8-char format: XX-NNNNN
// ==========================================

// Initialize counters
idGen.setCounter('NV', 6); // Staff next = NV-00006
idGen.setCounter('KH', 9); // Clients next = KH-00009
idGen.setCounter('LH', 17); // Contacts next = LH-00017
idGen.setCounter('DA', 11); // Projects next = DA-00011
idGen.setCounter('CV', 13); // Tasks next = CV-00013
idGen.setCounter('HD', 12); // Invoices next = HD-00012
idGen.setCounter('TC', 9); // Tickets next = TC-00009
idGen.setCounter('ND', 11); // Users next = ND-00011

const MOCK_STAFF = [
  {
    id: 'NV-00001',
    staffid: 'NV-00001',
    email: 'admin@baotienweb.cloud',
    firstname: 'Nguyễn',
    lastname: 'Minh Tiến',
    phonenumber: '0901234567',
    admin: 1,
    profile_image: null,
    last_login: '2025-06-12T08:00:00Z',
    datecreated: '2024-01-15T00:00:00Z',
    active: 1,
    role: 'SUPER_ADMIN',
    department: 'Quản trị',
  },
  {
    id: 'NV-00002',
    staffid: 'NV-00002',
    email: 'kts.linh@baotienweb.cloud',
    firstname: 'Trần',
    lastname: 'Thùy Linh',
    phonenumber: '0912345678',
    admin: 0,
    profile_image: null,
    last_login: '2025-06-11T14:30:00Z',
    datecreated: '2024-03-01T00:00:00Z',
    active: 1,
    role: 'ARCHITECT',
    department: 'Thiết kế',
  },
  {
    id: 'NV-00003',
    staffid: 'NV-00003',
    email: 'ks.hoang@baotienweb.cloud',
    firstname: 'Lê',
    lastname: 'Văn Hoàng',
    phonenumber: '0923456789',
    admin: 0,
    profile_image: null,
    last_login: '2025-06-12T09:15:00Z',
    datecreated: '2024-02-10T00:00:00Z',
    active: 1,
    role: 'ENGINEER',
    department: 'Kỹ thuật',
  },
  {
    id: 'NV-00004',
    staffid: 'NV-00004',
    email: 'sale.mai@baotienweb.cloud',
    firstname: 'Phạm',
    lastname: 'Ngọc Mai',
    phonenumber: '0934567890',
    admin: 0,
    profile_image: null,
    last_login: '2025-06-10T16:00:00Z',
    datecreated: '2024-04-20T00:00:00Z',
    active: 1,
    role: 'STAFF',
    department: 'Kinh doanh',
  },
  {
    id: 'NV-00005',
    staffid: 'NV-00005',
    email: 'pm.duc@baotienweb.cloud',
    firstname: 'Võ',
    lastname: 'Quốc Đức',
    phonenumber: '0945678901',
    admin: 0,
    profile_image: null,
    last_login: '2025-06-12T07:45:00Z',
    datecreated: '2024-05-15T00:00:00Z',
    active: 1,
    role: 'ENGINEER',
    department: 'Quản lý dự án',
  },
];

const MOCK_CLIENTS = [
  {
    id: 'KH-00001',
    userid: 'KH-00001',
    company: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    phonenumber: '028-3822-1234',
    country: 237,
    city: 'TP. Hồ Chí Minh',
    address: '123 Nguyễn Huệ, Quận 1',
    website: 'phumy-invest.vn',
    active: 1,
    datecreated: '2024-06-01T00:00:00Z',
    vat: '0301234567',
    contactName: 'Ông Trần Văn Phú',
    contactEmail: 'phu.tran@phumy-invest.vn',
    totalProjects: 3,
    totalSpent: 8500000000,
    status: 'active',
  },
  {
    id: 'KH-00002',
    userid: 'KH-00002',
    company: 'Resort Bãi Dài Cam Ranh',
    phonenumber: '0258-3888-999',
    country: 237,
    city: 'Khánh Hòa',
    address: 'Bãi Dài, Cam Lâm',
    website: 'baidai-resort.vn',
    active: 1,
    datecreated: '2024-07-15T00:00:00Z',
    vat: '4201234568',
    contactName: 'Bà Nguyễn Thị Hoa',
    contactEmail: 'hoa@baidai-resort.vn',
    totalProjects: 1,
    totalSpent: 45000000000,
    status: 'active',
  },
  {
    id: 'KH-00003',
    userid: 'KH-00003',
    company: 'Saigon Pearl Residence',
    phonenumber: '028-3910-5555',
    country: 237,
    city: 'TP. Hồ Chí Minh',
    address: '92 Nguyễn Hữu Cảnh, Bình Thạnh',
    website: 'saigonpearl.vn',
    active: 1,
    datecreated: '2024-08-20T00:00:00Z',
    vat: '0309876543',
    contactName: 'Ông Lý Minh Tuấn',
    contactEmail: 'tuan.ly@saigonpearl.vn',
    totalProjects: 2,
    totalSpent: 12000000000,
    status: 'active',
  },
  {
    id: 'KH-00004',
    userid: 'KH-00004',
    company: 'Hoàng Anh Construction',
    phonenumber: '0236-3835-888',
    country: 237,
    city: 'Đà Nẵng',
    address: '50 Bạch Đằng, Hải Châu',
    website: 'hoanganh-construction.vn',
    active: 1,
    datecreated: '2024-05-10T00:00:00Z',
    vat: '0401112233',
    contactName: 'Ông Hoàng Anh Tuấn',
    contactEmail: 'tuan@hoanganh.vn',
    totalProjects: 2,
    totalSpent: 6500000000,
    status: 'active',
  },
  {
    id: 'KH-00005',
    userid: 'KH-00005',
    company: 'Đà Lạt Garden Villas',
    phonenumber: '0263-3822-666',
    country: 237,
    city: 'Lâm Đồng',
    address: '15 Trần Hưng Đạo, TP. Đà Lạt',
    website: 'dalat-garden.vn',
    active: 1,
    datecreated: '2024-09-05T00:00:00Z',
    vat: '5801234567',
    contactName: 'Bà Lê Thị Lan',
    contactEmail: 'lan@dalat-garden.vn',
    totalProjects: 1,
    totalSpent: 3500000000,
    status: 'active',
  },
  {
    id: 'KH-00006',
    userid: 'KH-00006',
    company: 'Vingroup - Chi nhánh Hà Nội',
    phonenumber: '024-3974-9999',
    country: 237,
    city: 'Hà Nội',
    address: '7 Nguyễn Chí Thanh, Ba Đình',
    website: 'vingroup.net',
    active: 1,
    datecreated: '2024-04-01T00:00:00Z',
    vat: '0100000001',
    contactName: 'Ông Phạm Đức Mạnh',
    contactEmail: 'manh.pham@vingroup.net',
    totalProjects: 4,
    totalSpent: 95000000000,
    status: 'active',
  },
  {
    id: 'KH-00007',
    userid: 'KH-00007',
    company: 'Novaland Development',
    phonenumber: '028-3827-7777',
    country: 237,
    city: 'TP. Hồ Chí Minh',
    address: '65 Nguyễn Du, Quận 1',
    website: 'novaland.com.vn',
    active: 0,
    datecreated: '2024-03-15T00:00:00Z',
    vat: '0301122334',
    contactName: 'Bà Trương Ngọc Ánh',
    contactEmail: 'anh.truong@novaland.vn',
    totalProjects: 1,
    totalSpent: 15000000000,
    status: 'inactive',
  },
  {
    id: 'KH-00008',
    userid: 'KH-00008',
    company: 'SunGroup Phú Quốc',
    phonenumber: '0297-3988-888',
    country: 237,
    city: 'Kiên Giang',
    address: 'Bãi Khem, An Thới, Phú Quốc',
    website: 'sungroup.com.vn',
    active: 1,
    datecreated: '2024-10-01T00:00:00Z',
    vat: '1701234567',
    contactName: 'Ông Đặng Minh Trường',
    contactEmail: 'truong@sungroup.vn',
    totalProjects: 2,
    totalSpent: 55000000000,
    status: 'active',
  },
];

const MOCK_CONTACTS = [
  {
    id: 'LH-00001',
    userid: 'KH-00001',
    firstname: 'Trần',
    lastname: 'Văn Phú',
    email: 'phu.tran@phumy-invest.vn',
    phonenumber: '028-3822-1234',
    title: 'Giám đốc',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00002',
    userid: 'KH-00001',
    firstname: 'Lê',
    lastname: 'Thị Hạnh',
    email: 'hanh.le@phumy-invest.vn',
    phonenumber: '028-3822-1235',
    title: 'Kế toán trưởng',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00003',
    userid: 'KH-00002',
    firstname: 'Nguyễn',
    lastname: 'Thị Hoa',
    email: 'hoa@baidai-resort.vn',
    phonenumber: '0258-3888-999',
    title: 'Chủ đầu tư',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00004',
    userid: 'KH-00003',
    firstname: 'Lý',
    lastname: 'Minh Tuấn',
    email: 'tuan.ly@saigonpearl.vn',
    phonenumber: '028-3910-5555',
    title: 'Phó Giám đốc',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00005',
    userid: 'KH-00004',
    firstname: 'Hoàng',
    lastname: 'Anh Tuấn',
    email: 'tuan@hoanganh.vn',
    phonenumber: '0236-3835-888',
    title: 'Giám đốc',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00006',
    userid: 'KH-00005',
    firstname: 'Lê',
    lastname: 'Thị Lan',
    email: 'lan@dalat-garden.vn',
    phonenumber: '0263-3822-666',
    title: 'Chủ đầu tư',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00007',
    userid: 'KH-00006',
    firstname: 'Phạm',
    lastname: 'Đức Mạnh',
    email: 'manh.pham@vingroup.net',
    phonenumber: '024-3974-9999',
    title: 'Giám đốc dự án',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00008',
    userid: 'KH-00006',
    firstname: 'Trịnh',
    lastname: 'Thu Hà',
    email: 'ha.trinh@vingroup.net',
    phonenumber: '024-3974-9998',
    title: 'Trưởng phòng Đầu tư',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00009',
    userid: 'KH-00007',
    firstname: 'Trương',
    lastname: 'Ngọc Ánh',
    email: 'anh.truong@novaland.vn',
    phonenumber: '028-3827-7777',
    title: 'Phó TGĐ',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00010',
    userid: 'KH-00008',
    firstname: 'Đặng',
    lastname: 'Minh Trường',
    email: 'truong@sungroup.vn',
    phonenumber: '0297-3988-888',
    title: 'CEO',
    is_primary: 1,
    active: 1,
  },
  {
    id: 'LH-00011',
    userid: 'KH-00001',
    firstname: 'Trần',
    lastname: 'Quốc Bảo',
    email: 'bao.tran@phumy-invest.vn',
    phonenumber: '028-3822-1236',
    title: 'Quản lý dự án',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00012',
    userid: 'KH-00003',
    firstname: 'Nguyễn',
    lastname: 'Thị Mai',
    email: 'mai.nguyen@saigonpearl.vn',
    phonenumber: '028-3910-5556',
    title: 'Kế toán',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00013',
    userid: 'KH-00004',
    firstname: 'Trần',
    lastname: 'Đức Anh',
    email: 'anh.tran@hoanganh.vn',
    phonenumber: '0236-3835-889',
    title: 'Kỹ sư trưởng',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00014',
    userid: 'KH-00008',
    firstname: 'Lê',
    lastname: 'Minh Hải',
    email: 'hai.le@sungroup.vn',
    phonenumber: '0297-3988-889',
    title: 'Giám sát công trình',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00015',
    userid: 'KH-00002',
    firstname: 'Phan',
    lastname: 'Văn Tài',
    email: 'tai.phan@baidai-resort.vn',
    phonenumber: '0258-3888-998',
    title: 'Quản lý Resort',
    is_primary: 0,
    active: 1,
  },
  {
    id: 'LH-00016',
    userid: 'KH-00005',
    firstname: 'Nguyễn',
    lastname: 'Hữu Tâm',
    email: 'tam.nguyen@dalat-garden.vn',
    phonenumber: '0263-3822-667',
    title: 'Kiến trúc sư',
    is_primary: 0,
    active: 1,
  },
];

const MOCK_PROJECTS = [
  {
    id: 'DA-00001',
    name: 'Villa Riviera - Quận 2',
    description:
      'Thiết kế và thi công biệt thự nghỉ dưỡng phong cách Địa Trung Hải, 3 tầng, hồ bơi vô cực.',
    status: 4,
    clientid: 'KH-00001',
    clientName: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    billing_type: 2,
    project_cost: 8500000000,
    start_date: '2024-06-15',
    deadline: '2025-06-15',
    project_created: '2024-06-01T00:00:00Z',
    progress_from_tasks: 65,
    staffAssigned: ['NV-00002', 'NV-00003', 'NV-00005'],
    category: 'Biệt thự',
    location: 'Quận 2, TP.HCM',
  },
  {
    id: 'DA-00002',
    name: 'Khu nghỉ dưỡng Bãi Dài',
    description:
      'Thiết kế tổng thể khu resort 5 sao, 120 phòng, 2 nhà hàng, spa, hồ bơi.',
    status: 4,
    clientid: 'KH-00002',
    clientName: 'Resort Bãi Dài Cam Ranh',
    billing_type: 1,
    project_cost: 45000000000,
    start_date: '2024-08-01',
    deadline: '2026-08-01',
    project_created: '2024-07-15T00:00:00Z',
    progress_from_tasks: 35,
    staffAssigned: ['NV-00001', 'NV-00002', 'NV-00003', 'NV-00005'],
    category: 'Resort',
    location: 'Cam Ranh, Khánh Hòa',
  },
  {
    id: 'DA-00003',
    name: 'Penthouse Saigon Pearl',
    description:
      'Thiết kế nội thất penthouse cao cấp tầng 32, diện tích 350m2.',
    status: 5,
    clientid: 'KH-00003',
    clientName: 'Saigon Pearl Residence',
    billing_type: 2,
    project_cost: 5500000000,
    start_date: '2024-09-01',
    deadline: '2025-03-01',
    project_created: '2024-08-20T00:00:00Z',
    progress_from_tasks: 100,
    staffAssigned: ['NV-00002', 'NV-00004'],
    category: 'Nội thất',
    location: 'Bình Thạnh, TP.HCM',
  },
  {
    id: 'DA-00004',
    name: 'Chung cư Hoàng Anh Tower',
    description:
      'Thiết kế kiến trúc chung cư 25 tầng, 200 căn hộ, tiện ích đầy đủ.',
    status: 4,
    clientid: 'KH-00004',
    clientName: 'Hoàng Anh Construction',
    billing_type: 1,
    project_cost: 35000000000,
    start_date: '2024-07-01',
    deadline: '2026-07-01',
    project_created: '2024-05-10T00:00:00Z',
    progress_from_tasks: 45,
    staffAssigned: ['NV-00003', 'NV-00005'],
    category: 'Chung cư',
    location: 'Hải Châu, Đà Nẵng',
  },
  {
    id: 'DA-00005',
    name: 'Khu biệt thự Đà Lạt Garden',
    description:
      'Quy hoạch và thiết kế 15 căn biệt thự phong cách châu Âu trên đồi thông.',
    status: 2,
    clientid: 'KH-00005',
    clientName: 'Đà Lạt Garden Villas',
    billing_type: 2,
    project_cost: 22000000000,
    start_date: '2025-01-01',
    deadline: '2026-06-01',
    project_created: '2024-09-05T00:00:00Z',
    progress_from_tasks: 10,
    staffAssigned: ['NV-00001', 'NV-00002'],
    category: 'Biệt thự',
    location: 'TP. Đà Lạt, Lâm Đồng',
  },
  {
    id: 'DA-00006',
    name: 'Vinhomes Grand Park - Phase 3',
    description:
      'Thiết kế tiện ích công cộng, cảnh quan và khu vui chơi Phase 3.',
    status: 4,
    clientid: 'KH-00006',
    clientName: 'Vingroup - Chi nhánh Hà Nội',
    billing_type: 1,
    project_cost: 65000000000,
    start_date: '2024-06-01',
    deadline: '2025-12-31',
    project_created: '2024-04-01T00:00:00Z',
    progress_from_tasks: 55,
    staffAssigned: ['NV-00001', 'NV-00003', 'NV-00005'],
    category: 'Khu đô thị',
    location: 'Quận 9, TP.HCM',
  },
  {
    id: 'DA-00007',
    name: 'Novaland Gallery Office',
    description: 'Thiết kế văn phòng/showroom cao cấp tại The Grand Manhattan.',
    status: 1,
    clientid: 'KH-00007',
    clientName: 'Novaland Development',
    billing_type: 2,
    project_cost: 15000000000,
    start_date: '2024-10-01',
    deadline: '2025-04-01',
    project_created: '2024-03-15T00:00:00Z',
    progress_from_tasks: 15,
    staffAssigned: ['NV-00002'],
    category: 'Văn phòng',
    location: 'Quận 1, TP.HCM',
  },
  {
    id: 'DA-00008',
    name: 'JW Marriott Phú Quốc',
    description: 'Thiết kế 50 biệt thự biển và khu spa cao cấp.',
    status: 4,
    clientid: 'KH-00008',
    clientName: 'SunGroup Phú Quốc',
    billing_type: 1,
    project_cost: 55000000000,
    start_date: '2024-11-01',
    deadline: '2026-11-01',
    project_created: '2024-10-01T00:00:00Z',
    progress_from_tasks: 25,
    staffAssigned: ['NV-00001', 'NV-00002', 'NV-00003'],
    category: 'Resort',
    location: 'Phú Quốc, Kiên Giang',
  },
  {
    id: 'DA-00009',
    name: 'Sky Garden Apartment',
    description: 'Thiết kế nội thất căn hộ duplex Sky Garden, 210m2.',
    status: 5,
    clientid: 'KH-00003',
    clientName: 'Saigon Pearl Residence',
    billing_type: 2,
    project_cost: 3200000000,
    start_date: '2024-05-01',
    deadline: '2024-11-01',
    project_created: '2024-04-15T00:00:00Z',
    progress_from_tasks: 100,
    staffAssigned: ['NV-00002', 'NV-00004'],
    category: 'Nội thất',
    location: 'Quận 7, TP.HCM',
  },
  {
    id: 'DA-00010',
    name: 'Eco Green Tower',
    description: 'Tư vấn thiết kế tòa tháp xanh 40 tầng, đạt chuẩn LEED.',
    status: 4,
    clientid: 'KH-00006',
    clientName: 'Vingroup - Chi nhánh Hà Nội',
    billing_type: 1,
    project_cost: 85000000000,
    start_date: '2024-12-01',
    deadline: '2027-06-01',
    project_created: '2024-11-01T00:00:00Z',
    progress_from_tasks: 12,
    staffAssigned: ['NV-00001', 'NV-00003'],
    category: 'Tòa nhà xanh',
    location: 'Long Biên, Hà Nội',
  },
];

const MOCK_TASKS = [
  {
    id: 'CV-00001',
    name: 'Khảo sát hiện trạng Villa Riviera',
    description: 'Khảo sát mặt bằng, đo đạc, chụp ảnh hiện trạng khu đất.',
    status: 5,
    rel_id: 'DA-00001',
    rel_type: 'project',
    projectName: 'Villa Riviera - Quận 2',
    priority: 2,
    startdate: '2024-06-15',
    duedate: '2024-07-01',
    datecreated: '2024-06-15T00:00:00Z',
    assignees: ['NV-00003'],
    assigneeNames: ['Lê Văn Hoàng'],
  },
  {
    id: 'CV-00002',
    name: 'Thiết kế concept Villa Riviera',
    description:
      'Phát triển 3 phương án concept thiết kế phong cách Địa Trung Hải.',
    status: 5,
    rel_id: 'DA-00001',
    rel_type: 'project',
    projectName: 'Villa Riviera - Quận 2',
    priority: 2,
    startdate: '2024-07-01',
    duedate: '2024-08-15',
    datecreated: '2024-07-01T00:00:00Z',
    assignees: ['NV-00002'],
    assigneeNames: ['Trần Thùy Linh'],
  },
  {
    id: 'CV-00003',
    name: 'Bản vẽ kỹ thuật Villa Riviera',
    description: 'Triển khai bản vẽ kỹ thuật chi tiết từ concept được duyệt.',
    status: 4,
    rel_id: 'DA-00001',
    rel_type: 'project',
    projectName: 'Villa Riviera - Quận 2',
    priority: 2,
    startdate: '2024-09-01',
    duedate: '2025-01-15',
    datecreated: '2024-09-01T00:00:00Z',
    assignees: ['NV-00002', 'NV-00003'],
    assigneeNames: ['Trần Thùy Linh', 'Lê Văn Hoàng'],
  },
  {
    id: 'CV-00004',
    name: 'Master Plan Resort Bãi Dài',
    description: 'Lập quy hoạch tổng thể khu resort 5ha.',
    status: 5,
    rel_id: 'DA-00002',
    rel_type: 'project',
    projectName: 'Khu nghỉ dưỡng Bãi Dài',
    priority: 1,
    startdate: '2024-08-01',
    duedate: '2024-10-01',
    datecreated: '2024-08-01T00:00:00Z',
    assignees: ['NV-00001', 'NV-00002'],
    assigneeNames: ['Nguyễn Minh Tiến', 'Trần Thùy Linh'],
  },
  {
    id: 'CV-00005',
    name: 'Thiết kế phòng khách sạn Bãi Dài',
    description: 'Thiết kế 4 mẫu phòng: Standard, Deluxe, Suite, Presidential.',
    status: 4,
    rel_id: 'DA-00002',
    rel_type: 'project',
    projectName: 'Khu nghỉ dưỡng Bãi Dài',
    priority: 2,
    startdate: '2024-10-15',
    duedate: '2025-02-01',
    datecreated: '2024-10-15T00:00:00Z',
    assignees: ['NV-00002'],
    assigneeNames: ['Trần Thùy Linh'],
  },
  {
    id: 'CV-00006',
    name: 'Render 3D Penthouse Saigon Pearl',
    description: 'Dựng hình 3D và render interior penthouse tầng 32.',
    status: 5,
    rel_id: 'DA-00003',
    rel_type: 'project',
    projectName: 'Penthouse Saigon Pearl',
    priority: 3,
    startdate: '2024-10-01',
    duedate: '2024-11-15',
    datecreated: '2024-10-01T00:00:00Z',
    assignees: ['NV-00002'],
    assigneeNames: ['Trần Thùy Linh'],
  },
  {
    id: 'CV-00007',
    name: 'Xin phép xây dựng Hoàng Anh Tower',
    description: 'Chuẩn bị hồ sơ và nộp xin giấy phép xây dựng.',
    status: 4,
    rel_id: 'DA-00004',
    rel_type: 'project',
    projectName: 'Chung cư Hoàng Anh Tower',
    priority: 1,
    startdate: '2024-07-15',
    duedate: '2024-12-31',
    datecreated: '2024-07-15T00:00:00Z',
    assignees: ['NV-00005'],
    assigneeNames: ['Võ Quốc Đức'],
  },
  {
    id: 'CV-00008',
    name: 'Thiết kế cảnh quan Vinhomes Phase 3',
    description: 'Thiết kế chi tiết khu cảnh quan, công viên và hồ bơi.',
    status: 4,
    rel_id: 'DA-00006',
    rel_type: 'project',
    projectName: 'Vinhomes Grand Park - Phase 3',
    priority: 2,
    startdate: '2024-09-01',
    duedate: '2025-03-01',
    datecreated: '2024-09-01T00:00:00Z',
    assignees: ['NV-00002', 'NV-00003'],
    assigneeNames: ['Trần Thùy Linh', 'Lê Văn Hoàng'],
  },
  {
    id: 'CV-00009',
    name: 'Survey mặt bằng JW Marriott',
    description: 'Khảo sát địa hình bãi biển và lập báo cáo đánh giá.',
    status: 5,
    rel_id: 'DA-00008',
    rel_type: 'project',
    projectName: 'JW Marriott Phú Quốc',
    priority: 1,
    startdate: '2024-11-01',
    duedate: '2024-12-01',
    datecreated: '2024-11-01T00:00:00Z',
    assignees: ['NV-00003', 'NV-00005'],
    assigneeNames: ['Lê Văn Hoàng', 'Võ Quốc Đức'],
  },
  {
    id: 'CV-00010',
    name: 'Concept Design JW Marriott Villas',
    description: 'Phát triển concept 5 mẫu biệt thự biển phong cách tropical.',
    status: 4,
    rel_id: 'DA-00008',
    rel_type: 'project',
    projectName: 'JW Marriott Phú Quốc',
    priority: 2,
    startdate: '2025-01-01',
    duedate: '2025-04-01',
    datecreated: '2025-01-01T00:00:00Z',
    assignees: ['NV-00001', 'NV-00002'],
    assigneeNames: ['Nguyễn Minh Tiến', 'Trần Thùy Linh'],
  },
  {
    id: 'CV-00011',
    name: 'Thiết kế MEP Eco Green Tower',
    description: 'Hệ thống cơ điện đạt chuẩn LEED cho tòa tháp xanh.',
    status: 2,
    rel_id: 'DA-00010',
    rel_type: 'project',
    projectName: 'Eco Green Tower',
    priority: 2,
    startdate: '2025-03-01',
    duedate: '2025-09-01',
    datecreated: '2025-02-01T00:00:00Z',
    assignees: ['NV-00003'],
    assigneeNames: ['Lê Văn Hoàng'],
  },
  {
    id: 'CV-00012',
    name: 'Báo cáo ĐTM Khu biệt thự Đà Lạt',
    description: 'Lập báo cáo Đánh giá Tác động Môi trường cho dự án.',
    status: 2,
    rel_id: 'DA-00005',
    rel_type: 'project',
    projectName: 'Khu biệt thự Đà Lạt Garden',
    priority: 1,
    startdate: '2025-01-15',
    duedate: '2025-04-15',
    datecreated: '2025-01-01T00:00:00Z',
    assignees: ['NV-00005'],
    assigneeNames: ['Võ Quốc Đức'],
  },
];

const MOCK_INVOICES = [
  {
    id: 'HD-00001',
    number: 'INV-2024-001',
    clientid: 'KH-00001',
    clientName: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    project_id: 'DA-00001',
    projectName: 'Villa Riviera - Quận 2',
    total: 2500000000,
    subtotal: 2272727273,
    tax: 227272727,
    status: 2,
    datecreated: '2024-07-01T00:00:00Z',
    duedate: '2024-08-01',
    date: '2024-07-01',
    currency: 1,
    items: [
      {
        description: 'Phí thiết kế concept (Đợt 1 - 30%)',
        qty: 1,
        rate: 2272727273,
        amount: 2272727273,
      },
    ],
  },
  {
    id: 'HD-00002',
    number: 'INV-2024-002',
    clientid: 'KH-00002',
    clientName: 'Resort Bãi Dài Cam Ranh',
    project_id: 'DA-00002',
    projectName: 'Khu nghỉ dưỡng Bãi Dài',
    total: 13500000000,
    subtotal: 12272727273,
    tax: 1227272727,
    status: 2,
    datecreated: '2024-09-01T00:00:00Z',
    duedate: '2024-10-01',
    date: '2024-09-01',
    currency: 1,
    items: [
      {
        description: 'Phí thiết kế Master Plan (Đợt 1 - 30%)',
        qty: 1,
        rate: 12272727273,
        amount: 12272727273,
      },
    ],
  },
  {
    id: 'HD-00003',
    number: 'INV-2024-003',
    clientid: 'KH-00003',
    clientName: 'Saigon Pearl Residence',
    project_id: 'DA-00003',
    projectName: 'Penthouse Saigon Pearl',
    total: 5500000000,
    subtotal: 5000000000,
    tax: 500000000,
    status: 2,
    datecreated: '2025-03-01T00:00:00Z',
    duedate: '2025-04-01',
    date: '2025-03-01',
    currency: 1,
    items: [
      {
        description: 'Thanh toán hoàn tất thiết kế nội thất Penthouse',
        qty: 1,
        rate: 5000000000,
        amount: 5000000000,
      },
    ],
  },
  {
    id: 'HD-00004',
    number: 'INV-2024-004',
    clientid: 'KH-00004',
    clientName: 'Hoàng Anh Construction',
    project_id: 'DA-00004',
    projectName: 'Chung cư Hoàng Anh Tower',
    total: 10500000000,
    subtotal: 9545454545,
    tax: 954545455,
    status: 3,
    datecreated: '2024-08-01T00:00:00Z',
    duedate: '2024-09-15',
    date: '2024-08-01',
    currency: 1,
    items: [
      {
        description: 'Phí thiết kế kiến trúc (Đợt 1 - 30%)',
        qty: 1,
        rate: 9545454545,
        amount: 9545454545,
      },
    ],
  },
  {
    id: 'HD-00005',
    number: 'INV-2024-005',
    clientid: 'KH-00006',
    clientName: 'Vingroup - Chi nhánh Hà Nội',
    project_id: 'DA-00006',
    projectName: 'Vinhomes Grand Park - Phase 3',
    total: 19500000000,
    subtotal: 17727272727,
    tax: 1772727273,
    status: 2,
    datecreated: '2024-07-01T00:00:00Z',
    duedate: '2024-08-01',
    date: '2024-07-01',
    currency: 1,
    items: [
      {
        description: 'Phí thiết kế cảnh quan và tiện ích (Đợt 1 - 30%)',
        qty: 1,
        rate: 17727272727,
        amount: 17727272727,
      },
    ],
  },
  {
    id: 'HD-00006',
    number: 'INV-2024-006',
    clientid: 'KH-00008',
    clientName: 'SunGroup Phú Quốc',
    project_id: 'DA-00008',
    projectName: 'JW Marriott Phú Quốc',
    total: 16500000000,
    subtotal: 15000000000,
    tax: 1500000000,
    status: 6,
    datecreated: '2024-12-01T00:00:00Z',
    duedate: '2025-01-15',
    date: '2024-12-01',
    currency: 1,
    items: [
      {
        description: 'Phí khảo sát và lập quy hoạch (Đợt 1 - 30%)',
        qty: 1,
        rate: 15000000000,
        amount: 15000000000,
      },
    ],
  },
  {
    id: 'HD-00007',
    number: 'INV-2024-007',
    clientid: 'KH-00005',
    clientName: 'Đà Lạt Garden Villas',
    project_id: 'DA-00005',
    projectName: 'Khu biệt thự Đà Lạt Garden',
    total: 6600000000,
    subtotal: 6000000000,
    tax: 600000000,
    status: 6,
    datecreated: '2024-10-01T00:00:00Z',
    duedate: '2024-11-15',
    date: '2024-10-01',
    currency: 1,
    items: [
      {
        description: 'Phí quy hoạch khu biệt thự (Đợt 1 - 30%)',
        qty: 1,
        rate: 6000000000,
        amount: 6000000000,
      },
    ],
  },
  {
    id: 'HD-00008',
    number: 'INV-2025-001',
    clientid: 'KH-00001',
    clientName: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    project_id: 'DA-00001',
    projectName: 'Villa Riviera - Quận 2',
    total: 2500000000,
    subtotal: 2272727273,
    tax: 227272727,
    status: 6,
    datecreated: '2025-01-15T00:00:00Z',
    duedate: '2025-02-15',
    date: '2025-01-15',
    currency: 1,
    items: [
      {
        description: 'Phí triển khai bản vẽ kỹ thuật (Đợt 2 - 30%)',
        qty: 1,
        rate: 2272727273,
        amount: 2272727273,
      },
    ],
  },
  {
    id: 'HD-00009',
    number: 'INV-2025-002',
    clientid: 'KH-00006',
    clientName: 'Vingroup - Chi nhánh Hà Nội',
    project_id: 'DA-00010',
    projectName: 'Eco Green Tower',
    total: 25500000000,
    subtotal: 23181818182,
    tax: 2318181818,
    status: 6,
    datecreated: '2025-01-01T00:00:00Z',
    duedate: '2025-02-01',
    date: '2025-01-01',
    currency: 1,
    items: [
      {
        description: 'Phí tư vấn thiết kế LEED (Đợt 1 - 30%)',
        qty: 1,
        rate: 23181818182,
        amount: 23181818182,
      },
    ],
  },
  {
    id: 'HD-00010',
    number: 'INV-2025-003',
    clientid: 'KH-00003',
    clientName: 'Saigon Pearl Residence',
    project_id: 'DA-00009',
    projectName: 'Sky Garden Apartment',
    total: 3200000000,
    subtotal: 2909090909,
    tax: 290909091,
    status: 2,
    datecreated: '2024-11-01T00:00:00Z',
    duedate: '2024-12-01',
    date: '2024-11-01',
    currency: 1,
    items: [
      {
        description: 'Thanh toán hoàn tất thiết kế nội thất duplex',
        qty: 1,
        rate: 2909090909,
        amount: 2909090909,
      },
    ],
  },
  {
    id: 'HD-00011',
    number: 'INV-2025-004',
    clientid: 'KH-00004',
    clientName: 'Hoàng Anh Construction',
    project_id: 'DA-00004',
    projectName: 'Chung cư Hoàng Anh Tower',
    total: 10500000000,
    subtotal: 9545454545,
    tax: 954545455,
    status: 6,
    datecreated: '2025-02-01T00:00:00Z',
    duedate: '2025-03-15',
    date: '2025-02-01',
    currency: 1,
    items: [
      {
        description: 'Phí thiết kế kỹ thuật MEP (Đợt 2 - 30%)',
        qty: 1,
        rate: 9545454545,
        amount: 9545454545,
      },
    ],
  },
];

const MOCK_TICKETS = [
  {
    id: 'TC-00001',
    ticketid: 'TC-00001',
    userid: 'KH-00001',
    clientName: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    subject: 'Yêu cầu chỉnh sửa mặt tiền Villa Riviera',
    message:
      'Khách hàng muốn thay đổi phong cách mặt tiền từ Mediterranean sang Modern Tropical.',
    status: 2,
    priority: 2,
    department: 'Thiết kế',
    date: '2025-01-10T08:30:00Z',
    lastreply: '2025-01-12T14:00:00Z',
    assignedTo: 'NV-00002',
    assigneeName: 'Trần Thùy Linh',
  },
  {
    id: 'TC-00002',
    ticketid: 'TC-00002',
    userid: 'KH-00002',
    clientName: 'Resort Bãi Dài Cam Ranh',
    subject: 'Cập nhật tiến độ xây dựng hàng tuần',
    message: 'Đề nghị cung cấp báo cáo tiến độ chi tiết mỗi tuần kèm hình ảnh.',
    status: 1,
    priority: 3,
    department: 'Quản lý dự án',
    date: '2025-01-15T10:00:00Z',
    lastreply: null,
    assignedTo: 'NV-00005',
    assigneeName: 'Võ Quốc Đức',
  },
  {
    id: 'TC-00003',
    ticketid: 'TC-00003',
    userid: 'KH-00004',
    clientName: 'Hoàng Anh Construction',
    subject: 'Vấn đề giấy phép xây dựng',
    message: 'Hồ sơ xin phép bị trả lại, thiếu báo cáo ĐTM.',
    status: 2,
    priority: 1,
    department: 'Pháp lý',
    date: '2025-01-20T09:00:00Z',
    lastreply: '2025-01-21T11:30:00Z',
    assignedTo: 'NV-00005',
    assigneeName: 'Võ Quốc Đức',
  },
  {
    id: 'TC-00004',
    ticketid: 'TC-00004',
    userid: 'KH-00006',
    clientName: 'Vingroup - Chi nhánh Hà Nội',
    subject: 'Thay đổi vật liệu cảnh quan Phase 3',
    message:
      'Đề xuất dùng đá granite thay cho đá marble cho khu vườn trung tâm.',
    status: 5,
    priority: 3,
    department: 'Thiết kế',
    date: '2024-12-01T08:00:00Z',
    lastreply: '2024-12-05T16:00:00Z',
    assignedTo: 'NV-00002',
    assigneeName: 'Trần Thùy Linh',
  },
  {
    id: 'TC-00005',
    ticketid: 'TC-00005',
    userid: 'KH-00008',
    clientName: 'SunGroup Phú Quốc',
    subject: 'Yêu cầu bổ sung hồ bơi riêng',
    message: 'Bổ sung hồ bơi infinity riêng cho 20 villa hạng Presidential.',
    status: 1,
    priority: 2,
    department: 'Thiết kế',
    date: '2025-02-01T10:30:00Z',
    lastreply: null,
    assignedTo: 'NV-00001',
    assigneeName: 'Nguyễn Minh Tiến',
  },
  {
    id: 'TC-00006',
    ticketid: 'TC-00006',
    userid: 'KH-00003',
    clientName: 'Saigon Pearl Residence',
    subject: 'Bảo hành thiết kế nội thất Penthouse',
    message: 'Phát hiện lỗi kỹ thuật hệ thống đèn LED ẩn trần thạch cao.',
    status: 2,
    priority: 2,
    department: 'Bảo hành',
    date: '2025-02-10T13:00:00Z',
    lastreply: '2025-02-12T09:00:00Z',
    assignedTo: 'NV-00003',
    assigneeName: 'Lê Văn Hoàng',
  },
  {
    id: 'TC-00007',
    ticketid: 'TC-00007',
    userid: 'KH-00005',
    clientName: 'Đà Lạt Garden Villas',
    subject: 'Xin bản vẽ để xin phép xây dựng',
    message: 'Cần bộ hồ sơ bản vẽ hoàn chỉnh để nộp Sở Xây dựng Lâm Đồng.',
    status: 1,
    priority: 1,
    department: 'Quản lý dự án',
    date: '2025-02-15T08:00:00Z',
    lastreply: null,
    assignedTo: 'NV-00005',
    assigneeName: 'Võ Quốc Đức',
  },
  {
    id: 'TC-00008',
    ticketid: 'TC-00008',
    userid: 'KH-00001',
    clientName: 'Công ty TNHH Đầu tư BĐS Phú Mỹ',
    subject: 'Thanh toán đợt 2 - Xin gia hạn',
    message:
      'Xin gia hạn thanh toán đợt 2 thêm 30 ngày do điều chỉnh ngân sách.',
    status: 5,
    priority: 3,
    department: 'Kế toán',
    date: '2025-01-25T11:00:00Z',
    lastreply: '2025-01-27T09:00:00Z',
    assignedTo: 'NV-00004',
    assigneeName: 'Phạm Ngọc Mai',
  },
];

// ==========================================
// MOCK USERS (system users for admin panel)
// ==========================================
const MOCK_USERS = [
  {
    id: 'ND-00001',
    name: 'Nguyễn Minh Tiến',
    email: 'admin@baotienweb.cloud',
    phone: '0901234567',
    role: 'SUPER_ADMIN',
    isActive: true,
    createdAt: '2024-01-15T00:00:00Z',
    lastLogin: '2026-03-04T08:00:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00002',
    name: 'Trần Thùy Linh',
    email: 'kts.linh@baotienweb.cloud',
    phone: '0912345678',
    role: 'ARCHITECT',
    isActive: true,
    createdAt: '2024-03-01T00:00:00Z',
    lastLogin: '2026-03-03T14:30:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00003',
    name: 'Lê Văn Hoàng',
    email: 'ks.hoang@baotienweb.cloud',
    phone: '0923456789',
    role: 'ENGINEER',
    isActive: true,
    createdAt: '2024-02-10T00:00:00Z',
    lastLogin: '2026-03-04T09:15:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00004',
    name: 'Phạm Ngọc Mai',
    email: 'sale.mai@baotienweb.cloud',
    phone: '0934567890',
    role: 'STAFF',
    isActive: true,
    createdAt: '2024-04-20T00:00:00Z',
    lastLogin: '2026-03-02T16:00:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00005',
    name: 'Võ Quốc Đức',
    email: 'pm.duc@baotienweb.cloud',
    phone: '0945678901',
    role: 'ENGINEER',
    isActive: true,
    createdAt: '2024-05-15T00:00:00Z',
    lastLogin: '2026-03-04T07:45:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00006',
    name: 'Trần Văn Phú',
    email: 'phu.tran@phumy-invest.vn',
    phone: '028-3822-1234',
    role: 'CLIENT',
    isActive: true,
    createdAt: '2024-06-01T00:00:00Z',
    lastLogin: '2026-02-28T10:00:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00007',
    name: 'Nguyễn Thị Hoa',
    email: 'hoa@baidai-resort.vn',
    phone: '0258-3888-999',
    role: 'CLIENT',
    isActive: true,
    createdAt: '2024-07-15T00:00:00Z',
    lastLogin: '2026-03-01T09:00:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00008',
    name: 'Hoàng Anh Tuấn',
    email: 'tuan@hoanganh.vn',
    phone: '0236-3835-888',
    role: 'CONTRACTOR',
    isActive: true,
    createdAt: '2024-05-10T00:00:00Z',
    lastLogin: '2026-03-03T11:00:00Z',
    avatar: null,
    banReason: null,
  },
  {
    id: 'ND-00009',
    name: 'Trương Ngọc Ánh',
    email: 'anh.truong@novaland.vn',
    phone: '028-3827-7777',
    role: 'CLIENT',
    isActive: false,
    createdAt: '2024-03-15T00:00:00Z',
    lastLogin: '2025-12-01T16:00:00Z',
    avatar: null,
    banReason: 'Tài khoản tạm khóa do dự án bị hủy',
  },
  {
    id: 'ND-00010',
    name: 'Đặng Minh Trường',
    email: 'truong@sungroup.vn',
    phone: '0297-3988-888',
    role: 'CLIENT',
    isActive: true,
    createdAt: '2024-10-01T00:00:00Z',
    lastLogin: '2026-03-04T08:30:00Z',
    avatar: null,
    banReason: null,
  },
];

@Injectable()
export class CrmService {
  private readonly logger = new Logger(CrmService.name);
  private clients = [...MOCK_CLIENTS];
  private contacts: Array<
    (typeof MOCK_CONTACTS)[number] & { password?: string }
  > = [...MOCK_CONTACTS];
  private projects = [...MOCK_PROJECTS];
  private tasks = [...MOCK_TASKS];
  private invoices = [...MOCK_INVOICES];
  private tickets = [...MOCK_TICKETS];
  private staff = [...MOCK_STAFF];
  private users = [...MOCK_USERS];

  async onModuleInit() {
    this.logger.log('CRM Service initialized with mock data (8-char IDs)');
    this.logger.log(
      `  Clients: ${this.clients.length}, Projects: ${this.projects.length}, Tasks: ${this.tasks.length}`,
    );
    this.logger.log(
      `  Invoices: ${this.invoices.length}, Tickets: ${this.tickets.length}, Staff: ${this.staff.length}, Users: ${this.users.length}`,
    );
  }

  generateId(type: string): string {
    const prefixMap: Record<string, string> = {
      client: 'KH',
      project: 'DA',
      task: 'CV',
      invoice: 'HD',
      ticket: 'TC',
      staff: 'NV',
      user: 'ND',
      contact: 'LH',
    };
    return idGen.generate(prefixMap[type] || 'XX');
  }

  // ==========================================
  // DASHBOARD
  // ==========================================
  async getDashboard() {
    const activeProjects = this.projects.filter((p) => p.status === 4).length;
    const openTasks = this.tasks.filter((t) =>
      [1, 2, 4].includes(t.status),
    ).length;
    const unpaidInvs = this.invoices.filter((inv) =>
      [1, 6].includes(inv.status),
    );
    const openTickets = this.tickets.filter((t) =>
      [1, 2].includes(t.status),
    ).length;
    const paidInvs = this.invoices.filter((inv) => inv.status === 2);
    return {
      totalClients: this.clients.length,
      activeProjects,
      openTasks,
      unpaidInvoices: unpaidInvs.length,
      openTickets,
      totalStaff: this.staff.length,
      totalUsers: this.users.length,
      totalRevenue: paidInvs.reduce((s, i) => s + i.total, 0),
      pendingRevenue: unpaidInvs.reduce((s, i) => s + i.total, 0),
      recentProjects: this.projects.slice(0, 5),
      recentTickets: this.tickets.slice(0, 5),
      projectsByStatus: {
        notStarted: this.projects.filter((p) => p.status === 2).length,
        inProgress: activeProjects,
        onHold: this.projects.filter((p) => p.status === 3).length,
        finished: this.projects.filter((p) => p.status === 5).length,
        cancelled: this.projects.filter((p) => p.status === 1).length,
      },
      idFormat: 'XX-NNNNN',
      idPrefixes: {
        KH: 'Khách hàng',
        DA: 'Dự án',
        CV: 'Công việc',
        HD: 'Hóa đơn',
        TC: 'Ticket',
        NV: 'Nhân viên',
        ND: 'Người dùng',
        LH: 'Liên hệ',
      },
    };
  }

  // STAFF
  async getAllStaff() {
    return [...this.staff].sort(
      (a, b) =>
        new Date(b.datecreated).getTime() - new Date(a.datecreated).getTime(),
    );
  }
  async getStaffById(id: string) {
    return this.staff.find((s) => s.id === id || s.staffid === id) || null;
  }

  // CLIENTS
  async getAllClients() {
    return [...this.clients].sort(
      (a, b) =>
        new Date(b.datecreated).getTime() - new Date(a.datecreated).getTime(),
    );
  }
  async getClientById(id: string) {
    const client = this.clients.find((c) => c.id === id || c.userid === id);
    if (!client) return null;
    const contacts = this.contacts.filter((ct) => ct.userid === client.id);
    const projects = this.projects.filter((p) => p.clientid === client.id);
    const invoices = this.invoices.filter((inv) => inv.clientid === client.id);
    const tickets = this.tickets.filter((t) => t.userid === client.id);
    return {
      ...client,
      contacts,
      projects,
      invoices,
      tickets,
      summary: {
        totalProjects: projects.length,
        activeProjects: projects.filter((p) => p.status === 4).length,
        totalInvoiced: invoices.reduce((s, i) => s + i.total, 0),
        totalPaid: invoices
          .filter((i) => i.status === 2)
          .reduce((s, i) => s + i.total, 0),
        openTickets: tickets.filter((t) => [1, 2].includes(t.status)).length,
      },
    };
  }
  async updateClient(id: string, data: any) {
    const idx = this.clients.findIndex((c) => c.id === id || c.userid === id);
    if (idx === -1) return null;
    this.clients[idx] = {
      ...this.clients[idx],
      ...data,
      id: this.clients[idx].id,
      userid: this.clients[idx].userid,
    };
    return this.clients[idx];
  }
  async deleteClient(id: string) {
    const idx = this.clients.findIndex((c) => c.id === id || c.userid === id);
    if (idx === -1) return false;
    this.clients.splice(idx, 1);
    return true;
  }
  async getClientContacts(id: string) {
    return this.contacts.filter((c) => c.userid === id && c.active === 1);
  }
  async getPrimaryContact(id: string) {
    return (
      this.contacts.find(
        (c) => c.userid === id && c.is_primary === 1 && c.active === 1,
      ) || null
    );
  }

  // PROJECTS
  async getAllProjects() {
    return [...this.projects].sort(
      (a, b) =>
        new Date(b.project_created).getTime() -
        new Date(a.project_created).getTime(),
    );
  }
  async getActiveProjects() {
    return this.projects.filter((p) => p.status === 4);
  }
  async getProjectById(id: string) {
    const project = this.projects.find((p) => p.id === id);
    if (!project) return null;
    const tasks = this.tasks.filter((t) => t.rel_id === project.id);
    const invoices = this.invoices.filter(
      (inv) => inv.project_id === project.id,
    );
    const client = this.clients.find((c) => c.id === project.clientid);
    return {
      ...project,
      tasks,
      invoices,
      client: client || null,
      summary: {
        totalTasks: tasks.length,
        completedTasks: tasks.filter((t) => t.status === 5).length,
        totalInvoiced: invoices.reduce((s, i) => s + i.total, 0),
        totalPaid: invoices
          .filter((i) => i.status === 2)
          .reduce((s, i) => s + i.total, 0),
      },
    };
  }
  async getProjectsByClient(clientId: string) {
    return this.projects.filter((p) => p.clientid === clientId);
  }
  async createProject(data: any) {
    const newId = this.generateId('project');
    const project = {
      id: newId,
      name: data.name,
      description: data.description || '',
      status: 2,
      clientid: data.clientid || data.clientId,
      clientName: data.clientName || '',
      billing_type: data.billing_type || 2,
      project_cost: data.project_cost || 0,
      start_date: data.start_date || new Date().toISOString().split('T')[0],
      deadline: data.deadline || '',
      project_created: new Date().toISOString(),
      progress_from_tasks: 0,
      staffAssigned: data.staffAssigned || [],
      category: data.category || '',
      location: data.location || '',
    };
    this.projects.push(project);
    return project;
  }
  async updateProjectStatus(id: string, status: number) {
    const p = this.projects.find((p) => p.id === id);
    if (!p) return null;
    p.status = status;
    return p;
  }
  async updateProject(id: string, data: any) {
    const idx = this.projects.findIndex((p) => p.id === id);
    if (idx === -1) return null;
    this.projects[idx] = {
      ...this.projects[idx],
      ...data,
      id: this.projects[idx].id,
    };
    return this.projects[idx];
  }
  async deleteProject(id: string) {
    const idx = this.projects.findIndex((p) => p.id === id);
    if (idx === -1) return false;
    this.projects.splice(idx, 1);
    return true;
  }

  // TASKS
  async getAllTasks() {
    return [...this.tasks].sort(
      (a, b) =>
        new Date(b.datecreated).getTime() - new Date(a.datecreated).getTime(),
    );
  }
  async getOpenTasks() {
    return this.tasks.filter((t) => [1, 2, 4].includes(t.status));
  }
  async getTaskById(id: string) {
    const task = this.tasks.find((t) => t.id === id);
    if (!task) return null;
    const project = this.projects.find((p) => p.id === task.rel_id);
    return { ...task, project: project || null };
  }
  async getTasksByProject(projectId: string) {
    return this.tasks.filter((t) => t.rel_id === projectId);
  }
  async createTask(data: any) {
    const newId = this.generateId('task');
    const task = {
      id: newId,
      name: data.name,
      description: data.description || '',
      status: 2,
      rel_id: data.rel_id || data.projectId,
      rel_type: 'project',
      projectName: data.projectName || '',
      priority: data.priority || 3,
      startdate: data.startdate || new Date().toISOString().split('T')[0],
      duedate: data.duedate || '',
      datecreated: new Date().toISOString(),
      assignees: data.assignees || [],
      assigneeNames: data.assigneeNames || [],
    };
    this.tasks.push(task);
    return task;
  }
  async updateTaskStatus(id: string, status: number) {
    const t = this.tasks.find((t) => t.id === id);
    if (!t) return null;
    t.status = status;
    return t;
  }
  async updateTask(id: string, data: any) {
    const idx = this.tasks.findIndex((t) => t.id === id);
    if (idx === -1) return null;
    this.tasks[idx] = { ...this.tasks[idx], ...data, id: this.tasks[idx].id };
    return this.tasks[idx];
  }
  async deleteTask(id: string) {
    const idx = this.tasks.findIndex((t) => t.id === id);
    if (idx === -1) return false;
    this.tasks.splice(idx, 1);
    return true;
  }

  // INVOICES
  async getAllInvoices() {
    return [...this.invoices].sort(
      (a, b) =>
        new Date(b.datecreated).getTime() - new Date(a.datecreated).getTime(),
    );
  }
  async getUnpaidInvoices() {
    return this.invoices.filter((inv) => [1, 6].includes(inv.status));
  }
  async getInvoiceById(id: string) {
    const inv = this.invoices.find((i) => i.id === id);
    if (!inv) return null;
    const client = this.clients.find((c) => c.id === inv.clientid);
    const project = this.projects.find((p) => p.id === inv.project_id);
    return { ...inv, client: client || null, project: project || null };
  }
  async getInvoicesByClient(clientId: string) {
    return this.invoices.filter((inv) => inv.clientid === clientId);
  }
  async getInvoicesByProject(projectId: string) {
    return this.invoices.filter((inv) => inv.project_id === projectId);
  }
  async updateInvoice(id: string, data: any) {
    const idx = this.invoices.findIndex((i) => i.id === id);
    if (idx === -1) return null;
    this.invoices[idx] = {
      ...this.invoices[idx],
      ...data,
      id: this.invoices[idx].id,
    };
    return this.invoices[idx];
  }

  // TICKETS
  async getAllTickets() {
    return [...this.tickets].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
    );
  }
  async getOpenTickets() {
    return this.tickets.filter((t) => [1, 2].includes(t.status));
  }
  async getTicketById(id: string) {
    const ticket = this.tickets.find((t) => t.id === id || t.ticketid === id);
    if (!ticket) return null;
    const client = this.clients.find((c) => c.id === ticket.userid);
    return { ...ticket, client: client || null };
  }
  async getTicketsByClient(clientId: string) {
    return this.tickets.filter((t) => t.userid === clientId);
  }
  async createTicket(data: any) {
    const newId = this.generateId('ticket');
    const ticket = {
      id: newId,
      ticketid: newId,
      userid: data.userid || data.clientId,
      clientName: data.clientName || '',
      subject: data.subject,
      message: data.message || '',
      status: 1,
      priority: data.priority || 3,
      department: data.department || 'Hỗ trợ',
      date: new Date().toISOString(),
      lastreply: null,
      assignedTo: data.assignedTo || null,
      assigneeName: data.assigneeName || null,
    };
    this.tickets.push(ticket);
    return ticket;
  }
  async updateTicketStatus(id: string, status: number) {
    const t = this.tickets.find((t) => t.id === id || t.ticketid === id);
    if (!t) return null;
    t.status = status;
    return t;
  }
  async updateTicket(id: string, data: any) {
    const idx = this.tickets.findIndex((t) => t.id === id || t.ticketid === id);
    if (idx === -1) return null;
    this.tickets[idx] = {
      ...this.tickets[idx],
      ...data,
      id: this.tickets[idx].id,
      ticketid: this.tickets[idx].ticketid,
    };
    return this.tickets[idx];
  }
  async deleteTicket(id: string) {
    const idx = this.tickets.findIndex((t) => t.id === id || t.ticketid === id);
    if (idx === -1) return false;
    this.tickets.splice(idx, 1);
    return true;
  }

  // USERS (system user management for admin panel)
  async getAllUsers(limit = 50) {
    return { users: this.users.slice(0, limit), total: this.users.length };
  }
  async getUserById(id: string) {
    return this.users.find((u) => u.id === id) || null;
  }
  async updateUser(id: string, data: any) {
    const idx = this.users.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    this.users[idx] = { ...this.users[idx], ...data, id: this.users[idx].id };
    return this.users[idx];
  }
  async updateUserRole(id: string, role: string) {
    const u = this.users.find((u) => u.id === id);
    if (!u) return null;
    u.role = role;
    return u;
  }
  async toggleUserBan(id: string, ban: boolean, reason?: string) {
    const u = this.users.find((u) => u.id === id);
    if (!u) return null;
    u.isActive = !ban;
    u.banReason = ban ? reason || null : null;
    return u;
  }
  async deleteUser(id: string) {
    const idx = this.users.findIndex((u) => u.id === id);
    if (idx === -1) return false;
    this.users.splice(idx, 1);
    return true;
  }
  async createUser(data: any) {
    const newId = this.generateId('user');
    const user = {
      id: newId,
      name: data.name || '',
      email: data.email,
      phone: data.phone || '',
      role: data.role || 'CLIENT',
      isActive: true,
      createdAt: new Date().toISOString(),
      lastLogin: null as string | null,
      avatar: null as string | null,
      banReason: null as string | null,
    };
    this.users.push(user);
    return user;
  }

  // CLIENT PORTAL
  async registerClient(dto: any) {
    const newClientId = this.generateId('client');
    const newContactId = this.generateId('contact');
    const client = {
      id: newClientId,
      userid: newClientId,
      company: dto.company,
      phonenumber: dto.phone || '',
      country: 237,
      city: '',
      address: dto.address || '',
      website: '',
      active: 1,
      datecreated: new Date().toISOString(),
      vat: '',
      contactName: dto.name || '',
      contactEmail: dto.email,
      totalProjects: 0,
      totalSpent: 0,
      status: 'active' as const,
    };
    const contact = {
      id: newContactId,
      userid: newClientId,
      firstname: (dto.name || '').split(' ')[0],
      lastname: (dto.name || '').split(' ').slice(1).join(' '),
      email: dto.email,
      phonenumber: dto.phone || '',
      title: dto.title || '',
      password: dto.password || '',
      is_primary: 1,
      active: 1,
    };
    this.clients.push(client);
    this.contacts.push(contact);
    return { client, contact };
  }
  async loginClient(email: string) {
    const contact = this.contacts.find((c) => c.email === email);
    if (!contact) return null;
    const client = this.clients.find((c) => c.id === contact.userid);
    return client ? { contact, client } : null;
  }

  // SEARCH
  async search(query: string) {
    const q = query.toLowerCase();
    return {
      clients: this.clients
        .filter(
          (c) =>
            c.company.toLowerCase().includes(q) ||
            c.id.toLowerCase().includes(q),
        )
        .slice(0, 5),
      projects: this.projects
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q),
        )
        .slice(0, 5),
      tasks: this.tasks
        .filter(
          (t) =>
            t.name.toLowerCase().includes(q) || t.id.toLowerCase().includes(q),
        )
        .slice(0, 5),
      invoices: this.invoices
        .filter(
          (inv) =>
            inv.number.toLowerCase().includes(q) ||
            inv.id.toLowerCase().includes(q),
        )
        .slice(0, 5),
      tickets: this.tickets
        .filter(
          (t) =>
            t.subject.toLowerCase().includes(q) ||
            t.id.toLowerCase().includes(q),
        )
        .slice(0, 5),
    };
  }
}
