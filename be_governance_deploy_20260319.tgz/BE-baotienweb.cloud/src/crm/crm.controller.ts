import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    UnauthorizedException,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { getErrorMessage } from '../utils/error-helpers';
import { CrmService } from './crm.service';

import * as bcrypt from 'bcrypt';
import { JwtAuthGuard } from '../auth/guards';
import {
    ClientLoginDto,
    ClientRegisterDto,
    CrmCreateProjectDto,
    CrmCreateTaskDto,
    CrmCreateTicketDto,
} from './dto';

@ApiTags('CRM Integration')
@Controller({ path: 'crm', version: '1' })
export class CrmController {
  constructor(private readonly crmService: CrmService) {}

  // ==========================================
  // ROOT - API INFO
  // ==========================================
  @Get()
  @ApiOperation({ summary: 'Get CRM API information' })
  @ApiResponse({ status: 200, description: 'API info and available endpoints' })
  async getApiInfo() {
    return {
      name: 'Perfex CRM Integration API',
      version: '1.0.0',
      status: 'active',
      database: 'MySQL - Perfex CRM',
      endpoints: {
        dashboard: '/api/v1/crm/dashboard',
        staff: '/api/v1/crm/staff',
        clients: '/api/v1/crm/clients',
        projects: '/api/v1/crm/projects',
        tasks: '/api/v1/crm/tasks',
        invoices: '/api/v1/crm/invoices',
        tickets: '/api/v1/crm/tickets',
      },
      documentation: 'https://baotienweb.cloud/api/docs',
    };
  }

  // ==========================================
  // CLIENT PORTAL - AUTHENTICATION (No Auth Required)
  // ==========================================

  @Post('client/register')
  @ApiOperation({ summary: 'Register new CRM client (for mobile app)' })
  @ApiBody({ type: ClientRegisterDto })
  @ApiResponse({ status: 201, description: 'Client registered successfully' })
  @ApiResponse({ status: 400, description: 'Email already exists' })
  @HttpCode(HttpStatus.CREATED)
  async registerClient(@Body() dto: ClientRegisterDto) {
    try {
      // Hash password
      const hashedPassword = await bcrypt.hash(dto.password, 10);

      const result = await this.crmService.registerClient({
        ...dto,
        password: hashedPassword,
      });

      return {
        success: true,
        message: 'Client registered successfully',
        client: {
          userid: result.client.userid,
          company: result.client.company,
          email: result.contact.email,
          contactid: result.contact.id,
        },
      };
    } catch (error: unknown) {
      throw new UnauthorizedException(getErrorMessage(error));
    }
  }

  @Post('client/login')
  @ApiOperation({ summary: 'Login CRM client (for mobile app)' })
  @ApiBody({ type: ClientLoginDto })
  @ApiResponse({ status: 200, description: 'Login successful' })
  @ApiResponse({ status: 401, description: 'Invalid credentials' })
  @HttpCode(HttpStatus.OK)
  async loginClient(@Body() dto: ClientLoginDto) {
    try {
      const result = await this.crmService.loginClient(dto.email);
      if (!result) {
        throw new UnauthorizedException('Invalid credentials');
      }

      const passwordValid = result.contact.password
        ? await bcrypt.compare(dto.password, result.contact.password)
        : false;
      if (!passwordValid) {
        throw new UnauthorizedException('Invalid credentials');
      }

      return {
        success: true,
        client: {
          contactid: result.contact.id,
          userid: result.client.userid,
          email: result.contact.email,
          firstname: result.contact.firstname || '',
          lastname: result.contact.lastname || '',
          company: result.client.company,
        },
      };
    } catch (error: unknown) {
      throw new UnauthorizedException('Invalid credentials');
    }
  }

  // ==========================================
  // CLIENT PORTAL - MY DATA (Requires Auth)
  // ==========================================

  @Get('client/my/projects/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get my projects (for logged-in client)' })
  @ApiParam({ name: 'userid', type: Number })
  @ApiResponse({ status: 200, description: 'List of client projects' })
  async getMyProjects(@Param('userid', ParseIntPipe) userid: number) {
    return this.crmService.getProjectsByClient(String(userid));
  }

  @Get('client/my/invoices/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get my invoices (for logged-in client)' })
  @ApiParam({ name: 'userid', type: Number })
  @ApiResponse({ status: 200, description: 'List of client invoices' })
  async getMyInvoices(@Param('userid', ParseIntPipe) userid: number) {
    return this.crmService.getInvoicesByClient(String(userid));
  }

  @Get('client/my/tickets/:userid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get my tickets (for logged-in client)' })
  @ApiParam({ name: 'userid', type: Number })
  @ApiResponse({ status: 200, description: 'List of client tickets' })
  async getMyTickets(@Param('userid', ParseIntPipe) userid: number) {
    return this.crmService.getTicketsByClient(String(userid));
  }

  // ==========================================
  // WRITE OPERATIONS - PROJECTS
  // ==========================================

  @Post('projects')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create new project' })
  @ApiBody({ type: CrmCreateProjectDto })
  @ApiResponse({ status: 201, description: 'Project created successfully' })
  @HttpCode(HttpStatus.CREATED)
  async createProject(@Body() dto: CrmCreateProjectDto) {
    return this.crmService.createProject(dto);
  }

  @Put('projects/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update project status' })
  @ApiParam({ name: 'id', type: Number })
  @ApiBody({
    schema: {
      properties: {
        status: { type: 'number', example: 1 },
        progress: { type: 'number', example: 50 },
      },
    },
  })
  @ApiResponse({ status: 200, description: 'Project updated successfully' })
  async updateProjectStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() data: { status?: number; progress?: number },
  ) {
    return this.crmService.updateProject(String(id), data);
  }

  // ==========================================
  // WRITE OPERATIONS - TASKS
  // ==========================================

  @Post('tasks')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create new task' })
  @ApiBody({ type: CrmCreateTaskDto })
  @ApiResponse({ status: 201, description: 'Task created successfully' })
  @HttpCode(HttpStatus.CREATED)
  async createTask(@Body() dto: CrmCreateTaskDto) {
    return this.crmService.createTask(dto);
  }

  @Put('tasks/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update task status' })
  @ApiParam({ name: 'id', type: Number })
  @ApiBody({
    schema: {
      properties: {
        status: { type: 'number', example: 4 },
      },
    },
  })
  @ApiResponse({ status: 200, description: 'Task updated successfully' })
  async updateTaskStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() data: { status: number },
  ) {
    return this.crmService.updateTask(String(id), data);
  }

  // ==========================================
  // WRITE OPERATIONS - TICKETS
  // ==========================================

  @Post('tickets')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create new support ticket' })
  @ApiBody({ type: CrmCreateTicketDto })
  @ApiResponse({ status: 201, description: 'Ticket created successfully' })
  @HttpCode(HttpStatus.CREATED)
  async createTicket(@Body() dto: CrmCreateTicketDto) {
    return this.crmService.createTicket(dto);
  }

  @Put('tickets/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update ticket status' })
  @ApiParam({ name: 'id', type: Number })
  @ApiBody({
    schema: {
      properties: {
        status: { type: 'number', example: 5 },
      },
    },
  })
  @ApiResponse({ status: 200, description: 'Ticket updated successfully' })
  async updateTicketStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() data: { status: number },
  ) {
    return this.crmService.updateTicketStatus(String(id), data.status);
  }

  // ==========================================
  // DASHBOARD
  // ==========================================
  @Get('dashboard')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get CRM dashboard statistics' })
  @ApiResponse({ status: 200, description: 'Dashboard stats' })
  async getDashboard() {
    return this.crmService.getDashboard();
  }

  // ==========================================
  // STAFF
  // ==========================================
  @Get('staff')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM staff members' })
  @ApiResponse({ status: 200, description: 'List of staff' })
  async getAllStaff() {
    return this.crmService.getAllStaff();
  }

  @Get('staff/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get staff by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Staff details' })
  async getStaffById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getStaffById(String(id));
  }

  // ==========================================
  // CLIENTS
  // ==========================================
  @Get('clients')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM clients' })
  @ApiResponse({ status: 200, description: 'List of clients' })
  async getAllClients() {
    return this.crmService.getAllClients();
  }

  @Get('clients/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get client by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Client details' })
  async getClientById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getClientById(String(id));
  }

  @Get('clients/:id/contacts')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get client contacts' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'List of contacts' })
  async getClientContacts(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getClientContacts(String(id));
  }

  // ==========================================
  // PROJECTS
  // ==========================================
  @Get('projects')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM projects' })
  @ApiResponse({ status: 200, description: 'List of projects' })
  async getAllProjects() {
    return this.crmService.getAllProjects();
  }

  @Get('projects/active')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get active CRM projects' })
  @ApiResponse({ status: 200, description: 'List of active projects' })
  async getActiveProjects() {
    return this.crmService.getActiveProjects();
  }

  @Get('projects/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get project by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Project details' })
  async getProjectById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getProjectById(String(id));
  }

  @Get('projects/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get projects by client' })
  @ApiParam({ name: 'clientId', type: Number })
  @ApiResponse({ status: 200, description: 'List of client projects' })
  async getProjectsByClient(@Param('clientId', ParseIntPipe) clientId: number) {
    return this.crmService.getProjectsByClient(String(clientId));
  }

  // ==========================================
  // TASKS
  // ==========================================
  @Get('tasks')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM tasks' })
  @ApiResponse({ status: 200, description: 'List of tasks' })
  async getAllTasks() {
    return this.crmService.getAllTasks();
  }

  @Get('tasks/open')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get open CRM tasks' })
  @ApiResponse({ status: 200, description: 'List of open tasks' })
  async getOpenTasks() {
    return this.crmService.getOpenTasks();
  }

  @Get('tasks/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get task by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Task details' })
  async getTaskById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getTaskById(String(id));
  }

  @Get('tasks/project/:projectId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get tasks by project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'List of project tasks' })
  async getTasksByProject(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.crmService.getTasksByProject(String(projectId));
  }

  // ==========================================
  // INVOICES
  // ==========================================
  @Get('invoices')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM invoices' })
  @ApiResponse({ status: 200, description: 'List of invoices' })
  async getAllInvoices() {
    return this.crmService.getAllInvoices();
  }

  @Get('invoices/unpaid')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get unpaid invoices' })
  @ApiResponse({ status: 200, description: 'List of unpaid invoices' })
  async getUnpaidInvoices() {
    return this.crmService.getUnpaidInvoices();
  }

  @Get('invoices/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get invoice by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Invoice details' })
  async getInvoiceById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getInvoiceById(String(id));
  }

  @Get('invoices/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get invoices by client' })
  @ApiParam({ name: 'clientId', type: Number })
  @ApiResponse({ status: 200, description: 'List of client invoices' })
  async getInvoicesByClient(@Param('clientId', ParseIntPipe) clientId: number) {
    return this.crmService.getInvoicesByClient(String(clientId));
  }

  @Get('invoices/project/:projectId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get invoices by project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'List of project invoices' })
  async getInvoicesByProject(
    @Param('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.crmService.getInvoicesByProject(String(projectId));
  }

  // ==========================================
  // TICKETS
  // ==========================================
  @Get('tickets')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all CRM tickets' })
  @ApiResponse({ status: 200, description: 'List of tickets' })
  async getAllTickets() {
    return this.crmService.getAllTickets();
  }

  @Get('tickets/open')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get open tickets' })
  @ApiResponse({ status: 200, description: 'List of open tickets' })
  async getOpenTickets() {
    return this.crmService.getOpenTickets();
  }

  @Get('tickets/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get ticket by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Ticket details' })
  async getTicketById(@Param('id', ParseIntPipe) id: number) {
    return this.crmService.getTicketById(String(id));
  }

  @Get('tickets/client/:clientId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get tickets by client' })
  @ApiParam({ name: 'clientId', type: Number })
  @ApiResponse({ status: 200, description: 'List of client tickets' })
  async getTicketsByClient(@Param('clientId', ParseIntPipe) clientId: number) {
    return this.crmService.getTicketsByClient(String(clientId));
  }
}
