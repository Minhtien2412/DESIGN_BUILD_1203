import { Module } from '@nestjs/common';
import { CrmController } from './crm.controller';
import { CrmService } from './crm.service';
import { UsersAdminController } from './users-admin.controller';

@Module({
  controllers: [CrmController, UsersAdminController],
  providers: [CrmService],
  exports: [CrmService], // Export để các module khác có thể dùng
})
export class CrmModule {}
