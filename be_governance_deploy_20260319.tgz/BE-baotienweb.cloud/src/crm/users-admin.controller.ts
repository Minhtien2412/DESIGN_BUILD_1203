import {
    Body,
    Controller,
    Delete,
    Get,
    NotFoundException,
    Param,
    Patch,
    Put,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiTags
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards';
import { CrmService } from './crm.service';

@ApiTags('Users Admin')
@Controller({ path: 'users', version: '1' })
export class UsersAdminController {
  constructor(private readonly crmService: CrmService) {}

  // GET /users/admin/list?limit=50
  @Get('admin/list')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'List all users for admin management' })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  async listUsers(
    @Query('limit') limit?: string,
    @Query('page') page?: string,
    @Query('search') search?: string,
  ) {
    const result = await this.crmService.getAllUsers();
    let users = result.users || [];

    // Search filter
    if (search) {
      const q = search.toLowerCase();
      users = users.filter(
        (u: any) =>
          (u.name && u.name.toLowerCase().includes(q)) ||
          (u.email && u.email.toLowerCase().includes(q)) ||
          (u.phone && u.phone.toLowerCase().includes(q)) ||
          (u.id && u.id.toLowerCase().includes(q)),
      );
    }

    const total = users.length;
    const lim = parseInt(limit || '50', 10);
    const pg = parseInt(page || '1', 10);
    const offset = (pg - 1) * lim;
    users = users.slice(offset, offset + lim);

    return {
      users,
      total,
      page: pg,
      limit: lim,
      totalPages: Math.ceil(total / lim),
    };
  }

  // GET /users/:id
  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get user by ID' })
  @ApiParam({ name: 'id', type: String })
  async getUserById(@Param('id') id: string) {
    // Handle "admin" specially to avoid conflict with /users/admin/list
    if (id === 'admin') {
      return { error: 'Use /users/admin/list to list users' };
    }
    const user = await this.crmService.getUserById(id);
    if (!user) throw new NotFoundException(`User ${id} not found`);
    return user;
  }

  // PUT /users/:id
  @Put(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update user' })
  @ApiParam({ name: 'id', type: String })
  async updateUser(@Param('id') id: string, @Body() data: any) {
    const user = await this.crmService.updateUser(id, data);
    if (!user) throw new NotFoundException(`User ${id} not found`);
    return { success: true, user };
  }

  // PATCH /users/:id/role
  @Patch(':id/role')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Change user role' })
  @ApiParam({ name: 'id', type: String })
  async updateUserRole(
    @Param('id') id: string,
    @Body() data: { role: string },
  ) {
    const user = await this.crmService.updateUser(id, { role: data.role });
    if (!user) throw new NotFoundException(`User ${id} not found`);
    return { success: true, user };
  }

  // PATCH /users/:id/ban
  @Patch(':id/ban')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Ban/unban user' })
  @ApiParam({ name: 'id', type: String })
  async toggleBan(
    @Param('id') id: string,
    @Body() data: { banned?: boolean; banReason?: string },
  ) {
    const user = await this.crmService.toggleUserBan(
      id,
      data.banned ?? true,
      data.banReason,
    );
    if (!user) throw new NotFoundException(`User ${id} not found`);
    return { success: true, user };
  }

  // DELETE /users/:id
  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete user' })
  @ApiParam({ name: 'id', type: String })
  async deleteUser(@Param('id') id: string) {
    const deleted = await this.crmService.deleteUser(id);
    if (!deleted) throw new NotFoundException(`User ${id} not found`);
    return { success: true, message: `User ${id} deleted` };
  }
}
