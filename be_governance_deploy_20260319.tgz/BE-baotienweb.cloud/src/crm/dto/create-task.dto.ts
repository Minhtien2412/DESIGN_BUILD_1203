import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsOptional,
  IsNumber,
  IsDateString,
} from 'class-validator';

export class CrmCreateTaskDto {
  @ApiProperty({ example: 'Foundation Inspection' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'Inspect foundation before pouring concrete' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: 2, description: '0=Low, 1=Medium, 2=High, 3=Urgent' })
  @IsNumber()
  @IsOptional()
  priority?: number;

  @ApiProperty({ example: '2025-12-01T08:00:00.000Z' })
  @IsDateString()
  @IsOptional()
  startdate?: string;

  @ApiProperty({ example: '2025-12-05' })
  @IsDateString()
  @IsOptional()
  duedate?: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsOptional()
  rel_id?: number;

  @ApiProperty({ example: 'project' })
  @IsString()
  @IsOptional()
  rel_type?: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsOptional()
  billable?: number;

  @ApiProperty({ example: '150000.00' })
  @IsString()
  @IsOptional()
  hourly_rate?: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  addedfrom: number;
}
