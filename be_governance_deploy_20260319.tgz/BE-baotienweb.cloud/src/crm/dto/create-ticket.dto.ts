import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsOptional,
  IsNumber,
  IsEmail,
} from 'class-validator';

export class CrmCreateTicketDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  userid: number;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsOptional()
  contactid?: number;

  @ApiProperty({ example: 'client@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: 'John Client' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsOptional()
  department?: number;

  @ApiProperty({ example: 2, description: '1=Low, 2=Medium, 3=High' })
  @IsNumber()
  @IsOptional()
  priority?: number;

  @ApiProperty({ example: 'Request for tile change' })
  @IsString()
  @IsNotEmpty()
  subject: string;

  @ApiProperty({ example: 'I would like to change the bathroom tile color...' })
  @IsString()
  @IsNotEmpty()
  message: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsOptional()
  project_id?: number;
}
