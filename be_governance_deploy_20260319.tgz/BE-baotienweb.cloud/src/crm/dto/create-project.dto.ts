import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsOptional,
  IsNumber,
  IsDateString,
} from 'class-validator';

export class CrmCreateProjectDto {
  @ApiProperty({ example: 'Villa Construction Project' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'Build 3-story villa with modern design' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  clientid: number;

  @ApiProperty({ example: 1, description: '1=Fixed, 2=Hourly' })
  @IsNumber()
  @IsOptional()
  billing_type?: number;

  @ApiProperty({ example: '2025-12-01' })
  @IsDateString()
  @IsOptional()
  start_date?: string;

  @ApiProperty({ example: '2026-06-30' })
  @IsDateString()
  @IsOptional()
  deadline?: string;

  @ApiProperty({ example: '500000000.00' })
  @IsOptional()
  project_cost?: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  addedfrom: number;
}
