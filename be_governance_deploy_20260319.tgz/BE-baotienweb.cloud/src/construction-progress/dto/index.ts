import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsDateString,
    IsInt,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreatePhaseDto {
  @ApiProperty() @IsNumber() projectId: number;
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() order?: number;
  @ApiProperty() @IsDateString() plannedStartDate: string;
  @ApiProperty() @IsDateString() plannedEndDate: string;
}

export class UpdatePhaseDto {
  @ApiPropertyOptional() @IsOptional() @IsString() name?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() order?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() progress?: number;
  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  plannedStartDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() plannedEndDate?: string;
}

export class CreateCPTaskDto {
  @ApiProperty() @IsNumber() phaseId: number;
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() assignedWorkers?: number[];
  @ApiProperty() @IsDateString() plannedStartDate: string;
  @ApiProperty() @IsDateString() plannedEndDate: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() dependencies?: number[];
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
}

export class UpdateCPTaskDto {
  @ApiPropertyOptional() @IsOptional() @IsString() name?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() progressPercent?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() media?: string[];
}

export class UpdateTaskProgressDto {
  @ApiProperty() @IsInt() progress: number;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() notes?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() images?: string[];
}

export class CreateSubTaskDto {
  @ApiProperty() @IsString() name: string;
}

export class CreateProgressReportDto {
  @ApiProperty() @IsNumber() projectId: number;
  @ApiProperty() @IsString() title: string;
  @ApiProperty() @IsString() summary: string;
  @ApiProperty() @IsInt() overallProgress: number;
  @ApiPropertyOptional() @IsOptional() phaseProgress?: any;
  @ApiPropertyOptional() @IsOptional() @IsArray() issues?: string[];
  @ApiPropertyOptional() @IsOptional() @IsArray() nextSteps?: string[];
  @ApiPropertyOptional() @IsOptional() @IsArray() images?: string[];
}

export class CreateCPDailyReportDto {
  @ApiProperty() @IsNumber() projectId: number;
  @ApiProperty() @IsDateString() date: string;
  @ApiPropertyOptional() @IsOptional() @IsString() weather?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() workersPresent?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() totalWorkers?: number;
  @ApiProperty() @IsString() title: string;
  @ApiProperty() @IsString() content: string;
  @ApiPropertyOptional() @IsOptional() @IsString() workDone?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() issues?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() nextPlan?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() images?: string[];
}
