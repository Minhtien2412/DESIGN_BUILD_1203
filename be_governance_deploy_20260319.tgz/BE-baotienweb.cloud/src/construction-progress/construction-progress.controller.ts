import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ConstructionProgressService } from './construction-progress.service';
import {
    CreateCPDailyReportDto,
    CreateCPTaskDto,
    CreatePhaseDto,
    CreateProgressReportDto,
    CreateSubTaskDto,
    UpdateCPTaskDto,
    UpdatePhaseDto,
    UpdateTaskProgressDto,
} from './dto';

@ApiTags('Construction Progress')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'construction-progress', version: '1' })
export class ConstructionProgressController {
  constructor(private readonly service: ConstructionProgressService) {}

  // ── Project ──
  @Get('projects/:projectId')
  @ApiOperation({ summary: 'Get project progress overview' })
  getProjectProgress(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectProgress(projectId);
  }

  @Get('projects/:projectId/phases')
  @ApiOperation({ summary: 'Get all phases of a project' })
  getProjectPhases(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectPhases(projectId);
  }

  @Get('projects/:projectId/reports')
  @ApiOperation({ summary: 'Get progress reports for project' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  getProgressReports(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.service.getProgressReports(projectId, {
      page: page ? +page : undefined,
      limit: limit ? +limit : undefined,
    });
  }

  @Get('projects/:projectId/daily-reports')
  @ApiOperation({ summary: 'Get daily reports for project' })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  getDailyReports(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.service.getDailyReports(projectId, {
      startDate,
      endDate,
      page: page ? +page : undefined,
      limit: limit ? +limit : undefined,
    });
  }

  @Get('projects/:projectId/statistics')
  @ApiOperation({ summary: 'Get task statistics for project' })
  getTaskStatistics(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getTaskStatistics(projectId);
  }

  @Get('projects/:projectId/timeline')
  @ApiOperation({ summary: 'Get project timeline/Gantt data' })
  getProjectTimeline(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectTimeline(projectId);
  }

  // ── Phases ──
  @Get('phases/:phaseId')
  @ApiOperation({ summary: 'Get phase detail' })
  getPhaseDetail(@Param('phaseId', ParseIntPipe) phaseId: number) {
    return this.service.getPhaseDetail(phaseId);
  }

  @Post('phases')
  @ApiOperation({ summary: 'Create phase' })
  createPhase(@Body() dto: CreatePhaseDto) {
    return this.service.createPhase(dto);
  }

  @Patch('phases/:phaseId')
  @ApiOperation({ summary: 'Update phase' })
  updatePhase(
    @Param('phaseId', ParseIntPipe) phaseId: number,
    @Body() dto: UpdatePhaseDto,
  ) {
    return this.service.updatePhase(phaseId, dto);
  }

  @Get('phases/:phaseId/tasks')
  @ApiOperation({ summary: 'Get tasks of a phase' })
  getPhaseTasks(@Param('phaseId', ParseIntPipe) phaseId: number) {
    return this.service.getPhaseTasks(phaseId);
  }

  // ── Tasks ──
  @Get('tasks/:taskId')
  @ApiOperation({ summary: 'Get task detail' })
  getTaskDetail(@Param('taskId', ParseIntPipe) taskId: number) {
    return this.service.getTaskDetail(taskId);
  }

  @Post('tasks')
  @ApiOperation({ summary: 'Create task' })
  createTask(@Body() dto: CreateCPTaskDto) {
    return this.service.createTask(dto);
  }

  @Patch('tasks/:taskId')
  @ApiOperation({ summary: 'Update task' })
  updateTask(
    @Param('taskId', ParseIntPipe) taskId: number,
    @Body() dto: UpdateCPTaskDto,
  ) {
    return this.service.updateTask(taskId, dto);
  }

  @Patch('tasks/:taskId/progress')
  @ApiOperation({ summary: 'Update task progress' })
  updateTaskProgress(
    @Param('taskId', ParseIntPipe) taskId: number,
    @Body() dto: UpdateTaskProgressDto,
  ) {
    return this.service.updateTaskProgress(taskId, dto);
  }

  @Post('tasks/:taskId/subtasks')
  @ApiOperation({ summary: 'Add subtask' })
  addSubTask(
    @Param('taskId', ParseIntPipe) taskId: number,
    @Body() dto: CreateSubTaskDto,
  ) {
    return this.service.addSubTask(taskId, dto);
  }

  @Patch('tasks/:taskId/subtasks/:subTaskId/complete')
  @ApiOperation({ summary: 'Complete subtask' })
  completeSubTask(
    @Param('taskId', ParseIntPipe) taskId: number,
    @Param('subTaskId', ParseIntPipe) subTaskId: number,
    @Req() req: any,
  ) {
    return this.service.completeSubTask(
      taskId,
      subTaskId,
      req.user.id ?? req.user.sub,
    );
  }

  // ── Reports ──
  @Post('reports')
  @ApiOperation({ summary: 'Create progress report' })
  createProgressReport(@Req() req: any, @Body() dto: CreateProgressReportDto) {
    return this.service.createProgressReport(req.user.id ?? req.user.sub, dto);
  }

  @Post('daily-reports')
  @ApiOperation({ summary: 'Create daily report' })
  createDailyReport(@Req() req: any, @Body() dto: CreateCPDailyReportDto) {
    return this.service.createDailyReport(req.user.id ?? req.user.sub, dto);
  }
}
