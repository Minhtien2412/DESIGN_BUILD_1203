import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ConstructionProgressController } from './construction-progress.controller';
import { ConstructionProgressService } from './construction-progress.service';

@Module({
  controllers: [ConstructionProgressController],
  providers: [ConstructionProgressService, PrismaService],
  exports: [ConstructionProgressService],
})
export class ConstructionProgressModule {}
