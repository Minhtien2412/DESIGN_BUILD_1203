import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateCPDailyReportDto,
    CreateCPTaskDto,
    CreatePhaseDto,
    CreateProgressReportDto,
    CreateSubTaskDto,
    UpdateCPTaskDto,
    UpdatePhaseDto,
    UpdateTaskProgressDto,
} from './dto';

@Injectable()
export class ConstructionProgressService {
  constructor(private prisma: PrismaService) {}

  // ── Project Progress ──
  async getProjectProgress(projectId: number) {
    const project = await this.prisma.constructionProject.findUnique({
      where: { id: projectId },
      include: {
        phases: { include: { tasks: true }, orderBy: { order: 'asc' } },
      },
    });
    if (!project) throw new NotFoundException('Project not found');

    const phases = project.phases;
    const overallProgress =
      phases.length > 0
        ? Math.round(phases.reduce((s, p) => s + p.progress, 0) / phases.length)
        : project.progressPercent;

    const recentReports = await this.prisma.progressReport.findMany({
      where: { projectId },
      orderBy: { reportDate: 'desc' },
      take: 5,
    });

    return { ...project, overallProgress, recentReports };
  }

  // ── Phases ──
  async getProjectPhases(projectId: number) {
    return this.prisma.constructionPhase.findMany({
      where: { projectId },
      include: { tasks: true },
      orderBy: { order: 'asc' },
    });
  }

  async getPhaseDetail(phaseId: number) {
    const phase = await this.prisma.constructionPhase.findUnique({
      where: { id: phaseId },
      include: { tasks: { include: { subTasks: true } } },
    });
    if (!phase) throw new NotFoundException('Phase not found');
    return phase;
  }

  async createPhase(dto: CreatePhaseDto) {
    return this.prisma.constructionPhase.create({
      data: {
        projectId: dto.projectId,
        name: dto.name,
        description: dto.description,
        order: dto.order ?? 0,
        plannedStartDate: new Date(dto.plannedStartDate),
        plannedEndDate: new Date(dto.plannedEndDate),
      },
    });
  }

  async updatePhase(phaseId: number, dto: UpdatePhaseDto) {
    await this.getPhaseDetail(phaseId);
    const data: any = { ...dto };
    if (dto.plannedStartDate)
      data.plannedStartDate = new Date(dto.plannedStartDate);
    if (dto.plannedEndDate) data.plannedEndDate = new Date(dto.plannedEndDate);
    return this.prisma.constructionPhase.update({
      where: { id: phaseId },
      data,
    });
  }

  // ── Tasks ──
  async getPhaseTasks(phaseId: number) {
    return this.prisma.constructionTask.findMany({
      where: { phaseId },
      include: { subTasks: true },
      orderBy: { startDate: 'asc' },
    });
  }

  async getTaskDetail(taskId: number) {
    const task = await this.prisma.constructionTask.findUnique({
      where: { id: taskId },
      include: { subTasks: true, comments: true, confirmations: true },
    });
    if (!task) throw new NotFoundException('Task not found');
    return task;
  }

  async createTask(dto: CreateCPTaskDto) {
    // Find project from phase
    const phase = await this.prisma.constructionPhase.findUnique({
      where: { id: dto.phaseId },
    });
    if (!phase) throw new NotFoundException('Phase not found');

    return this.prisma.constructionTask.create({
      data: {
        projectId: phase.projectId,
        phaseId: dto.phaseId,
        name: dto.name,
        description: dto.description,
        category: (dto.category as any) ?? 'OTHER',
        priority: (dto.priority as any) ?? 'MEDIUM',
        startDate: new Date(dto.plannedStartDate),
        endDate: new Date(dto.plannedEndDate),
        assignedTo: dto.assignedWorkers?.[0],
      },
    });
  }

  async updateTask(taskId: number, dto: UpdateCPTaskDto) {
    await this.getTaskDetail(taskId);
    const data: any = {};
    if (dto.name) data.name = dto.name;
    if (dto.description) data.description = dto.description;
    if (dto.status) data.status = dto.status;
    if (dto.progressPercent !== undefined)
      data.progressPercent = dto.progressPercent;
    if (dto.priority) data.priority = dto.priority;
    if (dto.media) data.media = dto.media;
    return this.prisma.constructionTask.update({ where: { id: taskId }, data });
  }

  async updateTaskProgress(taskId: number, dto: UpdateTaskProgressDto) {
    await this.getTaskDetail(taskId);
    const data: any = { progressPercent: dto.progress };
    if (dto.status) data.status = dto.status;
    if (dto.images?.length) {
      const task = await this.prisma.constructionTask.findUnique({
        where: { id: taskId },
        select: { media: true },
      });
      data.media = [...(task?.media ?? []), ...dto.images];
    }
    return this.prisma.constructionTask.update({ where: { id: taskId }, data });
  }

  // ── SubTasks ──
  async addSubTask(taskId: number, dto: CreateSubTaskDto) {
    await this.getTaskDetail(taskId);
    return this.prisma.subTask.create({
      data: { taskId, name: dto.name },
    });
  }

  async completeSubTask(taskId: number, subTaskId: number, userId: number) {
    const sub = await this.prisma.subTask.findFirst({
      where: { id: subTaskId, taskId },
    });
    if (!sub) throw new NotFoundException('SubTask not found');
    return this.prisma.subTask.update({
      where: { id: subTaskId },
      data: { isCompleted: true, completedAt: new Date(), completedBy: userId },
    });
  }

  // ── Progress Reports ──
  async getProgressReports(
    projectId: number,
    query: { page?: number; limit?: number },
  ) {
    const { page = 1, limit = 20 } = query;
    const [data, total] = await Promise.all([
      this.prisma.progressReport.findMany({
        where: { projectId },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { reportDate: 'desc' },
      }),
      this.prisma.progressReport.count({ where: { projectId } }),
    ]);
    return { data, total };
  }

  async createProgressReport(userId: number, dto: CreateProgressReportDto) {
    const count = await this.prisma.progressReport.count({
      where: { projectId: dto.projectId },
    });
    return this.prisma.progressReport.create({
      data: {
        projectId: dto.projectId,
        reportDate: new Date(),
        reportNumber: `RPT-${dto.projectId}-${String(count + 1).padStart(3, '0')}`,
        title: dto.title,
        summary: dto.summary,
        overallProgress: dto.overallProgress,
        phaseProgress: dto.phaseProgress,
        issues: dto.issues ?? [],
        nextSteps: dto.nextSteps ?? [],
        images: dto.images ?? [],
        createdById: userId,
      },
    });
  }

  // ── Daily Reports ──
  async getDailyReports(
    projectId: number,
    query: {
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    },
  ) {
    const { page = 1, limit = 20 } = query;
    const where: any = { projectId };
    if (query.startDate || query.endDate) {
      where.date = {};
      if (query.startDate) where.date.gte = new Date(query.startDate);
      if (query.endDate) where.date.lte = new Date(query.endDate);
    }

    const [data, total] = await Promise.all([
      this.prisma.dailyReport.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      this.prisma.dailyReport.count({ where }),
    ]);
    return { data, total };
  }

  async createDailyReport(userId: number, dto: CreateCPDailyReportDto) {
    return this.prisma.dailyReport.create({
      data: {
        projectId: dto.projectId,
        engineerId: userId,
        title: dto.title,
        content: dto.content,
        date: new Date(dto.date),
        workDone: dto.workDone,
        issues: dto.issues,
        nextPlan: dto.nextPlan,
        imageUrls: dto.images ?? [],
      },
    });
  }

  // ── Statistics ──
  async getTaskStatistics(projectId: number) {
    const tasks = await this.prisma.constructionTask.findMany({
      where: { projectId },
      select: {
        status: true,
        priority: true,
        progressPercent: true,
        category: true,
      },
    });

    const total = tasks.length;
    const byStatus: Record<string, number> = {};
    const byPriority: Record<string, number> = {};
    const byCategory: Record<string, number> = {};
    let completedCount = 0;

    for (const t of tasks) {
      byStatus[t.status] = (byStatus[t.status] || 0) + 1;
      byPriority[t.priority] = (byPriority[t.priority] || 0) + 1;
      byCategory[t.category] = (byCategory[t.category] || 0) + 1;
      if (t.status === 'COMPLETED' || t.status === 'APPROVED') completedCount++;
    }
    const avgProgress =
      total > 0
        ? Math.round(tasks.reduce((s, t) => s + t.progressPercent, 0) / total)
        : 0;

    return {
      total,
      completedCount,
      avgProgress,
      byStatus,
      byPriority,
      byCategory,
    };
  }

  // ── Timeline ──
  async getProjectTimeline(projectId: number) {
    const phases = await this.prisma.constructionPhase.findMany({
      where: { projectId },
      include: {
        tasks: {
          select: {
            id: true,
            name: true,
            startDate: true,
            endDate: true,
            status: true,
            progressPercent: true,
          },
        },
      },
      orderBy: { order: 'asc' },
    });
    return phases;
  }
}
