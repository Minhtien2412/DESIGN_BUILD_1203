import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import {
    JobEventType,
    JobStatus,
    Prisma,
    WarrantyStatus,
} from '@prisma/client';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import {
    ClaimWarrantyDto,
    CreateWarrantyDto,
    CreateWarrantyPolicyDto,
    ResolveWarrantyDto,
    WarrantyQueryDto,
} from './dto';

const warrantyDetailInclude = {
  policy: true,
  job: {
    include: {
      booking: true,
      review: true,
    },
  },
};

@Injectable()
export class WarrantiesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async createPolicy(userId: number, dto: CreateWarrantyPolicyDto) {
    const policy = await this.prisma.warrantyPolicy.create({
      data: {
        name: dto.name,
        description: dto.description,
        serviceCategory: dto.serviceCategory,
        coverageDays: dto.coverageDays ?? 30,
        terms: dto.terms,
      },
    });

    await this.notifySafely(
      userId,
      'Chính sách bảo hành đã được tạo',
      `Chính sách ${policy.name} đã sẵn sàng để áp dụng cho các job phù hợp.`,
      { policyId: policy.id },
    );

    return policy;
  }

  async listPolicies() {
    return this.prisma.warrantyPolicy.findMany({
      where: { isActive: true },
      orderBy: [{ serviceCategory: 'asc' }, { coverageDays: 'asc' }],
    });
  }

  async createWarranty(userId: number, dto: CreateWarrantyDto) {
    const access = await this.getJobAccess(dto.jobId, userId);
    this.ensureRole(access, ['customer', 'worker']);

    if (access.job.status !== JobStatus.COMPLETED) {
      throw new BadRequestException(
        'Chỉ có thể tạo bảo hành cho job đã được khách hàng xác nhận hoàn tất.',
      );
    }

    const policy = await this.resolvePolicy(
      dto,
      access.job.booking?.serviceCategory,
    );
    const expiresAt = this.addDays(new Date(), policy.coverageDays);

    const warranty = await this.prisma.$transaction(async (tx) => {
      const created = await tx.warrantyCase.create({
        data: {
          code: this.buildCode('WAR'),
          jobId: access.job.id,
          customerId: access.job.customerId,
          workerId: access.job.workerId,
          policyId: policy.id,
          status: WarrantyStatus.ACTIVE,
          title: dto.title ?? `Bảo hành cho ${access.job.title}`,
          description: dto.description,
          expiresAt,
        },
      });

      await tx.job.update({
        where: { id: access.job.id },
        data: { warrantyUntil: expiresAt },
      });

      await tx.jobEvent.create({
        data: {
          jobId: access.job.id,
          type: JobEventType.WARRANTY_CREATED,
          actorUserId: userId,
          actorWorkerId: access.isWorker ? access.job.workerId : undefined,
          message: 'Đã tạo case bảo hành cho job.',
          metadata: {
            warrantyId: created.id,
            warrantyCode: created.code,
            policyId: policy.id,
            coverageDays: policy.coverageDays,
          },
        },
      });

      return tx.warrantyCase.findUniqueOrThrow({
        where: { id: created.id },
        include: warrantyDetailInclude,
      });
    });

    await this.notifySafely(
      access.job.customerId,
      'Đã kích hoạt bảo hành',
      `Bảo hành ${warranty.code} đã được tạo cho job ${access.job.jobCode}.`,
      {
        warrantyId: warranty.id,
        warrantyCode: warranty.code,
        jobId: access.job.id,
      },
    );

    const worker = await this.prisma.worker.findUnique({
      where: { id: access.job.workerId },
      select: { userId: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Job đã có bảo hành',
        `Case bảo hành ${warranty.code} đã được tạo cho job ${access.job.jobCode}.`,
        {
          warrantyId: warranty.id,
          warrantyCode: warranty.code,
          jobId: access.job.id,
        },
      );
    }

    return warranty;
  }

  async getMyWarranties(userId: number, query: WarrantyQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const workerIds = await this.getWorkerIdsForUser(userId);

    const orConditions: Prisma.WarrantyCaseWhereInput[] = [
      { customerId: userId },
    ];
    if (workerIds.length > 0) {
      orConditions.push({ workerId: { in: workerIds } });
    }

    const where: Prisma.WarrantyCaseWhereInput = {
      ...(query.status
        ? { status: query.status as unknown as WarrantyStatus }
        : {}),
      OR: orConditions,
    };

    const [data, total] = await Promise.all([
      this.prisma.warrantyCase.findMany({
        where,
        include: warrantyDetailInclude,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.warrantyCase.count({ where }),
    ]);

    return {
      data,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getWarrantyDetail(id: number, userId: number) {
    const access = await this.getWarrantyAccess(id, userId);
    return access.warranty;
  }

  async claimWarranty(id: number, userId: number, dto: ClaimWarrantyDto) {
    const access = await this.getWarrantyAccess(id, userId);
    this.ensureRole(access, ['customer']);

    if (access.warranty.status !== WarrantyStatus.ACTIVE) {
      throw new BadRequestException(
        'Case bảo hành này chưa sẵn sàng để claim.',
      );
    }

    await this.prisma.warrantyCase.update({
      where: { id },
      data: {
        status: WarrantyStatus.CLAIMED,
        claimReason: dto.reason,
        description: dto.description ?? access.warranty.description,
        claimedAt: new Date(),
      },
    });

    const worker = await this.prisma.worker.findUnique({
      where: { id: access.warranty.job.workerId },
      select: { userId: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Có yêu cầu bảo hành mới',
        `Khách hàng vừa gửi yêu cầu bảo hành ${access.warranty.code}.`,
        { warrantyId: access.warranty.id, warrantyCode: access.warranty.code },
      );
    }

    return this.getWarrantyDetail(id, userId);
  }

  async resolveWarranty(id: number, userId: number, dto: ResolveWarrantyDto) {
    const access = await this.getWarrantyAccess(id, userId);
    this.ensureRole(access, ['worker']);
    const actionableStatuses: WarrantyStatus[] = [
      WarrantyStatus.CLAIMED,
      WarrantyStatus.IN_PROGRESS,
    ];

    if (!actionableStatuses.includes(access.warranty.status)) {
      throw new BadRequestException(
        'Case bảo hành không ở trạng thái có thể xử lý xong.',
      );
    }

    await this.prisma.warrantyCase.update({
      where: { id },
      data: {
        status: WarrantyStatus.RESOLVED,
        resolutionNotes: dto.resolutionNotes,
        resolvedAt: new Date(),
      },
    });

    await this.notifySafely(
      access.warranty.customerId,
      'Bảo hành đã được xử lý',
      `Case bảo hành ${access.warranty.code} đã được xử lý xong.`,
      { warrantyId: access.warranty.id, warrantyCode: access.warranty.code },
    );

    return this.getWarrantyDetail(id, userId);
  }

  async rejectWarranty(id: number, userId: number, dto: ResolveWarrantyDto) {
    const access = await this.getWarrantyAccess(id, userId);
    this.ensureRole(access, ['worker']);
    const actionableStatuses: WarrantyStatus[] = [
      WarrantyStatus.CLAIMED,
      WarrantyStatus.IN_PROGRESS,
    ];

    if (!actionableStatuses.includes(access.warranty.status)) {
      throw new BadRequestException(
        'Case bảo hành không ở trạng thái có thể từ chối.',
      );
    }

    await this.prisma.warrantyCase.update({
      where: { id },
      data: {
        status: WarrantyStatus.REJECTED,
        resolutionNotes: dto.resolutionNotes,
      },
    });

    await this.notifySafely(
      access.warranty.customerId,
      'Yêu cầu bảo hành bị từ chối',
      `Case bảo hành ${access.warranty.code} đã bị từ chối.`,
      { warrantyId: access.warranty.id, warrantyCode: access.warranty.code },
    );

    return this.getWarrantyDetail(id, userId);
  }

  private async getJobAccess(jobId: number, userId: number) {
    const workerIds = await this.getWorkerIdsForUser(userId);
    const orConditions: Prisma.JobWhereInput[] = [{ customerId: userId }];

    if (workerIds.length > 0) {
      orConditions.push({ workerId: { in: workerIds } });
    }

    const job = await this.prisma.job.findFirst({
      where: {
        id: jobId,
        OR: orConditions,
      },
      include: {
        booking: true,
      },
    });

    if (!job) {
      throw new NotFoundException(`Job with ID ${jobId} not found`);
    }

    return {
      job,
      isCustomer: job.customerId === userId,
      isWorker: workerIds.includes(job.workerId),
    };
  }

  private async getWarrantyAccess(id: number, userId: number) {
    const workerIds = await this.getWorkerIdsForUser(userId);
    const orConditions: Prisma.WarrantyCaseWhereInput[] = [
      { customerId: userId },
    ];

    if (workerIds.length > 0) {
      orConditions.push({ workerId: { in: workerIds } });
    }

    const warranty = await this.prisma.warrantyCase.findFirst({
      where: {
        id,
        OR: orConditions,
      },
      include: warrantyDetailInclude,
    });

    if (!warranty) {
      throw new NotFoundException(`Warranty case with ID ${id} not found`);
    }

    return {
      warranty,
      isCustomer: warranty.customerId === userId,
      isWorker: warranty.workerId
        ? workerIds.includes(warranty.workerId)
        : false,
    };
  }

  private async resolvePolicy(
    dto: CreateWarrantyDto,
    bookingServiceCategory?: string | null,
  ) {
    if (dto.policyId) {
      const existing = await this.prisma.warrantyPolicy.findFirst({
        where: {
          id: dto.policyId,
          isActive: true,
        },
      });

      if (!existing) {
        throw new NotFoundException(
          `Warranty policy ${dto.policyId} not found`,
        );
      }

      return existing;
    }

    return this.prisma.warrantyPolicy.create({
      data: {
        name: dto.policyName ?? 'Chính sách bảo hành mặc định',
        description: dto.description,
        serviceCategory: dto.serviceCategory ?? bookingServiceCategory,
        coverageDays: dto.coverageDays ?? 30,
        terms: dto.terms,
      },
    });
  }

  private async getWorkerIdsForUser(userId: number) {
    const workers = await this.prisma.worker.findMany({
      where: { userId },
      select: { id: true },
    });

    return workers.map((worker) => worker.id);
  }

  private ensureRole(
    access: { isCustomer: boolean; isWorker: boolean },
    allowedRoles: Array<'customer' | 'worker'>,
  ) {
    const granted =
      (allowedRoles.includes('customer') && access.isCustomer) ||
      (allowedRoles.includes('worker') && access.isWorker);

    if (!granted) {
      throw new ForbiddenException(
        'Bạn không có quyền thao tác trên dữ liệu này.',
      );
    }
  }

  private addDays(date: Date, days: number) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  private async notifySafely(
    userId: number,
    title: string,
    message: string,
    data?: Record<string, unknown>,
  ) {
    try {
      await this.notificationsService.create({
        userId,
        title,
        message,
        type: 'SYSTEM',
        priority: 'MEDIUM',
        data,
      });
    } catch (error) {
      console.error('[WarrantiesService] Failed to send notification', error);
    }
  }

  private buildCode(prefix: string) {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.random().toString(36).slice(2, 8).toUpperCase();
    return `${prefix}-${date}-${random}`;
  }
}
