import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MaxLength,
    Min,
} from 'class-validator';

export enum WarrantyStatusDto {
  ACTIVE = 'ACTIVE',
  CLAIMED = 'CLAIMED',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  REJECTED = 'REJECTED',
  EXPIRED = 'EXPIRED',
  CANCELLED = 'CANCELLED',
}

export class WarrantyQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ enum: WarrantyStatusDto })
  @IsOptional()
  @IsEnum(WarrantyStatusDto)
  status?: WarrantyStatusDto;
}

export class CreateWarrantyPolicyDto {
  @ApiProperty({ description: 'Tên chính sách bảo hành' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(160)
  name: string;

  @ApiPropertyOptional({ description: 'Mô tả chính sách bảo hành' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ description: 'Loại dịch vụ áp dụng' })
  @IsOptional()
  @IsString()
  @MaxLength(120)
  serviceCategory?: string;

  @ApiPropertyOptional({ description: 'Số ngày hiệu lực', default: 30 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  coverageDays?: number;

  @ApiPropertyOptional({ description: 'Điều khoản bảo hành' })
  @IsOptional()
  @IsString()
  terms?: string;
}

export class CreateWarrantyDto {
  @ApiProperty({ description: 'Job ID đã hoàn tất' })
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  jobId: number;

  @ApiPropertyOptional({ description: 'Policy ID có sẵn để tái sử dụng' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  policyId?: number;

  @ApiPropertyOptional({ description: 'Tên policy mới nếu chưa có sẵn' })
  @IsOptional()
  @IsString()
  @MaxLength(160)
  policyName?: string;

  @ApiPropertyOptional({ description: 'Loại dịch vụ áp dụng' })
  @IsOptional()
  @IsString()
  @MaxLength(120)
  serviceCategory?: string;

  @ApiPropertyOptional({ description: 'Số ngày bảo hành', default: 30 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  coverageDays?: number;

  @ApiPropertyOptional({ description: 'Điều khoản bảo hành' })
  @IsOptional()
  @IsString()
  terms?: string;

  @ApiPropertyOptional({ description: 'Tiêu đề case bảo hành' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @ApiPropertyOptional({ description: 'Mô tả thêm cho case bảo hành' })
  @IsOptional()
  @IsString()
  description?: string;
}

export class ClaimWarrantyDto {
  @ApiProperty({ description: 'Lý do yêu cầu bảo hành' })
  @IsString()
  @IsNotEmpty()
  reason: string;

  @ApiPropertyOptional({
    description: 'Mô tả chi tiết tình trạng cần bảo hành',
  })
  @IsOptional()
  @IsString()
  description?: string;
}

export class ResolveWarrantyDto {
  @ApiPropertyOptional({ description: 'Ghi chú xử lý / kết luận bảo hành' })
  @IsOptional()
  @IsString()
  resolutionNotes?: string;

  @ApiPropertyOptional({ description: 'Metadata quá trình xử lý' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}
