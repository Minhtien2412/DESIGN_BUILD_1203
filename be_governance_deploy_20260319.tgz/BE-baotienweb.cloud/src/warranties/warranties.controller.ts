import {
    Body,
    Controller,
    Get,
    Param,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import {
    ClaimWarrantyDto,
    CreateWarrantyDto,
    CreateWarrantyPolicyDto,
    ResolveWarrantyDto,
    WarrantyQueryDto,
} from './dto';
import { WarrantiesService } from './warranties.service';

@ApiTags('Warranties - After service lifecycle')
@Controller('warranties')
@UseGuards(ApiKeyGuard)
export class WarrantiesController {
  constructor(private readonly warrantiesService: WarrantiesService) {}

  @Post('policies')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo chính sách bảo hành mới' })
  async createPolicy(
    @Body() dto: CreateWarrantyPolicyDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.createPolicy(user.id, dto);
  }

  @Get('policies')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách chính sách bảo hành đang hoạt động' })
  async listPolicies() {
    return this.warrantiesService.listPolicies();
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo case bảo hành từ job đã hoàn tất' })
  async createWarranty(
    @Body() dto: CreateWarrantyDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.createWarranty(user.id, dto);
  }

  @Get('mine')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách case bảo hành của tôi' })
  async getMyWarranties(
    @Query() query: WarrantyQueryDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.getMyWarranties(user.id, query);
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy chi tiết case bảo hành' })
  async getWarrantyDetail(@Param('id') id: string, @CurrentUser() user: any) {
    return this.warrantiesService.getWarrantyDetail(parseInt(id, 10), user.id);
  }

  @Post(':id/claim')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khách hàng gửi yêu cầu bảo hành' })
  async claimWarranty(
    @Param('id') id: string,
    @Body() dto: ClaimWarrantyDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.claimWarranty(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/resolve')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Xử lý xong yêu cầu bảo hành' })
  async resolveWarranty(
    @Param('id') id: string,
    @Body() dto: ResolveWarrantyDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.resolveWarranty(
      parseInt(id, 10),
      user.id,
      dto,
    );
  }

  @Post(':id/reject')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Từ chối yêu cầu bảo hành' })
  async rejectWarranty(
    @Param('id') id: string,
    @Body() dto: ResolveWarrantyDto,
    @CurrentUser() user: any,
  ) {
    return this.warrantiesService.rejectWarranty(
      parseInt(id, 10),
      user.id,
      dto,
    );
  }
}
