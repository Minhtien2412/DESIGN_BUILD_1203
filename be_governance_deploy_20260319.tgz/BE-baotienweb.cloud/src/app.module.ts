/**
 * App Module for VPS - Full version
 * =====================================
 * Includes all available modules
 */

import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AddressesModule } from './addresses/addresses.module';
import { AIModule } from './ai/ai.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AsBuiltModule } from './as-built/as-built.module';
import { AuditLogModule } from './audit/audit-log.module';
import { AuthModule } from './auth/auth.module';
import { AuthorizationModule } from './authorization/authorization.module';
import { BookingsModule } from './bookings/bookings.module';
import { BudgetModule } from './budget/budget.module';
import { CallModule } from './call/call.module';
import { CartModule } from './cart/cart.module';
import { ChangeManagementModule } from './change-management/change-management.module';
import { ChatModule } from './chat/chat.module';
import { CommentsModule } from './comments/comments.module';
import { CommissioningModule } from './commissioning/commissioning.module';
import { ApiKeyGuard } from './common/guards/api-key.guard';
import { RequestIdMiddleware } from './common/middleware/request-id.middleware';
import { CommunicationModule } from './communication/communication.module';
import { CompaniesModule } from './companies/companies.module';
import { ConstructionMapModule } from './construction-map/construction-map.module';
import { ConstructionProgressModule } from './construction-progress/construction-progress.module';
import { ContractModule } from './contract/contract.module';
import { ContractsModule } from './contracts/contracts.module';
import { ConversationMessagesModule } from './conversation-messages/conversation-messages.module';
import { ConversationsModule } from './conversations/conversations.module';
import { CrmModule } from './crm/crm.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { DocumentControlModule } from './document-control/document-control.module';
import { EmailModule } from './email/email.module';
import { EnvironmentalModule } from './environmental/environmental.module';
import { EstimatesModule } from './estimates/estimates.module';
import { FilesModule } from './files/files.module';
import { FleetModule } from './fleet/fleet.module';
import { GitHubWebhookModule } from './github/github-webhook.module';
import { HealthModule } from './health/health.module';
import { HomeContentModule } from './home-content/home-content.module';
import { JobsModule } from './jobs/jobs.module';
import { KycModule } from './kyc/kyc.module';
import { LaborModule } from './labor/labor.module';
import { LivestreamModule } from './livestream/livestream.module';
import { MarketplaceGovernanceModule } from './marketplace-governance/marketplace-governance.module';
import { MarketplacePaymentsModule } from './marketplace-payments/marketplace-payments.module';
import { MaterialsModule } from './materials/materials.module';
import { MeetingsModule } from './meetings/meetings.module';
import { MessagesModule } from './messages/messages.module';
import { MetricsModule } from './metrics/metrics.module';
import { NotificationsModule } from './notifications/notifications.module';
import { OrdersModule } from './orders/orders.module';
import { PaymentModule } from './payment/payment.module';
import { PostsModule } from './posts/posts.module';
import { PrismaModule } from './prisma/prisma.module';
import { ProductsModule } from './products/products.module';
import { ProfileModule } from './profile/profile.module';
import { ProgressModule } from './progress/progress.module';
import { ProjectsModule } from './projects/projects.module';
import { QCModule } from './qc/qc.module';
import { QuoteRequestsModule } from './quote-requests/quote-requests.module';
import { ReelsModule } from './reels/reels.module';
import { SafetyModule } from './safety/safety.module';
import { ServicesModule } from './services/services.module';
import { ShippingModule } from './shipping/shipping.module';
import { StrapiSyncModule } from './strapi-sync/strapi-sync.module';
import { TasksModule } from './tasks/tasks.module';
import { TimelineModule } from './timeline/timeline.module';
import { UploadModule } from './upload/upload.module';
import { UsersModule } from './users/users.module';
import { UtilitiesModule } from './utilities/utilities.module';
import { VideoModule } from './video/video.module';
import { WarrantiesModule } from './warranties/warranties.module';
import { WorkerBookingsModule } from './worker-bookings/worker-bookings.module';
import { WorkersModule } from './workers/workers.module';
import { ZaloModule } from './zalo/zalo.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 100,
      },
    ]),
    // Core
    PrismaModule,
    HealthModule, // Health check endpoints
    MetricsModule, // Global module - must be early
    EmailModule, // Global module
    AuditLogModule,
    AuthorizationModule,

    // Authentication & Users
    AuthModule,
    AddressesModule, // MUST be before UsersModule to handle /users/addresses before /users/:id
    UsersModule,
    ProfileModule,
    CompaniesModule,

    // Communication
    CallModule,
    ChatModule,
    ConversationsModule,
    ConversationMessagesModule,
    MessagesModule,
    CommunicationModule,
    CommentsModule,
    NotificationsModule,

    // E-Commerce
    ProductsModule,
    CartModule,
    OrdersModule,
    PaymentModule,
    MarketplacePaymentsModule,
    MarketplaceGovernanceModule,

    // Media & Files
    UploadModule,
    FilesModule,
    ReelsModule,
    VideoModule,
    LivestreamModule,

    // Construction & Projects
    ProjectsModule,
    TasksModule,
    ProgressModule,
    TimelineModule,
    ConstructionMapModule,
    QCModule,
    AsBuiltModule,
    ContractModule,
    EstimatesModule,
    MaterialsModule,

    // Resources
    LaborModule,
    WorkersModule,
    WorkerBookingsModule,
    BookingsModule,
    JobsModule,
    WarrantiesModule,
    FleetModule,
    SafetyModule,
    EnvironmentalModule,
    DocumentControlModule,

    // CRM & Dashboard
    CrmModule,
    DashboardModule,
    AnalyticsModule,

    // CMS
    PostsModule,

    // AI & Services
    AIModule,
    ServicesModule,
    UtilitiesModule,

    // Integrations
    StrapiSyncModule,
    ZaloModule,
    GitHubWebhookModule,
    HomeContentModule,

    // Customer Features (NEW)
    QuoteRequestsModule,
    KycModule,
    ShippingModule,
    // AddressesModule moved up - before UsersModule for route priority

    // Gap-fill Modules (Phase 2-4)
    CommissioningModule,
    ChangeManagementModule,
    BudgetModule,
    MeetingsModule,
    ContractsModule,
    ConstructionProgressModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
    {
      provide: APP_GUARD,
      useClass: ApiKeyGuard,
    },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(RequestIdMiddleware).forRoutes('*');
  }
}
