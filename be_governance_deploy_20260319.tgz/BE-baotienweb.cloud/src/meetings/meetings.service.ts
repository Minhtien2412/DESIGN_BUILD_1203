import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateMeetingDto,
    CreatePollDto,
    UpdateMeetingDto
} from './dto';

@Injectable()
export class MeetingsService {
  constructor(private prisma: PrismaService) {}

  // ==================== Meetings ====================

  async getMeetings(projectId?: number, status?: string, userId?: number) {
    return this.prisma.meeting.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(status ? { status: status as any } : {}),
        ...(userId
          ? {
              OR: [
                { createdById: userId },
                { participants: { some: { userId } } },
              ],
            }
          : {}),
      },
      include: {
        createdBy: { select: { id: true, name: true, avatar: true } },
        participants: {
          include: { user: { select: { id: true, name: true, avatar: true } } },
        },
        _count: { select: { participants: true, polls: true } },
      },
      orderBy: { scheduledAt: 'desc' },
    });
  }

  async getMeetingById(id: number) {
    const meeting = await this.prisma.meeting.findUnique({
      where: { id },
      include: {
        createdBy: { select: { id: true, name: true, avatar: true } },
        participants: {
          include: { user: { select: { id: true, name: true, avatar: true } } },
        },
        polls: true,
        project: { select: { id: true, title: true } },
      },
    });
    if (!meeting) throw new NotFoundException('Meeting not found');
    return meeting;
  }

  async getMeetingByCode(code: string) {
    const meeting = await this.prisma.meeting.findUnique({
      where: { code },
      include: {
        createdBy: { select: { id: true, name: true, avatar: true } },
        participants: {
          include: { user: { select: { id: true, name: true, avatar: true } } },
        },
      },
    });
    if (!meeting) throw new NotFoundException('Meeting not found');
    return { meeting };
  }

  async createMeeting(data: CreateMeetingDto, userId: number) {
    const code = this.generateMeetingCode();
    const meeting = await this.prisma.meeting.create({
      data: {
        title: data.title,
        description: data.description,
        code,
        createdById: userId,
        projectId: data.projectId,
        type: (data.type as any) ?? 'VIDEO',
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : undefined,
        duration: data.duration,
        maxParticipants: data.maxParticipants ?? 100,
        isPasswordProtected: !!data.password,
        password: data.password,
      },
    });

    // Add participants
    if (data.participantIds?.length) {
      await this.prisma.meetingParticipant.createMany({
        data: data.participantIds.map((uid) => ({
          meetingId: meeting.id,
          userId: uid,
        })),
      });
    }

    return this.getMeetingById(meeting.id);
  }

  async updateMeeting(id: number, data: UpdateMeetingDto) {
    return this.prisma.meeting.update({
      where: { id },
      data: {
        ...(data.title !== undefined ? { title: data.title } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.scheduledAt
          ? { scheduledAt: new Date(data.scheduledAt) }
          : {}),
        ...(data.duration !== undefined ? { duration: data.duration } : {}),
        ...(data.maxParticipants !== undefined
          ? { maxParticipants: data.maxParticipants }
          : {}),
      },
      include: { createdBy: { select: { id: true, name: true } } },
    });
  }

  async deleteMeeting(id: number) {
    return this.prisma.meeting.delete({ where: { id } });
  }

  async joinMeeting(id: number, userId: number, password?: string) {
    const meeting = await this.prisma.meeting.findUnique({ where: { id } });
    if (!meeting) throw new NotFoundException('Meeting not found');

    if (meeting.isPasswordProtected && meeting.password !== password) {
      throw new NotFoundException('Invalid password');
    }

    // Add as participant if not already
    const existing = await this.prisma.meetingParticipant.findFirst({
      where: { meetingId: id, userId },
    });
    if (!existing) {
      await this.prisma.meetingParticipant.create({
        data: {
          meetingId: id,
          userId,
          rsvpStatus: 'ACCEPTED',
          joinedAt: new Date(),
        },
      });
    } else {
      await this.prisma.meetingParticipant.update({
        where: { id: existing.id },
        data: { joinedAt: new Date() },
      });
    }

    return {
      meeting: await this.getMeetingById(id),
      token: `meeting-token-${id}-${userId}`,
      roomUrl: `/meetings/room?meetingId=${id}`,
    };
  }

  async leaveMeeting(id: number, userId: number) {
    const participant = await this.prisma.meetingParticipant.findFirst({
      where: { meetingId: id, userId },
    });
    if (participant) {
      await this.prisma.meetingParticipant.update({
        where: { id: participant.id },
        data: { leftAt: new Date() },
      });
    }
  }

  async respondToMeeting(id: number, userId: number, rsvp: string) {
    const participant = await this.prisma.meetingParticipant.findFirst({
      where: { meetingId: id, userId },
    });
    if (participant) {
      return this.prisma.meetingParticipant.update({
        where: { id: participant.id },
        data: { rsvpStatus: rsvp as any },
      });
    }
    return this.prisma.meetingParticipant.create({
      data: { meetingId: id, userId, rsvpStatus: rsvp as any },
    });
  }

  async startMeeting(id: number) {
    return this.prisma.meeting.update({
      where: { id },
      data: { status: 'IN_PROGRESS', startedAt: new Date() },
    });
  }

  async endMeeting(id: number) {
    return this.prisma.meeting.update({
      where: { id },
      data: { status: 'COMPLETED', endedAt: new Date() },
    });
  }

  // ==================== Polls ====================

  async createPoll(data: CreatePollDto, userId: number) {
    return this.prisma.poll.create({
      data: {
        question: data.question,
        options: data.options,
        meetingId: data.meetingId,
        createdById: userId,
      },
    });
  }

  async votePoll(pollId: number, userId: number, optionIds: number[]) {
    const poll = await this.prisma.poll.findUnique({ where: { id: pollId } });
    if (!poll) throw new NotFoundException('Poll not found');

    const votes = (poll.votes as any) || {};
    votes[userId] = optionIds;

    return this.prisma.poll.update({
      where: { id: pollId },
      data: { votes },
    });
  }

  async closePoll(pollId: number) {
    return this.prisma.poll.update({
      where: { id: pollId },
      data: { status: 'CLOSED', closedAt: new Date() },
    });
  }

  private generateMeetingCode(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyz';
    const part = () =>
      Array.from(
        { length: 3 },
        () => chars[Math.floor(Math.random() * chars.length)],
      ).join('');
    return `${part()}-${part()}${part().charAt(0)}-${part()}`;
  }
}
