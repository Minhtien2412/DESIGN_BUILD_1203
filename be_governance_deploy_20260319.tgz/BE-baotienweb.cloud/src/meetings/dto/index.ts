import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsDateString,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreateMeetingDto {
  @ApiProperty() @IsString() title: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() projectId?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() scheduledAt?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() duration?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() maxParticipants?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() password?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() participantIds?: number[];
}

export class UpdateMeetingDto {
  @ApiPropertyOptional() @IsOptional() @IsString() title?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() scheduledAt?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() duration?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() maxParticipants?: number;
}

export class CreatePollDto {
  @ApiProperty() @IsString() question: string;
  @ApiProperty() @IsArray() options: string[];
  @ApiPropertyOptional() @IsOptional() @IsNumber() meetingId?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() allowMultiple?: boolean;
  @ApiPropertyOptional() @IsOptional() @IsDateString() expiresAt?: string;
}

export class VotePollDto {
  @ApiProperty() @IsArray() optionIds: number[];
}
