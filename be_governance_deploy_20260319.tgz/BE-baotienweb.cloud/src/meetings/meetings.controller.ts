import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreateMeetingDto,
    CreatePollDto,
    UpdateMeetingDto,
    VotePollDto,
} from './dto';
import { MeetingsService } from './meetings.service';

@ApiTags('Meetings')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'meetings', version: '1' })
export class MeetingsController {
  constructor(private readonly service: MeetingsService) {}

  @Get()
  @ApiOperation({ summary: 'List meetings' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'userId', required: false })
  findAll(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
    @Query('userId') userId?: string,
  ) {
    return this.service.getMeetings(
      projectId ? +projectId : undefined,
      status,
      userId ? +userId : undefined,
    );
  }

  @Get('code/:code')
  @ApiOperation({ summary: 'Get meeting by code' })
  findByCode(@Param('code') code: string) {
    return this.service.getMeetingByCode(code);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get meeting by ID' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.getMeetingById(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create meeting' })
  create(@Body() dto: CreateMeetingDto, @Req() req: any) {
    return this.service.createMeeting(dto, req.user?.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update meeting' })
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateMeetingDto) {
    return this.service.updateMeeting(id, dto);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Patch meeting' })
  patch(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateMeetingDto) {
    return this.service.updateMeeting(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete meeting' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteMeeting(id);
  }

  @Post(':id/join')
  @ApiOperation({ summary: 'Join meeting' })
  join(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() body: { password?: string },
  ) {
    return this.service.joinMeeting(id, req.user?.id, body.password);
  }

  @Post(':id/leave')
  @ApiOperation({ summary: 'Leave meeting' })
  leave(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    return this.service.leaveMeeting(id, req.user?.id);
  }

  @Post(':id/rsvp')
  @ApiOperation({ summary: 'RSVP to meeting' })
  rsvp(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() body: { rsvp: string },
  ) {
    return this.service.respondToMeeting(id, req.user?.id, body.rsvp);
  }

  @Post(':id/start')
  @ApiOperation({ summary: 'Start meeting' })
  start(@Param('id', ParseIntPipe) id: number) {
    return this.service.startMeeting(id);
  }

  @Post(':id/end')
  @ApiOperation({ summary: 'End meeting' })
  end(@Param('id', ParseIntPipe) id: number) {
    return this.service.endMeeting(id);
  }
}

@ApiTags('Polls')
@ApiBearerAuth()
@Controller({ path: 'polls', version: '1' })
export class PollsController {
  constructor(private readonly service: MeetingsService) {}

  @Post()
  @ApiOperation({ summary: 'Create poll' })
  create(@Body() dto: CreatePollDto, @Req() req: any) {
    return this.service.createPoll(dto, req.user?.id);
  }

  @Post(':id/vote')
  @ApiOperation({ summary: 'Vote on poll' })
  vote(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() dto: VotePollDto,
  ) {
    return this.service.votePoll(id, req.user?.id, dto.optionIds);
  }

  @Post(':id/close')
  @ApiOperation({ summary: 'Close poll' })
  close(@Param('id', ParseIntPipe) id: number) {
    return this.service.closePoll(id);
  }
}
