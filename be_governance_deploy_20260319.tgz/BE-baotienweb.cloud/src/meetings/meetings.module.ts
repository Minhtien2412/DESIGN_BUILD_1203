import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { MeetingsController, PollsController } from './meetings.controller';
import { MeetingsService } from './meetings.service';

@Module({
  controllers: [MeetingsController, PollsController],
  providers: [MeetingsService, PrismaService],
  exports: [MeetingsService],
})
export class MeetingsModule {}
