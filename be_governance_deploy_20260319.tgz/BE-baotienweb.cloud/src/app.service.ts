import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getApiLandingPage(): string {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const mins = Math.floor((uptime % 3600) / 60);

    return `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Baotienweb API v1</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🏗️</text></svg>">
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0F172A;color:#E2E8F0;min-height:100vh;display:flex;align-items:center;justify-content:center}
    .container{max-width:720px;width:100%;padding:24px}
    .header{text-align:center;margin-bottom:40px}
    .logo{font-size:48px;margin-bottom:12px}
    h1{font-size:28px;font-weight:800;background:linear-gradient(135deg,#0D9488,#14B8A6,#5EEAD4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:6px}
    .subtitle{color:#94A3B8;font-size:14px}
    .status-card{background:linear-gradient(135deg,rgba(13,148,136,.15),rgba(20,184,166,.08));border:1px solid rgba(13,148,136,.3);border-radius:16px;padding:24px;margin-bottom:20px}
    .status-row{display:flex;align-items:center;gap:10px;margin-bottom:8px}
    .status-dot{width:10px;height:10px;border-radius:50%;background:#10B981;box-shadow:0 0 8px rgba(16,185,129,.6);animation:pulse 2s infinite}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
    .status-text{font-size:15px;font-weight:600;color:#10B981}
    .status-meta{color:#64748B;font-size:13px}
    .endpoints{display:grid;gap:10px;margin-bottom:24px}
    .endpoint{background:rgba(30,41,59,.8);border:1px solid rgba(51,65,85,.6);border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:12px;transition:all .2s}
    .endpoint:hover{border-color:rgba(13,148,136,.5);background:rgba(13,148,136,.08)}
    .method{font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;min-width:44px;text-align:center}
    .get{background:rgba(16,185,129,.15);color:#10B981}
    .post{background:rgba(59,130,246,.15);color:#60A5FA}
    .ep-path{font-size:13px;color:#CBD5E1;font-family:'Fira Code',monospace;flex:1}
    .ep-desc{font-size:11px;color:#64748B}
    .section-title{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#0D9488;margin-bottom:12px;margin-top:8px}
    .links{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-top:24px}
    .link{background:rgba(13,148,136,.12);border:1px solid rgba(13,148,136,.3);color:#14B8A6;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:600;font-size:13px;transition:all .2s}
    .link:hover{background:rgba(13,148,136,.25)}
    .link.primary{background:linear-gradient(135deg,#0D9488,#14B8A6);color:#fff;border:none}
    .footer{text-align:center;color:#475569;font-size:12px;margin-top:32px}
    .footer a{color:#0D9488;text-decoration:none}
    .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px}
    .stat{background:rgba(30,41,59,.6);border-radius:10px;padding:14px;text-align:center}
    .stat-value{font-size:20px;font-weight:800;color:#14B8A6}
    .stat-label{font-size:11px;color:#64748B;margin-top:2px}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">🏗️</div>
      <h1>Baotienweb API</h1>
      <p class="subtitle">Construction Management & E-Commerce Platform • v1.0</p>
    </div>

    <div class="status-card">
      <div class="status-row">
        <div class="status-dot"></div>
        <span class="status-text">Hệ thống đang hoạt động</span>
      </div>
      <div class="status-meta">Uptime: ${hours}h ${mins}m • Node ${process.version} • NestJS</div>
    </div>

    <div class="stats">
      <div class="stat"><div class="stat-value">25+</div><div class="stat-label">API Endpoints</div></div>
      <div class="stat"><div class="stat-value">REST</div><div class="stat-label">+ WebSocket</div></div>
      <div class="stat"><div class="stat-value">v1.0</div><div class="stat-label">Stable</div></div>
    </div>

    <div class="section-title">📡 Core Endpoints</div>
    <div class="endpoints">
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/products</span><span class="ep-desc">Sản phẩm</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/users</span><span class="ep-desc">Người dùng</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/workers</span><span class="ep-desc">Thợ xây dựng</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/projects</span><span class="ep-desc">Dự án</span></div>
      <div class="endpoint"><span class="method post">POST</span><span class="ep-path">/api/v1/chat/messages</span><span class="ep-desc">Tin nhắn</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/orders</span><span class="ep-desc">Đơn hàng</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/materials</span><span class="ep-desc">Vật liệu</span></div>
      <div class="endpoint"><span class="method get">GET</span><span class="ep-path">/api/v1/health</span><span class="ep-desc">Health Check</span></div>
    </div>

    <div class="links">
      <a href="/api/docs" class="link primary">📖 Swagger Docs</a>
      <a href="/api/v1/health" class="link">💚 Health</a>
      <a href="/api/v1/products" class="link">🛒 Products</a>
      <a href="/api/v1/workers" class="link">👷 Workers</a>
    </div>

    <div class="footer">
      <p>© 2026 <a href="https://app.baotienweb.cloud">Baotienweb</a> • Built with NestJS + Prisma + PostgreSQL</p>
      <p style="margin-top:4px">📱 App: <a href="https://app.baotienweb.cloud">app.baotienweb.cloud</a></p>
    </div>
  </div>
</body>
</html>`;
  }
}
