/**
 * WebSocket DTOs
 * ===============
 * Validated DTOs for all WebSocket gateway message payloads.
 * Use with WsValidationPipe for automatic type checking.
 */

import { Type } from 'class-transformer';
import {
    IsArray,
    IsBoolean,
    IsInt,
    IsNotEmpty,
    IsOptional,
    IsString,
    Min,
    ValidateNested,
} from 'class-validator';

// ===================== CHAT GATEWAY =====================

export class JoinRoomDto {
  @IsInt()
  @Min(1)
  roomId: number;

  @IsInt()
  @Min(1)
  userId: number;
}

export class LeaveRoomDto {
  @IsInt()
  @Min(1)
  roomId: number;

  @IsInt()
  @Min(1)
  userId: number;
}

export class WsSendMessageDto {
  @IsInt()
  @Min(1)
  roomId: number;

  @IsString()
  @IsNotEmpty()
  content: string;

  @IsInt()
  @Min(1)
  senderId: number;

  @IsOptional()
  @IsArray()
  attachments?: any[];
}

export class TypingDto {
  @IsInt()
  @Min(1)
  roomId: number;

  @IsInt()
  @Min(1)
  userId: number;

  @IsBoolean()
  isTyping: boolean;
}

export class MarkAsReadDto {
  @IsInt()
  @Min(1)
  messageId: number;

  @IsInt()
  @Min(1)
  userId: number;

  @IsInt()
  @Min(1)
  roomId: number;
}

export class GetTypingUsersDto {
  @IsInt()
  @Min(1)
  roomId: number;
}

// ===================== CALL GATEWAY =====================

export class RegisterUserDto {
  @IsInt()
  @Min(1)
  userId: number;
}

export class JoinCallDto {
  @IsString()
  @IsNotEmpty()
  roomId: string;
}

export class LeaveCallDto {
  @IsString()
  @IsNotEmpty()
  roomId: string;
}

export class CallSignalDto {
  @IsInt()
  @Min(1)
  to: number;

  @IsNotEmpty()
  signal: any;
}

export class AcceptCallDto {
  @IsInt()
  @Min(1)
  callId: number;
}

export class RejectCallDto {
  @IsInt()
  @Min(1)
  callId: number;
}

// ===================== PROGRESS GATEWAY =====================

export class SubscribeTaskDto {
  @IsInt()
  @Min(1)
  taskId: number;
}

export class SubscribeProjectDto {
  @IsInt()
  @Min(1)
  projectId: number;
}

// ===================== REACTIONS GATEWAY =====================

export class SubscribeContentDto {
  @IsString()
  @IsNotEmpty()
  contentType: string;

  @IsInt()
  @Min(1)
  contentId: number;
}

export class BatchSubscribeContentDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => SubscribeContentDto)
  contents: SubscribeContentDto[];
}

// ===================== CONVERSATIONS GATEWAY =====================

export class ConversationJoinDto {
  @IsString()
  @IsNotEmpty()
  conversationId: string;
}

export class ConversationLeaveDto {
  @IsString()
  @IsNotEmpty()
  conversationId: string;
}

export class ConversationTypingDto {
  @IsString()
  @IsNotEmpty()
  conversationId: string;

  @IsBoolean()
  isTyping: boolean;
}

export class MessageReadDto {
  @IsString()
  @IsNotEmpty()
  conversationId: string;

  @IsOptional()
  @IsInt()
  messageId?: number;
}

// ===================== NOTIFICATIONS GATEWAY =====================

export class NotificationRegisterDto {
  @IsInt()
  @Min(1)
  userId: number;
}
