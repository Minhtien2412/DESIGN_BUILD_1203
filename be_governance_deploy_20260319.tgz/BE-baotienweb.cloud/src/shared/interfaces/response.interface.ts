/**
 * Response Interfaces
 * ====================
 * TypeScript interfaces for API responses
 */

/**
 * Base API response structure
 */
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: ApiError;
  meta?: ResponseMeta;
}

/**
 * Success response
 */
export interface SuccessResponse<T = any> {
  success: true;
  data: T;
  meta?: ResponseMeta;
}

/**
 * Error response
 */
export interface ErrorResponse {
  success: false;
  error: ApiError;
}

/**
 * API error structure
 */
export interface ApiError {
  code: string;
  message: string;
  details?: any;
  timestamp?: string;
  path?: string;
  method?: string;
  requestId?: string;
}

/**
 * Response metadata
 */
export interface ResponseMeta {
  timestamp?: string;
  version?: string;
  requestId?: string;
  pagination?: PaginationMeta;
  [key: string]: any;
}

/**
 * Pagination metadata in response
 */
interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

/**
 * List response with pagination
 */
export interface ListResponse<T> {
  success: true;
  data: T[];
  meta: ResponseMeta & {
    pagination: PaginationMeta;
  };
}

/**
 * Single item response
 */
export interface SingleResponse<T> {
  success: true;
  data: T;
  meta?: ResponseMeta;
}

/**
 * Created response
 */
export interface CreatedResponse<T> {
  success: true;
  data: T;
  meta: ResponseMeta & {
    message: string;
  };
}

/**
 * Updated response
 */
export interface UpdatedResponse<T> {
  success: true;
  data: T;
  meta: ResponseMeta & {
    message: string;
  };
}

/**
 * Deleted response
 */
export interface DeletedResponse {
  success: true;
  data: {
    id: string | number;
  };
  meta: ResponseMeta & {
    message: string;
  };
}

/**
 * Batch operation response
 */
export interface BatchResponse<T = any> {
  success: true;
  data: {
    successful: T[];
    failed: Array<{
      item: any;
      error: string;
    }>;
  };
  meta: ResponseMeta & {
    totalProcessed: number;
    successCount: number;
    failCount: number;
  };
}

/**
 * Upload response
 */
export interface UploadResponse {
  success: true;
  data: {
    url: string;
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
    width?: number;
    height?: number;
  };
  meta?: ResponseMeta;
}

/**
 * Multiple upload response
 */
export interface MultipleUploadResponse {
  success: true;
  data: Array<{
    url: string;
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
  }>;
  meta: ResponseMeta & {
    totalUploaded: number;
  };
}

/**
 * Health check response
 */
export interface HealthCheckResponse {
  success: true;
  data: {
    status: 'healthy' | 'degraded' | 'unhealthy';
    version: string;
    uptime: number;
    timestamp: string;
    services: Array<{
      name: string;
      status: 'up' | 'down';
      latency?: number;
    }>;
  };
}

/**
 * Auth response
 */
export interface AuthResponse {
  success: true;
  data: {
    user: {
      id: string | number;
      email?: string;
      phone?: string;
      name: string;
      role: string;
      permissions?: string[];
    };
    tokens: {
      accessToken: string;
      refreshToken: string;
      expiresIn: number;
      tokenType: 'Bearer';
    };
  };
}

/**
 * Error codes
 */
export enum ErrorCode {
  // Authentication
  UNAUTHORIZED = 'UNAUTHORIZED',
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',
  TOKEN_INVALID = 'TOKEN_INVALID',

  // Authorization
  FORBIDDEN = 'FORBIDDEN',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',

  // Validation
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  BAD_REQUEST = 'BAD_REQUEST',

  // Resource
  NOT_FOUND = 'NOT_FOUND',
  ALREADY_EXISTS = 'ALREADY_EXISTS',
  CONFLICT = 'CONFLICT',

  // Rate limiting
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',

  // Server
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',
  TIMEOUT = 'TIMEOUT',

  // Business logic
  BUSINESS_ERROR = 'BUSINESS_ERROR',
  INVALID_OPERATION = 'INVALID_OPERATION',
}

/**
 * HTTP status codes with descriptions
 */
export enum HttpStatusCode {
  OK = 200,
  CREATED = 201,
  ACCEPTED = 202,
  NO_CONTENT = 204,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  CONFLICT = 409,
  UNPROCESSABLE_ENTITY = 422,
  TOO_MANY_REQUESTS = 429,
  INTERNAL_SERVER_ERROR = 500,
  BAD_GATEWAY = 502,
  SERVICE_UNAVAILABLE = 503,
}
