/**
 * Pagination Interfaces
 * ======================
 * TypeScript interfaces for pagination
 */

/**
 * Pagination request parameters
 */
export interface PaginationParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  search?: string;
}

/**
 * Extended pagination params with date filters
 */
export interface PaginationWithDateParams extends PaginationParams {
  startDate?: string | Date;
  endDate?: string | Date;
  status?: string;
}

/**
 * Paginated result response
 */
export interface PaginatedResult<T> {
  data: T[];
  meta: PaginationMeta;
}

/**
 * Pagination metadata
 */
export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

/**
 * Cursor-based pagination params
 */
export interface CursorPaginationParams {
  cursor?: string;
  limit?: number;
  direction?: 'forward' | 'backward';
}

/**
 * Cursor-based pagination result
 */
export interface CursorPaginatedResult<T> {
  data: T[];
  meta: CursorPaginationMeta;
}

/**
 * Cursor pagination metadata
 */
export interface CursorPaginationMeta {
  hasMore: boolean;
  nextCursor?: string;
  previousCursor?: string;
  limit: number;
}

/**
 * Infinite scroll response (mobile-friendly)
 */
export interface InfiniteScrollResult<T> {
  data: T[];
  meta: {
    hasMore: boolean;
    nextCursor?: string;
    total?: number;
  };
}

/**
 * Order by configuration
 */
export interface OrderByConfig {
  field: string;
  direction: 'asc' | 'desc';
}

/**
 * Sort configuration for Prisma
 */
export type PrismaSortOrder = {
  [key: string]: 'asc' | 'desc' | PrismaSortOrder;
};

/**
 * Search configuration
 */
export interface SearchConfig {
  fields: string[];
  query: string;
  mode?: 'contains' | 'startsWith' | 'equals';
  caseSensitive?: boolean;
}

/**
 * Filter configuration
 */
export interface FilterConfig {
  field: string;
  operator:
    | 'equals'
    | 'contains'
    | 'startsWith'
    | 'endsWith'
    | 'gt'
    | 'gte'
    | 'lt'
    | 'lte'
    | 'in'
    | 'notIn';
  value: any;
}

/**
 * Query builder options
 */
export interface QueryBuilderOptions {
  pagination?: PaginationParams;
  search?: SearchConfig;
  filters?: FilterConfig[];
  include?: string[];
  select?: string[];
}
