/**
 * Shared Module - Reusable Node.js & NestJS Utilities
 * ====================================================
 * Export all shared utilities for easy import across the application
 * NOTE: To avoid duplicate exports, helpers have priority over interfaces/constants
 */

// Helpers (primary source for types and functions)
export * from './helpers/crypto.helper';
export * from './helpers/date.helper';
export * from './helpers/file.helper';
export * from './helpers/pagination.helper';
export * from './helpers/response.helper';
export * from './helpers/string.helper';
export * from './helpers/validation.helper';

// Decorators
export * from './decorators/api-paginated.decorator';
export * from './decorators/cache-key.decorator';
export * from './decorators/roles.decorator';
export * from './decorators/throttle.decorator';
export * from './decorators/user.decorator';

// Interceptors
export * from './interceptors/logging.interceptor';
export * from './interceptors/timeout.interceptor';
export * from './interceptors/transform.interceptor';

// Filters
export * from './filters/http-exception.filter';
export * from './filters/validation-exception.filter';

// Pipes
export * from './pipes/parse-int.pipe';
export * from './pipes/trim.pipe';

// Guards
export * from './guards/roles.guard';
export * from './guards/throttle.guard';

// Constants - Only export unique ones not already in helpers
export {
    API, ENV, FILE_UPLOAD, PAGINATION, PERMISSIONS, QUEUES, RATE_LIMIT, REGEX, ROLES, STATUS, WS_EVENTS
} from './constants/app.constants';

// Module
export { SharedModule } from './shared.module';
