/**
 * Throttle Guard
 * ===============
 * Rate limiting guard with Redis support
 */

import {
    CanActivate,
    ExecutionContext,
    HttpException,
    HttpStatus,
    Inject,
    Injectable,
    Optional,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import {
    THROTTLE_LIMIT_KEY,
    THROTTLE_SKIP_KEY,
    THROTTLE_TTL_KEY,
} from '../decorators/throttle.decorator';

// Throttle options interface
interface ThrottleOptions {
  limit: number;
  ttl: number;
  keyPrefix?: string;
  message?: string;
}

// In-memory store for simple rate limiting (fallback when Redis unavailable)
interface RateLimitEntry {
  count: number;
  expiresAt: number;
}

const memoryStore = new Map<string, RateLimitEntry>();

@Injectable()
export class ThrottleGuard implements CanActivate {
  private readonly defaultLimit = 100;
  private readonly defaultTtl = 60; // seconds

  constructor(
    private readonly reflector: Reflector,
    @Optional() @Inject('REDIS_CLIENT') private readonly redis?: any,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    // Check if throttle should be skipped
    const skip = this.reflector.getAllAndOverride<boolean>(THROTTLE_SKIP_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (skip) return true;

    // Get limit and ttl from decorators
    const limit = this.reflector.getAllAndOverride<number>(THROTTLE_LIMIT_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    const ttl = this.reflector.getAllAndOverride<number>(THROTTLE_TTL_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    // No throttle decorator, allow request
    if (!limit && !ttl) {
      return true;
    }

    const throttleOptions: ThrottleOptions = {
      limit: limit || this.defaultLimit,
      ttl: ttl || this.defaultTtl,
    };

    const request = context.switchToHttp().getRequest();
    const key = this.generateKey(request, throttleOptions.keyPrefix);

    const finalLimit = throttleOptions.limit || this.defaultLimit;
    const finalTtl = throttleOptions.ttl || this.defaultTtl;

    // Try Redis first, fallback to memory
    const { current, remaining, resetTime } = this.redis
      ? await this.checkRateLimit(key, finalLimit, finalTtl)
      : this.checkRateLimitMemory(key, finalLimit, finalTtl);

    // Set rate limit headers
    const response = context.switchToHttp().getResponse();
    response.setHeader('X-RateLimit-Limit', finalLimit);
    response.setHeader('X-RateLimit-Remaining', Math.max(0, remaining));
    response.setHeader('X-RateLimit-Reset', resetTime);

    if (current > finalLimit) {
      const retryAfter = Math.ceil((resetTime - Date.now()) / 1000);
      response.setHeader('Retry-After', retryAfter);

      throw new HttpException(
        {
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          message:
            throttleOptions.message ||
            `Quá nhiều yêu cầu. Vui lòng thử lại sau ${retryAfter} giây.`,
          error: 'Too Many Requests',
          code: 'RATE_LIMIT_EXCEEDED',
          retryAfter,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    return true;
  }

  protected generateKey(request: any, prefix?: string): string {
    const userId = request.user?.id;
    const ip = request.ip || request.headers['x-forwarded-for'] || 'unknown';
    const path = request.route?.path || request.url;

    const identifier = userId ? `user:${userId}` : `ip:${ip}`;
    const keyPrefix = prefix || 'throttle';

    return `${keyPrefix}:${identifier}:${path}`;
  }

  private async checkRateLimit(
    key: string,
    limit: number,
    ttl: number,
  ): Promise<{ current: number; remaining: number; resetTime: number }> {
    try {
      const multi = this.redis.multi();
      multi.incr(key);
      multi.ttl(key);

      const results = await multi.exec();
      const current = results[0][1] as number;
      let keyTtl = results[1][1] as number;

      // Set TTL if key is new
      if (keyTtl === -1) {
        await this.redis.expire(key, ttl);
        keyTtl = ttl;
      }

      const resetTime = Date.now() + keyTtl * 1000;
      const remaining = limit - current;

      return { current, remaining, resetTime };
    } catch (error) {
      // Fallback to memory on Redis error
      return this.checkRateLimitMemory(key, limit, ttl);
    }
  }

  private checkRateLimitMemory(
    key: string,
    limit: number,
    ttl: number,
  ): { current: number; remaining: number; resetTime: number } {
    const now = Date.now();
    const entry = memoryStore.get(key);

    // Clean expired entries periodically
    if (Math.random() < 0.01) {
      this.cleanExpiredEntries();
    }

    if (!entry || entry.expiresAt < now) {
      // New entry
      const newEntry: RateLimitEntry = {
        count: 1,
        expiresAt: now + ttl * 1000,
      };
      memoryStore.set(key, newEntry);

      return {
        current: 1,
        remaining: limit - 1,
        resetTime: newEntry.expiresAt,
      };
    }

    // Increment existing entry
    entry.count++;

    return {
      current: entry.count,
      remaining: limit - entry.count,
      resetTime: entry.expiresAt,
    };
  }

  private cleanExpiredEntries(): void {
    const now = Date.now();

    for (const [key, entry] of memoryStore.entries()) {
      if (entry.expiresAt < now) {
        memoryStore.delete(key);
      }
    }
  }
}

/**
 * IP-based throttle guard (ignores user identity)
 */
@Injectable()
export class IpThrottleGuard extends ThrottleGuard {
  protected generateKey(request: any, prefix?: string): string {
    const ip = request.ip || request.headers['x-forwarded-for'] || 'unknown';
    const path = request.route?.path || request.url;
    const keyPrefix = prefix || 'throttle-ip';

    return `${keyPrefix}:${ip}:${path}`;
  }
}

/**
 * Global throttle guard (same limit for entire endpoint)
 */
@Injectable()
export class GlobalThrottleGuard extends ThrottleGuard {
  protected generateKey(request: any, prefix?: string): string {
    const path = request.route?.path || request.url;
    const keyPrefix = prefix || 'throttle-global';

    return `${keyPrefix}:${path}`;
  }
}
