/**
 * Roles Guard
 * ============
 * RBAC authorization guard
 */

import {
    CanActivate,
    ExecutionContext,
    ForbiddenException,
    Injectable,
    UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PERMISSIONS_KEY, ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    // Get required roles from decorator
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()],
    );

    // Get required permissions from decorator
    const requiredPermissions = this.reflector.getAllAndOverride<string[]>(
      PERMISSIONS_KEY,
      [context.getHandler(), context.getClass()],
    );

    // No roles or permissions required
    if (!requiredRoles?.length && !requiredPermissions?.length) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    // No user - unauthorized
    if (!user) {
      throw new UnauthorizedException('Vui lòng đăng nhập để tiếp tục');
    }

    // Check roles
    if (requiredRoles?.length) {
      const hasRole = this.checkRoles(user, requiredRoles);

      if (!hasRole) {
        throw new ForbiddenException(
          'Bạn không có quyền truy cập chức năng này',
        );
      }
    }

    // Check permissions
    if (requiredPermissions?.length) {
      const hasPermission = this.checkPermissions(user, requiredPermissions);

      if (!hasPermission) {
        throw new ForbiddenException(
          'Bạn không có quyền thực hiện thao tác này',
        );
      }
    }

    return true;
  }

  private checkRoles(user: any, requiredRoles: string[]): boolean {
    const userRole = user.role || user.roles;

    // User has single role
    if (typeof userRole === 'string') {
      return requiredRoles.includes(userRole);
    }

    // User has multiple roles
    if (Array.isArray(userRole)) {
      return requiredRoles.some((role) => userRole.includes(role));
    }

    return false;
  }

  private checkPermissions(user: any, requiredPermissions: string[]): boolean {
    const userPermissions = user.permissions || [];

    // Admin has all permissions
    if (user.role === 'admin' || user.role === 'super_admin') {
      return true;
    }

    // Check if user has any of the required permissions
    return requiredPermissions.some((permission) =>
      userPermissions.includes(permission),
    );
  }
}

/**
 * Ownership Guard
 * Checks if user owns the resource
 */
@Injectable()
export class OwnershipGuard implements CanActivate {
  constructor(
    private readonly getUserIdFromRequest: (req: any) => string | number,
    private readonly getResourceOwnerId: (
      req: any,
    ) => string | number | Promise<string | number>,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new UnauthorizedException('Vui lòng đăng nhập để tiếp tục');
    }

    // Admin can access all resources
    if (user.role === 'admin' || user.role === 'super_admin') {
      return true;
    }

    const userId = this.getUserIdFromRequest(request);
    const resourceOwnerId = await this.getResourceOwnerId(request);

    if (String(userId) !== String(resourceOwnerId)) {
      throw new ForbiddenException(
        'Bạn không có quyền truy cập tài nguyên này',
      );
    }

    return true;
  }
}

/**
 * Factory to create ownership guard for common patterns
 */
export function createOwnershipGuard(
  resourceIdParam = 'id',
  getOwnerIdFromService?: (resourceId: string) => Promise<string | number>,
) {
  @Injectable()
  class CustomOwnershipGuard implements CanActivate {
    async canActivate(context: ExecutionContext): Promise<boolean> {
      const request = context.switchToHttp().getRequest();
      const user = request.user;

      if (!user) {
        throw new UnauthorizedException('Vui lòng đăng nhập để tiếp tục');
      }

      // Admin bypass
      if (user.role === 'admin' || user.role === 'super_admin') {
        return true;
      }

      // If resource ID matches user ID directly (e.g., /users/:id)
      const resourceId = request.params[resourceIdParam];

      if (resourceId === 'me' || String(resourceId) === String(user.id)) {
        return true;
      }

      // If we have a service to get owner ID
      if (getOwnerIdFromService) {
        const ownerId = await getOwnerIdFromService(resourceId);

        if (String(ownerId) === String(user.id)) {
          return true;
        }
      }

      throw new ForbiddenException(
        'Bạn không có quyền truy cập tài nguyên này',
      );
    }
  }

  return CustomOwnershipGuard;
}
