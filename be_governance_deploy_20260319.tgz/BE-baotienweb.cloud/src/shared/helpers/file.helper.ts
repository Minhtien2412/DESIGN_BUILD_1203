/**
 * File Helper
 * ===========
 * File handling utilities
 */

import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

// ============================================================================
// INTERFACES
// ============================================================================

export interface FileInfo {
  name: string;
  extension: string;
  mimeType: string;
  size: number;
  hash?: string;
}

export interface UploadedFile {
  originalName: string;
  filename: string;
  path: string;
  mimeType: string;
  size: number;
}

// ============================================================================
// CONSTANTS
// ============================================================================

export const MIME_TYPES: Record<string, string> = {
  // Images
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.bmp': 'image/bmp',
  '.tiff': 'image/tiff',
  '.heic': 'image/heic',

  // Documents
  '.pdf': 'application/pdf',
  '.doc': 'application/msword',
  '.docx':
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx':
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.txt': 'text/plain',
  '.csv': 'text/csv',
  '.rtf': 'application/rtf',

  // Archives
  '.zip': 'application/zip',
  '.rar': 'application/vnd.rar',
  '.7z': 'application/x-7z-compressed',
  '.tar': 'application/x-tar',
  '.gz': 'application/gzip',

  // Audio
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.m4a': 'audio/mp4',
  '.flac': 'audio/flac',

  // Video
  '.mp4': 'video/mp4',
  '.avi': 'video/x-msvideo',
  '.mov': 'video/quicktime',
  '.wmv': 'video/x-ms-wmv',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',

  // Code
  '.js': 'text/javascript',
  '.ts': 'text/typescript',
  '.json': 'application/json',
  '.xml': 'application/xml',
  '.html': 'text/html',
  '.css': 'text/css',

  // CAD/3D (construction)
  '.dwg': 'application/acad',
  '.dxf': 'application/dxf',
  '.stl': 'model/stl',
  '.obj': 'model/obj',
  '.fbx': 'application/octet-stream',
  '.ifc': 'application/x-step',
};

export const FILE_CATEGORIES = {
  IMAGE: [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    'image/bmp',
    'image/heic',
  ],
  DOCUMENT: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain',
    'text/csv',
  ],
  VIDEO: [
    'video/mp4',
    'video/quicktime',
    'video/x-msvideo',
    'video/webm',
    'video/x-matroska',
  ],
  AUDIO: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4'],
  ARCHIVE: [
    'application/zip',
    'application/vnd.rar',
    'application/x-7z-compressed',
  ],
  CAD: [
    'application/acad',
    'application/dxf',
    'model/stl',
    'application/x-step',
  ],
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get MIME type from extension
 */
export function getMimeType(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  return MIME_TYPES[ext] || 'application/octet-stream';
}

/**
 * Get extension from MIME type
 */
export function getExtensionFromMime(mimeType: string): string {
  const entry = Object.entries(MIME_TYPES).find(
    ([, mime]) => mime === mimeType,
  );
  return entry ? entry[0] : '';
}

/**
 * Check if file is image
 */
export function isImage(mimeType: string): boolean {
  return FILE_CATEGORIES.IMAGE.includes(mimeType);
}

/**
 * Check if file is video
 */
export function isVideo(mimeType: string): boolean {
  return FILE_CATEGORIES.VIDEO.includes(mimeType);
}

/**
 * Check if file is audio
 */
export function isAudio(mimeType: string): boolean {
  return FILE_CATEGORIES.AUDIO.includes(mimeType);
}

/**
 * Check if file is document
 */
export function isDocument(mimeType: string): boolean {
  return FILE_CATEGORIES.DOCUMENT.includes(mimeType);
}

/**
 * Check if file is CAD file (construction)
 */
export function isCADFile(mimeType: string): boolean {
  return FILE_CATEGORIES.CAD.includes(mimeType);
}

/**
 * Get file category
 */
export function getFileCategory(mimeType: string): string {
  if (isImage(mimeType)) return 'image';
  if (isVideo(mimeType)) return 'video';
  if (isAudio(mimeType)) return 'audio';
  if (isDocument(mimeType)) return 'document';
  if (isCADFile(mimeType)) return 'cad';
  if (FILE_CATEGORIES.ARCHIVE.includes(mimeType)) return 'archive';
  return 'other';
}

/**
 * Generate unique filename
 */
export function generateUniqueFilename(originalName: string): string {
  const ext = path.extname(originalName);
  const timestamp = Date.now();
  const random = crypto.randomBytes(8).toString('hex');
  return `${timestamp}-${random}${ext}`;
}

/**
 * Generate filename with date structure
 */
export function generateDateFilename(originalName: string): {
  filename: string;
  path: string;
} {
  const ext = path.extname(originalName);
  const now = new Date();
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  const timestamp = now.getTime();
  const random = crypto.randomBytes(4).toString('hex');

  return {
    filename: `${timestamp}-${random}${ext}`,
    path: `${year}/${month}/${day}`,
  };
}

/**
 * Sanitize filename
 */
export function sanitizeFilename(filename: string): string {
  return filename
    .replace(/[^a-zA-Z0-9.-]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

/**
 * Get file info
 */
export function getFileInfo(filePath: string): FileInfo | null {
  try {
    const stats = fs.statSync(filePath);
    const ext = path.extname(filePath).toLowerCase();

    return {
      name: path.basename(filePath),
      extension: ext,
      mimeType: MIME_TYPES[ext] || 'application/octet-stream',
      size: stats.size,
    };
  } catch {
    return null;
  }
}

/**
 * Calculate file hash (MD5)
 */
export function calculateFileHash(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('md5');
    const stream = fs.createReadStream(filePath);

    stream.on('data', (data) => hash.update(data));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

/**
 * Calculate file hash from buffer (SHA256)
 */
export function calculateBufferHash(buffer: Buffer): string {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

/**
 * Ensure directory exists
 */
export function ensureDirectory(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

/**
 * Delete file safely
 */
export function deleteFile(filePath: string): boolean {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Move file
 */
export function moveFile(source: string, destination: string): boolean {
  try {
    ensureDirectory(path.dirname(destination));
    fs.renameSync(source, destination);
    return true;
  } catch {
    // If rename fails (cross-device), try copy + delete
    try {
      fs.copyFileSync(source, destination);
      fs.unlinkSync(source);
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Copy file
 */
export function copyFile(source: string, destination: string): boolean {
  try {
    ensureDirectory(path.dirname(destination));
    fs.copyFileSync(source, destination);
    return true;
  } catch {
    return false;
  }
}

/**
 * Read file as buffer
 */
export function readFileBuffer(filePath: string): Buffer | null {
  try {
    return fs.readFileSync(filePath);
  } catch {
    return null;
  }
}

/**
 * Write buffer to file
 */
export function writeFileBuffer(filePath: string, buffer: Buffer): boolean {
  try {
    ensureDirectory(path.dirname(filePath));
    fs.writeFileSync(filePath, buffer);
    return true;
  } catch {
    return false;
  }
}

/**
 * Get directory size
 */
export function getDirectorySize(dirPath: string): number {
  let totalSize = 0;

  const files = fs.readdirSync(dirPath);

  for (const file of files) {
    const filePath = path.join(dirPath, file);
    const stats = fs.statSync(filePath);

    if (stats.isDirectory()) {
      totalSize += getDirectorySize(filePath);
    } else {
      totalSize += stats.size;
    }
  }

  return totalSize;
}

/**
 * List files in directory
 */
export function listFiles(
  dirPath: string,
  recursive: boolean = false,
  filter?: (filename: string) => boolean,
): string[] {
  const files: string[] = [];

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory() && recursive) {
      files.push(...listFiles(fullPath, recursive, filter));
    } else if (entry.isFile()) {
      if (!filter || filter(entry.name)) {
        files.push(fullPath);
      }
    }
  }

  return files;
}

/**
 * Clean old files from directory
 */
export function cleanOldFiles(
  dirPath: string,
  maxAgeMs: number,
  recursive: boolean = false,
): number {
  let deletedCount = 0;
  const now = Date.now();

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory() && recursive) {
      deletedCount += cleanOldFiles(fullPath, maxAgeMs, recursive);
    } else if (entry.isFile()) {
      const stats = fs.statSync(fullPath);
      if (now - stats.mtimeMs > maxAgeMs) {
        if (deleteFile(fullPath)) {
          deletedCount++;
        }
      }
    }
  }

  return deletedCount;
}

/**
 * Get file extension from path
 */
export function getExtension(filePath: string): string {
  return path.extname(filePath).toLowerCase().slice(1);
}

/**
 * Get filename without extension
 */
export function getBasename(filePath: string): string {
  return path.basename(filePath, path.extname(filePath));
}
