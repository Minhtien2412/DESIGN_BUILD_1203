/**
 * Crypto Helper
 * =============
 * Encryption, hashing, and security utilities
 */

import * as bcrypt from 'bcryptjs';
import * as crypto from 'crypto';

// ============================================================================
// CONSTANTS
// ============================================================================

const DEFAULT_SALT_ROUNDS = 12;
const AES_ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;

// ============================================================================
// HASH FUNCTIONS
// ============================================================================

/**
 * Hash password using bcrypt
 */
export async function hashPassword(
  password: string,
  saltRounds: number = DEFAULT_SALT_ROUNDS,
): Promise<string> {
  return bcrypt.hash(password, saltRounds);
}

/**
 * Compare password with hash
 */
export async function comparePassword(
  password: string,
  hash: string,
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Generate MD5 hash
 */
export function md5(data: string | Buffer): string {
  return crypto.createHash('md5').update(data).digest('hex');
}

/**
 * Generate SHA256 hash
 */
export function sha256(data: string | Buffer): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Generate SHA512 hash
 */
export function sha512(data: string | Buffer): string {
  return crypto.createHash('sha512').update(data).digest('hex');
}

/**
 * Generate HMAC SHA256
 */
export function hmacSha256(data: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(data).digest('hex');
}

/**
 * Generate HMAC SHA512
 */
export function hmacSha512(data: string, secret: string): string {
  return crypto.createHmac('sha512', secret).update(data).digest('hex');
}

// ============================================================================
// ENCRYPTION FUNCTIONS
// ============================================================================

/**
 * Encrypt data using AES-256-GCM
 */
export function encrypt(text: string, key: string): string {
  // Ensure key is 32 bytes
  const keyBuffer = crypto.createHash('sha256').update(key).digest();
  const iv = crypto.randomBytes(IV_LENGTH);

  const cipher = crypto.createCipheriv(AES_ALGORITHM, keyBuffer, iv);

  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const authTag = cipher.getAuthTag();

  // Combine IV + auth tag + encrypted data
  return iv.toString('hex') + authTag.toString('hex') + encrypted;
}

/**
 * Decrypt data using AES-256-GCM
 */
export function decrypt(encryptedData: string, key: string): string {
  const keyBuffer = crypto.createHash('sha256').update(key).digest();

  const iv = Buffer.from(encryptedData.slice(0, IV_LENGTH * 2), 'hex');
  const authTag = Buffer.from(
    encryptedData.slice(IV_LENGTH * 2, (IV_LENGTH + TAG_LENGTH) * 2),
    'hex',
  );
  const encrypted = encryptedData.slice((IV_LENGTH + TAG_LENGTH) * 2);

  const decipher = crypto.createDecipheriv(AES_ALGORITHM, keyBuffer, iv);
  decipher.setAuthTag(authTag);

  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

/**
 * Encrypt object to string
 */
export function encryptObject<T>(obj: T, key: string): string {
  return encrypt(JSON.stringify(obj), key);
}

/**
 * Decrypt string to object
 */
export function decryptObject<T>(encryptedData: string, key: string): T {
  const decrypted = decrypt(encryptedData, key);
  return JSON.parse(decrypted);
}

// ============================================================================
// RANDOM GENERATION
// ============================================================================

/**
 * Generate random bytes
 */
export function randomBytes(length: number = 32): Buffer {
  return crypto.randomBytes(length);
}

/**
 * Generate random hex string
 */
export function randomHex(length: number = 32): string {
  return crypto
    .randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length);
}

/**
 * Generate random base64 string
 */
export function randomBase64(length: number = 32): string {
  return crypto
    .randomBytes(Math.ceil(length * 0.75))
    .toString('base64')
    .slice(0, length);
}

/**
 * Generate UUID v4
 */
export function uuid(): string {
  return crypto.randomUUID();
}

/**
 * Generate secure random token
 */
export function generateToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('base64url');
}

/**
 * Generate OTP (One-Time Password)
 */
export function generateOTP(length: number = 6): string {
  const digits = '0123456789';
  let otp = '';
  const bytes = crypto.randomBytes(length);

  for (let i = 0; i < length; i++) {
    otp += digits[bytes[i] % 10];
  }

  return otp;
}

/**
 * Generate secure PIN
 */
export function generatePIN(length: number = 4): string {
  return generateOTP(length);
}

/**
 * Generate API key
 */
export function generateApiKey(prefix: string = 'sk'): string {
  const timestamp = Date.now().toString(36);
  const random = randomHex(24);
  return `${prefix}_${timestamp}_${random}`;
}

/**
 * Generate secret key
 */
export function generateSecretKey(length: number = 64): string {
  return crypto.randomBytes(length).toString('base64');
}

// ============================================================================
// VERIFICATION
// ============================================================================

/**
 * Generate verification code (alphanumeric)
 */
export function generateVerificationCode(length: number = 8): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Excluded similar chars
  let code = '';
  const bytes = crypto.randomBytes(length);

  for (let i = 0; i < length; i++) {
    code += chars[bytes[i] % chars.length];
  }

  return code;
}

/**
 * Generate referral code
 */
export function generateReferralCode(userId: number | string): string {
  const userHash = md5(String(userId)).slice(0, 6).toUpperCase();
  const random = randomHex(4).toUpperCase();
  return `${userHash}${random}`;
}

// ============================================================================
// SIGNATURE
// ============================================================================

/**
 * Create signature for data
 */
export function createSignature(data: string, secret: string): string {
  return hmacSha256(data, secret);
}

/**
 * Verify signature
 */
export function verifySignature(
  data: string,
  signature: string,
  secret: string,
): boolean {
  const expectedSignature = createSignature(data, secret);
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature),
  );
}

/**
 * Create JWT-like signed payload (simplified)
 */
export function signPayload<T>(
  payload: T,
  secret: string,
  expiresIn?: number,
): string {
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);

  const fullPayload = {
    ...payload,
    iat: now,
    ...(expiresIn ? { exp: now + expiresIn } : {}),
  };

  const headerBase64 = Buffer.from(JSON.stringify(header)).toString(
    'base64url',
  );
  const payloadBase64 = Buffer.from(JSON.stringify(fullPayload)).toString(
    'base64url',
  );
  const signature = hmacSha256(`${headerBase64}.${payloadBase64}`, secret);

  return `${headerBase64}.${payloadBase64}.${Buffer.from(signature).toString('base64url')}`;
}

/**
 * Verify and decode signed payload
 */
export function verifyPayload<T>(token: string, secret: string): T | null {
  try {
    const [headerBase64, payloadBase64, signatureBase64] = token.split('.');

    const expectedSignature = hmacSha256(
      `${headerBase64}.${payloadBase64}`,
      secret,
    );
    const signature = Buffer.from(signatureBase64, 'base64url').toString();

    if (
      !crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expectedSignature),
      )
    ) {
      return null;
    }

    const payload = JSON.parse(
      Buffer.from(payloadBase64, 'base64url').toString(),
    );

    // Check expiration
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return payload as T;
  } catch {
    return null;
  }
}

// ============================================================================
// UTILITY
// ============================================================================

/**
 * Constant-time string comparison
 */
export function secureCompare(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

/**
 * Generate checksum
 */
export function generateChecksum(data: string | Buffer): string {
  return crypto.createHash('crc32c').update(data).digest('hex');
}

/**
 * Derive key from password (PBKDF2)
 */
export function deriveKey(
  password: string,
  salt: string | Buffer,
  iterations: number = 100000,
  keyLength: number = 32,
): Buffer {
  const saltBuffer = typeof salt === 'string' ? Buffer.from(salt) : salt;
  return crypto.pbkdf2Sync(
    password,
    saltBuffer,
    iterations,
    keyLength,
    'sha512',
  );
}
