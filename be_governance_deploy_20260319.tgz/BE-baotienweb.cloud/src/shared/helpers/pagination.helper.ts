/**
 * Pagination Helper
 * =================
 * Reusable pagination utilities for all list endpoints
 */


// ============================================================================
// INTERFACES
// ============================================================================

export interface PaginationParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

export interface CursorPaginationParams {
  cursor?: string;
  limit?: number;
  direction?: 'forward' | 'backward';
}

export interface CursorPaginatedResult<T> {
  data: T[];
  meta: {
    hasMore: boolean;
    nextCursor?: string;
    prevCursor?: string;
    total?: number;
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Calculate pagination offset
 */
export function getOffset(page: number, limit: number): number {
  return (Math.max(1, page) - 1) * limit;
}

/**
 * Calculate total pages
 */
export function getTotalPages(total: number, limit: number): number {
  return Math.ceil(total / limit);
}

/**
 * Create paginated response
 */
export function paginate<T>(
  data: T[],
  total: number,
  page: number,
  limit: number,
): PaginatedResult<T> {
  const totalPages = getTotalPages(total, limit);

  return {
    data,
    meta: {
      total,
      page,
      limit,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
    },
  };
}

/**
 * Parse pagination params with defaults
 */
export function parsePaginationParams(
  params: PaginationParams,
  defaults: { page?: number; limit?: number; maxLimit?: number } = {},
): { skip: number; take: number; page: number; limit: number } {
  const {
    page: defaultPage = 1,
    limit: defaultLimit = 20,
    maxLimit = 100,
  } = defaults;

  const page = Math.max(1, params.page || defaultPage);
  const limit = Math.min(maxLimit, Math.max(1, params.limit || defaultLimit));

  return {
    skip: getOffset(page, limit),
    take: limit,
    page,
    limit,
  };
}

/**
 * Build Prisma orderBy from params
 */
export function buildOrderBy(
  sortBy?: string,
  sortOrder: 'asc' | 'desc' = 'desc',
  allowedFields: string[] = [],
  defaultField: string = 'createdAt',
): Record<string, 'asc' | 'desc'> {
  const field =
    sortBy && allowedFields.includes(sortBy) ? sortBy : defaultField;
  return { [field]: sortOrder };
}

/**
 * Build cursor-based pagination for Prisma
 */
export function buildCursorPagination(
  cursor?: string,
  limit: number = 20,
  idField: string = 'id',
): { cursor?: Record<string, any>; take: number; skip?: number } {
  if (!cursor) {
    return { take: limit + 1 }; // +1 to check hasMore
  }

  return {
    cursor: { [idField]: cursor },
    take: limit + 1,
    skip: 1, // Skip the cursor item
  };
}

/**
 * Process cursor pagination result
 */
export function processCursorResult<T extends { id?: any }>(
  data: T[],
  limit: number,
  idField: keyof T = 'id' as keyof T,
): CursorPaginatedResult<T> {
  const hasMore = data.length > limit;
  const items = hasMore ? data.slice(0, limit) : data;

  return {
    data: items,
    meta: {
      hasMore,
      nextCursor:
        hasMore && items.length > 0
          ? String(items[items.length - 1][idField])
          : undefined,
    },
  };
}

/**
 * Infinite scroll pagination helper
 */
export function buildInfiniteScrollParams(
  lastId?: number | string,
  limit: number = 20,
): {
  where?: { id: { lt: number | string } };
  take: number;
  orderBy: { id: 'desc' };
} {
  return {
    ...(lastId ? { where: { id: { lt: lastId } } } : {}),
    take: limit,
    orderBy: { id: 'desc' as const },
  };
}
