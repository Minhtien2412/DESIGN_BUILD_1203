/**
 * Response Helper
 * ===============
 * Standardized API response utilities
 */

// ============================================================================
// INTERFACES
// ============================================================================

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    timestamp: string;
    requestId?: string;
    version?: string;
    [key: string]: any;
  };
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  meta: {
    timestamp: string;
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
    [key: string]: any;
  };
}

export interface ErrorResponse extends ApiResponse<never> {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
    stack?: string;
  };
}

// ============================================================================
// ERROR CODES
// ============================================================================

export const ERROR_CODES = {
  // Authentication
  UNAUTHORIZED: 'UNAUTHORIZED',
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  TOKEN_INVALID: 'TOKEN_INVALID',
  SESSION_EXPIRED: 'SESSION_EXPIRED',

  // Authorization
  FORBIDDEN: 'FORBIDDEN',
  INSUFFICIENT_PERMISSIONS: 'INSUFFICIENT_PERMISSIONS',

  // Validation
  BAD_REQUEST: 'BAD_REQUEST',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_INPUT: 'INVALID_INPUT',
  MISSING_REQUIRED_FIELD: 'MISSING_REQUIRED_FIELD',

  // Resource
  NOT_FOUND: 'NOT_FOUND',
  ALREADY_EXISTS: 'ALREADY_EXISTS',
  CONFLICT: 'CONFLICT',

  // Rate Limiting
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  TOO_MANY_REQUESTS: 'TOO_MANY_REQUESTS',

  // Server
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
  DATABASE_ERROR: 'DATABASE_ERROR',
  EXTERNAL_SERVICE_ERROR: 'EXTERNAL_SERVICE_ERROR',

  // Business Logic
  INVALID_OPERATION: 'INVALID_OPERATION',
  INSUFFICIENT_BALANCE: 'INSUFFICIENT_BALANCE',
  EXPIRED: 'EXPIRED',
  CANCELLED: 'CANCELLED',

  // File
  FILE_TOO_LARGE: 'FILE_TOO_LARGE',
  INVALID_FILE_TYPE: 'INVALID_FILE_TYPE',
  UPLOAD_FAILED: 'UPLOAD_FAILED',
} as const;

export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];

// ============================================================================
// SUCCESS MESSAGES (Vietnamese)
// ============================================================================

export const SUCCESS_MESSAGES = {
  // CRUD
  CREATED: 'Tạo mới thành công',
  UPDATED: 'Cập nhật thành công',
  DELETED: 'Xóa thành công',
  FETCHED: 'Lấy dữ liệu thành công',

  // Auth
  LOGIN_SUCCESS: 'Đăng nhập thành công',
  LOGOUT_SUCCESS: 'Đăng xuất thành công',
  REGISTER_SUCCESS: 'Đăng ký thành công',
  PASSWORD_CHANGED: 'Đổi mật khẩu thành công',
  EMAIL_VERIFIED: 'Xác thực email thành công',
  OTP_SENT: 'Mã OTP đã được gửi',

  // Actions
  SUBMITTED: 'Gửi yêu cầu thành công',
  APPROVED: 'Phê duyệt thành công',
  REJECTED: 'Từ chối thành công',
  CANCELLED: 'Hủy thành công',
  COMPLETED: 'Hoàn thành thành công',

  // Upload
  UPLOAD_SUCCESS: 'Tải lên thành công',

  // Generic
  SUCCESS: 'Thành công',
} as const;

// ============================================================================
// ERROR MESSAGES (Vietnamese)
// ============================================================================

export const ERROR_MESSAGES: Record<ErrorCode, string> = {
  UNAUTHORIZED: 'Vui lòng đăng nhập để tiếp tục',
  INVALID_CREDENTIALS: 'Thông tin đăng nhập không chính xác',
  TOKEN_EXPIRED: 'Phiên đăng nhập đã hết hạn',
  TOKEN_INVALID: 'Token không hợp lệ',
  SESSION_EXPIRED: 'Phiên làm việc đã hết hạn',
  FORBIDDEN: 'Bạn không có quyền thực hiện thao tác này',
  INSUFFICIENT_PERMISSIONS: 'Bạn không có đủ quyền truy cập',
  BAD_REQUEST: 'Yêu cầu không hợp lệ',
  VALIDATION_ERROR: 'Dữ liệu không hợp lệ',
  INVALID_INPUT: 'Dữ liệu đầu vào không hợp lệ',
  MISSING_REQUIRED_FIELD: 'Thiếu thông tin bắt buộc',
  NOT_FOUND: 'Không tìm thấy dữ liệu',
  ALREADY_EXISTS: 'Dữ liệu đã tồn tại',
  CONFLICT: 'Xung đột dữ liệu',
  RATE_LIMIT_EXCEEDED: 'Vượt quá giới hạn truy cập',
  TOO_MANY_REQUESTS: 'Quá nhiều yêu cầu, vui lòng thử lại sau',
  INTERNAL_ERROR: 'Lỗi hệ thống, vui lòng thử lại sau',
  SERVICE_UNAVAILABLE: 'Dịch vụ tạm thời không khả dụng',
  DATABASE_ERROR: 'Lỗi cơ sở dữ liệu',
  EXTERNAL_SERVICE_ERROR: 'Lỗi dịch vụ bên ngoài',
  INVALID_OPERATION: 'Thao tác không hợp lệ',
  INSUFFICIENT_BALANCE: 'Số dư không đủ',
  EXPIRED: 'Đã hết hạn',
  CANCELLED: 'Đã bị hủy',
  FILE_TOO_LARGE: 'File quá lớn',
  INVALID_FILE_TYPE: 'Loại file không được hỗ trợ',
  UPLOAD_FAILED: 'Tải lên thất bại',
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Create success response
 */
export function success<T>(
  data: T,
  message?: string,
  meta?: Record<string, any>,
): ApiResponse<T> {
  return {
    success: true,
    message: message || SUCCESS_MESSAGES.SUCCESS,
    data,
    meta: {
      timestamp: new Date().toISOString(),
      ...meta,
    },
  };
}

/**
 * Create paginated response
 */
export function paginated<T>(
  data: T[],
  total: number,
  page: number,
  limit: number,
  message?: string,
): PaginatedResponse<T> {
  const totalPages = Math.ceil(total / limit);

  return {
    success: true,
    message: message || SUCCESS_MESSAGES.FETCHED,
    data,
    meta: {
      timestamp: new Date().toISOString(),
      total,
      page,
      limit,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
    },
  };
}

/**
 * Create error response
 */
export function error(
  code: ErrorCode,
  message?: string,
  details?: any,
): ErrorResponse {
  return {
    success: false,
    error: {
      code,
      message: message || ERROR_MESSAGES[code],
      details,
    },
    meta: {
      timestamp: new Date().toISOString(),
    },
  };
}

/**
 * Create created response (201)
 */
export function created<T>(data: T, message?: string): ApiResponse<T> {
  return success(data, message || SUCCESS_MESSAGES.CREATED);
}

/**
 * Create updated response
 */
export function updated<T>(data: T, message?: string): ApiResponse<T> {
  return success(data, message || SUCCESS_MESSAGES.UPDATED);
}

/**
 * Create deleted response
 */
export function deleted(message?: string): ApiResponse<{ deleted: true }> {
  return success({ deleted: true }, message || SUCCESS_MESSAGES.DELETED);
}

/**
 * Create not found error
 */
export function notFound(resource?: string): ErrorResponse {
  const message = resource
    ? `Không tìm thấy ${resource}`
    : ERROR_MESSAGES.NOT_FOUND;
  return error(ERROR_CODES.NOT_FOUND, message);
}

/**
 * Create validation error
 */
export function validationError(
  errors: Record<string, string[]>,
  message?: string,
): ErrorResponse {
  return error(
    ERROR_CODES.VALIDATION_ERROR,
    message || ERROR_MESSAGES.VALIDATION_ERROR,
    { errors },
  );
}

/**
 * Create unauthorized error
 */
export function unauthorized(message?: string): ErrorResponse {
  return error(ERROR_CODES.UNAUTHORIZED, message);
}

/**
 * Create forbidden error
 */
export function forbidden(message?: string): ErrorResponse {
  return error(ERROR_CODES.FORBIDDEN, message);
}

/**
 * Create internal error
 */
export function internalError(message?: string, details?: any): ErrorResponse {
  return error(ERROR_CODES.INTERNAL_ERROR, message, details);
}

/**
 * Create rate limit error
 */
export function rateLimitExceeded(retryAfter?: number): ErrorResponse {
  return error(
    ERROR_CODES.RATE_LIMIT_EXCEEDED,
    ERROR_MESSAGES.RATE_LIMIT_EXCEEDED,
    retryAfter ? { retryAfter } : undefined,
  );
}

/**
 * Wrap async handler to catch errors
 */
export function wrapHandler<T>(
  handler: () => Promise<T>,
  errorHandler?: (err: Error) => ErrorResponse,
): Promise<ApiResponse<T>> {
  return handler()
    .then((data) => success(data))
    .catch((err) => {
      if (errorHandler) {
        return errorHandler(err);
      }
      console.error('Handler error:', err);
      return internalError();
    });
}
