/**
 * Validation Helper
 * =================
 * Input validation utilities
 */

// ============================================================================
// REGEX PATTERNS
// ============================================================================

export const PATTERNS = {
  // Basic
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  URL: /^https?:\/\/[^\s/$.?#].[^\s]*$/,
  UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,

  // Vietnamese specific
  PHONE_VN: /^(0|\+84)(3|5|7|8|9)[0-9]{8}$/,
  CMND: /^[0-9]{9}$/,
  CCCD: /^[0-9]{12}$/,
  TAX_CODE: /^[0-9]{10}(-[0-9]{3})?$/,

  // Numbers
  INTEGER: /^-?\d+$/,
  POSITIVE_INTEGER: /^\d+$/,
  DECIMAL: /^-?\d+(\.\d+)?$/,
  POSITIVE_DECIMAL: /^\d+(\.\d+)?$/,

  // Security
  STRONG_PASSWORD:
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/,
  MEDIUM_PASSWORD: /^(?=.*[a-zA-Z])(?=.*\d)[A-Za-z\d@$!%*?&#]{6,}$/,

  // Dates
  DATE_ISO: /^\d{4}-\d{2}-\d{2}$/,
  DATE_VN: /^\d{2}\/\d{2}\/\d{4}$/,
  DATETIME_ISO: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z?$/,

  // Code/Identifiers
  ALPHANUMERIC: /^[a-zA-Z0-9]+$/,
  SLUG: /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
  USERNAME: /^[a-zA-Z0-9_]{3,30}$/,

  // File
  FILE_NAME: /^[a-zA-Z0-9_\-. ]+$/,
  IMAGE_EXT: /\.(jpg|jpeg|png|gif|webp|svg|bmp)$/i,
  DOCUMENT_EXT: /\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv)$/i,

  // Construction specific
  CONTRACT_NO: /^HD-\d{4}-\d{4}$/,
  PROJECT_CODE: /^DA-\d{4}-\d{4}$/,
  WORKER_CODE: /^TN-\d{6}$/,
};

// ============================================================================
// VALIDATION FUNCTIONS
// ============================================================================

/**
 * Check if value is empty
 */
export function isEmpty(value: any): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return false;
}

/**
 * Check if value is not empty
 */
export function isNotEmpty(value: any): boolean {
  return !isEmpty(value);
}

/**
 * Validate email
 */
export function isEmail(email: string): boolean {
  return PATTERNS.EMAIL.test(email);
}

/**
 * Validate URL
 */
export function isURL(url: string): boolean {
  return PATTERNS.URL.test(url);
}

/**
 * Validate UUID
 */
export function isUUID(uuid: string): boolean {
  return PATTERNS.UUID.test(uuid);
}

/**
 * Validate Vietnamese phone number
 */
export function isVietnamesePhone(phone: string): boolean {
  const normalized = phone.replace(/\s/g, '');
  return PATTERNS.PHONE_VN.test(normalized);
}

/**
 * Validate Vietnamese ID card (CMND)
 */
export function isCMND(id: string): boolean {
  return PATTERNS.CMND.test(id);
}

/**
 * Validate Vietnamese citizen ID (CCCD)
 */
export function isCCCD(id: string): boolean {
  return PATTERNS.CCCD.test(id);
}

/**
 * Validate Vietnamese tax code
 */
export function isTaxCode(taxCode: string): boolean {
  return PATTERNS.TAX_CODE.test(taxCode);
}

/**
 * Validate integer
 */
export function isInteger(value: string | number): boolean {
  if (typeof value === 'number') return Number.isInteger(value);
  return PATTERNS.INTEGER.test(String(value));
}

/**
 * Validate positive integer
 */
export function isPositiveInteger(value: string | number): boolean {
  if (typeof value === 'number') return Number.isInteger(value) && value > 0;
  return (
    PATTERNS.POSITIVE_INTEGER.test(String(value)) &&
    parseInt(String(value), 10) > 0
  );
}

/**
 * Validate decimal
 */
export function isDecimal(value: string | number): boolean {
  if (typeof value === 'number') return !isNaN(value);
  return PATTERNS.DECIMAL.test(String(value));
}

/**
 * Validate number in range
 */
export function isInRange(value: number, min: number, max: number): boolean {
  return value >= min && value <= max;
}

/**
 * Validate string length
 */
export function isLength(str: string, min: number, max?: number): boolean {
  const len = str.length;
  if (max !== undefined) {
    return len >= min && len <= max;
  }
  return len >= min;
}

/**
 * Validate min length
 */
export function minLength(str: string, min: number): boolean {
  return str.length >= min;
}

/**
 * Validate max length
 */
export function maxLength(str: string, max: number): boolean {
  return str.length <= max;
}

/**
 * Validate strong password
 */
export function isStrongPassword(password: string): boolean {
  return PATTERNS.STRONG_PASSWORD.test(password);
}

/**
 * Validate medium password
 */
export function isMediumPassword(password: string): boolean {
  return PATTERNS.MEDIUM_PASSWORD.test(password);
}

/**
 * Validate alphanumeric
 */
export function isAlphanumeric(str: string): boolean {
  return PATTERNS.ALPHANUMERIC.test(str);
}

/**
 * Validate slug
 */
export function isSlug(str: string): boolean {
  return PATTERNS.SLUG.test(str);
}

/**
 * Validate username
 */
export function isUsername(username: string): boolean {
  return PATTERNS.USERNAME.test(username);
}

/**
 * Validate date string (ISO format)
 */
export function isDateISO(date: string): boolean {
  return PATTERNS.DATE_ISO.test(date) && !isNaN(Date.parse(date));
}

/**
 * Validate date string (Vietnamese format)
 */
export function isDateVN(date: string): boolean {
  if (!PATTERNS.DATE_VN.test(date)) return false;

  const [day, month, year] = date.split('/').map(Number);
  const d = new Date(year, month - 1, day);

  return (
    d.getDate() === day &&
    d.getMonth() === month - 1 &&
    d.getFullYear() === year
  );
}

/**
 * Validate array
 */
export function isArray(value: any): value is any[] {
  return Array.isArray(value);
}

/**
 * Validate array with min length
 */
export function isArrayMinLength(value: any[], min: number): boolean {
  return Array.isArray(value) && value.length >= min;
}

/**
 * Validate array with max length
 */
export function isArrayMaxLength(value: any[], max: number): boolean {
  return Array.isArray(value) && value.length <= max;
}

/**
 * Validate value in list
 */
export function isIn<T>(value: T, list: T[]): boolean {
  return list.includes(value);
}

/**
 * Validate value not in list
 */
export function isNotIn<T>(value: T, list: T[]): boolean {
  return !list.includes(value);
}

/**
 * Validate matches pattern
 */
export function matches(str: string, pattern: RegExp): boolean {
  return pattern.test(str);
}

/**
 * Validate equals
 */
export function equals(value: any, comparison: any): boolean {
  return value === comparison;
}

/**
 * Validate credit card (basic Luhn algorithm)
 */
export function isCreditCard(number: string): boolean {
  const digits = number.replace(/\D/g, '');

  if (digits.length < 13 || digits.length > 19) return false;

  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate JSON string
 */
export function isJSON(str: string): boolean {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
}

/**
 * Validate base64 string
 */
export function isBase64(str: string): boolean {
  try {
    return btoa(atob(str)) === str;
  } catch {
    return false;
  }
}

/**
 * Validate image file extension
 */
export function isImageFile(filename: string): boolean {
  return PATTERNS.IMAGE_EXT.test(filename);
}

/**
 * Validate document file extension
 */
export function isDocumentFile(filename: string): boolean {
  return PATTERNS.DOCUMENT_EXT.test(filename);
}

// ============================================================================
// VALIDATION RESULT TYPE
// ============================================================================

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string[]>;
}

/**
 * Validate object with rules
 */
export function validateObject<T extends Record<string, any>>(
  obj: T,
  rules: Record<keyof T, Array<(value: any) => string | null>>,
): ValidationResult {
  const errors: Record<string, string[]> = {};

  for (const [field, fieldRules] of Object.entries(rules)) {
    const value = obj[field];
    const fieldErrors: string[] = [];

    for (const rule of fieldRules as Array<(value: any) => string | null>) {
      const error = rule(value);
      if (error) {
        fieldErrors.push(error);
      }
    }

    if (fieldErrors.length > 0) {
      errors[field] = fieldErrors;
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

// ============================================================================
// VALIDATION RULE FACTORIES
// ============================================================================

export const rules = {
  required:
    (message = 'Trường này bắt buộc') =>
    (value: any) =>
      isEmpty(value) ? message : null,

  email:
    (message = 'Email không hợp lệ') =>
    (value: string) =>
      value && !isEmail(value) ? message : null,

  phone:
    (message = 'Số điện thoại không hợp lệ') =>
    (value: string) =>
      value && !isVietnamesePhone(value) ? message : null,

  min: (min: number, message?: string) => (value: number) =>
    value < min ? message || `Giá trị phải lớn hơn hoặc bằng ${min}` : null,

  max: (max: number, message?: string) => (value: number) =>
    value > max ? message || `Giá trị phải nhỏ hơn hoặc bằng ${max}` : null,

  minLength: (min: number, message?: string) => (value: string) =>
    value && value.length < min
      ? message || `Độ dài tối thiểu ${min} ký tự`
      : null,

  maxLength: (max: number, message?: string) => (value: string) =>
    value && value.length > max
      ? message || `Độ dài tối đa ${max} ký tự`
      : null,

  pattern:
    (pattern: RegExp, message = 'Định dạng không hợp lệ') =>
    (value: string) =>
      value && !pattern.test(value) ? message : null,

  oneOf:
    <T>(list: T[], message?: string) =>
    (value: T) =>
      !isIn(value, list)
        ? message || `Giá trị phải là một trong: ${list.join(', ')}`
        : null,
};
