/**
 * Application Constants
 * ======================
 * Centralized constants for the entire application
 */

// ===================
// Environment
// ===================
export const ENV = {
  DEVELOPMENT: 'development',
  STAGING: 'staging',
  PRODUCTION: 'production',
  TEST: 'test',
} as const;

// ===================
// Pagination
// ===================
export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 100,
  DEFAULT_SORT_ORDER: 'desc' as const,
} as const;

// ===================
// Cache TTL (in seconds)
// ===================
export const CACHE_TTL = {
  SHORT: 60, // 1 minute
  DEFAULT: 300, // 5 minutes
  MEDIUM: 900, // 15 minutes
  LONG: 3600, // 1 hour
  VERY_LONG: 86400, // 24 hours
  WEEK: 604800, // 7 days
} as const;

// ===================
// Rate Limiting
// ===================
export const RATE_LIMIT = {
  // General API
  GENERAL: { limit: 100, ttl: 60 },

  // Authentication
  LOGIN: { limit: 5, ttl: 300 },
  REGISTER: { limit: 3, ttl: 3600 },
  OTP: { limit: 5, ttl: 300 },
  PASSWORD_RESET: { limit: 3, ttl: 3600 },

  // Resource intensive
  UPLOAD: { limit: 10, ttl: 60 },
  SEARCH: { limit: 30, ttl: 60 },
  EXPORT: { limit: 5, ttl: 300 },
} as const;

// ===================
// File Upload
// ===================
export const FILE_UPLOAD = {
  // Size limits (in bytes)
  MAX_SIZE: {
    IMAGE: 5 * 1024 * 1024, // 5MB
    VIDEO: 100 * 1024 * 1024, // 100MB
    DOCUMENT: 20 * 1024 * 1024, // 20MB
    CAD: 50 * 1024 * 1024, // 50MB
    AVATAR: 2 * 1024 * 1024, // 2MB
  },

  // Allowed MIME types
  ALLOWED_TYPES: {
    IMAGE: [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/svg+xml',
    ],
    VIDEO: ['video/mp4', 'video/webm', 'video/quicktime'],
    DOCUMENT: [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ],
    CAD: [
      'application/dxf',
      'application/dwg',
      'image/vnd.dwg',
      'image/vnd.dxf',
    ],
  },

  // Storage paths
  PATHS: {
    AVATARS: 'avatars',
    PRODUCTS: 'products',
    PROJECTS: 'projects',
    DOCUMENTS: 'documents',
    CAD_FILES: 'cad',
    TEMP: 'temp',
  },
} as const;

// ===================
// User Roles
// ===================
export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  MANAGER: 'manager',
  STAFF: 'staff',
  USER: 'user',
  GUEST: 'guest',

  // Construction-specific
  PROJECT_MANAGER: 'project_manager',
  SITE_SUPERVISOR: 'site_supervisor',
  FOREMAN: 'foreman',
  WORKER: 'worker',
  QC_INSPECTOR: 'qc_inspector',
  ARCHITECT: 'architect',
  ENGINEER: 'engineer',
  CLIENT: 'client',
  CONTRACTOR: 'contractor',
} as const;

// ===================
// Permissions
// ===================
export const PERMISSIONS = {
  // User management
  USERS_VIEW: 'users.view',
  USERS_CREATE: 'users.create',
  USERS_UPDATE: 'users.update',
  USERS_DELETE: 'users.delete',

  // Project management
  PROJECTS_VIEW: 'projects.view',
  PROJECTS_CREATE: 'projects.create',
  PROJECTS_UPDATE: 'projects.update',
  PROJECTS_DELETE: 'projects.delete',

  // Tasks
  TASKS_VIEW: 'tasks.view',
  TASKS_CREATE: 'tasks.create',
  TASKS_UPDATE: 'tasks.update',
  TASKS_DELETE: 'tasks.delete',
  TASKS_ASSIGN: 'tasks.assign',

  // Workers
  WORKERS_VIEW: 'workers.view',
  WORKERS_CREATE: 'workers.create',
  WORKERS_UPDATE: 'workers.update',
  WORKERS_DELETE: 'workers.delete',

  // Finance
  FINANCE_VIEW: 'finance.view',
  FINANCE_CREATE: 'finance.create',
  FINANCE_APPROVE: 'finance.approve',

  // Reports
  REPORTS_VIEW: 'reports.view',
  REPORTS_EXPORT: 'reports.export',

  // Settings
  SETTINGS_VIEW: 'settings.view',
  SETTINGS_UPDATE: 'settings.update',
} as const;

// ===================
// Status
// ===================
export const STATUS = {
  // General
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  PENDING: 'pending',
  DELETED: 'deleted',

  // Orders
  ORDER_PENDING: 'pending',
  ORDER_CONFIRMED: 'confirmed',
  ORDER_PROCESSING: 'processing',
  ORDER_SHIPPED: 'shipped',
  ORDER_DELIVERED: 'delivered',
  ORDER_CANCELLED: 'cancelled',
  ORDER_REFUNDED: 'refunded',

  // Projects
  PROJECT_DRAFT: 'draft',
  PROJECT_PLANNING: 'planning',
  PROJECT_IN_PROGRESS: 'in_progress',
  PROJECT_ON_HOLD: 'on_hold',
  PROJECT_COMPLETED: 'completed',
  PROJECT_CANCELLED: 'cancelled',

  // Tasks
  TASK_TODO: 'todo',
  TASK_IN_PROGRESS: 'in_progress',
  TASK_REVIEW: 'review',
  TASK_DONE: 'done',
  TASK_BLOCKED: 'blocked',
} as const;

// ===================
// Regex Patterns
// ===================
export const REGEX = {
  // Vietnam-specific
  PHONE_VN: /^(0|\+84)(3|5|7|8|9)[0-9]{8}$/,
  CMND: /^\d{9}$|^\d{12}$/,
  CCCD: /^\d{12}$/,
  TAX_CODE: /^\d{10}(-\d{3})?$/,

  // General
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  URL: /^https?:\/\/.+/,
  UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
  SLUG: /^[a-z0-9]+(?:-[a-z0-9]+)*$/,

  // Password (min 8, uppercase, lowercase, number)
  PASSWORD_STRONG: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/,
} as const;

// ===================
// Date Formats
// ===================
export const DATE_FORMATS = {
  // Display
  DATE_VN: 'dd/MM/yyyy',
  DATETIME_VN: 'dd/MM/yyyy HH:mm',
  TIME_VN: 'HH:mm',

  // ISO
  ISO_DATE: 'yyyy-MM-dd',
  ISO_DATETIME: "yyyy-MM-dd'T'HH:mm:ss'Z'",

  // For filenames
  FILENAME: 'yyyyMMdd_HHmmss',
} as const;

// ===================
// API Versioning
// ===================
export const API = {
  VERSION: 'v1',
  BASE_PATH: '/api/v1',
  TIMEOUT: 30000, // 30 seconds
} as const;

// ===================
// WebSocket Events
// ===================
export const WS_EVENTS = {
  // Connection
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  ERROR: 'error',

  // Chat
  CHAT_MESSAGE: 'chat:message',
  CHAT_TYPING: 'chat:typing',
  CHAT_READ: 'chat:read',
  CHAT_ONLINE: 'chat:online',

  // Notifications
  NOTIFICATION: 'notification',
  NOTIFICATION_READ: 'notification:read',

  // Progress
  PROGRESS_UPDATE: 'progress:update',
  PROGRESS_COMPLETE: 'progress:complete',

  // Calls
  CALL_INCOMING: 'call:incoming',
  CALL_ACCEPTED: 'call:accepted',
  CALL_REJECTED: 'call:rejected',
  CALL_ENDED: 'call:ended',
} as const;

// ===================
// Queue Names
// ===================
export const QUEUES = {
  EMAIL: 'email-queue',
  SMS: 'sms-queue',
  PUSH_NOTIFICATION: 'push-notification-queue',
  FILE_PROCESSING: 'file-processing-queue',
  EXPORT: 'export-queue',
  REPORT: 'report-queue',
} as const;

// ===================
// Error Messages (Vietnamese)
// ===================
export const ERROR_MESSAGES = {
  // Authentication
  UNAUTHORIZED: 'Vui lòng đăng nhập để tiếp tục',
  INVALID_CREDENTIALS: 'Email hoặc mật khẩu không đúng',
  TOKEN_EXPIRED: 'Phiên đăng nhập đã hết hạn',

  // Authorization
  FORBIDDEN: 'Bạn không có quyền truy cập',
  INSUFFICIENT_PERMISSIONS: 'Bạn không có quyền thực hiện thao tác này',

  // Validation
  VALIDATION_ERROR: 'Dữ liệu không hợp lệ',
  REQUIRED_FIELD: 'Trường này là bắt buộc',
  INVALID_EMAIL: 'Email không hợp lệ',
  INVALID_PHONE: 'Số điện thoại không hợp lệ',

  // Resource
  NOT_FOUND: 'Không tìm thấy dữ liệu',
  ALREADY_EXISTS: 'Dữ liệu đã tồn tại',

  // Server
  INTERNAL_ERROR: 'Đã xảy ra lỗi hệ thống',
  SERVICE_UNAVAILABLE: 'Dịch vụ tạm thời không khả dụng',
  RATE_LIMIT: 'Quá nhiều yêu cầu, vui lòng thử lại sau',
} as const;

// ===================
// Success Messages (Vietnamese)
// ===================
export const SUCCESS_MESSAGES = {
  CREATED: 'Tạo mới thành công',
  UPDATED: 'Cập nhật thành công',
  DELETED: 'Xóa thành công',
  SAVED: 'Lưu thành công',
  SENT: 'Gửi thành công',
  UPLOADED: 'Tải lên thành công',
  DOWNLOADED: 'Tải xuống thành công',
  LOGIN: 'Đăng nhập thành công',
  LOGOUT: 'Đăng xuất thành công',
  REGISTER: 'Đăng ký thành công',
  PASSWORD_CHANGED: 'Đổi mật khẩu thành công',
  PASSWORD_RESET: 'Đặt lại mật khẩu thành công',
} as const;
