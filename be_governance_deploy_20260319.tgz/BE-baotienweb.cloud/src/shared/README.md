# Shared Module - Reusable Node.js & NestJS Utilities

## 📁 Structure

```
src/shared/
├── index.ts                          # Main export file
├── shared.module.ts                  # NestJS module
│
├── helpers/                          # Pure utility functions
│   ├── pagination.helper.ts          # Pagination utilities
│   ├── date.helper.ts                # Date manipulation (Vietnamese)
│   ├── string.helper.ts              # String utilities (Vietnamese)
│   ├── file.helper.ts                # File handling
│   ├── crypto.helper.ts              # Encryption & hashing
│   ├── validation.helper.ts          # Input validation
│   └── response.helper.ts            # API response helpers
│
├── decorators/                       # Custom decorators
│   ├── api-paginated.decorator.ts    # Swagger pagination
│   ├── user.decorator.ts             # User extraction
│   ├── roles.decorator.ts            # RBAC decorators
│   ├── cache-key.decorator.ts        # Cache configuration
│   └── throttle.decorator.ts         # Rate limiting
│
├── interceptors/                     # Request/Response interceptors
│   ├── transform.interceptor.ts      # Response transformation
│   ├── timeout.interceptor.ts        # Request timeout
│   └── logging.interceptor.ts        # HTTP logging
│
├── filters/                          # Exception filters
│   ├── http-exception.filter.ts      # HTTP error handling
│   └── validation-exception.filter.ts # Validation errors
│
├── guards/                           # Authorization guards
│   ├── throttle.guard.ts             # Rate limiting
│   └── roles.guard.ts                # RBAC authorization
│
├── pipes/                            # Transformation pipes
│   ├── parse-int.pipe.ts             # Integer parsing
│   └── trim.pipe.ts                  # String sanitization
│
├── interfaces/                       # TypeScript interfaces
│   ├── pagination.interface.ts       # Pagination types
│   └── response.interface.ts         # Response types
│
└── constants/                        # Application constants
    └── app.constants.ts              # All constants
```

## 🚀 Usage

### Import Module (Global)

```typescript
// app.module.ts
import { SharedModule } from './shared';

@Module({
  imports: [SharedModule],
})
export class AppModule {}
```

### Import Individual Utilities

```typescript
// Any service or controller
import {
  // Helpers
  paginate,
  formatDateVN,
  slugify,
  ResponseHelper,
  hashPassword,

  // Decorators
  CurrentUser,
  Roles,
  Throttle,

  // Guards
  RolesGuard,
  ThrottleGuard,

  // Constants
  PAGINATION,
  ROLES,
  STATUS,
} from './shared';
```

## 📚 API Reference

### Helpers

#### Pagination Helper

```typescript
// Offset-based pagination
const result = paginate(data, { total, page, limit });

// Parse pagination from query
const { page, limit, skip } = parsePaginationParams(query);

// Build Prisma orderBy
const orderBy = buildOrderBy('createdAt', 'desc');
```

#### Date Helper (Vietnamese)

```typescript
formatDateVN(date); // "25/12/2024"
formatDateTimeVN(date); // "25/12/2024 14:30"
getRelativeTime(date); // "2 giờ trước"
getWorkingDays(start, end); // Excludes weekends
```

#### String Helper (Vietnamese)

```typescript
slugify('Thiết kế nhà'); // "thiet-ke-nha"
formatPhoneVN('0912345678'); // "+84 912 345 678"
formatCurrency(1000000); // "1.000.000 ₫"
maskEmail('user@email.com'); // "u***@email.com"
```

#### Crypto Helper

```typescript
await hashPassword('password123');
await verifyPassword('password123', hash);
encrypt('data', secretKey);
decrypt(encrypted, secretKey);
generateOTP(6); // "123456"
generateApiKey(); // "sk_xxxxxx"
```

#### Validation Helper (Vietnamese)

```typescript
isValidPhoneVN('0912345678'); // true
isValidCCCD('012345678901'); // true
isPasswordStrong('Pass123!'); // { valid: true, score: 4 }
```

#### Response Helper

```typescript
ResponseHelper.success(data);
ResponseHelper.paginated(data, pagination);
ResponseHelper.created(data, 'Tạo mới thành công');
ResponseHelper.error('NOT_FOUND', 'Không tìm thấy');
```

### Decorators

#### User Extraction

```typescript
@Get('profile')
getProfile(@CurrentUser() user, @UserId() userId) {
  return user;
}
```

#### RBAC

```typescript
@Roles('admin', 'manager')
@Permissions('projects.create')
@Post()
create() {}
```

#### Rate Limiting

```typescript
@Throttle({ limit: 5, ttl: 300 })
// or use presets
@Throttle(THROTTLE_PRESETS.LOGIN)
@Post('login')
login() {}
```

### Interceptors

```typescript
// Global
app.useGlobalInterceptors(new TransformInterceptor(), new LoggingInterceptor());

// Controller level
@UseInterceptors(TimeoutInterceptor)
@SetTimeout(60000) // 60 seconds
@Controller('exports')
export class ExportsController {}
```

### Guards

```typescript
// RBAC
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('admin')
@Controller('admin')
export class AdminController {}

// Rate Limiting
@UseGuards(ThrottleGuard)
@Throttle({ limit: 10, ttl: 60 })
@Controller('api')
export class ApiController {}
```

### Pipes

```typescript
@Get(':id')
findOne(@Param('id', ParseIdPipe) id: number) {}

@Get()
findAll(
  @Query('page', ParsePagePipe) page: number,
  @Query('limit', ParseLimitPipe) limit: number,
) {}

@Post()
create(@Body(TrimPipe) dto: CreateDto) {}
```

### Constants

```typescript
import {
  PAGINATION, // DEFAULT_PAGE, DEFAULT_LIMIT, MAX_LIMIT
  CACHE_TTL, // SHORT, DEFAULT, MEDIUM, LONG
  RATE_LIMIT, // LOGIN, REGISTER, OTP, UPLOAD
  FILE_UPLOAD, // MAX_SIZE, ALLOWED_TYPES, PATHS
  ROLES, // ADMIN, MANAGER, STAFF, PROJECT_MANAGER
  PERMISSIONS, // PROJECTS_CREATE, TASKS_UPDATE, etc.
  STATUS, // ACTIVE, PENDING, PROJECT_IN_PROGRESS
  REGEX, // PHONE_VN, EMAIL, UUID, CCCD
  ERROR_MESSAGES, // Vietnamese error messages
  SUCCESS_MESSAGES, // Vietnamese success messages
} from './shared';
```

## 🏗️ Construction-Specific Features

### Roles

- `project_manager`, `site_supervisor`, `foreman`
- `worker`, `qc_inspector`, `architect`, `engineer`
- `client`, `contractor`

### Permissions

```typescript
PERMISSIONS.PROJECTS_VIEW;
PERMISSIONS.TASKS_ASSIGN;
PERMISSIONS.WORKERS_CREATE;
PERMISSIONS.FINANCE_APPROVE;
PERMISSIONS.QC_VERIFY;
```

### File Types

```typescript
FILE_UPLOAD.ALLOWED_TYPES.CAD; // DWG, DXF files
FILE_UPLOAD.MAX_SIZE.CAD; // 50MB
FILE_UPLOAD.PATHS.CAD_FILES; // 'cad'
```

---

**Created:** December 2024
**Backend:** NestJS with Prisma ORM
**Language:** TypeScript with Vietnamese localization
