/**
 * HTTP Exception Filter
 * ======================
 * Global exception handler with standardized error responses
 */

import {
    ArgumentsHost,
    Catch,
    ExceptionFilter,
    HttpException,
    HttpStatus,
    Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ERROR_CODES, ERROR_MESSAGES } from '../helpers/response.helper';

interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
    timestamp: string;
    path: string;
    method: string;
    requestId?: string;
  };
}

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('HttpException');

  catch(exception: HttpException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const status = exception.getStatus();
    const exceptionResponse = exception.getResponse();

    const requestId = request.headers['x-request-id'] as string;

    // Extract error details
    let message: string;
    let code: string;
    let details: any;

    if (typeof exceptionResponse === 'object') {
      const errorObj = exceptionResponse as any;
      message = errorObj.message || exception.message;
      code = errorObj.code || this.getErrorCode(status);
      details = errorObj.details || errorObj.errors;

      // Handle array of messages (from class-validator)
      if (Array.isArray(message)) {
        message = message[0];
        details = { validationErrors: exceptionResponse['message'] };
      }
    } else {
      message = exceptionResponse as string;
      code = this.getErrorCode(status);
    }

    // Get Vietnamese message if available
    const viMessage =
      ERROR_MESSAGES[code as keyof typeof ERROR_MESSAGES] || message;

    const errorResponse: ErrorResponse = {
      success: false,
      error: {
        code,
        message: viMessage,
        details,
        timestamp: new Date().toISOString(),
        path: request.url,
        method: request.method,
        requestId,
      },
    };

    // Log the error
    this.logger.error(
      `[${requestId}] ${request.method} ${request.url} - ${status} - ${message}`,
      exception.stack,
    );

    response.status(status).json(errorResponse);
  }

  private getErrorCode(status: number): string {
    const statusCodeMap: Record<number, string> = {
      400: ERROR_CODES.BAD_REQUEST,
      401: ERROR_CODES.UNAUTHORIZED,
      403: ERROR_CODES.FORBIDDEN,
      404: ERROR_CODES.NOT_FOUND,
      409: ERROR_CODES.CONFLICT,
      422: ERROR_CODES.VALIDATION_ERROR,
      429: 'RATE_LIMIT_EXCEEDED',
      500: ERROR_CODES.INTERNAL_ERROR,
      502: 'BAD_GATEWAY',
      503: 'SERVICE_UNAVAILABLE',
    };

    return statusCodeMap[status] || ERROR_CODES.INTERNAL_ERROR;
  }
}

/**
 * Global exception filter - catches all unhandled exceptions
 */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger('AllExceptions');

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const requestId = request.headers['x-request-id'] as string;

    // Determine status and message
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let stack: string | undefined;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      message = exception.message;
      stack = exception.stack;
    } else if (exception instanceof Error) {
      message = exception.message;
      stack = exception.stack;
    }

    // Log the error with stack trace
    this.logger.error(`[${requestId}] Unhandled exception: ${message}`, stack);

    // Don't expose internal error details in production
    const isProduction = process.env.NODE_ENV === 'production';

    const errorResponse: ErrorResponse = {
      success: false,
      error: {
        code: ERROR_CODES.INTERNAL_ERROR,
        message: isProduction
          ? 'Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.'
          : message,
        details: isProduction ? undefined : { stack },
        timestamp: new Date().toISOString(),
        path: request.url,
        method: request.method,
        requestId,
      },
    };

    response.status(status).json(errorResponse);
  }
}

/**
 * Prisma Exception Filter
 * Handles Prisma-specific database errors
 */
@Catch()
export class PrismaExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('PrismaException');

  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    // Check if it's a Prisma error
    if (!exception.code || !exception.code.startsWith('P')) {
      throw exception; // Re-throw non-Prisma errors
    }

    const requestId = request.headers['x-request-id'] as string;
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Database error';
    let code = 'DATABASE_ERROR';

    // Handle specific Prisma error codes
    switch (exception.code) {
      case 'P2002': // Unique constraint violation
        status = HttpStatus.CONFLICT;
        message = this.getUniqueConstraintMessage(exception.meta?.target);
        code = 'DUPLICATE_ENTRY';
        break;

      case 'P2003': // Foreign key constraint violation
        status = HttpStatus.BAD_REQUEST;
        message = 'Dữ liệu tham chiếu không hợp lệ';
        code = 'INVALID_REFERENCE';
        break;

      case 'P2025': // Record not found
        status = HttpStatus.NOT_FOUND;
        message = 'Không tìm thấy dữ liệu';
        code = ERROR_CODES.NOT_FOUND;
        break;

      case 'P2014': // Required relation violation
        status = HttpStatus.BAD_REQUEST;
        message = 'Thiếu dữ liệu quan hệ bắt buộc';
        code = 'MISSING_RELATION';
        break;

      default:
        this.logger.error(
          `[${requestId}] Unhandled Prisma error: ${exception.code}`,
          exception.message,
        );
    }

    const errorResponse: ErrorResponse = {
      success: false,
      error: {
        code,
        message,
        timestamp: new Date().toISOString(),
        path: request.url,
        method: request.method,
        requestId,
      },
    };

    response.status(status).json(errorResponse);
  }

  private getUniqueConstraintMessage(target: string[] | undefined): string {
    if (!target || target.length === 0) {
      return 'Dữ liệu đã tồn tại';
    }

    const fieldMap: Record<string, string> = {
      email: 'Email',
      phone: 'Số điện thoại',
      username: 'Tên đăng nhập',
      code: 'Mã',
      slug: 'Đường dẫn',
      sku: 'Mã sản phẩm',
    };

    const field = target[0];
    const vietnameseField = fieldMap[field] || field;

    return `${vietnameseField} đã được sử dụng`;
  }
}
