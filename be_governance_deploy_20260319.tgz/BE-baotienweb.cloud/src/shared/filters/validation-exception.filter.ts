/**
 * Validation Exception Filter
 * ============================
 * Handles validation errors with detailed field information
 */

import {
    ArgumentsHost,
    BadRequestException,
    Catch,
    ExceptionFilter,
    HttpStatus,
} from '@nestjs/common';
import { ValidationError } from 'class-validator';
import { Request, Response } from 'express';

interface ValidationErrorDetail {
  field: string;
  message: string;
  value?: any;
  constraints?: Record<string, string>;
}

interface ValidationErrorResponse {
  success: false;
  error: {
    code: 'VALIDATION_ERROR';
    message: string;
    details: {
      fields: ValidationErrorDetail[];
    };
    timestamp: string;
    path: string;
    method: string;
    requestId?: string;
  };
}

@Catch(BadRequestException)
export class ValidationExceptionFilter implements ExceptionFilter {
  catch(exception: BadRequestException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const exceptionResponse = exception.getResponse() as any;

    const requestId = request.headers['x-request-id'] as string;

    // Check if this is a validation error
    if (
      !exceptionResponse.message ||
      !Array.isArray(exceptionResponse.message)
    ) {
      // Not a validation error, re-throw
      response.status(HttpStatus.BAD_REQUEST).json({
        success: false,
        error: {
          code: 'BAD_REQUEST',
          message: exceptionResponse.message || 'Bad request',
          timestamp: new Date().toISOString(),
          path: request.url,
          method: request.method,
          requestId,
        },
      });
      return;
    }

    // Parse validation errors
    const fields = this.parseValidationErrors(exceptionResponse.message);

    const errorResponse: ValidationErrorResponse = {
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: this.getSummaryMessage(fields),
        details: { fields },
        timestamp: new Date().toISOString(),
        path: request.url,
        method: request.method,
        requestId,
      },
    };

    response.status(HttpStatus.BAD_REQUEST).json(errorResponse);
  }

  private parseValidationErrors(
    errors: (string | ValidationError)[],
  ): ValidationErrorDetail[] {
    const fields: ValidationErrorDetail[] = [];

    for (const error of errors) {
      if (typeof error === 'string') {
        // Simple string error
        const fieldMatch = error.match(/^(\w+):\s*(.+)$/);
        if (fieldMatch) {
          fields.push({
            field: fieldMatch[1],
            message: this.translateMessage(fieldMatch[2]),
          });
        } else {
          fields.push({
            field: 'unknown',
            message: this.translateMessage(error),
          });
        }
      } else if (error && typeof error === 'object') {
        // Nested ValidationError object
        const detail = this.parseValidationError(error as ValidationError);
        fields.push(...detail);
      }
    }

    return fields;
  }

  private parseValidationError(
    error: ValidationError,
    parentPath = '',
  ): ValidationErrorDetail[] {
    const results: ValidationErrorDetail[] = [];
    const fieldPath = parentPath
      ? `${parentPath}.${error.property}`
      : error.property;

    // Add constraint violations
    if (error.constraints) {
      const constraintMessages = Object.entries(error.constraints).map(
        ([constraint, message]) => ({
          field: fieldPath,
          message: this.translateMessage(message),
          value: error.value,
          constraints: { [constraint]: message },
        }),
      );
      results.push(...constraintMessages);
    }

    // Process children (nested validation)
    if (error.children && error.children.length > 0) {
      for (const child of error.children) {
        results.push(...this.parseValidationError(child, fieldPath));
      }
    }

    return results;
  }

  private getSummaryMessage(fields: ValidationErrorDetail[]): string {
    if (fields.length === 0) {
      return 'Dữ liệu không hợp lệ';
    }

    if (fields.length === 1) {
      return fields[0].message;
    }

    return `${fields.length} trường dữ liệu không hợp lệ`;
  }

  private translateMessage(message: string): string {
    // Common validation message translations to Vietnamese
    const translations: Record<string, string> = {
      // Required validations
      'should not be empty': 'không được để trống',
      'must be a string': 'phải là chuỗi ký tự',
      'must be a number': 'phải là số',
      'must be an integer number': 'phải là số nguyên',
      'must be a positive number': 'phải là số dương',
      'must be a boolean value': 'phải là giá trị đúng/sai',
      'must be an email': 'phải là email hợp lệ',
      'must be a URL address': 'phải là địa chỉ URL hợp lệ',
      'must be a UUID': 'phải là UUID hợp lệ',
      'must be a valid ISO 8601 date string': 'phải là ngày hợp lệ',
      'must be an array': 'phải là danh sách',
      'must be an object': 'phải là đối tượng',

      // String validations
      'must be longer than or equal to': 'phải có độ dài tối thiểu',
      'must be shorter than or equal to': 'phải có độ dài tối đa',
      'must match': 'không đúng định dạng',

      // Number validations
      'must not be less than': 'phải lớn hơn hoặc bằng',
      'must not be greater than': 'phải nhỏ hơn hoặc bằng',

      // Array validations
      'must contain at least': 'phải chứa ít nhất',
      'must contain not more than': 'không được chứa quá',

      // Enum validations
      'must be a valid enum value': 'giá trị không hợp lệ',
      'must be one of the following values': 'phải là một trong các giá trị',
    };

    let translated = message;

    for (const [en, vi] of Object.entries(translations)) {
      if (translated.toLowerCase().includes(en.toLowerCase())) {
        translated = translated.replace(new RegExp(en, 'gi'), vi);
      }
    }

    return translated;
  }
}

/**
 * Custom validation error class for use in services
 */
export class CustomValidationError extends BadRequestException {
  constructor(
    fields: Array<{ field: string; message: string }>,
    message = 'Validation failed',
  ) {
    super({
      statusCode: 400,
      message: fields.map((f) => `${f.field}: ${f.message}`),
      error: 'Bad Request',
    });
  }

  static field(field: string, message: string): CustomValidationError {
    return new CustomValidationError([{ field, message }]);
  }

  static fields(
    fields: Array<{ field: string; message: string }>,
  ): CustomValidationError {
    return new CustomValidationError(fields);
  }
}
