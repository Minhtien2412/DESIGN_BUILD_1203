/**
 * Shared Module
 * ==============
 * NestJS module that exports all shared utilities
 */

import { Global, Module } from '@nestjs/common';

// Helpers - these are pure functions, no need to be providers
// Just export them for direct import

// Interceptors
import {
    LoggingInterceptor,
    MinimalLoggingInterceptor,
} from './interceptors/logging.interceptor';
import { TimeoutInterceptor } from './interceptors/timeout.interceptor';
import { TransformInterceptor } from './interceptors/transform.interceptor';

// Filters
import {
    AllExceptionsFilter,
    HttpExceptionFilter,
    PrismaExceptionFilter,
} from './filters/http-exception.filter';
import { ValidationExceptionFilter } from './filters/validation-exception.filter';

// Guards
import { RolesGuard } from './guards/roles.guard';
import {
    GlobalThrottleGuard,
    IpThrottleGuard,
    ThrottleGuard,
} from './guards/throttle.guard';

// Pipes
import {
    ParseIdPipe,
    ParseIntPipe,
    ParseLimitPipe,
    ParsePagePipe,
    ParsePositiveIntPipe,
} from './pipes/parse-int.pipe';
import {
    LowercasePipe,
    ParseArrayPipe,
    ParseBooleanPipe,
    SanitizeStringPipe,
    TrimPipe,
    UppercasePipe,
} from './pipes/trim.pipe';

/**
 * Providers that can be injected
 */
const providers = [
  // Interceptors
  TransformInterceptor,
  TimeoutInterceptor,
  LoggingInterceptor,
  MinimalLoggingInterceptor,

  // Filters
  HttpExceptionFilter,
  AllExceptionsFilter,
  PrismaExceptionFilter,
  ValidationExceptionFilter,

  // Guards
  ThrottleGuard,
  IpThrottleGuard,
  GlobalThrottleGuard,
  RolesGuard,

  // Pipes
  ParseIntPipe,
  ParsePositiveIntPipe,
  ParseIdPipe,
  ParsePagePipe,
  ParseLimitPipe,
  TrimPipe,
  LowercasePipe,
  UppercasePipe,
  SanitizeStringPipe,
  ParseBooleanPipe,
  ParseArrayPipe,
];

@Global()
@Module({
  providers,
  exports: providers,
})
export class SharedModule {}

// NOTE: All re-exports are now in ./index.ts to avoid duplicate exports
