/**
 * WebSocket Validation Pipe
 * ==========================
 * Validates incoming WebSocket message bodies using class-validator.
 * Throws WsException on validation failure.
 *
 * Usage on a gateway:
 *   @UsePipes(new WsValidationPipe())
 *   @SubscribeMessage('joinRoom')
 *   handleJoinRoom(@MessageBody() data: JoinRoomDto) { ... }
 */

import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { WsException } from '@nestjs/websockets';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';

@Injectable()
export class WsValidationPipe implements PipeTransform {
  async transform(value: any, metadata: ArgumentMetadata) {
    // Skip validation for non-body parameters or plain types
    if (!metadata.metatype || this.isNativeType(metadata.metatype)) {
      return value;
    }

    const object = plainToInstance(metadata.metatype, value);
    const errors = await validate(object, {
      whitelist: true,
      forbidNonWhitelisted: true,
    });

    if (errors.length > 0) {
      const messages = errors.flatMap((err) =>
        Object.values(err.constraints || {}),
      );
      throw new WsException({
        status: 'error',
        message: 'Validation failed',
        errors: messages,
      });
    }

    return object;
  }

  private isNativeType(metatype: any): boolean {
    const types = [String, Boolean, Number, Array, Object];
    return types.includes(metatype);
  }
}
