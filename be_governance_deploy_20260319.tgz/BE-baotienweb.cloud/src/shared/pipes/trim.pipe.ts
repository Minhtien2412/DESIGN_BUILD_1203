/**
 * Trim Pipe
 * ==========
 * Trim whitespace from string inputs
 */

import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';

@Injectable()
export class TrimPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata): any {
    if (typeof value === 'string') {
      return value.trim();
    }

    if (typeof value === 'object' && value !== null) {
      return this.trimObject(value);
    }

    return value;
  }

  private trimObject(obj: any): any {
    if (Array.isArray(obj)) {
      return obj.map((item) => this.trimObject(item));
    }

    if (typeof obj === 'object' && obj !== null) {
      const trimmed: any = {};

      for (const key of Object.keys(obj)) {
        const value = obj[key];

        if (typeof value === 'string') {
          trimmed[key] = value.trim();
        } else if (typeof value === 'object' && value !== null) {
          trimmed[key] = this.trimObject(value);
        } else {
          trimmed[key] = value;
        }
      }

      return trimmed;
    }

    return obj;
  }
}

/**
 * Lowercase Pipe
 * Converts string to lowercase
 */
@Injectable()
export class LowercasePipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata): any {
    if (typeof value === 'string') {
      return value.toLowerCase().trim();
    }
    return value;
  }
}

/**
 * Uppercase Pipe
 * Converts string to uppercase
 */
@Injectable()
export class UppercasePipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata): any {
    if (typeof value === 'string') {
      return value.toUpperCase().trim();
    }
    return value;
  }
}

/**
 * Sanitize String Pipe
 * Removes potentially dangerous characters
 */
@Injectable()
export class SanitizeStringPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata): any {
    if (typeof value === 'string') {
      return this.sanitize(value);
    }

    if (typeof value === 'object' && value !== null) {
      return this.sanitizeObject(value);
    }

    return value;
  }

  private sanitize(str: string): string {
    return (
      str
        .trim()
        // Remove null bytes
        .replace(/\0/g, '')
        // Remove control characters (except newlines and tabs)
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
        // Escape HTML entities
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
    );
  }

  private sanitizeObject(obj: any): any {
    if (Array.isArray(obj)) {
      return obj.map((item) =>
        typeof item === 'string'
          ? this.sanitize(item)
          : this.sanitizeObject(item),
      );
    }

    const sanitized: any = {};

    for (const key of Object.keys(obj)) {
      const value = obj[key];

      if (typeof value === 'string') {
        sanitized[key] = this.sanitize(value);
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = this.sanitizeObject(value);
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }
}

/**
 * Parse Boolean Pipe
 * Converts string boolean representations to actual boolean
 */
@Injectable()
export class ParseBooleanPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata): boolean | undefined {
    if (value === undefined || value === null || value === '') {
      return undefined;
    }

    if (typeof value === 'boolean') {
      return value;
    }

    if (typeof value === 'string') {
      const lowered = value.toLowerCase().trim();

      if (['true', '1', 'yes', 'on', 'có'].includes(lowered)) {
        return true;
      }

      if (['false', '0', 'no', 'off', 'không'].includes(lowered)) {
        return false;
      }
    }

    if (typeof value === 'number') {
      return value !== 0;
    }

    return undefined;
  }
}

/**
 * Default Value Pipe
 * Provides default value when input is empty
 */
@Injectable()
export class DefaultValuePipe<T = any> implements PipeTransform {
  private readonly defaultValue: T;

  constructor(defaultValue: T) {
    this.defaultValue = defaultValue;
  }

  transform(value: any, metadata: ArgumentMetadata): T {
    if (value === undefined || value === null || value === '') {
      return this.defaultValue;
    }
    return value;
  }
}

/**
 * Parse Enum Pipe
 * Validates and parses enum values
 */
@Injectable()
export class ParseEnumPipe<T extends object> implements PipeTransform {
  private readonly enumType: T;
  private readonly optional: boolean;

  constructor(enumType: T, optional = false) {
    this.enumType = enumType;
    this.optional = optional;
  }

  transform(value: any, metadata: ArgumentMetadata): T[keyof T] | undefined {
    if (value === undefined || value === null || value === '') {
      if (this.optional) {
        return undefined;
      }
      throw new Error(`${metadata.data} là bắt buộc`);
    }

    const enumValues = Object.values(this.enumType);

    if (!enumValues.includes(value)) {
      throw new Error(
        `${metadata.data} phải là một trong: ${enumValues.join(', ')}`,
      );
    }

    return value as T[keyof T];
  }
}

/**
 * Parse Array Pipe
 * Parses comma-separated string to array
 */
@Injectable()
export class ParseArrayPipe implements PipeTransform {
  private readonly separator: string;
  private readonly trim: boolean;

  constructor(options?: { separator?: string; trim?: boolean }) {
    this.separator = options?.separator || ',';
    this.trim = options?.trim ?? true;
  }

  transform(value: any, metadata: ArgumentMetadata): string[] {
    if (value === undefined || value === null || value === '') {
      return [];
    }

    if (Array.isArray(value)) {
      return this.trim ? value.map((v) => String(v).trim()) : value;
    }

    if (typeof value === 'string') {
      const parts = value.split(this.separator);
      return this.trim ? parts.map((p) => p.trim()).filter((p) => p) : parts;
    }

    return [String(value)];
  }
}
