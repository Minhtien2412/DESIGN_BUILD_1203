/**
 * Parse Int Pipe
 * ===============
 * Enhanced integer parsing with validation and Vietnamese messages
 */

import {
    ArgumentMetadata,
    BadRequestException,
    Injectable,
    PipeTransform,
} from '@nestjs/common';

export interface ParseIntPipeOptions {
  optional?: boolean;
  min?: number;
  max?: number;
  errorMessage?: string;
}

@Injectable()
export class ParseIntPipe implements PipeTransform<string, number | undefined> {
  private readonly options: ParseIntPipeOptions;

  constructor(options: ParseIntPipeOptions = {}) {
    this.options = options;
  }

  transform(value: string, metadata: ArgumentMetadata): number | undefined {
    // Handle optional values
    if (value === undefined || value === null || value === '') {
      if (this.options.optional) {
        return undefined;
      }
      throw new BadRequestException(
        this.options.errorMessage || `${metadata.data} là bắt buộc`,
      );
    }

    // Parse the value
    const parsedValue = parseInt(value, 10);

    // Check if valid integer
    if (isNaN(parsedValue)) {
      throw new BadRequestException(
        this.options.errorMessage || `${metadata.data} phải là số nguyên`,
      );
    }

    // Check min value
    if (this.options.min !== undefined && parsedValue < this.options.min) {
      throw new BadRequestException(
        this.options.errorMessage ||
          `${metadata.data} phải lớn hơn hoặc bằng ${this.options.min}`,
      );
    }

    // Check max value
    if (this.options.max !== undefined && parsedValue > this.options.max) {
      throw new BadRequestException(
        this.options.errorMessage ||
          `${metadata.data} phải nhỏ hơn hoặc bằng ${this.options.max}`,
      );
    }

    return parsedValue;
  }
}

/**
 * Parse positive integer (> 0)
 */
@Injectable()
export class ParsePositiveIntPipe extends ParseIntPipe {
  constructor() {
    super({ min: 1, errorMessage: undefined });
  }
}

/**
 * Parse optional int with default value
 */
@Injectable()
export class ParseOptionalIntPipe implements PipeTransform<string, number> {
  private readonly defaultValue: number;
  private readonly min?: number;
  private readonly max?: number;

  constructor(defaultValue: number, options?: { min?: number; max?: number }) {
    this.defaultValue = defaultValue;
    this.min = options?.min;
    this.max = options?.max;
  }

  transform(value: string, metadata: ArgumentMetadata): number {
    if (value === undefined || value === null || value === '') {
      return this.defaultValue;
    }

    const parsedValue = parseInt(value, 10);

    if (isNaN(parsedValue)) {
      return this.defaultValue;
    }

    // Apply bounds
    if (this.min !== undefined && parsedValue < this.min) {
      return this.min;
    }

    if (this.max !== undefined && parsedValue > this.max) {
      return this.max;
    }

    return parsedValue;
  }
}

/**
 * Parse ID parameter (common use case)
 */
@Injectable()
export class ParseIdPipe extends ParseIntPipe {
  constructor() {
    super({ min: 1, errorMessage: 'ID không hợp lệ' });
  }
}

/**
 * Parse pagination page number
 */
@Injectable()
export class ParsePagePipe extends ParseOptionalIntPipe {
  constructor() {
    super(1, { min: 1 });
  }
}

/**
 * Parse pagination limit
 */
@Injectable()
export class ParseLimitPipe extends ParseOptionalIntPipe {
  constructor(defaultLimit = 20, maxLimit = 100) {
    super(defaultLimit, { min: 1, max: maxLimit });
  }
}
