/**
 * Logging Interceptor
 * ===================
 * Log all requests with timing and response info
 */

import {
    CallHandler,
    ExecutionContext,
    Injectable,
    Logger,
    NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const { method, url, body, query, ip, headers } = request;
    const userAgent = headers['user-agent'] || '-';
    const userId = request.user?.id || 'anonymous';
    const requestId = headers['x-request-id'] || this.generateRequestId();

    const startTime = Date.now();

    // Log request
    this.logger.log(
      `[${requestId}] ${method} ${url} - User: ${userId} - IP: ${ip}`,
    );

    // Log body for mutations (excluding sensitive data)
    if (['POST', 'PUT', 'PATCH'].includes(method) && body) {
      const sanitizedBody = this.sanitizeBody(body);
      this.logger.debug(
        `[${requestId}] Body: ${JSON.stringify(sanitizedBody)}`,
      );
    }

    return next.handle().pipe(
      tap((response) => {
        const duration = Date.now() - startTime;
        const statusCode = context.switchToHttp().getResponse().statusCode;

        this.logger.log(
          `[${requestId}] ${method} ${url} - ${statusCode} - ${duration}ms`,
        );

        // Log slow requests
        if (duration > 3000) {
          this.logger.warn(
            `[${requestId}] Slow request detected: ${method} ${url} took ${duration}ms`,
          );
        }
      }),
      catchError((error) => {
        const duration = Date.now() - startTime;

        this.logger.error(
          `[${requestId}] ${method} ${url} - ${error.status || 500} - ${duration}ms - ${error.message}`,
        );

        throw error;
      }),
    );
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private sanitizeBody(body: any): any {
    const sensitiveFields = [
      'password',
      'currentPassword',
      'newPassword',
      'confirmPassword',
      'token',
      'accessToken',
      'refreshToken',
      'apiKey',
      'secret',
      'otp',
      'pin',
      'creditCard',
      'cardNumber',
      'cvv',
    ];

    if (typeof body !== 'object' || body === null) {
      return body;
    }

    const sanitized = { ...body };

    for (const field of sensitiveFields) {
      if (field in sanitized) {
        sanitized[field] = '[REDACTED]';
      }
    }

    return sanitized;
  }
}

/**
 * Lightweight logging interceptor for high-traffic endpoints
 */
@Injectable()
export class MinimalLoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const startTime = Date.now();

    return next.handle().pipe(
      tap(() => {
        const duration = Date.now() - startTime;

        // Only log slow requests
        if (duration > 1000) {
          this.logger.log(`${request.method} ${request.url} - ${duration}ms`);
        }
      }),
    );
  }
}
