/**
 * Transform Interceptor
 * =====================
 * Transform all responses to standard format
 */

import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
    SetMetadata,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface StandardResponse<T> {
  success: boolean;
  message?: string;
  data: T;
  meta: {
    timestamp: string;
    path: string;
    method: string;
    duration?: number;
  };
}

@Injectable()
export class TransformInterceptor<T>
  implements NestInterceptor<T, StandardResponse<T>>
{
  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<StandardResponse<T>> {
    const request = context.switchToHttp().getRequest();
    const startTime = Date.now();

    return next.handle().pipe(
      map((data) => {
        // If response is already in standard format, return as-is
        if (data && typeof data === 'object' && 'success' in data) {
          return {
            ...data,
            meta: {
              ...(data.meta || {}),
              timestamp: new Date().toISOString(),
              path: request.url,
              method: request.method,
              duration: Date.now() - startTime,
            },
          };
        }

        // Transform to standard format
        return {
          success: true,
          data,
          meta: {
            timestamp: new Date().toISOString(),
            path: request.url,
            method: request.method,
            duration: Date.now() - startTime,
          },
        };
      }),
    );
  }
}

/**
 * Exclude transform for specific endpoints
 */
export const EXCLUDE_TRANSFORM_KEY = 'exclude_transform';
export const ExcludeTransform = () => SetMetadata(EXCLUDE_TRANSFORM_KEY, true);
