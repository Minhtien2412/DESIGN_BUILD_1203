/**
 * Timeout Interceptor
 * ===================
 * Handle request timeouts
 */

import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
    RequestTimeoutException,
    SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable, throwError, TimeoutError } from 'rxjs';
import { catchError, timeout } from 'rxjs/operators';

export const TIMEOUT_KEY = 'request_timeout';
export const DEFAULT_TIMEOUT = 30000; // 30 seconds

/**
 * Set custom timeout for endpoint (in milliseconds)
 */
export const SetTimeout = (ms: number) => SetMetadata(TIMEOUT_KEY, ms);

/**
 * Timeout presets
 */
export const TIMEOUT = {
  SHORT: 5000, // 5 seconds
  DEFAULT: 30000, // 30 seconds
  LONG: 60000, // 1 minute
  UPLOAD: 120000, // 2 minutes
  EXPORT: 300000, // 5 minutes
  REPORT: 600000, // 10 minutes
} as const;

@Injectable()
export class TimeoutInterceptor implements NestInterceptor {
  constructor(private reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const timeoutValue =
      this.reflector.get<number>(TIMEOUT_KEY, context.getHandler()) ||
      this.reflector.get<number>(TIMEOUT_KEY, context.getClass()) ||
      DEFAULT_TIMEOUT;

    return next.handle().pipe(
      timeout(timeoutValue),
      catchError((err) => {
        if (err instanceof TimeoutError) {
          return throwError(
            () =>
              new RequestTimeoutException(
                `Request timed out after ${timeoutValue}ms`,
              ),
          );
        }
        return throwError(() => err);
      }),
    );
  }
}

/**
 * Preset timeout decorators
 */
export const ShortTimeout = () => SetTimeout(TIMEOUT.SHORT);
export const LongTimeout = () => SetTimeout(TIMEOUT.LONG);
export const UploadTimeout = () => SetTimeout(TIMEOUT.UPLOAD);
export const ExportTimeout = () => SetTimeout(TIMEOUT.EXPORT);
export const ReportTimeout = () => SetTimeout(TIMEOUT.REPORT);
