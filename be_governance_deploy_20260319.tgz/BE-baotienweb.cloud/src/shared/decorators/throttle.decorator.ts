/**
 * Throttle Decorator
 * ==================
 * Rate limiting decorators
 */

import { SetMetadata } from '@nestjs/common';

export const THROTTLE_LIMIT_KEY = 'throttle_limit';
export const THROTTLE_TTL_KEY = 'throttle_ttl';
export const THROTTLE_SKIP_KEY = 'throttle_skip';

/**
 * Set rate limit for endpoint
 * @param limit Maximum requests
 * @param ttl Time window in seconds
 */
export const Throttle = (limit: number, ttl: number) => {
  return (
    target: any,
    propertyKey?: string,
    descriptor?: PropertyDescriptor,
  ) => {
    SetMetadata(THROTTLE_LIMIT_KEY, limit)(target, propertyKey!, descriptor!);
    SetMetadata(THROTTLE_TTL_KEY, ttl)(target, propertyKey!, descriptor!);
    return descriptor;
  };
};

/**
 * Skip throttle for endpoint
 */
export const SkipThrottle = () => SetMetadata(THROTTLE_SKIP_KEY, true);

/**
 * Rate limit presets
 */
export const RATE_LIMITS = {
  // Strict limits for sensitive operations
  LOGIN: { limit: 5, ttl: 300 }, // 5 requests per 5 minutes
  REGISTER: { limit: 3, ttl: 3600 }, // 3 requests per hour
  PASSWORD_RESET: { limit: 3, ttl: 3600 }, // 3 requests per hour
  OTP: { limit: 5, ttl: 300 }, // 5 OTPs per 5 minutes

  // Standard API limits
  API_DEFAULT: { limit: 100, ttl: 60 }, // 100 requests per minute
  API_STRICT: { limit: 30, ttl: 60 }, // 30 requests per minute
  API_LOOSE: { limit: 300, ttl: 60 }, // 300 requests per minute

  // Upload limits
  UPLOAD: { limit: 10, ttl: 60 }, // 10 uploads per minute
  UPLOAD_LARGE: { limit: 3, ttl: 60 }, // 3 large uploads per minute

  // Report/Export limits
  EXPORT: { limit: 5, ttl: 300 }, // 5 exports per 5 minutes
  REPORT: { limit: 10, ttl: 300 }, // 10 reports per 5 minutes

  // Search limits
  SEARCH: { limit: 60, ttl: 60 }, // 60 searches per minute

  // WebSocket limits
  WS_MESSAGE: { limit: 60, ttl: 60 }, // 60 messages per minute
  WS_EVENT: { limit: 100, ttl: 60 }, // 100 events per minute
} as const;

/**
 * Preset decorators
 */
export const LoginThrottle = () =>
  Throttle(RATE_LIMITS.LOGIN.limit, RATE_LIMITS.LOGIN.ttl);
export const RegisterThrottle = () =>
  Throttle(RATE_LIMITS.REGISTER.limit, RATE_LIMITS.REGISTER.ttl);
export const OtpThrottle = () =>
  Throttle(RATE_LIMITS.OTP.limit, RATE_LIMITS.OTP.ttl);
export const UploadThrottle = () =>
  Throttle(RATE_LIMITS.UPLOAD.limit, RATE_LIMITS.UPLOAD.ttl);
export const ExportThrottle = () =>
  Throttle(RATE_LIMITS.EXPORT.limit, RATE_LIMITS.EXPORT.ttl);
export const SearchThrottle = () =>
  Throttle(RATE_LIMITS.SEARCH.limit, RATE_LIMITS.SEARCH.ttl);
