/**
 * API Error Response Decorators
 * ==============================
 * Standard error response decorators for OpenAPI documentation.
 * Apply to controllers/methods so Swagger spec reflects actual runtime error shapes.
 */

import { applyDecorators } from '@nestjs/common';
import { ApiResponse } from '@nestjs/swagger';

/**
 * Standard error response body shape (matches HttpExceptionFilter output)
 */
const ErrorSchema = {
  type: 'object' as const,
  properties: {
    success: { type: 'boolean' as const, example: false },
    error: {
      type: 'object' as const,
      properties: {
        code: { type: 'string' as const, example: 'BAD_REQUEST' },
        message: { type: 'string' as const, example: 'Validation failed' },
        details: {
          type: 'array' as const,
          items: { type: 'object' as const },
          nullable: true,
        },
        timestamp: {
          type: 'string' as const,
          example: '2026-03-10T10:00:00.000Z',
        },
        path: { type: 'string' as const, example: '/api/v1/resource' },
        method: { type: 'string' as const, example: 'POST' },
      },
    },
  },
};

/**
 * Apply standard error responses (400, 401, 403, 500) to an endpoint.
 * Use on most authenticated endpoints.
 */
export const ApiStandardErrors = () =>
  applyDecorators(
    ApiResponse({
      status: 400,
      description: 'Bad Request - Validation error or invalid input',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 401,
      description: 'Unauthorized - Missing or invalid token',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 403,
      description: 'Forbidden - Insufficient permissions',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 500,
      description: 'Internal Server Error',
      schema: ErrorSchema,
    }),
  );

/**
 * Apply full CRUD error responses (400, 401, 403, 404, 409, 500).
 * Use on single-resource endpoints (GET/:id, PUT/:id, DELETE/:id).
 */
export const ApiCrudErrors = () =>
  applyDecorators(
    ApiResponse({
      status: 400,
      description: 'Bad Request - Validation error',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 401,
      description: 'Unauthorized - Missing or invalid token',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 403,
      description: 'Forbidden - Insufficient permissions',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 404,
      description: 'Not Found - Resource does not exist',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 409,
      description: 'Conflict - Resource already exists or version conflict',
      schema: ErrorSchema,
    }),
    ApiResponse({
      status: 500,
      description: 'Internal Server Error',
      schema: ErrorSchema,
    }),
  );

/**
 * Apply rate-limited endpoint errors (add 429 on top of standard errors).
 */
export const ApiRateLimitedErrors = () =>
  applyDecorators(
    ApiStandardErrors(),
    ApiResponse({
      status: 429,
      description: 'Too Many Requests - Rate limit exceeded',
      schema: ErrorSchema,
    }),
  );

/**
 * Standard delete response (can use 200 with body or 204).
 * We use 200 + body for consistency.
 */
export const ApiDeleteResponse = () =>
  applyDecorators(
    ApiResponse({
      status: 200,
      description: 'Deleted successfully',
      schema: {
        type: 'object',
        properties: {
          success: { type: 'boolean', example: true },
          message: { type: 'string', example: 'Deleted successfully' },
        },
      },
    }),
    ApiCrudErrors(),
  );
