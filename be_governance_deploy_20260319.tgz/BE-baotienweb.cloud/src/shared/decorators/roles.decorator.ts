/**
 * Roles Decorator
 * ===============
 * Role-based access control decorators
 */

import { SetMetadata } from '@nestjs/common';

export const ROLES_KEY = 'roles';
export const PERMISSIONS_KEY = 'permissions';

/**
 * Set required roles for endpoint
 */
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);

/**
 * Set required permissions for endpoint
 */
export const Permissions = (...permissions: string[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);

/**
 * Common role shortcuts
 */
export const AdminOnly = () => Roles('ADMIN', 'SUPER_ADMIN');
export const ManagerOnly = () => Roles('ADMIN', 'SUPER_ADMIN', 'MANAGER');
export const StaffOnly = () =>
  Roles('ADMIN', 'SUPER_ADMIN', 'MANAGER', 'STAFF');
export const WorkerOnly = () =>
  Roles('ADMIN', 'SUPER_ADMIN', 'MANAGER', 'WORKER');
export const ClientOnly = () => Roles('CLIENT', 'ADMIN', 'SUPER_ADMIN');

/**
 * Permission constants for construction app
 */
export const PERMISSION = {
  // Projects
  PROJECT_CREATE: 'project:create',
  PROJECT_READ: 'project:read',
  PROJECT_UPDATE: 'project:update',
  PROJECT_DELETE: 'project:delete',
  PROJECT_ASSIGN: 'project:assign',

  // Tasks
  TASK_CREATE: 'task:create',
  TASK_READ: 'task:read',
  TASK_UPDATE: 'task:update',
  TASK_DELETE: 'task:delete',
  TASK_ASSIGN: 'task:assign',

  // Workers
  WORKER_CREATE: 'worker:create',
  WORKER_READ: 'worker:read',
  WORKER_UPDATE: 'worker:update',
  WORKER_DELETE: 'worker:delete',
  WORKER_APPROVE: 'worker:approve',

  // QC
  QC_CREATE: 'qc:create',
  QC_READ: 'qc:read',
  QC_UPDATE: 'qc:update',
  QC_APPROVE: 'qc:approve',

  // Finance
  FINANCE_READ: 'finance:read',
  FINANCE_CREATE: 'finance:create',
  FINANCE_APPROVE: 'finance:approve',

  // Reports
  REPORT_CREATE: 'report:create',
  REPORT_READ: 'report:read',
  REPORT_EXPORT: 'report:export',

  // Users
  USER_CREATE: 'user:create',
  USER_READ: 'user:read',
  USER_UPDATE: 'user:update',
  USER_DELETE: 'user:delete',

  // Settings
  SETTINGS_READ: 'settings:read',
  SETTINGS_UPDATE: 'settings:update',
} as const;

export type PermissionType = (typeof PERMISSION)[keyof typeof PERMISSION];

/**
 * Role definitions with default permissions
 */
export const ROLE_PERMISSIONS: Record<string, PermissionType[]> = {
  SUPER_ADMIN: Object.values(PERMISSION),

  ADMIN: [
    PERMISSION.PROJECT_CREATE,
    PERMISSION.PROJECT_READ,
    PERMISSION.PROJECT_UPDATE,
    PERMISSION.PROJECT_ASSIGN,
    PERMISSION.TASK_CREATE,
    PERMISSION.TASK_READ,
    PERMISSION.TASK_UPDATE,
    PERMISSION.TASK_ASSIGN,
    PERMISSION.WORKER_READ,
    PERMISSION.WORKER_APPROVE,
    PERMISSION.QC_READ,
    PERMISSION.QC_APPROVE,
    PERMISSION.FINANCE_READ,
    PERMISSION.FINANCE_CREATE,
    PERMISSION.REPORT_READ,
    PERMISSION.REPORT_CREATE,
    PERMISSION.USER_READ,
    PERMISSION.USER_UPDATE,
    PERMISSION.SETTINGS_READ,
  ],

  MANAGER: [
    PERMISSION.PROJECT_READ,
    PERMISSION.PROJECT_UPDATE,
    PERMISSION.TASK_CREATE,
    PERMISSION.TASK_READ,
    PERMISSION.TASK_UPDATE,
    PERMISSION.TASK_ASSIGN,
    PERMISSION.WORKER_READ,
    PERMISSION.QC_READ,
    PERMISSION.QC_CREATE,
    PERMISSION.REPORT_READ,
    PERMISSION.REPORT_CREATE,
  ],

  ENGINEER: [
    PERMISSION.PROJECT_READ,
    PERMISSION.TASK_READ,
    PERMISSION.TASK_UPDATE,
    PERMISSION.QC_READ,
    PERMISSION.QC_CREATE,
    PERMISSION.REPORT_READ,
    PERMISSION.REPORT_CREATE,
  ],

  WORKER: [
    PERMISSION.PROJECT_READ,
    PERMISSION.TASK_READ,
    PERMISSION.TASK_UPDATE,
  ],

  CLIENT: [PERMISSION.PROJECT_READ, PERMISSION.REPORT_READ, PERMISSION.QC_READ],
};

/**
 * Check if role has permission
 */
export function hasPermission(
  role: string,
  permission: PermissionType,
): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  return permissions ? permissions.includes(permission) : false;
}

/**
 * Get all permissions for role
 */
export function getRolePermissions(role: string): PermissionType[] {
  return ROLE_PERMISSIONS[role] || [];
}
