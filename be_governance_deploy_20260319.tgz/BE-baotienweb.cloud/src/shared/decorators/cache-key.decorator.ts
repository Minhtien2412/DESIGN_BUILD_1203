/**
 * Cache Key Decorator
 * ===================
 * Custom cache key generation
 */

import { SetMetadata } from '@nestjs/common';

export const CACHE_KEY_METADATA = 'cache_key';
export const CACHE_TTL_METADATA = 'cache_ttl';
export const CACHE_SKIP_METADATA = 'cache_skip';

/**
 * Set custom cache key for endpoint
 */
export const CacheKey = (key: string) => SetMetadata(CACHE_KEY_METADATA, key);

/**
 * Set cache TTL (in seconds)
 */
export const CacheTTL = (ttl: number) => SetMetadata(CACHE_TTL_METADATA, ttl);

/**
 * Skip cache for endpoint
 */
export const NoCache = () => SetMetadata(CACHE_SKIP_METADATA, true);

/**
 * Cache presets (in seconds)
 */
export const CACHE_TTL = {
  SHORT: 60, // 1 minute
  MEDIUM: 300, // 5 minutes
  LONG: 3600, // 1 hour
  DAY: 86400, // 24 hours
  WEEK: 604800, // 7 days
} as const;

/**
 * Generate cache key from params
 */
export function generateCacheKey(
  prefix: string,
  params: Record<string, any>,
): string {
  const sortedParams = Object.keys(params)
    .sort()
    .map((key) => `${key}:${params[key]}`)
    .join(':');

  return `${prefix}:${sortedParams}`;
}

/**
 * Generate user-specific cache key
 */
export function userCacheKey(userId: number, prefix: string): string {
  return `user:${userId}:${prefix}`;
}

/**
 * Generate list cache key with pagination
 */
export function listCacheKey(
  entity: string,
  page: number,
  limit: number,
  filters?: Record<string, any>,
): string {
  let key = `${entity}:list:p${page}:l${limit}`;

  if (filters && Object.keys(filters).length > 0) {
    const filterStr = Object.entries(filters)
      .filter(([, value]) => value !== undefined && value !== null)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`)
      .join('&');

    if (filterStr) {
      key += `:f(${filterStr})`;
    }
  }

  return key;
}

/**
 * Generate detail cache key
 */
export function detailCacheKey(entity: string, id: number | string): string {
  return `${entity}:detail:${id}`;
}
