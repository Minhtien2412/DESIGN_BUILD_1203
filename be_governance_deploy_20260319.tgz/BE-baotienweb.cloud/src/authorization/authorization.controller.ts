/**
 * Authorization Controller
 * ========================
 * API endpoints cho phân quyền
 */

import {
    Body,
    Controller,
    Get,
    Logger,
    Param,
    Post,
    Request,
    UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { AuthorizationService } from './authorization.service';
import {
    getRoleLevel,
    MENU_VISIBILITY,
    Permission,
    PermissionType,
    PRODUCT_CATEGORY_VISIBILITY,
    ROLE_HIERARCHY,
    ROLE_PERMISSIONS,
} from './constants/roles.constant';
import { AdminGuard, StaffOrHigherGuard } from './guards/permission.guard';

@ApiTags('Authorization')
@Controller('authorization')
@UseGuards(JwtAuthGuard)
export class AuthorizationController {
  private readonly logger = new Logger(AuthorizationController.name);

  constructor(private authorizationService: AuthorizationService) {}

  /**
   * GET /authorization/my-permissions
   * Lấy thông tin phân quyền của user hiện tại
   */
  @Get('my-permissions')
  getMyPermissions(@Request() req: any) {
    const user = req.user;
    return this.authorizationService.getAuthorizationSummary({
      id: user.id,
      email: user.email,
      role: user.role,
      permissions: user.permissions,
    });
  }

  /**
   * GET /authorization/my-menus
   * Lấy danh sách menu mà user có quyền truy cập
   */
  @Get('my-menus')
  getMyMenus(@Request() req: any) {
    const user = req.user;
    const accessibleMenus = this.authorizationService.getAccessibleMenus({
      id: user.id,
      email: user.email,
      role: user.role,
    });

    const menuVisibility = this.authorizationService.getMenuVisibility({
      id: user.id,
      email: user.email,
      role: user.role,
    });

    return {
      role: user.role,
      accessibleMenus,
      menuVisibility,
    };
  }

  /**
   * GET /authorization/my-categories
   * Lấy danh sách danh mục sản phẩm mà user có quyền xem
   */
  @Get('my-categories')
  getMyCategories(@Request() req: any) {
    const user = req.user;
    const viewableCategories =
      this.authorizationService.getViewableProductCategories({
        id: user.id,
        email: user.email,
        role: user.role,
      });

    return {
      role: user.role,
      viewableCategories,
      totalCategories: Object.keys(PRODUCT_CATEGORY_VISIBILITY).length,
    };
  }

  /**
   * POST /authorization/check-permission
   * Kiểm tra user có permission cụ thể không
   */
  @Post('check-permission')
  checkPermission(@Request() req: any, @Body() body: { permission: string }) {
    const user = req.user;
    const hasPermission = this.authorizationService.hasPermission(
      {
        id: user.id,
        email: user.email,
        role: user.role,
        permissions: user.permissions,
      },
      body.permission as PermissionType,
    );

    return {
      permission: body.permission,
      hasPermission,
      userRole: user.role,
    };
  }

  /**
   * POST /authorization/check-menu
   * Kiểm tra user có quyền truy cập menu không
   */
  @Post('check-menu')
  checkMenu(@Request() req: any, @Body() body: { menuKey: string }) {
    const user = req.user;
    const canAccess = this.authorizationService.canAccessMenu(
      {
        id: user.id,
        email: user.email,
        role: user.role,
      },
      body.menuKey,
    );

    return {
      menuKey: body.menuKey,
      canAccess,
      userRole: user.role,
    };
  }

  /**
   * POST /authorization/check-category
   * Kiểm tra user có quyền xem danh mục không
   */
  @Post('check-category')
  checkCategory(@Request() req: any, @Body() body: { category: string }) {
    const user = req.user;
    const canView = this.authorizationService.canViewProductCategory(
      {
        id: user.id,
        email: user.email,
        role: user.role,
      },
      body.category,
    );

    return {
      category: body.category,
      canView,
      userRole: user.role,
    };
  }

  /**
   * GET /authorization/assignable-roles
   * Lấy danh sách roles mà user có thể gán cho người khác
   */
  @Get('assignable-roles')
  @UseGuards(StaffOrHigherGuard)
  getAssignableRoles(@Request() req: any) {
    const user = req.user;
    const assignableRoles = this.authorizationService.getAssignableRoles(
      user.role,
    );

    return {
      userRole: user.role,
      userRoleLevel: getRoleLevel(user.role),
      assignableRoles: assignableRoles.map((role) => ({
        role,
        level: getRoleLevel(role),
      })),
    };
  }

  /**
   * POST /authorization/can-manage-user
   * Kiểm tra user có thể quản lý user khác không (dựa trên role hierarchy)
   */
  @Post('can-manage-user')
  @UseGuards(StaffOrHigherGuard)
  canManageUser(@Request() req: any, @Body() body: { targetRole: string }) {
    const user = req.user;
    const canManage = this.authorizationService.canManageUser(
      user.role,
      body.targetRole,
    );

    return {
      managerRole: user.role,
      targetRole: body.targetRole,
      canManage,
      reason: canManage
        ? 'Role cấp cao hơn có thể quản lý'
        : 'Không thể quản lý role có cấp bậc cao hơn hoặc bằng',
    };
  }

  // ==================== ADMIN ENDPOINTS ====================

  /**
   * GET /authorization/roles
   * [ADMIN] Lấy danh sách tất cả roles và permissions
   */
  @Get('roles')
  @UseGuards(AdminGuard)
  getAllRoles() {
    return {
      roles: Object.entries(ROLE_HIERARCHY).map(([role, level]) => ({
        role,
        level,
        permissions: ROLE_PERMISSIONS[role] || [],
      })),
      allPermissions: Object.values(Permission),
    };
  }

  /**
   * GET /authorization/roles/:role/permissions
   * [ADMIN] Lấy permissions của một role cụ thể
   */
  @Get('roles/:role/permissions')
  @UseGuards(AdminGuard)
  getRolePermissions(@Param('role') role: string) {
    const permissions = ROLE_PERMISSIONS[role];
    if (!permissions) {
      return {
        error: 'Role không tồn tại',
        validRoles: Object.keys(ROLE_HIERARCHY),
      };
    }

    return {
      role,
      level: getRoleLevel(role),
      permissions,
      totalPermissions: permissions.length,
    };
  }

  /**
   * GET /authorization/menus
   * [ADMIN] Lấy danh sách tất cả menu và roles có quyền truy cập
   */
  @Get('menus')
  @UseGuards(AdminGuard)
  getAllMenus() {
    return Object.entries(MENU_VISIBILITY).map(([menu, roles]) => ({
      menu,
      accessibleRoles: roles,
      totalRoles: roles.length,
    }));
  }

  /**
   * GET /authorization/categories
   * [ADMIN] Lấy danh sách tất cả danh mục và roles có quyền xem
   */
  @Get('categories')
  @UseGuards(AdminGuard)
  getAllCategories() {
    return Object.entries(PRODUCT_CATEGORY_VISIBILITY).map(
      ([category, roles]) => ({
        category,
        visibleToRoles: roles,
        totalRoles: roles.length,
      }),
    );
  }

  /**
   * GET /authorization/user/:userId
   * [ADMIN] Lấy thông tin phân quyền của một user cụ thể
   */
  @Get('user/:userId')
  @UseGuards(AdminGuard)
  async getUserAuthorization(
    @Param('userId') userId: string,
    @Request() req: any,
  ) {
    // TODO: Fetch user from database
    // For now, return structure that would be returned
    return {
      message: 'Endpoint để lấy thông tin phân quyền của user cụ thể',
      userId,
      note: 'Cần integrate với UserService để fetch user data',
    };
  }

  /**
   * GET /authorization/sensitive-data-access
   * [ADMIN] Kiểm tra ai có quyền xem dữ liệu nhạy cảm
   */
  @Get('sensitive-data-access')
  @UseGuards(AdminGuard)
  getSensitiveDataAccess() {
    const sensitivePermissions = [
      Permission.SENSITIVE_VIEW_SALARY,
      Permission.SENSITIVE_VIEW_COST,
      Permission.SENSITIVE_VIEW_PROFIT,
    ];

    const roleAccess: Record<string, string[]> = {};

    Object.entries(ROLE_PERMISSIONS).forEach(([role, permissions]) => {
      const sensitiveAccess = sensitivePermissions.filter((p) =>
        permissions.includes(p),
      );
      if (sensitiveAccess.length > 0) {
        roleAccess[role] = sensitiveAccess;
      }
    });

    return {
      sensitivePermissions,
      roleAccess,
      warning: 'Các quyền này cho phép xem dữ liệu tài chính nhạy cảm',
    };
  }
}
