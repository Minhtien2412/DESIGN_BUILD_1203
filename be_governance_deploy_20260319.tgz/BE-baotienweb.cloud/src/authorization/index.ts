/**
 * Authorization Module Index
 * ==========================
 * Export tất cả các thành phần của hệ thống phân quyền
 */

// Module
export { AuthorizationModule } from './authorization.module';

// Service
export { AuthorizationService } from './authorization.service';
export type { ResourceContext, UserContext } from './authorization.service';

// Constants
export {
    AppRole, MENU_VISIBILITY,
    PRODUCT_CATEGORY_VISIBILITY, Permission,
    ROLE_HIERARCHY,
    ROLE_PERMISSIONS, canAccessMenu,
    canManageRole,
    canViewProductCategory,
    getAccessibleMenus,
    getRoleLevel,
    getRolePermissions,
    hasPermission,
    isRoleHigher
} from './constants/roles.constant';
export type { PermissionType } from './constants/roles.constant';

// Decorators
export {
    AdminOnly,
    // Admin permissions
    CanAccessAdminPanel,
    CanApprovePayment,
    CanApproveProduct,
    CanAssignRole,
    CanAssignTask,
    CanConfigSystem,
    CanCreatePayment,
    // Product permissions
    CanCreateProduct,
    // Project permissions
    CanCreateProject,
    // Task permissions
    CanCreateTask,
    CanCreateUser,
    CanDeleteProduct,
    CanDeleteProject,
    CanDeleteUser,
    CanEditProduct,
    CanEditProject,
    CanEditUser,
    CanRejectProduct,
    CanViewCost,
    // Finance permissions
    CanViewFinance,
    CanViewLogs,
    CanViewPendingProducts,
    CanViewProfit,
    CanViewProject,
    // Sensitive data permissions
    CanViewSalary,
    CanViewTask,
    // User management permissions
    CanViewUsers,
    EngineerOrHigher,
    FinanceManagement,
    MIN_ROLE_LEVEL_KEY,
    MinRoleLevel,
    // Metadata keys
    PERMISSIONS_KEY,
    // Combined decorators
    ProductManagement,
    ProjectManagement,
    RESOURCE_OWNERSHIP_KEY,
    ROLES_KEY,
    RequireAllPermissions,
    // Basic decorators
    RequirePermission,
    RequireRole,
    ResourceOwnership,
    StaffOrHigher,
    SuperAdminOnly,
    UserManagement
} from './decorators/permission.decorator';

// Guards
export {
    AdminGuard,
    AllPermissionsGuard,
    FinanceAccessGuard,
    PermissionGuard,
    ProductApprovalGuard,
    SensitiveDataGuard,
    StaffOrHigherGuard
} from './guards/permission.guard';

export {
    DocumentAccessGuard,
    FinanceResourceGuard,
    ProductAccessGuard,
    ProjectAccessGuard,
    ReportAccessGuard,
    ResourceGuard,
    ResourceOwnershipGuard,
    RoleHierarchyGuard,
    TaskAccessGuard,
    TeamMemberGuard
} from './guards/resource.guard';
export type { ResourceOwnershipConfig } from './guards/resource.guard';

export {
    AdminSettingsMenuAccessGuard,
    CostAnalysisMenuAccessGuard,
    DashboardAccessGuard,
    FinanceMenuAccessGuard,
    HRMenuAccessGuard,
    MenuAccessGuard,
    ProfitReportsMenuAccessGuard,
    ProjectsMenuAccessGuard,
    ReportsMenuAccessGuard,
    RequireMenuAccess,
    SalaryMenuAccessGuard,
    SystemLogsMenuAccessGuard
} from './guards/menu-access.guard';

export {
    BuildingMaterialsAccessGuard,
    CategoryAccessGuard,
    CategoryFilterInterceptor,
    ElectricalAccessGuard,
    HeavyMachineryAccessGuard,
    InteriorDesignAccessGuard,
    InternalSuppliesAccessGuard,
    PlumbingAccessGuard,
    PremiumProductsAccessGuard,
    RawMaterialsAccessGuard,
    RequireCategoryAccess,
    SafetyEquipmentAccessGuard,
    WholesaleAccessGuard
} from './guards/category-access.guard';

