/**
 * Authorization Module
 * ====================
 * Comprehensive role-based access control (RBAC) system
 * Quản lý phân quyền chi tiết cho từng role
 *
 * Chức năng chính:
 * 1. Phân quyền theo Role (SUPER_ADMIN > ADMIN > STAFF > ENGINEER > ...)
 * 2. Phân quyền chi tiết theo Permission
 * 3. Kiểm soát truy cập Menu/UI
 * 4. Kiểm soát truy cập Danh mục sản phẩm
 * 5. Kiểm soát dữ liệu nhạy cảm (lương, chi phí, lợi nhuận)
 */

import { Global, Module } from '@nestjs/common';

// Controller
import { AuthorizationController } from './authorization.controller';

// Services
import { AuthorizationService } from './authorization.service';

// Guards
import {
    AdminGuard,
    AllPermissionsGuard,
    FinanceAccessGuard,
    PermissionGuard,
    ProductApprovalGuard,
    SensitiveDataGuard,
    StaffOrHigherGuard,
} from './guards/permission.guard';

import {
    ResourceGuard,
    RoleHierarchyGuard,
    TeamMemberGuard,
} from './guards/resource.guard';

import { MenuAccessGuard } from './guards/menu-access.guard';

import {
    CategoryAccessGuard,
    CategoryFilterInterceptor,
} from './guards/category-access.guard';

// Export all constants and decorators
export * from './constants/roles.constant';
export * from './decorators/permission.decorator';

const guards = [
  // Permission-based guards
  PermissionGuard,
  AllPermissionsGuard,
  AdminGuard,
  StaffOrHigherGuard,
  ProductApprovalGuard,
  FinanceAccessGuard,
  SensitiveDataGuard,

  // Resource-based guards
  ResourceGuard,
  RoleHierarchyGuard,
  TeamMemberGuard,

  // Menu access
  MenuAccessGuard,

  // Category access
  CategoryAccessGuard,
];

const services = [AuthorizationService, CategoryFilterInterceptor];

@Global()
@Module({
  controllers: [AuthorizationController],
  providers: [...services, ...guards],
  exports: [...services, ...guards],
})
export class AuthorizationModule {}
