/**
 * Category Access Guard
 * ======================
 * Guard kiểm tra quyền truy cập danh mục sản phẩm
 */

import {
    CanActivate,
    ExecutionContext,
    ForbiddenException,
    Injectable,
    Logger,
    mixin,
    Type,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import {
    AppRole,
    canViewProductCategory,
    PRODUCT_CATEGORY_VISIBILITY,
} from '../constants/roles.constant';

export const CATEGORY_ACCESS_KEY = 'categoryAccess';

/**
 * Category Access Guard - kiểm tra quyền truy cập danh mục
 */
@Injectable()
export class CategoryAccessGuard implements CanActivate {
  private readonly logger = new Logger(CategoryAccessGuard.name);

  constructor(private reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const categoryKey = this.reflector.get<string>(
      CATEGORY_ACCESS_KEY,
      context.getHandler(),
    );

    if (!categoryKey) {
      return true; // No category restriction
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const canAccess = canViewProductCategory(user.role, categoryKey);

    if (!canAccess) {
      this.logger.warn(
        `Category access denied: User ${user.email || user.id} (role: ${user.role}) ` +
          `tried to access category ${categoryKey}`,
      );
      throw new ForbiddenException(`Bạn không có quyền xem danh mục này`);
    }

    return true;
  }
}

/**
 * Middleware để filter categories trong response dựa trên role
 */
@Injectable()
export class CategoryFilterInterceptor {
  private readonly logger = new Logger(CategoryFilterInterceptor.name);

  /**
   * Filter products array based on user's viewable categories
   */
  filterProductsByCategory<T extends { category?: string }>(
    products: T[],
    userRole: string,
  ): T[] {
    return products.filter((product) => {
      if (!product.category) return true;
      return canViewProductCategory(userRole, product.category);
    });
  }

  /**
   * Get viewable categories for a role
   */
  getViewableCategories(userRole: string): string[] {
    return Object.entries(PRODUCT_CATEGORY_VISIBILITY)
      .filter(([_, roles]) => roles.includes(userRole as AppRole))
      .map(([category, _]) => category);
  }

  /**
   * Check if user can view category
   */
  canViewCategory(userRole: string, category: string): boolean {
    return canViewProductCategory(userRole, category);
  }
}

/**
 * Factory để tạo Category Guard với config cụ thể
 */
export function RequireCategoryAccess(categoryKey: string): Type<CanActivate> {
  @Injectable()
  class CategoryAccessGuardMixin implements CanActivate {
    private readonly logger = new Logger('CategoryAccessGuard');

    async canActivate(context: ExecutionContext): Promise<boolean> {
      const request = context.switchToHttp().getRequest();
      const user = request.user;

      if (!user) {
        throw new ForbiddenException('Bạn cần đăng nhập');
      }

      const canAccess = canViewProductCategory(user.role, categoryKey);

      if (!canAccess) {
        this.logger.warn(
          `Category access denied: User ${user.email || user.id} (role: ${user.role}) ` +
            `tried to access category ${categoryKey}`,
        );
        throw new ForbiddenException(`Bạn không có quyền xem danh mục này`);
      }

      return true;
    }
  }

  return mixin(CategoryAccessGuardMixin);
}

// Pre-built category access guards

/**
 * Building Materials Category Guard - Tất cả roles
 */
export const BuildingMaterialsAccessGuard =
  RequireCategoryAccess('building_materials');

/**
 * Heavy Machinery Category Guard - Chỉ cho Engineer, Contractor trở lên
 */
export const HeavyMachineryAccessGuard =
  RequireCategoryAccess('heavy_machinery');

/**
 * Safety Equipment Category Guard - Staff trở lên
 */
export const SafetyEquipmentAccessGuard =
  RequireCategoryAccess('safety_equipment');

/**
 * Electrical Category Guard - Engineer trở lên
 */
export const ElectricalAccessGuard = RequireCategoryAccess('electrical');

/**
 * Plumbing Category Guard - Engineer trở lên
 */
export const PlumbingAccessGuard = RequireCategoryAccess('plumbing');

/**
 * Interior Design Category Guard - Designer trở lên
 */
export const InteriorDesignAccessGuard =
  RequireCategoryAccess('interior_design');

/**
 * Raw Materials Category Guard - Supplier trở lên (nhạy cảm về giá)
 */
export const RawMaterialsAccessGuard = RequireCategoryAccess('raw_materials');

/**
 * Wholesale Category Guard - Admin Only (nhạy cảm về giá sỉ)
 */
export const WholesaleAccessGuard = RequireCategoryAccess('wholesale');

/**
 * Internal Supplies Category Guard - Staff Only (nội bộ)
 */
export const InternalSuppliesAccessGuard =
  RequireCategoryAccess('internal_supplies');

/**
 * Premium Products Category Guard - Chỉ cho Engineer, Architect trở lên
 */
export const PremiumProductsAccessGuard =
  RequireCategoryAccess('premium_products');
