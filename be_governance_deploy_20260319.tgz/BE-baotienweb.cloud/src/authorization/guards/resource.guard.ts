/**
 * Resource Guard
 * ===============
 * Guard kiểm tra quyền truy cập dựa trên ownership và resource context
 */

import {
    CanActivate,
    ExecutionContext,
    ForbiddenException,
    Injectable,
    Logger,
    Type,
    mixin,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import {
    Permission,
    PermissionType,
    getRoleLevel,
    hasPermission,
} from '../constants/roles.constant';

export interface ResourceOwnershipConfig {
  // Field trong request.params chứa resource ID
  resourceIdParam?: string;
  // Field trong resource data chứa owner ID
  ownerField?: string;
  // Permission cần thiết để truy cập resource của mình
  ownPermission?: PermissionType;
  // Permission cần thiết để truy cập tất cả resources
  allPermission?: PermissionType;
  // Roles được phép truy cập tất cả
  bypassRoles?: string[];
}

/**
 * Base Resource Guard - kiểm tra ownership
 */
@Injectable()
export class ResourceGuard implements CanActivate {
  protected readonly logger = new Logger(ResourceGuard.name);

  constructor(protected reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    // Admin and Super Admin always pass
    if (['SUPER_ADMIN', 'ADMIN'].includes(user.role)) {
      return true;
    }

    // Get resource metadata from decorator
    const resourceConfig = this.reflector.get<ResourceOwnershipConfig>(
      'resourceOwnership',
      context.getHandler(),
    );

    // No config = allow
    if (!resourceConfig) {
      return true;
    }

    return this.checkResourceAccess(request, user, resourceConfig);
  }

  protected async checkResourceAccess(
    request: any,
    user: any,
    config: ResourceOwnershipConfig,
  ): Promise<boolean> {
    const { bypassRoles = ['SUPER_ADMIN', 'ADMIN'] } = config;

    // Check bypass roles
    if (bypassRoles.includes(user.role)) {
      return true;
    }

    // Check if user has all permission
    if (
      config.allPermission &&
      hasPermission(user.role, config.allPermission)
    ) {
      return true;
    }

    // For own permission check, we need to verify ownership in controller
    // This guard just checks if user has the own permission
    if (
      config.ownPermission &&
      hasPermission(user.role, config.ownPermission)
    ) {
      // Mark that ownership check is needed in controller
      request.requiresOwnershipCheck = true;
      request.ownerField = config.ownerField || 'userId';
      return true;
    }

    throw new ForbiddenException('Bạn không có quyền truy cập tài nguyên này');
  }
}

/**
 * Factory để tạo Resource Guard với config cụ thể
 */
export function ResourceOwnershipGuard(
  config: ResourceOwnershipConfig,
): Type<CanActivate> {
  @Injectable()
  class ResourceOwnershipGuardMixin implements CanActivate {
    private readonly logger = new Logger('ResourceOwnershipGuard');

    async canActivate(context: ExecutionContext): Promise<boolean> {
      const request = context.switchToHttp().getRequest();
      const user = request.user;

      if (!user) {
        throw new ForbiddenException('Bạn cần đăng nhập');
      }

      const {
        bypassRoles = ['SUPER_ADMIN', 'ADMIN'],
        ownPermission,
        allPermission,
        ownerField = 'userId',
      } = config;

      // Bypass roles (Admin...)
      if (bypassRoles.includes(user.role)) {
        return true;
      }

      // Has permission for all resources
      if (allPermission && hasPermission(user.role, allPermission)) {
        return true;
      }

      // Has permission for own resources - mark for controller check
      if (ownPermission && hasPermission(user.role, ownPermission)) {
        request.requiresOwnershipCheck = true;
        request.ownerField = ownerField;
        return true;
      }

      this.logger.warn(
        `Resource access denied: User ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException(
        'Bạn không có quyền truy cập tài nguyên này',
      );
    }
  }

  return mixin(ResourceOwnershipGuardMixin);
}

/**
 * Project Access Guard - kiểm tra quyền truy cập project
 */
export const ProjectAccessGuard = ResourceOwnershipGuard({
  ownPermission: Permission.PROJECT_VIEW_OWN,
  allPermission: Permission.PROJECT_VIEW_ALL,
  ownerField: 'ownerId',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN', 'STAFF'],
});

/**
 * Task Access Guard - kiểm tra quyền truy cập task
 */
export const TaskAccessGuard = ResourceOwnershipGuard({
  ownPermission: Permission.TASK_VIEW_ASSIGNED,
  allPermission: Permission.TASK_VIEW_ALL,
  ownerField: 'assigneeId',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN', 'STAFF', 'ENGINEER'],
});

/**
 * Product Access Guard - kiểm tra quyền truy cập product
 */
export const ProductAccessGuard = ResourceOwnershipGuard({
  ownPermission: Permission.PRODUCT_VIEW_APPROVED,
  allPermission: Permission.PRODUCT_VIEW_ALL,
  ownerField: 'sellerId',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN', 'STAFF'],
});

/**
 * Finance Access Guard - kiểm tra quyền xem tài chính
 */
export const FinanceResourceGuard = ResourceOwnershipGuard({
  ownPermission: Permission.FINANCE_VIEW_OWN,
  allPermission: Permission.FINANCE_VIEW_ALL,
  ownerField: 'userId',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN'],
});

/**
 * Document Access Guard - kiểm tra quyền truy cập document
 */
export const DocumentAccessGuard = ResourceOwnershipGuard({
  ownPermission: Permission.DOCUMENT_VIEW_PROJECT,
  allPermission: Permission.DOCUMENT_VIEW_ALL,
  ownerField: 'uploadedBy',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN', 'STAFF', 'ENGINEER', 'ARCHITECT'],
});

/**
 * Report Access Guard - kiểm tra quyền xem báo cáo
 */
export const ReportAccessGuard = ResourceOwnershipGuard({
  ownPermission: Permission.REPORT_VIEW_PROJECT,
  allPermission: Permission.REPORT_VIEW_ALL,
  ownerField: 'createdBy',
  bypassRoles: ['SUPER_ADMIN', 'ADMIN'],
});

/**
 * Role Hierarchy Guard - chỉ cho phép quản lý users có role thấp hơn
 */
@Injectable()
export class RoleHierarchyGuard implements CanActivate {
  private readonly logger = new Logger(RoleHierarchyGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    // Get target user role from request body or params
    const targetRole = request.body?.role || request.params?.targetRole;

    if (!targetRole) {
      return true; // No target role specified
    }

    const userLevel = getRoleLevel(user.role);
    const targetLevel = getRoleLevel(targetRole);

    // Can only manage users with lower role level
    if (targetLevel >= userLevel) {
      this.logger.warn(
        `Role hierarchy violation: ${user.email} (${user.role}, level ${userLevel}) ` +
          `tried to manage role ${targetRole} (level ${targetLevel})`,
      );
      throw new ForbiddenException(
        'Bạn không thể quản lý người dùng có cấp bậc cao hơn hoặc bằng bạn',
      );
    }

    return true;
  }
}

/**
 * Team Member Guard - kiểm tra xem user có phải là member của project/team không
 */
@Injectable()
export class TeamMemberGuard implements CanActivate {
  private readonly logger = new Logger(TeamMemberGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    // Admin bypass
    if (['SUPER_ADMIN', 'ADMIN'].includes(user.role)) {
      return true;
    }

    // Mark that team membership check is required in controller
    request.requiresTeamMemberCheck = true;
    return true;
  }
}
