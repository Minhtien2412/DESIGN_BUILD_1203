/**
 * Menu Access Guard
 * ==================
 * Guard kiểm tra quyền truy cập menu/UI components
 */

import {
    CanActivate,
    ExecutionContext,
    ForbiddenException,
    Injectable,
    Logger,
    mixin,
    Type,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import {
    canAccessMenu
} from '../constants/roles.constant';

export const MENU_ACCESS_KEY = 'menuAccess';

/**
 * Menu Access Guard - kiểm tra quyền truy cập menu
 */
@Injectable()
export class MenuAccessGuard implements CanActivate {
  private readonly logger = new Logger(MenuAccessGuard.name);

  constructor(private reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const menuKey = this.reflector.get<string>(
      MENU_ACCESS_KEY,
      context.getHandler(),
    );

    if (!menuKey) {
      return true; // No menu restriction
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const canAccess = canAccessMenu(user.role, menuKey);

    if (!canAccess) {
      this.logger.warn(
        `Menu access denied: User ${user.email || user.id} (role: ${user.role}) ` +
          `tried to access menu ${menuKey}`,
      );
      throw new ForbiddenException(`Bạn không có quyền truy cập chức năng này`);
    }

    return true;
  }
}

/**
 * Factory để tạo Menu Guard với config cụ thể
 */
export function RequireMenuAccess(menuKey: string): Type<CanActivate> {
  @Injectable()
  class MenuAccessGuardMixin implements CanActivate {
    private readonly logger = new Logger('MenuAccessGuard');

    async canActivate(context: ExecutionContext): Promise<boolean> {
      const request = context.switchToHttp().getRequest();
      const user = request.user;

      if (!user) {
        throw new ForbiddenException('Bạn cần đăng nhập');
      }

      const canAccess = canAccessMenu(user.role, menuKey);

      if (!canAccess) {
        this.logger.warn(
          `Menu access denied: User ${user.email || user.id} (role: ${user.role}) ` +
            `tried to access menu ${menuKey}`,
        );
        throw new ForbiddenException(
          `Bạn không có quyền truy cập chức năng này`,
        );
      }

      return true;
    }
  }

  return mixin(MenuAccessGuardMixin);
}

// Pre-built menu access guards

/**
 * Dashboard Menu Guard
 */
export const DashboardAccessGuard = RequireMenuAccess('dashboard');

/**
 * Projects Menu Guard
 */
export const ProjectsMenuAccessGuard = RequireMenuAccess('projects');

/**
 * Finance Menu Guard
 */
export const FinanceMenuAccessGuard = RequireMenuAccess('finance');

/**
 * HR Menu Guard
 */
export const HRMenuAccessGuard = RequireMenuAccess('hr');

/**
 * Reports Menu Guard
 */
export const ReportsMenuAccessGuard = RequireMenuAccess('reports');

/**
 * Admin Settings Menu Guard
 */
export const AdminSettingsMenuAccessGuard = RequireMenuAccess('admin_settings');

/**
 * System Logs Menu Guard
 */
export const SystemLogsMenuAccessGuard = RequireMenuAccess('system_logs');

/**
 * Salary Menu Guard - Menu nhạy cảm
 */
export const SalaryMenuAccessGuard = RequireMenuAccess('salary');

/**
 * Cost Analysis Menu Guard - Menu nhạy cảm
 */
export const CostAnalysisMenuAccessGuard = RequireMenuAccess('cost_analysis');

/**
 * Profit Reports Menu Guard - Menu nhạy cảm nhất
 */
export const ProfitReportsMenuAccessGuard = RequireMenuAccess('profit_reports');
