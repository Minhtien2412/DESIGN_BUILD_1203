/**
 * Permission Guard
 * =================
 * Guard kiểm tra quyền truy cập dựa trên permission
 */

import {
    CanActivate,
    ExecutionContext,
    ForbiddenException,
    Injectable,
    Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import {
    hasPermission,
    Permission,
    PermissionType,
} from '../constants/roles.constant';
import { PERMISSIONS_KEY } from '../decorators/permission.decorator';

@Injectable()
export class PermissionGuard implements CanActivate {
  private readonly logger = new Logger(PermissionGuard.name);

  constructor(private reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    // Get required permissions from decorator
    const requiredPermissions = this.reflector.getAllAndOverride<
      PermissionType[]
    >(PERMISSIONS_KEY, [context.getHandler(), context.getClass()]);

    // No permissions required = allow access
    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    // No user = deny
    if (!user) {
      this.logger.warn('No user in request - permission denied');
      throw new ForbiddenException(
        'Bạn cần đăng nhập để truy cập tài nguyên này',
      );
    }

    const userRole = user.role || 'CLIENT';
    const userPermissions = user.permissions || [];

    // Check if user has ANY of the required permissions
    const hasRequiredPermission = requiredPermissions.some((permission) => {
      // Check custom user permissions first
      if (userPermissions.includes(permission)) {
        return true;
      }
      // Check role-based permissions
      return hasPermission(userRole, permission);
    });

    if (!hasRequiredPermission) {
      this.logger.warn(
        `Permission denied: User ${user.email || user.id} (role: ${userRole}) ` +
          `tried to access resource requiring [${requiredPermissions.join(', ')}]`,
      );
      throw new ForbiddenException(
        `Bạn không có quyền thực hiện thao tác này. Quyền yêu cầu: ${requiredPermissions.join(', ')}`,
      );
    }

    return true;
  }
}

/**
 * Permission Guard với logic ALL (user phải có TẤT CẢ permissions)
 */
@Injectable()
export class AllPermissionsGuard implements CanActivate {
  private readonly logger = new Logger(AllPermissionsGuard.name);

  constructor(private reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPermissions = this.reflector.getAllAndOverride<
      PermissionType[]
    >(PERMISSIONS_KEY, [context.getHandler(), context.getClass()]);

    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException(
        'Bạn cần đăng nhập để truy cập tài nguyên này',
      );
    }

    const userRole = user.role || 'CLIENT';
    const userPermissions = user.permissions || [];

    // Check if user has ALL of the required permissions
    const hasAllPermissions = requiredPermissions.every((permission) => {
      if (userPermissions.includes(permission)) {
        return true;
      }
      return hasPermission(userRole, permission);
    });

    if (!hasAllPermissions) {
      this.logger.warn(
        `All permissions denied: User ${user.email || user.id} (role: ${userRole}) ` +
          `missing some permissions from [${requiredPermissions.join(', ')}]`,
      );
      throw new ForbiddenException(
        `Bạn thiếu một số quyền để thực hiện thao tác này`,
      );
    }

    return true;
  }
}

/**
 * Admin Only Guard - chỉ ADMIN và SUPER_ADMIN
 */
@Injectable()
export class AdminGuard implements CanActivate {
  private readonly logger = new Logger(AdminGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const isAdmin = ['SUPER_ADMIN', 'ADMIN'].includes(user.role);

    if (!isAdmin) {
      this.logger.warn(
        `Admin access denied for user ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException('Chỉ quản trị viên mới có quyền truy cập');
    }

    return true;
  }
}

/**
 * Staff Or Higher Guard - STAFF, ADMIN, SUPER_ADMIN
 */
@Injectable()
export class StaffOrHigherGuard implements CanActivate {
  private readonly logger = new Logger(StaffOrHigherGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const allowedRoles = [
      'SUPER_ADMIN',
      'ADMIN',
      'STAFF',
      'ENGINEER',
      'ARCHITECT',
    ];
    const isAllowed = allowedRoles.includes(user.role);

    if (!isAllowed) {
      this.logger.warn(
        `Staff access denied for user ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException('Bạn không có quyền truy cập chức năng này');
    }

    return true;
  }
}

/**
 * Product Approval Guard - chỉ những role có quyền duyệt sản phẩm
 */
@Injectable()
export class ProductApprovalGuard implements CanActivate {
  private readonly logger = new Logger(ProductApprovalGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const canApprove = hasPermission(user.role, Permission.PRODUCT_APPROVE);

    if (!canApprove) {
      this.logger.warn(
        `Product approval denied for user ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException('Bạn không có quyền duyệt sản phẩm');
    }

    return true;
  }
}

/**
 * Finance Access Guard - kiểm tra quyền xem tài chính
 */
@Injectable()
export class FinanceAccessGuard implements CanActivate {
  private readonly logger = new Logger(FinanceAccessGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const canAccessFinance =
      hasPermission(user.role, Permission.FINANCE_VIEW_ALL) ||
      hasPermission(user.role, Permission.FINANCE_VIEW_PROJECT) ||
      hasPermission(user.role, Permission.FINANCE_VIEW_OWN);

    if (!canAccessFinance) {
      this.logger.warn(
        `Finance access denied for user ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException(
        'Bạn không có quyền xem thông tin tài chính',
      );
    }

    return true;
  }
}

/**
 * Sensitive Data Guard - kiểm tra quyền xem dữ liệu nhạy cảm
 */
@Injectable()
export class SensitiveDataGuard implements CanActivate {
  private readonly logger = new Logger(SensitiveDataGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Bạn cần đăng nhập');
    }

    const canAccessSensitive =
      hasPermission(user.role, Permission.SENSITIVE_VIEW_SALARY) ||
      hasPermission(user.role, Permission.SENSITIVE_VIEW_COST) ||
      hasPermission(user.role, Permission.SENSITIVE_VIEW_PROFIT);

    if (!canAccessSensitive) {
      this.logger.warn(
        `Sensitive data access denied for user ${user.email || user.id} (role: ${user.role})`,
      );
      throw new ForbiddenException('Bạn không có quyền xem dữ liệu nhạy cảm');
    }

    return true;
  }
}
