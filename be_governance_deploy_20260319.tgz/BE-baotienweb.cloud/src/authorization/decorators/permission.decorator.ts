/**
 * Permission Decorators
 * =====================
 * Decorators để đánh dấu quyền cần thiết cho endpoints
 */

import { CustomDecorator, SetMetadata } from '@nestjs/common';
import {
    AppRole,
    Permission,
    PermissionType,
} from '../constants/roles.constant';

// Metadata keys
export const PERMISSIONS_KEY = 'permissions';
export const ROLES_KEY = 'roles';
export const RESOURCE_OWNERSHIP_KEY = 'resourceOwnership';
export const MIN_ROLE_LEVEL_KEY = 'minRoleLevel';

/**
 * Decorator yêu cầu một hoặc nhiều permission (OR logic - cần ít nhất 1)
 * @example
 * @RequirePermission(Permission.PRODUCT_CREATE)
 * @RequirePermission(Permission.PRODUCT_APPROVE, Permission.ADMIN_PANEL_ACCESS)
 */
export const RequirePermission = (
  ...permissions: PermissionType[]
): CustomDecorator<string> => SetMetadata(PERMISSIONS_KEY, permissions);

/**
 * Decorator yêu cầu TẤT CẢ permissions (AND logic)
 * @example
 * @RequireAllPermissions(Permission.PRODUCT_CREATE, Permission.PRODUCT_APPROVE)
 */
export const RequireAllPermissions = (
  ...permissions: PermissionType[]
): CustomDecorator<string> => SetMetadata('allPermissions', permissions);

/**
 * Decorator yêu cầu một trong các roles
 * @example
 * @RequireRole(AppRole.ADMIN, AppRole.STAFF)
 */
export const RequireRole = (
  ...roles: (AppRole | string)[]
): CustomDecorator<string> => SetMetadata(ROLES_KEY, roles);

/**
 * Decorator chỉ cho phép Admin
 */
export const AdminOnly = () => RequireRole(AppRole.SUPER_ADMIN, AppRole.ADMIN);

/**
 * Decorator chỉ cho phép Super Admin
 */
export const SuperAdminOnly = () => RequireRole(AppRole.SUPER_ADMIN);

/**
 * Decorator cho phép Staff trở lên
 */
export const StaffOrHigher = () =>
  RequireRole(AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF);

/**
 * Decorator cho phép Engineer trở lên
 */
export const EngineerOrHigher = () =>
  RequireRole(
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.ENGINEER,
    AppRole.ARCHITECT,
  );

/**
 * Decorator đánh dấu resource ownership config
 */
export interface ResourceOwnershipOptions {
  ownerField?: string; // Field chứa owner ID trong resource
  ownPermission?: PermissionType; // Permission để truy cập resource của mình
  allPermission?: PermissionType; // Permission để truy cập tất cả
  bypassRoles?: string[]; // Roles được bypass
}

export const ResourceOwnership = (
  options: ResourceOwnershipOptions,
): CustomDecorator<string> => SetMetadata(RESOURCE_OWNERSHIP_KEY, options);

/**
 * Decorator yêu cầu role level tối thiểu
 */
export const MinRoleLevel = (level: number): CustomDecorator<string> =>
  SetMetadata(MIN_ROLE_LEVEL_KEY, level);

// ==================== PRODUCT PERMISSIONS ====================

/**
 * Cho phép tạo product
 */
export const CanCreateProduct = () =>
  RequirePermission(Permission.PRODUCT_CREATE);

/**
 * Cho phép sửa product
 */
export const CanEditProduct = () =>
  RequirePermission(
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PRODUCT_UPDATE_ALL,
  );

/**
 * Cho phép xóa product
 */
export const CanDeleteProduct = () =>
  RequirePermission(
    Permission.PRODUCT_DELETE_OWN,
    Permission.PRODUCT_DELETE_ALL,
  );

/**
 * Cho phép duyệt product
 */
export const CanApproveProduct = () =>
  RequirePermission(Permission.PRODUCT_APPROVE);

/**
 * Cho phép từ chối product
 */
export const CanRejectProduct = () =>
  RequirePermission(Permission.PRODUCT_REJECT);

/**
 * Cho phép xem products đang chờ duyệt
 */
export const CanViewPendingProducts = () =>
  RequirePermission(Permission.PRODUCT_VIEW_PENDING);

// ==================== PROJECT PERMISSIONS ====================

/**
 * Cho phép tạo project
 */
export const CanCreateProject = () =>
  RequirePermission(Permission.PROJECT_CREATE);

/**
 * Cho phép xem project
 */
export const CanViewProject = () =>
  RequirePermission(
    Permission.PROJECT_VIEW_ALL,
    Permission.PROJECT_VIEW_OWN,
    Permission.PROJECT_VIEW_ASSIGNED,
  );

/**
 * Cho phép sửa project
 */
export const CanEditProject = () =>
  RequirePermission(Permission.PROJECT_UPDATE);

/**
 * Cho phép xóa project
 */
export const CanDeleteProject = () =>
  RequirePermission(Permission.PROJECT_DELETE);

// ==================== TASK PERMISSIONS ====================

/**
 * Cho phép tạo task
 */
export const CanCreateTask = () => RequirePermission(Permission.TASK_CREATE);

/**
 * Cho phép xem task
 */
export const CanViewTask = () =>
  RequirePermission(Permission.TASK_VIEW_ALL, Permission.TASK_VIEW_ASSIGNED);

/**
 * Cho phép assign task
 */
export const CanAssignTask = () => RequirePermission(Permission.TASK_ASSIGN);

// ==================== FINANCE PERMISSIONS ====================

/**
 * Cho phép xem tài chính
 */
export const CanViewFinance = () =>
  RequirePermission(
    Permission.FINANCE_VIEW_ALL,
    Permission.FINANCE_VIEW_PROJECT,
    Permission.FINANCE_VIEW_OWN,
  );

/**
 * Cho phép tạo thanh toán
 */
export const CanCreatePayment = () =>
  RequirePermission(Permission.FINANCE_CREATE_INVOICE);

/**
 * Cho phép duyệt thanh toán
 */
export const CanApprovePayment = () =>
  RequirePermission(Permission.FINANCE_APPROVE_PAYMENT);

// ==================== USER MANAGEMENT PERMISSIONS ====================

/**
 * Cho phép xem danh sách users
 */
export const CanViewUsers = () =>
  RequirePermission(Permission.USER_VIEW_ALL, Permission.USER_VIEW_TEAM);

/**
 * Cho phép tạo user
 */
export const CanCreateUser = () => RequirePermission(Permission.USER_CREATE);

/**
 * Cho phép sửa user
 */
export const CanEditUser = () => RequirePermission(Permission.USER_UPDATE);

/**
 * Cho phép xóa user
 */
export const CanDeleteUser = () => RequirePermission(Permission.USER_DELETE);

/**
 * Cho phép gán role
 */
export const CanAssignRole = () =>
  RequirePermission(Permission.USER_ASSIGN_ROLE);

// ==================== ADMIN PERMISSIONS ====================

/**
 * Cho phép truy cập Admin Panel
 */
export const CanAccessAdminPanel = () =>
  RequirePermission(Permission.ADMIN_PANEL_ACCESS);

/**
 * Cho phép xem logs
 */
export const CanViewLogs = () => RequirePermission(Permission.ADMIN_VIEW_LOGS);

/**
 * Cho phép cấu hình hệ thống
 */
export const CanConfigSystem = () =>
  RequirePermission(Permission.ADMIN_SYSTEM_CONFIG);

// ==================== SENSITIVE DATA PERMISSIONS ====================

/**
 * Cho phép xem lương
 */
export const CanViewSalary = () =>
  RequirePermission(Permission.SENSITIVE_VIEW_SALARY);

/**
 * Cho phép xem chi phí
 */
export const CanViewCost = () =>
  RequirePermission(Permission.SENSITIVE_VIEW_COST);

/**
 * Cho phép xem lợi nhuận
 */
export const CanViewProfit = () =>
  RequirePermission(Permission.SENSITIVE_VIEW_PROFIT);

// ==================== COMBINED DECORATORS ====================

/**
 * Product Management - Tổng hợp permission cho quản lý sản phẩm
 */
export const ProductManagement = () =>
  RequirePermission(
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PRODUCT_UPDATE_ALL,
    Permission.PRODUCT_APPROVE,
  );

/**
 * Project Management - Tổng hợp permission cho quản lý dự án
 */
export const ProjectManagement = () =>
  RequirePermission(
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.PROJECT_APPROVE_BUDGET,
  );

/**
 * Finance Management - Tổng hợp permission cho quản lý tài chính
 */
export const FinanceManagement = () =>
  RequirePermission(
    Permission.FINANCE_VIEW_ALL,
    Permission.FINANCE_CREATE_INVOICE,
    Permission.FINANCE_APPROVE_PAYMENT,
  );

/**
 * User Management - Tổng hợp permission cho quản lý người dùng
 */
export const UserManagement = () =>
  RequirePermission(
    Permission.USER_VIEW_ALL,
    Permission.USER_CREATE,
    Permission.USER_UPDATE,
    Permission.USER_DELETE,
    Permission.USER_ASSIGN_ROLE,
  );
