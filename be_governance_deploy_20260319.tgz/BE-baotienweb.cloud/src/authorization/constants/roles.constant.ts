/**
 * Role Definitions
 * ================
 * Định nghĩa các role và phân quyền chi tiết
 *
 * HIERARCHY (từ cao đến thấp):
 * 1. SUPER_ADMIN - Toàn quyền hệ thống
 * 2. ADMIN - Quản trị viên cấp cao
 * 3. STAFF - Nhân viên văn phòng
 * 4. CONTRACTOR - Nhà thầu (đối tác quan trọng)
 * 5. ENGINEER - Kỹ sư/Giám sát
 * 6. ARCHITECT - Kiến trúc sư
 * 7. DESIGNER - Thiết kế nội thất
 * 8. SUPPLIER - Nhà cung cấp
 * 9. CLIENT - Khách hàng
 */

// ==================== ROLE ENUM ====================
export enum AppRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  STAFF = 'STAFF',
  CONTRACTOR = 'CONTRACTOR',
  ENGINEER = 'ENGINEER',
  ARCHITECT = 'ARCHITECT',
  DESIGNER = 'DESIGNER',
  SUPPLIER = 'SUPPLIER',
  CLIENT = 'CLIENT',
}

// ==================== ROLE HIERARCHY ====================
// Higher number = higher priority/access
export const ROLE_HIERARCHY: Record<AppRole, number> = {
  [AppRole.SUPER_ADMIN]: 100,
  [AppRole.ADMIN]: 90,
  [AppRole.STAFF]: 70,
  [AppRole.CONTRACTOR]: 60,
  [AppRole.ENGINEER]: 50,
  [AppRole.ARCHITECT]: 45,
  [AppRole.DESIGNER]: 40,
  [AppRole.SUPPLIER]: 30,
  [AppRole.CLIENT]: 10,
};

// ==================== PERMISSION DEFINITIONS ====================
export const Permission = {
  // === USER MANAGEMENT ===
  USER_VIEW_ALL: 'user:view:all',
  USER_VIEW_TEAM: 'user:view:team',
  USER_CREATE: 'user:create',
  USER_UPDATE: 'user:update',
  USER_DELETE: 'user:delete',
  USER_ASSIGN_ROLE: 'user:assign:role',
  USER_BAN: 'user:ban',

  // === PRODUCT MANAGEMENT ===
  PRODUCT_VIEW_ALL: 'product:view:all',
  PRODUCT_VIEW_APPROVED: 'product:view:approved',
  PRODUCT_CREATE: 'product:create',
  PRODUCT_UPDATE_OWN: 'product:update:own',
  PRODUCT_UPDATE_ALL: 'product:update:all',
  PRODUCT_DELETE_OWN: 'product:delete:own',
  PRODUCT_DELETE_ALL: 'product:delete:all',
  PRODUCT_APPROVE: 'product:approve',
  PRODUCT_REJECT: 'product:reject',
  PRODUCT_FEATURE: 'product:feature',
  PRODUCT_VIEW_PENDING: 'product:view:pending',
  PRODUCT_VIEW_REJECTED: 'product:view:rejected',

  // === PROJECT MANAGEMENT ===
  PROJECT_VIEW_ALL: 'project:view:all',
  PROJECT_VIEW_ASSIGNED: 'project:view:assigned',
  PROJECT_VIEW_OWN: 'project:view:own',
  PROJECT_CREATE: 'project:create',
  PROJECT_UPDATE: 'project:update',
  PROJECT_DELETE: 'project:delete',
  PROJECT_ASSIGN_TEAM: 'project:assign:team',
  PROJECT_VIEW_FINANCE: 'project:view:finance',
  PROJECT_APPROVE_BUDGET: 'project:approve:budget',

  // === TASK MANAGEMENT ===
  TASK_VIEW_ALL: 'task:view:all',
  TASK_VIEW_ASSIGNED: 'task:view:assigned',
  TASK_CREATE: 'task:create',
  TASK_UPDATE: 'task:update',
  TASK_DELETE: 'task:delete',
  TASK_ASSIGN: 'task:assign',
  TASK_CHANGE_STATUS: 'task:change:status',
  TASK_APPROVE: 'task:approve',

  // === QC / QUALITY CONTROL ===
  QC_VIEW_ALL: 'qc:view:all',
  QC_VIEW_PROJECT: 'qc:view:project',
  QC_CREATE: 'qc:create',
  QC_UPDATE: 'qc:update',
  QC_APPROVE: 'qc:approve',
  QC_REPORT_BUG: 'qc:report:bug',

  // === FINANCE / PAYMENT ===
  FINANCE_VIEW_ALL: 'finance:view:all',
  FINANCE_VIEW_PROJECT: 'finance:view:project',
  FINANCE_VIEW_OWN: 'finance:view:own',
  FINANCE_CREATE_INVOICE: 'finance:create:invoice',
  FINANCE_APPROVE_PAYMENT: 'finance:approve:payment',
  FINANCE_VIEW_REPORT: 'finance:view:report',
  FINANCE_EXPORT: 'finance:export',

  // === REPORT ===
  REPORT_VIEW_ALL: 'report:view:all',
  REPORT_VIEW_PROJECT: 'report:view:project',
  REPORT_CREATE: 'report:create',
  REPORT_EXPORT: 'report:export',
  REPORT_ANALYTICS: 'report:analytics',

  // === CONTRACT ===
  CONTRACT_VIEW_ALL: 'contract:view:all',
  CONTRACT_VIEW_OWN: 'contract:view:own',
  CONTRACT_CREATE: 'contract:create',
  CONTRACT_UPDATE: 'contract:update',
  CONTRACT_SIGN: 'contract:sign',
  CONTRACT_TERMINATE: 'contract:terminate',

  // === CHAT / COMMUNICATION ===
  CHAT_VIEW_ALL: 'chat:view:all',
  CHAT_VIEW_PROJECT: 'chat:view:project',
  CHAT_CREATE_GROUP: 'chat:create:group',
  CHAT_ADMIN_GROUP: 'chat:admin:group',
  CHAT_DELETE_MESSAGE: 'chat:delete:message',

  // === DOCUMENT ===
  DOCUMENT_VIEW_ALL: 'document:view:all',
  DOCUMENT_VIEW_PROJECT: 'document:view:project',
  DOCUMENT_UPLOAD: 'document:upload',
  DOCUMENT_DELETE: 'document:delete',
  DOCUMENT_APPROVE: 'document:approve',

  // === SETTINGS ===
  SETTINGS_VIEW: 'settings:view',
  SETTINGS_UPDATE: 'settings:update',
  SETTINGS_SYSTEM: 'settings:system',

  // === SENSITIVE DATA ===
  SENSITIVE_VIEW_SALARY: 'sensitive:view:salary',
  SENSITIVE_VIEW_COST: 'sensitive:view:cost',
  SENSITIVE_VIEW_PROFIT: 'sensitive:view:profit',
  SENSITIVE_VIEW_CLIENT_INFO: 'sensitive:view:client:info',
  SENSITIVE_VIEW_CONTRACT_DETAIL: 'sensitive:view:contract:detail',

  // === ADMIN PANEL ===
  ADMIN_PANEL_ACCESS: 'admin:panel:access',
  ADMIN_VIEW_LOGS: 'admin:view:logs',
  ADMIN_VIEW_METRICS: 'admin:view:metrics',
  ADMIN_MANAGE_ROLES: 'admin:manage:roles',
  ADMIN_SYSTEM_CONFIG: 'admin:system:config',
} as const;

export type PermissionType = (typeof Permission)[keyof typeof Permission];

// ==================== ROLE PERMISSIONS MAPPING ====================
export const ROLE_PERMISSIONS: Record<AppRole, PermissionType[]> = {
  // SUPER_ADMIN - Toàn quyền
  [AppRole.SUPER_ADMIN]: Object.values(Permission),

  // ADMIN - Quản trị viên cấp cao (không có system config)
  [AppRole.ADMIN]: [
    // User management
    Permission.USER_VIEW_ALL,
    Permission.USER_CREATE,
    Permission.USER_UPDATE,
    Permission.USER_DELETE,
    Permission.USER_ASSIGN_ROLE,
    Permission.USER_BAN,
    // Product
    Permission.PRODUCT_VIEW_ALL,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_VIEW_PENDING,
    Permission.PRODUCT_VIEW_REJECTED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_ALL,
    Permission.PRODUCT_DELETE_ALL,
    Permission.PRODUCT_APPROVE,
    Permission.PRODUCT_REJECT,
    Permission.PRODUCT_FEATURE,
    // Project
    Permission.PROJECT_VIEW_ALL,
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.PROJECT_DELETE,
    Permission.PROJECT_ASSIGN_TEAM,
    Permission.PROJECT_VIEW_FINANCE,
    Permission.PROJECT_APPROVE_BUDGET,
    // Task
    Permission.TASK_VIEW_ALL,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.TASK_DELETE,
    Permission.TASK_ASSIGN,
    Permission.TASK_CHANGE_STATUS,
    Permission.TASK_APPROVE,
    // QC
    Permission.QC_VIEW_ALL,
    Permission.QC_CREATE,
    Permission.QC_UPDATE,
    Permission.QC_APPROVE,
    Permission.QC_REPORT_BUG,
    // Finance
    Permission.FINANCE_VIEW_ALL,
    Permission.FINANCE_CREATE_INVOICE,
    Permission.FINANCE_APPROVE_PAYMENT,
    Permission.FINANCE_VIEW_REPORT,
    Permission.FINANCE_EXPORT,
    // Report
    Permission.REPORT_VIEW_ALL,
    Permission.REPORT_CREATE,
    Permission.REPORT_EXPORT,
    Permission.REPORT_ANALYTICS,
    // Contract
    Permission.CONTRACT_VIEW_ALL,
    Permission.CONTRACT_CREATE,
    Permission.CONTRACT_UPDATE,
    Permission.CONTRACT_SIGN,
    Permission.CONTRACT_TERMINATE,
    // Chat
    Permission.CHAT_VIEW_ALL,
    Permission.CHAT_CREATE_GROUP,
    Permission.CHAT_ADMIN_GROUP,
    Permission.CHAT_DELETE_MESSAGE,
    // Document
    Permission.DOCUMENT_VIEW_ALL,
    Permission.DOCUMENT_UPLOAD,
    Permission.DOCUMENT_DELETE,
    Permission.DOCUMENT_APPROVE,
    // Settings
    Permission.SETTINGS_VIEW,
    Permission.SETTINGS_UPDATE,
    // Sensitive
    Permission.SENSITIVE_VIEW_SALARY,
    Permission.SENSITIVE_VIEW_COST,
    Permission.SENSITIVE_VIEW_PROFIT,
    Permission.SENSITIVE_VIEW_CLIENT_INFO,
    Permission.SENSITIVE_VIEW_CONTRACT_DETAIL,
    // Admin
    Permission.ADMIN_PANEL_ACCESS,
    Permission.ADMIN_VIEW_LOGS,
    Permission.ADMIN_VIEW_METRICS,
    Permission.ADMIN_MANAGE_ROLES,
  ],

  // STAFF - Nhân viên văn phòng
  [AppRole.STAFF]: [
    Permission.USER_VIEW_TEAM,
    Permission.PRODUCT_VIEW_ALL,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_VIEW_PENDING,
    Permission.PRODUCT_VIEW_REJECTED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PRODUCT_APPROVE,
    Permission.PRODUCT_REJECT,
    Permission.PROJECT_VIEW_ALL,
    Permission.PROJECT_CREATE,
    Permission.PROJECT_UPDATE,
    Permission.PROJECT_ASSIGN_TEAM,
    Permission.TASK_VIEW_ALL,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.TASK_ASSIGN,
    Permission.TASK_CHANGE_STATUS,
    Permission.QC_VIEW_ALL,
    Permission.QC_CREATE,
    Permission.QC_UPDATE,
    Permission.FINANCE_VIEW_PROJECT,
    Permission.FINANCE_CREATE_INVOICE,
    Permission.FINANCE_VIEW_REPORT,
    Permission.REPORT_VIEW_ALL,
    Permission.REPORT_CREATE,
    Permission.REPORT_EXPORT,
    Permission.CONTRACT_VIEW_ALL,
    Permission.CONTRACT_CREATE,
    Permission.CHAT_VIEW_ALL,
    Permission.CHAT_CREATE_GROUP,
    Permission.DOCUMENT_VIEW_ALL,
    Permission.DOCUMENT_UPLOAD,
    Permission.SETTINGS_VIEW,
    Permission.SENSITIVE_VIEW_COST,
    Permission.ADMIN_PANEL_ACCESS,
  ],

  // CONTRACTOR - Nhà thầu (đối tác quan trọng)
  [AppRole.CONTRACTOR]: [
    Permission.USER_VIEW_TEAM,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PRODUCT_DELETE_OWN,
    Permission.PROJECT_VIEW_ASSIGNED,
    Permission.PROJECT_VIEW_OWN,
    Permission.PROJECT_UPDATE,
    Permission.PROJECT_VIEW_FINANCE,
    Permission.TASK_VIEW_ALL, // Xem tất cả task trong dự án assigned
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.TASK_ASSIGN,
    Permission.TASK_CHANGE_STATUS,
    Permission.QC_VIEW_PROJECT,
    Permission.QC_CREATE,
    Permission.QC_UPDATE,
    Permission.QC_REPORT_BUG,
    Permission.FINANCE_VIEW_PROJECT,
    Permission.FINANCE_CREATE_INVOICE,
    Permission.REPORT_VIEW_PROJECT,
    Permission.REPORT_CREATE,
    Permission.CONTRACT_VIEW_OWN,
    Permission.CONTRACT_SIGN,
    Permission.CHAT_VIEW_PROJECT,
    Permission.CHAT_CREATE_GROUP,
    Permission.DOCUMENT_VIEW_PROJECT,
    Permission.DOCUMENT_UPLOAD,
    Permission.SENSITIVE_VIEW_COST,
    Permission.SENSITIVE_VIEW_CONTRACT_DETAIL,
  ],

  // ENGINEER - Kỹ sư / Giám sát
  [AppRole.ENGINEER]: [
    Permission.USER_VIEW_TEAM,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PROJECT_VIEW_ASSIGNED,
    Permission.PROJECT_UPDATE,
    Permission.TASK_VIEW_ASSIGNED,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.TASK_CHANGE_STATUS,
    Permission.QC_VIEW_PROJECT,
    Permission.QC_CREATE,
    Permission.QC_UPDATE,
    Permission.QC_REPORT_BUG,
    Permission.REPORT_VIEW_PROJECT,
    Permission.REPORT_CREATE,
    Permission.CHAT_VIEW_PROJECT,
    Permission.DOCUMENT_VIEW_PROJECT,
    Permission.DOCUMENT_UPLOAD,
  ],

  // ARCHITECT - Kiến trúc sư
  [AppRole.ARCHITECT]: [
    Permission.USER_VIEW_TEAM,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PROJECT_VIEW_ASSIGNED,
    Permission.PROJECT_UPDATE,
    Permission.TASK_VIEW_ASSIGNED,
    Permission.TASK_CREATE,
    Permission.TASK_UPDATE,
    Permission.QC_VIEW_PROJECT,
    Permission.QC_CREATE,
    Permission.REPORT_VIEW_PROJECT,
    Permission.REPORT_CREATE,
    Permission.CHAT_VIEW_PROJECT,
    Permission.DOCUMENT_VIEW_PROJECT,
    Permission.DOCUMENT_UPLOAD,
    Permission.DOCUMENT_APPROVE, // Duyệt bản vẽ
  ],

  // DESIGNER - Thiết kế nội thất
  [AppRole.DESIGNER]: [
    Permission.USER_VIEW_TEAM,
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PROJECT_VIEW_ASSIGNED,
    Permission.TASK_VIEW_ASSIGNED,
    Permission.TASK_UPDATE,
    Permission.REPORT_VIEW_PROJECT,
    Permission.CHAT_VIEW_PROJECT,
    Permission.DOCUMENT_VIEW_PROJECT,
    Permission.DOCUMENT_UPLOAD,
  ],

  // SUPPLIER - Nhà cung cấp
  [AppRole.SUPPLIER]: [
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE,
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PRODUCT_DELETE_OWN,
    Permission.PROJECT_VIEW_OWN, // Xem đơn hàng của mình
    Permission.CONTRACT_VIEW_OWN,
    Permission.FINANCE_VIEW_OWN,
    Permission.CHAT_VIEW_PROJECT,
    Permission.DOCUMENT_VIEW_PROJECT,
  ],

  // CLIENT - Khách hàng
  [AppRole.CLIENT]: [
    Permission.PRODUCT_VIEW_APPROVED,
    Permission.PRODUCT_CREATE, // Có thể đăng bán sản phẩm
    Permission.PRODUCT_UPDATE_OWN,
    Permission.PROJECT_VIEW_OWN,
    Permission.QC_VIEW_PROJECT, // Xem báo cáo QC dự án của mình
    Permission.REPORT_VIEW_PROJECT,
    Permission.CONTRACT_VIEW_OWN,
    Permission.FINANCE_VIEW_OWN,
    Permission.CHAT_VIEW_PROJECT,
    Permission.DOCUMENT_VIEW_PROJECT,
  ],
};

// ==================== CATEGORY VISIBILITY ====================
// Danh mục nào hiện với role nào

export const MENU_VISIBILITY: Record<string, AppRole[]> = {
  // Admin Panel - Chỉ admin trở lên
  'admin-panel': [AppRole.SUPER_ADMIN, AppRole.ADMIN],
  'admin-users': [AppRole.SUPER_ADMIN, AppRole.ADMIN],
  'admin-settings': [AppRole.SUPER_ADMIN, AppRole.ADMIN],
  'admin-logs': [AppRole.SUPER_ADMIN, AppRole.ADMIN],

  // Product Management
  products: Object.values(AppRole), // Ai cũng xem được
  'products-pending': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'products-my': Object.values(AppRole), // Sản phẩm của tôi
  'products-create': Object.values(AppRole), // Ai cũng tạo được

  // Project Management
  projects: Object.values(AppRole),
  'projects-create': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
  ],
  'projects-finance': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
  ],
  'projects-team': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
  ],

  // Finance - Nhạy cảm
  finance: [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'finance-invoices': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
  ],
  'finance-reports': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'finance-salary': [AppRole.SUPER_ADMIN, AppRole.ADMIN], // Rất nhạy cảm

  // QC / Quality
  qc: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
    AppRole.ARCHITECT,
  ],
  'qc-approve': [AppRole.SUPER_ADMIN, AppRole.ADMIN],

  // Reports
  reports: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
  ],
  'reports-analytics': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'reports-export': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
  ],

  // Contracts - Nhạy cảm
  contracts: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.CLIENT,
  ],
  'contracts-create': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'contracts-sign': [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.CONTRACTOR,
    AppRole.CLIENT,
  ],

  // Workers/Team
  workers: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
  ],
  'workers-salary': [AppRole.SUPER_ADMIN, AppRole.ADMIN], // Nhạy cảm

  // Chat
  chat: Object.values(AppRole),
  'chat-admin': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],

  // Documents
  documents: Object.values(AppRole),
  'documents-approve': [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.ARCHITECT],

  // Settings
  settings: [AppRole.SUPER_ADMIN, AppRole.ADMIN, AppRole.STAFF],
  'settings-system': [AppRole.SUPER_ADMIN],
};

// ==================== PRODUCT CATEGORY VISIBILITY ====================
// Danh mục sản phẩm nào hiện với role nào

export const PRODUCT_CATEGORY_VISIBILITY: Record<string, AppRole[]> = {
  // Public categories - Ai cũng xem được
  ELECTRONICS: Object.values(AppRole),
  HOME: Object.values(AppRole),
  FASHION: Object.values(AppRole),
  BEAUTY: Object.values(AppRole),
  SPORTS: Object.values(AppRole),
  BOOKS: Object.values(AppRole),
  TOYS: Object.values(AppRole),
  FOOD: Object.values(AppRole),
  OTHER: Object.values(AppRole),

  // Construction specific - Professional roles only
  CONSTRUCTION_EQUIPMENT: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
    AppRole.ARCHITECT,
    AppRole.SUPPLIER,
  ],
  MATERIALS_WHOLESALE: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.SUPPLIER,
  ],
  PROFESSIONAL_SERVICES: [
    AppRole.SUPER_ADMIN,
    AppRole.ADMIN,
    AppRole.STAFF,
    AppRole.CONTRACTOR,
    AppRole.ENGINEER,
    AppRole.ARCHITECT,
    AppRole.DESIGNER,
  ],
};

// ==================== HELPER FUNCTIONS ====================

/**
 * Check if a role has a specific permission
 */
export function hasPermission(
  role: AppRole | string,
  permission: PermissionType,
): boolean {
  const roleKey = role as AppRole;
  const permissions = ROLE_PERMISSIONS[roleKey];
  return permissions ? permissions.includes(permission) : false;
}

/**
 * Check if role can access a menu item
 */
export function canAccessMenu(
  role: AppRole | string,
  menuKey: string,
): boolean {
  const allowedRoles = MENU_VISIBILITY[menuKey];
  if (!allowedRoles) return true; // If not defined, allow all
  return allowedRoles.includes(role as AppRole);
}

/**
 * Check if role can view a product category
 */
export function canViewProductCategory(
  role: AppRole | string,
  category: string,
): boolean {
  const allowedRoles = PRODUCT_CATEGORY_VISIBILITY[category];
  if (!allowedRoles) return true; // If not defined, allow all
  return allowedRoles.includes(role as AppRole);
}

/**
 * Get role hierarchy level
 */
export function getRoleLevel(role: AppRole | string): number {
  return ROLE_HIERARCHY[role as AppRole] || 0;
}

/**
 * Check if role1 is higher than role2
 */
export function isRoleHigher(
  role1: AppRole | string,
  role2: AppRole | string,
): boolean {
  return getRoleLevel(role1) > getRoleLevel(role2);
}

/**
 * Check if role1 can manage role2
 */
export function canManageRole(
  managerRole: AppRole | string,
  targetRole: AppRole | string,
): boolean {
  // Super admin can manage everyone
  if (managerRole === AppRole.SUPER_ADMIN) return true;
  // Cannot manage same level or higher
  return getRoleLevel(managerRole) > getRoleLevel(targetRole);
}

/**
 * Get all permissions for a role
 */
export function getRolePermissions(role: AppRole | string): PermissionType[] {
  return ROLE_PERMISSIONS[role as AppRole] || [];
}

/**
 * Get all accessible menus for a role
 */
export function getAccessibleMenus(role: AppRole | string): string[] {
  return Object.entries(MENU_VISIBILITY)
    .filter(([_, roles]) => roles.includes(role as AppRole))
    .map(([menu, _]) => menu);
}
