/**
 * Authorization Service
 * =====================
 * Service quản lý phân quyền chi tiết
 */

import { ForbiddenException, Injectable, Logger } from '@nestjs/common';
import {
    AppRole,
    canAccessMenu,
    canManageRole,
    canViewProductCategory,
    getAccessibleMenus,
    getRoleLevel,
    getRolePermissions,
    hasPermission,
    MENU_VISIBILITY,
    Permission,
    PermissionType,
    PRODUCT_CATEGORY_VISIBILITY,
    ROLE_HIERARCHY
} from './constants/roles.constant';

export interface UserContext {
  id: number;
  email: string;
  role: string;
  permissions?: string[];
}

export interface ResourceContext {
  ownerId?: number;
  projectId?: number;
  teamMembers?: number[];
}

@Injectable()
export class AuthorizationService {
  private readonly logger = new Logger(AuthorizationService.name);

  // ==================== PERMISSION CHECKS ====================

  /**
   * Check if user has a specific permission
   */
  hasPermission(user: UserContext, permission: PermissionType): boolean {
    // Check custom permissions first
    if (user.permissions?.includes(permission)) {
      return true;
    }
    // Check role-based permissions
    return hasPermission(user.role, permission);
  }

  /**
   * Check if user has any of the given permissions
   */
  hasAnyPermission(user: UserContext, permissions: PermissionType[]): boolean {
    return permissions.some((p) => this.hasPermission(user, p));
  }

  /**
   * Check if user has all of the given permissions
   */
  hasAllPermissions(user: UserContext, permissions: PermissionType[]): boolean {
    return permissions.every((p) => this.hasPermission(user, p));
  }

  /**
   * Require permission - throws if not allowed
   */
  requirePermission(
    user: UserContext,
    permission: PermissionType,
    message?: string,
  ): void {
    if (!this.hasPermission(user, permission)) {
      this.logger.warn(
        `Permission denied: ${user.email} tried to access ${permission}`,
      );
      throw new ForbiddenException(
        message || `Bạn không có quyền thực hiện thao tác này (${permission})`,
      );
    }
  }

  // ==================== MENU/UI ACCESS ====================

  /**
   * Check if user can access a menu item
   */
  canAccessMenu(user: UserContext, menuKey: string): boolean {
    return canAccessMenu(user.role, menuKey);
  }

  /**
   * Get all accessible menus for user
   */
  getAccessibleMenus(user: UserContext): string[] {
    return getAccessibleMenus(user.role);
  }

  /**
   * Get menu items with visibility status
   */
  getMenuVisibility(user: UserContext): Record<string, boolean> {
    const result: Record<string, boolean> = {};
    Object.keys(MENU_VISIBILITY).forEach((menu) => {
      result[menu] = this.canAccessMenu(user, menu);
    });
    return result;
  }

  // ==================== PRODUCT CATEGORY ACCESS ====================

  /**
   * Check if user can view a product category
   */
  canViewProductCategory(user: UserContext, category: string): boolean {
    return canViewProductCategory(user.role, category);
  }

  /**
   * Get viewable product categories for user
   */
  getViewableProductCategories(user: UserContext): string[] {
    return Object.entries(PRODUCT_CATEGORY_VISIBILITY)
      .filter(([_, roles]) => roles.includes(user.role as AppRole))
      .map(([category, _]) => category);
  }

  // ==================== RESOURCE ACCESS ====================

  /**
   * Check if user can access a resource based on ownership
   */
  canAccessResource(
    user: UserContext,
    resource: ResourceContext,
    requiredPermissionOwn: PermissionType,
    requiredPermissionAll: PermissionType,
  ): boolean {
    // Admin và Super Admin có quyền truy cập tất cả
    if (user.role === AppRole.SUPER_ADMIN || user.role === AppRole.ADMIN) {
      return true;
    }

    // Check if user is owner
    if (resource.ownerId === user.id) {
      return this.hasPermission(user, requiredPermissionOwn);
    }

    // Check if user is team member
    if (resource.teamMembers?.includes(user.id)) {
      return this.hasPermission(user, requiredPermissionOwn);
    }

    // Check if has permission for all resources
    return this.hasPermission(user, requiredPermissionAll);
  }

  /**
   * Check if user can modify a resource
   */
  canModifyResource(user: UserContext, resource: ResourceContext): boolean {
    // Admin có quyền sửa tất cả
    if (user.role === AppRole.SUPER_ADMIN || user.role === AppRole.ADMIN) {
      return true;
    }

    // Owner có quyền sửa
    if (resource.ownerId === user.id) {
      return true;
    }

    // Staff có quyền sửa trong phạm vi dự án
    if (user.role === AppRole.STAFF && resource.projectId) {
      return true;
    }

    return false;
  }

  // ==================== PRODUCT APPROVAL ====================

  /**
   * Check if user can approve products
   */
  canApproveProduct(user: UserContext): boolean {
    return this.hasPermission(user, Permission.PRODUCT_APPROVE);
  }

  /**
   * Check if user can reject products
   */
  canRejectProduct(user: UserContext): boolean {
    return this.hasPermission(user, Permission.PRODUCT_REJECT);
  }

  /**
   * Check if user can view pending products
   */
  canViewPendingProducts(user: UserContext): boolean {
    return this.hasPermission(user, Permission.PRODUCT_VIEW_PENDING);
  }

  // ==================== ROLE MANAGEMENT ====================

  /**
   * Check if user can assign a role to another user
   */
  canAssignRole(assignerRole: string, targetRole: string): boolean {
    // Must have permission to assign roles
    if (!hasPermission(assignerRole, Permission.USER_ASSIGN_ROLE)) {
      return false;
    }

    // Can only assign roles lower than your own
    return canManageRole(assignerRole, targetRole);
  }

  /**
   * Check if user can manage another user
   */
  canManageUser(managerRole: string, targetUserRole: string): boolean {
    return canManageRole(managerRole, targetUserRole);
  }

  /**
   * Get assignable roles for a user
   */
  getAssignableRoles(userRole: string): AppRole[] {
    const userLevel = getRoleLevel(userRole);
    return Object.entries(ROLE_HIERARCHY)
      .filter(([_, level]) => level < userLevel)
      .map(([role, _]) => role as AppRole);
  }

  // ==================== SENSITIVE DATA ACCESS ====================

  /**
   * Check if user can view sensitive financial data
   */
  canViewSensitiveFinance(user: UserContext): boolean {
    return this.hasAnyPermission(user, [
      Permission.SENSITIVE_VIEW_SALARY,
      Permission.SENSITIVE_VIEW_COST,
      Permission.SENSITIVE_VIEW_PROFIT,
    ]);
  }

  /**
   * Check if user can view salary information
   */
  canViewSalary(user: UserContext): boolean {
    return this.hasPermission(user, Permission.SENSITIVE_VIEW_SALARY);
  }

  /**
   * Check if user can view cost information
   */
  canViewCost(user: UserContext): boolean {
    return this.hasPermission(user, Permission.SENSITIVE_VIEW_COST);
  }

  /**
   * Check if user can view profit information
   */
  canViewProfit(user: UserContext): boolean {
    return this.hasPermission(user, Permission.SENSITIVE_VIEW_PROFIT);
  }

  // ==================== PROJECT ACCESS ====================

  /**
   * Check if user can access a project
   */
  canAccessProject(
    user: UserContext,
    projectOwnerId: number,
    projectTeamIds: number[],
  ): boolean {
    // Admin có quyền xem tất cả
    if (this.hasPermission(user, Permission.PROJECT_VIEW_ALL)) {
      return true;
    }

    // Owner of project
    if (user.id === projectOwnerId) {
      return this.hasPermission(user, Permission.PROJECT_VIEW_OWN);
    }

    // Team member
    if (projectTeamIds.includes(user.id)) {
      return this.hasPermission(user, Permission.PROJECT_VIEW_ASSIGNED);
    }

    return false;
  }

  /**
   * Check if user can view project finance
   */
  canViewProjectFinance(user: UserContext, isProjectMember: boolean): boolean {
    // Full finance access
    if (this.hasPermission(user, Permission.FINANCE_VIEW_ALL)) {
      return true;
    }

    // Project-level finance access
    if (
      isProjectMember &&
      this.hasPermission(user, Permission.FINANCE_VIEW_PROJECT)
    ) {
      return true;
    }

    // Own finance only
    if (this.hasPermission(user, Permission.FINANCE_VIEW_OWN)) {
      return true;
    }

    return false;
  }

  // ==================== ADMIN PANEL ACCESS ====================

  /**
   * Check if user can access admin panel
   */
  canAccessAdminPanel(user: UserContext): boolean {
    return this.hasPermission(user, Permission.ADMIN_PANEL_ACCESS);
  }

  /**
   * Check if user can view system logs
   */
  canViewLogs(user: UserContext): boolean {
    return this.hasPermission(user, Permission.ADMIN_VIEW_LOGS);
  }

  /**
   * Check if user can modify system config
   */
  canModifySystemConfig(user: UserContext): boolean {
    return this.hasPermission(user, Permission.ADMIN_SYSTEM_CONFIG);
  }

  // ==================== UTILITY METHODS ====================

  /**
   * Get all permissions for a user
   */
  getUserPermissions(user: UserContext): PermissionType[] {
    const rolePermissions = getRolePermissions(user.role);
    const customPermissions = (user.permissions || []) as PermissionType[];
    return [...new Set([...rolePermissions, ...customPermissions])];
  }

  /**
   * Get user authorization summary
   */
  getAuthorizationSummary(user: UserContext): {
    role: string;
    roleLevel: number;
    permissions: PermissionType[];
    accessibleMenus: string[];
    viewableCategories: string[];
    canApproveProducts: boolean;
    canAccessAdminPanel: boolean;
    canViewSensitiveData: boolean;
  } {
    return {
      role: user.role,
      roleLevel: getRoleLevel(user.role),
      permissions: this.getUserPermissions(user),
      accessibleMenus: this.getAccessibleMenus(user),
      viewableCategories: this.getViewableProductCategories(user),
      canApproveProducts: this.canApproveProduct(user),
      canAccessAdminPanel: this.canAccessAdminPanel(user),
      canViewSensitiveData: this.canViewSensitiveFinance(user),
    };
  }

  /**
   * Filter data based on user permissions (for sensitive fields)
   */
  filterSensitiveData<T extends Record<string, any>>(
    user: UserContext,
    data: T,
    sensitiveFields: { field: keyof T; permission: PermissionType }[],
  ): T {
    const filtered = { ...data };

    for (const { field, permission } of sensitiveFields) {
      if (!this.hasPermission(user, permission)) {
        delete filtered[field];
      }
    }

    return filtered;
  }
}
