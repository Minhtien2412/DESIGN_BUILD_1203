/**
 * Home Content Controller
 * =======================
 *
 * Controller cho các API liên quan đến nội dung trang chủ
 * - Banners
 * - Workers (theo category)
 * - Categories
 * - Videos featured
 * - Livestreams
 * - Services
 */

import { Controller, Get, Param, Query } from '@nestjs/common';
import {
    ApiHeader,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { HomeContentService } from './home-content.service.db';

@ApiTags('Home Content')
@Controller({ path: '', version: '1' })
@ApiHeader({ name: 'x-api-key', description: 'API Key', required: true })
export class HomeContentController {
  constructor(private readonly homeContentService: HomeContentService) {}

  // ================================
  // BANNERS
  // ================================

  @Get('banners/home')
  @ApiOperation({ summary: 'Lấy danh sách banner trang chủ' })
  @ApiResponse({ status: 200, description: 'Thành công' })
  async getHomeBanners() {
    return this.homeContentService.getHomeBanners();
  }

  @Get('banners/:position')
  @ApiOperation({ summary: 'Lấy banner theo vị trí' })
  async getBannersByPosition(@Param('position') position: string) {
    return this.homeContentService.getBannersByPosition(position);
  }

  // ================================
  // WORKERS
  // ================================

  @Get('workers')
  @ApiOperation({ summary: 'Lấy danh sách công nhân' })
  @ApiQuery({
    name: 'category',
    required: false,
    description: 'Lọc theo ngành nghề',
  })
  @ApiQuery({ name: 'limit', required: false, description: 'Số lượng kết quả' })
  async getWorkers(
    @Query('category') category?: string,
    @Query('limit') limit?: string,
  ) {
    return this.homeContentService.getWorkers(
      category,
      limit ? parseInt(limit, 10) : 10,
    );
  }

  @Get('workers/stats')
  @ApiOperation({ summary: 'Lấy thống kê công nhân' })
  async getWorkerStats() {
    return this.homeContentService.getWorkerStats();
  }

  @Get('workers/:id')
  @ApiOperation({ summary: 'Lấy chi tiết công nhân' })
  async getWorkerById(@Param('id') id: string) {
    return this.homeContentService.getWorkerById(id);
  }

  // ================================
  // CATEGORIES
  // ================================

  @Get('categories/featured')
  @ApiOperation({ summary: 'Lấy danh mục nổi bật' })
  async getFeaturedCategories() {
    return this.homeContentService.getFeaturedCategories();
  }

  @Get('categories/library')
  @ApiOperation({ summary: 'Lấy danh mục thư viện' })
  async getLibraryCategories() {
    return this.homeContentService.getLibraryCategories();
  }

  @Get('categories')
  @ApiOperation({ summary: 'Lấy tất cả danh mục' })
  @ApiQuery({ name: 'type', required: false })
  async getAllCategories(@Query('type') type?: string) {
    return this.homeContentService.getAllCategories(type);
  }

  // ================================
  // VIDEOS
  // ================================

  @Get('videos/featured')
  @ApiOperation({ summary: 'Lấy video nổi bật' })
  async getFeaturedVideos() {
    return this.homeContentService.getFeaturedVideos();
  }

  @Get('videos/trending')
  @ApiOperation({ summary: 'Lấy video trending' })
  async getTrendingVideos() {
    return this.homeContentService.getTrendingVideos();
  }

  // ================================
  // LIVESTREAMS
  // ================================

  @Get('livestreams/active')
  @ApiOperation({ summary: 'Lấy danh sách livestream đang hoạt động' })
  async getActiveLivestreams() {
    return this.homeContentService.getActiveLivestreams();
  }

  @Get('livestreams/scheduled')
  @ApiOperation({ summary: 'Lấy lịch livestream sắp tới' })
  async getScheduledLivestreams() {
    return this.homeContentService.getScheduledLivestreams();
  }

  // ================================
  // SERVICES (Home specific - avoid conflict with ServicesController)
  // ================================

  @Get('home/services/featured')
  @ApiOperation({ summary: 'Lấy dịch vụ nổi bật cho trang chủ' })
  async getFeaturedServices() {
    return this.homeContentService.getFeaturedServices();
  }

  @Get('home/services/design')
  @ApiOperation({ summary: 'Lấy dịch vụ thiết kế cho trang chủ' })
  async getDesignServices() {
    return this.homeContentService.getDesignServices();
  }

  @Get('home/services')
  @ApiOperation({ summary: 'Lấy tất cả dịch vụ cho trang chủ' })
  @ApiQuery({ name: 'type', required: false })
  async getAllServices(@Query('type') type?: string) {
    return this.homeContentService.getAllServices(type);
  }

  // ================================
  // PRODUCTS (Home specific - avoid conflict with ProductsController)
  // ================================

  @Get('home/products/equipment')
  @ApiOperation({ summary: 'Lấy sản phẩm thiết bị cho trang chủ' })
  @ApiQuery({ name: 'limit', required: false })
  async getEquipmentProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getEquipmentProducts(
      limit ? parseInt(limit, 10) : 20,
    );
  }

  @Get('home/products/materials')
  @ApiOperation({ summary: 'Lấy vật liệu xây dựng cho trang chủ' })
  @ApiQuery({ name: 'limit', required: false })
  async getMaterialProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getMaterialProducts(
      limit ? parseInt(limit, 10) : 20,
    );
  }

  // ================================
  // HOME AGGREGATE DATA
  // ================================
  // NOTE: Flash sale, trending, bestsellers, new-arrivals, top-rated workers,
  // and stats are in HomeProductsExtraController (home-products-extra.controller.ts)

  @Get('home/data')
  @ApiOperation({
    summary: 'Lấy tất cả dữ liệu trang chủ (có thể lọc theo sections)',
  })
  @ApiQuery({
    name: 'sections',
    required: false,
    description:
      'Comma-separated section IDs: banners,services,flashSale,trending,bestsellers,newArrivals,topWorkers,stats,...',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng items cho mỗi section (mặc định 10)',
  })
  async getHomeData(
    @Query('sections') sections?: string,
    @Query('limit') limit?: string,
  ) {
    return this.homeContentService.getHomeData({
      sections,
      limit: limit ? parseInt(limit, 10) : undefined,
    });
  }

  @Get('home/sections')
  @ApiOperation({ summary: 'Lấy cấu hình section trang chủ' })
  async getHomeSections() {
    return this.homeContentService.getHomeSections();
  }
}
