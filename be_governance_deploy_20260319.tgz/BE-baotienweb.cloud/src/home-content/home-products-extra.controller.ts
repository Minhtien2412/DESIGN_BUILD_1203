/**
 * Home Products Extra Controller
 * ===============================
 *
 * Controller bổ sung cho các API sản phẩm trang chủ
 * Tách ra từ HomeContentController để đảm bảo route registration
 * - Flash Sale Products
 * - Trending Products
 * - Bestseller Products
 * - New Arrival Products
 * - Top Rated Workers
 * - Platform Stats
 */

import { Controller, Get, Query } from '@nestjs/common';
import {
    ApiHeader,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { HomeContentService } from './home-content.service.db';

@ApiTags('Home Content - Products & Stats')
@Controller({ path: 'home', version: '1' })
@ApiHeader({ name: 'x-api-key', description: 'API Key', required: true })
export class HomeProductsExtraController {
  constructor(private readonly homeContentService: HomeContentService) {}

  // ================================
  // FLASH SALE PRODUCTS
  // ================================

  @Get('products/flash-sale')
  @ApiOperation({ summary: 'Lấy sản phẩm flash sale' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng (mặc định 10)',
  })
  async getFlashSaleProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getFlashSaleProducts(
      limit ? parseInt(limit, 10) : 10,
    );
  }

  // ================================
  // TRENDING PRODUCTS
  // ================================

  @Get('products/trending')
  @ApiOperation({ summary: 'Lấy sản phẩm trending' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng (mặc định 10)',
  })
  async getTrendingProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getTrendingProducts(
      limit ? parseInt(limit, 10) : 10,
    );
  }

  // ================================
  // BESTSELLER PRODUCTS
  // ================================

  @Get('products/bestsellers')
  @ApiOperation({ summary: 'Lấy sản phẩm bán chạy nhất' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng (mặc định 6)',
  })
  async getBestsellerProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getBestsellerProducts(
      limit ? parseInt(limit, 10) : 6,
    );
  }

  // ================================
  // NEW ARRIVAL PRODUCTS
  // ================================

  @Get('products/new-arrivals')
  @ApiOperation({ summary: 'Lấy sản phẩm mới nhất' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng (mặc định 6)',
  })
  async getNewArrivalProducts(@Query('limit') limit?: string) {
    return this.homeContentService.getNewArrivalProducts(
      limit ? parseInt(limit, 10) : 6,
    );
  }

  // ================================
  // TOP RATED WORKERS
  // ================================

  @Get('workers/top-rated')
  @ApiOperation({ summary: 'Lấy thợ đánh giá cao nhất' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Số lượng (mặc định 8)',
  })
  async getTopRatedWorkers(@Query('limit') limit?: string) {
    return this.homeContentService.getTopRatedWorkers(
      limit ? parseInt(limit, 10) : 8,
    );
  }

  // ================================
  // PLATFORM STATS
  // ================================

  @Get('stats')
  @ApiOperation({
    summary: 'Lấy thống kê nền tảng (products, workers, orders)',
  })
  @ApiResponse({ status: 200, description: 'Thành công' })
  async getHomeStats() {
    return this.homeContentService.getHomeStats();
  }
}
