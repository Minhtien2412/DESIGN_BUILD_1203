/**
 * Home Content Service - Database Version
 * =========================================
 * Queries from PostgreSQL via Prisma, with mock fallback.
 * Provides all data needed by the new home screen UI:
 *   banners, services, categories, workers, products (flash sale,
 *   trending, bestsellers, new arrivals), livestreams, videos,
 *   design services, stats, and the aggregate /home/data endpoint.
 */

import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

// Worker type → Vietnamese display name
const WORKER_CATEGORY_NAMES: Record<string, string> = {
  tho_xay: 'Thợ xây',
  tho_sat: 'Thợ sắt',
  tho_coffa: 'Thợ coffa',
  ep_coc: 'Ép cọc',
  dao_dat: 'Đào đất',
  be_tong: 'Bê tông',
  nhan_cong: 'Nhân công',
  tho_dien: 'Thợ điện',
  tho_nuoc: 'Thợ nước',
  tho_dien_nuoc: 'Thợ điện nước',
  tho_may_lanh: 'Thợ máy lạnh',
  tho_son: 'Thợ sơn',
  tho_op_lat: 'Thợ ốp lát',
  tho_thach_cao: 'Thợ thạch cao',
  tho_moc: 'Thợ mộc',
  tho_han: 'Thợ hàn',
  tho_da: 'Thợ đá',
  tho_lam_cua: 'Thợ làm cửa',
  tho_lan_can: 'Thợ lan can',
  tho_cong: 'Thợ cổng',
  tho_camera: 'Thợ camera',
  tho_nhom_kinh: 'Thợ nhôm kính',
  tho_alu: 'Thợ nhôm kính',
  tho_nhom: 'Thợ nhôm',
  tho_gach: 'Thợ gạch',
  tho_cua: 'Thợ cửa',
  ky_su: 'Kỹ sư',
  kien_truc_su: 'Kiến trúc sư',
  giam_sat: 'Giám sát',
  phu_ho: 'Phụ hồ',
  lai_xe: 'Lái xe',
  other: 'Khác',
};

// Category → worker types mapping (valid DB enum values only)
const CATEGORY_WORKER_MAP: Record<string, string[]> = {
  construction: ['tho_xay', 'tho_sat'],
  finishing: [
    'tho_son',
    'tho_op_lat',
    'tho_tran_thach_cao',
    'tho_moc',
    'tho_da',
  ],
  design: ['kien_truc_su', 'ky_su'],
  electrical: ['tho_dien', 'tho_may_lanh'],
  plumbing: ['tho_nuoc'],
  aluminum: ['tho_nhom', 'tho_alu'],
};

@Injectable()
export class HomeContentService {
  private readonly logger = new Logger(HomeContentService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ================================================================
  // BANNERS
  // ================================================================

  async getHomeBanners() {
    try {
      const banners = await this.prisma.homeBanner.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
      });

      if (banners.length > 0) {
        return {
          success: true,
          data: banners.map((b) => ({
            id: String(b.id),
            title: b.title,
            subtitle: b.subtitle || '',
            image: b.imageUrl,
            link: b.link || '',
            backgroundColor: b.backgroundColor,
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB banners query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          title: 'Khuyến mãi mùa hè',
          subtitle: 'Giảm đến 30% vật liệu xây dựng',
          image: 'https://picsum.photos/800/400?random=1',
          link: '/promotions/summer',
          backgroundColor: '#FF6B35',
        },
        {
          id: '2',
          title: 'Dịch vụ thiết kế',
          subtitle: 'Miễn phí tư vấn kiến trúc',
          image: 'https://picsum.photos/800/400?random=2',
          link: '/services/design',
          backgroundColor: '#2E86AB',
        },
        {
          id: '3',
          title: 'Đội ngũ thợ xây',
          subtitle: 'Tay nghề cao, giá cả hợp lý',
          image: 'https://picsum.photos/800/400?random=3',
          link: '/workers',
          backgroundColor: '#A23B72',
        },
      ],
    };
  }

  async getBannersByPosition(position: string) {
    try {
      const banners = await this.prisma.homeBanner.findMany({
        where: { isActive: true, position },
        orderBy: { displayOrder: 'asc' },
      });

      return {
        success: true,
        data: banners.map((b) => ({
          id: String(b.id),
          title: b.title,
          subtitle: b.subtitle,
          image: b.imageUrl,
          link: b.link,
          backgroundColor: b.backgroundColor,
        })),
        position,
      };
    } catch {
      return { success: true, data: [], position };
    }
  }

  // ================================================================
  // SERVICES
  // ================================================================

  async getServices() {
    try {
      const services = await this.prisma.homeService.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
      });

      if (services.length > 0) {
        return {
          success: true,
          data: services.map((s) => ({
            id: String(s.id),
            name: s.name,
            description: s.description || '',
            icon: s.icon || 'construct-outline',
            image: s.imageUrl || '',
            link: s.link || '',
            category: '',
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB services query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Thiết kế nhà',
          description: 'Thiết kế kiến trúc & nội thất',
          icon: 'home-outline',
          image: '',
          link: '/services/design',
          category: 'design',
        },
        {
          id: '2',
          name: 'Thiết kế nội thất',
          description: 'Nội thất hiện đại, sang trọng',
          icon: 'color-palette-outline',
          image: '',
          link: '/services/interior',
          category: 'design',
        },
        {
          id: '3',
          name: 'Tra cứu xây dựng',
          description: 'Tra cứu tiêu chuẩn, quy chuẩn',
          icon: 'search-outline',
          image: '',
          link: '/services/lookup',
          category: 'tools',
        },
        {
          id: '4',
          name: 'Xin phép',
          description: 'Xin giấy phép xây dựng',
          icon: 'document-text-outline',
          image: '',
          link: '/services/permits',
          category: 'tools',
        },
        {
          id: '5',
          name: 'Hồ sơ mẫu',
          description: 'Mẫu hồ sơ xây dựng',
          icon: 'folder-outline',
          image: '',
          link: '/services/templates',
          category: 'tools',
        },
        {
          id: '6',
          name: 'Lô bàn',
          description: 'Xem ngày tốt xây dựng',
          icon: 'calendar-outline',
          image: '',
          link: '/services/calendar',
          category: 'tools',
        },
        {
          id: '7',
          name: 'Bảng màu',
          description: 'Tra cứu bảng màu sơn',
          icon: 'color-fill-outline',
          image: '',
          link: '/services/colors',
          category: 'tools',
        },
        {
          id: '8',
          name: 'Tư vấn CL',
          description: 'Tư vấn chất lượng',
          icon: 'chatbubbles-outline',
          image: '',
          link: '/services/consultation',
          category: 'consultation',
        },
      ],
    };
  }

  async getFeaturedServices() {
    try {
      const services = await this.prisma.homeService.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
        take: 6,
      });

      if (services.length > 0) {
        return {
          success: true,
          data: services.map((s) => ({
            id: String(s.id),
            name: s.name,
            description: s.description || '',
            icon: s.icon || 'construct-outline',
            price: '',
            rating: 4.8,
            orderCount: 0,
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB featured services query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Thiết kế kiến trúc',
          description: 'Thiết kế nhà ở, biệt thự, văn phòng',
          icon: 'home-outline',
          price: 'Từ 50.000đ/m²',
          rating: 4.9,
          orderCount: 1560,
        },
        {
          id: '2',
          name: 'Thi công xây dựng',
          description: 'Trọn gói từ móng đến hoàn thiện',
          icon: 'construct-outline',
          price: 'Từ 3.500.000đ/m²',
          rating: 4.8,
          orderCount: 890,
        },
        {
          id: '3',
          name: 'Tư vấn phong thủy',
          description: 'Xem hướng nhà, bố trí nội thất',
          icon: 'compass-outline',
          price: 'Từ 500.000đ/lần',
          rating: 4.7,
          orderCount: 456,
        },
      ],
    };
  }

  async getDesignServices() {
    try {
      const services = await this.prisma.homeService.findMany({
        where: {
          isActive: true,
          OR: [
            { name: { contains: 'thiết kế', mode: 'insensitive' } },
            { name: { contains: 'nội thất', mode: 'insensitive' } },
            { name: { contains: 'kiến trúc', mode: 'insensitive' } },
          ],
        },
        orderBy: { displayOrder: 'asc' },
      });

      if (services.length > 0) {
        return {
          success: true,
          data: services.map((s) => ({
            id: String(s.id),
            name: s.name,
            description: s.description || '',
            packages: [],
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB design services query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Thiết kế nội thất',
          description: 'Thiết kế phòng khách, phòng ngủ, bếp',
          packages: [
            { name: 'Cơ bản', price: 2000000 },
            { name: 'Tiêu chuẩn', price: 5000000 },
            { name: 'Cao cấp', price: 10000000 },
          ],
        },
        {
          id: '2',
          name: 'Thiết kế kiến trúc',
          description: 'Bản vẽ 2D, 3D, phối cảnh',
          packages: [
            { name: 'Bản vẽ 2D', price: 3000000 },
            { name: '3D + Phối cảnh', price: 8000000 },
            { name: 'Trọn gói', price: 15000000 },
          ],
        },
      ],
    };
  }

  async getAllServices(type?: string) {
    const featured = await this.getFeaturedServices();
    const design = await this.getDesignServices();
    return {
      success: true,
      data: { featured: featured.data, design: design.data },
      type,
    };
  }

  // ================================================================
  // CATEGORIES
  // ================================================================

  async getFeaturedCategories() {
    try {
      const categories = await this.prisma.homeCategory.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
      });

      if (categories.length > 0) {
        return {
          success: true,
          data: categories.map((c) => ({
            id: String(c.id),
            name: c.name,
            slug: c.slug,
            icon: c.icon || 'cube-outline',
            color: '#FF6B35',
            productCount: 0,
            image: c.imageUrl || '',
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB categories query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Lát gạch',
          slug: 'lat-gach',
          icon: 'grid-outline',
          color: '#FF6B35',
          productCount: 1250,
          image: '',
        },
        {
          id: '2',
          name: 'Nội quy công trình',
          slug: 'noi-quy',
          icon: 'document-text-outline',
          color: '#2E86AB',
          productCount: 890,
          image: '',
        },
        {
          id: '3',
          name: 'Bảo quản',
          slug: 'bao-quan',
          icon: 'shield-checkmark-outline',
          color: '#F7C548',
          productCount: 567,
          image: '',
        },
        {
          id: '4',
          name: 'Vật liệu xây dựng',
          slug: 'vat-lieu',
          icon: 'cube-outline',
          color: '#A23B72',
          productCount: 432,
          image: '',
        },
        {
          id: '5',
          name: 'Nội thất',
          slug: 'noi-that',
          icon: 'bed-outline',
          color: '#28A745',
          productCount: 321,
          image: '',
        },
        {
          id: '6',
          name: 'Dụng cụ',
          slug: 'dung-cu',
          icon: 'hammer-outline',
          color: '#6C757D',
          productCount: 234,
          image: '',
        },
      ],
    };
  }

  async getLibraryCategories() {
    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Mẫu nhà đẹp',
          thumbnail: 'https://picsum.photos/200/150?random=20',
          itemCount: 156,
        },
        {
          id: '2',
          name: 'Thiết kế nội thất',
          thumbnail: 'https://picsum.photos/200/150?random=21',
          itemCount: 89,
        },
        {
          id: '3',
          name: 'Phong thủy',
          thumbnail: 'https://picsum.photos/200/150?random=22',
          itemCount: 45,
        },
        {
          id: '4',
          name: 'Video hướng dẫn',
          thumbnail: 'https://picsum.photos/200/150?random=23',
          itemCount: 78,
        },
      ],
    };
  }

  async getAllCategories(type?: string) {
    const featured = await this.getFeaturedCategories();
    const library = await this.getLibraryCategories();
    return {
      success: true,
      data: { featured: featured.data, library: library.data },
      type,
    };
  }

  // ================================================================
  // WORKERS
  // ================================================================

  async getWorkers(category?: string, limit = 10) {
    try {
      const where: any = { status: 'active' };
      if (category) {
        const types = CATEGORY_WORKER_MAP[category];
        if (types) where.workerType = { in: types };
      }

      const workers = await this.prisma.worker.findMany({
        where,
        orderBy: { rating: 'desc' },
        take: limit,
      });

      if (workers.length > 0) {
        return {
          success: true,
          data: workers.map((w) => ({
            id: String(w.id),
            name: w.name,
            category: w.workerType,
            categoryName: WORKER_CATEGORY_NAMES[w.workerType] || 'Khác',
            avatar: w.avatar || `https://i.pravatar.cc/150?img=${w.id}`,
            rating: Number(w.rating),
            reviewCount: w.totalReviews || 0,
            experience: `${w.experienceYears || 0} năm`,
            location: w.city || w.location || '',
            hourlyRate: Number(w.hourlyRate),
            skills: w.specialties || [],
            verified: w.isVerified,
          })),
          total: workers.length,
          category,
        };
      }
    } catch (error) {
      this.logger.warn('DB workers query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Nguyễn Văn An',
          category: 'construction',
          categoryName: 'Xây dựng',
          avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
          rating: 4.8,
          reviewCount: 156,
          experience: '10 năm',
          location: 'Hà Nội',
          hourlyRate: 250000,
          skills: ['Xây móng', 'Đổ bê tông'],
          verified: true,
        },
        {
          id: '2',
          name: 'Trần Minh Đức',
          category: 'construction',
          categoryName: 'Xây dựng',
          avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
          rating: 4.9,
          reviewCount: 203,
          experience: '15 năm',
          location: 'TP.HCM',
          hourlyRate: 300000,
          skills: ['Xây thô', 'Gia cố'],
          verified: true,
        },
      ],
      total: 2,
      category,
    };
  }

  async getTopRatedWorkers(limit = 8) {
    try {
      const workers = await this.prisma.worker.findMany({
        where: {
          status: 'active',
          rating: { gte: 4.0 },
        },
        orderBy: [{ rating: 'desc' }, { totalReviews: 'desc' }],
        take: limit,
      });

      if (workers.length > 0) {
        return {
          success: true,
          data: workers.map((w) => ({
            id: Number(w.id),
            name: w.name,
            avatar: w.avatar || `https://i.pravatar.cc/150?img=${w.id}`,
            specialty: WORKER_CATEGORY_NAMES[w.workerType] || w.workerType,
            rating: Number(w.rating),
            reviews: w.totalReviews,
            location: w.city || w.location || 'TP.HCM',
            verified: w.isVerified,
            completedJobs: w.completedJobs || 0,
            experience: w.experienceYears || 0,
            dailyRate: Number(w.dailyRate || Number(w.hourlyRate) * 8),
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB top workers query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: 1,
          name: 'Nguyễn Văn An',
          avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
          specialty: 'Thợ xây',
          rating: 4.9,
          reviews: 203,
          location: 'TP.HCM',
          verified: true,
          completedJobs: 156,
          experience: 15,
          dailyRate: 500000,
        },
        {
          id: 2,
          name: 'Trần Minh Đức',
          avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
          specialty: 'Thợ điện',
          rating: 4.8,
          reviews: 156,
          location: 'Hà Nội',
          verified: true,
          completedJobs: 120,
          experience: 10,
          dailyRate: 450000,
        },
        {
          id: 3,
          name: 'Lê Hoàng Nam',
          avatar: 'https://randomuser.me/api/portraits/men/3.jpg',
          specialty: 'Thợ sơn',
          rating: 4.8,
          reviews: 128,
          location: 'Đà Nẵng',
          verified: true,
          completedJobs: 98,
          experience: 8,
          dailyRate: 400000,
        },
      ],
    };
  }

  async getWorkerById(id: string) {
    try {
      const wid = parseInt(id, 10);
      if (!isNaN(wid)) {
        const worker = await this.prisma.worker.findUnique({
          where: { id: wid },
        });
        if (worker) {
          return {
            success: true,
            data: {
              id: String(worker.id),
              name: worker.name,
              avatar:
                worker.avatar || `https://i.pravatar.cc/150?img=${worker.id}`,
              rating: Number(worker.rating),
              reviewCount: worker.totalReviews,
              experience: `${worker.experienceYears} năm`,
              location: worker.city || worker.location || '',
              hourlyRate: Number(worker.hourlyRate),
              skills: worker.specialties || [],
              verified: worker.isVerified,
              bio: worker.description || '',
              portfolio: [],
              availability: {
                monday: true,
                tuesday: true,
                wednesday: true,
                thursday: true,
                friday: true,
                saturday: true,
                sunday: false,
              },
            },
          };
        }
      }
    } catch (error) {
      this.logger.warn('DB worker query failed', error);
    }

    return { success: false, message: 'Không tìm thấy công nhân' };
  }

  async getWorkerStats() {
    try {
      const workers = await this.prisma.worker.findMany({
        where: { status: 'active' },
        select: { workerType: true, city: true, availability: true },
      });

      if (workers.length > 0) {
        const typeMap = new Map<string, Map<string, number>>();
        for (const w of workers) {
          const type = w.workerType;
          const city = w.city || 'Khác';
          if (!typeMap.has(type)) typeMap.set(type, new Map());
          const locMap = typeMap.get(type)!;
          locMap.set(city, (locMap.get(city) || 0) + 1);
        }

        return {
          stats: Array.from(typeMap.entries()).map(([type, locs]) => ({
            workerType: type.toUpperCase(),
            totalCount: Array.from(locs.values()).reduce((s, c) => s + c, 0),
            locations: Array.from(locs.entries()).map(([loc, count]) => ({
              location: loc,
              count,
              status: 'available',
            })),
          })),
          lastUpdated: new Date().toISOString(),
        };
      }
    } catch (error) {
      this.logger.warn('DB worker stats failed, using mock', error);
    }

    return this.getMockWorkerStats();
  }

  private getMockWorkerStats() {
    return {
      stats: [
        {
          workerType: 'EP_COC',
          totalCount: 50,
          locations: [
            { location: 'Sài Gòn', count: 25, status: 'available' },
            { location: 'Hà Nội', count: 15, status: 'available' },
          ],
        },
        {
          workerType: 'THO_XAY',
          totalCount: 95,
          locations: [
            { location: 'Sài Gòn', count: 40, status: 'available' },
            { location: 'Hà Nội', count: 30, status: 'available' },
          ],
        },
        {
          workerType: 'THO_DIEN',
          totalCount: 75,
          locations: [
            { location: 'Sài Gòn', count: 32, status: 'available' },
            { location: 'Hà Nội', count: 25, status: 'available' },
          ],
        },
        {
          workerType: 'THO_SON',
          totalCount: 60,
          locations: [
            { location: 'Sài Gòn', count: 28, status: 'available' },
            { location: 'Hà Nội', count: 20, status: 'available' },
          ],
        },
        {
          workerType: 'THO_SAT',
          totalCount: 45,
          locations: [
            { location: 'Sài Gòn', count: 22, status: 'available' },
            { location: 'Hà Nội', count: 15, status: 'available' },
          ],
        },
      ],
      lastUpdated: new Date().toISOString(),
    };
  }

  // ================================================================
  // PRODUCTS — DB-backed queries
  // ================================================================

  /** Flash Sale: top sold products with images */
  async getFlashSaleProducts(limit = 10) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED' },
        orderBy: { soldCount: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
          users_products_createdByTousers: {
            select: { id: true, name: true },
          },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => {
            const price = Number(p.price);
            const discount = Math.floor(Math.random() * 20 + 15);
            const originalPrice = Math.round(price / (1 - discount / 100));
            return {
              id: p.id,
              name: p.name,
              image: p.images[0]?.url || '',
              originalPrice,
              salePrice: price,
              sold: p.soldCount,
              total: Math.max(p.soldCount + 50, p.soldCount * 2),
              rating: 4.5 + Math.random() * 0.5,
              category: p.category,
              seller: p.users_products_createdByTousers?.name || 'Design Build',
            };
          }),
        };
      }
    } catch (error) {
      this.logger.warn('DB flash sale query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: 1,
          name: 'Máy khoan Bosch GSB 550',
          image: 'https://picsum.photos/200/200?random=50',
          originalPrice: 1500000,
          salePrice: 1250000,
          sold: 1234,
          total: 2468,
          rating: 4.8,
          category: 'EQUIPMENT',
          seller: 'Design Build',
        },
        {
          id: 2,
          name: 'Xi măng Hoàng Thạch PCB40',
          image: 'https://picsum.photos/200/200?random=51',
          originalPrice: 120000,
          salePrice: 98000,
          sold: 5678,
          total: 11356,
          rating: 4.9,
          category: 'MATERIALS',
          seller: 'Design Build',
        },
        {
          id: 3,
          name: 'Máy cắt gạch Makita',
          image: 'https://picsum.photos/200/200?random=52',
          originalPrice: 3200000,
          salePrice: 2800000,
          sold: 567,
          total: 1134,
          rating: 4.7,
          category: 'EQUIPMENT',
          seller: 'Design Build',
        },
      ],
    };
  }

  /** Trending: highest view count */
  async getTrendingProducts(limit = 10) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED' },
        orderBy: { viewCount: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
          users_products_createdByTousers: {
            select: { id: true, name: true },
          },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => ({
            id: p.id,
            name: p.name,
            image: p.images[0]?.url || '',
            price: Number(p.price),
            soldCount: p.soldCount,
            viewCount: p.viewCount,
            isNew: p.isNew,
            isBestseller: p.isBestseller,
            seller: p.users_products_createdByTousers?.name || 'Design Build',
            sellerId: p.users_products_createdByTousers?.id
              ? String(p.users_products_createdByTousers.id)
              : undefined,
            route: `/product/${p.id}`,
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB trending query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: 1,
          name: 'Sơn Dulux nội thất',
          image: 'https://picsum.photos/200/200?random=53',
          price: 850000,
          soldCount: 3400,
          viewCount: 45000,
          isNew: false,
          isBestseller: true,
          seller: 'Design Build',
          route: '/product/1',
        },
        {
          id: 2,
          name: 'Gạch ốp lát 60x60',
          image: 'https://picsum.photos/200/200?random=54',
          price: 125000,
          soldCount: 8900,
          viewCount: 38000,
          isNew: true,
          isBestseller: false,
          seller: 'Design Build',
          route: '/product/2',
        },
      ],
    };
  }

  /** Bestsellers: flagged products */
  async getBestsellerProducts(limit = 6) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED', isBestseller: true },
        orderBy: { soldCount: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
          users_products_createdByTousers: {
            select: { id: true, name: true },
          },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => ({
            id: p.id,
            name: p.name,
            image: p.images[0]?.url || '',
            price: Number(p.price),
            soldCount: p.soldCount,
            rating: 4.5 + Math.random() * 0.5,
            seller: p.users_products_createdByTousers?.name || 'Design Build',
            sellerId: p.users_products_createdByTousers?.id
              ? String(p.users_products_createdByTousers.id)
              : undefined,
            route: `/product/${p.id}`,
          })),
        };
      }
    } catch (error) {
      this.logger.warn('DB bestsellers query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: 1,
          name: 'Xi măng Hoàng Thạch',
          image: 'https://picsum.photos/200/200?random=60',
          price: 98000,
          soldCount: 5678,
          rating: 4.9,
          seller: 'Design Build',
          route: '/product/1',
        },
        {
          id: 2,
          name: 'Thép Hòa Phát D10',
          image: 'https://picsum.photos/200/200?random=61',
          price: 18500,
          soldCount: 3456,
          rating: 4.8,
          seller: 'Design Build',
          route: '/product/2',
        },
      ],
    };
  }

  /** New Arrivals: newest products */
  async getNewArrivalProducts(limit = 6) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED', isNew: true },
        orderBy: { createdAt: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
          users_products_createdByTousers: {
            select: { id: true, name: true },
          },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => {
            const daysNew = Math.max(
              1,
              Math.floor(
                (Date.now() - p.createdAt.getTime()) / (1000 * 60 * 60 * 24),
              ),
            );
            return {
              id: p.id,
              name: p.name,
              image: p.images[0]?.url || '',
              price: Number(p.price),
              daysNew,
              seller: p.users_products_createdByTousers?.name || 'Design Build',
              sellerId: p.users_products_createdByTousers?.id
                ? String(p.users_products_createdByTousers.id)
                : undefined,
              route: `/product/${p.id}`,
            };
          }),
        };
      }
    } catch (error) {
      this.logger.warn('DB new arrivals query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: 1,
          name: 'Sơn chống thấm mới',
          image: 'https://picsum.photos/200/200?random=70',
          price: 650000,
          daysNew: 3,
          seller: 'Design Build',
          route: '/product/1',
        },
        {
          id: 2,
          name: 'Gạch granite cao cấp',
          image: 'https://picsum.photos/200/200?random=71',
          price: 250000,
          daysNew: 5,
          seller: 'Design Build',
          route: '/product/2',
        },
      ],
    };
  }

  /** Equipment products */
  async getEquipmentProducts(limit = 20) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED' },
        orderBy: { soldCount: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => ({
            id: String(p.id),
            name: p.name,
            price: Number(p.price),
            originalPrice: Math.round(Number(p.price) * 1.15),
            discount: 15,
            image: p.images[0]?.url || '',
            rating: 4.5 + Math.random() * 0.5,
            soldCount: p.soldCount,
            category: 'equipment',
          })),
          total: products.length,
        };
      }
    } catch (error) {
      this.logger.warn('DB equipment query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '1',
          name: 'Máy khoan Bosch GSB 550',
          price: 1250000,
          originalPrice: 1500000,
          discount: 17,
          image: 'https://picsum.photos/200/200?random=50',
          rating: 4.8,
          soldCount: 1234,
          category: 'equipment',
        },
        {
          id: '2',
          name: 'Máy cắt gạch Makita',
          price: 2800000,
          originalPrice: 3200000,
          discount: 12,
          image: 'https://picsum.photos/200/200?random=51',
          rating: 4.7,
          soldCount: 567,
          category: 'equipment',
        },
        {
          id: '3',
          name: 'Máy trộn bê tông mini',
          price: 4500000,
          originalPrice: 5000000,
          discount: 10,
          image: 'https://picsum.photos/200/200?random=52',
          rating: 4.6,
          soldCount: 234,
          category: 'equipment',
        },
      ].slice(0, limit),
      total: 50,
    };
  }

  /** Material products */
  async getMaterialProducts(limit = 20) {
    try {
      const products = await this.prisma.product.findMany({
        where: { status: 'APPROVED' },
        orderBy: { soldCount: 'desc' },
        take: limit,
        include: {
          images: { orderBy: { displayOrder: 'asc' }, take: 1 },
        },
      });

      if (products.length > 0) {
        return {
          success: true,
          data: products.map((p) => ({
            id: String(p.id),
            name: p.name,
            price: Number(p.price),
            unit: 'item',
            image: p.images[0]?.url || '',
            rating: 4.5 + Math.random() * 0.5,
            soldCount: p.soldCount,
            category: 'materials',
          })),
          total: products.length,
        };
      }
    } catch (error) {
      this.logger.warn('DB materials query failed, using mock', error);
    }

    return {
      success: true,
      data: [
        {
          id: '10',
          name: 'Xi măng Hoàng Thạch PCB40',
          price: 98000,
          unit: 'bao',
          image: 'https://picsum.photos/200/200?random=60',
          rating: 4.9,
          soldCount: 5678,
          category: 'materials',
        },
        {
          id: '11',
          name: 'Gạch ống 6 lỗ',
          price: 2500,
          unit: 'viên',
          image: 'https://picsum.photos/200/200?random=61',
          rating: 4.8,
          soldCount: 12345,
          category: 'materials',
        },
        {
          id: '12',
          name: 'Thép Hòa Phát D10',
          price: 18500,
          unit: 'kg',
          image: 'https://picsum.photos/200/200?random=62',
          rating: 4.7,
          soldCount: 3456,
          category: 'materials',
        },
      ].slice(0, limit),
      total: 100,
    };
  }

  // ================================================================
  // VIDEOS
  // ================================================================

  async getFeaturedVideos() {
    return {
      success: true,
      data: [
        {
          id: '1',
          title: 'Hướng dẫn xây móng nhà 3 tầng',
          thumbnail: 'https://picsum.photos/400/225?random=30',
          duration: '15:32',
          views: 125000,
          author: {
            id: '1',
            name: 'Kiến Trúc Việt',
            avatar: 'https://randomuser.me/api/portraits/men/10.jpg',
          },
          createdAt: '2025-01-10',
        },
        {
          id: '2',
          title: 'Thiết kế nội thất phòng khách',
          thumbnail: 'https://picsum.photos/400/225?random=31',
          duration: '22:15',
          views: 89000,
          author: {
            id: '2',
            name: 'Nội Thất Pro',
            avatar: 'https://randomuser.me/api/portraits/women/10.jpg',
          },
          createdAt: '2025-01-08',
        },
      ],
    };
  }

  async getTrendingVideos() {
    return this.getFeaturedVideos();
  }

  // ================================================================
  // LIVESTREAMS
  // ================================================================

  async getActiveLivestreams() {
    return {
      success: true,
      data: [
        {
          id: '1',
          title: 'Live: Tư vấn thiết kế nhà miễn phí',
          thumbnail: 'https://picsum.photos/400/225?random=40',
          viewerCount: 1234,
          host: {
            id: '1',
            name: 'KTS Minh Anh',
            avatar: 'https://randomuser.me/api/portraits/women/20.jpg',
            verified: true,
          },
          startedAt: new Date().toISOString(),
          status: 'live',
        },
        {
          id: '2',
          title: 'Live: Hướng dẫn chọn vật liệu',
          thumbnail: 'https://picsum.photos/400/225?random=42',
          viewerCount: 856,
          host: {
            id: '3',
            name: 'Thợ Xây Tuấn',
            avatar: 'https://randomuser.me/api/portraits/men/25.jpg',
            verified: true,
          },
          startedAt: new Date().toISOString(),
          status: 'live',
        },
      ],
    };
  }

  async getScheduledLivestreams() {
    return {
      success: true,
      data: [
        {
          id: '3',
          title: 'Workshop: Cách đọc bản vẽ kỹ thuật',
          thumbnail: 'https://picsum.photos/400/225?random=41',
          scheduledAt: new Date(Date.now() + 86400000).toISOString(),
          host: {
            id: '2',
            name: 'Kỹ Sư Hùng',
            avatar: 'https://randomuser.me/api/portraits/men/20.jpg',
            verified: true,
          },
          status: 'scheduled',
        },
      ],
    };
  }

  // ================================================================
  // PLATFORM STATS
  // ================================================================

  async getHomeStats() {
    try {
      const [
        totalProducts,
        totalWorkers,
        soldAgg,
        ratingAgg,
        activeDeals,
        categoriesCount,
      ] = await Promise.all([
        this.prisma.product.count({ where: { status: 'APPROVED' } }),
        this.prisma.worker.count({ where: { status: 'active' } }),
        this.prisma.product.aggregate({
          _sum: { soldCount: true },
          where: { status: 'APPROVED' },
        }),
        this.prisma.worker.aggregate({
          _avg: { rating: true },
          where: { status: 'active' },
        }),
        this.prisma.product.count({
          where: { status: 'APPROVED', soldCount: { gt: 0 } },
        }),
        this.prisma.homeCategory.count({ where: { isActive: true } }),
      ]);

      return {
        success: true,
        data: {
          totalProducts,
          totalWorkers,
          totalSold: soldAgg._sum.soldCount || 0,
          avgRating: ratingAgg._avg.rating
            ? +Number(ratingAgg._avg.rating).toFixed(1)
            : 4.7,
          activeDeals,
          categoriesCount,
        },
      };
    } catch (error) {
      this.logger.warn('DB stats query failed, using mock', error);
    }

    return {
      success: true,
      data: {
        totalProducts: 500,
        totalWorkers: 200,
        totalSold: 15000,
        avgRating: 4.7,
        activeDeals: 50,
        categoriesCount: 12,
      },
    };
  }

  // ================================================================
  // HOME AGGREGATE DATA — single endpoint for entire home screen
  // ================================================================

  async getHomeData(options?: { sections?: string; limit?: number }) {
    const requestedSections = options?.sections
      ? new Set(options.sections.split(',').map((s) => s.trim()))
      : null; // null = all sections
    const defaultLimit = options?.limit || 10;

    const shouldInclude = (section: string) =>
      !requestedSections || requestedSections.has(section);

    // Build parallel query array based on requested sections
    const queries: Array<{ key: string; promise: Promise<any> }> = [];

    if (shouldInclude('banners'))
      queries.push({ key: 'banners', promise: this.getHomeBanners() });
    if (shouldInclude('services'))
      queries.push({ key: 'services', promise: this.getServices() });
    if (shouldInclude('categories'))
      queries.push({
        key: 'featuredCategories',
        promise: this.getFeaturedCategories(),
      });
    if (shouldInclude('library'))
      queries.push({
        key: 'libraryCategories',
        promise: this.getLibraryCategories(),
      });
    if (shouldInclude('livestreams'))
      queries.push({
        key: 'livestreams',
        promise: this.getActiveLivestreams(),
      });
    if (shouldInclude('videos'))
      queries.push({ key: 'videos', promise: this.getFeaturedVideos() });
    if (shouldInclude('featuredServices'))
      queries.push({
        key: 'featuredServices',
        promise: this.getFeaturedServices(),
      });
    if (shouldInclude('designServices'))
      queries.push({
        key: 'designServices',
        promise: this.getDesignServices(),
      });
    if (shouldInclude('topWorkers'))
      queries.push({
        key: 'topRatedWorkers',
        promise: this.getTopRatedWorkers(defaultLimit),
      });
    if (shouldInclude('construction'))
      queries.push({
        key: 'constructionWorkers',
        promise: this.getWorkers('construction', 5),
      });
    if (shouldInclude('finishing'))
      queries.push({
        key: 'finishingWorkers',
        promise: this.getWorkers('finishing', 5),
      });
    if (shouldInclude('flashSale'))
      queries.push({
        key: 'flashSale',
        promise: this.getFlashSaleProducts(defaultLimit),
      });
    if (shouldInclude('trending'))
      queries.push({
        key: 'trending',
        promise: this.getTrendingProducts(defaultLimit),
      });
    if (shouldInclude('bestsellers'))
      queries.push({
        key: 'bestsellers',
        promise: this.getBestsellerProducts(6),
      });
    if (shouldInclude('newArrivals'))
      queries.push({
        key: 'newArrivals',
        promise: this.getNewArrivalProducts(6),
      });
    if (shouldInclude('equipment'))
      queries.push({
        key: 'equipment',
        promise: this.getEquipmentProducts(defaultLimit),
      });
    if (shouldInclude('materials'))
      queries.push({
        key: 'materials',
        promise: this.getMaterialProducts(defaultLimit),
      });
    if (shouldInclude('stats'))
      queries.push({ key: 'stats', promise: this.getHomeStats() });

    // Execute all queries in parallel
    const results = await Promise.all(
      queries.map((q) => q.promise.catch(() => ({ data: [] }))),
    );

    // Build response object
    const data: Record<string, any> = {};
    queries.forEach((q, i) => {
      const result = results[i];
      data[q.key] = result?.data ?? result ?? [];
    });

    return {
      success: true,
      data: {
        banners: data.banners || [],
        services: data.services || [],
        categories: {
          featured: data.featuredCategories || [],
          library: data.libraryCategories || [],
        },
        livestreams: data.livestreams || [],
        videos: data.videos || [],
        featuredServices: data.featuredServices || [],
        designServices: data.designServices || [],
        workers: {
          topRated: data.topRatedWorkers || [],
          construction: data.constructionWorkers || [],
          finishing: data.finishingWorkers || [],
        },
        products: {
          flashSale: data.flashSale || [],
          trending: data.trending || [],
          bestsellers: data.bestsellers || [],
          newArrivals: data.newArrivals || [],
          equipment: data.equipment || [],
          materials: data.materials || [],
        },
        stats: data.stats || null,
      },
      timestamp: new Date().toISOString(),
    };
  }

  // ================================================================
  // HOME SECTIONS CONFIG — maps to the new UI layout
  // ================================================================

  async getHomeSections() {
    return {
      success: true,
      data: [
        { id: 'banners', title: 'Banner quảng cáo', enabled: true, order: 1 },
        { id: 'services', title: 'Dịch vụ', enabled: true, order: 2 },
        { id: 'categories', title: 'Danh mục', enabled: true, order: 3 },
        { id: 'livestreams', title: 'Live Stream', enabled: true, order: 4 },
        { id: 'flashSale', title: 'Flash Sale', enabled: true, order: 5 },
        { id: 'stats', title: 'Thống kê', enabled: true, order: 6 },
        {
          id: 'featuredServices',
          title: 'Tính năng nổi bật',
          enabled: true,
          order: 7,
        },
        {
          id: 'designServices',
          title: 'Thiết kế nội thất',
          enabled: true,
          order: 8,
        },
        {
          id: 'topWorkers',
          title: 'Thợ đánh giá cao',
          enabled: true,
          order: 9,
        },
        {
          id: 'construction',
          title: 'Xây dựng & Thi công',
          enabled: true,
          order: 10,
        },
        {
          id: 'finishing',
          title: 'Hoàn thiện',
          enabled: true,
          order: 11,
        },
        {
          id: 'trending',
          title: 'Sản phẩm nổi bật',
          enabled: true,
          order: 12,
        },
        { id: 'videos', title: 'Video xây dựng', enabled: true, order: 13 },
        {
          id: 'bestsellers',
          title: 'Bán chạy nhất',
          enabled: true,
          order: 14,
        },
        {
          id: 'newArrivals',
          title: 'Sản phẩm mới',
          enabled: true,
          order: 15,
        },
        {
          id: 'equipment',
          title: 'Thiết bị & Vật liệu',
          enabled: true,
          order: 16,
        },
        { id: 'library', title: 'Thư viện', enabled: true, order: 17 },
      ],
    };
  }

  async getHomePageData() {
    return this.getHomeData();
  }
}
