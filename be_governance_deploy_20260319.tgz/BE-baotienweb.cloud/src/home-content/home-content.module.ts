/**
 * Home Content Module
 * ===================
 *
 * Module quản lý dữ liệu cho trang chủ app
 * Bao gồm: banners, featured content, workers, categories, etc.
 */

import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { HomeContentController } from './home-content.controller';
import { HomeContentService } from './home-content.service.db';
import { HomeProductsExtraController } from './home-products-extra.controller';

@Module({
  imports: [PrismaModule],
  controllers: [HomeContentController, HomeProductsExtraController],
  providers: [HomeContentService],
  exports: [HomeContentService],
})
export class HomeContentModule {}
