/**
 * Files Scheduler Service
 * Scheduled tasks for file management (trash cleanup, etc.)
 *
 * @module files/files.scheduler
 * @created 2026-01-23
 */

import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { FilesService } from './files.service';

@Injectable()
export class FilesSchedulerService {
  private readonly logger = new Logger(FilesSchedulerService.name);

  constructor(private readonly filesService: FilesService) {}

  /**
   * Clean up expired trash items every day at 3:00 AM
   * Files in trash for more than 30 days are permanently deleted
   */
  @Cron(CronExpression.EVERY_DAY_AT_3AM)
  async handleTrashCleanup() {
    this.logger.log('Starting trash cleanup job...');

    try {
      const result = await this.filesService.cleanupExpiredTrash();
      this.logger.log(
        `Trash cleanup completed: ${result.deleted} files deleted`,
      );
    } catch (error) {
      this.logger.error('Trash cleanup job failed:', error);
    }
  }

  /**
   * Log storage statistics every day at midnight
   */
  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async handleStorageStats() {
    this.logger.log('Logging storage statistics...');
    // TODO: Implement storage statistics gathering
    // This would query the database for total files, total size, etc.
  }
}
