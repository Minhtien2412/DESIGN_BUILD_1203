/**
 * File Management Service
 * Handles file versioning, soft delete (trash), and audit logging
 *
 * @module files/files.service
 * @created 2026-01-23
 */

import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { ManagedFileAction, Prisma } from '@prisma/client';
import * as crypto from 'crypto';
import * as path from 'path';
import { PrismaService } from '../prisma/prisma.service';

// Types
interface CreateFileDto {
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  path: string;
  url?: string;
  folderId?: string;
  metadata?: Record<string, any>;
  tags?: string[];
}

interface UpdateFileDto {
  filename?: string;
  folderId?: string;
  metadata?: Record<string, any>;
  tags?: string[];
}

interface CreateVersionDto {
  filename: string;
  mimeType: string;
  size: number;
  path: string;
  url?: string;
  changeNote?: string;
  checksum?: string;
}

interface FileQueryOptions {
  includeDeleted?: boolean;
  includeTrashed?: boolean;
  folderId?: string;
  tags?: string[];
  search?: string;
  page?: number;
  limit?: number;
}

interface AuditLogContext {
  userId: string;
  userEmail?: string;
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class FilesService {
  private readonly logger = new Logger(FilesService.name);

  // Trash retention period: 30 days
  private readonly TRASH_RETENTION_DAYS = 30;

  constructor(private readonly prisma: PrismaService) {}

  // ===================== FILE CRUD =====================

  /**
   * Create a new file record
   */
  async createFile(ownerId: string, dto: CreateFileDto, ctx: AuditLogContext) {
    const file = await this.prisma.managedFile.create({
      data: {
        ownerId,
        filename: dto.filename,
        originalName: dto.originalName,
        mimeType: dto.mimeType,
        size: dto.size,
        path: dto.path,
        url: dto.url,
        folderId: dto.folderId,
        metadata: dto.metadata,
        tags: dto.tags || [],
        currentVersion: 1,
        versions: {
          create: {
            version: 1,
            filename: dto.filename,
            mimeType: dto.mimeType,
            size: dto.size,
            path: dto.path,
            url: dto.url,
            changedBy: ownerId,
            changeNote: 'Initial upload',
          },
        },
      },
      include: {
        versions: true,
        folder: true,
      },
    });

    // Audit log
    await this.createAuditLog(file.id, ManagedFileAction.CREATED, ctx, {
      filename: dto.filename,
      size: dto.size,
    });

    this.logger.log(`File created: ${file.id} by user ${ownerId}`);
    return file;
  }

  /**
   * Get file by ID
   */
  async getFile(fileId: string, includeDeleted = false) {
    const where: Prisma.ManagedFileWhereInput = { id: fileId };
    if (!includeDeleted) {
      where.isDeleted = false;
    }

    const file = await this.prisma.managedFile.findFirst({
      where,
      include: {
        versions: {
          orderBy: { version: 'desc' },
        },
        folder: true,
        auditLogs: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    return file;
  }

  /**
   * List files with filtering and pagination
   */
  async listFiles(ownerId: string, options: FileQueryOptions = {}) {
    const {
      includeDeleted = false,
      includeTrashed = false,
      folderId,
      tags,
      search,
      page = 1,
      limit = 20,
    } = options;

    const where: Prisma.ManagedFileWhereInput = { ownerId };

    // Deleted filter
    if (!includeDeleted && !includeTrashed) {
      where.isDeleted = false;
    } else if (includeTrashed && !includeDeleted) {
      // Only show trashed items
      where.isDeleted = true;
      where.permanentDeleteAt = { not: null };
    }

    // Folder filter
    if (folderId !== undefined) {
      where.folderId = folderId;
    }

    // Tags filter
    if (tags && tags.length > 0) {
      where.tags = { hasSome: tags };
    }

    // Search filter
    if (search) {
      where.OR = [
        { filename: { contains: search, mode: 'insensitive' } },
        { originalName: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [files, total] = await Promise.all([
      this.prisma.managedFile.findMany({
        where,
        include: {
          folder: true,
          _count: {
            select: { versions: true },
          },
        },
        orderBy: { updatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.managedFile.count({ where }),
    ]);

    return {
      files,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Update file metadata
   */
  async updateFile(fileId: string, dto: UpdateFileDto, ctx: AuditLogContext) {
    const file = await this.getFile(fileId);

    const updated = await this.prisma.managedFile.update({
      where: { id: fileId },
      data: {
        filename: dto.filename,
        folderId: dto.folderId,
        metadata: dto.metadata,
        tags: dto.tags,
      },
      include: {
        versions: true,
        folder: true,
      },
    });

    await this.createAuditLog(fileId, ManagedFileAction.UPDATED, ctx, {
      changes: dto,
    });

    return updated;
  }

  // ===================== VERSIONING =====================

  /**
   * Create a new version of a file
   */
  async createVersion(
    fileId: string,
    dto: CreateVersionDto,
    ctx: AuditLogContext,
  ) {
    const file = await this.getFile(fileId);
    const newVersion = file.currentVersion + 1;

    const [updatedFile, version] = await this.prisma.$transaction([
      // Update file with new current version
      this.prisma.managedFile.update({
        where: { id: fileId },
        data: {
          currentVersion: newVersion,
          filename: dto.filename,
          mimeType: dto.mimeType,
          size: dto.size,
          path: dto.path,
          url: dto.url,
        },
      }),
      // Create version record
      this.prisma.managedFileVersion.create({
        data: {
          fileId,
          version: newVersion,
          filename: dto.filename,
          mimeType: dto.mimeType,
          size: dto.size,
          path: dto.path,
          url: dto.url,
          changeNote: dto.changeNote,
          changedBy: ctx.userId,
          checksum: dto.checksum,
        },
      }),
    ]);

    await this.createAuditLog(fileId, ManagedFileAction.VERSION_CREATED, ctx, {
      versionFrom: file.currentVersion,
      versionTo: newVersion,
      changeNote: dto.changeNote,
    });

    this.logger.log(`Version ${newVersion} created for file ${fileId}`);

    return {
      file: updatedFile,
      version,
    };
  }

  /**
   * Get all versions of a file
   */
  async getVersions(fileId: string) {
    await this.getFile(fileId); // Verify file exists

    const versions = await this.prisma.managedFileVersion.findMany({
      where: { fileId },
      orderBy: { version: 'desc' },
    });

    return versions;
  }

  /**
   * Get a specific version
   */
  async getVersion(fileId: string, version: number) {
    const fileVersion = await this.prisma.managedFileVersion.findUnique({
      where: {
        fileId_version: { fileId, version },
      },
    });

    if (!fileVersion) {
      throw new NotFoundException(`Version ${version} not found`);
    }

    return fileVersion;
  }

  /**
   * Restore a previous version as the current version
   */
  async restoreVersion(fileId: string, version: number, ctx: AuditLogContext) {
    const file = await this.getFile(fileId);
    const targetVersion = await this.getVersion(fileId, version);

    const newVersion = file.currentVersion + 1;

    const [updatedFile, restoredVersion] = await this.prisma.$transaction([
      // Update file
      this.prisma.managedFile.update({
        where: { id: fileId },
        data: {
          currentVersion: newVersion,
          filename: targetVersion.filename,
          mimeType: targetVersion.mimeType,
          size: targetVersion.size,
          path: targetVersion.path,
          url: targetVersion.url,
        },
      }),
      // Create new version record referencing restored version
      this.prisma.managedFileVersion.create({
        data: {
          fileId,
          version: newVersion,
          filename: targetVersion.filename,
          mimeType: targetVersion.mimeType,
          size: targetVersion.size,
          path: targetVersion.path,
          url: targetVersion.url,
          changeNote: `Restored from version ${version}`,
          changedBy: ctx.userId,
          checksum: targetVersion.checksum,
        },
      }),
    ]);

    await this.createAuditLog(fileId, ManagedFileAction.RESTORED_VERSION, ctx, {
      restoredFromVersion: version,
      newVersion,
    });

    this.logger.log(`File ${fileId} restored to version ${version}`);

    return {
      file: updatedFile,
      version: restoredVersion,
    };
  }

  // ===================== TRASH / SOFT DELETE =====================

  /**
   * Move file to trash (soft delete)
   */
  async moveToTrash(fileId: string, ctx: AuditLogContext) {
    const file = await this.getFile(fileId);

    const permanentDeleteAt = new Date();
    permanentDeleteAt.setDate(
      permanentDeleteAt.getDate() + this.TRASH_RETENTION_DAYS,
    );

    const updated = await this.prisma.managedFile.update({
      where: { id: fileId },
      data: {
        isDeleted: true,
        deletedAt: new Date(),
        deletedBy: ctx.userId,
        permanentDeleteAt,
      },
    });

    await this.createAuditLog(fileId, ManagedFileAction.SOFT_DELETED, ctx, {
      permanentDeleteAt,
    });

    this.logger.log(`File ${fileId} moved to trash`);

    return {
      message: 'File moved to trash',
      permanentDeleteAt,
      file: updated,
    };
  }

  /**
   * Restore file from trash
   */
  async restoreFromTrash(fileId: string, ctx: AuditLogContext) {
    const file = await this.getFile(fileId, true);

    if (!file.isDeleted) {
      throw new BadRequestException('File is not in trash');
    }

    const updated = await this.prisma.managedFile.update({
      where: { id: fileId },
      data: {
        isDeleted: false,
        deletedAt: null,
        deletedBy: null,
        permanentDeleteAt: null,
      },
    });

    await this.createAuditLog(fileId, ManagedFileAction.RESTORED, ctx);

    this.logger.log(`File ${fileId} restored from trash`);

    return {
      message: 'File restored',
      file: updated,
    };
  }

  /**
   * Permanently delete a file
   */
  async permanentDelete(fileId: string, ctx: AuditLogContext) {
    const file = await this.getFile(fileId, true);

    // Log before deletion
    await this.createAuditLog(
      fileId,
      ManagedFileAction.PERMANENTLY_DELETED,
      ctx,
      {
        filename: file.filename,
        size: file.size,
      },
    );

    // Delete file and all versions (cascade)
    await this.prisma.managedFile.delete({
      where: { id: fileId },
    });

    this.logger.log(`File ${fileId} permanently deleted`);

    return {
      message: 'File permanently deleted',
    };
  }

  /**
   * Get trash contents
   */
  async getTrash(ownerId: string, page = 1, limit = 20) {
    return this.listFiles(ownerId, {
      includeTrashed: true,
      page,
      limit,
    });
  }

  /**
   * Empty trash (permanently delete all trashed files)
   */
  async emptyTrash(ownerId: string, ctx: AuditLogContext) {
    const trashedFiles = await this.prisma.managedFile.findMany({
      where: {
        ownerId,
        isDeleted: true,
      },
      select: { id: true },
    });

    for (const file of trashedFiles) {
      await this.permanentDelete(file.id, ctx);
    }

    this.logger.log(
      `Trash emptied for user ${ownerId}: ${trashedFiles.length} files`,
    );

    return {
      message: `${trashedFiles.length} files permanently deleted`,
      count: trashedFiles.length,
    };
  }

  /**
   * Auto-delete expired trash items (run via cron job)
   */
  async cleanupExpiredTrash() {
    const now = new Date();

    const expiredFiles = await this.prisma.managedFile.findMany({
      where: {
        isDeleted: true,
        permanentDeleteAt: { lte: now },
      },
      select: { id: true, ownerId: true },
    });

    this.logger.log(`Found ${expiredFiles.length} expired trash items`);

    for (const file of expiredFiles) {
      try {
        await this.permanentDelete(file.id, {
          userId: 'SYSTEM',
          userEmail: 'system@cleanup',
        });
      } catch (error) {
        this.logger.error(`Failed to delete expired file ${file.id}:`, error);
      }
    }

    return {
      deleted: expiredFiles.length,
    };
  }

  // ===================== FOLDERS =====================

  /**
   * Create a folder
   */
  async createFolder(ownerId: string, name: string, parentId?: string) {
    const folder = await this.prisma.managedFolder.create({
      data: {
        ownerId,
        name,
        parentId,
      },
      include: {
        parent: true,
      },
    });

    this.logger.log(`Folder created: ${folder.id}`);
    return folder;
  }

  /**
   * Get folder contents
   */
  async getFolderContents(
    ownerId: string,
    folderId: string | null,
    options: FileQueryOptions = {},
  ) {
    const [files, folders] = await Promise.all([
      this.listFiles(ownerId, { ...options, folderId: folderId || undefined }),
      this.prisma.managedFolder.findMany({
        where: {
          ownerId,
          parentId: folderId,
          isDeleted: false,
        },
        include: {
          _count: {
            select: { files: true, children: true },
          },
        },
        orderBy: { name: 'asc' },
      }),
    ]);

    return {
      folders,
      ...files,
    };
  }

  /**
   * Delete folder (soft delete)
   */
  async deleteFolder(folderId: string, ctx: AuditLogContext) {
    const folder = await this.prisma.managedFolder.findUnique({
      where: { id: folderId },
      include: {
        files: { select: { id: true } },
        children: { select: { id: true } },
      },
    });

    if (!folder) {
      throw new NotFoundException('Folder not found');
    }

    const permanentDeleteAt = new Date();
    permanentDeleteAt.setDate(
      permanentDeleteAt.getDate() + this.TRASH_RETENTION_DAYS,
    );

    // Soft delete folder and all files inside
    await this.prisma.$transaction([
      this.prisma.managedFolder.update({
        where: { id: folderId },
        data: {
          isDeleted: true,
          deletedAt: new Date(),
          permanentDeleteAt,
        },
      }),
      this.prisma.managedFile.updateMany({
        where: { folderId },
        data: {
          isDeleted: true,
          deletedAt: new Date(),
          deletedBy: ctx.userId,
          permanentDeleteAt,
        },
      }),
    ]);

    // Recursively delete child folders
    for (const child of folder.children) {
      await this.deleteFolder(child.id, ctx);
    }

    this.logger.log(`Folder ${folderId} moved to trash`);

    return { message: 'Folder moved to trash' };
  }

  // ===================== AUDIT LOGGING =====================

  /**
   * Create audit log entry
   */
  private async createAuditLog(
    fileId: string,
    action: ManagedFileAction,
    ctx: AuditLogContext,
    details?: Record<string, any>,
  ) {
    try {
      await this.prisma.managedFileAuditLog.create({
        data: {
          fileId,
          action,
          userId: ctx.userId,
          userEmail: ctx.userEmail,
          ipAddress: ctx.ipAddress,
          userAgent: ctx.userAgent,
          details: details || undefined,
        },
      });
    } catch (error) {
      // Don't fail the main operation if audit logging fails
      this.logger.error(`Failed to create audit log: ${error}`);
    }
  }

  /**
   * Get audit logs for a file
   */
  async getAuditLogs(fileId: string, page = 1, limit = 50) {
    const [logs, total] = await Promise.all([
      this.prisma.managedFileAuditLog.findMany({
        where: { fileId },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.managedFileAuditLog.count({ where: { fileId } }),
    ]);

    return {
      logs,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  // ===================== UTILITIES =====================

  /**
   * Calculate file checksum
   */
  calculateChecksum(buffer: Buffer): string {
    return crypto.createHash('sha256').update(buffer).digest('hex');
  }

  /**
   * Generate unique filename
   */
  generateUniqueFilename(originalName: string): string {
    const ext = path.extname(originalName);
    const name = path.basename(originalName, ext);
    const timestamp = Date.now();
    const random = crypto.randomBytes(4).toString('hex');
    return `${name}-${timestamp}-${random}${ext}`;
  }

  /**
   * Log file view
   */
  async logView(fileId: string, ctx: AuditLogContext) {
    await this.createAuditLog(fileId, ManagedFileAction.VIEWED, ctx);
  }

  /**
   * Log file download
   */
  async logDownload(fileId: string, ctx: AuditLogContext) {
    await this.createAuditLog(fileId, ManagedFileAction.DOWNLOADED, ctx);
  }
}
