/**
 * File Management Controller
 * REST API for file versioning, trash, and management
 *
 * @module files/files.controller
 * @created 2026-01-23
 */

import {
    Body,
    Controller,
    DefaultValuePipe,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiProperty,
    ApiPropertyOptional,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsInt,
    IsNotEmpty,
    IsObject,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';
import { Request } from 'express';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    ApiCrudErrors,
    ApiDeleteResponse,
    ApiStandardErrors,
} from '../shared/decorators/api-error-responses.decorator';
import { FilesService } from './files.service';

interface AuthenticatedRequest extends Request {
  user: {
    id: string | number;
    email: string;
  };
}

// Helper to coerce user ID to string (JWT may return int)
function userId(req: AuthenticatedRequest): string {
  return String(req.user.id);
}

// DTOs
class CreateFileDto {
  @ApiProperty({ description: 'Filename', example: 'report.pdf' })
  @IsString()
  @IsNotEmpty()
  filename: string;

  @ApiProperty({
    description: 'Original upload name',
    example: 'Monthly Report.pdf',
  })
  @IsString()
  @IsNotEmpty()
  originalName: string;

  @ApiProperty({ description: 'MIME type', example: 'application/pdf' })
  @IsString()
  @IsNotEmpty()
  mimeType: string;

  @ApiProperty({ description: 'File size in bytes', example: 204800 })
  @Type(() => Number)
  @IsInt()
  @Min(0)
  size: number;

  @ApiProperty({
    description: 'Storage path',
    example: 'uploads/2024/report.pdf',
  })
  @IsString()
  @IsNotEmpty()
  path: string;

  @ApiPropertyOptional({ description: 'Public URL' })
  @IsOptional()
  @IsString()
  url?: string;

  @ApiPropertyOptional({ description: 'Parent folder ID' })
  @IsOptional()
  @IsString()
  folderId?: string;

  @ApiPropertyOptional({ description: 'Additional metadata' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;

  @ApiPropertyOptional({ description: 'Tags', example: ['invoice', 'Q1'] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}

class UpdateFileDto {
  @ApiPropertyOptional({ description: 'New filename' })
  @IsOptional()
  @IsString()
  filename?: string;

  @ApiPropertyOptional({ description: 'Move to folder' })
  @IsOptional()
  @IsString()
  folderId?: string;

  @ApiPropertyOptional({ description: 'Additional metadata' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;

  @ApiPropertyOptional({ description: 'Tags' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}

class CreateVersionDto {
  @ApiProperty({ description: 'Filename' })
  @IsString()
  @IsNotEmpty()
  filename: string;

  @ApiProperty({ description: 'MIME type' })
  @IsString()
  @IsNotEmpty()
  mimeType: string;

  @ApiProperty({ description: 'File size in bytes' })
  @Type(() => Number)
  @IsInt()
  @Min(0)
  size: number;

  @ApiProperty({ description: 'Storage path' })
  @IsString()
  @IsNotEmpty()
  path: string;

  @ApiPropertyOptional({ description: 'Public URL' })
  @IsOptional()
  @IsString()
  url?: string;

  @ApiPropertyOptional({ description: 'Change note' })
  @IsOptional()
  @IsString()
  changeNote?: string;
}

class CreateFolderDto {
  @ApiProperty({ description: 'Folder name', example: 'Documents' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Parent folder ID (omit for root)' })
  @IsOptional()
  @IsString()
  parentId?: string;
}

@ApiTags('files')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('files')
export class FilesController {
  constructor(private readonly filesService: FilesService) {}

  private getAuditContext(req: AuthenticatedRequest) {
    return {
      userId: userId(req),
      userEmail: req.user.email,
      ipAddress: req.ip || req.connection?.remoteAddress,
      userAgent: req.headers['user-agent'],
    };
  }

  // ===================== FILES =====================

  @Post()
  @ApiOperation({ summary: 'Create file record' })
  @ApiResponse({ status: 201, description: 'File created successfully' })
  @ApiStandardErrors()
  async createFile(
    @Req() req: AuthenticatedRequest,
    @Body() dto: CreateFileDto,
  ) {
    return this.filesService.createFile(
      userId(req),
      dto,
      this.getAuditContext(req),
    );
  }

  @Get()
  @ApiOperation({ summary: 'List files' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'folderId', required: false, type: String })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'tags', required: false, type: String, isArray: true })
  @ApiStandardErrors()
  async listFiles(
    @Req() req: AuthenticatedRequest,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
    @Query('folderId') folderId?: string,
    @Query('search') search?: string,
    @Query('tags') tags?: string[],
  ) {
    return this.filesService.listFiles(userId(req), {
      page,
      limit,
      folderId,
      search,
      tags: typeof tags === 'string' ? [tags] : tags,
    });
  }

  // ===================== TRASH (literal routes before :id) =====================

  @Get('trash')
  @ApiOperation({ summary: 'Get trash contents' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiStandardErrors()
  async getTrash(
    @Req() req: AuthenticatedRequest,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
  ) {
    return this.filesService.getTrash(userId(req), page, limit);
  }

  @Delete('trash/empty')
  @ApiOperation({ summary: 'Empty trash' })
  @ApiDeleteResponse()
  async emptyTrash(@Req() req: AuthenticatedRequest) {
    return this.filesService.emptyTrash(userId(req), this.getAuditContext(req));
  }

  // ===================== FOLDERS (literal routes before :id) =====================

  @Post('folders')
  @ApiOperation({ summary: 'Create folder' })
  @ApiResponse({ status: 201, description: 'Folder created' })
  @ApiStandardErrors()
  async createFolder(
    @Req() req: AuthenticatedRequest,
    @Body() dto: CreateFolderDto,
  ) {
    return this.filesService.createFolder(userId(req), dto.name, dto.parentId);
  }

  @Get('folders/:id/contents')
  @ApiOperation({ summary: 'Get folder contents' })
  @ApiParam({
    name: 'id',
    description: 'Folder ID (or "root" for root folder)',
  })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiCrudErrors()
  async getFolderContents(
    @Req() req: AuthenticatedRequest,
    @Param('id') id: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
  ) {
    const folderId = id === 'root' ? null : id;
    return this.filesService.getFolderContents(userId(req), folderId, {
      page,
      limit,
    });
  }

  @Delete('folders/:id')
  @ApiOperation({ summary: 'Delete folder (soft delete)' })
  @ApiParam({ name: 'id', description: 'Folder ID' })
  @ApiDeleteResponse()
  async deleteFolder(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.deleteFolder(id, this.getAuditContext(req));
  }

  // ===================== PARAMETERIZED :id ROUTES =====================

  @Get(':id')
  @ApiOperation({ summary: 'Get file by ID' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiResponse({ status: 200, description: 'File details' })
  @ApiCrudErrors()
  async getFile(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    const file = await this.filesService.getFile(id);
    await this.filesService.logView(id, this.getAuditContext(req));
    return file;
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update file metadata' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiResponse({ status: 200, description: 'File updated' })
  @ApiCrudErrors()
  async updateFile(
    @Param('id') id: string,
    @Body() dto: UpdateFileDto,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.updateFile(id, dto, this.getAuditContext(req));
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Move file to trash (soft delete)' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiDeleteResponse()
  async moveToTrash(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    return this.filesService.moveToTrash(id, this.getAuditContext(req));
  }

  @Post(':id/restore')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Restore file from trash' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiResponse({ status: 200, description: 'File restored' })
  @ApiCrudErrors()
  async restoreFromTrash(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.restoreFromTrash(id, this.getAuditContext(req));
  }

  @Delete(':id/permanent')
  @ApiOperation({ summary: 'Permanently delete file' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiDeleteResponse()
  async permanentDelete(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.permanentDelete(id, this.getAuditContext(req));
  }

  @Post(':id/download-log')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Log file download' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiStandardErrors()
  async logDownload(@Param('id') id: string, @Req() req: AuthenticatedRequest) {
    await this.filesService.logDownload(id, this.getAuditContext(req));
    return { logged: true };
  }

  // ===================== VERSIONING =====================

  @Post(':id/versions')
  @ApiOperation({ summary: 'Create new file version' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiResponse({ status: 201, description: 'Version created' })
  @ApiCrudErrors()
  async createVersion(
    @Param('id') id: string,
    @Body() dto: CreateVersionDto,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.createVersion(id, dto, this.getAuditContext(req));
  }

  @Get(':id/versions')
  @ApiOperation({ summary: 'List file versions' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiResponse({ status: 200, description: 'List of versions' })
  @ApiCrudErrors()
  async getVersions(@Param('id') id: string) {
    return this.filesService.getVersions(id);
  }

  @Get(':id/versions/:version')
  @ApiOperation({ summary: 'Get specific version' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiParam({ name: 'version', description: 'Version number', type: 'number' })
  @ApiResponse({ status: 200, description: 'Version details' })
  @ApiCrudErrors()
  async getVersion(
    @Param('id') id: string,
    @Param('version', ParseIntPipe) version: number,
  ) {
    return this.filesService.getVersion(id, version);
  }

  @Post(':id/versions/:version/restore')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Restore a previous version' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiParam({ name: 'version', description: 'Version number', type: 'number' })
  @ApiResponse({ status: 200, description: 'Version restored' })
  @ApiCrudErrors()
  async restoreVersion(
    @Param('id') id: string,
    @Param('version', ParseIntPipe) version: number,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.filesService.restoreVersion(
      id,
      version,
      this.getAuditContext(req),
    );
  }

  // ===================== AUDIT LOGS =====================

  @Get(':id/audit-logs')
  @ApiOperation({ summary: 'Get file audit logs' })
  @ApiParam({ name: 'id', description: 'File ID' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiCrudErrors()
  async getAuditLogs(
    @Param('id') id: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
  ) {
    return this.filesService.getAuditLogs(id, page, limit);
  }
}
