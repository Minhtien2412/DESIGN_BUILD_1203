/**
 * Files Module
 * Module registration for file management features
 *
 * @module files/files.module
 * @created 2026-01-23
 */

import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { PrismaModule } from '../prisma/prisma.module';
import { FilesController } from './files.controller';
import { FilesSchedulerService } from './files.scheduler';
import { FilesService } from './files.service';

@Module({
  imports: [PrismaModule, ScheduleModule.forRoot()],
  controllers: [FilesController],
  providers: [FilesService, FilesSchedulerService],
  exports: [FilesService],
})
export class FilesModule {}
