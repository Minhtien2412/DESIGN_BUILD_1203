import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsDateString,
    IsInt,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreateFuelRecordDto {
  @ApiProperty({ example: 1, description: 'ID phương tiện' })
  @IsInt()
  vehicleId: number;

  @ApiProperty({ example: '2025-01-20', description: 'Ngày đổ xăng' })
  @IsDateString()
  date: string;

  @ApiProperty({ example: 50, description: 'Số lít' })
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 21500, description: 'Đơn giá (VND/lít)' })
  @IsNumber()
  unitPrice: number;

  @ApiProperty({ example: 1075000, description: 'Tổng tiền (VND)' })
  @IsNumber()
  totalCost: number;

  @ApiPropertyOptional({
    example: 50500,
    description: 'Số km tại thời điểm đổ xăng',
  })
  @IsOptional()
  @IsNumber()
  mileage?: number;

  @ApiPropertyOptional({
    example: 'Petrolimex Bình Dương',
    description: 'Trạm xăng',
  })
  @IsOptional()
  @IsString()
  fuelStation?: string;

  @ApiPropertyOptional({
    example: 'https://example.com/receipt.jpg',
    description: 'URL hóa đơn',
  })
  @IsOptional()
  @IsString()
  receiptUrl?: string;

  @ApiPropertyOptional({ example: 'Đổ đầy bình', description: 'Ghi chú' })
  @IsOptional()
  @IsString()
  notes?: string;
}
