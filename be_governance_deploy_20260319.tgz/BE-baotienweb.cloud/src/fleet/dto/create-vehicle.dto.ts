import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { VehicleStatus, VehicleType } from '@prisma/client';
import {
    IsDateString,
    IsEnum,
    IsInt,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreateVehicleDto {
  @ApiProperty({
    example: 'Xe tải Hyundai HD72',
    description: 'Tên phương tiện',
  })
  @IsString()
  name: string;

  @ApiProperty({
    enum: [
      'TRUCK',
      'EXCAVATOR',
      'CRANE',
      'CONCRETE_MIXER',
      'BULLDOZER',
      'FORKLIFT',
      'CAR',
      'VAN',
      'OTHER',
    ],
    example: 'TRUCK',
    description: 'Loại phương tiện',
  })
  @IsEnum(VehicleType)
  type: VehicleType;

  @ApiProperty({ example: '51C-12345', description: 'Biển số xe' })
  @IsString()
  licensePlate: string;

  @ApiPropertyOptional({ example: 'KMFGA17BPWC123456', description: 'Số VIN' })
  @IsOptional()
  @IsString()
  vin?: string;

  @ApiPropertyOptional({ example: 'Hyundai', description: 'Hãng xe' })
  @IsOptional()
  @IsString()
  brand?: string;

  @ApiPropertyOptional({ example: 'HD72', description: 'Model xe' })
  @IsOptional()
  @IsString()
  model?: string;

  @ApiPropertyOptional({ example: 2023, description: 'Năm sản xuất' })
  @IsOptional()
  @IsInt()
  year?: number;

  @ApiPropertyOptional({ example: 'Trắng', description: 'Màu sắc' })
  @IsOptional()
  @IsString()
  color?: string;

  @ApiPropertyOptional({
    enum: ['AVAILABLE', 'IN_USE', 'MAINTENANCE', 'RETIRED'],
    example: 'AVAILABLE',
    description: 'Trạng thái',
  })
  @IsOptional()
  @IsEnum(VehicleStatus)
  status?: VehicleStatus;

  @ApiPropertyOptional({ example: 50000, description: 'Số km hiện tại' })
  @IsOptional()
  @IsNumber()
  currentMileage?: number;

  @ApiPropertyOptional({ example: 'Diesel', description: 'Loại nhiên liệu' })
  @IsOptional()
  @IsString()
  fuelType?: string;

  @ApiPropertyOptional({
    example: 200,
    description: 'Dung tích bình xăng (lít)',
  })
  @IsOptional()
  @IsNumber()
  fuelCapacity?: number;

  @ApiPropertyOptional({ example: '2023-01-15', description: 'Ngày mua xe' })
  @IsOptional()
  @IsDateString()
  purchaseDate?: string;

  @ApiPropertyOptional({ example: 500000000, description: 'Giá mua (VND)' })
  @IsOptional()
  @IsNumber()
  purchasePrice?: number;

  @ApiPropertyOptional({
    example: '2025-06-30',
    description: 'Ngày hết hạn bảo hiểm',
  })
  @IsOptional()
  @IsDateString()
  insuranceExpiry?: string;

  @ApiPropertyOptional({
    example: '2025-12-31',
    description: 'Ngày hết hạn đăng kiểm',
  })
  @IsOptional()
  @IsDateString()
  registrationExpiry?: string;

  @ApiPropertyOptional({
    example: 'Xe mới mua, cần bảo dưỡng định kỳ',
    description: 'Ghi chú',
  })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    example: 'https://example.com/vehicle.jpg',
    description: 'URL hình ảnh xe',
  })
  @IsOptional()
  @IsString()
  imageUrl?: string;

  @ApiPropertyOptional({ example: 1, description: 'ID dự án gán xe' })
  @IsOptional()
  @IsInt()
  projectId?: number;
}
