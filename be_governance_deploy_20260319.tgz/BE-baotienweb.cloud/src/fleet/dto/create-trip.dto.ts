import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { TripStatus } from '@prisma/client';
import {
    IsDateString,
    IsEnum,
    IsInt,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreateTripDto {
  @ApiProperty({ example: 1, description: 'ID phương tiện' })
  @IsInt()
  vehicleId: number;

  @ApiPropertyOptional({ example: 1, description: 'ID tài xế' })
  @IsOptional()
  @IsInt()
  driverId?: number;

  @ApiPropertyOptional({ example: 1, description: 'ID dự án' })
  @IsOptional()
  @IsInt()
  projectId?: number;

  @ApiPropertyOptional({
    enum: ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
    example: 'SCHEDULED',
    description: 'Trạng thái chuyến đi',
  })
  @IsOptional()
  @IsEnum(TripStatus)
  status?: TripStatus;

  @ApiProperty({ example: 'Kho Bình Dương', description: 'Điểm đi' })
  @IsString()
  startLocation: string;

  @ApiProperty({ example: 'Công trường Quận 7', description: 'Điểm đến' })
  @IsString()
  endLocation: string;

  @ApiProperty({
    example: '2025-01-20T08:00:00.000Z',
    description: 'Thời gian khởi hành',
  })
  @IsDateString()
  startTime: string;

  @ApiPropertyOptional({
    example: '2025-01-20T10:30:00.000Z',
    description: 'Thời gian kết thúc',
  })
  @IsOptional()
  @IsDateString()
  endTime?: string;

  @ApiPropertyOptional({ example: 45.5, description: 'Quãng đường (km)' })
  @IsOptional()
  @IsNumber()
  distance?: number;

  @ApiPropertyOptional({
    example: 12.5,
    description: 'Nhiên liệu tiêu thụ (lít)',
  })
  @IsOptional()
  @IsNumber()
  fuelUsed?: number;

  @ApiPropertyOptional({ example: 50000, description: 'Số km lúc xuất phát' })
  @IsOptional()
  @IsNumber()
  startMileage?: number;

  @ApiPropertyOptional({ example: 50045, description: 'Số km lúc về' })
  @IsOptional()
  @IsNumber()
  endMileage?: number;

  @ApiPropertyOptional({
    example: 'Vận chuyển vật liệu xây dựng',
    description: 'Mục đích chuyến đi',
  })
  @IsOptional()
  @IsString()
  purpose?: string;

  @ApiPropertyOptional({
    example: 'Giao hàng đúng hẹn',
    description: 'Ghi chú',
  })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    example: 'gpx-track-data',
    description: 'Dữ liệu GPS track',
  })
  @IsOptional()
  @IsString()
  gpxTrack?: string;
}
