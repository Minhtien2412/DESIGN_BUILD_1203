import { InspectionStatus } from '@prisma/client';
import {
    IsArray,
    IsDateString,
    IsEnum,
    IsInt,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
} from 'class-validator';

/**
 * Fleet Vehicle Inspection DTO
 * Renamed to avoid conflict with QC CreateInspectionDto
 */
export class CreateFleetInspectionDto {
  @IsInt()
  vehicleId: number;

  @IsString()
  inspectorName: string;

  @IsDateString()
  inspectionDate: string;

  @IsOptional()
  @IsEnum(InspectionStatus)
  status?: InspectionStatus;

  @IsOptional()
  @IsNumber()
  mileage?: number;

  @IsObject()
  checklistItems: any;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  issues?: string[];

  @IsOptional()
  @IsString()
  recommendations?: string;

  @IsOptional()
  @IsDateString()
  nextInspectionDate?: string;

  @IsOptional()
  @IsString()
  certificateUrl?: string;

  @IsOptional()
  @IsString()
  notes?: string;
}
