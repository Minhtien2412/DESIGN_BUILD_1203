import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { MaintenanceStatus, MaintenanceType } from '@prisma/client';
import {
    IsDateString,
    IsEnum,
    IsInt,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
} from 'class-validator';

export class CreateMaintenanceDto {
  @ApiProperty({ example: 1, description: 'ID phương tiện' })
  @IsInt()
  vehicleId: number;

  @ApiProperty({
    enum: [
      'ROUTINE',
      'REPAIR',
      'INSPECTION',
      'TIRE',
      'OIL_CHANGE',
      'BRAKE',
      'ENGINE',
      'OTHER',
    ],
    example: 'OIL_CHANGE',
    description: 'Loại bảo dưỡng',
  })
  @IsEnum(MaintenanceType)
  type: MaintenanceType;

  @ApiPropertyOptional({
    enum: ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
    example: 'SCHEDULED',
    description: 'Trạng thái',
  })
  @IsOptional()
  @IsEnum(MaintenanceStatus)
  status?: MaintenanceStatus;

  @ApiProperty({
    example: 'Thay dầu máy và lọc dầu',
    description: 'Mô tả công việc',
  })
  @IsString()
  description: string;

  @ApiProperty({ example: '2025-01-25', description: 'Ngày dự kiến' })
  @IsDateString()
  scheduledDate: string;

  @ApiPropertyOptional({
    example: '2025-01-25',
    description: 'Ngày hoàn thành',
  })
  @IsOptional()
  @IsDateString()
  completedDate?: string;

  @ApiProperty({ example: 1500000, description: 'Chi phí (VND)' })
  @IsNumber()
  cost: number;

  @ApiPropertyOptional({
    example: 51000,
    description: 'Số km tại thời điểm bảo dưỡng',
  })
  @IsOptional()
  @IsNumber()
  mileage?: number;

  @ApiPropertyOptional({ example: 'Garage ABC', description: 'Nơi thực hiện' })
  @IsOptional()
  @IsString()
  performedBy?: string;

  @ApiPropertyOptional({
    example: '123 Đường XYZ, Quận 1',
    description: 'Địa điểm',
  })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional({
    example: 'Thay dầu Shell Helix 5W-40',
    description: 'Ghi chú',
  })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    example: { oilFilter: 1, oilLiters: 4 },
    description: 'Phụ tùng thay thế',
  })
  @IsOptional()
  @IsObject()
  parts?: any;

  @ApiPropertyOptional({
    example: 'https://example.com/invoice.pdf',
    description: 'URL hóa đơn',
  })
  @IsOptional()
  @IsString()
  invoiceUrl?: string;
}
