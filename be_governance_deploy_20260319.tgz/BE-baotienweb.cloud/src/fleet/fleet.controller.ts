import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreateDriverDto,
    CreateFleetInspectionDto,
    CreateFuelRecordDto,
    CreateMaintenanceDto,
    CreateTripDto,
    CreateVehicleDto,
} from './dto';
import { FleetService } from './fleet.service';

@ApiTags('Fleet')
@ApiBearerAuth()
@Controller('fleet')
@UseGuards(JwtAuthGuard)
export class FleetController {
  constructor(private readonly fleetService: FleetService) {}

  // ==================== FLEET OVERVIEW ====================
  @Get()
  async getFleetOverview(@Query('projectId') projectId?: string) {
    const pid = projectId ? parseInt(projectId, 10) : undefined;
    const [vehicles, drivers] = await Promise.all([
      this.fleetService.getVehicles(pid),
      this.fleetService.getDrivers(),
    ]);
    return {
      status: 'ok',
      summary: {
        totalVehicles: Array.isArray(vehicles) ? vehicles.length : 0,
        totalDrivers: Array.isArray(drivers) ? drivers.length : 0,
      },
      vehicles: Array.isArray(vehicles) ? vehicles.slice(0, 5) : [],
      drivers: Array.isArray(drivers) ? drivers.slice(0, 5) : [],
    };
  }

  // ==================== VEHICLES ====================
  @Post('vehicles')
  createVehicle(@Body() createVehicleDto: CreateVehicleDto) {
    return this.fleetService.createVehicle(createVehicleDto);
  }

  @Get('vehicles')
  getVehicles(@Query('projectId', ParseIntPipe) projectId?: number) {
    return this.fleetService.getVehicles(projectId);
  }

  @Get('vehicles/:id')
  getVehicle(@Param('id', ParseIntPipe) id: number) {
    return this.fleetService.getVehicle(id);
  }

  @Patch('vehicles/:id')
  updateVehicle(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateData: Partial<CreateVehicleDto>,
  ) {
    return this.fleetService.updateVehicle(id, updateData);
  }

  @Delete('vehicles/:id')
  deleteVehicle(@Param('id', ParseIntPipe) id: number) {
    return this.fleetService.deleteVehicle(id);
  }

  // ==================== MAINTENANCE ====================
  @Post('maintenance')
  createMaintenance(@Body() createMaintenanceDto: CreateMaintenanceDto) {
    return this.fleetService.createMaintenance(createMaintenanceDto);
  }

  @Get('maintenance')
  getMaintenanceRecords(@Query('vehicleId', ParseIntPipe) vehicleId?: number) {
    return this.fleetService.getMaintenanceRecords(vehicleId);
  }

  @Patch('maintenance/:id')
  updateMaintenance(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateData: Partial<CreateMaintenanceDto>,
  ) {
    return this.fleetService.updateMaintenance(id, updateData);
  }

  // ==================== TRIPS ====================
  @Post('trips')
  createTrip(@Body() createTripDto: CreateTripDto) {
    return this.fleetService.createTrip(createTripDto);
  }

  @Get('trips')
  getTrips(
    @Query('vehicleId', ParseIntPipe) vehicleId?: number,
    @Query('projectId', ParseIntPipe) projectId?: number,
  ) {
    return this.fleetService.getTrips(vehicleId, projectId);
  }

  @Patch('trips/:id')
  updateTrip(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateData: Partial<CreateTripDto>,
  ) {
    return this.fleetService.updateTrip(id, updateData);
  }

  // ==================== FUEL RECORDS ====================
  @Post('fuel')
  createFuelRecord(@Body() createFuelRecordDto: CreateFuelRecordDto) {
    return this.fleetService.createFuelRecord(createFuelRecordDto);
  }

  @Get('fuel')
  getFuelRecords(@Query('vehicleId', ParseIntPipe) vehicleId?: number) {
    return this.fleetService.getFuelRecords(vehicleId);
  }

  @Get('fuel/stats/:vehicleId')
  getFuelStats(
    @Param('vehicleId', ParseIntPipe) vehicleId: number,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    const start = startDate ? new Date(startDate) : undefined;
    const end = endDate ? new Date(endDate) : undefined;
    return this.fleetService.getFuelStats(vehicleId, start, end);
  }

  // ==================== DRIVERS ====================
  @Post('drivers')
  createDriver(@Body() createDriverDto: CreateDriverDto) {
    return this.fleetService.createDriver(createDriverDto);
  }

  @Get('drivers')
  getDrivers() {
    return this.fleetService.getDrivers();
  }

  @Get('drivers/:id')
  getDriver(@Param('id', ParseIntPipe) id: number) {
    return this.fleetService.getDriver(id);
  }

  @Patch('drivers/:id')
  updateDriver(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateData: Partial<CreateDriverDto>,
  ) {
    return this.fleetService.updateDriver(id, updateData);
  }

  // ==================== INSPECTIONS ====================
  @Post('inspections')
  createInspection(@Body() createInspectionDto: CreateFleetInspectionDto) {
    return this.fleetService.createInspection(createInspectionDto);
  }

  @Get('inspections')
  getInspections(@Query('vehicleId', ParseIntPipe) vehicleId?: number) {
    return this.fleetService.getInspections(vehicleId);
  }

  @Patch('inspections/:id')
  updateInspection(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateData: Partial<CreateFleetInspectionDto>,
  ) {
    return this.fleetService.updateInspection(id, updateData);
  }
}
