import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateDriverDto,
    CreateFleetInspectionDto,
    CreateFuelRecordDto,
    CreateMaintenanceDto,
    CreateTripDto,
    CreateVehicleDto,
} from './dto';

@Injectable()
export class FleetService {
  constructor(private prisma: PrismaService) {}

  // ==================== VEHICLES ====================
  async createVehicle(createVehicleDto: CreateVehicleDto) {
    return this.prisma.vehicle.create({
      data: createVehicleDto,
    });
  }

  async getVehicles(projectId?: number) {
    return this.prisma.vehicle.findMany({
      where: projectId ? { projectId } : {},
      include: {
        maintenanceRecords: {
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
        trips: {
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
        fuelRecords: {
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getVehicle(id: number) {
    const vehicle = await this.prisma.vehicle.findUnique({
      where: { id },
      include: {
        maintenanceRecords: { orderBy: { createdAt: 'desc' } },
        trips: { orderBy: { createdAt: 'desc' } },
        fuelRecords: { orderBy: { createdAt: 'desc' } },
        inspections: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!vehicle) throw new NotFoundException('Vehicle not found');
    return vehicle;
  }

  async updateVehicle(id: number, updateData: Partial<CreateVehicleDto>) {
    return this.prisma.vehicle.update({
      where: { id },
      data: updateData,
    });
  }

  async deleteVehicle(id: number) {
    return this.prisma.vehicle.delete({
      where: { id },
    });
  }

  // ==================== MAINTENANCE ====================
  async createMaintenance(createMaintenanceDto: CreateMaintenanceDto) {
    return this.prisma.maintenance.create({
      data: createMaintenanceDto,
      include: { vehicle: true },
    });
  }

  async getMaintenanceRecords(vehicleId?: number) {
    return this.prisma.maintenance.findMany({
      where: vehicleId ? { vehicleId } : {},
      include: { vehicle: true },
      orderBy: { scheduledDate: 'desc' },
    });
  }

  async updateMaintenance(
    id: number,
    updateData: Partial<CreateMaintenanceDto>,
  ) {
    return this.prisma.maintenance.update({
      where: { id },
      data: updateData,
      include: { vehicle: true },
    });
  }

  // ==================== TRIPS ====================
  async createTrip(createTripDto: CreateTripDto) {
    return this.prisma.trip.create({
      data: createTripDto,
      include: { vehicle: true, driver: true, project: true },
    });
  }

  async getTrips(vehicleId?: number, projectId?: number) {
    return this.prisma.trip.findMany({
      where: {
        ...(vehicleId && { vehicleId }),
        ...(projectId && { projectId }),
      },
      include: { vehicle: true, driver: true, project: true },
      orderBy: { startTime: 'desc' },
    });
  }

  async updateTrip(id: number, updateData: Partial<CreateTripDto>) {
    return this.prisma.trip.update({
      where: { id },
      data: updateData,
      include: { vehicle: true, driver: true },
    });
  }

  // ==================== FUEL RECORDS ====================
  async createFuelRecord(createFuelRecordDto: CreateFuelRecordDto) {
    return this.prisma.fuelRecord.create({
      data: createFuelRecordDto,
      include: { vehicle: true },
    });
  }

  async getFuelRecords(vehicleId?: number) {
    return this.prisma.fuelRecord.findMany({
      where: vehicleId ? { vehicleId } : {},
      include: { vehicle: true },
      orderBy: { date: 'desc' },
    });
  }

  async getFuelStats(vehicleId: number, startDate?: Date, endDate?: Date) {
    const where: any = { vehicleId };
    if (startDate && endDate) {
      where.date = { gte: startDate, lte: endDate };
    }

    const records = await this.prisma.fuelRecord.findMany({ where });

    const totalQuantity = records.reduce(
      (sum, r) => sum + Number(r.quantity),
      0,
    );
    const totalCost = records.reduce((sum, r) => sum + Number(r.totalCost), 0);
    const avgPrice = totalQuantity > 0 ? totalCost / totalQuantity : 0;

    return {
      totalRecords: records.length,
      totalQuantity,
      totalCost,
      avgPrice,
      records: records.slice(0, 10),
    };
  }

  // ==================== DRIVERS ====================
  async createDriver(createDriverDto: CreateDriverDto) {
    return this.prisma.driver.create({
      data: createDriverDto,
    });
  }

  async getDrivers() {
    return this.prisma.driver.findMany({
      include: {
        trips: {
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getDriver(id: number) {
    const driver = await this.prisma.driver.findUnique({
      where: { id },
      include: { trips: { orderBy: { createdAt: 'desc' } } },
    });
    if (!driver) throw new NotFoundException('Driver not found');
    return driver;
  }

  async updateDriver(id: number, updateData: Partial<CreateDriverDto>) {
    return this.prisma.driver.update({
      where: { id },
      data: updateData,
    });
  }

  // ==================== INSPECTIONS ====================
  async createInspection(createInspectionDto: CreateFleetInspectionDto) {
    return this.prisma.inspection.create({
      data: createInspectionDto,
      include: { vehicle: true },
    });
  }

  async getInspections(vehicleId?: number) {
    return this.prisma.inspection.findMany({
      where: vehicleId ? { vehicleId } : {},
      include: { vehicle: true },
      orderBy: { inspectionDate: 'desc' },
    });
  }

  async updateInspection(
    id: number,
    updateData: Partial<CreateFleetInspectionDto>,
  ) {
    return this.prisma.inspection.update({
      where: { id },
      data: updateData,
      include: { vehicle: true },
    });
  }
}
