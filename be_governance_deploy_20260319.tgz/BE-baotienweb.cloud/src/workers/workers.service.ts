import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    ApproveWorkerDto,
    CreateWorkerReviewDto,
    RegisterWorkerDto,
    WorkerQueryDto,
    WorkerStatsQueryDto,
    WorkerStatus,
    WorkerType,
} from './dto/worker.dto';

export type WorkerAvailability =
  | 'available'
  | 'busy'
  | 'almost-done'
  | 'offline';

export interface LocationStat {
  location: string;
  count: number;
  status: WorkerAvailability;
}

export interface WorkerStat {
  workerType: WorkerType;
  totalCount: number;
  locations: LocationStat[];
}

export interface WorkerStatsResponse {
  stats: WorkerStat[];
  lastUpdated: string;
  totalWorkers: number;
}

// Mock worker data
export interface MockWorker {
  id: string;
  name: string;
  phone: string;
  workerType: WorkerType;
  location: string;
  district?: string;
  experience: number;
  skills: string[];
  hasEquipment: boolean;
  dailyRate: number;
  avatar?: string;
  bio?: string;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  status: WorkerStatus;
  verified: boolean;
  featured: boolean;
  availability: WorkerAvailability;
  createdAt: string;
  updatedAt: string;
}

export interface MockReview {
  id: string;
  workerId: string;
  userId: string;
  userName: string;
  rating: number;
  comment?: string;
  images?: string[];
  createdAt: string;
}

@Injectable()
export class WorkersService {
  private readonly logger = new Logger(WorkersService.name);

  // Mock data storage
  private mockWorkers: MockWorker[] = this.initializeMockWorkers();
  private mockReviews: MockReview[] = this.initializeMockReviews();

  constructor(private readonly prisma: PrismaService) {}

  // ==================== CRUD OPERATIONS ====================

  /**
   * Get all workers with filters
   */
  async findAll(query: WorkerQueryDto) {
    const {
      page = 1,
      limit = 20,
      search,
      specialty,
      workerType,
      location,
      available,
      verified,
      minRating,
      maxPrice,
      status,
      sortBy = 'rating',
      sortOrder = 'desc',
    } = query;

    let filtered = [...this.mockWorkers];

    // Filter by status (only APPROVED for public)
    if (status) {
      filtered = filtered.filter((w) => w.status === status);
    } else {
      filtered = filtered.filter((w) => w.status === WorkerStatus.APPROVED);
    }

    // Search by name/specialty
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(
        (w) =>
          w.name.toLowerCase().includes(searchLower) ||
          w.skills.some((s) => s.toLowerCase().includes(searchLower)) ||
          this.getWorkerTypeLabel(w.workerType)
            .toLowerCase()
            .includes(searchLower),
      );
    }

    // Filter by specialty
    if (specialty) {
      const specLower = specialty.toLowerCase();
      filtered = filtered.filter(
        (w) =>
          w.skills.some((s) => s.toLowerCase().includes(specLower)) ||
          w.workerType.toLowerCase().includes(specLower),
      );
    }

    // Filter by worker type
    if (workerType) {
      filtered = filtered.filter((w) => w.workerType === workerType);
    }

    // Filter by location
    if (location) {
      const locLower = location.toLowerCase();
      filtered = filtered.filter(
        (w) =>
          w.location.toLowerCase().includes(locLower) ||
          (w.district && w.district.toLowerCase().includes(locLower)),
      );
    }

    // Filter by availability
    if (available !== undefined) {
      filtered = filtered.filter((w) =>
        available
          ? w.availability === 'available'
          : w.availability !== 'available',
      );
    }

    // Filter by verified
    if (verified !== undefined) {
      filtered = filtered.filter((w) => w.verified === verified);
    }

    // Filter by min rating
    if (minRating) {
      filtered = filtered.filter((w) => w.rating >= minRating);
    }

    // Filter by max price
    if (maxPrice) {
      filtered = filtered.filter((w) => w.dailyRate <= maxPrice);
    }

    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'rating':
          comparison = a.rating - b.rating;
          break;
        case 'price':
          comparison = a.dailyRate - b.dailyRate;
          break;
        case 'experience':
          comparison = a.experience - b.experience;
          break;
        case 'completedJobs':
          comparison = a.completedJobs - b.completedJobs;
          break;
        default:
          comparison = a.rating - b.rating;
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    // Pagination
    const total = filtered.length;
    const startIndex = (page - 1) * limit;
    const paginatedData = filtered.slice(startIndex, startIndex + limit);

    return {
      data: paginatedData,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Get single worker by ID
   */
  async findOne(id: string) {
    const worker = this.mockWorkers.find((w) => w.id === id);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${id} not found`);
    }
    return worker;
  }

  /**
   * Get worker reviews
   */
  async getReviews(workerId: string) {
    const worker = this.mockWorkers.find((w) => w.id === workerId);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${workerId} not found`);
    }

    const reviews = this.mockReviews.filter((r) => r.workerId === workerId);
    return {
      data: reviews,
      meta: {
        total: reviews.length,
        averageRating: worker.rating,
      },
    };
  }

  /**
   * Add review for worker
   */
  async addReview(
    workerId: string,
    dto: CreateWorkerReviewDto,
    userId: string,
  ) {
    const worker = this.mockWorkers.find((w) => w.id === workerId);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${workerId} not found`);
    }

    const newReview: MockReview = {
      id: `review_${Date.now()}`,
      workerId,
      userId,
      userName: 'Người dùng', // Would fetch from user service
      rating: dto.rating,
      comment: dto.comment,
      images: dto.images,
      createdAt: new Date().toISOString(),
    };

    this.mockReviews.push(newReview);

    // Update worker rating
    const workerReviews = this.mockReviews.filter(
      (r) => r.workerId === workerId,
    );
    const avgRating =
      workerReviews.reduce((sum, r) => sum + r.rating, 0) /
      workerReviews.length;
    worker.rating = Math.round(avgRating * 10) / 10;
    worker.reviewCount = workerReviews.length;

    return newReview;
  }

  /**
   * Contact worker (send inquiry)
   */
  async contactWorker(workerId: string, userId: string, message?: string) {
    const worker = this.mockWorkers.find((w) => w.id === workerId);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${workerId} not found`);
    }

    this.logger.log(
      `User ${userId} contacted worker ${workerId}: ${message || 'No message'}`,
    );

    // In production, would send notification to worker
    return {
      success: true,
      message: 'Yêu cầu liên hệ đã được gửi',
      worker: {
        id: worker.id,
        name: worker.name,
        phone: worker.phone,
      },
    };
  }

  // ==================== ADMIN OPERATIONS ====================

  /**
   * Get pending workers for admin approval
   */
  async getPendingWorkers() {
    const pending = this.mockWorkers.filter(
      (w) => w.status === WorkerStatus.PENDING,
    );
    return {
      data: pending,
      meta: {
        total: pending.length,
      },
    };
  }

  /**
   * Approve/reject worker
   */
  async approveWorker(id: string, dto: ApproveWorkerDto, adminId: string) {
    const worker = this.mockWorkers.find((w) => w.id === id);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${id} not found`);
    }

    if (worker.status !== WorkerStatus.PENDING) {
      throw new BadRequestException('Worker is not in pending status');
    }

    worker.status = dto.status;
    worker.updatedAt = new Date().toISOString();

    this.logger.log(
      `Admin ${adminId} ${dto.status} worker ${id}. Reason: ${dto.reason || 'N/A'}`,
    );

    return {
      success: true,
      worker,
      message:
        dto.status === WorkerStatus.APPROVED
          ? 'Thợ đã được phê duyệt thành công'
          : `Thợ đã bị từ chối. Lý do: ${dto.reason || 'Không đủ điều kiện'}`,
    };
  }

  /**
   * Verify worker (check credentials)
   */
  async verifyWorker(id: string, adminId: string) {
    const worker = this.mockWorkers.find((w) => w.id === id);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${id} not found`);
    }

    worker.verified = true;
    worker.updatedAt = new Date().toISOString();

    this.logger.log(`Admin ${adminId} verified worker ${id}`);

    return {
      success: true,
      worker,
      message: 'Thợ đã được xác minh thành công',
    };
  }

  /**
   * Toggle featured status
   */
  async toggleFeatured(id: string, adminId: string) {
    const worker = this.mockWorkers.find((w) => w.id === id);
    if (!worker) {
      throw new NotFoundException(`Worker with ID ${id} not found`);
    }

    worker.featured = !worker.featured;
    worker.updatedAt = new Date().toISOString();

    this.logger.log(
      `Admin ${adminId} ${worker.featured ? 'featured' : 'unfeatured'} worker ${id}`,
    );

    return {
      success: true,
      featured: worker.featured,
      message: worker.featured
        ? 'Đã đánh dấu nổi bật'
        : 'Đã bỏ đánh dấu nổi bật',
    };
  }

  // ==================== PUBLIC ENDPOINTS ====================

  /**
   * Get all specialties/worker types
   */
  getSpecialties() {
    return Object.entries(WorkerType).map(([key, value]) => ({
      id: key,
      value: value,
      label: this.getWorkerTypeLabel(value as WorkerType),
      icon: this.getWorkerTypeIcon(value as WorkerType),
      count: this.mockWorkers.filter(
        (w) => w.workerType === value && w.status === WorkerStatus.APPROVED,
      ).length,
    }));
  }

  /**
   * Get featured workers
   */
  getFeaturedWorkers() {
    const featured = this.mockWorkers.filter(
      (w) => w.featured && w.status === WorkerStatus.APPROVED,
    );
    return {
      data: featured,
      meta: {
        total: featured.length,
      },
    };
  }

  /**
   * Get worker statistics by type and location
   */
  async getWorkerStats(
    query: WorkerStatsQueryDto,
  ): Promise<WorkerStatsResponse> {
    try {
      // Try to get from database first
      // For now, return mock data since Worker table may not exist yet
      return this.getMockWorkerStats(query);
    } catch (error) {
      this.logger.warn('Database query failed, returning mock data', error);
      return this.getMockWorkerStats(query);
    }
  }

  /**
   * Register a new worker
   */
  async registerWorker(dto: RegisterWorkerDto) {
    this.logger.log(
      `Registering worker: ${dto.name} - ${dto.workerType} at ${dto.location}`,
    );

    const newWorker: MockWorker = {
      id: `worker_${Date.now()}`,
      name: dto.name,
      phone: dto.phone,
      workerType: dto.workerType,
      location: dto.location,
      district: dto.district,
      experience: dto.experience || 0,
      skills: dto.skills || [],
      hasEquipment: dto.hasEquipment || false,
      dailyRate: dto.dailyRate || 500000,
      avatar: dto.avatar,
      bio: dto.bio,
      rating: 0,
      reviewCount: 0,
      completedJobs: 0,
      status: WorkerStatus.PENDING, // Needs admin approval
      verified: false,
      featured: false,
      availability: 'available',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.mockWorkers.push(newWorker);

    return {
      ...newWorker,
      message: 'Đăng ký thành công! Hồ sơ của bạn đang chờ được phê duyệt.',
    };
  }

  /**
   * Get all worker types
   */
  getWorkerTypes() {
    return Object.entries(WorkerType).map(([key, value]) => ({
      id: key,
      value: value,
      label: this.getWorkerTypeLabel(value as WorkerType),
    }));
  }

  /**
   * Get available locations
   */
  getLocations() {
    return [
      { id: 'saigon', name: 'Sài Gòn', region: 'south' },
      { id: 'hanoi', name: 'Hà Nội', region: 'north' },
      { id: 'danang', name: 'Đà Nẵng', region: 'central' },
      { id: 'cantho', name: 'Cần Thơ', region: 'south' },
      { id: 'haiphong', name: 'Hải Phòng', region: 'north' },
      { id: 'nhatrang', name: 'Nha Trang', region: 'central' },
      { id: 'vungtau', name: 'Vũng Tàu', region: 'south' },
      { id: 'bienhoa', name: 'Biên Hòa', region: 'south' },
    ];
  }

  // ==================== HELPER METHODS ====================

  private getWorkerTypeLabel(type: WorkerType): string {
    const labels: Record<WorkerType, string> = {
      [WorkerType.EP_COC]: 'Ép cọc',
      [WorkerType.DAO_DAT]: 'Đào đất',
      [WorkerType.VAT_LIEU]: 'Vật liệu xây dựng',
      [WorkerType.NHAN_CONG]: 'Nhân công',
      [WorkerType.THO_XAY]: 'Thợ xây',
      [WorkerType.THO_COFFA]: 'Thợ coffa',
      [WorkerType.THO_SAT]: 'Thợ sắt',
      [WorkerType.THO_DIEN]: 'Thợ điện',
      [WorkerType.THO_NUOC]: 'Thợ nước',
      [WorkerType.THO_SON]: 'Thợ sơn',
      [WorkerType.THO_GACH]: 'Thợ gạch',
      [WorkerType.THO_THACH_CAO]: 'Thợ thạch cao',
      [WorkerType.THO_MOC]: 'Thợ mộc',
      [WorkerType.THO_HAN]: 'Thợ hàn',
      [WorkerType.THO_CAMERA]: 'Thợ camera',
      [WorkerType.THO_NHOM_KINH]: 'Thợ nhôm kính',
      [WorkerType.KY_SU]: 'Kỹ sư',
      [WorkerType.GIAM_SAT]: 'Giám sát',
    };
    return labels[type] || type;
  }

  private getWorkerTypeIcon(type: WorkerType): string {
    const icons: Record<WorkerType, string> = {
      [WorkerType.EP_COC]: 'hammer',
      [WorkerType.DAO_DAT]: 'shovel',
      [WorkerType.VAT_LIEU]: 'package',
      [WorkerType.NHAN_CONG]: 'users',
      [WorkerType.THO_XAY]: 'building',
      [WorkerType.THO_COFFA]: 'grid',
      [WorkerType.THO_SAT]: 'link',
      [WorkerType.THO_DIEN]: 'zap',
      [WorkerType.THO_NUOC]: 'droplet',
      [WorkerType.THO_SON]: 'brush',
      [WorkerType.THO_GACH]: 'layers',
      [WorkerType.THO_THACH_CAO]: 'square',
      [WorkerType.THO_MOC]: 'tool',
      [WorkerType.THO_HAN]: 'flame',
      [WorkerType.THO_CAMERA]: 'camera',
      [WorkerType.THO_NHOM_KINH]: 'maximize',
      [WorkerType.KY_SU]: 'hard-hat',
      [WorkerType.GIAM_SAT]: 'eye',
    };
    return icons[type] || 'user';
  }

  // ==================== MOCK DATA ====================

  private initializeMockWorkers(): MockWorker[] {
    return [
      {
        id: 'worker_1',
        name: 'Nguyễn Văn An',
        phone: '0901234567',
        workerType: WorkerType.THO_DIEN,
        location: 'Sài Gòn',
        district: 'Quận 1',
        experience: 8,
        skills: [
          'Điện dân dụng',
          'Điện công nghiệp',
          'Điện năng lượng mặt trời',
        ],
        hasEquipment: true,
        dailyRate: 600000,
        avatar: 'https://i.pravatar.cc/150?img=1',
        bio: 'Thợ điện chuyên nghiệp với 8 năm kinh nghiệm',
        rating: 4.8,
        reviewCount: 45,
        completedJobs: 120,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: true,
        availability: 'available',
        createdAt: '2024-01-15T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_2',
        name: 'Trần Văn Bình',
        phone: '0912345678',
        workerType: WorkerType.THO_NUOC,
        location: 'Sài Gòn',
        district: 'Quận 7',
        experience: 5,
        skills: ['Sửa ống nước', 'Lắp bồn cầu', 'Chống thấm'],
        hasEquipment: true,
        dailyRate: 500000,
        avatar: 'https://i.pravatar.cc/150?img=2',
        bio: 'Thợ nước tận tâm, uy tín',
        rating: 4.6,
        reviewCount: 32,
        completedJobs: 85,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: true,
        availability: 'available',
        createdAt: '2024-02-20T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_3',
        name: 'Lê Minh Cường',
        phone: '0923456789',
        workerType: WorkerType.THO_XAY,
        location: 'Hà Nội',
        district: 'Cầu Giấy',
        experience: 12,
        skills: ['Xây tường', 'Đổ bê tông', 'Ốp lát'],
        hasEquipment: true,
        dailyRate: 550000,
        avatar: 'https://i.pravatar.cc/150?img=3',
        bio: 'Thợ xây kinh nghiệm, đội nhóm 5 người',
        rating: 4.9,
        reviewCount: 78,
        completedJobs: 200,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: true,
        availability: 'busy',
        createdAt: '2023-06-10T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_4',
        name: 'Phạm Đức Dũng',
        phone: '0934567890',
        workerType: WorkerType.THO_SON,
        location: 'Đà Nẵng',
        district: 'Hải Châu',
        experience: 6,
        skills: ['Sơn nội thất', 'Sơn ngoại thất', 'Sơn PU'],
        hasEquipment: true,
        dailyRate: 450000,
        avatar: 'https://i.pravatar.cc/150?img=4',
        bio: 'Chuyên sơn nhà đẹp, bền màu',
        rating: 4.5,
        reviewCount: 28,
        completedJobs: 65,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: false,
        availability: 'available',
        createdAt: '2024-03-05T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_5',
        name: 'Hoàng Văn Em',
        phone: '0945678901',
        workerType: WorkerType.KY_SU,
        location: 'Sài Gòn',
        district: 'Bình Thạnh',
        experience: 10,
        skills: ['Thiết kế kiến trúc', 'Giám sát công trình', 'Dự toán'],
        hasEquipment: false,
        dailyRate: 1200000,
        avatar: 'https://i.pravatar.cc/150?img=5',
        bio: 'Kỹ sư xây dựng, tốt nghiệp ĐH Bách Khoa',
        rating: 4.9,
        reviewCount: 25,
        completedJobs: 40,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: true,
        availability: 'available',
        createdAt: '2023-09-15T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_6',
        name: 'Vũ Thành Công',
        phone: '0956789012',
        workerType: WorkerType.THO_MOC,
        location: 'Hà Nội',
        district: 'Đống Đa',
        experience: 15,
        skills: ['Đóng tủ', 'Làm cầu thang', 'Nội thất gỗ'],
        hasEquipment: true,
        dailyRate: 700000,
        avatar: 'https://i.pravatar.cc/150?img=6',
        bio: 'Nghệ nhân mộc truyền thống',
        rating: 4.7,
        reviewCount: 52,
        completedJobs: 150,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: false,
        availability: 'almost-done',
        createdAt: '2023-01-20T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_7',
        name: 'Đỗ Văn Giang',
        phone: '0967890123',
        workerType: WorkerType.THO_NHOM_KINH,
        location: 'Sài Gòn',
        district: 'Tân Bình',
        experience: 7,
        skills: ['Cửa nhôm', 'Vách kính', 'Cửa cuốn'],
        hasEquipment: true,
        dailyRate: 550000,
        avatar: 'https://i.pravatar.cc/150?img=7',
        bio: 'Chuyên thi công nhôm kính cao cấp',
        rating: 4.4,
        reviewCount: 19,
        completedJobs: 55,
        status: WorkerStatus.APPROVED,
        verified: false,
        featured: false,
        availability: 'available',
        createdAt: '2024-04-10T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      {
        id: 'worker_8',
        name: 'Nguyễn Thị Hà',
        phone: '0978901234',
        workerType: WorkerType.GIAM_SAT,
        location: 'Cần Thơ',
        district: 'Ninh Kiều',
        experience: 8,
        skills: ['Giám sát thi công', 'Nghiệm thu', 'Quản lý dự án'],
        hasEquipment: false,
        dailyRate: 800000,
        avatar: 'https://i.pravatar.cc/150?img=8',
        bio: 'Giám sát công trình chuyên nghiệp',
        rating: 4.8,
        reviewCount: 35,
        completedJobs: 60,
        status: WorkerStatus.APPROVED,
        verified: true,
        featured: false,
        availability: 'available',
        createdAt: '2023-11-01T00:00:00Z',
        updatedAt: '2024-12-01T00:00:00Z',
      },
      // Pending workers (for admin approval demo)
      {
        id: 'worker_9',
        name: 'Trần Minh Khoa',
        phone: '0989012345',
        workerType: WorkerType.THO_HAN,
        location: 'Sài Gòn',
        district: 'Quận 9',
        experience: 4,
        skills: ['Hàn inox', 'Hàn sắt', 'Làm cửa sắt'],
        hasEquipment: true,
        dailyRate: 500000,
        avatar: 'https://i.pravatar.cc/150?img=9',
        bio: 'Thợ hàn mới đăng ký',
        rating: 0,
        reviewCount: 0,
        completedJobs: 0,
        status: WorkerStatus.PENDING,
        verified: false,
        featured: false,
        availability: 'available',
        createdAt: '2024-12-10T00:00:00Z',
        updatedAt: '2024-12-10T00:00:00Z',
      },
      {
        id: 'worker_10',
        name: 'Lê Văn Long',
        phone: '0990123456',
        workerType: WorkerType.THO_CAMERA,
        location: 'Hà Nội',
        district: 'Hoàng Mai',
        experience: 3,
        skills: ['Lắp camera', 'Thiết lập hệ thống an ninh'],
        hasEquipment: true,
        dailyRate: 400000,
        avatar: 'https://i.pravatar.cc/150?img=10',
        bio: 'Chuyên lắp đặt camera an ninh',
        rating: 0,
        reviewCount: 0,
        completedJobs: 0,
        status: WorkerStatus.PENDING,
        verified: false,
        featured: false,
        availability: 'available',
        createdAt: '2024-12-11T00:00:00Z',
        updatedAt: '2024-12-11T00:00:00Z',
      },
    ];
  }

  private initializeMockReviews(): MockReview[] {
    return [
      {
        id: 'review_1',
        workerId: 'worker_1',
        userId: 'user_1',
        userName: 'Anh Minh',
        rating: 5,
        comment: 'Thợ điện rất chuyên nghiệp, làm việc cẩn thận và sạch sẽ.',
        createdAt: '2024-11-15T10:30:00Z',
      },
      {
        id: 'review_2',
        workerId: 'worker_1',
        userId: 'user_2',
        userName: 'Chị Lan',
        rating: 5,
        comment: 'Đến đúng giờ, giá cả hợp lý. Rất hài lòng!',
        createdAt: '2024-11-20T14:00:00Z',
      },
      {
        id: 'review_3',
        workerId: 'worker_2',
        userId: 'user_3',
        userName: 'Anh Tuấn',
        rating: 4,
        comment: 'Sửa ống nước nhanh, tay nghề tốt.',
        createdAt: '2024-11-18T09:00:00Z',
      },
      {
        id: 'review_4',
        workerId: 'worker_3',
        userId: 'user_4',
        userName: 'Cô Hương',
        rating: 5,
        comment: 'Đội thợ xây rất đông, làm nhanh và đẹp.',
        createdAt: '2024-10-25T16:00:00Z',
      },
    ];
  }

  private getMockWorkerStats(query: WorkerStatsQueryDto): WorkerStatsResponse {
    const allStats: WorkerStat[] = [
      {
        workerType: WorkerType.EP_COC,
        totalCount: 50,
        locations: [
          { location: 'Sài Gòn', count: 30, status: 'available' },
          { location: 'Hà Nội', count: 20, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.DAO_DAT,
        totalCount: 40,
        locations: [
          { location: 'Sài Gòn', count: 25, status: 'available' },
          { location: 'Đà Nẵng', count: 15, status: 'almost-done' },
        ],
      },
      {
        workerType: WorkerType.VAT_LIEU,
        totalCount: 30,
        locations: [
          { location: 'Hà Nội', count: 18, status: 'almost-done' },
          { location: 'Cần Thơ', count: 12, status: 'busy' },
        ],
      },
      {
        workerType: WorkerType.NHAN_CONG,
        totalCount: 13,
        locations: [
          { location: 'Sài Gòn', count: 5, status: 'busy' },
          { location: 'Hà Nội', count: 8, status: 'busy' },
        ],
      },
      {
        workerType: WorkerType.THO_XAY,
        totalCount: 50,
        locations: [
          { location: 'Hà Nội', count: 28, status: 'available' },
          { location: 'Sài Gòn', count: 22, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.THO_COFFA,
        totalCount: 28,
        locations: [
          { location: 'Sài Gòn', count: 12, status: 'almost-done' },
          { location: 'Đà Nẵng', count: 16, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.THO_SAT,
        totalCount: 35,
        locations: [
          { location: 'Sài Gòn', count: 20, status: 'available' },
          { location: 'Hà Nội', count: 15, status: 'busy' },
        ],
      },
      {
        workerType: WorkerType.THO_DIEN,
        totalCount: 25,
        locations: [
          { location: 'Sài Gòn', count: 15, status: 'available' },
          { location: 'Đà Nẵng', count: 10, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.THO_NUOC,
        totalCount: 20,
        locations: [
          { location: 'Hà Nội', count: 12, status: 'almost-done' },
          { location: 'Cần Thơ', count: 8, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.THO_SON,
        totalCount: 22,
        locations: [
          { location: 'Sài Gòn', count: 14, status: 'available' },
          { location: 'Hà Nội', count: 8, status: 'busy' },
        ],
      },
      {
        workerType: WorkerType.KY_SU,
        totalCount: 18,
        locations: [
          { location: 'Sài Gòn', count: 10, status: 'available' },
          { location: 'Hà Nội', count: 8, status: 'available' },
        ],
      },
      {
        workerType: WorkerType.GIAM_SAT,
        totalCount: 15,
        locations: [
          { location: 'Sài Gòn', count: 8, status: 'available' },
          { location: 'Đà Nẵng', count: 7, status: 'almost-done' },
        ],
      },
    ];

    let filteredStats = allStats;

    // Filter by worker type if provided
    if (query.workerType) {
      filteredStats = allStats.filter((s) => s.workerType === query.workerType);
    }

    // Filter by location if provided
    if (query.location) {
      filteredStats = filteredStats
        .map((stat) => ({
          ...stat,
          locations: stat.locations.filter((l) =>
            l.location.toLowerCase().includes(query.location!.toLowerCase()),
          ),
          totalCount: stat.locations
            .filter((l) =>
              l.location.toLowerCase().includes(query.location!.toLowerCase()),
            )
            .reduce((sum, l) => sum + l.count, 0),
        }))
        .filter((s) => s.locations.length > 0);
    }

    const totalWorkers = filteredStats.reduce(
      (sum, s) => sum + s.totalCount,
      0,
    );

    return {
      stats: filteredStats,
      lastUpdated: new Date().toISOString(),
      totalWorkers,
    };
  }
}
