import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { WorkerType as PrismaWorkerType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import {
    ApproveWorkerDto,
    CreateWorkerReviewDto,
    NearbyWorkerQueryDto,
    RegisterWorkerDto,
    SeedWorkerLocationsDto,
    WorkerQueryDto,
    WorkerStatsQueryDto,
    WorkerStatus,
    WorkerType,
} from './dto/worker.dto';

export type WorkerAvailability =
  | 'available'
  | 'busy'
  | 'almost-done'
  | 'offline';

export interface LocationStat {
  location: string;
  count: number;
  status: WorkerAvailability;
}

export interface WorkerStat {
  workerType: WorkerType;
  totalCount: number;
  locations: LocationStat[];
}

export interface WorkerStatsResponse {
  stats: WorkerStat[];
  lastUpdated: string;
  totalWorkers: number;
}

// ==================== ENUM MAPPINGS ====================
// Map from DTO WorkerType to Prisma DB enum
const dtoToPrismaWorkerType: Partial<Record<WorkerType, PrismaWorkerType>> = {
  [WorkerType.THO_XAY]: 'tho_xay' as PrismaWorkerType,
  [WorkerType.THO_SON]: 'tho_son' as PrismaWorkerType,
  [WorkerType.THO_DIEN]: 'tho_dien' as PrismaWorkerType,
  [WorkerType.THO_NUOC]: 'tho_nuoc' as PrismaWorkerType,
  [WorkerType.THO_MOC]: 'tho_moc' as PrismaWorkerType,
  [WorkerType.THO_SAT]: 'tho_sat' as PrismaWorkerType,
  [WorkerType.THO_NHOM_KINH]: 'tho_nhom' as PrismaWorkerType,
  [WorkerType.THO_GACH]: 'tho_op_lat' as PrismaWorkerType,
  [WorkerType.THO_THACH_CAO]: 'tho_tran_thach_cao' as PrismaWorkerType,
  [WorkerType.KY_SU]: 'ky_su' as PrismaWorkerType,
  [WorkerType.GIAM_SAT]: 'giam_sat' as PrismaWorkerType,
  [WorkerType.THO_HAN]: 'tho_sat' as PrismaWorkerType, // mapped to tho_sat
  [WorkerType.THO_CAMERA]: 'tho_dien' as PrismaWorkerType, // mapped to tho_dien
  [WorkerType.THO_COFFA]: 'tho_xay' as PrismaWorkerType, // mapped to tho_xay
};

const prismaToDto: Record<string, WorkerType> = {
  tho_xay: WorkerType.THO_XAY,
  tho_son: WorkerType.THO_SON,
  tho_dien: WorkerType.THO_DIEN,
  tho_nuoc: WorkerType.THO_NUOC,
  tho_moc: WorkerType.THO_MOC,
  tho_sat: WorkerType.THO_SAT,
  tho_alu: WorkerType.THO_NHOM_KINH,
  tho_nhom: WorkerType.THO_NHOM_KINH,
  tho_op_lat: WorkerType.THO_GACH,
  tho_tran_thach_cao: WorkerType.THO_THACH_CAO,
  ky_su: WorkerType.KY_SU,
  giam_sat: WorkerType.GIAM_SAT,
  kien_truc_su: WorkerType.KY_SU,
  lai_xe: WorkerType.NHAN_CONG,
  bao_ve: WorkerType.NHAN_CONG,
  don_dep: WorkerType.NHAN_CONG,
  tho_may_lanh: WorkerType.THO_DIEN,
  tho_da: WorkerType.THO_XAY,
};

const dtoToPrismaStatus: Record<WorkerStatus, string> = {
  [WorkerStatus.PENDING]: 'active',
  [WorkerStatus.APPROVED]: 'active',
  [WorkerStatus.REJECTED]: 'inactive',
  [WorkerStatus.SUSPENDED]: 'suspended',
};

// Category → worker_type mappings (valid DB enum values only)
const CATEGORY_WORKER_MAP: Record<string, string[]> = {
  construction: ['tho_xay', 'tho_sat'],
  finishing: [
    'tho_son',
    'tho_op_lat',
    'tho_tran_thach_cao',
    'tho_moc',
    'tho_da',
  ],
  design: ['kien_truc_su', 'ky_su'],
  electrical: ['tho_dien', 'tho_may_lanh'],
  plumbing: ['tho_nuoc'],
  aluminum: ['tho_nhom', 'tho_alu'],
};

@Injectable()
export class WorkersService {
  private readonly logger = new Logger(WorkersService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ==================== CRUD OPERATIONS ====================

  /**
   * Get all workers with filters - from DB
   */
  async findAll(query: WorkerQueryDto) {
    const {
      page = 1,
      limit = 20,
      search,
      specialty,
      workerType,
      category,
      location,
      available,
      verified,
      minRating,
      maxPrice,
      status,
      sortBy = 'rating',
      sortOrder = 'desc',
    } = query;

    try {
      const where: any = {};

      // Filter by status
      if (status) {
        const dbStatus = dtoToPrismaStatus[status];
        if (dbStatus) where.status = dbStatus;
      } else {
        where.status = 'active';
      }

      // Search by name
      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
          { specialties: { hasSome: [search] } },
        ];
      }

      // Filter by category (maps to multiple worker types)
      if (category && !workerType) {
        const types = CATEGORY_WORKER_MAP[category];
        if (types && types.length > 0) {
          where.workerType = { in: types };
        }
      }

      // Filter by worker type
      if (workerType) {
        const prismaType = dtoToPrismaWorkerType[workerType];
        if (prismaType) where.workerType = prismaType;
      }

      // Filter by specialty (search in specialties array)
      if (specialty) {
        where.specialties = { hasSome: [specialty] };
      }

      // Filter by location
      if (location) {
        where.OR = [
          ...(where.OR || []),
          { location: { contains: location, mode: 'insensitive' } },
          { city: { contains: location, mode: 'insensitive' } },
          { district: { contains: location, mode: 'insensitive' } },
        ];
      }

      // Filter by availability
      if (available !== undefined) {
        where.availability = available ? 'available' : { not: 'available' };
      }

      // Filter by verified
      if (verified !== undefined) {
        where.isVerified = verified;
      }

      // Filter by min rating
      if (minRating) {
        where.rating = { gte: minRating };
      }

      // Filter by max price
      if (maxPrice) {
        where.dailyRate = { lte: maxPrice };
      }

      // Sort mapping
      const orderBy: any = {};
      switch (sortBy) {
        case 'rating':
          orderBy.rating = sortOrder;
          break;
        case 'price':
          orderBy.dailyRate = sortOrder;
          break;
        case 'experience':
          orderBy.experienceYears = sortOrder;
          break;
        case 'completedJobs':
          orderBy.completedJobs = sortOrder;
          break;
        default:
          orderBy.rating = 'desc';
      }

      const [data, total] = await Promise.all([
        this.prisma.worker.findMany({
          where,
          orderBy,
          skip: (page - 1) * limit,
          take: limit,
        }),
        this.prisma.worker.count({ where }),
      ]);

      // Map to API response format
      const mappedData = data.map((w) => this.mapWorkerToResponse(w));

      return {
        data: mappedData,
        meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
      };
    } catch (error) {
      this.logger.warn('DB query failed, returning empty', error);
      return { data: [], meta: { total: 0, page, limit, totalPages: 0 } };
    }
  }

  /**
   * Get single worker by ID
   */
  async findOne(id: string) {
    try {
      const workerId = parseInt(id, 10);
      if (isNaN(workerId))
        throw new NotFoundException(`Worker with ID ${id} not found`);

      const worker = await this.prisma.worker.findUnique({
        where: { id: workerId },
      });

      if (!worker)
        throw new NotFoundException(`Worker with ID ${id} not found`);
      return this.mapWorkerToResponse(worker);
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      throw new NotFoundException(`Worker with ID ${id} not found`);
    }
  }

  /**
   * Get worker reviews
   */
  async getReviews(workerId: string) {
    try {
      const wid = parseInt(workerId, 10);
      if (isNaN(wid))
        throw new NotFoundException(`Worker with ID ${workerId} not found`);

      const worker = await this.prisma.worker.findUnique({
        where: { id: wid },
      });
      if (!worker)
        throw new NotFoundException(`Worker with ID ${workerId} not found`);

      const reviews = await this.prisma.workerReview.findMany({
        where: { workerId: wid },
        orderBy: { createdAt: 'desc' },
      });

      return {
        data: reviews.map((r) => ({
          id: String(r.id),
          workerId: String(r.workerId),
          userId: r.reviewerId ? String(r.reviewerId) : null,
          userName: 'Người dùng',
          rating: r.rating,
          comment: r.comment,
          createdAt: r.createdAt.toISOString(),
        })),
        meta: {
          total: reviews.length,
          averageRating: Number(worker.rating),
        },
      };
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      return { data: [], meta: { total: 0, averageRating: 0 } };
    }
  }

  /**
   * Add review for worker
   */
  async addReview(
    workerId: string,
    dto: CreateWorkerReviewDto,
    userId: string,
  ) {
    const wid = parseInt(workerId, 10);
    if (isNaN(wid))
      throw new NotFoundException(`Worker with ID ${workerId} not found`);

    const worker = await this.prisma.worker.findUnique({ where: { id: wid } });
    if (!worker)
      throw new NotFoundException(`Worker with ID ${workerId} not found`);

    const review = await this.prisma.workerReview.create({
      data: {
        workerId: wid,
        reviewerId: userId ? parseInt(userId, 10) : 0,
        rating: dto.rating,
        comment: dto.comment || null,
      },
    });

    // Update worker rating
    const allReviews = await this.prisma.workerReview.findMany({
      where: { workerId: wid },
    });
    const avgRating =
      allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;

    await this.prisma.worker.update({
      where: { id: wid },
      data: {
        rating: Math.round(avgRating * 10) / 10,
        totalReviews: allReviews.length,
      },
    });

    return {
      id: String(review.id),
      workerId: String(review.workerId),
      userId,
      rating: review.rating,
      comment: review.comment,
      createdAt: review.createdAt.toISOString(),
    };
  }

  /**
   * Contact worker
   */
  async contactWorker(workerId: string, userId: string, message?: string) {
    const wid = parseInt(workerId, 10);
    if (isNaN(wid))
      throw new NotFoundException(`Worker with ID ${workerId} not found`);

    const worker = await this.prisma.worker.findUnique({ where: { id: wid } });
    if (!worker)
      throw new NotFoundException(`Worker with ID ${workerId} not found`);

    this.logger.log(
      `User ${userId} contacted worker ${workerId}: ${message || 'No message'}`,
    );

    return {
      success: true,
      message: 'Yêu cầu liên hệ đã được gửi',
      worker: { id: String(worker.id), name: worker.name, phone: worker.phone },
    };
  }

  // ==================== ADMIN OPERATIONS ====================

  async getPendingWorkers() {
    try {
      const pending = await this.prisma.worker.findMany({
        where: { status: 'active' as any, isVerified: false },
      });

      return {
        data: pending.map((w) => this.mapWorkerToResponse(w)),
        meta: { total: pending.length },
      };
    } catch {
      return { data: [], meta: { total: 0 } };
    }
  }

  async approveWorker(id: string, dto: ApproveWorkerDto, adminId: string) {
    const wid = parseInt(id, 10);
    if (isNaN(wid))
      throw new NotFoundException(`Worker with ID ${id} not found`);

    const worker = await this.prisma.worker.findUnique({ where: { id: wid } });
    if (!worker) throw new NotFoundException(`Worker with ID ${id} not found`);

    const newStatus =
      dto.status === WorkerStatus.APPROVED ? 'active' : 'inactive';
    const updated = await this.prisma.worker.update({
      where: { id: wid },
      data: {
        status: newStatus as any,
        isVerified: dto.status === WorkerStatus.APPROVED,
      },
    });

    this.logger.log(`Admin ${adminId} ${dto.status} worker ${id}`);

    return {
      success: true,
      worker: this.mapWorkerToResponse(updated),
      message:
        dto.status === WorkerStatus.APPROVED
          ? 'Thợ đã được phê duyệt thành công'
          : `Thợ đã bị từ chối. Lý do: ${dto.reason || 'Không đủ điều kiện'}`,
    };
  }

  async verifyWorker(id: string, adminId: string) {
    const wid = parseInt(id, 10);
    if (isNaN(wid))
      throw new NotFoundException(`Worker with ID ${id} not found`);

    const updated = await this.prisma.worker.update({
      where: { id: wid },
      data: { isVerified: true },
    });

    this.logger.log(`Admin ${adminId} verified worker ${id}`);

    return {
      success: true,
      worker: this.mapWorkerToResponse(updated),
      message: 'Thợ đã được xác minh thành công',
    };
  }

  async toggleFeatured(id: string, adminId: string) {
    const wid = parseInt(id, 10);
    if (isNaN(wid))
      throw new NotFoundException(`Worker with ID ${id} not found`);

    const worker = await this.prisma.worker.findUnique({ where: { id: wid } });
    if (!worker) throw new NotFoundException(`Worker with ID ${id} not found`);

    // No featured column in DB, just log it
    this.logger.log(`Admin ${adminId} toggled featured for worker ${id}`);

    return { success: true, featured: true, message: 'Đã đánh dấu nổi bật' };
  }

  // ==================== PUBLIC ENDPOINTS ====================

  getSpecialties() {
    return Object.entries(WorkerType).map(([key, value]) => ({
      id: key,
      value: value,
      label: this.getWorkerTypeLabel(value as WorkerType),
      icon: this.getWorkerTypeIcon(value as WorkerType),
      count: 0,
    }));
  }

  async getFeaturedWorkers() {
    try {
      const featured = await this.prisma.worker.findMany({
        where: {
          status: 'active' as any,
          isVerified: true,
          rating: { gte: 4.5 },
        },
        orderBy: { rating: 'desc' },
        take: 10,
      });

      return {
        data: featured.map((w) => this.mapWorkerToResponse(w)),
        meta: { total: featured.length },
      };
    } catch {
      return { data: [], meta: { total: 0 } };
    }
  }

  /**
   * Get worker statistics by type and location - from DB
   */
  async getWorkerStats(
    query: WorkerStatsQueryDto,
  ): Promise<WorkerStatsResponse> {
    try {
      const workers = await this.prisma.worker.findMany({
        where: { status: 'active' as any },
        select: { workerType: true, city: true, availability: true },
      });

      // Group by worker type
      const typeMap = new Map<
        string,
        { locations: Map<string, { count: number; availability: string }> }
      >();

      for (const w of workers) {
        const dtoType =
          prismaToDto[w.workerType as string] || WorkerType.NHAN_CONG;
        const typeKey = dtoType as string;
        const cityName = w.city || 'Khác';

        if (!typeMap.has(typeKey)) {
          typeMap.set(typeKey, { locations: new Map() });
        }

        const typeData = typeMap.get(typeKey)!;
        if (!typeData.locations.has(cityName)) {
          typeData.locations.set(cityName, {
            count: 0,
            availability: 'available',
          });
        }

        const locData = typeData.locations.get(cityName)!;
        locData.count++;
        // Use worst availability as group status
        if (w.availability === 'offline') locData.availability = 'offline';
        else if (
          w.availability === 'busy' &&
          locData.availability !== 'offline'
        )
          locData.availability = 'busy';
      }

      // Filter by query params
      let stats: WorkerStat[] = Array.from(typeMap.entries()).map(
        ([type, data]) => ({
          workerType: type as WorkerType,
          totalCount: Array.from(data.locations.values()).reduce(
            (s, l) => s + l.count,
            0,
          ),
          locations: Array.from(data.locations.entries()).map(([loc, d]) => ({
            location: loc,
            count: d.count,
            status: (d.availability === 'available'
              ? 'available'
              : d.availability === 'busy'
                ? 'busy'
                : 'almost-done') as WorkerAvailability,
          })),
        }),
      );

      if (query.workerType) {
        stats = stats.filter((s) => s.workerType === query.workerType);
      }
      if (query.location) {
        stats = stats
          .map((s) => ({
            ...s,
            locations: s.locations.filter((l) =>
              l.location.toLowerCase().includes(query.location!.toLowerCase()),
            ),
          }))
          .filter((s) => s.locations.length > 0);
      }

      const totalWorkers = stats.reduce((sum, s) => sum + s.totalCount, 0);

      return { stats, lastUpdated: new Date().toISOString(), totalWorkers };
    } catch (error) {
      this.logger.warn('DB stats query failed, returning empty', error);
      return {
        stats: [],
        lastUpdated: new Date().toISOString(),
        totalWorkers: 0,
      };
    }
  }

  /**
   * Register a new worker
   */
  async registerWorker(dto: RegisterWorkerDto) {
    this.logger.log(
      `Registering worker: ${dto.name} - ${dto.workerType} at ${dto.location}`,
    );

    try {
      const prismaType =
        dtoToPrismaWorkerType[dto.workerType] ||
        ('tho_xay' as PrismaWorkerType);

      const worker = await this.prisma.worker.create({
        data: {
          name: dto.name,
          phone: dto.phone,
          workerType: prismaType,
          location: dto.location,
          district: dto.district,
          experienceYears: dto.experience || 0,
          dailyRate: dto.dailyRate || 500000,
          avatar: dto.avatar,
          description: dto.bio,
          specialties: dto.skills || [],
          status: 'active' as any,
          availability: 'available' as any,
          isVerified: false,
        },
      });

      return {
        id: String(worker.id),
        name: worker.name,
        phone: worker.phone,
        workerType: dto.workerType,
        location: worker.location,
        status: WorkerStatus.PENDING,
        message: 'Đăng ký thành công! Hồ sơ của bạn đang chờ được phê duyệt.',
      };
    } catch (error) {
      this.logger.error('Failed to register worker', error);
      throw new BadRequestException('Không thể đăng ký thợ. Vui lòng thử lại.');
    }
  }

  getWorkerTypes() {
    return Object.entries(WorkerType).map(([key, value]) => ({
      id: key,
      value: value,
      label: this.getWorkerTypeLabel(value as WorkerType),
    }));
  }

  getLocations() {
    return [
      { id: 'saigon', name: 'Sài Gòn', region: 'south' },
      { id: 'hanoi', name: 'Hà Nội', region: 'north' },
      { id: 'danang', name: 'Đà Nẵng', region: 'central' },
      { id: 'cantho', name: 'Cần Thơ', region: 'south' },
      { id: 'haiphong', name: 'Hải Phòng', region: 'north' },
      { id: 'nhatrang', name: 'Nha Trang', region: 'central' },
      { id: 'vungtau', name: 'Vũng Tàu', region: 'south' },
      { id: 'bienhoa', name: 'Biên Hòa', region: 'south' },
      { id: 'hcm', name: 'TP.HCM', region: 'south' },
    ];
  }

  // ==================== HELPER METHODS ====================

  private mapWorkerToResponse(worker: any) {
    return {
      id: String(worker.id),
      name: worker.name,
      phone: worker.phone || '',
      workerType:
        prismaToDto[worker.workerType as string] || WorkerType.NHAN_CONG,
      location: worker.location || worker.city || '',
      district: worker.district || '',
      experience: worker.experienceYears || 0,
      skills: worker.specialties || [],
      hasEquipment: false,
      dailyRate: Number(worker.dailyRate) || 0,
      hourlyRate: Number(worker.hourlyRate) || 0,
      avatar: worker.avatar || `https://i.pravatar.cc/150?img=${worker.id}`,
      bio: worker.description || '',
      rating: Number(worker.rating) || 0,
      reviewCount: worker.totalReviews || 0,
      completedJobs: worker.completedJobs || 0,
      status: worker.isVerified ? WorkerStatus.APPROVED : WorkerStatus.PENDING,
      verified: worker.isVerified || false,
      featured: worker.isFeatured || Number(worker.rating) >= 4.5,
      availability: (worker.availability || 'available') as WorkerAvailability,
      createdAt: worker.createdAt?.toISOString?.() || new Date().toISOString(),
      updatedAt: worker.updatedAt?.toISOString?.() || new Date().toISOString(),
    };
  }

  private getWorkerTypeLabel(type: WorkerType): string {
    const labels: Record<WorkerType, string> = {
      [WorkerType.EP_COC]: 'Ép cọc',
      [WorkerType.DAO_DAT]: 'Đào đất',
      [WorkerType.VAT_LIEU]: 'Vật liệu xây dựng',
      [WorkerType.NHAN_CONG]: 'Nhân công',
      [WorkerType.THO_XAY]: 'Thợ xây',
      [WorkerType.THO_COFFA]: 'Thợ coffa',
      [WorkerType.THO_SAT]: 'Thợ sắt',
      [WorkerType.THO_DIEN]: 'Thợ điện',
      [WorkerType.THO_NUOC]: 'Thợ nước',
      [WorkerType.THO_SON]: 'Thợ sơn',
      [WorkerType.THO_GACH]: 'Thợ gạch',
      [WorkerType.THO_THACH_CAO]: 'Thợ thạch cao',
      [WorkerType.THO_MOC]: 'Thợ mộc',
      [WorkerType.THO_HAN]: 'Thợ hàn',
      [WorkerType.THO_CAMERA]: 'Thợ camera',
      [WorkerType.THO_NHOM_KINH]: 'Thợ nhôm kính',
      [WorkerType.KY_SU]: 'Kỹ sư',
      [WorkerType.GIAM_SAT]: 'Giám sát',
    };
    return labels[type] || type;
  }

  private getWorkerTypeIcon(type: WorkerType): string {
    const icons: Record<WorkerType, string> = {
      [WorkerType.EP_COC]: 'hammer',
      [WorkerType.DAO_DAT]: 'shovel',
      [WorkerType.VAT_LIEU]: 'package',
      [WorkerType.NHAN_CONG]: 'users',
      [WorkerType.THO_XAY]: 'building',
      [WorkerType.THO_COFFA]: 'grid',
      [WorkerType.THO_SAT]: 'link',
      [WorkerType.THO_DIEN]: 'zap',
      [WorkerType.THO_NUOC]: 'droplet',
      [WorkerType.THO_SON]: 'brush',
      [WorkerType.THO_GACH]: 'layers',
      [WorkerType.THO_THACH_CAO]: 'square',
      [WorkerType.THO_MOC]: 'tool',
      [WorkerType.THO_HAN]: 'flame',
      [WorkerType.THO_CAMERA]: 'camera',
      [WorkerType.THO_NHOM_KINH]: 'maximize',
      [WorkerType.KY_SU]: 'hard-hat',
      [WorkerType.GIAM_SAT]: 'eye',
    };
    return icons[type] || 'user';
  }

  // ==================== PRICE RANGE & WORK PROCESS ====================

  /**
   * Get price range (min/max dailyRate) grouped by workerType
   * Aggregates real worker-submitted prices from DB
   */
  async getPriceRanges(workerType?: WorkerType) {
    try {
      const where: any = { status: 'active', dailyRate: { not: null, gt: 0 } };

      if (workerType) {
        const prismaType = dtoToPrismaWorkerType[workerType];
        if (prismaType) where.workerType = prismaType;
      }

      // Use raw SQL for accurate MIN/MAX aggregation by workerType
      const rawQuery = workerType
        ? `
          SELECT
            "workerType",
            MIN("dailyRate") as min_price,
            MAX("dailyRate") as max_price,
            ROUND(AVG("dailyRate")) as avg_price,
            COUNT(*)::int as worker_count
          FROM workers
          WHERE status = 'active' AND "dailyRate" > 0
            AND "workerType" = $1::"WorkerType"
          GROUP BY "workerType"
          ORDER BY "workerType"
        `
        : `
          SELECT
            "workerType",
            MIN("dailyRate") as min_price,
            MAX("dailyRate") as max_price,
            ROUND(AVG("dailyRate")) as avg_price,
            COUNT(*)::int as worker_count
          FROM workers
          WHERE status = 'active' AND "dailyRate" > 0
          GROUP BY "workerType"
          ORDER BY "workerType"
        `;

      const params = workerType ? [dtoToPrismaWorkerType[workerType]] : [];

      const results = (await this.prisma.$queryRawUnsafe(
        rawQuery,
        ...params,
      )) as any[];

      const priceRanges = results.map((r: any) => {
        const dtoType = prismaToDto[r.workerType] || WorkerType.NHAN_CONG;
        return {
          workerType: dtoType,
          workerTypeLabel: this.getWorkerTypeLabel(dtoType),
          icon: this.getWorkerTypeIcon(dtoType),
          minPrice: Number(r.min_price),
          maxPrice: Number(r.max_price),
          avgPrice: Number(r.avg_price),
          workerCount: Number(r.worker_count),
          priceRangeText: `${this.formatPrice(Number(r.min_price))} - ${this.formatPrice(Number(r.max_price))}`,
        };
      });

      return {
        success: true,
        data: priceRanges,
        total: priceRanges.length,
        note: 'Khoảng giá được tính từ giá thấp nhất và cao nhất mà thợ báo giá',
      };
    } catch (error) {
      this.logger.error('Error getting price ranges:', error);
      throw new BadRequestException(
        'Không thể lấy khoảng giá: ' + error.message,
      );
    }
  }

  /**
   * Format price in VND
   */
  private formatPrice(price: number): string {
    if (price >= 1000000) {
      return `${(price / 1000000).toFixed(1)}tr`;
    }
    return `${(price / 1000).toFixed(0)}k`;
  }

  /**
   * Get work process guide — Quy trình làm việc kiểu Vua Thợ
   */
  getWorkProcess() {
    return {
      success: true,
      data: {
        title: 'Quy trình đặt thợ',
        subtitle: 'Đơn giản - Nhanh chóng - Uy tín',
        steps: [
          {
            step: 1,
            title: 'Chọn dịch vụ',
            description:
              'Chọn loại thợ bạn cần từ danh mục dịch vụ. Mỗi loại thợ có khoảng giá tham khảo từ giá thấp nhất đến cao nhất trên hệ thống.',
            icon: 'search',
            color: '#3B82F6',
            tips: [
              'Mô tả chi tiết công việc để thợ hiểu rõ yêu cầu',
              'Chụp ảnh hiện trạng để thợ đánh giá chính xác',
              'Chọn đúng loại thợ chuyên môn để được phục vụ tốt nhất',
            ],
          },
          {
            step: 2,
            title: 'Xem khoảng giá',
            description:
              'Hệ thống hiển thị khoảng giá từ thấp nhất đến cao nhất dựa trên báo giá thực tế của thợ. Giá thấp nhất là giá thợ rẻ nhất, giá cao nhất là giá thợ đắt nhất.',
            icon: 'pricetags',
            color: '#F59E0B',
            tips: [
              'Giá thấp thường là thợ ít kinh nghiệm hoặc mới',
              'Giá cao thường đi kèm thợ nhiều kinh nghiệm, có chứng chỉ',
              'Giá trung bình là lựa chọn cân bằng chất lượng - chi phí',
            ],
          },
          {
            step: 3,
            title: 'Tìm thợ gần bạn',
            description:
              'Hệ thống tìm thợ trong bán kính quanh vị trí của bạn. Xem khoảng cách, đánh giá, kinh nghiệm và giá của từng thợ trên bản đồ.',
            icon: 'map',
            color: '#0D9488',
            tips: [
              'Thợ gần bạn sẽ đến nhanh hơn',
              'Xem đánh giá từ khách hàng trước',
              'So sánh giá giữa các thợ trong khu vực',
            ],
          },
          {
            step: 4,
            title: 'Chọn thợ & đặt lịch',
            description:
              'Chọn thợ phù hợp nhất dựa trên giá, đánh giá và khoảng cách. Đặt lịch hẹn theo thời gian thuận tiện cho bạn.',
            icon: 'calendar',
            color: '#8B5CF6',
            tips: [
              'Đặt lịch trước 1-2 ngày để thợ sắp xếp',
              'Chọn khung giờ sáng sớm để thợ hoàn thành trong ngày',
              'Ghi chú rõ ràng công việc cần làm',
            ],
          },
          {
            step: 5,
            title: 'Theo dõi & đánh giá',
            description:
              'Theo dõi thợ di chuyển đến vị trí của bạn trên bản đồ. Sau khi hoàn thành, đánh giá chất lượng để giúp cộng đồng.',
            icon: 'checkmark-circle',
            color: '#10B981',
            tips: [
              'Kiểm tra kỹ trước khi xác nhận hoàn thành',
              'Đánh giá trung thực giúp thợ cải thiện',
              'Bảo hành theo cam kết nếu có vấn đề',
            ],
          },
        ],
        priceGuide: {
          title: 'Cách tính khoảng giá',
          description:
            'Khoảng giá được tính từ giá báo thấp nhất và cao nhất của các thợ trong hệ thống. Giá thực tế phụ thuộc vào khối lượng công việc, vật liệu, và thỏa thuận giữa bạn và thợ.',
          factors: [
            {
              factor: 'Kinh nghiệm thợ',
              description:
                'Thợ lâu năm thường giá cao hơn nhưng chất lượng đảm bảo',
            },
            {
              factor: 'Khối lượng công việc',
              description: 'Công trình lớn thường được giảm giá theo ngày',
            },
            {
              factor: 'Vật liệu',
              description: 'Một số thợ bao vật liệu, một số chỉ tính tiền công',
            },
            {
              factor: 'Khu vực',
              description: 'Giá có thể chênh lệch theo quận/huyện',
            },
            {
              factor: 'Thời điểm',
              description: 'Cuối tuần, lễ tết có thể phí thêm 10-20%',
            },
          ],
        },
        guarantees: [
          {
            title: 'Thợ xác minh',
            description: 'Tất cả thợ đều được xác minh CCCD và kinh nghiệm',
            icon: 'shield-checkmark',
          },
          {
            title: 'Giá minh bạch',
            description: 'Khoảng giá hiển thị rõ, không phí ẩn',
            icon: 'pricetags',
          },
          {
            title: 'Bảo hành',
            description: 'Cam kết bảo hành theo thỏa thuận',
            icon: 'ribbon',
          },
          {
            title: 'Hỗ trợ 24/7',
            description: 'Đội ngũ hỗ trợ sẵn sàng giải quyết khiếu nại',
            icon: 'headset',
          },
        ],
      },
    };
  }

  // ==================== GEO/NEARBY OPERATIONS ====================

  /**
   * Find nearby workers using Haversine formula (Grab-style)
   */
  async findNearby(query: NearbyWorkerQueryDto) {
    const {
      lat,
      lng,
      radius = 10,
      workerType,
      available = true,
      minRating,
      limit = 20,
    } = query;

    try {
      // Build WHERE conditions for raw SQL
      const conditions: string[] = [
        'w.latitude IS NOT NULL',
        'w.longitude IS NOT NULL',
      ];
      const params: any[] = [lat, lng, lat, radius];
      let paramIndex = 5;

      if (available) {
        conditions.push(`w.availability = 'available'`);
        conditions.push(`w.status = 'active'`);
      }

      if (workerType) {
        const prismaType = dtoToPrismaWorkerType[workerType];
        if (prismaType) {
          conditions.push(`w."workerType" = $${paramIndex}::"WorkerType"`);
          params.push(prismaType);
          paramIndex++;
        }
      }

      if (minRating) {
        conditions.push(`w.rating >= $${paramIndex}`);
        params.push(minRating);
        paramIndex++;
      }

      const whereClause =
        conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      // Haversine formula in SQL (using subquery to filter by distance)
      const rawQuery = `
        SELECT * FROM (
          SELECT
            w.id,
            w.name,
            w.phone,
            w.avatar,
            w."workerType",
            w.skills,
            w.experience,
            w.rating,
            w."reviewCount",
            w.location,
            w.district,
            w.province,
            w.latitude,
            w.longitude,
            w.availability,
            w."isVerified",
            w."completedJobs",
            w."hourlyRate",
            w."dailyRate",
            w.bio,
            w.certifications,
            w."portfolioImages",
            (
              6371 * acos(
                LEAST(1.0, GREATEST(-1.0,
                  cos(radians($1)) * cos(radians(w.latitude))
                  * cos(radians(w.longitude) - radians($2))
                  + sin(radians($3)) * sin(radians(w.latitude))
                ))
              )
            ) AS distance_km
          FROM workers w
          ${whereClause}
        ) sub
        WHERE sub.distance_km <= $4
        ORDER BY sub.distance_km ASC
        LIMIT ${limit}
      `;

      const workers = (await this.prisma.$queryRawUnsafe(
        rawQuery,
        ...params,
      )) as any[];

      const formatted = workers.map((w: any) => {
        const dtoType = prismaToDto[w.workerType] || WorkerType.NHAN_CONG;
        return {
          id: w.id,
          name: w.name,
          phone: w.phone,
          avatar: w.avatar,
          workerType: dtoType,
          workerTypeLabel: this.getWorkerTypeLabel(dtoType),
          skills: w.skills || [],
          experience: w.experience || 0,
          rating: Number(w.rating) || 0,
          reviewCount: w.reviewCount || 0,
          location: w.location,
          district: w.district,
          province: w.province,
          latitude: w.latitude,
          longitude: w.longitude,
          availability: w.availability,
          verified: w.isVerified || false,
          completedJobs: w.completedJobs || 0,
          hourlyRate: w.hourlyRate ? Number(w.hourlyRate) : null,
          dailyRate: w.dailyRate ? Number(w.dailyRate) : null,
          bio: w.bio,
          certifications: w.certifications || [],
          portfolioImages: w.portfolioImages || [],
          distanceKm: Math.round(Number(w.distance_km) * 10) / 10,
          estimatedArrival: this.estimateArrival(Number(w.distance_km)),
        };
      });

      return {
        success: true,
        data: formatted,
        total: formatted.length,
        searchCenter: { lat, lng },
        radiusKm: radius,
      };
    } catch (error) {
      this.logger.error('Error finding nearby workers:', error);
      throw new BadRequestException(
        'Không thể tìm thợ gần đây: ' + error.message,
      );
    }
  }

  /**
   * Seed random GPS locations for workers without coordinates
   */
  async seedWorkerLocations(dto: SeedWorkerLocationsDto) {
    const {
      centerLat = 10.7769,
      centerLng = 106.7009,
      spreadRadius = 15,
    } = dto;

    try {
      // Get all workers without GPS
      const workers = await this.prisma.worker.findMany({
        where: {
          OR: [{ latitude: null }, { longitude: null }],
        },
        select: { id: true, district: true, location: true },
      });

      if (workers.length === 0) {
        return {
          success: true,
          message: 'Tất cả workers đã có tọa độ GPS',
          updated: 0,
        };
      }

      // HCM district coordinates for realistic distribution
      const districtCoords: Record<string, { lat: number; lng: number }> = {
        'Quận 1': { lat: 10.7769, lng: 106.7009 },
        'Quận 2': { lat: 10.787, lng: 106.748 },
        'Quận 3': { lat: 10.7854, lng: 106.6856 },
        'Quận 4': { lat: 10.7589, lng: 106.705 },
        'Quận 5': { lat: 10.7544, lng: 106.6637 },
        'Quận 6': { lat: 10.7463, lng: 106.6351 },
        'Quận 7': { lat: 10.734, lng: 106.7216 },
        'Quận 8': { lat: 10.7228, lng: 106.6285 },
        'Quận 9': { lat: 10.8483, lng: 106.776 },
        'Quận 10': { lat: 10.7774, lng: 106.6683 },
        'Quận 11': { lat: 10.7629, lng: 106.6506 },
        'Quận 12': { lat: 10.8671, lng: 106.6413 },
        'Thủ Đức': { lat: 10.8513, lng: 106.7532 },
        'Bình Thạnh': { lat: 10.8081, lng: 106.7046 },
        'Gò Vấp': { lat: 10.8388, lng: 106.6526 },
        'Tân Bình': { lat: 10.8015, lng: 106.6325 },
        'Tân Phú': { lat: 10.79, lng: 106.628 },
        'Phú Nhuận': { lat: 10.7996, lng: 106.6815 },
        'Bình Tân': { lat: 10.7652, lng: 106.6043 },
        'Nhà Bè': { lat: 10.694, lng: 106.7 },
        'Hóc Môn': { lat: 10.8863, lng: 106.592 },
        'Củ Chi': { lat: 11.0076, lng: 106.5137 },
        'Cần Giờ': { lat: 10.4114, lng: 106.9533 },
      };

      let updated = 0;

      for (const worker of workers) {
        // Try to match by district name
        let baseLat = centerLat;
        let baseLng = centerLng;

        const district = worker.district || worker.location || '';
        for (const [key, coords] of Object.entries(districtCoords)) {
          if (
            district.toLowerCase().includes(key.toLowerCase()) ||
            key.toLowerCase().includes(district.toLowerCase())
          ) {
            baseLat = coords.lat;
            baseLng = coords.lng;
            break;
          }
        }

        // Add random jitter (~0.5-3km)
        const jitterLat = (Math.random() - 0.5) * 0.04;
        const jitterLng = (Math.random() - 0.5) * 0.04;

        await this.prisma.worker.update({
          where: { id: worker.id },
          data: {
            latitude: baseLat + jitterLat,
            longitude: baseLng + jitterLng,
          },
        });

        updated++;
      }

      return {
        success: true,
        message: `Đã cập nhật tọa độ GPS cho ${updated} workers`,
        updated,
        total: workers.length,
      };
    } catch (error) {
      this.logger.error('Error seeding worker locations:', error);
      throw new BadRequestException('Không thể seed tọa độ: ' + error.message);
    }
  }

  /**
   * Estimate arrival time based on distance
   */
  private estimateArrival(distanceKm: number): string {
    // Average speed ~25 km/h in city traffic
    const minutes = Math.round((distanceKm / 25) * 60);
    if (minutes < 5) return '< 5 phút';
    if (minutes < 15) return '5-15 phút';
    if (minutes < 30) return '15-30 phút';
    if (minutes < 60) return '30-60 phút';
    return `~${Math.round(minutes / 60)} giờ`;
  }
}
