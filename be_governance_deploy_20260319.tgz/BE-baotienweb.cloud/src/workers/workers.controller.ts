import {
    Body,
    Controller,
    Get,
    Param,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import {
    ApproveWorkerDto,
    CreateWorkerReviewDto,
    NearbyWorkerQueryDto,
    RegisterWorkerDto,
    SeedWorkerLocationsDto,
    WorkerQueryDto,
    WorkerStatsQueryDto,
    WorkerStatus,
    WorkerType,
} from './dto/worker.dto';
import { WorkersService, WorkerStatsResponse } from './workers.service.db';

@ApiTags('Workers - Tìm thợ xây dựng')
@Controller('workers')
@UseGuards(ApiKeyGuard)
export class WorkersController {
  constructor(private readonly workersService: WorkersService) {}

  // ==================== PUBLIC ENDPOINTS ====================

  @Get()
  @ApiOperation({ summary: 'Lấy danh sách thợ với filter' })
  @ApiResponse({ status: 200, description: 'Danh sách thợ' })
  @ApiQuery({
    name: 'specialty',
    required: false,
    description: 'Filter by specialty (e.g., dien, nuoc, son)',
  })
  @ApiQuery({
    name: 'location',
    required: false,
    description: 'Filter by location',
  })
  @ApiQuery({
    name: 'available',
    required: false,
    type: Boolean,
    description: 'Only available workers',
  })
  @ApiQuery({
    name: 'verified',
    required: false,
    type: Boolean,
    description: 'Only verified workers',
  })
  @ApiQuery({
    name: 'minRating',
    required: false,
    type: Number,
    description: 'Minimum rating',
  })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  findAll(@Query() query: WorkerQueryDto) {
    return this.workersService.findAll(query);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get worker statistics by type and location' })
  @ApiResponse({
    status: 200,
    description: 'Worker statistics returned successfully',
  })
  @ApiQuery({
    name: 'workerType',
    required: false,
    description: 'Filter by worker type',
  })
  @ApiQuery({
    name: 'location',
    required: false,
    description: 'Filter by location',
  })
  async getWorkerStats(
    @Query() query: WorkerStatsQueryDto,
  ): Promise<WorkerStatsResponse> {
    return this.workersService.getWorkerStats(query);
  }

  @Get('types')
  @ApiOperation({ summary: 'Get all worker types/specialties' })
  @ApiResponse({ status: 200, description: 'Worker types returned' })
  async getWorkerTypes() {
    return this.workersService.getWorkerTypes();
  }

  @Get('specialties')
  @ApiOperation({ summary: 'Get all specialties with labels' })
  @ApiResponse({ status: 200, description: 'Specialties returned' })
  async getSpecialties() {
    return this.workersService.getSpecialties();
  }

  @Get('locations')
  @ApiOperation({ summary: 'Get available locations' })
  @ApiResponse({ status: 200, description: 'Locations returned' })
  async getLocations() {
    return this.workersService.getLocations();
  }

  @Get('featured')
  @ApiOperation({ summary: 'Get featured/top-rated workers' })
  @ApiResponse({ status: 200, description: 'Featured workers' })
  async getFeatured(@Query('limit') limit?: number) {
    return this.workersService.getFeaturedWorkers();
  }

  @Get('prices')
  @ApiOperation({
    summary: 'Lấy khoảng giá thợ (min/max) theo loại - Vua Thợ style',
  })
  @ApiResponse({
    status: 200,
    description: 'Khoảng giá theo loại thợ dựa trên báo giá thực tế',
  })
  @ApiQuery({
    name: 'workerType',
    required: false,
    description: 'Lọc theo loại thợ cụ thể',
  })
  async getPriceRanges(@Query('workerType') workerType?: WorkerType) {
    return this.workersService.getPriceRanges(workerType as any);
  }

  @Get('guide')
  @ApiOperation({
    summary: 'Quy trình làm việc đặt thợ - Hướng dẫn như Vua Thợ',
  })
  @ApiResponse({
    status: 200,
    description: 'Quy trình đặt thợ và hướng dẫn khoảng giá',
  })
  async getWorkProcess() {
    return this.workersService.getWorkProcess();
  }

  @Get('nearby')
  @ApiOperation({ summary: 'Tìm thợ gần đây theo tọa độ GPS (Grab-style)' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách thợ gần đây với khoảng cách',
  })
  @ApiQuery({
    name: 'lat',
    required: true,
    type: Number,
    description: 'Latitude',
  })
  @ApiQuery({
    name: 'lng',
    required: true,
    type: Number,
    description: 'Longitude',
  })
  @ApiQuery({
    name: 'radius',
    required: false,
    type: Number,
    description: 'Bán kính tìm kiếm (km), mặc định 10',
  })
  @ApiQuery({ name: 'workerType', required: false, description: 'Loại thợ' })
  @ApiQuery({
    name: 'available',
    required: false,
    type: Boolean,
    description: 'Chỉ thợ có sẵn',
  })
  @ApiQuery({
    name: 'minRating',
    required: false,
    type: Number,
    description: 'Đánh giá tối thiểu',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'Số lượng kết quả tối đa',
  })
  async findNearby(@Query() query: NearbyWorkerQueryDto) {
    return this.workersService.findNearby(query);
  }

  @Post('seed-locations')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Seed GPS locations cho workers chưa có tọa độ (Admin)',
  })
  @ApiResponse({ status: 200, description: 'Workers đã được cập nhật tọa độ' })
  async seedWorkerLocations(@Body() dto: SeedWorkerLocationsDto) {
    return this.workersService.seedWorkerLocations(dto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get worker detail' })
  @ApiResponse({ status: 200, description: 'Worker detail' })
  @ApiResponse({ status: 404, description: 'Worker not found' })
  async findOne(@Param('id') id: string) {
    return this.workersService.findOne(id);
  }

  @Get(':id/reviews')
  @ApiOperation({ summary: 'Get worker reviews' })
  @ApiResponse({ status: 200, description: 'Worker reviews' })
  async getReviews(@Param('id') id: string) {
    return this.workersService.getReviews(id);
  }

  // ==================== AUTHENTICATED ENDPOINTS ====================

  @Post('register')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Register as a new worker' })
  @ApiResponse({
    status: 201,
    description: 'Worker registered, pending approval',
  })
  async registerWorker(@Body() dto: RegisterWorkerDto) {
    return this.workersService.registerWorker(dto);
  }

  @Post(':id/reviews')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Add review for a worker' })
  @ApiResponse({ status: 201, description: 'Review added' })
  async addReview(
    @Param('id') workerId: string,
    @Body() dto: CreateWorkerReviewDto,
    @CurrentUser() user: any,
  ) {
    return this.workersService.addReview(workerId, dto, user.id);
  }

  @Post(':id/contact')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Contact/Book a worker' })
  @ApiResponse({ status: 200, description: 'Contact request sent' })
  async contactWorker(
    @Param('id') workerId: string,
    @Body() dto: { message?: string; projectDescription?: string },
    @CurrentUser() user: any,
  ) {
    return this.workersService.contactWorker(workerId, user.id, dto.message);
  }

  // ==================== ADMIN ENDPOINTS ====================

  @Get('admin/pending')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.STAFF)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get pending worker registrations (Admin)' })
  async getPendingWorkers(@Query() query: WorkerQueryDto) {
    return this.workersService.findAll({
      ...query,
      status: WorkerStatus.PENDING,
    });
  }

  @Patch(':id/approve')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.STAFF)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Approve/Reject worker registration (Admin)' })
  @ApiResponse({ status: 200, description: 'Worker status updated' })
  async approveWorker(
    @Param('id') id: string,
    @Body() dto: ApproveWorkerDto,
    @CurrentUser() user: any,
  ) {
    return this.workersService.approveWorker(id, dto, user.id);
  }

  @Patch(':id/verify')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.STAFF)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Verify worker identity (Admin)' })
  @ApiResponse({ status: 200, description: 'Worker verified' })
  async verifyWorker(@Param('id') id: string, @CurrentUser() user: any) {
    return this.workersService.verifyWorker(id, user.id);
  }

  @Patch(':id/feature')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Toggle featured status (Admin)' })
  async toggleFeatured(@Param('id') id: string, @CurrentUser() user: any) {
    return this.workersService.toggleFeatured(id, user.id);
  }
}
