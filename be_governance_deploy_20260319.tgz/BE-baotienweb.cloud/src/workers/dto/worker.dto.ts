import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    Max,
    Min,
} from 'class-validator';

export enum WorkerType {
  EP_COC = 'EP_COC',
  DAO_DAT = 'DAO_DAT',
  VAT_LIEU = 'VAT_LIEU',
  NHAN_CONG = 'NHAN_CONG',
  THO_XAY = 'THO_XAY',
  THO_COFFA = 'THO_COFFA',
  THO_SAT = 'THO_SAT',
  THO_DIEN = 'THO_DIEN',
  THO_NUOC = 'THO_NUOC',
  THO_SON = 'THO_SON',
  THO_GACH = 'THO_GACH',
  THO_THACH_CAO = 'THO_THACH_CAO',
  THO_MOC = 'THO_MOC',
  THO_HAN = 'THO_HAN',
  THO_CAMERA = 'THO_CAMERA',
  THO_NHOM_KINH = 'THO_NHOM_KINH',
  KY_SU = 'KY_SU',
  GIAM_SAT = 'GIAM_SAT',
}

export enum WorkerStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  SUSPENDED = 'SUSPENDED',
}

// ==================== QUERY DTO ====================
export class WorkerQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional({ description: 'Search by name, specialty' })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({
    description: 'Filter by specialty (e.g., dien, nuoc, son)',
  })
  @IsOptional()
  @IsString()
  specialty?: string;

  @ApiPropertyOptional({ enum: WorkerType })
  @IsOptional()
  @IsEnum(WorkerType)
  workerType?: WorkerType;

  @ApiPropertyOptional({
    description:
      'Filter by category (construction, finishing, design, electrical, plumbing, aluminum)',
  })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiPropertyOptional({ description: 'Filter by location' })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional({ description: 'Only available workers' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  available?: boolean;

  @ApiPropertyOptional({ description: 'Only verified workers' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  verified?: boolean;

  @ApiPropertyOptional({ description: 'Minimum rating (1-5)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(5)
  minRating?: number;

  @ApiPropertyOptional({ description: 'Maximum price per day' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  maxPrice?: number;

  @ApiPropertyOptional({ enum: WorkerStatus })
  @IsOptional()
  @IsEnum(WorkerStatus)
  status?: WorkerStatus;

  @ApiPropertyOptional({
    default: 'rating',
    enum: ['rating', 'price', 'experience', 'completedJobs'],
  })
  @IsOptional()
  @IsString()
  sortBy?: string;

  @ApiPropertyOptional({ default: 'desc', enum: ['asc', 'desc'] })
  @IsOptional()
  @IsString()
  sortOrder?: 'asc' | 'desc';
}

export class WorkerStatsQueryDto {
  @ApiPropertyOptional({
    enum: WorkerType,
    description: 'Filter by worker type',
  })
  @IsOptional()
  @IsEnum(WorkerType)
  workerType?: WorkerType;

  @ApiPropertyOptional({ description: 'Filter by location' })
  @IsOptional()
  @IsString()
  location?: string;
}

// ==================== NEARBY QUERY DTO ====================
export class NearbyWorkerQueryDto {
  @ApiProperty({ description: 'Latitude of search center' })
  @Type(() => Number)
  @IsNumber()
  lat: number;

  @ApiProperty({ description: 'Longitude of search center' })
  @Type(() => Number)
  @IsNumber()
  lng: number;

  @ApiPropertyOptional({
    description: 'Search radius in km (default: 10)',
    default: 10,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(100)
  radius?: number;

  @ApiPropertyOptional({
    enum: WorkerType,
    description: 'Filter by worker type',
  })
  @IsOptional()
  @IsEnum(WorkerType)
  workerType?: WorkerType;

  @ApiPropertyOptional({ description: 'Only available workers' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  available?: boolean;

  @ApiPropertyOptional({ description: 'Minimum rating (1-5)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(5)
  minRating?: number;

  @ApiPropertyOptional({
    description: 'Max results (default: 20)',
    default: 20,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(50)
  limit?: number;
}

// ==================== SEED LOCATIONS DTO ====================
export class SeedWorkerLocationsDto {
  @ApiPropertyOptional({
    description: 'Center latitude (default: HCM 10.7769)',
    default: 10.7769,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  centerLat?: number;

  @ApiPropertyOptional({
    description: 'Center longitude (default: HCM 106.7009)',
    default: 106.7009,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  centerLng?: number;

  @ApiPropertyOptional({
    description: 'Spread radius in km (default: 15)',
    default: 15,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  spreadRadius?: number;
}

// ==================== REGISTER DTO ====================
export class RegisterWorkerDto {
  @ApiProperty({ description: 'Worker name' })
  @IsString()
  name: string;

  @ApiProperty({ description: 'Phone number' })
  @IsString()
  phone: string;

  @ApiProperty({ enum: WorkerType, description: 'Worker type' })
  @IsEnum(WorkerType)
  workerType: WorkerType;

  @ApiProperty({ description: 'Location/City' })
  @IsString()
  location: string;

  @ApiPropertyOptional({ description: 'District/Area' })
  @IsOptional()
  @IsString()
  district?: string;

  @ApiPropertyOptional({ description: 'Years of experience' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  experience?: number;

  @ApiPropertyOptional({ description: 'Skills/certifications' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  skills?: string[];

  @ApiPropertyOptional({ description: 'Has own equipment' })
  @IsOptional()
  @IsBoolean()
  hasEquipment?: boolean;

  @ApiPropertyOptional({ description: 'Expected daily rate (VND)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  dailyRate?: number;

  @ApiPropertyOptional({ description: 'Avatar URL' })
  @IsOptional()
  @IsString()
  avatar?: string;

  @ApiPropertyOptional({ description: 'ID card number (CCCD)' })
  @IsOptional()
  @IsString()
  idCard?: string;

  @ApiPropertyOptional({ description: 'ID card images' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  idCardImages?: string[];

  @ApiPropertyOptional({ description: 'Portfolio images' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  portfolio?: string[];

  @ApiPropertyOptional({ description: 'Bio/Introduction' })
  @IsOptional()
  @IsString()
  bio?: string;
}

// ==================== REVIEW DTO ====================
export class CreateWorkerReviewDto {
  @ApiProperty({ description: 'Rating (1-5)', minimum: 1, maximum: 5 })
  @IsNumber()
  @Min(1)
  @Max(5)
  rating: number;

  @ApiPropertyOptional({ description: 'Review comment' })
  @IsOptional()
  @IsString()
  comment?: string;

  @ApiPropertyOptional({ description: 'Project ID related to this review' })
  @IsOptional()
  @IsString()
  projectId?: string;

  @ApiPropertyOptional({ description: 'Review images' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  images?: string[];
}

// ==================== APPROVE DTO ====================
export class ApproveWorkerDto {
  @ApiProperty({ enum: WorkerStatus })
  @IsEnum(WorkerStatus)
  status: WorkerStatus;

  @ApiPropertyOptional({ description: 'Reason for rejection' })
  @IsOptional()
  @IsString()
  reason?: string;
}

// ==================== RESPONSE DTO ====================
export class WorkerResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  phone: string;

  @ApiProperty({ enum: WorkerType })
  workerType: WorkerType;

  @ApiProperty()
  location: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  registeredAt: string;

  @ApiProperty()
  verified: boolean;
}
