import { Module } from '@nestjs/common';
import { MetricsModule } from '../metrics/metrics.module';
import { ProgressGateway } from './progress.gateway';

@Module({
  imports: [MetricsModule],
  providers: [ProgressGateway],
  exports: [ProgressGateway],
})
export class ProgressModule {}
