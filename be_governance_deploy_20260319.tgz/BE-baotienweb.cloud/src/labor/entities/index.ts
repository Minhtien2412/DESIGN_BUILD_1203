// Entity definitions for future database integration
// Currently using in-memory storage

export enum ProviderStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  SUSPENDED = 'suspended',
}

export enum ProviderType {
  INDIVIDUAL = 'individual',
  COMPANY = 'company',
  TEAM = 'team',
}

export interface LaborProvider {
  id: number;
  name: string;
  companyName?: string;
  type: ProviderType;
  description?: string;
  skills?: string[];
  certifications?: string[];
  hourlyRate?: number;
  dailyRate?: number;
  phone?: string;
  email?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  avatarUrl?: string;
  portfolioImages?: string[];
  status: ProviderStatus;
  availability?: {
    days: string[];
    startTime: string;
    endTime: string;
  };
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface LaborReview {
  id: number;
  providerId: number;
  userId: number;
  bookingId?: number;
  rating: number;
  comment?: string;
  images?: string[];
  isVerified: boolean;
  providerResponse?: string;
  responseAt?: Date;
  createdAt: Date;
}

export enum BookingStatus {
  PENDING = 'pending',
  CONFIRMED = 'confirmed',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export interface LaborBooking {
  id: number;
  providerId: number;
  userId: number;
  projectId?: number;
  description?: string;
  startDate: Date;
  endDate?: Date;
  startTime?: string;
  endTime?: string;
  estimatedCost?: number;
  finalCost?: number;
  status: BookingStatus;
  notes?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}
