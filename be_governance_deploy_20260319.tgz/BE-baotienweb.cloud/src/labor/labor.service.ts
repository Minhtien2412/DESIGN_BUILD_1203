import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateBookingDto,
    CreateProviderDto,
    CreateReviewDto,
    NearbyProvidersDto,
    QueryProvidersDto,
    QueryReviewsDto,
    UpdateBookingDto,
    UpdateProviderDto,
} from './dto';

@Injectable()
export class LaborService {
  // In-memory storage
  private providers: Map<number, any> = new Map();
  private reviews: Map<number, any> = new Map();
  private bookings: Map<number, any> = new Map();
  private providerIdCounter = 1;
  private reviewIdCounter = 1;
  private bookingIdCounter = 1;

  constructor(private prisma: PrismaService) {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleProviders = [
      {
        id: 1,
        name: 'Nguyễn Văn Minh',
        companyName: null,
        type: 'individual',
        description: 'Thợ điện lành nghề với 10 năm kinh nghiệm',
        skills: ['Electrical', 'Wiring', 'Panel Installation'],
        certifications: ['Chứng chỉ thợ điện hạng 3'],
        hourlyRate: 200000,
        dailyRate: 1500000,
        phone: '0901234567',
        email: 'minh@email.com',
        address: '123 Nguyễn Huệ, Q.1, TP.HCM',
        latitude: 10.773083,
        longitude: 106.701044,
        rating: 4.8,
        reviewCount: 56,
        completedJobs: 89,
        avatarUrl: 'https://randomuser.me/api/portraits/men/1.jpg',
        status: 'active',
        availability: {
          days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
          startTime: '07:00',
          endTime: '18:00',
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        name: 'Trần Thị Lan',
        companyName: 'Lan Plumbing Services',
        type: 'company',
        description: 'Dịch vụ sửa chữa nước uy tín',
        skills: ['Plumbing', 'Pipe Installation', 'Water Heater'],
        certifications: ['Giấy phép kinh doanh', 'Chứng nhận ISO'],
        hourlyRate: 180000,
        dailyRate: 1300000,
        phone: '0912345678',
        email: 'lan.plumbing@email.com',
        address: '456 Lê Lợi, Q.3, TP.HCM',
        latitude: 10.778655,
        longitude: 106.699633,
        rating: 4.6,
        reviewCount: 42,
        completedJobs: 67,
        avatarUrl: 'https://randomuser.me/api/portraits/women/2.jpg',
        status: 'active',
        availability: {
          days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
          startTime: '08:00',
          endTime: '17:00',
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 3,
        name: 'Đội xây dựng Hoàng Long',
        companyName: 'Hoàng Long Construction',
        type: 'team',
        description: 'Đội xây dựng chuyên nghiệp, nhận mọi công trình',
        skills: ['Construction', 'Masonry', 'Concrete', 'Framing', 'Roofing'],
        certifications: ['Giấy phép xây dựng', 'Bảo hiểm công trình'],
        hourlyRate: 250000,
        dailyRate: 2000000,
        phone: '0923456789',
        email: 'hoanglong@construction.com',
        address: '789 Võ Văn Tần, Q.3, TP.HCM',
        latitude: 10.771324,
        longitude: 106.689285,
        rating: 4.9,
        reviewCount: 128,
        completedJobs: 234,
        avatarUrl: 'https://randomuser.me/api/portraits/men/3.jpg',
        status: 'active',
        availability: {
          days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
          startTime: '06:00',
          endTime: '18:00',
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 4,
        name: 'Lê Văn Hùng',
        type: 'individual',
        description: 'Thợ sơn nước chuyên nghiệp',
        skills: ['Painting', 'Wall Preparation', 'Decorative Painting'],
        hourlyRate: 150000,
        dailyRate: 1100000,
        phone: '0934567890',
        address: '321 Hai Bà Trưng, Q.1, TP.HCM',
        latitude: 10.785734,
        longitude: 106.699156,
        rating: 4.5,
        reviewCount: 23,
        completedJobs: 45,
        avatarUrl: 'https://randomuser.me/api/portraits/men/4.jpg',
        status: 'active',
        availability: {
          days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
          startTime: '08:00',
          endTime: '17:00',
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    sampleProviders.forEach((p) => {
      this.providers.set(p.id, p);
      this.providerIdCounter = Math.max(this.providerIdCounter, p.id + 1);
    });

    // Sample reviews
    const sampleReviews = [
      {
        id: 1,
        providerId: 1,
        userId: 1,
        rating: 5,
        comment: 'Thợ điện rất chuyên nghiệp, làm việc nhanh gọn',
        isVerified: true,
        createdAt: new Date(),
      },
      {
        id: 2,
        providerId: 1,
        userId: 2,
        rating: 4,
        comment: 'Giá cả hợp lý, chất lượng tốt',
        isVerified: true,
        createdAt: new Date(),
      },
      {
        id: 3,
        providerId: 3,
        userId: 1,
        rating: 5,
        comment: 'Đội xây dựng làm việc rất chỉnh chu',
        isVerified: true,
        createdAt: new Date(),
      },
    ];

    sampleReviews.forEach((r) => {
      this.reviews.set(r.id, r);
      this.reviewIdCounter = Math.max(this.reviewIdCounter, r.id + 1);
    });
  }

  // ============ PROVIDERS ============

  async getProviders(query: QueryProvidersDto) {
    let providers = Array.from(this.providers.values());

    // Search filter
    if (query.search) {
      const search = query.search.toLowerCase();
      providers = providers.filter(
        (p) =>
          p.name.toLowerCase().includes(search) ||
          p.description?.toLowerCase().includes(search) ||
          p.skills?.some((s: string) => s.toLowerCase().includes(search)),
      );
    }

    // Skills filter
    if (query.skills?.length) {
      providers = providers.filter((p) =>
        query.skills!.some((skill) =>
          p.skills?.some((s: string) =>
            s.toLowerCase().includes(skill.toLowerCase()),
          ),
        ),
      );
    }

    // Type filter
    if (query.type) {
      providers = providers.filter((p) => p.type === query.type);
    }

    // Rating filter
    if (query.minRating) {
      providers = providers.filter((p) => p.rating >= query.minRating!);
    }

    // Hourly rate filter
    if (query.maxHourlyRate) {
      providers = providers.filter(
        (p) => p.hourlyRate && p.hourlyRate <= query.maxHourlyRate!,
      );
    }

    // Pagination
    const page = query.page || 1;
    const limit = query.limit || 20;
    const total = providers.length;
    const start = (page - 1) * limit;
    const paginatedProviders = providers.slice(start, start + limit);

    return {
      data: paginatedProviders,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getProvider(id: number) {
    const provider = this.providers.get(id);
    if (!provider) {
      throw new NotFoundException(`Provider with ID ${id} not found`);
    }
    return provider;
  }

  async getNearbyProviders(dto: NearbyProvidersDto) {
    const radius = dto.radius || 10;
    const limit = dto.limit || 20;

    let providers = Array.from(this.providers.values()).filter((p) => {
      if (!p.latitude || !p.longitude) return false;
      const distance = this.calculateDistance(
        dto.latitude,
        dto.longitude,
        p.latitude,
        p.longitude,
      );
      return distance <= radius;
    });

    // Skills filter
    if (dto.skills?.length) {
      providers = providers.filter((p) =>
        dto.skills!.some((skill) =>
          p.skills?.some((s: string) =>
            s.toLowerCase().includes(skill.toLowerCase()),
          ),
        ),
      );
    }

    // Add distance to each provider
    providers = providers.map((p) => ({
      ...p,
      distance: this.calculateDistance(
        dto.latitude,
        dto.longitude,
        p.latitude,
        p.longitude,
      ),
    }));

    // Sort by distance
    providers.sort((a, b) => a.distance - b.distance);

    return {
      data: providers.slice(0, limit),
      meta: {
        total: providers.length,
        searchLocation: { latitude: dto.latitude, longitude: dto.longitude },
        radius,
      },
    };
  }

  async createProvider(dto: CreateProviderDto) {
    const provider = {
      id: this.providerIdCounter++,
      ...dto,
      type: dto.type || 'individual',
      rating: 0,
      reviewCount: 0,
      completedJobs: 0,
      status: 'active',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.providers.set(provider.id, provider);
    return provider;
  }

  async updateProvider(id: number, dto: UpdateProviderDto) {
    const provider = await this.getProvider(id);
    const updated = {
      ...provider,
      ...dto,
      updatedAt: new Date(),
    };
    this.providers.set(id, updated);
    return updated;
  }

  async deleteProvider(id: number) {
    if (!this.providers.has(id)) {
      throw new NotFoundException(`Provider with ID ${id} not found`);
    }
    this.providers.delete(id);
    return { deleted: true, id };
  }

  // ============ REVIEWS ============

  async getProviderReviews(providerId: number, query: QueryReviewsDto) {
    await this.getProvider(providerId);

    let reviews = Array.from(this.reviews.values()).filter(
      (r) => r.providerId === providerId,
    );

    if (query.minRating) {
      reviews = reviews.filter((r) => r.rating >= query.minRating!);
    }

    // Sort by date descending
    reviews.sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );

    const page = query.page || 1;
    const limit = query.limit || 10;
    const total = reviews.length;
    const start = (page - 1) * limit;
    const paginatedReviews = reviews.slice(start, start + limit);

    return {
      data: paginatedReviews,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        averageRating:
          reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length || 0,
      },
    };
  }

  async createReview(userId: number, dto: CreateReviewDto) {
    await this.getProvider(dto.providerId);

    const review = {
      id: this.reviewIdCounter++,
      ...dto,
      userId,
      isVerified: false,
      createdAt: new Date(),
    };
    this.reviews.set(review.id, review);

    // Update provider rating
    await this.updateProviderRating(dto.providerId);

    return review;
  }

  private async updateProviderRating(providerId: number) {
    const reviews = Array.from(this.reviews.values()).filter(
      (r) => r.providerId === providerId,
    );
    const provider = this.providers.get(providerId);
    if (provider && reviews.length > 0) {
      const avgRating =
        reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
      provider.rating = Math.round(avgRating * 10) / 10;
      provider.reviewCount = reviews.length;
      this.providers.set(providerId, provider);
    }
  }

  // ============ BOOKINGS ============

  async createBooking(userId: number, dto: CreateBookingDto) {
    const provider = await this.getProvider(dto.providerId);

    const booking = {
      id: this.bookingIdCounter++,
      ...dto,
      userId,
      status: 'pending',
      estimatedCost: this.calculateEstimatedCost(provider, dto),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bookings.set(booking.id, booking);
    return booking;
  }

  async getBooking(id: number) {
    const booking = this.bookings.get(id);
    if (!booking) {
      throw new NotFoundException(`Booking with ID ${id} not found`);
    }
    return booking;
  }

  async updateBooking(id: number, dto: UpdateBookingDto) {
    const booking = await this.getBooking(id);
    const updated = {
      ...booking,
      ...dto,
      updatedAt: new Date(),
    };
    this.bookings.set(id, updated);

    // If completed, increment provider's completedJobs
    if (dto.status === 'completed' && booking.status !== 'completed') {
      const provider = this.providers.get(booking.providerId);
      if (provider) {
        provider.completedJobs++;
        this.providers.set(provider.id, provider);
      }
    }

    return updated;
  }

  async getUserBookings(userId: number) {
    return Array.from(this.bookings.values())
      .filter((b) => b.userId === userId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
  }

  // ============ HELPERS ============

  private calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
  ): number {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) *
        Math.cos(this.toRad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c * 10) / 10;
  }

  private toRad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  private calculateEstimatedCost(
    provider: any,
    dto: CreateBookingDto,
  ): number | null {
    if (!provider.dailyRate) return null;
    const startDate = new Date(dto.startDate);
    const endDate = dto.endDate ? new Date(dto.endDate) : startDate;
    const days = Math.max(
      1,
      Math.ceil(
        (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24),
      ) + 1,
    );
    return provider.dailyRate * days;
  }
}
