import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import {
    CreateBookingDto,
    CreateProviderDto,
    CreateReviewDto,
    NearbyProvidersDto,
    QueryProvidersDto,
    QueryReviewsDto,
    UpdateBookingDto,
    UpdateProviderDto,
} from './dto';
import { LaborService } from './labor.service';

@ApiTags('Labor Providers')
@Controller({ path: 'labor', version: '1' })
export class LaborController {
  constructor(private readonly service: LaborService) {}

  // ============ PROVIDERS ============

  @Get()
  @ApiOperation({ summary: 'Get all labor providers with filters' })
  @ApiResponse({ status: 200, description: 'List of providers' })
  getProviders(@Query() query: QueryProvidersDto) {
    return this.service.getProviders(query);
  }

  @Get('nearby')
  @ApiOperation({ summary: 'Get nearby providers by location' })
  @ApiQuery({ name: 'latitude', required: true, type: Number })
  @ApiQuery({ name: 'longitude', required: true, type: Number })
  @ApiQuery({ name: 'radius', required: false, type: Number })
  @ApiQuery({ name: 'skills', required: false, type: [String] })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'List of nearby providers' })
  getNearbyProviders(@Query() query: NearbyProvidersDto) {
    return this.service.getNearbyProviders(query);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get provider by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Provider details' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  getProvider(@Param('id', ParseIntPipe) id: number) {
    return this.service.getProvider(id);
  }

  @Post()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new provider' })
  @ApiResponse({ status: 201, description: 'Provider created successfully' })
  @HttpCode(HttpStatus.CREATED)
  createProvider(@Body() dto: CreateProviderDto) {
    return this.service.createProvider(dto);
  }

  @Put(':id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update provider by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Provider updated successfully' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  updateProvider(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateProviderDto,
  ) {
    return this.service.updateProvider(id, dto);
  }

  @Delete(':id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete provider by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Provider deleted' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  deleteProvider(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteProvider(id);
  }

  // ============ REVIEWS ============

  @Get(':id/reviews')
  @ApiOperation({ summary: 'Get reviews for a provider' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'List of reviews' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  getProviderReviews(
    @Param('id', ParseIntPipe) id: number,
    @Query() query: QueryReviewsDto,
  ) {
    return this.service.getProviderReviews(id, query);
  }

  @Post(':id/reviews')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a review for a provider' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 201, description: 'Review created successfully' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  @HttpCode(HttpStatus.CREATED)
  createReview(
    @Param('id', ParseIntPipe) providerId: number,
    @Body() dto: CreateReviewDto,
    @Req() req: any,
  ) {
    const userId = req.user?.id || 1; // Default to 1 for testing
    return this.service.createReview(userId, { ...dto, providerId });
  }

  // ============ BOOKINGS ============

  @Post(':id/bookings')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a booking with a provider' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 201, description: 'Booking created successfully' })
  @ApiResponse({ status: 404, description: 'Provider not found' })
  @HttpCode(HttpStatus.CREATED)
  createBooking(
    @Param('id', ParseIntPipe) providerId: number,
    @Body() dto: CreateBookingDto,
    @Req() req: any,
  ) {
    const userId = req.user?.id || 1; // Default to 1 for testing
    return this.service.createBooking(userId, { ...dto, providerId });
  }

  @Get('bookings/my')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current user bookings' })
  @ApiResponse({ status: 200, description: 'List of user bookings' })
  getUserBookings(@Req() req: any) {
    const userId = req.user?.id || 1;
    return this.service.getUserBookings(userId);
  }

  @Get('bookings/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get booking by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Booking details' })
  @ApiResponse({ status: 404, description: 'Booking not found' })
  getBooking(@Param('id', ParseIntPipe) id: number) {
    return this.service.getBooking(id);
  }

  @Put('bookings/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update booking by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Booking updated' })
  @ApiResponse({ status: 404, description: 'Booking not found' })
  updateBooking(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateBookingDto,
  ) {
    return this.service.updateBooking(id, dto);
  }
}
