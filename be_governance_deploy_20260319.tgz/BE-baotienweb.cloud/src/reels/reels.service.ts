/**
 * Reels Service - Xử lý video từ Pexels và biến thành "video của chúng ta"
 * 
 * Flow:
 * 1. Fetch video từ Pexels API (key ẩn phía server)
 * 2. Transform data: thêm user giả, description tiếng Việt, tags
 * 3. Cache trong database để không cần gọi Pexels mỗi lần
 * 4. Trả về cho app với format chuẩn
 * 
 * @author AI Assistant
 * @date 16/01/2026
 */

import { HttpService } from '@nestjs/axios';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';

// ==================== TYPES ====================

interface PexelsVideoFile {
  id: number;
  quality: string;
  file_type: string;
  width: number;
  height: number;
  link: string;
}

interface PexelsVideo {
  id: number;
  width: number;
  height: number;
  duration: number;
  url: string;
  image: string;
  user: {
    id: number;
    name: string;
    url: string;
  };
  video_files: PexelsVideoFile[];
}

interface PexelsResponse {
  page: number;
  per_page: number;
  total_results: number;
  videos: PexelsVideo[];
}

// Output format cho app
export interface ReelResponse {
  id: string;
  user: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    followers: string;
    isFollowing: boolean;
  };
  videoUrl: string;
  thumbnail: string;
  description: string;
  music: string;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  views: string;
  duration: string;
  liked: boolean;
  saved: boolean;
  category: string;
  tags: string[];
  source: 'server';
  createdAt: string;
}

// ==================== FAKE DATA GENERATORS ====================

// Danh sách tên người Việt giả
const VIETNAMESE_NAMES = [
  'Kiến Trúc Sư Minh', 'Nội Thất Luxury', 'Thợ Xây Pro', 'HomeDesign VN',
  'Garden Master', 'Đồ Gỗ Mỹ Nghệ', 'Phong Thủy Số', 'Decor Studio',
  'Architect Team', 'Interior Dreams', 'Build Master VN', 'Design House',
  'Nguyễn Kiến Trúc', 'Trần Nội Thất', 'Lê Xây Dựng', 'Phạm Thiết Kế',
  'Hoàng Decor', 'Vũ Landscape', 'Đặng Home', 'Bùi Construction',
];

// Descriptions tiếng Việt theo category
const DESCRIPTIONS: Record<string, string[]> = {
  architecture: [
    '🏠 Thiết kế nhà phố hiện đại 2024\n\n#kientruc #nhadep #thietke',
    '🏗️ Biệt thự sang trọng với hồ bơi\n\n#biethu #luxuryhouse #vietnam',
    '🏢 Văn phòng minimalist đẳng cấp\n\n#vanphong #office #modern',
    '🌆 Căn hộ view đẹp Sài Gòn\n\n#canho #apartment #saigon',
    '🏡 Nhà vườn yên bình\n\n#nhavuon #garden #peaceful',
  ],
  interior: [
    '✨ Phòng khách tối giản sang trọng\n\n#noithat #phongkhach #minimal',
    '🛋️ Decor phòng ngủ aesthetic\n\n#phongngu #bedroom #aesthetic',
    '🍳 Bếp hiện đại tiện nghi\n\n#bep #kitchen #modern',
    '🚿 Phòng tắm spa tại gia\n\n#phongtam #bathroom #spa',
    '📚 Góc làm việc work from home\n\n#workfromhome #desk #office',
  ],
  construction: [
    '💪 Kỹ thuật xây móng chuẩn\n\n#xaydung #mong #foundation',
    '🧱 Tiến độ thi công tuần 5\n\n#thicong #progress #building',
    '⚡ Lắp đặt hệ thống điện\n\n#dien #electrical #install',
    '🔧 Hoàn thiện nội thất\n\n#hoanthien #finish #interior',
    '🏗️ Đổ sàn tầng 3\n\n#dosan #concrete #floor',
  ],
  garden: [
    '🌿 Thiết kế sân vườn mini\n\n#sanvuon #garden #landscape',
    '🌺 Góc ban công đầy hoa\n\n#bancong #balcony #flowers',
    '🌳 Tiểu cảnh sân vườn Nhật\n\n#sanvuonnhat #zen #japanese',
    '💧 Hồ cá koi tự làm\n\n#hocakoi #pond #diy',
    '🌱 Vườn rau sạch tại nhà\n\n#vuonrau #organic #homegrown',
  ],
  material: [
    '🪵 Review gỗ tự nhiên vs công nghiệp\n\n#go #wood #material',
    '🧱 So sánh các loại gạch ốp\n\n#gach #tiles #compare',
    '🎨 Bảng màu sơn 2024\n\n#son #paint #color',
    '💎 Đá granite cao cấp\n\n#da #granite #stone',
    '🔩 Phụ kiện nội thất thông minh\n\n#phukien #hardware #smart',
  ],
};

// Music tracks giả
const MUSIC_TRACKS = [
  '♪ Nhạc nền - Chill Acoustic',
  '♪ Original Sound',
  '♪ Trending Beat 2024',
  '♪ Lo-fi Construction',
  '♪ Peaceful Garden',
  '♪ Modern House Mix',
  '♪ Build & Design',
  '♪ Home Sweet Home',
];

// Category mapping từ Pexels query
const CATEGORY_MAP: Record<string, string> = {
  architecture: 'kientruc',
  interior: 'noithat',
  construction: 'thicong',
  garden: 'sanvuon',
  material: 'vatlieu',
  default: 'general',
};

// ==================== SERVICE ====================

@Injectable()
export class ReelsService {
  private readonly logger = new Logger(ReelsService.name);
  private readonly pexelsApiKey: string;
  private readonly pexelsBaseUrl = 'https://api.pexels.com/videos';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    this.pexelsApiKey = this.configService.get<string>('PEXELS_API_KEY', '');
    
    if (!this.pexelsApiKey) {
      this.logger.warn('PEXELS_API_KEY not configured!');
    }
  }

  /**
   * Lấy danh sách reels - ưu tiên cache, nếu không có thì fetch từ Pexels
   */
  async getReels(
    category = 'all',
    page = 1,
    limit = 15,
  ): Promise<{ reels: ReelResponse[]; hasMore: boolean; total: number }> {
    try {
      // 1. Thử lấy từ database cache trước
      const cachedReels = await this.getCachedReels(category, page, limit);
      
      if (cachedReels.length >= limit) {
        this.logger.log(`[Cache Hit] Returning ${cachedReels.length} cached reels`);
        return {
          reels: cachedReels,
          hasMore: true,
          total: cachedReels.length,
        };
      }

      // 2. Nếu cache không đủ, fetch từ Pexels
      this.logger.log(`[Cache Miss] Fetching from Pexels for category: ${category}`);
      const pexelsReels = await this.fetchFromPexels(category, page, limit);
      
      // 3. Lưu vào cache
      if (pexelsReels.length > 0) {
        await this.cacheReels(pexelsReels);
      }

      return {
        reels: pexelsReels,
        hasMore: pexelsReels.length >= limit,
        total: pexelsReels.length,
      };
    } catch (error: unknown) {
      this.logger.error('Error getting reels:', error);
      
      // Fallback: trả về sample reels
      return {
        reels: this.getSampleReels(),
        hasMore: false,
        total: 5,
      };
    }
  }

  /**
   * Fetch videos từ Pexels API và transform thành format của chúng ta
   */
  private async fetchFromPexels(
    category: string,
    page: number,
    limit: number,
  ): Promise<ReelResponse[]> {
    if (!this.pexelsApiKey) {
      this.logger.warn('Pexels API key not configured, using samples');
      return this.getSampleReels();
    }

    // Map category to search query
    const queryMap: Record<string, string> = {
      all: 'architecture interior design construction',
      kientruc: 'modern architecture building design',
      noithat: 'interior design living room bedroom',
      thicong: 'construction building site work',
      sanvuon: 'garden landscape outdoor design',
      vatlieu: 'construction materials wood concrete',
      general: 'home design renovation',
    };

    const query = queryMap[category] || queryMap.general;

    try {
      const response = await firstValueFrom(
        this.httpService.get<PexelsResponse>(`${this.pexelsBaseUrl}/search`, {
          headers: {
            Authorization: this.pexelsApiKey,
          },
          params: {
            query,
            page,
            per_page: limit,
            orientation: 'portrait', // Video dọc cho reels
          },
        }),
      );

      const videos = response.data.videos || [];
      
      // Transform Pexels videos to our format
      return videos.map((video, index) => 
        this.transformPexelsVideo(video, category, index)
      );
    } catch (error: any) {
      this.logger.error('Pexels API error:', error?.message || error);
      return [];
    }
  }

  /**
   * Transform Pexels video sang format của chúng ta
   * Thêm user Việt Nam, description tiếng Việt, stats giả
   */
  private transformPexelsVideo(
    video: PexelsVideo,
    category: string,
    index: number,
  ): ReelResponse {
    // Lấy video file chất lượng SD (nhẹ hơn)
    const sdVideo = video.video_files.find(f => f.quality === 'sd') 
      || video.video_files.find(f => f.quality === 'hd')
      || video.video_files[0];

    // Random user Việt Nam
    const userName = VIETNAMESE_NAMES[Math.floor(Math.random() * VIETNAMESE_NAMES.length)];
    const userId = `user_${video.user.id}_${Date.now()}`;

    // Random description theo category
    const categoryKey = this.getCategoryKey(category);
    const descriptions = DESCRIPTIONS[categoryKey] || DESCRIPTIONS.architecture;
    const description = descriptions[index % descriptions.length];

    // Random stats
    const likes = Math.floor(Math.random() * 50000) + 1000;
    const comments = Math.floor(Math.random() * 2000) + 50;
    const shares = Math.floor(Math.random() * 1000) + 20;
    const saves = Math.floor(Math.random() * 3000) + 100;
    const views = Math.floor(Math.random() * 500000) + 10000;

    return {
      id: `reel_${video.id}`,
      user: {
        id: userId,
        name: userName,
        avatar: `https://i.pravatar.cc/150?u=${userId}`,
        verified: Math.random() > 0.5,
        followers: this.formatNumber(Math.floor(Math.random() * 200000) + 5000),
        isFollowing: false,
      },
      videoUrl: sdVideo?.link || '',
      thumbnail: video.image,
      description,
      music: MUSIC_TRACKS[Math.floor(Math.random() * MUSIC_TRACKS.length)],
      likes,
      comments,
      shares,
      saves,
      views: this.formatNumber(views),
      duration: this.formatDuration(video.duration),
      liked: false,
      saved: false,
      category: CATEGORY_MAP[categoryKey] || 'general',
      tags: this.extractTags(description),
      source: 'server',
      createdAt: new Date().toISOString(),
    };
  }

  /**
   * Lấy reels từ database cache
   */
  private async getCachedReels(
    category: string,
    page: number,
    limit: number,
  ): Promise<ReelResponse[]> {
    try {
      // Giả sử có bảng CachedReel trong Prisma schema
      // Nếu chưa có, return empty array
      // const cachedReels = await this.prisma.cachedReel.findMany({
      //   where: category !== 'all' ? { category } : {},
      //   skip: (page - 1) * limit,
      //   take: limit,
      //   orderBy: { createdAt: 'desc' },
      // });
      // return cachedReels.map(r => JSON.parse(r.data));
      
      return []; // Tạm thời return empty, cần migrate database
    } catch (error: any) {
      this.logger.warn('Cache not available:', error?.message || error);
      return [];
    }
  }

  /**
   * Lưu reels vào database cache
   */
  private async cacheReels(reels: ReelResponse[]): Promise<void> {
    try {
      // Giả sử có bảng CachedReel
      // await this.prisma.cachedReel.createMany({
      //   data: reels.map(reel => ({
      //     reelId: reel.id,
      //     category: reel.category,
      //     data: JSON.stringify(reel),
      //     expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24h
      //   })),
      //   skipDuplicates: true,
      // });
      this.logger.log(`Cached ${reels.length} reels (cache disabled)`);
    } catch (error: any) {
      this.logger.warn('Failed to cache reels:', error?.message || error);
    }
  }

  /**
   * Sample reels khi không có Pexels API
   */
  private getSampleReels(): ReelResponse[] {
    const sampleVideos = [
      'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    ];

    return sampleVideos.map((url, index) => ({
      id: `sample_${index + 1}`,
      user: {
        id: `sample_user_${index + 1}`,
        name: VIETNAMESE_NAMES[index],
        avatar: `https://i.pravatar.cc/150?u=sample${index}`,
        verified: true,
        followers: `${Math.floor(Math.random() * 100) + 10}K`,
        isFollowing: false,
      },
      videoUrl: url,
      thumbnail: url.replace('.mp4', '.jpg').replace('sample/', 'sample/images/'),
      description: DESCRIPTIONS.architecture[index % 5],
      music: MUSIC_TRACKS[index % MUSIC_TRACKS.length],
      likes: Math.floor(Math.random() * 10000) + 500,
      comments: Math.floor(Math.random() * 500) + 20,
      shares: Math.floor(Math.random() * 200) + 10,
      saves: Math.floor(Math.random() * 1000) + 50,
      views: `${Math.floor(Math.random() * 100) + 10}K`,
      duration: '0:30',
      liked: false,
      saved: false,
      category: 'kientruc',
      tags: ['demo', 'video', 'sample'],
      source: 'server',
      createdAt: new Date().toISOString(),
    }));
  }

  // ==================== HELPERS ====================

  private getCategoryKey(category: string): string {
    const map: Record<string, string> = {
      kientruc: 'architecture',
      noithat: 'interior',
      thicong: 'construction',
      sanvuon: 'garden',
      vatlieu: 'material',
    };
    return map[category] || 'architecture';
  }

  private formatNumber(num: number): string {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  private formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  private extractTags(description: string): string[] {
    const matches = description.match(/#\w+/g) || [];
    return matches.map(tag => tag.replace('#', ''));
  }

  /**
   * Lấy video theo ID
   */
  async getReelById(id: string): Promise<ReelResponse | null> {
    // Có thể implement sau với database lookup
    return null;
  }

  /**
   * Tăng view count
   */
  async incrementView(id: string): Promise<void> {
    // Có thể implement sau với database
    this.logger.log(`View incremented for reel: ${id}`);
  }
}
