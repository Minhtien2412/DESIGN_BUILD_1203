/**
 * Video Cache Service - Hệ thống lưu trữ và quản lý video
 * 
 * Tính năng:
 * 1. Lưu trữ ~2GB video từ các nguồn API (Pexels)
 * 2. Auto-cleanup video cũ khi đạt giới hạn dung lượng
 * 3. Random display cho mỗi user, không trùng lặp
 * 4. Background download video mới
 * 
 * Algorithm:
 * - FIFO cleanup: Video được hiển thị sớm nhất sẽ bị xóa trước
 * - Random selection: Fisher-Yates shuffle + tracking per session
 * - Deduplication: Mỗi video unique by externalId
 * 
 * @author AI Assistant
 * @date 16/01/2026
 */

import { HttpService } from '@nestjs/axios';
import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron, CronExpression } from '@nestjs/schedule';
import * as fs from 'fs';
import * as path from 'path';
import { firstValueFrom } from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';

// ==================== CONFIGURATION ====================

interface CacheConfig {
  maxStorageBytes: number;        // 2GB default
  minFreeSpaceBytes: number;      // Keep 100MB free
  videosPerFetch: number;         // Videos to fetch per API call
  targetVideoCount: number;       // Số video mục tiêu trong cache
  cleanupThreshold: number;       // % dung lượng để trigger cleanup
  downloadIntervalMs: number;     // Interval giữa các lần download
}

const DEFAULT_CONFIG: CacheConfig = {
  maxStorageBytes: 2 * 1024 * 1024 * 1024, // 2GB
  minFreeSpaceBytes: 100 * 1024 * 1024,    // 100MB
  videosPerFetch: 15,
  targetVideoCount: 200,                    // ~200 videos
  cleanupThreshold: 0.9,                    // 90%
  downloadIntervalMs: 5 * 60 * 1000,       // 5 minutes
};

// Vietnamese names pool
const VIETNAMESE_NAMES = [
  'Kiến Trúc Sư Minh', 'Nội Thất Luxury', 'Thợ Xây Pro', 'HomeDesign VN',
  'Garden Master', 'Đồ Gỗ Mỹ Nghệ', 'Phong Thủy Số', 'Decor Studio',
  'Architect Team', 'Interior Dreams', 'Build Master VN', 'Design House',
  'Nguyễn Kiến Trúc', 'Trần Nội Thất', 'Lê Xây Dựng', 'Phạm Thiết Kế',
  'Hoàng Decor', 'Vũ Landscape', 'Đặng Home', 'Bùi Construction',
  'An Decor Studio', 'Bình Nội Thất', 'Cường Kiến Trúc', 'Dũng Builder',
];

// Descriptions pool
const DESCRIPTIONS: Record<string, string[]> = {
  architecture: [
    '🏠 Thiết kế nhà phố hiện đại 2024\n\n#kientruc #nhadep #thietke',
    '🏗️ Biệt thự sang trọng với hồ bơi\n\n#biethu #luxuryhouse #vietnam',
    '🏢 Văn phòng minimalist đẳng cấp\n\n#vanphong #office #modern',
    '🌆 Căn hộ view đẹp Sài Gòn\n\n#canho #apartment #saigon',
    '🏡 Nhà vườn yên bình\n\n#nhavuon #garden #peaceful',
    '🏘️ Thiết kế nhà liền kề\n\n#nhalienke #townhouse #design',
    '🏛️ Kiến trúc tân cổ điển\n\n#tancodien #classic #architecture',
  ],
  interior: [
    '✨ Phòng khách tối giản sang trọng\n\n#noithat #phongkhach #minimal',
    '🛋️ Decor phòng ngủ aesthetic\n\n#phongngu #bedroom #aesthetic',
    '🍳 Bếp hiện đại tiện nghi\n\n#bep #kitchen #modern',
    '🚿 Phòng tắm spa tại gia\n\n#phongtam #bathroom #spa',
    '📚 Góc làm việc work from home\n\n#workfromhome #desk #office',
    '🪑 Nội thất gỗ công nghiệp\n\n#gocongnghiep #furniture #wood',
    '💡 Hệ thống chiếu sáng thông minh\n\n#lighting #smart #design',
  ],
  construction: [
    '💪 Kỹ thuật xây móng chuẩn\n\n#xaydung #mong #foundation',
    '🧱 Tiến độ thi công tuần 5\n\n#thicong #progress #building',
    '⚡ Lắp đặt hệ thống điện\n\n#dien #electrical #install',
    '🔧 Hoàn thiện nội thất\n\n#hoanthien #finish #interior',
    '🏗️ Đổ sàn tầng 3\n\n#dosan #concrete #floor',
    '🚧 Công trình đang thi công\n\n#congtrinh #construction #site',
    '🔨 Kỹ thuật xây tường gạch\n\n#xaytuong #brick #masonry',
  ],
  garden: [
    '🌿 Thiết kế sân vườn mini\n\n#sanvuon #garden #landscape',
    '🌺 Góc ban công đầy hoa\n\n#bancong #balcony #flowers',
    '🌳 Tiểu cảnh sân vườn Nhật\n\n#sanvuonnhat #zen #japanese',
    '💧 Hồ cá koi tự làm\n\n#hocakoi #pond #diy',
    '🌱 Vườn rau sạch tại nhà\n\n#vuonrau #organic #homegrown',
    '🌴 Cây xanh trong nhà\n\n#indoorplants #green #nature',
    '🎍 Sân vườn phong cách tropical\n\n#tropical #garden #outdoor',
  ],
  material: [
    '🪵 Review gỗ tự nhiên vs công nghiệp\n\n#go #wood #material',
    '🧱 So sánh các loại gạch ốp\n\n#gach #tiles #compare',
    '🎨 Bảng màu sơn 2024\n\n#son #paint #color',
    '💎 Đá granite cao cấp\n\n#da #granite #stone',
    '🔩 Phụ kiện nội thất thông minh\n\n#phukien #hardware #smart',
    '🏗️ Vật liệu xây dựng mới\n\n#vatlieu #buildingmaterial #new',
    '🪟 Các loại kính xây dựng\n\n#kinh #glass #window',
  ],
};

// Music tracks
const MUSIC_TRACKS = [
  '♪ Nhạc nền - Chill Acoustic',
  '♪ Original Sound - Build & Design',
  '♪ Trending Beat 2024',
  '♪ Lo-fi Construction',
  '♪ Peaceful Garden Vibes',
  '♪ Modern House Mix',
  '♪ Home Sweet Home',
  '♪ Vietnamese Chill',
  '♪ Relaxing Piano',
  '♪ Nature Sounds Mix',
];

// Pexels search queries
const SEARCH_QUERIES = [
  'modern architecture building',
  'interior design living room',
  'construction building site',
  'garden landscape design',
  'home renovation',
  'luxury house interior',
  'minimalist design',
  'house construction process',
  'kitchen design modern',
  'bedroom interior design',
];

// ==================== SERVICE ====================

@Injectable()
export class VideoCacheService implements OnModuleInit {
  private readonly logger = new Logger(VideoCacheService.name);
  private readonly pexelsApiKey: string;
  private readonly pexelsBaseUrl = 'https://api.pexels.com/videos';
  private readonly videoStoragePath: string;
  private config: CacheConfig;
  private isDownloading = false;
  private currentPage = 1;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    this.pexelsApiKey = this.configService.get<string>('PEXELS_API_KEY', '');
    this.videoStoragePath = this.configService.get<string>(
      'VIDEO_STORAGE_PATH',
      '/var/www/video-cache',
    );
    this.config = { ...DEFAULT_CONFIG };
  }

  async onModuleInit() {
    // Ensure storage directory exists
    await this.ensureStorageDirectory();
    
    // Load config from database
    await this.loadConfig();
    
    // Initial stats
    const stats = await this.getStorageStats();
    this.logger.log(`[VideoCacheService] Initialized`);
    this.logger.log(`  Storage: ${this.videoStoragePath}`);
    this.logger.log(`  Videos: ${stats.videoCount}`);
    this.logger.log(`  Size: ${this.formatBytes(stats.totalSize)} / ${this.formatBytes(this.config.maxStorageBytes)}`);
    
    // Start initial download if empty
    if (stats.videoCount < 10) {
      this.logger.log('[VideoCacheService] Starting initial video download...');
      this.downloadNewVideos();
    }
  }

  // ==================== PUBLIC API ====================

  /**
   * Lấy danh sách video random cho user, không trùng lặp
   */
  async getRandomVideosForUser(
    sessionId: string,
    userId: number | null,
    limit = 10,
  ): Promise<any[]> {
    try {
      // 1. Lấy các video đã xem của session này
      const watchedIds = await this.prisma.userVideoHistory.findMany({
        where: { sessionId },
        select: { videoId: true },
      });
      const watchedVideoIds = watchedIds.map(w => w.videoId);

      // 2. Lấy các video active chưa xem
      const availableVideos = await this.prisma.cachedVideo.findMany({
        where: {
          isActive: true,
          id: { notIn: watchedVideoIds },
        },
        orderBy: { downloadedAt: 'desc' },
        take: Math.min(limit * 3, 100), // Lấy nhiều hơn để shuffle
      });

      if (availableVideos.length === 0) {
        // Reset history nếu đã xem hết
        this.logger.log(`[Session ${sessionId}] Watched all videos, resetting history`);
        await this.prisma.userVideoHistory.deleteMany({
          where: { sessionId },
        });
        return this.getRandomVideosForUser(sessionId, userId, limit);
      }

      // 3. Fisher-Yates shuffle
      const shuffled = this.shuffleArray([...availableVideos]);
      const selectedVideos = shuffled.slice(0, limit);

      // 4. Record viewing history
      const historyRecords = selectedVideos.map((video, index) => ({
        sessionId,
        userId,
        videoId: video.id,
        feedPosition: watchedVideoIds.length + index,
      }));

      await this.prisma.userVideoHistory.createMany({
        data: historyRecords,
        skipDuplicates: true,
      });

      // 5. Update displayOrder for cleanup tracking
      await this.updateDisplayOrder(selectedVideos.map(v => v.id));

      // 6. Transform to response format
      return selectedVideos.map(video => this.transformToResponse(video));
    } catch (error: any) {
      this.logger.error('Error getting random videos:', error?.message);
      return [];
    }
  }

  /**
   * Lấy thông tin storage
   */
  async getStorageStats(): Promise<{
    videoCount: number;
    totalSize: number;
    usedPercent: number;
    maxSize: number;
    freeSpace: number;
  }> {
    const videos = await this.prisma.cachedVideo.findMany({
      where: { isActive: true },
      select: { fileSize: true },
    });

    const totalSize = videos.reduce((sum, v) => sum + v.fileSize, 0);
    const usedPercent = (totalSize / this.config.maxStorageBytes) * 100;

    return {
      videoCount: videos.length,
      totalSize,
      usedPercent: Math.round(usedPercent * 100) / 100,
      maxSize: this.config.maxStorageBytes,
      freeSpace: this.config.maxStorageBytes - totalSize,
    };
  }

  /**
   * Record video view
   */
  async recordView(
    videoId: number,
    sessionId: string,
    watchDuration: number,
    completed: boolean,
  ): Promise<void> {
    try {
      await this.prisma.userVideoHistory.updateMany({
        where: { videoId, sessionId },
        data: { watchDuration, completed },
      });

      // Update view count
      await this.prisma.cachedVideo.update({
        where: { id: videoId },
        data: {
          viewsCount: { increment: 1 },
          lastDisplayedAt: new Date(),
        },
      });
    } catch (error: any) {
      this.logger.warn('Error recording view:', error?.message);
    }
  }

  /**
   * Get single video by ID
   */
  async getVideoById(id: number): Promise<any | null> {
    const video = await this.prisma.cachedVideo.findUnique({
      where: { id },
    });
    return video ? this.transformToResponse(video) : null;
  }

  // ==================== DOWNLOAD & CLEANUP ====================

  /**
   * Download videos mới từ Pexels - Chạy theo schedule
   */
  @Cron(CronExpression.EVERY_5_MINUTES)
  async downloadNewVideos(): Promise<void> {
    if (this.isDownloading) {
      this.logger.log('[Download] Already in progress, skipping...');
      return;
    }

    if (!this.pexelsApiKey) {
      this.logger.warn('[Download] PEXELS_API_KEY not configured');
      return;
    }

    this.isDownloading = true;
    this.logger.log('[Download] Starting video download job...');

    try {
      // 1. Check storage
      const stats = await this.getStorageStats();
      
      if (stats.usedPercent >= this.config.cleanupThreshold * 100) {
        this.logger.log(`[Download] Storage at ${stats.usedPercent}%, running cleanup first`);
        await this.cleanupOldVideos();
      }

      // 2. Check if we need more videos
      if (stats.videoCount >= this.config.targetVideoCount) {
        this.logger.log(`[Download] Already have ${stats.videoCount} videos, skipping`);
        this.isDownloading = false;
        return;
      }

      // 3. Fetch from Pexels
      const query = SEARCH_QUERIES[Math.floor(Math.random() * SEARCH_QUERIES.length)];
      const videos = await this.fetchPexelsVideos(query, this.currentPage);

      this.logger.log(`[Download] Fetched ${videos.length} videos for query: "${query}"`);

      // 4. Download each video
      let downloadCount = 0;
      for (const video of videos) {
        const externalId = `pexels_${video.id}`;
        
        // Check if already exists
        const exists = await this.prisma.cachedVideo.findUnique({
          where: { externalId },
        });

        if (exists) {
          this.logger.debug(`[Download] Video ${externalId} already exists, skipping`);
          continue;
        }

        // Check storage space
        const currentStats = await this.getStorageStats();
        if (currentStats.freeSpace < this.config.minFreeSpaceBytes) {
          this.logger.log('[Download] Not enough space, stopping downloads');
          break;
        }

        // Download video file
        const result = await this.downloadVideoFile(video);
        if (result) {
          downloadCount++;
          await this.logAction('download', result.id, externalId, result.fileSize, true);
        }

        // Small delay between downloads
        await this.sleep(1000);
      }

      this.logger.log(`[Download] Completed. Downloaded ${downloadCount} new videos`);
      
      // Move to next page
      this.currentPage = (this.currentPage % 10) + 1;

    } catch (error: any) {
      this.logger.error('[Download] Error:', error?.message);
      await this.logAction('error', null, null, null, false, error?.message);
    } finally {
      this.isDownloading = false;
    }
  }

  /**
   * Cleanup video cũ - FIFO based on displayOrder
   */
  @Cron(CronExpression.EVERY_10_MINUTES)
  async cleanupOldVideos(): Promise<void> {
    this.logger.log('[Cleanup] Starting cleanup job...');

    try {
      const stats = await this.getStorageStats();
      
      if (stats.usedPercent < this.config.cleanupThreshold * 100 - 10) {
        this.logger.log(`[Cleanup] Storage at ${stats.usedPercent}%, no cleanup needed`);
        return;
      }

      // Target: reduce to 70% usage
      const targetSize = this.config.maxStorageBytes * 0.7;
      let currentSize = stats.totalSize;
      let deletedCount = 0;

      // Get oldest displayed videos first
      const videosToDelete = await this.prisma.cachedVideo.findMany({
        where: { isActive: true },
        orderBy: [
          { displayOrder: 'asc' },
          { lastDisplayedAt: 'asc' },
          { downloadedAt: 'asc' },
        ],
        take: 50, // Process in batches
      });

      for (const video of videosToDelete) {
        if (currentSize <= targetSize) break;

        // Delete file
        await this.deleteVideoFile(video.localPath);
        if (video.thumbnailPath) {
          await this.deleteVideoFile(video.thumbnailPath);
        }

        // Soft delete in database
        await this.prisma.cachedVideo.update({
          where: { id: video.id },
          data: { isActive: false },
        });

        currentSize -= video.fileSize;
        deletedCount++;

        await this.logAction('delete', video.id, video.externalId, video.fileSize, true);
      }

      this.logger.log(`[Cleanup] Deleted ${deletedCount} videos, freed ${this.formatBytes(stats.totalSize - currentSize)}`);

    } catch (error: any) {
      this.logger.error('[Cleanup] Error:', error?.message);
    }
  }

  // ==================== PRIVATE HELPERS ====================

  private async fetchPexelsVideos(query: string, page: number): Promise<any[]> {
    try {
      const response = await firstValueFrom(
        this.httpService.get(`${this.pexelsBaseUrl}/search`, {
          headers: { Authorization: this.pexelsApiKey },
          params: {
            query,
            page,
            per_page: this.config.videosPerFetch,
            orientation: 'portrait',
          },
        }),
      );
      return response.data?.videos || [];
    } catch (error: any) {
      this.logger.error('Pexels API error:', error?.message);
      return [];
    }
  }

  private async downloadVideoFile(pexelsVideo: any): Promise<any | null> {
    try {
      // Get SD quality video (smaller file)
      const videoFile = pexelsVideo.video_files.find((f: any) => f.quality === 'sd')
        || pexelsVideo.video_files.find((f: any) => f.quality === 'hd')
        || pexelsVideo.video_files[0];

      if (!videoFile?.link) {
        this.logger.warn(`No video URL for ${pexelsVideo.id}`);
        return null;
      }

      // Generate filename
      const externalId = `pexels_${pexelsVideo.id}`;
      const fileName = `${externalId}_${Date.now()}.mp4`;
      const localPath = path.join(this.videoStoragePath, fileName);

      // Download video
      this.logger.debug(`[Download] Downloading ${externalId}...`);
      const response = await firstValueFrom(
        this.httpService.get(videoFile.link, {
          responseType: 'arraybuffer',
          timeout: 60000, // 60s timeout
        }),
      );

      // Write to file
      fs.writeFileSync(localPath, Buffer.from(response.data));
      const fileSize = fs.statSync(localPath).size;

      // Generate fake Vietnamese data
      const category = this.getRandomCategory();
      const userName = VIETNAMESE_NAMES[Math.floor(Math.random() * VIETNAMESE_NAMES.length)];
      const descriptions = DESCRIPTIONS[category] || DESCRIPTIONS.architecture;
      const description = descriptions[Math.floor(Math.random() * descriptions.length)];

      // Save to database
      const cachedVideo = await this.prisma.cachedVideo.create({
        data: {
          externalId,
          sourceType: 'pexels',
          localPath,
          fileName,
          fileSize,
          mimeType: 'video/mp4',
          title: `Video ${pexelsVideo.id}`,
          description,
          thumbnailUrl: pexelsVideo.image,
          duration: pexelsVideo.duration || 0,
          width: videoFile.width || 0,
          height: videoFile.height || 0,
          userName,
          userAvatar: `https://i.pravatar.cc/150?u=${externalId}`,
          userVerified: Math.random() > 0.6,
          userFollowers: this.formatFollowers(Math.floor(Math.random() * 200000) + 5000),
          likesCount: Math.floor(Math.random() * 50000) + 1000,
          commentsCount: Math.floor(Math.random() * 2000) + 50,
          sharesCount: Math.floor(Math.random() * 1000) + 20,
          savesCount: Math.floor(Math.random() * 3000) + 100,
          viewsCount: Math.floor(Math.random() * 500000) + 10000,
          category,
          tags: this.extractTags(description),
          musicTrack: MUSIC_TRACKS[Math.floor(Math.random() * MUSIC_TRACKS.length)],
          displayOrder: 0,
        },
      });

      this.logger.log(`[Download] Saved ${externalId} (${this.formatBytes(fileSize)})`);
      return cachedVideo;

    } catch (error: any) {
      this.logger.error(`Download error for ${pexelsVideo.id}:`, error?.message);
      return null;
    }
  }

  private async deleteVideoFile(filePath: string): Promise<void> {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (error: any) {
      this.logger.warn(`Failed to delete file ${filePath}:`, error?.message);
    }
  }

  private async updateDisplayOrder(videoIds: number[]): Promise<void> {
    const maxOrder = await this.prisma.cachedVideo.aggregate({
      _max: { displayOrder: true },
    });
    const startOrder = (maxOrder._max.displayOrder || 0) + 1;

    for (let i = 0; i < videoIds.length; i++) {
      await this.prisma.cachedVideo.update({
        where: { id: videoIds[i] },
        data: {
          displayOrder: startOrder + i,
          lastDisplayedAt: new Date(),
        },
      });
    }
  }

  private async ensureStorageDirectory(): Promise<void> {
    if (!fs.existsSync(this.videoStoragePath)) {
      fs.mkdirSync(this.videoStoragePath, { recursive: true });
      this.logger.log(`Created storage directory: ${this.videoStoragePath}`);
    }
  }

  private async loadConfig(): Promise<void> {
    try {
      const configs = await this.prisma.videoCacheConfig.findMany();
      for (const cfg of configs) {
        if (cfg.key === 'maxStorageBytes') {
          this.config.maxStorageBytes = parseInt(cfg.value, 10);
        } else if (cfg.key === 'targetVideoCount') {
          this.config.targetVideoCount = parseInt(cfg.value, 10);
        }
      }
    } catch (error: unknown) {
      // Use defaults if table doesn't exist yet
    }
  }

  private async logAction(
    action: string,
    videoId: number | null,
    externalId: string | null,
    fileSize: number | null,
    success: boolean,
    errorMsg?: string,
  ): Promise<void> {
    try {
      await this.prisma.videoCacheLog.create({
        data: {
          action,
          videoId,
          externalId,
          fileSize,
          success,
          errorMsg,
        },
      });
    } catch (error: unknown) {
      // Ignore logging errors
    }
  }

  private transformToResponse(video: any): any {
    const baseUrl = this.configService.get<string>('APP_URL', 'https://baotienweb.cloud');
    
    return {
      id: video.id.toString(),
      user: {
        id: `user_${video.id}`,
        name: video.userName,
        avatar: video.userAvatar,
        verified: video.userVerified,
        followers: video.userFollowers,
        isFollowing: false,
      },
      videoUrl: `${baseUrl}/api/v1/reels/stream/${video.id}`,
      thumbnail: video.thumbnailUrl,
      description: video.description,
      music: video.musicTrack,
      likes: video.likesCount,
      comments: video.commentsCount,
      shares: video.sharesCount,
      saves: video.savesCount,
      views: this.formatFollowers(video.viewsCount),
      duration: this.formatDuration(video.duration),
      liked: false,
      saved: false,
      category: video.category,
      tags: video.tags,
      source: 'server',
      createdAt: video.createdAt.toISOString(),
    };
  }

  private shuffleArray<T>(array: T[]): T[] {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  private getRandomCategory(): string {
    const categories = ['architecture', 'interior', 'construction', 'garden', 'material'];
    return categories[Math.floor(Math.random() * categories.length)];
  }

  private extractTags(description: string): string[] {
    const matches = description.match(/#\w+/g) || [];
    return matches.map(tag => tag.replace('#', ''));
  }

  private formatBytes(bytes: number): string {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
  }

  private formatFollowers(num: number): string {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  private formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Stream video file - Được gọi từ controller
   */
  async getVideoFilePath(videoId: number): Promise<string | null> {
    const video = await this.prisma.cachedVideo.findUnique({
      where: { id: videoId, isActive: true },
      select: { localPath: true },
    });
    
    if (video && fs.existsSync(video.localPath)) {
      return video.localPath;
    }
    return null;
  }

  /**
   * Force refresh videos - Manual trigger
   */
  async forceRefresh(): Promise<{ downloaded: number; deleted: number }> {
    this.logger.log('[ForceRefresh] Starting manual refresh...');
    
    await this.cleanupOldVideos();
    await this.downloadNewVideos();
    
    const stats = await this.getStorageStats();
    return {
      downloaded: stats.videoCount,
      deleted: 0,
    };
  }

  /**
   * Get session stats
   */
  async getSessionStats(sessionId: string): Promise<{
    watched: number;
    remaining: number;
  }> {
    const watched = await this.prisma.userVideoHistory.count({
      where: { sessionId },
    });
    
    const total = await this.prisma.cachedVideo.count({
      where: { isActive: true },
    });

    return {
      watched,
      remaining: total - watched,
    };
  }
}
