/**
 * Reactions Controller
 *
 * API Endpoints cho emoji reactions:
 * - POST /reactions - Toggle reaction (add/change/remove)
 * - DELETE /reactions/:contentType/:contentId - Remove reaction
 * - GET /reactions/:contentType/:contentId - Get reaction summary
 * - GET /reactions/:contentType/:contentId/users - Get users who reacted
 * - POST /reactions/batch - Batch get reactions for multiple contents
 *
 * @author AI Assistant
 * @date 27/01/2026
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Logger,
    Param,
    ParseIntPipe,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import type { ReactionType } from './reactions.service';
import { ReactionsService } from './reactions.service';

// ==================== DTOs ====================

interface ToggleReactionDto {
  contentType: string; // 'post', 'article', 'product', 'video', 'message'
  contentId: number;
  type: ReactionType; // 'like', 'love', 'haha', 'wow', 'sad', 'angry'
}

interface BatchGetReactionsDto {
  contentType: string;
  contentIds: number[];
}

// ==================== CONTROLLER ====================

@ApiTags('Reactions')
@Controller('reactions')
export class ReactionsController {
  private readonly logger = new Logger(ReactionsController.name);

  constructor(private readonly reactionsService: ReactionsService) {}

  /**
   * Toggle reaction (add/change/remove)
   * POST /api/v1/reactions
   */
  @Post()
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async toggleReaction(@Body() dto: ToggleReactionDto, @Req() req: any) {
    const userId = req.user.id;
    this.logger.log(
      `User ${userId} toggling ${dto.type} on ${dto.contentType}:${dto.contentId}`,
    );

    const validTypes: ReactionType[] = [
      'like',
      'love',
      'haha',
      'wow',
      'sad',
      'angry',
    ];
    if (!validTypes.includes(dto.type)) {
      return {
        success: false,
        error: `Invalid reaction type. Valid types: ${validTypes.join(', ')}`,
      };
    }

    const result = await this.reactionsService.toggleReaction(
      userId,
      dto.contentType,
      dto.contentId,
      dto.type,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Remove reaction
   * DELETE /api/v1/reactions/:contentType/:contentId
   */
  @Delete(':contentType/:contentId')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async removeReaction(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    this.logger.log(
      `User ${userId} removing reaction from ${contentType}:${contentId}`,
    );

    const result = await this.reactionsService.removeReaction(
      userId,
      contentType,
      contentId,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Get reaction summary for content
   * GET /api/v1/reactions/:contentType/:contentId
   */
  @Get(':contentType/:contentId')
  @UseGuards(OptionalAuthGuard)
  async getReactionSummary(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;

    const summary = await this.reactionsService.getReactionSummary(
      contentType,
      contentId,
      userId,
    );

    return {
      success: true,
      ...summary,
    };
  }

  /**
   * Get users who reacted
   * GET /api/v1/reactions/:contentType/:contentId/users
   */
  @Get(':contentType/:contentId/users')
  @UseGuards(OptionalAuthGuard)
  async getReactedUsers(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Query('type') reactionType?: ReactionType,
    @Query('limit') limit = 50,
    @Query('offset') offset = 0,
  ) {
    const result = await this.reactionsService.getReactedUsers(
      contentType,
      contentId,
      reactionType,
      +limit,
      +offset,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Batch get reactions for multiple contents
   * POST /api/v1/reactions/batch
   */
  @Post('batch')
  @UseGuards(OptionalAuthGuard)
  async batchGetReactions(@Body() dto: BatchGetReactionsDto, @Req() req: any) {
    const userId = req.user?.id || null;

    if (!dto.contentIds || dto.contentIds.length === 0) {
      return {
        success: false,
        error: 'contentIds is required',
      };
    }

    if (dto.contentIds.length > 100) {
      return {
        success: false,
        error: 'Maximum 100 content IDs allowed per batch',
      };
    }

    const reactionsMap = await this.reactionsService.batchGetReactions(
      dto.contentType,
      dto.contentIds,
      userId,
    );

    // Convert Map to object for JSON response
    const reactions: Record<number, any> = {};
    for (const [contentId, summary] of reactionsMap) {
      reactions[contentId] = summary;
    }

    return {
      success: true,
      contentType: dto.contentType,
      reactions,
    };
  }

  /**
   * Get current user's reaction history
   * GET /api/v1/reactions/me
   */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  async getMyReactions(
    @Req() req: any,
    @Query('contentType') contentType?: string,
    @Query('limit') limit = 50,
    @Query('offset') offset = 0,
  ) {
    const userId = req.user.id;

    const reactions = await this.reactionsService.getUserReactions(
      userId,
      contentType,
      +limit,
      +offset,
    );

    return {
      success: true,
      reactions,
    };
  }
}
