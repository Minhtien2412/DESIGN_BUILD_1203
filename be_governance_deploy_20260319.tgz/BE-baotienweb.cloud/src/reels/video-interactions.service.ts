/**
 * Video Interactions Service
 * 
 * Quản lý tất cả tương tác với video (giống TikTok):
 * - Like/Unlike video
 * - Comment (+ reply, threading)
 * - Share tracking
 * - View tracking với watch duration
 * - Download tracking
 * - Save/Bookmark
 * 
 * @author AI Assistant
 * @date 16/01/2026
 */

import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

// ==================== TYPES ====================

export interface CommentResponse {
  id: number;
  videoId: number;
  userId: number;
  content: string;
  parentId: number | null;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    avatar: string;
    verified?: boolean;
  };
  likes: number;
  liked: boolean;
  replies?: CommentResponse[];
  repliesCount: number;
}

export interface VideoStats {
  likes: number;
  comments: number;
  shares: number;
  views: number;
  saves: number;
  downloads: number;
}

export interface VideoInteractionStatus {
  liked: boolean;
  saved: boolean;
  shared: boolean;
  viewed: boolean;
}

// ==================== SERVICE ====================

@Injectable()
export class VideoInteractionsService {
  private readonly logger = new Logger(VideoInteractionsService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ==================== LIKES ====================

  /**
   * Like/Unlike video
   * Returns: { liked: boolean, likesCount: number }
   */
  async toggleLike(videoId: number, userId: number): Promise<{ liked: boolean; likesCount: number }> {
    try {
      // Check if already liked
      const existingLike = await this.prisma.videoLike.findUnique({
        where: {
          videoId_userId: { videoId, userId },
        },
      });

      if (existingLike) {
        // Unlike
        await this.prisma.videoLike.delete({
          where: { id: existingLike.id },
        });

        // Update cached video if exists
        await this.updateCachedVideoStats(videoId, 'likes', -1);

        const likesCount = await this.getLikesCount(videoId);
        return { liked: false, likesCount };
      } else {
        // Like
        await this.prisma.videoLike.create({
          data: { videoId, userId },
        });

        // Update cached video if exists
        await this.updateCachedVideoStats(videoId, 'likes', 1);

        const likesCount = await this.getLikesCount(videoId);
        return { liked: true, likesCount };
      }
    } catch (error: any) {
      this.logger.error(`Error toggling like: ${error?.message}`);
      throw error;
    }
  }

  /**
   * Check if user liked a video
   */
  async checkLiked(videoId: number, userId: number): Promise<boolean> {
    const like = await this.prisma.videoLike.findUnique({
      where: {
        videoId_userId: { videoId, userId },
      },
    });
    return !!like;
  }

  /**
   * Get likes count for video
   */
  async getLikesCount(videoId: number): Promise<number> {
    return this.prisma.videoLike.count({
      where: { videoId },
    });
  }

  /**
   * Get list of users who liked
   */
  async getLikedUsers(videoId: number, limit = 50, offset = 0) {
    const likes = await this.prisma.videoLike.findMany({
      where: { videoId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });

    return likes.map(l => l.user);
  }

  // ==================== COMMENTS ====================

  /**
   * Create a comment (or reply if parentId provided)
   */
  async createComment(
    videoId: number,
    userId: number,
    content: string,
    parentId?: number,
  ): Promise<CommentResponse> {
    // Validate content
    if (!content || content.trim().length === 0) {
      throw new BadRequestException('Comment content is required');
    }

    if (content.length > 1000) {
      throw new BadRequestException('Comment too long (max 1000 chars)');
    }

    // Validate parent if reply
    if (parentId) {
      const parent = await this.prisma.videoComment.findUnique({
        where: { id: parentId },
      });
      if (!parent || parent.videoId !== videoId) {
        throw new BadRequestException('Invalid parent comment');
      }
    }

    const comment = await this.prisma.videoComment.create({
      data: {
        videoId,
        userId,
        content: content.trim(),
        parentId: parentId || null,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    });

    // Update cached video stats
    await this.updateCachedVideoStats(videoId, 'comments', 1);

    return this.transformComment(comment, userId);
  }

  /**
   * Get comments for video (with threading)
   */
  async getComments(
    videoId: number,
    userId: number | null,
    page = 1,
    limit = 20,
    sortBy: 'newest' | 'popular' = 'newest',
  ): Promise<{ comments: CommentResponse[]; total: number; hasMore: boolean }> {
    const offset = (page - 1) * limit;

    // Get root comments (parentId = null)
    const [comments, total] = await Promise.all([
      this.prisma.videoComment.findMany({
        where: {
          videoId,
          parentId: null, // Only root comments
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          likes: true,
          replies: {
            take: 3, // Only first 3 replies
            orderBy: { createdAt: 'asc' },
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  avatar: true,
                },
              },
              likes: true,
            },
          },
          _count: {
            select: { replies: true },
          },
        },
        orderBy: sortBy === 'popular' 
          ? { likes: { _count: 'desc' } }
          : { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      this.prisma.videoComment.count({
        where: { videoId, parentId: null },
      }),
    ]);

    const transformedComments = comments.map(c => this.transformComment(c, userId));

    return {
      comments: transformedComments,
      total,
      hasMore: offset + comments.length < total,
    };
  }

  /**
   * Get replies for a comment
   */
  async getReplies(
    commentId: number,
    userId: number | null,
    page = 1,
    limit = 10,
  ): Promise<{ replies: CommentResponse[]; hasMore: boolean }> {
    const offset = (page - 1) * limit;

    const [replies, total] = await Promise.all([
      this.prisma.videoComment.findMany({
        where: { parentId: commentId },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          likes: true,
        },
        orderBy: { createdAt: 'asc' },
        take: limit,
        skip: offset,
      }),
      this.prisma.videoComment.count({
        where: { parentId: commentId },
      }),
    ]);

    return {
      replies: replies.map(r => this.transformComment(r, userId)),
      hasMore: offset + replies.length < total,
    };
  }

  /**
   * Delete a comment (only owner can delete)
   */
  async deleteComment(commentId: number, userId: number): Promise<void> {
    const comment = await this.prisma.videoComment.findUnique({
      where: { id: commentId },
    });

    if (!comment) {
      throw new NotFoundException('Comment not found');
    }

    if (comment.userId !== userId) {
      throw new BadRequestException('Not authorized to delete this comment');
    }

    // Delete comment and all its replies (cascade)
    await this.prisma.videoComment.delete({
      where: { id: commentId },
    });

    // Update cached video stats
    await this.updateCachedVideoStats(comment.videoId, 'comments', -1);
  }

  /**
   * Like/Unlike a comment
   */
  async toggleCommentLike(commentId: number, userId: number): Promise<{ liked: boolean; likesCount: number }> {
    const existingLike = await this.prisma.videoCommentLike.findUnique({
      where: {
        commentId_userId: { commentId, userId },
      },
    });

    if (existingLike) {
      await this.prisma.videoCommentLike.delete({
        where: { id: existingLike.id },
      });
    } else {
      await this.prisma.videoCommentLike.create({
        data: { commentId, userId },
      });
    }

    const likesCount = await this.prisma.videoCommentLike.count({
      where: { commentId },
    });

    return { liked: !existingLike, likesCount };
  }

  // ==================== VIEWS ====================

  /**
   * Record a view
   */
  async recordView(
    videoId: number,
    userId: number | null,
    watchDuration: number,
    completed: boolean,
  ): Promise<{ viewsCount: number }> {
    // Check for recent view from same user (prevent spam)
    if (userId) {
      const recentView = await this.prisma.videoView.findFirst({
        where: {
          videoId,
          userId,
          createdAt: {
            gte: new Date(Date.now() - 5 * 60 * 1000), // Last 5 minutes
          },
        },
        orderBy: { createdAt: 'desc' },
      });

      if (recentView) {
        // Update existing view instead
        await this.prisma.videoView.update({
          where: { id: recentView.id },
          data: {
            watchDuration: Math.max(recentView.watchDuration, watchDuration),
            completed: completed || recentView.completed,
          },
        });
      } else {
        await this.prisma.videoView.create({
          data: { videoId, userId, watchDuration, completed },
        });
        await this.updateCachedVideoStats(videoId, 'views', 1);
      }
    } else {
      // Anonymous view
      await this.prisma.videoView.create({
        data: { videoId, watchDuration, completed },
      });
      await this.updateCachedVideoStats(videoId, 'views', 1);
    }

    const viewsCount = await this.getViewsCount(videoId);
    return { viewsCount };
  }

  /**
   * Get views count
   */
  async getViewsCount(videoId: number): Promise<number> {
    return this.prisma.videoView.count({
      where: { videoId },
    });
  }

  // ==================== SHARES ====================

  /**
   * Record a share
   */
  async recordShare(
    videoId: number,
    userId: number | null,
    platform: string,
  ): Promise<{ sharesCount: number }> {
    await this.prisma.videoShare.create({
      data: {
        videoId,
        userId,
        platform,
      },
    });

    await this.updateCachedVideoStats(videoId, 'shares', 1);

    const sharesCount = await this.getSharesCount(videoId);
    return { sharesCount };
  }

  /**
   * Get shares count
   */
  async getSharesCount(videoId: number): Promise<number> {
    return this.prisma.videoShare.count({
      where: { videoId },
    });
  }

  // ==================== SAVES/BOOKMARKS ====================
  // Note: Using existing 'saved' boolean from CachedVideo + UserVideoHistory

  /**
   * Toggle save/bookmark video
   */
  async toggleSave(videoId: number, userId: number): Promise<{ saved: boolean; savesCount: number }> {
    // For saves, we'll track via a separate field in UserVideoHistory
    const history = await this.prisma.userVideoHistory.findFirst({
      where: {
        videoId,
        userId,
      },
      orderBy: { createdAt: 'desc' },
    });

    const isSaved = history?.saved ?? false;

    if (history) {
      await this.prisma.userVideoHistory.update({
        where: { id: history.id },
        data: { saved: !isSaved },
      });
    } else {
      // Create a history entry for save
      await this.prisma.userVideoHistory.create({
        data: {
          videoId,
          userId,
          sessionId: `save_${Date.now()}`,
          saved: true,
        },
      });
    }

    // Count total saves
    const savesCount = await this.prisma.userVideoHistory.count({
      where: {
        videoId,
        saved: true,
      },
    });

    return { saved: !isSaved, savesCount };
  }

  // ==================== DOWNLOADS ====================

  /**
   * Record a download
   */
  async recordDownload(videoId: number, userId: number | null): Promise<{ downloadsCount: number }> {
    // Use VideoShare with platform = 'download'
    await this.prisma.videoShare.create({
      data: {
        videoId,
        userId,
        platform: 'download',
      },
    });

    const downloadsCount = await this.prisma.videoShare.count({
      where: {
        videoId,
        platform: 'download',
      },
    });

    return { downloadsCount };
  }

  // ==================== STATS ====================

  /**
   * Get full stats for a video
   */
  async getVideoStats(videoId: number): Promise<VideoStats> {
    const [likes, comments, shares, views, saves] = await Promise.all([
      this.prisma.videoLike.count({ where: { videoId } }),
      this.prisma.videoComment.count({ where: { videoId } }),
      this.prisma.videoShare.count({ 
        where: { videoId, NOT: { platform: 'download' } },
      }),
      this.prisma.videoView.count({ where: { videoId } }),
      this.prisma.userVideoHistory.count({
        where: { videoId, saved: true },
      }),
    ]);

    const downloads = await this.prisma.videoShare.count({
      where: { videoId, platform: 'download' },
    });

    return { likes, comments, shares, views, saves, downloads };
  }

  /**
   * Get user interaction status for a video
   */
  async getUserInteractionStatus(videoId: number, userId: number): Promise<VideoInteractionStatus> {
    const [like, save, share, view] = await Promise.all([
      this.prisma.videoLike.findUnique({
        where: { videoId_userId: { videoId, userId } },
      }),
      this.prisma.userVideoHistory.findFirst({
        where: { videoId, userId, saved: true },
      }),
      this.prisma.videoShare.findFirst({
        where: { videoId, userId },
      }),
      this.prisma.videoView.findFirst({
        where: { videoId, userId },
      }),
    ]);

    return {
      liked: !!like,
      saved: !!save,
      shared: !!share,
      viewed: !!view,
    };
  }

  /**
   * Get multiple videos stats in batch
   */
  async getBatchStats(videoIds: number[]): Promise<Record<number, VideoStats>> {
    const result: Record<number, VideoStats> = {};

    for (const id of videoIds) {
      result[id] = await this.getVideoStats(id);
    }

    return result;
  }

  // ==================== HELPERS ====================

  /**
   * Transform comment to response format
   */
  private transformComment(comment: any, userId: number | null): CommentResponse {
    const userLiked = userId
      ? comment.likes?.some((l: any) => l.userId === userId)
      : false;

    return {
      id: comment.id,
      videoId: comment.videoId,
      userId: comment.userId,
      content: comment.content,
      parentId: comment.parentId,
      createdAt: comment.createdAt,
      user: {
        id: comment.user.id,
        name: comment.user.name || 'User',
        avatar: comment.user.avatar || `https://i.pravatar.cc/150?u=${comment.userId}`,
        verified: false,
      },
      likes: comment.likes?.length || 0,
      liked: userLiked,
      replies: comment.replies?.map((r: any) => this.transformComment(r, userId)),
      repliesCount: comment._count?.replies || 0,
    };
  }

  /**
   * Update cached video stats
   */
  private async updateCachedVideoStats(
    videoId: number,
    field: 'likes' | 'comments' | 'shares' | 'views',
    increment: number,
  ): Promise<void> {
    try {
      const fieldMap: Record<string, string> = {
        likes: 'likesCount',
        comments: 'commentsCount',
        shares: 'sharesCount',
        views: 'viewsCount',
      };

      await this.prisma.cachedVideo.update({
        where: { id: videoId },
        data: {
          [fieldMap[field]]: { increment },
        },
      });
    } catch {
      // Ignore if video not in cache
    }
  }
}
