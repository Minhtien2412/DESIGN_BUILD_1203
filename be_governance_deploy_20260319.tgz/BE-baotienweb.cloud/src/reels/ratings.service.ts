/**
 * Ratings Service - Mock Data Version
 *
 * Hệ thống đánh giá sao (1-5) cho:
 * - Products (sản phẩm)
 * - Services (dịch vụ)
 * - Videos
 * - Workers
 *
 * @author AI Assistant
 * @date 28/01/2026
 */

import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';

// ==================== TYPES ====================

export interface RatingResponse {
  id: number;
  userId: number;
  contentType: string;
  contentId: number;
  stars: number;
  review: string | null;
  title: string | null;
  images: string[];
  helpful: number;
  verified: boolean;
  createdAt: Date;
  updatedAt: Date;
  user?: {
    id: number;
    name: string;
    avatar: string;
  };
}

export interface RatingSummary {
  averageRating: number;
  totalRatings: number;
  distribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
  userRating: RatingResponse | null;
}

export interface CreateRatingDto {
  stars: number;
  review?: string;
  title?: string;
  images?: string[];
  verified?: boolean;
}

export interface UpdateRatingDto {
  stars?: number;
  review?: string;
  title?: string;
  images?: string[];
}

// Mock rating data storage
interface MockRating {
  id: number;
  userId: number;
  contentType: string;
  contentId: number;
  stars: number;
  review: string | null;
  title: string | null;
  images: string[];
  helpful: number;
  verified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// ==================== SERVICE ====================

@Injectable()
export class RatingsService {
  private readonly logger = new Logger(RatingsService.name);
  private mockRatings: MockRating[] = this.initializeMockRatings();
  private nextId = 100;

  /**
   * Create or update rating
   */
  async upsertRating(
    userId: number,
    contentType: string,
    contentId: number,
    data: CreateRatingDto,
  ): Promise<{
    action: 'created' | 'updated';
    rating: RatingResponse;
    summary: RatingSummary;
  }> {
    // Validate stars
    if (data.stars < 1 || data.stars > 5) {
      throw new BadRequestException('Stars must be between 1 and 5');
    }

    this.logger.log(
      `User ${userId} rating ${contentType}:${contentId} with ${data.stars} stars`,
    );

    const existingIndex = this.mockRatings.findIndex(
      (r) =>
        r.userId === userId &&
        r.contentType === contentType &&
        r.contentId === contentId,
    );

    let rating: MockRating;
    let action: 'created' | 'updated';

    if (existingIndex >= 0) {
      // Update existing
      rating = {
        ...this.mockRatings[existingIndex],
        stars: data.stars,
        review: data.review ?? this.mockRatings[existingIndex].review,
        title: data.title ?? this.mockRatings[existingIndex].title,
        images: data.images ?? this.mockRatings[existingIndex].images,
        updatedAt: new Date(),
      };
      this.mockRatings[existingIndex] = rating;
      action = 'updated';
    } else {
      // Create new
      rating = {
        id: this.nextId++,
        userId,
        contentType,
        contentId,
        stars: data.stars,
        review: data.review || null,
        title: data.title || null,
        images: data.images || [],
        helpful: 0,
        verified: data.verified || false,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.mockRatings.push(rating);
      action = 'created';
    }

    const summary = await this.getRatingSummary(contentType, contentId, userId);

    return {
      action,
      rating: this.formatRating(rating),
      summary,
    };
  }

  /**
   * Delete user's rating
   */
  async deleteRating(
    userId: number,
    contentType: string,
    contentId: number,
  ): Promise<{ deleted: boolean; summary: RatingSummary }> {
    const existingIndex = this.mockRatings.findIndex(
      (r) =>
        r.userId === userId &&
        r.contentType === contentType &&
        r.contentId === contentId,
    );

    if (existingIndex >= 0) {
      this.mockRatings.splice(existingIndex, 1);
    }

    const summary = await this.getRatingSummary(contentType, contentId);
    return { deleted: existingIndex >= 0, summary };
  }

  /**
   * Get rating summary for content
   */
  async getRatingSummary(
    contentType: string,
    contentId: number,
    userId?: number,
  ): Promise<RatingSummary> {
    const ratings = this.mockRatings.filter(
      (r) => r.contentType === contentType && r.contentId === contentId,
    );

    const userRating = userId
      ? ratings.find((r) => r.userId === userId) || null
      : null;

    // Calculate distribution
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    let totalStars = 0;

    for (const r of ratings) {
      if (r.stars >= 1 && r.stars <= 5) {
        distribution[r.stars as 1 | 2 | 3 | 4 | 5]++;
        totalStars += r.stars;
      }
    }

    const averageRating =
      ratings.length > 0
        ? Math.round((totalStars / ratings.length) * 10) / 10
        : 0;

    return {
      averageRating,
      totalRatings: ratings.length,
      distribution,
      userRating: userRating ? this.formatRating(userRating) : null,
    };
  }

  /**
   * Get all ratings for content
   */
  async getRatings(
    contentType: string,
    contentId: number,
    options: {
      stars?: number;
      withReview?: boolean;
      sortBy?: 'newest' | 'oldest' | 'helpful' | 'highest' | 'lowest';
      limit?: number;
      offset?: number;
    } = {},
  ): Promise<{ ratings: RatingResponse[]; total: number }> {
    const {
      stars,
      withReview,
      sortBy = 'newest',
      limit = 20,
      offset = 0,
    } = options;

    let filtered = this.mockRatings.filter(
      (r) => r.contentType === contentType && r.contentId === contentId,
    );

    if (stars) {
      filtered = filtered.filter((r) => r.stars === stars);
    }
    if (withReview) {
      filtered = filtered.filter((r) => r.review !== null);
    }

    // Sort
    switch (sortBy) {
      case 'oldest':
        filtered.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
        break;
      case 'helpful':
        filtered.sort((a, b) => b.helpful - a.helpful);
        break;
      case 'highest':
        filtered.sort((a, b) => b.stars - a.stars);
        break;
      case 'lowest':
        filtered.sort((a, b) => a.stars - b.stars);
        break;
      default:
        filtered.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }

    const total = filtered.length;
    const paginated = filtered.slice(offset, offset + limit);

    return {
      ratings: paginated.map((r) => this.formatRating(r)),
      total,
    };
  }

  /**
   * Mark rating as helpful
   */
  async markHelpful(
    ratingId: number,
    _userId: number,
  ): Promise<{ helpful: number }> {
    const rating = this.mockRatings.find((r) => r.id === ratingId);

    if (!rating) {
      throw new NotFoundException('Rating not found');
    }

    rating.helpful += 1;

    return { helpful: rating.helpful };
  }

  /**
   * Batch get rating summaries
   */
  async batchGetSummaries(
    contentType: string,
    contentIds: number[],
    userId?: number,
  ): Promise<Map<number, RatingSummary>> {
    const result = new Map<number, RatingSummary>();

    for (const contentId of contentIds) {
      const summary = await this.getRatingSummary(
        contentType,
        contentId,
        userId,
      );
      result.set(contentId, summary);
    }

    return result;
  }

  /**
   * Get user's ratings
   */
  async getUserRatings(
    userId: number,
    contentType?: string,
    limit = 50,
    offset = 0,
  ): Promise<RatingResponse[]> {
    let filtered = this.mockRatings.filter((r) => r.userId === userId);

    if (contentType) {
      filtered = filtered.filter((r) => r.contentType === contentType);
    }

    filtered.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return filtered
      .slice(offset, offset + limit)
      .map((r) => this.formatRating(r));
  }

  private formatRating(rating: MockRating): RatingResponse {
    return {
      id: rating.id,
      userId: rating.userId,
      contentType: rating.contentType,
      contentId: rating.contentId,
      stars: rating.stars,
      review: rating.review,
      title: rating.title,
      images: rating.images || [],
      helpful: rating.helpful || 0,
      verified: rating.verified || false,
      createdAt: rating.createdAt,
      updatedAt: rating.updatedAt,
      user: {
        id: rating.userId,
        name: `User ${rating.userId}`,
        avatar: '',
      },
    };
  }

  private initializeMockRatings(): MockRating[] {
    return [
      {
        id: 1,
        userId: 1,
        contentType: 'product',
        contentId: 1,
        stars: 5,
        review: 'Sản phẩm chất lượng, giao hàng nhanh',
        title: 'Rất hài lòng',
        images: [],
        helpful: 10,
        verified: true,
        createdAt: new Date('2024-12-01'),
        updatedAt: new Date('2024-12-01'),
      },
      {
        id: 2,
        userId: 2,
        contentType: 'product',
        contentId: 1,
        stars: 4,
        review: 'Tốt, đáng tiền',
        title: null,
        images: [],
        helpful: 5,
        verified: false,
        createdAt: new Date('2024-12-05'),
        updatedAt: new Date('2024-12-05'),
      },
      {
        id: 3,
        userId: 3,
        contentType: 'worker',
        contentId: 1,
        stars: 5,
        review: 'Thợ làm việc chuyên nghiệp, đúng hẹn',
        title: 'Tuyệt vời',
        images: [],
        helpful: 15,
        verified: true,
        createdAt: new Date('2024-11-20'),
        updatedAt: new Date('2024-11-20'),
      },
      {
        id: 4,
        userId: 4,
        contentType: 'video',
        contentId: 1,
        stars: 5,
        review: 'Video hữu ích',
        title: null,
        images: [],
        helpful: 8,
        verified: false,
        createdAt: new Date('2024-12-10'),
        updatedAt: new Date('2024-12-10'),
      },
    ];
  }
}
