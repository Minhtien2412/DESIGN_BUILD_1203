/**
 * Reactions Service
 *
 * Generic emoji reactions cho mọi loại content:
 * - 👍 like
 * - ❤️ love
 * - 😂 haha
 * - 😮 wow
 * - 😢 sad
 * - 😡 angry
 *
 * Có thể áp dụng cho: posts, comments, messages, articles, products, etc.
 *
 * @author AI Assistant
 * @date 27/01/2026
 */

import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

// ==================== TYPES ====================

export type ReactionType = 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';

export interface ReactionResponse {
  id: number;
  userId: number;
  contentType: string;
  contentId: number;
  type: ReactionType;
  createdAt: Date;
  user?: {
    id: number;
    name: string;
    avatar: string;
  };
}

export interface ReactionCounts {
  total: number;
  like: number;
  love: number;
  haha: number;
  wow: number;
  sad: number;
  angry: number;
}

export interface ReactionSummary {
  counts: ReactionCounts;
  topReactions: ReactionType[];
  userReaction: ReactionType | null;
}

export interface ReactedUser {
  id: number;
  name: string;
  avatar: string;
  reactionType: ReactionType;
  reactedAt: Date;
}

// ==================== SERVICE ====================

@Injectable()
export class ReactionsService {
  private readonly logger = new Logger(ReactionsService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Toggle reaction - Add or change reaction
   * If same type: remove reaction
   * If different type: change to new type
   * If no existing: add reaction
   */
  async toggleReaction(
    userId: number,
    contentType: string,
    contentId: number,
    type: ReactionType,
  ): Promise<{
    action: 'added' | 'changed' | 'removed';
    previousType?: ReactionType;
    currentType?: ReactionType;
    counts: ReactionCounts;
  }> {
    this.logger.log(
      `User ${userId} toggling ${type} on ${contentType}:${contentId}`,
    );

    try {
      // Check existing reaction
      const existing = await this.prisma.reaction.findUnique({
        where: {
          userId_contentType_contentId: {
            userId,
            contentType,
            contentId,
          },
        },
      });

      if (existing) {
        if (existing.type === type) {
          // Same type - remove reaction
          await this.prisma.reaction.delete({
            where: { id: existing.id },
          });

          const counts = await this.getReactionCounts(contentType, contentId);
          return {
            action: 'removed',
            previousType: type,
            counts,
          };
        } else {
          // Different type - update reaction
          await this.prisma.reaction.update({
            where: { id: existing.id },
            data: { type },
          });

          const counts = await this.getReactionCounts(contentType, contentId);
          return {
            action: 'changed',
            previousType: existing.type as ReactionType,
            currentType: type,
            counts,
          };
        }
      } else {
        // No existing - add new reaction
        await this.prisma.reaction.create({
          data: {
            userId,
            contentType,
            contentId,
            type,
          },
        });

        const counts = await this.getReactionCounts(contentType, contentId);
        return {
          action: 'added',
          currentType: type,
          counts,
        };
      }
    } catch (error) {
      this.logger.error(`Failed to toggle reaction: ${error.message}`);
      throw error;
    }
  }

  /**
   * Remove user's reaction from content
   */
  async removeReaction(
    userId: number,
    contentType: string,
    contentId: number,
  ): Promise<{ removed: boolean; counts: ReactionCounts }> {
    try {
      const existing = await this.prisma.reaction.findUnique({
        where: {
          userId_contentType_contentId: {
            userId,
            contentType,
            contentId,
          },
        },
      });

      if (existing) {
        await this.prisma.reaction.delete({
          where: { id: existing.id },
        });
      }

      const counts = await this.getReactionCounts(contentType, contentId);
      return { removed: !!existing, counts };
    } catch (error) {
      this.logger.error(`Failed to remove reaction: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get reaction counts for content
   */
  async getReactionCounts(
    contentType: string,
    contentId: number,
  ): Promise<ReactionCounts> {
    const reactions = await this.prisma.reaction.groupBy({
      by: ['type'],
      where: {
        contentType,
        contentId,
      },
      _count: {
        type: true,
      },
    });

    const counts: ReactionCounts = {
      total: 0,
      like: 0,
      love: 0,
      haha: 0,
      wow: 0,
      sad: 0,
      angry: 0,
    };

    for (const r of reactions) {
      const type = r.type as ReactionType;
      if (type in counts) {
        counts[type] = r._count.type;
        counts.total += r._count.type;
      }
    }

    return counts;
  }

  /**
   * Get full reaction summary for content
   */
  async getReactionSummary(
    contentType: string,
    contentId: number,
    userId?: number,
  ): Promise<ReactionSummary> {
    const counts = await this.getReactionCounts(contentType, contentId);

    // Get top 3 reactions by count
    const reactionTypes: ReactionType[] = [
      'like',
      'love',
      'haha',
      'wow',
      'sad',
      'angry',
    ];
    const topReactions = reactionTypes
      .filter((type) => counts[type] > 0)
      .sort((a, b) => counts[b] - counts[a])
      .slice(0, 3);

    // Get user's reaction if authenticated
    let userReaction: ReactionType | null = null;
    if (userId) {
      const existing = await this.prisma.reaction.findUnique({
        where: {
          userId_contentType_contentId: {
            userId,
            contentType,
            contentId,
          },
        },
      });
      if (existing) {
        userReaction = existing.type as ReactionType;
      }
    }

    return {
      counts,
      topReactions,
      userReaction,
    };
  }

  /**
   * Get users who reacted to content
   */
  async getReactedUsers(
    contentType: string,
    contentId: number,
    reactionType?: ReactionType,
    limit = 50,
    offset = 0,
  ): Promise<{ users: ReactedUser[]; total: number }> {
    const where: any = {
      contentType,
      contentId,
    };

    if (reactionType) {
      where.type = reactionType;
    }

    const [reactions, total] = await Promise.all([
      this.prisma.reaction.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      this.prisma.reaction.count({ where }),
    ]);

    const users: ReactedUser[] = reactions.map((r) => ({
      id: r.user.id,
      name: r.user.name || 'Anonymous',
      avatar: r.user.avatar || '',
      reactionType: r.type as ReactionType,
      reactedAt: r.createdAt,
    }));

    return { users, total };
  }

  /**
   * Batch get reactions for multiple contents
   * Useful for feed optimization
   */
  async batchGetReactions(
    contentType: string,
    contentIds: number[],
    userId?: number,
  ): Promise<Map<number, ReactionSummary>> {
    const result = new Map<number, ReactionSummary>();

    // Get all reactions for these contents
    const reactions = await this.prisma.reaction.findMany({
      where: {
        contentType,
        contentId: { in: contentIds },
      },
    });

    // Group by contentId
    for (const contentId of contentIds) {
      const contentReactions = reactions.filter(
        (r) => r.contentId === contentId,
      );

      const counts: ReactionCounts = {
        total: contentReactions.length,
        like: 0,
        love: 0,
        haha: 0,
        wow: 0,
        sad: 0,
        angry: 0,
      };

      for (const r of contentReactions) {
        const type = r.type as ReactionType;
        if (type in counts) {
          counts[type]++;
        }
      }

      // Top reactions
      const reactionTypes: ReactionType[] = [
        'like',
        'love',
        'haha',
        'wow',
        'sad',
        'angry',
      ];
      const topReactions = reactionTypes
        .filter((type) => counts[type] > 0)
        .sort((a, b) => counts[b] - counts[a])
        .slice(0, 3);

      // User reaction
      let userReaction: ReactionType | null = null;
      if (userId) {
        const userR = contentReactions.find((r) => r.userId === userId);
        if (userR) {
          userReaction = userR.type as ReactionType;
        }
      }

      result.set(contentId, {
        counts,
        topReactions,
        userReaction,
      });
    }

    return result;
  }

  /**
   * Get user's reactions history
   */
  async getUserReactions(
    userId: number,
    contentType?: string,
    limit = 50,
    offset = 0,
  ): Promise<ReactionResponse[]> {
    const where: any = { userId };
    if (contentType) {
      where.contentType = contentType;
    }

    const reactions = await this.prisma.reaction.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });

    return reactions.map((r) => ({
      id: r.id,
      userId: r.userId,
      contentType: r.contentType,
      contentId: r.contentId,
      type: r.type as ReactionType,
      createdAt: r.createdAt,
    }));
  }
}
