/**
 * Reactions WebSocket Gateway
 *
 * Real-time reactions broadcast:
 * - reaction:added - Khi ai đó thêm reaction
 * - reaction:changed - Khi ai đó đổi reaction
 * - reaction:removed - Khi ai đó xóa reaction
 * - rating:added - Khi ai đó đánh giá
 * - rating:updated - Khi ai đó cập nhật đánh giá
 *
 * Client subscription example:
 * socket.emit('subscribe:content', { contentType: 'video', contentId: 123 })
 * socket.on('reaction:added', (data) => { ... })
 *
 * @author AI Assistant
 * @date 27/01/2026
 */

import { Logger } from '@nestjs/common';
import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

// ==================== TYPES ====================

export interface ReactionEvent {
  action: 'added' | 'changed' | 'removed';
  contentType: string;
  contentId: number;
  userId: number;
  userName: string;
  userAvatar: string;
  reactionType?: string;
  previousType?: string;
  counts: {
    total: number;
    like: number;
    love: number;
    haha: number;
    wow: number;
    sad: number;
    angry: number;
  };
  timestamp: Date;
}

export interface RatingEvent {
  action: 'added' | 'updated' | 'removed';
  contentType: string;
  contentId: number;
  userId: number;
  userName: string;
  userAvatar: string;
  stars?: number;
  review?: string;
  summary: {
    averageRating: number;
    totalRatings: number;
  };
  timestamp: Date;
}

// ==================== GATEWAY ====================

@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/reactions',
})
export class ReactionsGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(ReactionsGateway.name);

  // Track subscribed clients: Map<roomName, Set<socketId>>
  private subscriptions: Map<string, Set<string>> = new Map();

  // Track client info: Map<socketId, { userId, userName, rooms }>
  private clientInfo: Map<
    string,
    { userId?: number; userName?: string; rooms: Set<string> }
  > = new Map();

  handleConnection(client: Socket) {
    this.logger.log(`Client connected to /reactions: ${client.id}`);

    // Extract user info from handshake
    const userId = client.handshake.query.userId as string;
    const userName = client.handshake.query.userName as string;

    this.clientInfo.set(client.id, {
      userId: userId ? parseInt(userId) : undefined,
      userName: userName || undefined,
      rooms: new Set(),
    });

    // Emit connection confirmation
    client.emit('connected', {
      socketId: client.id,
      timestamp: new Date(),
    });
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected from /reactions: ${client.id}`);

    // Clean up subscriptions
    const clientData = this.clientInfo.get(client.id);
    if (clientData) {
      clientData.rooms.forEach((room) => {
        const roomClients = this.subscriptions.get(room);
        if (roomClients) {
          roomClients.delete(client.id);
          if (roomClients.size === 0) {
            this.subscriptions.delete(room);
          }
        }
      });
    }

    this.clientInfo.delete(client.id);
  }

  /**
   * Subscribe to content reactions
   * Client sends: { contentType: 'video', contentId: 123 }
   */
  @SubscribeMessage('subscribe:content')
  handleSubscribe(
    @MessageBody() data: { contentType: string; contentId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `${data.contentType}:${data.contentId}`;
    client.join(room);

    // Track subscription
    if (!this.subscriptions.has(room)) {
      this.subscriptions.set(room, new Set());
    }
    this.subscriptions.get(room)!.add(client.id);

    // Track in client info
    const clientData = this.clientInfo.get(client.id);
    if (clientData) {
      clientData.rooms.add(room);
    }

    this.logger.log(`Client ${client.id} subscribed to ${room}`);
    return {
      success: true,
      room,
      subscribers: this.subscriptions.get(room)?.size || 0,
    };
  }

  /**
   * Unsubscribe from content reactions
   */
  @SubscribeMessage('unsubscribe:content')
  handleUnsubscribe(
    @MessageBody() data: { contentType: string; contentId: number },
    @ConnectedSocket() client: Socket,
  ) {
    const room = `${data.contentType}:${data.contentId}`;
    client.leave(room);

    // Remove from tracking
    const roomClients = this.subscriptions.get(room);
    if (roomClients) {
      roomClients.delete(client.id);
      if (roomClients.size === 0) {
        this.subscriptions.delete(room);
      }
    }

    const clientData = this.clientInfo.get(client.id);
    if (clientData) {
      clientData.rooms.delete(room);
    }

    this.logger.log(`Client ${client.id} unsubscribed from ${room}`);
    return { success: true, room };
  }

  /**
   * Subscribe to multiple contents at once (for feed)
   */
  @SubscribeMessage('subscribe:batch')
  handleBatchSubscribe(
    @MessageBody()
    data: { contents: Array<{ contentType: string; contentId: number }> },
    @ConnectedSocket() client: Socket,
  ) {
    const rooms: string[] = [];

    for (const content of data.contents) {
      const room = `${content.contentType}:${content.contentId}`;
      client.join(room);

      if (!this.subscriptions.has(room)) {
        this.subscriptions.set(room, new Set());
      }
      this.subscriptions.get(room)!.add(client.id);

      const clientData = this.clientInfo.get(client.id);
      if (clientData) {
        clientData.rooms.add(room);
      }

      rooms.push(room);
    }

    this.logger.log(
      `Client ${client.id} batch subscribed to ${rooms.length} rooms`,
    );
    return { success: true, rooms };
  }

  // ==================== BROADCAST METHODS ====================
  // These are called from ReactionsService/RatingsService

  /**
   * Broadcast reaction event to all subscribers
   */
  broadcastReactionEvent(event: ReactionEvent) {
    const room = `${event.contentType}:${event.contentId}`;
    const eventName = `reaction:${event.action}`;

    this.server.to(room).emit(eventName, event);
    this.logger.log(
      `Broadcasted ${eventName} to ${room} (${
        this.subscriptions.get(room)?.size || 0
      } subscribers)`,
    );
  }

  /**
   * Broadcast rating event to all subscribers
   */
  broadcastRatingEvent(event: RatingEvent) {
    const room = `${event.contentType}:${event.contentId}`;
    const eventName = `rating:${event.action}`;

    this.server.to(room).emit(eventName, event);
    this.logger.log(
      `Broadcasted ${eventName} to ${room} (${
        this.subscriptions.get(room)?.size || 0
      } subscribers)`,
    );
  }

  /**
   * Get active subscribers count for content
   */
  getSubscribersCount(contentType: string, contentId: number): number {
    const room = `${contentType}:${contentId}`;
    return this.subscriptions.get(room)?.size || 0;
  }

  /**
   * Get all active rooms
   */
  getActiveRooms(): string[] {
    return Array.from(this.subscriptions.keys());
  }

  /**
   * Ping handler for connection health check
   */
  @SubscribeMessage('ping')
  handlePing(@ConnectedSocket() client: Socket) {
    return { pong: true, timestamp: Date.now() };
  }
}
