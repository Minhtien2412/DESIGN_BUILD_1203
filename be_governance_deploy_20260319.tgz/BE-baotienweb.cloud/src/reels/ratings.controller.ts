/**
 * Ratings Controller
 *
 * API Endpoints cho đánh giá sao:
 * - POST /ratings - Create/Update rating
 * - DELETE /ratings/:contentType/:contentId - Delete rating
 * - GET /ratings/:contentType/:contentId - Get rating summary
 * - GET /ratings/:contentType/:contentId/list - Get all ratings
 * - POST /ratings/:id/helpful - Mark rating as helpful
 * - POST /ratings/batch - Batch get rating summaries
 *
 * @author AI Assistant
 * @date 27/01/2026
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Logger,
    Param,
    ParseIntPipe,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import { RatingsService } from './ratings.service';

// ==================== DTOs ====================

interface CreateRatingDto {
  contentType: string;
  contentId: number;
  stars: number; // 1-5
  review?: string;
  title?: string;
  images?: string[];
  verified?: boolean;
}

interface BatchGetSummariesDto {
  contentType: string;
  contentIds: number[];
}

// ==================== CONTROLLER ====================

@ApiTags('Ratings')
@Controller('ratings')
export class RatingsController {
  private readonly logger = new Logger(RatingsController.name);

  constructor(private readonly ratingsService: RatingsService) {}

  /**
   * Create or update rating
   * POST /api/v1/ratings
   */
  @Post()
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async createOrUpdateRating(@Body() dto: CreateRatingDto, @Req() req: any) {
    const userId = req.user.id;
    this.logger.log(
      `User ${userId} rating ${dto.contentType}:${dto.contentId} with ${dto.stars} stars`,
    );

    if (dto.stars < 1 || dto.stars > 5) {
      return {
        success: false,
        error: 'Stars must be between 1 and 5',
      };
    }

    const result = await this.ratingsService.upsertRating(
      userId,
      dto.contentType,
      dto.contentId,
      {
        stars: dto.stars,
        review: dto.review,
        title: dto.title,
        images: dto.images,
        verified: dto.verified,
      },
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Delete rating
   * DELETE /api/v1/ratings/:contentType/:contentId
   */
  @Delete(':contentType/:contentId')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async deleteRating(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    this.logger.log(
      `User ${userId} deleting rating for ${contentType}:${contentId}`,
    );

    const result = await this.ratingsService.deleteRating(
      userId,
      contentType,
      contentId,
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Get rating summary for content
   * GET /api/v1/ratings/:contentType/:contentId
   */
  @Get(':contentType/:contentId')
  @UseGuards(OptionalAuthGuard)
  async getRatingSummary(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Req() req: any,
  ) {
    const userId = req.user?.id || null;

    const summary = await this.ratingsService.getRatingSummary(
      contentType,
      contentId,
      userId,
    );

    return {
      success: true,
      ...summary,
    };
  }

  /**
   * Get all ratings for content
   * GET /api/v1/ratings/:contentType/:contentId/list
   */
  @Get(':contentType/:contentId/list')
  @UseGuards(OptionalAuthGuard)
  async getRatings(
    @Param('contentType') contentType: string,
    @Param('contentId', ParseIntPipe) contentId: number,
    @Query('stars') stars?: number,
    @Query('withReview') withReview?: string,
    @Query('sortBy')
    sortBy?: 'newest' | 'oldest' | 'helpful' | 'highest' | 'lowest',
    @Query('limit') limit = 20,
    @Query('offset') offset = 0,
  ) {
    const result = await this.ratingsService.getRatings(
      contentType,
      contentId,
      {
        stars: stars ? +stars : undefined,
        withReview: withReview === 'true',
        sortBy,
        limit: +limit,
        offset: +offset,
      },
    );

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Mark rating as helpful
   * POST /api/v1/ratings/:id/helpful
   */
  @Post(':id/helpful')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async markHelpful(
    @Param('id', ParseIntPipe) ratingId: number,
    @Req() req: any,
  ) {
    const userId = req.user.id;

    const result = await this.ratingsService.markHelpful(ratingId, userId);

    return {
      success: true,
      ...result,
    };
  }

  /**
   * Batch get rating summaries
   * POST /api/v1/ratings/batch
   */
  @Post('batch')
  @UseGuards(OptionalAuthGuard)
  async batchGetSummaries(@Body() dto: BatchGetSummariesDto, @Req() req: any) {
    const userId = req.user?.id || null;

    if (!dto.contentIds || dto.contentIds.length === 0) {
      return {
        success: false,
        error: 'contentIds is required',
      };
    }

    if (dto.contentIds.length > 100) {
      return {
        success: false,
        error: 'Maximum 100 content IDs allowed per batch',
      };
    }

    const summariesMap = await this.ratingsService.batchGetSummaries(
      dto.contentType,
      dto.contentIds,
      userId,
    );

    // Convert Map to object for JSON response
    const summaries: Record<number, any> = {};
    for (const [contentId, summary] of summariesMap) {
      summaries[contentId] = summary;
    }

    return {
      success: true,
      contentType: dto.contentType,
      summaries,
    };
  }

  /**
   * Get current user's ratings
   * GET /api/v1/ratings/me
   */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  async getMyRatings(
    @Req() req: any,
    @Query('contentType') contentType?: string,
    @Query('limit') limit = 50,
    @Query('offset') offset = 0,
  ) {
    const userId = req.user.id;

    const ratings = await this.ratingsService.getUserRatings(
      userId,
      contentType,
      +limit,
      +offset,
    );

    return {
      success: true,
      ratings,
    };
  }
}
