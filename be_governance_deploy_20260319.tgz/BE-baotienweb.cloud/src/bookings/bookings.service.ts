import {
    BadRequestException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import {
    BookingStatus,
    JobEventType,
    JobStatus,
    Prisma,
    WorkerOfferStatus,
} from '@prisma/client';
import type { Decimal } from '@prisma/client/runtime/library';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import {
    BookingQueryDto,
    CancelBookingDto,
    ConfirmWorkerDto,
    ConvertBookingToJobDto,
    CreateBookingAttachmentDto,
    CreateBookingDto,
} from './dto';

const bookingDetailInclude = {
  attachments: {
    orderBy: { createdAt: 'desc' as const },
  },
  offers: {
    orderBy: { createdAt: 'desc' as const },
  },
  job: true,
};

const jobDetailInclude = {
  booking: true,
  events: {
    orderBy: { createdAt: 'desc' as const },
  },
  costItems: {
    orderBy: { createdAt: 'asc' as const },
  },
  review: true,
  warranties: {
    include: { policy: true },
    orderBy: { createdAt: 'desc' as const },
  },
};

@Injectable()
export class BookingsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async createBooking(userId: number, dto: CreateBookingDto) {
    if (dto.addressId) {
      await this.ensureAddressOwnership(dto.addressId, userId);
    }

    const booking = await this.prisma.booking.create({
      data: {
        bookingCode: this.buildCode('BKG'),
        customerId: userId,
        addressId: dto.addressId,
        serviceCategory: dto.serviceCategory,
        serviceCategoryLabel: dto.serviceCategoryLabel,
        title: dto.title,
        description: dto.description,
        status: BookingStatus.SUBMITTED,
        priority: dto.priority ?? 'NORMAL',
        requestedAt: new Date(),
        scheduledFor: dto.scheduledFor ? new Date(dto.scheduledFor) : undefined,
        estimatedBudget: this.toDecimal(dto.estimatedBudget),
        estimatedDurationMinutes: dto.estimatedDurationMinutes,
        aiSummary: dto.aiSummary,
        aiMetadata: this.toJsonValue(dto.aiMetadata),
        locationText: dto.locationText,
        latitude: dto.latitude,
        longitude: dto.longitude,
        customerPhone: dto.customerPhone,
        preferredContactMethod: dto.preferredContactMethod,
        notes: dto.notes,
      },
      include: bookingDetailInclude,
    });

    return booking;
  }

  async getMyBookings(userId: number, query: BookingQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const where: Prisma.BookingWhereInput = {
      customerId: userId,
      ...(query.status ? { status: query.status } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.booking.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: bookingDetailInclude,
      }),
      this.prisma.booking.count({ where }),
    ]);

    return {
      data,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getBookingDetail(id: number, userId: number) {
    return this.getOwnedBookingOrThrow(id, userId);
  }

  async addAttachment(
    id: number,
    userId: number,
    dto: CreateBookingAttachmentDto,
  ) {
    await this.getOwnedBookingOrThrow(id, userId);

    const file = await this.prisma.managedFile.findUnique({
      where: { id: dto.managedFileId },
      select: { id: true },
    });

    if (!file) {
      throw new NotFoundException(
        `Managed file ${dto.managedFileId} was not found`,
      );
    }

    await this.prisma.bookingAttachment.create({
      data: {
        bookingId: id,
        managedFileId: dto.managedFileId,
        label: dto.label,
        note: dto.note,
        createdById: userId,
      },
    });

    return this.getOwnedBookingOrThrow(id, userId);
  }

  async requestMatching(id: number, userId: number) {
    const booking = await this.getOwnedBookingOrThrow(id, userId);
    const blockedStatuses: BookingStatus[] = [
      BookingStatus.CANCELLED,
      BookingStatus.EXPIRED,
    ];

    if (blockedStatuses.includes(booking.status)) {
      throw new BadRequestException(
        'Booking đã bị hủy hoặc hết hạn nên không thể tiếp tục matching.',
      );
    }

    if (booking.job) {
      throw new BadRequestException(
        'Booking đã được chuyển thành job, vui lòng thao tác trên job.',
      );
    }

    const candidates = await this.findCandidateWorkers(booking);
    const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000);

    await Promise.all(
      candidates.map((worker) => {
        const price = this.estimateOfferPrice(booking, worker);
        return this.prisma.workerOffer.upsert({
          where: {
            bookingId_workerId: {
              bookingId: booking.id,
              workerId: worker.id,
            },
          },
          update: {
            status: WorkerOfferStatus.PENDING,
            price: this.toDecimal(price),
            estimatedArrivalMinutes: this.estimateArrivalMinutes(worker),
            estimatedDurationMinutes:
              booking.estimatedDurationMinutes ??
              this.estimateDurationMinutes(worker),
            message: this.buildOfferMessage(worker),
            metadata: {
              workerName: worker.name,
              rating: worker.rating,
              completedJobs: worker.completedJobs,
              skills: worker.specialties,
            },
            expiresAt,
            respondedAt: null,
          },
          create: {
            bookingId: booking.id,
            workerId: worker.id,
            status: WorkerOfferStatus.PENDING,
            price: this.toDecimal(price),
            estimatedArrivalMinutes: this.estimateArrivalMinutes(worker),
            estimatedDurationMinutes:
              booking.estimatedDurationMinutes ??
              this.estimateDurationMinutes(worker),
            message: this.buildOfferMessage(worker),
            metadata: {
              workerName: worker.name,
              rating: worker.rating,
              completedJobs: worker.completedJobs,
              skills: worker.specialties,
            },
            expiresAt,
          },
        });
      }),
    );

    await this.prisma.booking.update({
      where: { id: booking.id },
      data: {
        status:
          candidates.length > 0 ? BookingStatus.QUOTED : BookingStatus.MATCHING,
        matchedAt: candidates.length > 0 ? new Date() : undefined,
      },
    });

    if (candidates.length > 0) {
      await this.notifySafely(
        userId,
        'Đã tìm thấy thợ phù hợp',
        `Booking ${booking.bookingCode} hiện có ${candidates.length} đề xuất thợ để bạn chọn.`,
        {
          bookingId: booking.id,
          bookingCode: booking.bookingCode,
          candidateCount: candidates.length,
        },
      );
    }

    return this.getOwnedBookingOrThrow(id, userId);
  }

  async confirmWorker(id: number, userId: number, dto: ConfirmWorkerDto) {
    const booking = await this.getOwnedBookingOrThrow(id, userId);

    if (
      booking.status === BookingStatus.CANCELLED ||
      booking.status === BookingStatus.EXPIRED
    ) {
      throw new BadRequestException(
        'Booking không còn hợp lệ để xác nhận thợ.',
      );
    }

    if (booking.job) {
      throw new BadRequestException('Booking này đã có job vận hành.');
    }

    const selectedOffer = await this.prisma.workerOffer.findFirst({
      where: {
        id: dto.offerId,
        bookingId: booking.id,
      },
    });

    if (!selectedOffer) {
      throw new NotFoundException(
        'Không tìm thấy offer tương ứng với booking này.',
      );
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.workerOffer.update({
        where: { id: selectedOffer.id },
        data: {
          status: WorkerOfferStatus.SELECTED,
          respondedAt: new Date(),
        },
      });

      await tx.workerOffer.updateMany({
        where: {
          bookingId: booking.id,
          id: { not: selectedOffer.id },
          status: {
            in: [WorkerOfferStatus.PENDING, WorkerOfferStatus.ACCEPTED],
          },
        },
        data: {
          status: WorkerOfferStatus.DECLINED,
          respondedAt: new Date(),
        },
      });

      await tx.booking.update({
        where: { id: booking.id },
        data: {
          status: BookingStatus.WORKER_CONFIRMED,
          selectedWorkerId: selectedOffer.workerId,
          selectedOfferId: selectedOffer.id,
          confirmedAt: new Date(),
        },
      });
    });

    const worker = await this.prisma.worker.findUnique({
      where: { id: selectedOffer.workerId },
      select: { id: true, userId: true, name: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Bạn vừa được chọn cho một booking mới',
        `Khách hàng đã chọn bạn cho booking ${booking.bookingCode}.`,
        {
          bookingId: booking.id,
          bookingCode: booking.bookingCode,
          workerId: worker.id,
        },
      );
    }

    return this.getOwnedBookingOrThrow(id, userId);
  }

  async convertToJob(id: number, userId: number, dto: ConvertBookingToJobDto) {
    const booking = await this.getOwnedBookingOrThrow(id, userId);

    if (!booking.selectedWorkerId) {
      throw new BadRequestException(
        'Booking chưa có worker được xác nhận nên chưa thể chuyển thành job.',
      );
    }

    if (
      booking.status === BookingStatus.CANCELLED ||
      booking.status === BookingStatus.EXPIRED
    ) {
      throw new BadRequestException('Booking không thể chuyển sang job.');
    }

    if (booking.job) {
      return this.prisma.job.findUnique({
        where: { id: booking.job.id },
        include: jobDetailInclude,
      });
    }

    const job = await this.prisma.$transaction(async (tx) => {
      const created = await tx.job.create({
        data: {
          jobCode: this.buildCode('JOB'),
          bookingId: booking.id,
          customerId: booking.customerId,
          workerId: booking.selectedWorkerId!,
          status: JobStatus.ASSIGNED,
          title: booking.title,
          description: booking.description,
          scheduledFor: dto.scheduledFor
            ? new Date(dto.scheduledFor)
            : booking.scheduledFor,
          paymentMethod: dto.paymentMethod,
          notes: dto.notes ?? booking.notes,
        },
      });

      await tx.jobEvent.createMany({
        data: [
          {
            jobId: created.id,
            type: JobEventType.CREATED,
            actorUserId: userId,
            message: 'Job được tạo từ booking đã xác nhận.',
            metadata: {
              bookingId: booking.id,
              bookingCode: booking.bookingCode,
            },
          },
          {
            jobId: created.id,
            type: JobEventType.WORKER_ASSIGNED,
            actorUserId: userId,
            actorWorkerId: booking.selectedWorkerId,
            message: 'Worker đã được gán cho job.',
            metadata: {
              bookingId: booking.id,
              selectedOfferId: booking.selectedOfferId,
              selectedWorkerId: booking.selectedWorkerId,
            },
          },
        ],
      });

      await tx.booking.update({
        where: { id: booking.id },
        data: {
          status: BookingStatus.JOB_CREATED,
        },
      });

      return tx.job.findUniqueOrThrow({
        where: { id: created.id },
        include: jobDetailInclude,
      });
    });

    await this.notifySafely(
      userId,
      'Booking đã chuyển thành job',
      `Job ${job.jobCode} đã được tạo thành công từ booking ${booking.bookingCode}.`,
      {
        bookingId: booking.id,
        jobId: job.id,
        jobCode: job.jobCode,
      },
    );

    const worker = await this.prisma.worker.findUnique({
      where: { id: job.workerId },
      select: { userId: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Bạn có job mới',
        `Job ${job.jobCode} đã được tạo và đang chờ bạn xử lý.`,
        {
          bookingId: booking.id,
          jobId: job.id,
          jobCode: job.jobCode,
        },
      );
    }

    return job;
  }

  async cancelBooking(id: number, userId: number, dto: CancelBookingDto) {
    const booking = await this.getOwnedBookingOrThrow(id, userId);

    if (booking.job) {
      throw new BadRequestException(
        'Booking này đã có job. Hãy dùng flow hủy trên job để bảo toàn lịch sử vận hành.',
      );
    }

    if (booking.status === BookingStatus.CANCELLED) {
      return booking;
    }

    await this.prisma.booking.update({
      where: { id: booking.id },
      data: {
        status: BookingStatus.CANCELLED,
        cancellationReason: dto.reason,
      },
    });

    return this.getOwnedBookingOrThrow(id, userId);
  }

  private async getOwnedBookingOrThrow(id: number, userId: number) {
    const booking = await this.prisma.booking.findFirst({
      where: {
        id,
        customerId: userId,
      },
      include: bookingDetailInclude,
    });

    if (!booking) {
      throw new NotFoundException(`Booking with ID ${id} not found`);
    }

    return booking;
  }

  private async ensureAddressOwnership(addressId: number, userId: number) {
    const address = await this.prisma.userAddress.findFirst({
      where: { id: addressId, userId },
      select: { id: true },
    });

    if (!address) {
      throw new BadRequestException('Address không thuộc về user hiện tại.');
    }
  }

  private async findCandidateWorkers(booking: {
    serviceCategory: string;
    serviceCategoryLabel?: string | null;
  }) {
    const skillTokens = [booking.serviceCategory, booking.serviceCategoryLabel]
      .filter((value): value is string => Boolean(value))
      .slice(0, 3);

    if (skillTokens.length > 0) {
      const primary = await this.prisma.worker.findMany({
        where: {
          isVerified: true,
          OR: skillTokens.map((skill) => ({
            specialties: { has: skill },
          })),
        },
        orderBy: [
          { isFeatured: 'desc' },
          { rating: 'desc' },
          { completedJobs: 'desc' },
        ],
        take: 5,
      });

      if (primary.length > 0) {
        return primary;
      }
    }

    const verified = await this.prisma.worker.findMany({
      where: { isVerified: true },
      orderBy: [
        { isFeatured: 'desc' },
        { rating: 'desc' },
        { completedJobs: 'desc' },
      ],
      take: 5,
    });

    if (verified.length > 0) {
      return verified;
    }

    return this.prisma.worker.findMany({
      orderBy: [{ rating: 'desc' }, { completedJobs: 'desc' }],
      take: 5,
    });
  }

  private estimateOfferPrice(
    booking: { estimatedBudget: Prisma.Decimal | null },
    worker: {
      hourlyRate: Prisma.Decimal | null;
      dailyRate: Prisma.Decimal | null;
    },
  ) {
    if (booking.estimatedBudget) {
      return Number(booking.estimatedBudget);
    }

    if (worker.hourlyRate) {
      return Number(worker.hourlyRate) * 2;
    }

    if (worker.dailyRate) {
      return Number(worker.dailyRate);
    }

    return null;
  }

  private estimateArrivalMinutes(worker: {
    isFeatured: boolean | null;
    rating: Decimal | null;
  }) {
    if (worker.isFeatured) {
      return 20;
    }

    if (Number(worker.rating) >= 4.8) {
      return 30;
    }

    return 45;
  }

  private estimateDurationMinutes(worker: { experienceYears: number | null }) {
    if ((worker.experienceYears ?? 0) >= 8) {
      return 90;
    }

    if ((worker.experienceYears ?? 0) >= 3) {
      return 120;
    }

    return 150;
  }

  private buildOfferMessage(worker: {
    name: string;
    rating: Decimal | null;
    experienceYears: number | null;
  }) {
    return `${worker.name} có rating ${Number(worker.rating).toFixed(1)} và ${worker.experienceYears ?? 0} năm kinh nghiệm.`;
  }

  private async notifySafely(
    userId: number,
    title: string,
    message: string,
    data?: Record<string, unknown>,
  ) {
    try {
      await this.notificationsService.create({
        userId,
        title,
        message,
        type: 'SYSTEM',
        priority: 'MEDIUM',
        data,
      });
    } catch (error) {
      console.error('[BookingsService] Failed to send notification', error);
    }
  }

  private toDecimal(value?: number | null) {
    if (value === undefined || value === null) {
      return undefined;
    }

    return new Prisma.Decimal(value);
  }

  private toJsonValue(value?: Record<string, unknown>) {
    if (!value) {
      return undefined;
    }

    return value as Prisma.InputJsonValue;
  }

  private buildCode(prefix: string) {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.random().toString(36).slice(2, 8).toUpperCase();
    return `${prefix}-${date}-${random}`;
  }
}
