import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsDateString,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MaxLength,
    Min,
    MinLength,
} from 'class-validator';

export enum BookingStatusDto {
  SUBMITTED = 'SUBMITTED',
  MATCHING = 'MATCHING',
  QUOTED = 'QUOTED',
  WORKER_CONFIRMED = 'WORKER_CONFIRMED',
  JOB_CREATED = 'JOB_CREATED',
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
}

export class CreateBookingDto {
  @ApiProperty({
    description: 'Mã loại dịch vụ nội bộ, ví dụ: tho_dien, tho_nuoc',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(120)
  serviceCategory: string;

  @ApiPropertyOptional({ description: 'Nhãn hiển thị loại dịch vụ' })
  @IsOptional()
  @IsString()
  @MaxLength(160)
  serviceCategoryLabel?: string;

  @ApiProperty({ description: 'Tiêu đề ngắn gọn cho nhu cầu dịch vụ' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  title: string;

  @ApiProperty({ description: 'Mô tả chi tiết nhu cầu của khách hàng' })
  @IsString()
  @IsNotEmpty()
  @MinLength(10)
  description: string;

  @ApiPropertyOptional({ description: 'ID địa chỉ đã lưu của người dùng' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  addressId?: number;

  @ApiPropertyOptional({ description: 'Địa chỉ dạng text để hiển thị nhanh' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  locationText?: string;

  @ApiPropertyOptional({ description: 'Vĩ độ' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  latitude?: number;

  @ApiPropertyOptional({ description: 'Kinh độ' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  longitude?: number;

  @ApiPropertyOptional({
    description: 'Thời gian mong muốn thực hiện (ISO string)',
  })
  @IsOptional()
  @IsDateString()
  scheduledFor?: string;

  @ApiPropertyOptional({ description: 'Ngân sách dự kiến' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  estimatedBudget?: number;

  @ApiPropertyOptional({ description: 'Ước lượng thời lượng công việc (phút)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  estimatedDurationMinutes?: number;

  @ApiPropertyOptional({ description: 'Số điện thoại liên hệ ưu tiên' })
  @IsOptional()
  @IsString()
  @MaxLength(40)
  customerPhone?: string;

  @ApiPropertyOptional({
    description: 'Phương thức liên hệ ưu tiên, ví dụ: phone, chat, zalo',
  })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  preferredContactMethod?: string;

  @ApiPropertyOptional({
    description: 'Độ ưu tiên nghiệp vụ',
    default: 'NORMAL',
  })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  priority?: string;

  @ApiPropertyOptional({ description: 'Tóm tắt do AI phân tích' })
  @IsOptional()
  @IsString()
  aiSummary?: string;

  @ApiPropertyOptional({
    description: 'Metadata AI / phân tích hình ảnh / intent extraction',
  })
  @IsOptional()
  @IsObject()
  aiMetadata?: Record<string, unknown>;

  @ApiPropertyOptional({ description: 'Ghi chú thêm cho hệ thống hoặc thợ' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class BookingQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ enum: BookingStatusDto })
  @IsOptional()
  @IsEnum(BookingStatusDto)
  status?: BookingStatusDto;
}

export class CreateBookingAttachmentDto {
  @ApiProperty({
    description: 'ManagedFile ID đại diện cho ảnh/video/tài liệu đính kèm',
  })
  @IsString()
  @IsNotEmpty()
  managedFileId: string;

  @ApiPropertyOptional({ description: 'Nhãn ngắn gọn cho file đính kèm' })
  @IsOptional()
  @IsString()
  @MaxLength(120)
  label?: string;

  @ApiPropertyOptional({ description: 'Ghi chú cho file đính kèm' })
  @IsOptional()
  @IsString()
  note?: string;
}

export class ConfirmWorkerDto {
  @ApiProperty({ description: 'ID offer được khách hàng chọn' })
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  offerId: number;
}

export class ConvertBookingToJobDto {
  @ApiPropertyOptional({ description: 'Lịch hẹn cụ thể khi tạo job' })
  @IsOptional()
  @IsDateString()
  scheduledFor?: string;

  @ApiPropertyOptional({ description: 'Phương thức thanh toán dự kiến' })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  paymentMethod?: string;

  @ApiPropertyOptional({ description: 'Ghi chú vận hành cho job' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CancelBookingDto {
  @ApiPropertyOptional({ description: 'Lý do hủy booking' })
  @IsOptional()
  @IsString()
  reason?: string;
}
