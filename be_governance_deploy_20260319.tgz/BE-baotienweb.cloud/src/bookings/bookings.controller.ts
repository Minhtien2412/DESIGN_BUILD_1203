import {
    Body,
    Controller,
    Get,
    Param,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import { BookingsService } from './bookings.service';
import {
    BookingQueryDto,
    CancelBookingDto,
    ConfirmWorkerDto,
    ConvertBookingToJobDto,
    CreateBookingAttachmentDto,
    CreateBookingDto,
} from './dto';

@ApiTags('Bookings - Marketplace lifecycle')
@Controller('bookings')
@UseGuards(ApiKeyGuard)
export class BookingsController {
  constructor(private readonly bookingsService: BookingsService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo booking nhu cầu dịch vụ mới' })
  @ApiResponse({ status: 201, description: 'Booking đã được tạo' })
  async createBooking(@Body() dto: CreateBookingDto, @CurrentUser() user: any) {
    return this.bookingsService.createBooking(user.id, dto);
  }

  @Get('mine')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách booking của tôi' })
  async getMyBookings(
    @Query() query: BookingQueryDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.getMyBookings(user.id, query);
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy chi tiết booking' })
  async getBookingDetail(@Param('id') id: string, @CurrentUser() user: any) {
    return this.bookingsService.getBookingDetail(parseInt(id, 10), user.id);
  }

  @Post(':id/attachments')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Gắn file đính kèm vào booking' })
  async addAttachment(
    @Param('id') id: string,
    @Body() dto: CreateBookingAttachmentDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.addAttachment(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/match')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Phân tích và tạo danh sách worker offer cho booking',
  })
  async requestMatching(@Param('id') id: string, @CurrentUser() user: any) {
    return this.bookingsService.requestMatching(parseInt(id, 10), user.id);
  }

  @Post(':id/confirm-worker')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khách hàng xác nhận worker/offer đã chọn' })
  async confirmWorker(
    @Param('id') id: string,
    @Body() dto: ConfirmWorkerDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.confirmWorker(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/convert-to-job')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Chuyển booking đã xác nhận worker sang job vận hành',
  })
  async convertToJob(
    @Param('id') id: string,
    @Body() dto: ConvertBookingToJobDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.convertToJob(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy booking trước khi chuyển sang job' })
  async cancelBooking(
    @Param('id') id: string,
    @Body() dto: CancelBookingDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.cancelBooking(parseInt(id, 10), user.id, dto);
  }
}
