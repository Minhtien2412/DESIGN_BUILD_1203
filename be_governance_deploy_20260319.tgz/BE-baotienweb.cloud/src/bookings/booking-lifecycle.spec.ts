/**
 * Integration-style test for the full marketplace lifecycle:
 *   create booking → match → confirm worker → convert to job
 *   → en-route → arrived → start → complete → confirm → review
 *   → create warranty → claim → resolve
 *
 * Uses mocked PrismaService to validate service-layer transitions
 * without requiring a live database.
 */
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { Prisma } from '@prisma/client';
import { JobsService } from '../jobs/jobs.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { WarrantiesService } from '../warranties/warranties.service';
import { BookingsService } from './bookings.service';

// ---------------------------------------------------------------------------
// Test-data seed values
// ---------------------------------------------------------------------------
const CUSTOMER_ID = 1;
const WORKER_ID = 10;
const WORKER_USER_ID = 2;
const OFFER_ID = 100;
const BOOKING_ID = 50;
const JOB_ID = 200;
const WARRANTY_ID = 300;
const POLICY_ID = 400;
const NOW = new Date('2026-03-12T08:00:00Z');

const makeBooking = (overrides: Record<string, unknown> = {}) => ({
  id: BOOKING_ID,
  bookingCode: 'BKG-20260312-ABC123',
  customerId: CUSTOMER_ID,
  serviceCategory: 'tho_dien',
  serviceCategoryLabel: 'Thợ điện',
  title: 'Sửa điện phòng khách',
  description: 'Ổ cắm bị chập, cần kiểm tra và sửa',
  status: 'SUBMITTED',
  priority: 'NORMAL',
  requestedAt: NOW,
  scheduledFor: null,
  estimatedBudget: null,
  estimatedDurationMinutes: null,
  aiSummary: null,
  aiMetadata: null,
  locationText: null,
  latitude: null,
  longitude: null,
  customerPhone: null,
  preferredContactMethod: null,
  notes: null,
  cancellationReason: null,
  matchedAt: null,
  confirmedAt: null,
  expiredAt: null,
  selectedWorkerId: null,
  selectedOfferId: null,
  addressId: null,
  createdAt: NOW,
  updatedAt: NOW,
  attachments: [],
  offers: [],
  job: null,
  ...overrides,
});

const makeWorker = (overrides: Record<string, unknown> = {}) => ({
  id: WORKER_ID,
  userId: WORKER_USER_ID,
  name: 'Nguyễn Văn A',
  phone: '0901234567',
  email: null,
  avatar: null,
  workerType: 'tho_dien',
  skills: ['tho_dien'],
  experience: 5,
  rating: 4.8,
  reviewCount: 20,
  completedJobs: 50,
  isVerified: true,
  isFeatured: false,
  hourlyRate: new Prisma.Decimal(100000),
  dailyRate: new Prisma.Decimal(800000),
  ...overrides,
});

const makeOffer = (overrides: Record<string, unknown> = {}) => ({
  id: OFFER_ID,
  bookingId: BOOKING_ID,
  workerId: WORKER_ID,
  status: 'PENDING',
  price: new Prisma.Decimal(200000),
  estimatedArrivalMinutes: 30,
  estimatedDurationMinutes: 120,
  message: 'Nguyễn Văn A có rating 4.8 và 5 năm kinh nghiệm.',
  metadata: {
    workerName: 'Nguyễn Văn A',
    rating: 4.8,
    completedJobs: 50,
    skills: ['tho_dien'],
  },
  respondedAt: null,
  expiresAt: new Date(NOW.getTime() + 7200000),
  createdAt: NOW,
  updatedAt: NOW,
  ...overrides,
});

const makeJob = (overrides: Record<string, unknown> = {}) => ({
  id: JOB_ID,
  jobCode: 'JOB-20260312-XYZ789',
  bookingId: BOOKING_ID,
  customerId: CUSTOMER_ID,
  workerId: WORKER_ID,
  status: 'ASSIGNED',
  title: 'Sửa điện phòng khách',
  description: 'Ổ cắm bị chập, cần kiểm tra và sửa',
  scheduledFor: null,
  startedAt: null,
  arrivedAt: null,
  completedAt: null,
  cancelledAt: null,
  cancellationReason: null,
  finalAmount: null,
  paymentMethod: null,
  paymentStatus: 'UNPAID',
  customerConfirmedAt: null,
  warrantyUntil: null,
  notes: null,
  createdAt: NOW,
  updatedAt: NOW,
  booking: makeBooking({
    status: 'JOB_CREATED',
    selectedWorkerId: WORKER_ID,
    selectedOfferId: OFFER_ID,
  }),
  events: [],
  costItems: [],
  review: null,
  warranties: [],
  ...overrides,
});

const makeWarranty = (overrides: Record<string, unknown> = {}) => ({
  id: WARRANTY_ID,
  code: 'WAR-20260312-DEF456',
  jobId: JOB_ID,
  customerId: CUSTOMER_ID,
  workerId: WORKER_ID,
  policyId: POLICY_ID,
  status: 'ACTIVE',
  title: 'Bảo hành cho Sửa điện phòng khách',
  description: null,
  claimReason: null,
  resolutionNotes: null,
  expiresAt: new Date(NOW.getTime() + 30 * 86400000),
  claimedAt: null,
  resolvedAt: null,
  createdAt: NOW,
  updatedAt: NOW,
  policy: {
    id: POLICY_ID,
    name: 'Bảo hành điện',
    coverageDays: 30,
    isActive: true,
  },
  job: makeJob({ status: 'COMPLETED', customerConfirmedAt: NOW }),
  ...overrides,
});

// ---------------------------------------------------------------------------
// Mock factories
// ---------------------------------------------------------------------------
function createMockPrisma() {
  const transactionFn = jest
    .fn()
    .mockImplementation(async (cb: (tx: any) => Promise<any>) => {
      return cb(mockPrisma);
    });

  const mockPrisma: Record<string, any> = {
    $transaction: transactionFn,
    booking: {
      create: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      count: jest.fn(),
    },
    bookingAttachment: {
      create: jest.fn(),
    },
    workerOffer: {
      upsert: jest.fn(),
      findFirst: jest.fn(),
      update: jest.fn(),
      updateMany: jest.fn(),
    },
    worker: {
      findMany: jest.fn().mockResolvedValue([]),
      findUnique: jest.fn(),
      update: jest.fn(),
    },
    userAddress: {
      findFirst: jest.fn(),
    },
    managedFile: {
      findUnique: jest.fn(),
    },
    job: {
      create: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      findUniqueOrThrow: jest.fn(),
      update: jest.fn(),
      count: jest.fn(),
    },
    jobEvent: {
      create: jest.fn(),
      createMany: jest.fn(),
    },
    jobCostItem: {
      create: jest.fn(),
    },
    jobReview: {
      create: jest.fn(),
      findUnique: jest.fn(),
      aggregate: jest.fn(),
    },
    warrantyPolicy: {
      create: jest.fn(),
      findMany: jest.fn(),
      findFirst: jest.fn(),
    },
    warrantyCase: {
      create: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      findUniqueOrThrow: jest.fn(),
      update: jest.fn(),
      count: jest.fn(),
    },
  };

  return mockPrisma;
}

function createMockNotifications() {
  return {
    create: jest.fn().mockResolvedValue(undefined),
  };
}

// ---------------------------------------------------------------------------
// Test suite
// ---------------------------------------------------------------------------
describe('Booking → Job → Warranty lifecycle', () => {
  let bookingsService: BookingsService;
  let jobsService: JobsService;
  let warrantiesService: WarrantiesService;
  let prisma: ReturnType<typeof createMockPrisma>;
  let notifications: ReturnType<typeof createMockNotifications>;

  beforeEach(async () => {
    prisma = createMockPrisma();
    notifications = createMockNotifications();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BookingsService,
        JobsService,
        WarrantiesService,
        { provide: PrismaService, useValue: prisma },
        { provide: NotificationsService, useValue: notifications },
      ],
    }).compile();

    bookingsService = module.get(BookingsService);
    jobsService = module.get(JobsService);
    warrantiesService = module.get(WarrantiesService);
  });

  // --------------------------------------------------------
  // Phase 1: Booking creation
  // --------------------------------------------------------
  describe('Phase 1 – Create booking', () => {
    it('should create a booking with SUBMITTED status', async () => {
      const created = makeBooking();
      prisma.booking.create.mockResolvedValue(created);

      const result = await bookingsService.createBooking(CUSTOMER_ID, {
        serviceCategory: 'tho_dien',
        serviceCategoryLabel: 'Thợ điện',
        title: 'Sửa điện phòng khách',
        description: 'Ổ cắm bị chập, cần kiểm tra và sửa',
      });

      expect(result.status).toBe('SUBMITTED');
      expect(result.customerId).toBe(CUSTOMER_ID);
      expect(prisma.booking.create).toHaveBeenCalledTimes(1);
    });

    it('should validate address ownership when addressId is provided', async () => {
      prisma.userAddress.findFirst.mockResolvedValue(null);

      await expect(
        bookingsService.createBooking(CUSTOMER_ID, {
          serviceCategory: 'tho_dien',
          title: 'Test',
          description: 'Description long enough for validation',
          addressId: 999,
        }),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Phase 2: Matching workers
  // --------------------------------------------------------
  describe('Phase 2 – Match workers', () => {
    it('should find candidate workers and create offers', async () => {
      const booking = makeBooking();
      prisma.booking.findFirst.mockResolvedValue(booking);
      prisma.worker.findMany.mockResolvedValue([makeWorker()]);
      prisma.workerOffer.upsert.mockResolvedValue(makeOffer());

      const bookingAfterMatch = makeBooking({
        status: 'QUOTED',
        matchedAt: NOW,
        offers: [makeOffer()],
      });
      prisma.booking.update.mockResolvedValue(bookingAfterMatch);
      // Return the updated booking on the second findFirst call (re-fetch)
      prisma.booking.findFirst
        .mockResolvedValueOnce(booking)
        .mockResolvedValueOnce(bookingAfterMatch);

      const result = await bookingsService.requestMatching(
        BOOKING_ID,
        CUSTOMER_ID,
      );

      expect(prisma.workerOffer.upsert).toHaveBeenCalled();
      expect(prisma.booking.update).toHaveBeenCalled();
      expect(result.status).toBe('QUOTED');
    });

    it('should reject matching on cancelled bookings', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'CANCELLED' }),
      );

      await expect(
        bookingsService.requestMatching(BOOKING_ID, CUSTOMER_ID),
      ).rejects.toThrow(BadRequestException);
    });

    it('should reject matching when booking already has a job', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'JOB_CREATED', job: makeJob() }),
      );

      await expect(
        bookingsService.requestMatching(BOOKING_ID, CUSTOMER_ID),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Phase 3: Confirm worker
  // --------------------------------------------------------
  describe('Phase 3 – Confirm worker', () => {
    it('should select an offer and update booking to WORKER_CONFIRMED', async () => {
      const quotedBooking = makeBooking({
        status: 'QUOTED',
        offers: [makeOffer()],
      });
      prisma.booking.findFirst
        .mockResolvedValueOnce(quotedBooking)
        .mockResolvedValueOnce(
          makeBooking({
            status: 'WORKER_CONFIRMED',
            selectedWorkerId: WORKER_ID,
            selectedOfferId: OFFER_ID,
          }),
        );
      prisma.workerOffer.findFirst.mockResolvedValue(makeOffer());
      prisma.workerOffer.update.mockResolvedValue(
        makeOffer({ status: 'SELECTED' }),
      );
      prisma.workerOffer.updateMany.mockResolvedValue({ count: 0 });
      prisma.booking.update.mockResolvedValue(
        makeBooking({ status: 'WORKER_CONFIRMED' }),
      );
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await bookingsService.confirmWorker(
        BOOKING_ID,
        CUSTOMER_ID,
        {
          offerId: OFFER_ID,
        },
      );

      expect(result.status).toBe('WORKER_CONFIRMED');
    });

    it('should reject confirm on cancelled booking', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'CANCELLED' }),
      );

      await expect(
        bookingsService.confirmWorker(BOOKING_ID, CUSTOMER_ID, {
          offerId: OFFER_ID,
        }),
      ).rejects.toThrow(BadRequestException);
    });

    it('should reject when offer does not belong to booking', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'QUOTED' }),
      );
      prisma.workerOffer.findFirst.mockResolvedValue(null);

      await expect(
        bookingsService.confirmWorker(BOOKING_ID, CUSTOMER_ID, {
          offerId: 9999,
        }),
      ).rejects.toThrow(NotFoundException);
    });
  });

  // --------------------------------------------------------
  // Phase 4: Convert to job
  // --------------------------------------------------------
  describe('Phase 4 – Convert booking to job', () => {
    it('should create a job from confirmed booking', async () => {
      const confirmed = makeBooking({
        status: 'WORKER_CONFIRMED',
        selectedWorkerId: WORKER_ID,
        selectedOfferId: OFFER_ID,
      });
      prisma.booking.findFirst
        .mockResolvedValueOnce(confirmed)
        .mockResolvedValueOnce(confirmed);

      const job = makeJob();
      prisma.job.create.mockResolvedValue(job);
      prisma.jobEvent.createMany.mockResolvedValue({ count: 2 });
      prisma.booking.update.mockResolvedValue(
        makeBooking({ status: 'JOB_CREATED' }),
      );
      prisma.job.findUniqueOrThrow.mockResolvedValue(job);
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await bookingsService.convertToJob(
        BOOKING_ID,
        CUSTOMER_ID,
        {},
      );

      expect(result).toBeDefined();
      expect(prisma.job.create).toHaveBeenCalled();
      expect(prisma.jobEvent.createMany).toHaveBeenCalled();
    });

    it('should reject conversion when no worker is confirmed', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'SUBMITTED' }),
      );

      await expect(
        bookingsService.convertToJob(BOOKING_ID, CUSTOMER_ID, {}),
      ).rejects.toThrow(BadRequestException);
    });

    it('should return existing job if booking already has one', async () => {
      const existingJob = makeJob();
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({
          status: 'JOB_CREATED',
          selectedWorkerId: WORKER_ID,
          job: existingJob,
        }),
      );
      prisma.job.findUnique.mockResolvedValue(existingJob);

      const result = await bookingsService.convertToJob(
        BOOKING_ID,
        CUSTOMER_ID,
        {},
      );

      expect(result).toBeDefined();
      expect(prisma.job.create).not.toHaveBeenCalled();
    });
  });

  // --------------------------------------------------------
  // Phase 5: Job execution lifecycle
  // --------------------------------------------------------
  describe('Phase 5 – Job execution (en-route → arrived → start)', () => {
    beforeEach(() => {
      // Worker has a worker profile linked to their userId
      prisma.worker.findMany.mockResolvedValue([{ id: WORKER_ID }]);
    });

    it('should mark job as EN_ROUTE', async () => {
      const job = makeJob({ status: 'ASSIGNED' });
      prisma.job.findFirst
        .mockResolvedValueOnce(job)
        .mockResolvedValueOnce(makeJob({ status: 'EN_ROUTE' }));
      prisma.job.update.mockResolvedValue(makeJob({ status: 'EN_ROUTE' }));
      prisma.jobEvent.create.mockResolvedValue({});

      const result = await jobsService.markEnRoute(JOB_ID, WORKER_USER_ID, {});

      expect(result.status).toBe('EN_ROUTE');
      expect(prisma.jobEvent.create).toHaveBeenCalled();
    });

    it('should mark job as ARRIVED', async () => {
      const job = makeJob({ status: 'EN_ROUTE' });
      prisma.job.findFirst
        .mockResolvedValueOnce(job)
        .mockResolvedValueOnce(makeJob({ status: 'ARRIVED' }));
      prisma.job.update.mockResolvedValue(makeJob({ status: 'ARRIVED' }));
      prisma.jobEvent.create.mockResolvedValue({});

      const result = await jobsService.markArrived(JOB_ID, WORKER_USER_ID, {});

      expect(result.status).toBe('ARRIVED');
    });

    it('should start job', async () => {
      const job = makeJob({ status: 'ARRIVED' });
      prisma.job.findFirst
        .mockResolvedValueOnce(job)
        .mockResolvedValueOnce(
          makeJob({ status: 'IN_PROGRESS', startedAt: NOW }),
        );
      prisma.job.update.mockResolvedValue(makeJob({ status: 'IN_PROGRESS' }));
      prisma.jobEvent.create.mockResolvedValue({});

      const result = await jobsService.startJob(JOB_ID, WORKER_USER_ID, {});

      expect(result.status).toBe('IN_PROGRESS');
    });

    it('should reject en-route on completed job', async () => {
      prisma.job.findFirst.mockResolvedValue(makeJob({ status: 'COMPLETED' }));

      await expect(
        jobsService.markEnRoute(JOB_ID, WORKER_USER_ID, {}),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Phase 6: Complete + customer confirm
  // --------------------------------------------------------
  describe('Phase 6 – Complete and confirm job', () => {
    beforeEach(() => {
      prisma.worker.findMany.mockResolvedValue([{ id: WORKER_ID }]);
    });

    it('should complete job (worker) → WAITING_CONFIRMATION', async () => {
      const inProgress = makeJob({ status: 'IN_PROGRESS', startedAt: NOW });
      prisma.job.findFirst
        .mockResolvedValueOnce(inProgress)
        .mockResolvedValueOnce(
          makeJob({ status: 'WAITING_CONFIRMATION', completedAt: NOW }),
        );
      prisma.job.update.mockResolvedValue({});
      prisma.jobEvent.create.mockResolvedValue({});

      const result = await jobsService.completeJob(JOB_ID, WORKER_USER_ID, {
        finalAmount: 500000,
        warrantyDays: 30,
      });

      expect(result.status).toBe('WAITING_CONFIRMATION');
      expect(prisma.job.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'WAITING_CONFIRMATION',
          }),
        }),
      );
    });

    it('should allow customer to confirm completion → COMPLETED', async () => {
      const waiting = makeJob({ status: 'WAITING_CONFIRMATION' });
      prisma.worker.findMany.mockResolvedValue([]); // customer has no worker profiles
      prisma.job.findFirst
        .mockResolvedValueOnce(waiting)
        .mockResolvedValueOnce(
          makeJob({ status: 'COMPLETED', customerConfirmedAt: NOW }),
        );
      prisma.job.update.mockResolvedValue({});
      prisma.jobEvent.create.mockResolvedValue({});
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await jobsService.confirmCompletion(
        JOB_ID,
        CUSTOMER_ID,
        {},
      );

      expect(result.status).toBe('COMPLETED');
    });
  });

  // --------------------------------------------------------
  // Phase 7: Review
  // --------------------------------------------------------
  describe('Phase 7 – Customer review', () => {
    it('should create review and update worker rating', async () => {
      const completed = makeJob({
        status: 'COMPLETED',
        customerConfirmedAt: NOW,
      });
      prisma.worker.findMany.mockResolvedValue([]); // customer
      prisma.job.findFirst
        .mockResolvedValueOnce(completed)
        .mockResolvedValueOnce(completed);
      prisma.jobReview.findUnique.mockResolvedValue(null);
      prisma.jobReview.create.mockResolvedValue({});
      prisma.jobReview.aggregate.mockResolvedValue({
        _avg: { rating: 4.7 },
        _count: { rating: 21 },
      });
      prisma.worker.update.mockResolvedValue({});
      prisma.jobEvent.create.mockResolvedValue({});
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await jobsService.createReview(JOB_ID, CUSTOMER_ID, {
        rating: 5,
        comment: 'Thợ làm rất tốt!',
      });

      expect(prisma.jobReview.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ rating: 5, customerId: CUSTOMER_ID }),
        }),
      );
      expect(prisma.worker.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ rating: 4.7, totalReviews: 21 }),
        }),
      );
    });

    it('should reject duplicate review', async () => {
      const completed = makeJob({
        status: 'COMPLETED',
        customerConfirmedAt: NOW,
      });
      prisma.worker.findMany.mockResolvedValue([]);
      prisma.job.findFirst.mockResolvedValue(completed);
      prisma.jobReview.findUnique.mockResolvedValue({ id: 1 });

      await expect(
        jobsService.createReview(JOB_ID, CUSTOMER_ID, { rating: 5 }),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Phase 8: Warranty lifecycle
  // --------------------------------------------------------
  describe('Phase 8 – Warranty', () => {
    it('should create warranty for completed job', async () => {
      const completedJob = makeJob({
        status: 'COMPLETED',
        customerConfirmedAt: NOW,
        booking: makeBooking({ serviceCategory: 'tho_dien' }),
      });
      prisma.worker.findMany.mockResolvedValue([]); // customer path
      prisma.job.findFirst.mockResolvedValue(completedJob);

      const policy = {
        id: POLICY_ID,
        name: 'Bảo hành điện',
        coverageDays: 30,
        isActive: true,
      };
      prisma.warrantyPolicy.findFirst.mockResolvedValue(policy);

      const warranty = makeWarranty();
      prisma.warrantyCase.create.mockResolvedValue(warranty);
      prisma.job.update.mockResolvedValue({});
      prisma.jobEvent.create.mockResolvedValue({});
      prisma.warrantyCase.findUniqueOrThrow.mockResolvedValue(warranty);
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await warrantiesService.createWarranty(CUSTOMER_ID, {
        jobId: JOB_ID,
        policyId: POLICY_ID,
        title: 'Bảo hành cho Sửa điện phòng khách',
      });

      expect(result.status).toBe('ACTIVE');
      expect(result.policyId).toBe(POLICY_ID);
    });

    it('should reject warranty for non-completed job', async () => {
      const inProgress = makeJob({ status: 'IN_PROGRESS' });
      prisma.worker.findMany.mockResolvedValue([]);
      prisma.job.findFirst.mockResolvedValue(inProgress);

      await expect(
        warrantiesService.createWarranty(CUSTOMER_ID, { jobId: JOB_ID }),
      ).rejects.toThrow(BadRequestException);
    });

    it('should allow customer to claim warranty', async () => {
      const active = makeWarranty({ status: 'ACTIVE' });
      prisma.worker.findMany.mockResolvedValue([]); // customer
      prisma.warrantyCase.findFirst
        .mockResolvedValueOnce(active)
        .mockResolvedValueOnce(
          makeWarranty({ status: 'CLAIMED', claimedAt: NOW }),
        );
      prisma.warrantyCase.update.mockResolvedValue({});
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await warrantiesService.claimWarranty(
        WARRANTY_ID,
        CUSTOMER_ID,
        {
          reason: 'Ổ cắm lại bị chập sau 2 tuần',
        },
      );

      expect(result.status).toBe('CLAIMED');
    });

    it('should allow worker to resolve warranty', async () => {
      const claimed = makeWarranty({ status: 'CLAIMED', claimedAt: NOW });
      prisma.worker.findMany.mockResolvedValue([{ id: WORKER_ID }]); // worker
      prisma.warrantyCase.findFirst
        .mockResolvedValueOnce(claimed)
        .mockResolvedValueOnce(
          makeWarranty({ status: 'RESOLVED', resolvedAt: NOW }),
        );
      prisma.warrantyCase.update.mockResolvedValue({});

      const result = await warrantiesService.resolveWarranty(
        WARRANTY_ID,
        WORKER_USER_ID,
        {
          resolutionNotes: 'Đã thay ổ cắm mới và kiểm tra lại toàn bộ.',
        },
      );

      expect(result.status).toBe('RESOLVED');
    });

    it('should allow worker to reject warranty', async () => {
      const claimed = makeWarranty({ status: 'CLAIMED', claimedAt: NOW });
      prisma.worker.findMany.mockResolvedValue([{ id: WORKER_ID }]);
      prisma.warrantyCase.findFirst
        .mockResolvedValueOnce(claimed)
        .mockResolvedValueOnce(makeWarranty({ status: 'REJECTED' }));
      prisma.warrantyCase.update.mockResolvedValue({});

      const result = await warrantiesService.rejectWarranty(
        WARRANTY_ID,
        WORKER_USER_ID,
        {
          resolutionNotes: 'Không thuộc phạm vi bảo hành.',
        },
      );

      expect(result.status).toBe('REJECTED');
    });

    it('should reject claim on non-active warranty', async () => {
      prisma.worker.findMany.mockResolvedValue([]);
      prisma.warrantyCase.findFirst.mockResolvedValue(
        makeWarranty({ status: 'RESOLVED' }),
      );

      await expect(
        warrantiesService.claimWarranty(WARRANTY_ID, CUSTOMER_ID, {
          reason: 'test',
        }),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Phase 9: Cancellation edge cases
  // --------------------------------------------------------
  describe('Phase 9 – Cancellation', () => {
    it('should cancel booking before job creation', async () => {
      const booking = makeBooking({ status: 'QUOTED' });
      prisma.booking.findFirst
        .mockResolvedValueOnce(booking)
        .mockResolvedValueOnce(makeBooking({ status: 'CANCELLED' }));
      prisma.booking.update.mockResolvedValue({});

      const result = await bookingsService.cancelBooking(
        BOOKING_ID,
        CUSTOMER_ID,
        {
          reason: 'Không cần nữa',
        },
      );

      expect(result.status).toBe('CANCELLED');
    });

    it('should reject booking cancellation after job exists', async () => {
      prisma.booking.findFirst.mockResolvedValue(
        makeBooking({ status: 'JOB_CREATED', job: makeJob() }),
      );

      await expect(
        bookingsService.cancelBooking(BOOKING_ID, CUSTOMER_ID, {
          reason: 'test',
        }),
      ).rejects.toThrow(BadRequestException);
    });

    it('should cancel a job', async () => {
      const job = makeJob({ status: 'IN_PROGRESS' });
      prisma.worker.findMany.mockResolvedValue([{ id: WORKER_ID }]);
      prisma.job.findFirst
        .mockResolvedValueOnce(job)
        .mockResolvedValueOnce(makeJob({ status: 'CANCELLED' }));
      prisma.job.update.mockResolvedValue({});
      prisma.jobEvent.create.mockResolvedValue({});
      prisma.worker.findUnique.mockResolvedValue(makeWorker());

      const result = await jobsService.cancelJob(JOB_ID, WORKER_USER_ID, {
        reason: 'Khách hàng yêu cầu hủy',
      });

      expect(result.status).toBe('CANCELLED');
    });

    it('should reject cancellation of completed job', async () => {
      prisma.worker.findMany.mockResolvedValue([]);
      prisma.job.findFirst.mockResolvedValue(makeJob({ status: 'COMPLETED' }));

      await expect(
        jobsService.cancelJob(JOB_ID, CUSTOMER_ID, { reason: 'test' }),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // --------------------------------------------------------
  // Notifications
  // --------------------------------------------------------
  describe('Notifications', () => {
    it('should send notifications during matching', async () => {
      const booking = makeBooking();
      prisma.booking.findFirst
        .mockResolvedValueOnce(booking)
        .mockResolvedValueOnce(makeBooking({ status: 'QUOTED' }));
      prisma.worker.findMany.mockResolvedValue([makeWorker()]);
      prisma.workerOffer.upsert.mockResolvedValue(makeOffer());
      prisma.booking.update.mockResolvedValue({});

      await bookingsService.requestMatching(BOOKING_ID, CUSTOMER_ID);

      expect(notifications.create).toHaveBeenCalledWith(
        expect.objectContaining({
          userId: CUSTOMER_ID,
          title: expect.stringContaining('tìm thấy thợ'),
        }),
      );
    });

    it('should not throw even if notification fails', async () => {
      notifications.create.mockRejectedValue(new Error('push failed'));

      const booking = makeBooking();
      prisma.booking.findFirst
        .mockResolvedValueOnce(booking)
        .mockResolvedValueOnce(makeBooking({ status: 'QUOTED' }));
      prisma.worker.findMany.mockResolvedValue([makeWorker()]);
      prisma.workerOffer.upsert.mockResolvedValue(makeOffer());
      prisma.booking.update.mockResolvedValue({});

      // Should not throw even when notification fails
      await expect(
        bookingsService.requestMatching(BOOKING_ID, CUSTOMER_ID),
      ).resolves.toBeDefined();
    });
  });
});
