import {
    Body,
    Controller,
    Headers,
    HttpException,
    HttpStatus,
    Logger,
    Post,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import * as crypto from 'crypto';

@ApiTags('GitHub Webhook')
@Controller('github-webhook')
export class GitHubWebhookController {
  private readonly logger = new Logger(GitHubWebhookController.name);

  constructor(private readonly configService: ConfigService) {}

  /**
   * Verify GitHub webhook signature
   */
  private verifySignature(
    payload: string,
    signature: string | undefined,
  ): boolean {
    const secret = this.configService.get<string>('GITHUB_WEBHOOK_SECRET');

    if (!secret) {
      this.logger.warn(
        'GITHUB_WEBHOOK_SECRET not configured - skipping verification',
      );
      return true; // Allow in development
    }

    if (!signature) {
      return false;
    }

    const hmac = crypto.createHmac('sha256', secret);
    const digest = 'sha256=' + hmac.update(payload).digest('hex');

    try {
      return crypto.timingSafeEqual(
        Buffer.from(digest),
        Buffer.from(signature),
      );
    } catch {
      return false;
    }
  }

  @Post()
  @ApiOperation({
    summary: 'GitHub Webhook Receiver',
    description:
      'Receives webhook events from GitHub (push, pull_request, issues, etc.)',
  })
  @ApiResponse({ status: 200, description: 'Webhook processed successfully' })
  @ApiResponse({ status: 401, description: 'Invalid signature' })
  async handleWebhook(
    @Headers('x-hub-signature-256') signature: string,
    @Headers('x-github-event') event: string,
    @Headers('x-github-delivery') deliveryId: string,
    @Body() payload: any,
  ) {
    this.logger.log(
      `📥 GitHub Webhook received - Event: ${event}, Delivery: ${deliveryId}`,
    );

    // Verify signature
    const rawBody = JSON.stringify(payload);
    if (!this.verifySignature(rawBody, signature)) {
      this.logger.error('❌ Invalid GitHub webhook signature');
      throw new HttpException('Invalid signature', HttpStatus.UNAUTHORIZED);
    }

    // Log event details
    this.logger.log(`✅ Signature verified for delivery: ${deliveryId}`);

    // Handle different event types
    try {
      switch (event) {
        case 'ping':
          return this.handlePing(payload);

        case 'push':
          return this.handlePush(payload);

        case 'pull_request':
          return this.handlePullRequest(payload);

        case 'issues':
          return this.handleIssues(payload);

        case 'release':
          return this.handleRelease(payload);

        case 'workflow_run':
          return this.handleWorkflowRun(payload);

        default:
          this.logger.log(`ℹ️ Unhandled event type: ${event}`);
          return {
            success: true,
            message: `Event '${event}' received but not processed`,
            deliveryId,
          };
      }
    } catch (error) {
      this.logger.error(`❌ Error processing ${event}:`, error);
      throw new HttpException(
        'Error processing webhook',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Handle ping event (sent when webhook is created)
   */
  private handlePing(payload: any) {
    this.logger.log('🏓 Ping event received - Webhook is active!');
    this.logger.log(`   Repository: ${payload.repository?.full_name}`);
    this.logger.log(`   Zen: ${payload.zen}`);

    return {
      success: true,
      message: 'Pong! Webhook configured successfully',
      repository: payload.repository?.full_name,
      hookId: payload.hook_id,
    };
  }

  /**
   * Handle push events
   */
  private handlePush(payload: any) {
    const { ref, repository, pusher, commits, head_commit } = payload;
    const branch = ref?.replace('refs/heads/', '');

    this.logger.log(`🚀 Push to ${repository?.full_name}:${branch}`);
    this.logger.log(`   Pusher: ${pusher?.name}`);
    this.logger.log(`   Commits: ${commits?.length || 0}`);
    this.logger.log(`   Latest: ${head_commit?.message?.substring(0, 50)}...`);

    // TODO: Add your custom logic here
    // - Trigger CI/CD pipeline
    // - Send notification to team
    // - Update deployment status
    // - Sync code changes

    return {
      success: true,
      event: 'push',
      repository: repository?.full_name,
      branch,
      pusher: pusher?.name,
      commitCount: commits?.length || 0,
      latestCommit: {
        id: head_commit?.id?.substring(0, 7),
        message: head_commit?.message?.substring(0, 100),
        author: head_commit?.author?.name,
      },
    };
  }

  /**
   * Handle pull request events
   */
  private handlePullRequest(payload: any) {
    const { action, number, pull_request, repository } = payload;

    this.logger.log(`🔃 PR #${number} ${action} on ${repository?.full_name}`);
    this.logger.log(`   Title: ${pull_request?.title}`);
    this.logger.log(`   Author: ${pull_request?.user?.login}`);
    this.logger.log(
      `   Base: ${pull_request?.base?.ref} <- ${pull_request?.head?.ref}`,
    );

    // TODO: Add your custom logic
    // - Notify reviewers
    // - Run automated tests
    // - Check for conflicts
    // - Auto-merge if approved

    return {
      success: true,
      event: 'pull_request',
      action,
      repository: repository?.full_name,
      pullRequest: {
        number,
        title: pull_request?.title,
        author: pull_request?.user?.login,
        state: pull_request?.state,
        base: pull_request?.base?.ref,
        head: pull_request?.head?.ref,
        url: pull_request?.html_url,
      },
    };
  }

  /**
   * Handle issues events
   */
  private handleIssues(payload: any) {
    const { action, issue, repository } = payload;

    this.logger.log(
      `📋 Issue #${issue?.number} ${action} on ${repository?.full_name}`,
    );
    this.logger.log(`   Title: ${issue?.title}`);
    this.logger.log(`   Author: ${issue?.user?.login}`);

    // TODO: Add your custom logic
    // - Send notification
    // - Update project board
    // - Assign team members
    // - Create task in CRM

    return {
      success: true,
      event: 'issues',
      action,
      repository: repository?.full_name,
      issue: {
        number: issue?.number,
        title: issue?.title,
        author: issue?.user?.login,
        state: issue?.state,
        labels: issue?.labels?.map((l: any) => l.name),
        url: issue?.html_url,
      },
    };
  }

  /**
   * Handle release events
   */
  private handleRelease(payload: any) {
    const { action, release, repository } = payload;

    this.logger.log(
      `📦 Release ${release?.tag_name} ${action} on ${repository?.full_name}`,
    );
    this.logger.log(`   Name: ${release?.name}`);
    this.logger.log(`   Author: ${release?.author?.login}`);

    // TODO: Add your custom logic
    // - Trigger deployment
    // - Update changelog
    // - Notify users
    // - Create announcement

    return {
      success: true,
      event: 'release',
      action,
      repository: repository?.full_name,
      release: {
        tagName: release?.tag_name,
        name: release?.name,
        author: release?.author?.login,
        prerelease: release?.prerelease,
        url: release?.html_url,
      },
    };
  }

  /**
   * Handle workflow run events (GitHub Actions)
   */
  private handleWorkflowRun(payload: any) {
    const { action, workflow_run, repository } = payload;

    this.logger.log(
      `⚙️ Workflow "${workflow_run?.name}" ${action} on ${repository?.full_name}`,
    );
    this.logger.log(`   Status: ${workflow_run?.status}`);
    this.logger.log(
      `   Conclusion: ${workflow_run?.conclusion || 'in progress'}`,
    );

    // TODO: Add your custom logic
    // - Track CI/CD status
    // - Notify on failure
    // - Update deployment status
    // - Trigger downstream jobs

    return {
      success: true,
      event: 'workflow_run',
      action,
      repository: repository?.full_name,
      workflow: {
        name: workflow_run?.name,
        status: workflow_run?.status,
        conclusion: workflow_run?.conclusion,
        branch: workflow_run?.head_branch,
        url: workflow_run?.html_url,
      },
    };
  }
}
