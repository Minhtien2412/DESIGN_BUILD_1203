import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { GitHubWebhookController } from './github-webhook.controller';

@Module({
  imports: [ConfigModule],
  controllers: [GitHubWebhookController],
  providers: [],
  exports: [],
})
export class GitHubWebhookModule {}
