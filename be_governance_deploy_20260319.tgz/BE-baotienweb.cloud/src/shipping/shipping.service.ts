import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EstimateShippingDto } from './dto/shipping.dto';

// Default shipping zones for Vietnam (used as fallback / seed data)
const DEFAULT_ZONES = [
  {
    name: 'TP.HCM',
    provinces: ['TP.HCM', 'Hồ Chí Minh', 'Ho Chi Minh', 'TPHCM'],
    baseRate: 15000,
    perKgRate: 3000,
    freeShippingThreshold: 500000,
    estimatedDays: 1,
  },
  {
    name: 'Hà Nội',
    provinces: ['Hà Nội', 'Ha Noi', 'Hanoi'],
    baseRate: 15000,
    perKgRate: 3000,
    freeShippingThreshold: 500000,
    estimatedDays: 1,
  },
  {
    name: 'Miền Nam',
    provinces: [
      'Bình Dương',
      'Đồng Nai',
      'Long An',
      'Bà Rịa - Vũng Tàu',
      'Tây Ninh',
      'Bình Phước',
      'Tiền Giang',
      'Bến Tre',
    ],
    baseRate: 20000,
    perKgRate: 4000,
    freeShippingThreshold: 800000,
    estimatedDays: 2,
  },
  {
    name: 'Miền Trung',
    provinces: [
      'Đà Nẵng',
      'Huế',
      'Quảng Nam',
      'Quảng Ngãi',
      'Bình Định',
      'Phú Yên',
      'Khánh Hòa',
      'Ninh Thuận',
      'Bình Thuận',
      'Quảng Bình',
      'Quảng Trị',
      'Hà Tĩnh',
      'Nghệ An',
      'Thanh Hóa',
    ],
    baseRate: 30000,
    perKgRate: 5000,
    freeShippingThreshold: 1000000,
    estimatedDays: 3,
  },
  {
    name: 'Miền Bắc',
    provinces: [
      'Hải Phòng',
      'Bắc Ninh',
      'Hải Dương',
      'Hưng Yên',
      'Vĩnh Phúc',
      'Bắc Giang',
      'Thái Nguyên',
      'Nam Định',
      'Ninh Bình',
      'Thái Bình',
    ],
    baseRate: 25000,
    perKgRate: 4500,
    freeShippingThreshold: 800000,
    estimatedDays: 2,
  },
  {
    name: 'Vùng xa',
    provinces: [
      'Lào Cai',
      'Yên Bái',
      'Điện Biên',
      'Lai Châu',
      'Sơn La',
      'Hà Giang',
      'Cao Bằng',
      'Bắc Kạn',
      'Lạng Sơn',
      'Tuyên Quang',
      'Đắk Lắk',
      'Đắk Nông',
      'Gia Lai',
      'Kon Tum',
      'Lâm Đồng',
      'An Giang',
      'Kiên Giang',
      'Cần Thơ',
      'Vĩnh Long',
      'Đồng Tháp',
      'Sóc Trăng',
      'Trà Vinh',
      'Bạc Liêu',
      'Cà Mau',
      'Hậu Giang',
    ],
    baseRate: 40000,
    perKgRate: 6000,
    freeShippingThreshold: 1500000,
    estimatedDays: 4,
  },
];

@Injectable()
export class ShippingService {
  private readonly logger = new Logger(ShippingService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Estimate shipping cost based on destination and order details
   */
  async estimateShipping(dto: EstimateShippingDto) {
    const { city, totalWeight = 1, itemCount = 1, subtotal = 0 } = dto;

    // Try to find matching zone from database
    let zone = await this.findZoneByCity(city);

    // If not found in DB, use default zones
    if (!zone) {
      const defaultZone = this.findDefaultZone(city);
      if (defaultZone) {
        zone = {
          name: defaultZone.name,
          baseRate: defaultZone.baseRate,
          perKgRate: defaultZone.perKgRate,
          freeShippingThreshold: defaultZone.freeShippingThreshold,
          estimatedDays: defaultZone.estimatedDays,
        };
      } else {
        // Fallback: unknown zone
        zone = {
          name: 'Khác',
          baseRate: 35000,
          perKgRate: 5000,
          freeShippingThreshold: 1000000,
          estimatedDays: 5,
        };
      }
    }

    // Calculate fee
    const weight = Math.max(totalWeight, itemCount * 0.5); // Minimum 0.5kg per item
    let fee = zone.baseRate + weight * zone.perKgRate;

    // Check free shipping threshold
    const freeShipping =
      zone.freeShippingThreshold != null &&
      subtotal >= zone.freeShippingThreshold;
    if (freeShipping) {
      fee = 0;
    }

    return {
      success: true,
      data: {
        fee: Math.round(fee),
        estimatedDays: zone.estimatedDays,
        zoneName: zone.name,
        freeShipping,
        freeShippingThreshold: zone.freeShippingThreshold
          ? Number(zone.freeShippingThreshold)
          : null,
      },
    };
  }

  /**
   * Get all shipping zones
   */
  async getShippingZones() {
    try {
      const zones = await this.prisma.shippingZone.findMany({
        where: { isActive: true },
        orderBy: { name: 'asc' },
      });

      if (zones.length > 0) {
        return {
          success: true,
          data: zones.map((z) => ({
            id: z.id,
            name: z.name,
            provinces: z.provinces,
            baseRate: Number(z.baseRate),
            perKgRate: Number(z.perKgRate),
            freeShippingThreshold: z.freeShippingThreshold
              ? Number(z.freeShippingThreshold)
              : null,
            estimatedDays: z.estimatedDays,
          })),
        };
      }
    } catch {
      // DB table might not exist yet
    }

    // Return defaults
    return {
      success: true,
      data: DEFAULT_ZONES.map((z) => ({
        name: z.name,
        provinces: z.provinces,
        baseRate: z.baseRate,
        perKgRate: z.perKgRate,
        freeShippingThreshold: z.freeShippingThreshold,
        estimatedDays: z.estimatedDays,
      })),
    };
  }

  /**
   * Seed default zones into database
   */
  async seedDefaultZones() {
    let created = 0;
    for (const zone of DEFAULT_ZONES) {
      const exists = await this.prisma.shippingZone.findFirst({
        where: { name: zone.name },
      });
      if (!exists) {
        await this.prisma.shippingZone.create({ data: zone });
        created++;
      }
    }
    return { success: true, message: `Seeded ${created} shipping zones` };
  }

  // ============ Private helpers ============

  private async findZoneByCity(city: string): Promise<any | null> {
    try {
      const zones = await this.prisma.shippingZone.findMany({
        where: { isActive: true },
      });

      for (const zone of zones) {
        if (
          zone.provinces.some(
            (p) =>
              p.toLowerCase().includes(city.toLowerCase()) ||
              city.toLowerCase().includes(p.toLowerCase()),
          )
        ) {
          return {
            name: zone.name,
            baseRate: Number(zone.baseRate),
            perKgRate: Number(zone.perKgRate),
            freeShippingThreshold: zone.freeShippingThreshold
              ? Number(zone.freeShippingThreshold)
              : null,
            estimatedDays: zone.estimatedDays,
          };
        }
      }
    } catch {
      // DB table might not exist yet, use defaults
    }
    return null;
  }

  private findDefaultZone(city: string) {
    return DEFAULT_ZONES.find((zone) =>
      zone.provinces.some(
        (p) =>
          p.toLowerCase().includes(city.toLowerCase()) ||
          city.toLowerCase().includes(p.toLowerCase()),
      ),
    );
  }
}
