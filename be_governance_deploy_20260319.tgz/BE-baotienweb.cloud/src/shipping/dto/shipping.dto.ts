import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsInt,
    IsNotEmpty,
    IsOptional,
    IsString,
    Min
} from 'class-validator';

export class EstimateShippingDto {
  @ApiProperty({ example: 'TP.HCM', description: 'Destination city/province' })
  @IsString()
  @IsNotEmpty()
  city: string;

  @ApiPropertyOptional({ example: 'Quận 1' })
  @IsString()
  @IsOptional()
  district?: string;

  @ApiPropertyOptional({ example: 5.5, description: 'Total weight in kg' })
  @IsOptional()
  totalWeight?: number;

  @ApiPropertyOptional({ example: 3, description: 'Number of items' })
  @IsInt()
  @IsOptional()
  @Min(1)
  itemCount?: number;

  @ApiPropertyOptional({
    example: 500000,
    description: 'Subtotal for free shipping check',
  })
  @IsOptional()
  subtotal?: number;
}

export class ShippingEstimateResponse {
  @ApiProperty() fee: number;
  @ApiProperty() estimatedDays: number;
  @ApiProperty() zoneName: string;
  @ApiProperty() freeShipping: boolean;
  @ApiPropertyOptional() freeShippingThreshold?: number;
}
