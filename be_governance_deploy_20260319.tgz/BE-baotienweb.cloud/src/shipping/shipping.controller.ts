import { Body, Controller, Get, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { EstimateShippingDto } from './dto/shipping.dto';
import { ShippingService } from './shipping.service';

@ApiTags('Shipping')
@Controller({ path: 'shipping', version: '1' })
export class ShippingController {
  constructor(private readonly shippingService: ShippingService) {}

  @Post('estimate')
  @ApiOperation({ summary: 'Estimate shipping cost' })
  @ApiResponse({ status: 200, description: 'Shipping estimate calculated' })
  async estimateShipping(@Body() dto: EstimateShippingDto) {
    return this.shippingService.estimateShipping(dto);
  }

  @Get('zones')
  @ApiOperation({ summary: 'Get all shipping zones with rates' })
  @ApiResponse({ status: 200, description: 'List of shipping zones' })
  async getShippingZones() {
    return this.shippingService.getShippingZones();
  }

  @Post('zones/seed')
  @ApiOperation({ summary: 'Seed default shipping zones (Admin)' })
  async seedZones() {
    return this.shippingService.seedDefaultZones();
  }
}
