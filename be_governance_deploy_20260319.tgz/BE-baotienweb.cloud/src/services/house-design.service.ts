import {
    ForbiddenException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import {
    ApproveDesignDto,
    CreateHouseDesignDto,
    DesignStatus,
    HouseDesignQueryDto,
    UpdateHouseDesignDto,
} from './dto/house-design.dto';

@Injectable()
export class HouseDesignService {
  private readonly logger = new Logger(HouseDesignService.name);

  constructor(private prisma: PrismaService) {}

  /**
   * Lấy danh sách mẫu thiết kế với filter và pagination
   */
  async findAll(query: HouseDesignQueryDto) {
    const {
      page = 1,
      limit = 20,
      search,
      type,
      style,
      status,
      minArea,
      maxArea,
      minPrice,
      maxPrice,
      floors,
      minBedrooms,
      location,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      featured,
    } = query;

    // Build where clause
    const where: any = {};

    // Mặc định chỉ hiển thị APPROVED, trừ khi có filter khác
    if (status) {
      where.status = status;
    } else {
      where.status = DesignStatus.APPROVED;
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (type) where.type = type;
    if (style) where.style = style;
    if (location) where.location = { contains: location, mode: 'insensitive' };
    if (floors) where.floors = floors;
    if (minBedrooms) where.bedrooms = { gte: minBedrooms };
    if (featured) where.status = DesignStatus.FEATURED;

    if (minArea || maxArea) {
      where.area = {};
      if (minArea) where.area.gte = minArea;
      if (maxArea) where.area.lte = maxArea;
    }

    if (minPrice || maxPrice) {
      where.pricePerSqm = {};
      if (minPrice) where.pricePerSqm.gte = minPrice;
      if (maxPrice) where.pricePerSqm.lte = maxPrice;
    }

    // Execute query with mock data for now
    // TODO: Replace with actual Prisma query when HouseDesign model is added
    const mockDesigns = this.getMockDesigns();

    // Apply filters to mock data
    let filteredData = mockDesigns.filter((design: any) => {
      if (type && design.type !== type) return false;
      if (style && design.style !== style) return false;
      if (minArea && design.area < minArea) return false;
      if (maxArea && design.area > maxArea) return false;
      if (floors && design.floors !== floors) return false;
      if (minBedrooms && design.bedrooms < minBedrooms) return false;
      if (search) {
        const searchLower = search.toLowerCase();
        if (
          !design.title.toLowerCase().includes(searchLower) &&
          !design.description.toLowerCase().includes(searchLower)
        ) {
          return false;
        }
      }
      return true;
    });

    // Sort
    filteredData = filteredData.sort((a: any, b: any) => {
      const aVal = a[sortBy] || 0;
      const bVal = b[sortBy] || 0;
      return sortOrder === 'desc' ? bVal - aVal : aVal - bVal;
    });

    // Paginate
    const total = filteredData.length;
    const skip = (page - 1) * limit;
    const data = filteredData.slice(skip, skip + limit);

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Lấy chi tiết mẫu thiết kế
   */
  async findOne(id: number) {
    const designs = this.getMockDesigns();
    const design = designs.find((d: any) => d.id === id);

    if (!design) {
      throw new NotFoundException(`Không tìm thấy mẫu thiết kế #${id}`);
    }

    // Increment view count
    design.viewCount = (design.viewCount || 0) + 1;

    return design;
  }

  /**
   * Tạo mẫu thiết kế mới
   */
  async create(dto: CreateHouseDesignDto, userId: number) {
    this.logger.log(`Creating house design by user ${userId}: ${dto.title}`);

    // Tạo với status PENDING để Admin duyệt
    const newDesign = {
      id: Date.now(),
      ...dto,
      status: DesignStatus.PENDING,
      createdBy: userId,
      viewCount: 0,
      likeCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    return {
      ...newDesign,
      message: 'Mẫu thiết kế đã được tạo và đang chờ Admin duyệt',
    };
  }

  /**
   * Cập nhật mẫu thiết kế
   */
  async update(id: number, dto: UpdateHouseDesignDto, user: any) {
    const design = await this.findOne(id);

    // Check ownership hoặc admin
    if (design.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException(
        'Bạn không có quyền chỉnh sửa mẫu thiết kế này',
      );
    }

    // Reset status về PENDING nếu có thay đổi nội dung
    const shouldResetStatus = dto.title || dto.description || dto.images;

    return {
      ...design,
      ...dto,
      status: shouldResetStatus ? DesignStatus.PENDING : design.status,
      updatedAt: new Date().toISOString(),
      message: shouldResetStatus
        ? 'Đã cập nhật và chờ Admin duyệt lại'
        : 'Đã cập nhật thành công',
    };
  }

  /**
   * Xóa mẫu thiết kế
   */
  async remove(id: number, user: any) {
    const design = await this.findOne(id);

    if (design.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException('Bạn không có quyền xóa mẫu thiết kế này');
    }

    return { message: 'Đã xóa mẫu thiết kế thành công' };
  }

  /**
   * Admin duyệt/từ chối mẫu thiết kế
   */
  async approve(id: number, dto: ApproveDesignDto, adminId: number) {
    const design = await this.findOne(id);

    this.logger.log(`Admin ${adminId} ${dto.status} design #${id}`);

    const newStatus = dto.featured ? DesignStatus.FEATURED : dto.status;

    return {
      ...design,
      status: newStatus,
      approvedBy: adminId,
      approvedAt: new Date().toISOString(),
      approvalReason: dto.reason,
      message:
        dto.status === DesignStatus.APPROVED
          ? 'Mẫu thiết kế đã được duyệt'
          : 'Mẫu thiết kế đã bị từ chối',
    };
  }

  /**
   * Toggle featured status
   */
  async toggleFeatured(id: number) {
    const design = await this.findOne(id);

    const newStatus =
      design.status === DesignStatus.FEATURED
        ? DesignStatus.APPROVED
        : DesignStatus.FEATURED;

    return {
      ...design,
      status: newStatus,
      message:
        newStatus === DesignStatus.FEATURED
          ? 'Đã đánh dấu là mẫu nổi bật'
          : 'Đã bỏ đánh dấu nổi bật',
    };
  }

  /**
   * Lấy mẫu thiết kế nổi bật
   */
  async getFeatured(limit: number) {
    const designs = this.getMockDesigns()
      .filter(
        (d: any) =>
          d.status === DesignStatus.FEATURED ||
          d.status === DesignStatus.APPROVED,
      )
      .slice(0, limit);

    return { data: designs };
  }

  /**
   * Mock data - sẽ thay bằng database thực
   */
  private getMockDesigns() {
    return [
      {
        id: 1,
        title: 'Thiết kế nhà phố 3 tầng hiện đại',
        description:
          'Mẫu thiết kế nhà phố 3 tầng với phong cách hiện đại, tối ưu không gian và ánh sáng tự nhiên. Phù hợp cho gia đình 4-5 người.',
        type: 'TOWNHOUSE',
        style: 'MODERN',
        area: 100,
        floors: 3,
        bedrooms: 4,
        bathrooms: 3,
        pricePerSqm: 5000000,
        estimatedCost: 1500000000,
        images: [
          'https://picsum.photos/800/600?random=1',
          'https://picsum.photos/800/600?random=2',
          'https://picsum.photos/800/600?random=3',
        ],
        floorPlans: [],
        amenities: ['Sân thượng', 'Garage', 'Sân vườn nhỏ'],
        location: 'TP.HCM',
        landSize: '5x20m',
        status: 'APPROVED',
        viewCount: 1250,
        likeCount: 89,
        rating: 4.8,
        reviewCount: 23,
        createdBy: 1,
        createdAt: '2026-01-01T00:00:00Z',
        creator: {
          id: 1,
          name: 'KTS Nguyễn Văn A',
          avatar: 'https://ui-avatars.com/api/?name=A',
        },
      },
      {
        id: 2,
        title: 'Biệt thự vườn phong cách nhiệt đới',
        description:
          'Thiết kế biệt thự vườn 2 tầng với không gian xanh, hồ bơi và sân vườn rộng. Lý tưởng cho những ai yêu thích cuộc sống gần gũi thiên nhiên.',
        type: 'VILLA',
        style: 'TROPICAL',
        area: 250,
        floors: 2,
        bedrooms: 5,
        bathrooms: 4,
        pricePerSqm: 7000000,
        estimatedCost: 3500000000,
        images: [
          'https://picsum.photos/800/600?random=4',
          'https://picsum.photos/800/600?random=5',
        ],
        floorPlans: [],
        amenities: ['Hồ bơi', 'Sân vườn', 'BBQ', 'Garage 2 xe'],
        location: 'Hà Nội',
        landSize: '15x25m',
        status: 'FEATURED',
        viewCount: 2340,
        likeCount: 156,
        rating: 4.9,
        reviewCount: 45,
        createdBy: 2,
        createdAt: '2026-01-05T00:00:00Z',
        creator: {
          id: 2,
          name: 'KTS Trần Văn B',
          avatar: 'https://ui-avatars.com/api/?name=B',
        },
      },
      {
        id: 3,
        title: 'Căn hộ studio tối giản',
        description:
          'Thiết kế căn hộ studio 45m² theo phong cách tối giản, tối ưu không gian sống cho người trẻ.',
        type: 'APARTMENT',
        style: 'MINIMALIST',
        area: 45,
        floors: 1,
        bedrooms: 1,
        bathrooms: 1,
        pricePerSqm: 3000000,
        estimatedCost: 200000000,
        images: [
          'https://picsum.photos/800/600?random=6',
          'https://picsum.photos/800/600?random=7',
        ],
        floorPlans: [],
        amenities: ['Smart home', 'Ban công'],
        location: 'Đà Nẵng',
        landSize: 'N/A',
        status: 'APPROVED',
        viewCount: 890,
        likeCount: 67,
        rating: 4.7,
        reviewCount: 19,
        createdBy: 3,
        createdAt: '2026-01-10T00:00:00Z',
        creator: {
          id: 3,
          name: 'KTS Lê Thị C',
          avatar: 'https://ui-avatars.com/api/?name=C',
        },
      },
      {
        id: 4,
        title: 'Văn phòng startup hiện đại',
        description:
          'Thiết kế văn phòng 200m² cho startup công nghệ với không gian mở, phòng họp và khu giải trí.',
        type: 'OFFICE',
        style: 'INDUSTRIAL',
        area: 200,
        floors: 1,
        bedrooms: 0,
        bathrooms: 2,
        pricePerSqm: 4500000,
        estimatedCost: 900000000,
        images: [
          'https://picsum.photos/800/600?random=8',
          'https://picsum.photos/800/600?random=9',
        ],
        floorPlans: [],
        amenities: ['Phòng họp', 'Pantry', 'Khu giải trí', 'Bàn làm việc đứng'],
        location: 'TP.HCM',
        landSize: 'N/A',
        status: 'APPROVED',
        viewCount: 567,
        likeCount: 34,
        rating: 4.6,
        reviewCount: 12,
        createdBy: 1,
        createdAt: '2026-01-12T00:00:00Z',
        creator: {
          id: 1,
          name: 'KTS Nguyễn Văn A',
          avatar: 'https://ui-avatars.com/api/?name=A',
        },
      },
      {
        id: 5,
        title: 'Biệt thự cổ điển Pháp',
        description:
          'Thiết kế biệt thự 3 tầng theo phong cách cổ điển Pháp sang trọng với các chi tiết trang trí tinh xảo.',
        type: 'CLASSIC_VILLA',
        style: 'CLASSIC',
        area: 350,
        floors: 3,
        bedrooms: 6,
        bathrooms: 5,
        pricePerSqm: 10000000,
        estimatedCost: 7000000000,
        images: [
          'https://picsum.photos/800/600?random=10',
          'https://picsum.photos/800/600?random=11',
        ],
        floorPlans: [],
        amenities: [
          'Hồ bơi',
          'Sân tennis',
          'Garage 3 xe',
          'Hầm rượu',
          'Phòng gym',
        ],
        location: 'Hà Nội',
        landSize: '20x30m',
        status: 'FEATURED',
        viewCount: 3456,
        likeCount: 234,
        rating: 4.95,
        reviewCount: 67,
        createdBy: 2,
        createdAt: '2026-01-15T00:00:00Z',
        creator: {
          id: 2,
          name: 'KTS Trần Văn B',
          avatar: 'https://ui-avatars.com/api/?name=B',
        },
      },
      {
        id: 6,
        title: 'Quán café phong cách Nhật Bản',
        description:
          'Thiết kế quán café 80m² với phong cách Nhật Bản yên tĩnh, sử dụng vật liệu tự nhiên.',
        type: 'CAFE',
        style: 'JAPANESE',
        area: 80,
        floors: 1,
        bedrooms: 0,
        bathrooms: 1,
        pricePerSqm: 5500000,
        estimatedCost: 440000000,
        images: [
          'https://picsum.photos/800/600?random=12',
          'https://picsum.photos/800/600?random=13',
        ],
        floorPlans: [],
        amenities: ['Sân vườn zen', 'Quầy bar', 'Khu ngoài trời'],
        location: 'Đà Nẵng',
        landSize: '8x10m',
        status: 'APPROVED',
        viewCount: 1234,
        likeCount: 98,
        rating: 4.8,
        reviewCount: 28,
        createdBy: 3,
        createdAt: '2026-01-18T00:00:00Z',
        creator: {
          id: 3,
          name: 'KTS Lê Thị C',
          avatar: 'https://ui-avatars.com/api/?name=C',
        },
      },
      {
        id: 7,
        title: 'Nhà phố 2 tầng tân cổ điển',
        description:
          'Thiết kế nhà phố 2 tầng theo phong cách tân cổ điển, kết hợp hài hòa giữa cổ điển và hiện đại.',
        type: 'TOWNHOUSE',
        style: 'NEOCLASSIC',
        area: 85,
        floors: 2,
        bedrooms: 3,
        bathrooms: 2,
        pricePerSqm: 4800000,
        estimatedCost: 800000000,
        images: [
          'https://picsum.photos/800/600?random=14',
          'https://picsum.photos/800/600?random=15',
        ],
        floorPlans: [],
        amenities: ['Sân thượng', 'Ban công', 'Phòng thờ'],
        location: 'Cần Thơ',
        landSize: '5x17m',
        status: 'PENDING',
        viewCount: 456,
        likeCount: 23,
        rating: 0,
        reviewCount: 0,
        createdBy: 4,
        createdAt: '2026-01-25T00:00:00Z',
        creator: {
          id: 4,
          name: 'KTS Phạm Văn D',
          avatar: 'https://ui-avatars.com/api/?name=D',
        },
      },
      {
        id: 8,
        title: 'Khách sạn boutique Bắc Âu',
        description:
          'Thiết kế khách sạn boutique 15 phòng theo phong cách Bắc Âu ấm áp và tinh tế.',
        type: 'HOTEL',
        style: 'SCANDINAVIAN',
        area: 500,
        floors: 4,
        bedrooms: 15,
        bathrooms: 16,
        pricePerSqm: 8000000,
        estimatedCost: 8000000000,
        images: [
          'https://picsum.photos/800/600?random=16',
          'https://picsum.photos/800/600?random=17',
        ],
        floorPlans: [],
        amenities: [
          'Spa',
          'Nhà hàng',
          'Bar rooftop',
          'Phòng gym',
          'Hồ bơi trong nhà',
        ],
        location: 'Đà Lạt',
        landSize: '20x25m',
        status: 'APPROVED',
        viewCount: 2100,
        likeCount: 145,
        rating: 4.85,
        reviewCount: 38,
        createdBy: 2,
        createdAt: '2026-01-20T00:00:00Z',
        creator: {
          id: 2,
          name: 'KTS Trần Văn B',
          avatar: 'https://ui-avatars.com/api/?name=B',
        },
      },
    ];
  }
}
