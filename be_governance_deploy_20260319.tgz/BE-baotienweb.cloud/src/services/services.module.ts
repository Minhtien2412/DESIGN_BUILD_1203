import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { HouseDesignController } from './house-design.controller';
import { HouseDesignService } from './house-design.service';
import { ServicesController } from './services.controller';
import { ServicesService } from './services.service';

@Module({
  imports: [PrismaModule],
  // HouseDesignController MUST be first to handle /services/house-designs before /services/:id
  controllers: [HouseDesignController, ServicesController],
  providers: [ServicesService, HouseDesignService],
  exports: [ServicesService, HouseDesignService],
})
export class ServicesModule {}
