import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

// ==================== ENUMS ====================
export enum DesignType {
  TOWNHOUSE = 'TOWNHOUSE', // Nhà phố
  VILLA = 'VILLA', // Biệt thự
  CLASSIC_VILLA = 'CLASSIC_VILLA', // Biệt thự cổ điển
  APARTMENT = 'APARTMENT', // Căn hộ
  OFFICE = 'OFFICE', // Văn phòng
  HOTEL = 'HOTEL', // Khách sạn
  FACTORY = 'FACTORY', // Nhà xưởng
  RESTAURANT = 'RESTAURANT', // Nhà hàng
  CAFE = 'CAFE', // Quán cà phê
  SPA = 'SPA', // Spa
  GYM = 'GYM', // Phòng gym
  SCHOOL = 'SCHOOL', // Trường học
  HOSPITAL = 'HOSPITAL', // Bệnh viện
  SHOWROOM = 'SHOWROOM', // Showroom
  WAREHOUSE = 'WAREHOUSE', // Kho
}

export enum DesignStyle {
  MODERN = 'MODERN', // Hiện đại
  CLASSIC = 'CLASSIC', // Cổ điển
  NEOCLASSIC = 'NEOCLASSIC', // Tân cổ điển
  MINIMALIST = 'MINIMALIST', // Tối giản
  SCANDINAVIAN = 'SCANDINAVIAN', // Bắc Âu
  JAPANESE = 'JAPANESE', // Nhật Bản
  INDUSTRIAL = 'INDUSTRIAL', // Công nghiệp
  TROPICAL = 'TROPICAL', // Nhiệt đới
}

export enum DesignStatus {
  PENDING = 'PENDING', // Chờ duyệt
  APPROVED = 'APPROVED', // Đã duyệt
  REJECTED = 'REJECTED', // Từ chối
  DRAFT = 'DRAFT', // Bản nháp
  FEATURED = 'FEATURED', // Nổi bật
}

// ==================== CREATE DTO ====================
export class CreateHouseDesignDto {
  @ApiProperty({ example: 'Thiết kế nhà phố 3 tầng hiện đại' })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({
    example: 'Mẫu thiết kế nhà phố 3 tầng với phong cách hiện đại...',
  })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ enum: DesignType, example: DesignType.TOWNHOUSE })
  @IsEnum(DesignType)
  type: DesignType;

  @ApiProperty({ enum: DesignStyle, example: DesignStyle.MODERN })
  @IsEnum(DesignStyle)
  style: DesignStyle;

  @ApiProperty({ example: 100, description: 'Diện tích (m²)' })
  @IsNumber()
  @Min(0)
  area: number;

  @ApiProperty({ example: 3, description: 'Số tầng' })
  @IsNumber()
  @Min(1)
  floors: number;

  @ApiProperty({ example: 4, description: 'Số phòng ngủ' })
  @IsNumber()
  @Min(0)
  bedrooms: number;

  @ApiProperty({ example: 3, description: 'Số phòng tắm' })
  @IsNumber()
  @Min(0)
  bathrooms: number;

  @ApiProperty({ example: 5000000, description: 'Giá thiết kế (VNĐ/m²)' })
  @IsNumber()
  @Min(0)
  pricePerSqm: number;

  @ApiPropertyOptional({
    example: 1500000000,
    description: 'Chi phí dự kiến xây dựng',
  })
  @IsNumber()
  @IsOptional()
  estimatedCost?: number;

  @ApiProperty({
    example: ['https://example.com/image1.jpg'],
    description: 'Hình ảnh 2D/3D',
  })
  @IsArray()
  @IsString({ each: true })
  images: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/floor1.pdf'],
    description: 'Bản vẽ mặt bằng',
  })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  floorPlans?: string[];

  @ApiPropertyOptional({
    example: ['Sân thượng', 'Hồ bơi', 'Garage'],
    description: 'Tiện ích',
  })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  amenities?: string[];

  @ApiPropertyOptional({
    example: 'TP.HCM',
    description: 'Vị trí/Khu vực phù hợp',
  })
  @IsString()
  @IsOptional()
  location?: string;

  @ApiPropertyOptional({ example: '5x20m', description: 'Kích thước đất' })
  @IsString()
  @IsOptional()
  landSize?: string;

  @ApiPropertyOptional({ enum: DesignStatus, default: DesignStatus.PENDING })
  @IsEnum(DesignStatus)
  @IsOptional()
  status?: DesignStatus;
}

// ==================== UPDATE DTO ====================
export class UpdateHouseDesignDto {
  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  title?: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ enum: DesignType })
  @IsEnum(DesignType)
  @IsOptional()
  type?: DesignType;

  @ApiPropertyOptional({ enum: DesignStyle })
  @IsEnum(DesignStyle)
  @IsOptional()
  style?: DesignStyle;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  area?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  floors?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  bedrooms?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  bathrooms?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  pricePerSqm?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  estimatedCost?: number;

  @ApiPropertyOptional()
  @IsArray()
  @IsOptional()
  images?: string[];

  @ApiPropertyOptional()
  @IsArray()
  @IsOptional()
  floorPlans?: string[];

  @ApiPropertyOptional()
  @IsArray()
  @IsOptional()
  amenities?: string[];

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  location?: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  landSize?: string;

  @ApiPropertyOptional({ enum: DesignStatus })
  @IsEnum(DesignStatus)
  @IsOptional()
  status?: DesignStatus;
}

// ==================== QUERY DTO ====================
export class HouseDesignQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({ enum: DesignType })
  @IsOptional()
  @IsEnum(DesignType)
  type?: DesignType;

  @ApiPropertyOptional({ enum: DesignStyle })
  @IsOptional()
  @IsEnum(DesignStyle)
  style?: DesignStyle;

  @ApiPropertyOptional({ enum: DesignStatus })
  @IsOptional()
  @IsEnum(DesignStatus)
  status?: DesignStatus;

  @ApiPropertyOptional({ description: 'Diện tích tối thiểu' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  minArea?: number;

  @ApiPropertyOptional({ description: 'Diện tích tối đa' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  maxArea?: number;

  @ApiPropertyOptional({ description: 'Giá tối thiểu' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  minPrice?: number;

  @ApiPropertyOptional({ description: 'Giá tối đa' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  maxPrice?: number;

  @ApiPropertyOptional({ description: 'Số tầng' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  floors?: number;

  @ApiPropertyOptional({ description: 'Số phòng ngủ tối thiểu' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  minBedrooms?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional({ default: 'createdAt' })
  @IsOptional()
  @IsString()
  sortBy?: string;

  @ApiPropertyOptional({ default: 'desc', enum: ['asc', 'desc'] })
  @IsOptional()
  @IsString()
  sortOrder?: 'asc' | 'desc';

  @ApiPropertyOptional({ description: 'Chỉ lấy mẫu nổi bật' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  featured?: boolean;
}

// ==================== APPROVE/REJECT DTO ====================
export class ApproveDesignDto {
  @ApiProperty({ enum: ['APPROVED', 'REJECTED'], example: 'APPROVED' })
  @IsEnum(DesignStatus)
  status: DesignStatus.APPROVED | DesignStatus.REJECTED;

  @ApiPropertyOptional({ example: 'Thiết kế đạt tiêu chuẩn' })
  @IsString()
  @IsOptional()
  reason?: string;

  @ApiPropertyOptional({ description: 'Đánh dấu là mẫu nổi bật' })
  @IsBoolean()
  @IsOptional()
  featured?: boolean;
}
