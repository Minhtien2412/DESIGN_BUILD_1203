import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import {
    ApproveDesignDto,
    CreateHouseDesignDto,
    DesignStatus,
    DesignStyle,
    DesignType,
    HouseDesignQueryDto,
    UpdateHouseDesignDto,
} from './dto/house-design.dto';
import { HouseDesignService } from './house-design.service';

@ApiTags('House Designs - Mẫu thiết kế nhà')
@Controller({ path: 'services/house-designs', version: '1' })
export class HouseDesignController {
  constructor(private readonly houseDesignService: HouseDesignService) {}

  // ==================== PUBLIC ENDPOINTS ====================

  @Get()
  @ApiOperation({ summary: 'Lấy danh sách mẫu thiết kế nhà (Public)' })
  @ApiResponse({ status: 200, description: 'Danh sách mẫu thiết kế' })
  findAll(@Query() query: HouseDesignQueryDto) {
    return this.houseDesignService.findAll(query);
  }

  @Get('types')
  @ApiOperation({ summary: 'Lấy danh sách loại thiết kế' })
  getDesignTypes() {
    return Object.entries(DesignType).map(([key, value]) => ({
      id: key,
      value,
      label: this.getTypeLabel(value),
    }));
  }

  @Get('styles')
  @ApiOperation({ summary: 'Lấy danh sách phong cách thiết kế' })
  getDesignStyles() {
    return Object.entries(DesignStyle).map(([key, value]) => ({
      id: key,
      value,
      label: this.getStyleLabel(value),
    }));
  }

  @Get('featured')
  @ApiOperation({ summary: 'Lấy danh sách mẫu thiết kế nổi bật' })
  getFeatured(@Query('limit') limit?: number) {
    return this.houseDesignService.getFeatured(limit || 10);
  }

  @Get('categories/:type')
  @ApiOperation({ summary: 'Lấy mẫu thiết kế theo loại' })
  getByType(
    @Param('type') type: DesignType,
    @Query() query: HouseDesignQueryDto,
  ) {
    return this.houseDesignService.findAll({ ...query, type });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Lấy chi tiết mẫu thiết kế' })
  @ApiResponse({ status: 200, description: 'Chi tiết mẫu thiết kế' })
  @ApiResponse({ status: 404, description: 'Không tìm thấy' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.houseDesignService.findOne(id);
  }

  // ==================== AUTHENTICATED ENDPOINTS ====================

  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.ARCHITECT, Role.DESIGNER, Role.STAFF)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Tạo mẫu thiết kế mới (ARCHITECT/DESIGNER)' })
  @ApiResponse({
    status: 201,
    description: 'Mẫu thiết kế đã được tạo, chờ Admin duyệt',
  })
  create(@Body() dto: CreateHouseDesignDto, @CurrentUser() user: any) {
    return this.houseDesignService.create(dto, user.id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Cập nhật mẫu thiết kế' })
  @ApiResponse({ status: 200, description: 'Đã cập nhật' })
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateHouseDesignDto,
    @CurrentUser() user: any,
  ) {
    return this.houseDesignService.update(id, dto, user);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Xóa mẫu thiết kế' })
  remove(@Param('id', ParseIntPipe) id: number, @CurrentUser() user: any) {
    return this.houseDesignService.remove(id, user);
  }

  // ==================== ADMIN ONLY ENDPOINTS ====================

  @Get('admin/pending')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.STAFF)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách mẫu chờ duyệt (Admin)' })
  getPendingDesigns(@Query() query: HouseDesignQueryDto) {
    return this.houseDesignService.findAll({
      ...query,
      status: DesignStatus.PENDING,
    });
  }

  @Patch(':id/approve')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.STAFF)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Duyệt/Từ chối mẫu thiết kế (Admin)' })
  @ApiResponse({ status: 200, description: 'Đã cập nhật trạng thái' })
  approveDesign(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ApproveDesignDto,
    @CurrentUser() user: any,
  ) {
    return this.houseDesignService.approve(id, dto, user.id);
  }

  @Patch(':id/feature')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Đánh dấu mẫu nổi bật (Admin)' })
  toggleFeatured(@Param('id', ParseIntPipe) id: number) {
    return this.houseDesignService.toggleFeatured(id);
  }

  // ==================== HELPER METHODS ====================

  private getTypeLabel(type: DesignType): string {
    const labels: Record<DesignType, string> = {
      [DesignType.TOWNHOUSE]: 'Nhà phố',
      [DesignType.VILLA]: 'Biệt thự',
      [DesignType.CLASSIC_VILLA]: 'Biệt thự cổ điển',
      [DesignType.APARTMENT]: 'Căn hộ',
      [DesignType.OFFICE]: 'Văn phòng',
      [DesignType.HOTEL]: 'Khách sạn',
      [DesignType.FACTORY]: 'Nhà xưởng',
      [DesignType.RESTAURANT]: 'Nhà hàng',
      [DesignType.CAFE]: 'Quán cà phê',
      [DesignType.SPA]: 'Spa',
      [DesignType.GYM]: 'Phòng gym',
      [DesignType.SCHOOL]: 'Trường học',
      [DesignType.HOSPITAL]: 'Bệnh viện',
      [DesignType.SHOWROOM]: 'Showroom',
      [DesignType.WAREHOUSE]: 'Kho',
    };
    return labels[type] || type;
  }

  private getStyleLabel(style: DesignStyle): string {
    const labels: Record<DesignStyle, string> = {
      [DesignStyle.MODERN]: 'Hiện đại',
      [DesignStyle.CLASSIC]: 'Cổ điển',
      [DesignStyle.NEOCLASSIC]: 'Tân cổ điển',
      [DesignStyle.MINIMALIST]: 'Tối giản',
      [DesignStyle.SCANDINAVIAN]: 'Bắc Âu',
      [DesignStyle.JAPANESE]: 'Nhật Bản',
      [DesignStyle.INDUSTRIAL]: 'Công nghiệp',
      [DesignStyle.TROPICAL]: 'Nhiệt đới',
    };
    return labels[style] || style;
  }
}
