import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateBudgetDto,
    CreateCostEstimateDto,
    CreateExpenseDto,
    CreateInvoiceDto,
    RecordPaymentDto,
    UpdateBudgetDto,
    UpdateCostEstimateDto,
    UpdateExpenseDto,
    UpdateInvoiceDto,
} from './dto';

@Injectable()
export class BudgetService {
  constructor(private prisma: PrismaService) {}

  // ==================== Budgets ====================

  async getBudgets(projectId?: number) {
    return this.prisma.budget.findMany({
      where: projectId ? { projectId } : {},
      include: {
        lineItems: true,
        _count: { select: { lineItems: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getBudgetById(id: number) {
    const budget = await this.prisma.budget.findUnique({
      where: { id },
      include: {
        lineItems: { orderBy: { createdAt: 'asc' } },
        project: { select: { id: true, title: true } },
        createdBy: { select: { id: true, name: true } },
      },
    });
    if (!budget) throw new NotFoundException('Budget not found');
    return budget;
  }

  async createBudget(data: CreateBudgetDto, userId: number) {
    return this.prisma.budget.create({
      data: {
        name: data.name,
        projectId: data.projectId,
        totalAmount: data.totalAmount,
        description: data.description,
        currency: data.currency ?? 'VND',
        fiscalYear: data.fiscalYear ? parseInt(data.fiscalYear, 10) : undefined,
        startDate: data.startDate ? new Date(data.startDate) : undefined,
        endDate: data.endDate ? new Date(data.endDate) : undefined,
        notes: data.notes,
        createdById: userId,
      },
    });
  }

  async updateBudget(id: number, data: UpdateBudgetDto) {
    return this.prisma.budget.update({
      where: { id },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.totalAmount !== undefined
          ? { totalAmount: data.totalAmount }
          : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.currency !== undefined ? { currency: data.currency } : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.fiscalYear !== undefined
          ? { fiscalYear: parseInt(data.fiscalYear, 10) }
          : {}),
        ...(data.startDate !== undefined
          ? { startDate: data.startDate ? new Date(data.startDate) : null }
          : {}),
        ...(data.endDate !== undefined
          ? { endDate: data.endDate ? new Date(data.endDate) : null }
          : {}),
        ...(data.notes !== undefined ? { notes: data.notes } : {}),
      },
    });
  }

  async deleteBudget(id: number) {
    return this.prisma.budget.delete({ where: { id } });
  }

  async getBudgetSummary(projectId?: number) {
    const budgets = await this.prisma.budget.findMany({
      where: projectId ? { projectId } : {},
      include: { lineItems: true },
    });
    const expenses = await this.prisma.expense.findMany({
      where: projectId ? { projectId } : {},
    });

    const totalBudget = budgets.reduce((s, b) => s + Number(b.totalAmount), 0);
    const totalSpent = expenses.reduce((s, e) => s + Number(e.amount), 0);

    return {
      totalBudget,
      totalSpent,
      remaining: totalBudget - totalSpent,
      utilizationRate: totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0,
      budgetCount: budgets.length,
      expenseCount: expenses.length,
    };
  }

  // ==================== Cost Estimates ====================

  async getCostEstimates(projectId?: number, phase?: string) {
    return this.prisma.budgetLineItem.findMany({
      where: {
        ...(projectId ? { budget: { projectId } } : {}),
        ...(phase ? { category: phase } : {}),
      },
      include: { budget: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getCostEstimate(id: number) {
    const item = await this.prisma.budgetLineItem.findUnique({
      where: { id },
      include: { budget: true },
    });
    if (!item) throw new NotFoundException('Cost estimate not found');
    return item;
  }

  async createCostEstimate(data: CreateCostEstimateDto) {
    const budget = await this.prisma.budget.findFirst({
      where: { projectId: data.projectId },
    });
    if (!budget) throw new NotFoundException('No budget found for project');

    return this.prisma.budgetLineItem.create({
      data: {
        description: data.description ?? data.name,
        category: data.category ?? data.phase,
        estimatedAmount: data.estimatedAmount,
        budgetId: budget.id,
      },
    });
  }

  async updateCostEstimate(id: number, data: UpdateCostEstimateDto) {
    return this.prisma.budgetLineItem.update({
      where: { id },
      data: {
        ...(data.estimatedAmount !== undefined
          ? { estimatedAmount: data.estimatedAmount }
          : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
      },
    });
  }

  async deleteCostEstimate(id: number) {
    return this.prisma.budgetLineItem.delete({ where: { id } });
  }

  // ==================== Expenses ====================

  async getExpenses(projectId?: number, budgetId?: number) {
    return this.prisma.expense.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(budgetId ? { budgetId } : {}),
      },
      include: {
        project: { select: { id: true, title: true } },
        submittedBy: { select: { id: true, name: true } },
        approvedBy: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getExpenseById(id: number) {
    const expense = await this.prisma.expense.findUnique({
      where: { id },
      include: {
        project: true,
        submittedBy: { select: { id: true, name: true } },
        approvedBy: { select: { id: true, name: true } },
      },
    });
    if (!expense) throw new NotFoundException('Expense not found');
    return expense;
  }

  async createExpense(data: CreateExpenseDto, userId: number) {
    return this.prisma.expense.create({
      data: {
        description: data.description,
        amount: data.amount,
        projectId: data.projectId,
        budgetId: data.budgetId,
        category: data.category,
        vendor: data.vendor,
        paymentMethod: data.paymentMethod,
        notes: data.vendor,
        receiptUrl: data.receipts?.[0],
        submittedById: userId,
      },
    });
  }

  async updateExpense(id: number, data: UpdateExpenseDto) {
    return this.prisma.expense.update({
      where: { id },
      data: {
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.amount !== undefined ? { amount: data.amount } : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.vendor !== undefined
          ? { vendor: data.vendor, notes: data.vendor }
          : {}),
        ...(data.paymentMethod !== undefined
          ? { paymentMethod: data.paymentMethod }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.rejectionReason !== undefined
          ? { rejectionReason: data.rejectionReason }
          : {}),
      },
    });
  }

  async deleteExpense(id: number) {
    return this.prisma.expense.delete({ where: { id } });
  }

  async approveExpense(id: number, userId: number, notes?: string) {
    return this.prisma.expense.update({
      where: { id },
      data: {
        status: 'APPROVED',
        approvedById: userId,
        approvedAt: new Date(),
      },
    });
  }

  async rejectExpense(id: number, reason: string) {
    return this.prisma.expense.update({
      where: { id },
      data: { status: 'REJECTED' },
    });
  }

  // ==================== Invoices ====================

  async getInvoices(projectId?: number) {
    return this.prisma.budgetInvoice.findMany({
      where: projectId ? { projectId } : {},
      include: {
        payments: true,
        _count: { select: { payments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getInvoiceById(id: number) {
    const invoice = await this.prisma.budgetInvoice.findUnique({
      where: { id },
      include: { payments: { orderBy: { paidAt: 'desc' } }, project: true },
    });
    if (!invoice) throw new NotFoundException('Invoice not found');
    return invoice;
  }

  async createInvoice(data: CreateInvoiceDto, userId: number) {
    return this.prisma.budgetInvoice.create({
      data: {
        invoiceNumber: data.invoiceNumber,
        title: data.title ?? `Invoice ${data.invoiceNumber}`,
        amount: data.amount,
        tax: data.tax ?? 0,
        totalAmount: data.totalAmount ?? data.amount,
        description: data.description,
        projectId: data.projectId,
        dueDate: data.dueDate ? new Date(data.dueDate) : new Date(),
        items: data.items,
        subtotal: data.subtotal,
        taxRate: data.taxRate,
        discount: data.discount,
        terms: data.terms,
        createdById: userId,
      },
    });
  }

  async updateInvoice(id: number, data: UpdateInvoiceDto) {
    return this.prisma.budgetInvoice.update({
      where: { id },
      data: {
        ...(data.invoiceNumber !== undefined
          ? { invoiceNumber: data.invoiceNumber }
          : {}),
        ...(data.amount !== undefined ? { amount: data.amount } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.status !== undefined ? { status: data.status } : {}),
        ...(data.dueDate ? { dueDate: new Date(data.dueDate) } : {}),
        ...(data.items !== undefined ? { items: data.items } : {}),
        ...(data.subtotal !== undefined ? { subtotal: data.subtotal } : {}),
        ...(data.taxRate !== undefined ? { taxRate: data.taxRate } : {}),
        ...(data.discount !== undefined ? { discount: data.discount } : {}),
        ...(data.terms !== undefined ? { terms: data.terms } : {}),
      },
    });
  }

  async deleteInvoice(id: number) {
    return this.prisma.budgetInvoice.delete({ where: { id } });
  }

  async sendInvoice(id: number) {
    return this.prisma.budgetInvoice.update({
      where: { id },
      data: { status: 'SENT' },
    });
  }

  async recordPayment(
    invoiceId: number,
    data: RecordPaymentDto,
    userId: number,
  ) {
    const payment = await this.prisma.budgetPayment.create({
      data: {
        invoiceId,
        amount: data.amount,
        method: data.method,
        reference: data.reference,
        paidById: userId,
        paidAt: data.paidAt ? new Date(data.paidAt) : new Date(),
      },
    });

    // Check if invoice is fully paid
    const payments = await this.prisma.budgetPayment.findMany({
      where: { invoiceId },
    });
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
    const invoice = await this.prisma.budgetInvoice.findUnique({
      where: { id: invoiceId },
    });
    if (invoice && totalPaid >= Number(invoice.amount)) {
      await this.prisma.budgetInvoice.update({
        where: { id: invoiceId },
        data: { status: 'PAID', paidAt: new Date() },
      });
    }

    return payment;
  }

  async getInvoicePayments(invoiceId: number) {
    return this.prisma.budgetPayment.findMany({
      where: { invoiceId },
      orderBy: { paidAt: 'desc' },
    });
  }

  // ==================== Reports ====================

  async getCostReport(projectId: number) {
    const [budgets, expenses, invoices] = await Promise.all([
      this.prisma.budget.findMany({ where: { projectId } }),
      this.prisma.expense.findMany({ where: { projectId } }),
      this.prisma.budgetInvoice.findMany({ where: { projectId } }),
    ]);

    return {
      totalBudget: budgets.reduce((s, b) => s + Number(b.totalAmount), 0),
      totalExpenses: expenses.reduce((s, e) => s + Number(e.amount), 0),
      totalInvoiced: invoices.reduce((s, i) => s + Number(i.amount), 0),
      expensesByCategory: this.groupBy(expenses, 'category', 'amount'),
    };
  }

  async getCashFlowProjection(projectId: number, months: number) {
    const cashFlows = await this.prisma.cashFlow.findMany({
      where: { projectId },
      orderBy: { date: 'asc' },
    });
    return cashFlows;
  }

  async exportBudgetReport(projectId: number) {
    return this.getCostReport(projectId);
  }

  async exportExpenseReport(projectId: number) {
    return this.getExpenses(projectId);
  }

  private groupBy(items: any[], key: string, sumField: string) {
    return Object.entries(
      items.reduce(
        (acc, item) => {
          const k = item[key] || 'Other';
          acc[k] = (acc[k] || 0) + (item[sumField] || 0);
          return acc;
        },
        {} as Record<string, number>,
      ),
    ).map(([category, total]) => ({ category, total }));
  }
}
