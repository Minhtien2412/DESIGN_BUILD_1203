import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { BudgetService } from './budget.service';
import {
    CreateBudgetDto,
    CreateCostEstimateDto,
    CreateExpenseDto,
    CreateInvoiceDto,
    RecordPaymentDto,
    UpdateBudgetDto,
    UpdateCostEstimateDto,
    UpdateExpenseDto,
    UpdateInvoiceDto,
} from './dto';

@ApiTags('Budget')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'budget', version: '1' })
export class BudgetController {
  constructor(private readonly service: BudgetService) {}

  // ==================== Budgets ====================

  @Get('budgets')
  @ApiOperation({ summary: 'List budgets for a project' })
  @ApiQuery({ name: 'projectId', required: false })
  getBudgets(@Query('projectId') projectId?: string) {
    return this.service.getBudgets(projectId ? +projectId : undefined);
  }

  @Get('budgets/summary')
  @ApiOperation({ summary: 'Get budget summary' })
  @ApiQuery({ name: 'projectId', required: false })
  getBudgetSummary(@Query('projectId') projectId?: string) {
    return this.service.getBudgetSummary(projectId ? +projectId : undefined);
  }

  @Get('budgets/:id')
  @ApiOperation({ summary: 'Get budget by ID' })
  getBudget(@Param('id', ParseIntPipe) id: number) {
    return this.service.getBudgetById(id);
  }

  @Post('budgets')
  @ApiOperation({ summary: 'Create budget' })
  createBudget(@Body() dto: CreateBudgetDto, @Req() req: any) {
    return this.service.createBudget(dto, req.user?.id);
  }

  @Put('budgets/:id')
  @ApiOperation({ summary: 'Update budget' })
  updateBudget(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateBudgetDto,
  ) {
    return this.service.updateBudget(id, dto);
  }

  @Delete('budgets/:id')
  @ApiOperation({ summary: 'Delete budget' })
  deleteBudget(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteBudget(id);
  }

  // ==================== Cost Estimates ====================

  @Get('estimates')
  @ApiOperation({ summary: 'List cost estimates' })
  @ApiQuery({ name: 'projectId', required: true })
  @ApiQuery({ name: 'phaseId', required: false })
  getEstimates(
    @Query('projectId') projectId: string,
    @Query('phaseId') phaseId?: string,
  ) {
    return this.service.getCostEstimates(+projectId, phaseId);
  }

  @Get('estimates/:id')
  @ApiOperation({ summary: 'Get cost estimate by ID' })
  getEstimate(@Param('id', ParseIntPipe) id: number) {
    return this.service.getCostEstimate(id);
  }

  @Post('estimates')
  @ApiOperation({ summary: 'Create cost estimate' })
  createEstimate(@Body() dto: CreateCostEstimateDto) {
    return this.service.createCostEstimate(dto);
  }

  @Put('estimates/:id')
  @ApiOperation({ summary: 'Update cost estimate' })
  updateEstimate(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateCostEstimateDto,
  ) {
    return this.service.updateCostEstimate(id, dto);
  }

  @Delete('estimates/:id')
  @ApiOperation({ summary: 'Delete cost estimate' })
  deleteEstimate(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteCostEstimate(id);
  }

  // ==================== Expenses ====================

  @Get('expenses')
  @ApiOperation({ summary: 'List expenses' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'budgetId', required: false })
  getExpenses(
    @Query('projectId') projectId?: string,
    @Query('budgetId') budgetId?: string,
  ) {
    return this.service.getExpenses(
      projectId ? +projectId : undefined,
      budgetId ? +budgetId : undefined,
    );
  }

  @Get('expenses/:id')
  @ApiOperation({ summary: 'Get expense by ID' })
  getExpense(@Param('id', ParseIntPipe) id: number) {
    return this.service.getExpenseById(id);
  }

  @Post('expenses')
  @ApiOperation({ summary: 'Create expense' })
  createExpense(@Body() dto: CreateExpenseDto, @Req() req: any) {
    return this.service.createExpense(dto, req.user?.id);
  }

  @Put('expenses/:id')
  @ApiOperation({ summary: 'Update expense' })
  updateExpense(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateExpenseDto,
  ) {
    return this.service.updateExpense(id, dto);
  }

  @Delete('expenses/:id')
  @ApiOperation({ summary: 'Delete expense' })
  deleteExpense(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteExpense(id);
  }

  @Post('expenses/:id/approve')
  @ApiOperation({ summary: 'Approve expense' })
  approveExpense(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() body: { notes?: string },
  ) {
    return this.service.approveExpense(id, req.user?.id, body.notes);
  }

  @Post('expenses/:id/reject')
  @ApiOperation({ summary: 'Reject expense' })
  rejectExpense(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { reason: string },
  ) {
    return this.service.rejectExpense(id, body.reason);
  }

  // ==================== Invoices ====================

  @Get('invoices')
  @ApiOperation({ summary: 'List invoices' })
  @ApiQuery({ name: 'projectId', required: false })
  getInvoices(@Query('projectId') projectId?: string) {
    return this.service.getInvoices(projectId ? +projectId : undefined);
  }

  @Get('invoices/:id')
  @ApiOperation({ summary: 'Get invoice by ID' })
  getInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.service.getInvoiceById(id);
  }

  @Post('invoices')
  @ApiOperation({ summary: 'Create invoice' })
  createInvoice(@Body() dto: CreateInvoiceDto, @Req() req: any) {
    const userId = req.user?.id ?? req.user?.sub;
    return this.service.createInvoice(dto, userId);
  }

  @Put('invoices/:id')
  @ApiOperation({ summary: 'Update invoice' })
  updateInvoice(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateInvoiceDto,
  ) {
    return this.service.updateInvoice(id, dto);
  }

  @Delete('invoices/:id')
  @ApiOperation({ summary: 'Delete invoice' })
  deleteInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteInvoice(id);
  }

  @Post('invoices/:id/send')
  @ApiOperation({ summary: 'Send invoice' })
  sendInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.service.sendInvoice(id);
  }

  @Post('invoices/:id/payments')
  @ApiOperation({ summary: 'Record payment for invoice' })
  recordPayment(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RecordPaymentDto,
    @Req() req: any,
  ) {
    const userId = req.user?.id ?? req.user?.sub;
    return this.service.recordPayment(id, dto, userId);
  }

  @Get('invoices/:id/payments')
  @ApiOperation({ summary: 'Get invoice payments' })
  getPayments(@Param('id', ParseIntPipe) id: number) {
    return this.service.getInvoicePayments(id);
  }

  @Get('invoices/:id/pdf')
  @ApiOperation({ summary: 'Download invoice PDF' })
  downloadPdf(@Param('id', ParseIntPipe) id: number) {
    return this.service.getInvoiceById(id);
  }

  // ==================== Reports ====================

  @Get('reports/cost')
  @ApiOperation({ summary: 'Get cost report' })
  @ApiQuery({ name: 'projectId', required: true })
  getCostReport(@Query('projectId') projectId: string) {
    return this.service.getCostReport(+projectId);
  }

  @Get('reports/cashflow')
  @ApiOperation({ summary: 'Get cash flow projection' })
  @ApiQuery({ name: 'projectId', required: true })
  @ApiQuery({ name: 'months', required: false })
  getCashFlow(
    @Query('projectId') projectId: string,
    @Query('months') months?: string,
  ) {
    return this.service.getCashFlowProjection(
      +projectId,
      months ? +months : 12,
    );
  }

  @Get('reports/budget/export')
  @ApiOperation({ summary: 'Export budget report' })
  @ApiQuery({ name: 'projectId', required: true })
  exportBudget(@Query('projectId') projectId: string) {
    return this.service.exportBudgetReport(+projectId);
  }

  @Get('reports/expenses/export')
  @ApiOperation({ summary: 'Export expense report' })
  @ApiQuery({ name: 'projectId', required: true })
  exportExpenses(@Query('projectId') projectId: string) {
    return this.service.exportExpenseReport(+projectId);
  }
}
