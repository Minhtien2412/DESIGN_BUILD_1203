/**
 * Chat Attachment Controller
 * ==========================
 *
 * REST endpoints for chat attachments (MSG-005)
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    AttachmentType,
    ChatAttachmentService,
} from './chat-attachment.service';

// ============================================================================
// DTOs
// ============================================================================

class RequestAttachmentUploadDto {
  conversationId: string;
  filename: string;
  contentType: string;
  size: number;
  checksum?: string;
}

class CompleteAttachmentUploadDto {
  uploadId: string;
  checksum?: string;
  metadata?: {
    duration?: number;
    width?: number;
    height?: number;
    waveform?: number[];
  };
}

class RequestVoiceUploadDto {
  conversationId: string;
  duration: number;
  waveform?: number[];
}

// ============================================================================
// CONTROLLER
// ============================================================================

@ApiTags('Chat Attachments')
@ApiBearerAuth()
@Controller('chat/attachments')
@UseGuards(JwtAuthGuard)
export class ChatAttachmentController {
  constructor(private readonly attachmentService: ChatAttachmentService) {}

  /**
   * Request presigned URL for attachment upload
   */
  @Post('upload/request')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Request presigned URL for attachment upload' })
  @ApiResponse({ status: 200, description: 'Upload URL generated' })
  async requestUpload(
    @CurrentUser('id') userId: number,
    @Body() dto: RequestAttachmentUploadDto,
  ) {
    const result = await this.attachmentService.requestAttachmentUpload(
      userId,
      dto,
    );
    return {
      success: true,
      data: result,
    };
  }

  /**
   * Complete attachment upload
   */
  @Post('upload/complete')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Complete attachment upload and get final URL' })
  @ApiResponse({ status: 200, description: 'Upload completed' })
  async completeUpload(
    @CurrentUser('id') userId: number,
    @Body() dto: CompleteAttachmentUploadDto,
  ) {
    const attachment = await this.attachmentService.completeAttachmentUpload(
      userId,
      dto.uploadId,
      dto.checksum,
      dto.metadata,
    );
    return {
      success: true,
      data: { attachment },
    };
  }

  /**
   * Request voice message upload
   */
  @Post('voice/request')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Request presigned URL for voice message upload' })
  @ApiResponse({ status: 200, description: 'Voice upload URL generated' })
  async requestVoiceUpload(
    @CurrentUser('id') userId: number,
    @Body() dto: RequestVoiceUploadDto,
  ) {
    const result = await this.attachmentService.requestVoiceMessageUpload(
      userId,
      dto.conversationId,
      dto.duration,
      dto.waveform,
    );
    return {
      success: true,
      data: result,
    };
  }

  /**
   * Get attachments for a conversation
   */
  @Get('conversation/:conversationId')
  @ApiOperation({ summary: 'Get attachments for a conversation' })
  @ApiQuery({ name: 'type', required: false, enum: AttachmentType })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'cursor', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Attachments retrieved' })
  async getConversationAttachments(
    @CurrentUser('id') userId: number,
    @Param('conversationId') conversationId: string,
    @Query('type') type?: AttachmentType,
    @Query('limit') limit?: string,
    @Query('cursor') cursor?: string,
  ) {
    const result = await this.attachmentService.getConversationAttachments(
      userId,
      conversationId,
      {
        type,
        limit: limit ? parseInt(limit, 10) : undefined,
        cursor,
      },
    );
    return {
      success: true,
      data: result,
    };
  }

  /**
   * Delete attachment from message
   */
  @Delete('message/:messageId/:attachmentId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete attachment from message' })
  @ApiResponse({ status: 200, description: 'Attachment deleted' })
  async deleteAttachment(
    @CurrentUser('id') userId: number,
    @Param('messageId') messageId: string,
    @Param('attachmentId') attachmentId: string,
  ) {
    await this.attachmentService.deleteAttachment(
      userId,
      messageId,
      attachmentId,
    );
    return {
      success: true,
      message: 'Attachment deleted',
    };
  }
}
