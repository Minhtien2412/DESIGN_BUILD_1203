import {
    Injectable,
    NotFoundException,
    UnprocessableEntityException,
} from '@nestjs/common';
import { MarketplaceGovernanceService } from '../marketplace-governance/governance.service';
import { GovernancePersistenceService } from '../marketplace-governance/services/governance-persistence.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRoomDto, SendMessageDto } from './dto';

@Injectable()
export class ChatService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly marketplaceGovernanceService: MarketplaceGovernanceService,
    private readonly governancePersistenceService: GovernancePersistenceService,
  ) {}

  // Tạo chat room cho project
  async createRoom(createRoomDto: CreateRoomDto, userId: number) {
    const { projectId, name } = createRoomDto;

    // Kiểm tra project tồn tại
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { client: true, engineer: true },
    });

    if (!project) {
      throw new NotFoundException(`Project với ID ${projectId} không tồn tại`);
    }

    // Tạo chat room
    const room = await this.prisma.chatRoom.create({
      data: {
        name,
        projectId,
        members: {
          create: [
            ...(project.clientId ? [{ userId: project.clientId }] : []),
            ...(project.engineerId ? [{ userId: project.engineerId }] : []),
          ],
        },
      },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    return {
      ...room,
      members: room.members.map((m) => m.user),
    };
  }

  // Gửi tin nhắn
  async sendMessage(sendMessageDto: SendMessageDto, senderId: number) {
    const { roomId, content, attachments } = sendMessageDto;

    // Kiểm tra room tồn tại và user là thành viên
    const room = await this.prisma.chatRoom.findFirst({
      where: {
        id: roomId,
        members: {
          some: {
            userId: senderId,
          },
        },
      },
    });

    if (!room) {
      throw new NotFoundException(
        `Chat room với ID ${roomId} không tồn tại hoặc bạn không phải thành viên`,
      );
    }

    const recentMessages = await this.prisma.chatMessage.findMany({
      where: {
        roomId,
        senderId,
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { content: true },
    });

    const moderationResponse =
      await this.marketplaceGovernanceService.moderateMessage({
        senderId,
        message: content,
        recentMessages: recentMessages.map((message) => message.content),
      });

    const moderationLog =
      await this.governancePersistenceService.createMessageModerationLog({
        conversationId: `chat-room-${roomId}`,
        senderId,
        message: content,
        moderation: moderationResponse.moderation,
      });

    if (moderationResponse.reviewQueue.length > 0) {
      await this.governancePersistenceService.createModerationReviewQueueItems({
        moderationLogId: moderationLog.id,
        reviewQueue: moderationResponse.reviewQueue,
      });
    }

    if (!moderationResponse.allowSend) {
      throw new UnprocessableEntityException({
        message:
          'Tin nhắn không thể gửi do vi phạm chính sách giao dịch trên nền tảng',
        decision: moderationResponse.moderation.decision,
        moderation: moderationResponse.moderation,
        reviewQueue: moderationResponse.reviewQueue,
        moderationLogId: moderationLog.id,
      });
    }

    const message = await this.prisma.chatMessage.create({
      data: {
        roomId,
        senderId,
        content,
        attachments: attachments || [],
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        readStatus: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    return {
      ...message,
      readBy: message.readStatus.map((rs) => ({
        userId: rs.userId,
        readAt: rs.readAt,
      })),
    };
  }

  // Đánh dấu tin nhắn đã đọc
  async markAsRead(messageId: number, userId: number) {
    // Kiểm tra tin nhắn tồn tại
    const message = await this.prisma.chatMessage.findUnique({
      where: { id: messageId },
      include: {
        room: {
          include: {
            members: true,
          },
        },
      },
    });

    if (!message) {
      throw new NotFoundException(`Tin nhắn với ID ${messageId} không tồn tại`);
    }

    // Kiểm tra user là thành viên của room
    const isMember = message.room.members.some((m) => m.userId === userId);
    if (!isMember) {
      throw new NotFoundException(
        'Bạn không phải thành viên của chat room này',
      );
    }

    // Tạo hoặc update read status
    const readStatus = await this.prisma.messageReadStatus.upsert({
      where: {
        messageId_userId: {
          messageId,
          userId,
        },
      },
      create: {
        messageId,
        userId,
      },
      update: {
        readAt: new Date(),
      },
    });

    return readStatus;
  }

  // Lấy danh sách tin nhắn trong room
  async getRoomMessages(
    roomId: number,
    userId: number,
    limit = 50,
    offset = 0,
  ) {
    // Kiểm tra user là thành viên
    const room = await this.prisma.chatRoom.findFirst({
      where: {
        id: roomId,
        members: {
          some: {
            userId,
          },
        },
      },
    });

    if (!room) {
      throw new NotFoundException(
        `Chat room với ID ${roomId} không tồn tại hoặc bạn không phải thành viên`,
      );
    }

    const messages = await this.prisma.chatMessage.findMany({
      where: { roomId },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        readStatus: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });

    return messages.map((msg) => ({
      ...msg,
      readBy: msg.readStatus.map((rs) => ({
        userId: rs.userId,
        readAt: rs.readAt,
      })),
    }));
  }

  // Lấy danh sách chat rooms của user
  async getUserRooms(userId: number) {
    const rooms = await this.prisma.chatRoom.findMany({
      where: {
        members: {
          some: {
            userId,
          },
        },
      },
      include: {
        project: {
          select: {
            id: true,
            title: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          include: {
            sender: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
      orderBy: {
        updatedAt: 'desc',
      },
    });

    return rooms.map((room) => ({
      ...room,
      members: room.members.map((m) => m.user),
      lastMessage: room.messages[0] || null,
    }));
  }

  // Thêm thành viên vào room
  async addMemberToRoom(roomId: number, userId: number, newMemberId: number) {
    // Kiểm tra room tồn tại và user có quyền (là thành viên)
    const room = await this.prisma.chatRoom.findFirst({
      where: {
        id: roomId,
        members: {
          some: {
            userId,
          },
        },
      },
    });

    if (!room) {
      throw new NotFoundException(
        `Chat room với ID ${roomId} không tồn tại hoặc bạn không có quyền`,
      );
    }

    // Thêm member
    const member = await this.prisma.chatRoomMember.create({
      data: {
        roomId,
        userId: newMemberId,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });

    return member.user;
  }
}
