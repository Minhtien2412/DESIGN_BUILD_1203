/**
 * Chat Attachment Service (MSG-005)
 * ==================================
 *
 * Handles file attachments in chat messages:
 * - Upload validation and processing
 * - Thumbnail generation for images/videos
 * - Voice message handling
 * - Attachment type detection
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { FileContext } from '../upload/dto/presigned-upload.dto';
import { PresignedUploadService } from '../upload/presigned-upload.service';

// ============================================================================
// TYPES
// ============================================================================

export enum AttachmentType {
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  FILE = 'FILE',
  VOICE = 'VOICE',
  AUDIO = 'AUDIO',
}

export interface ChatAttachment {
  id: string;
  type: AttachmentType;
  url: string;
  thumbnailUrl?: string;
  filename: string;
  mimeType: string;
  size: number;
  duration?: number; // for audio/video in seconds
  width?: number; // for images/videos
  height?: number; // for images/videos
  waveform?: number[]; // for voice messages
  createdAt: Date;
}

export interface CreateAttachmentDto {
  conversationId: string;
  type: AttachmentType;
  filename: string;
  mimeType: string;
  size: number;
  duration?: number;
  width?: number;
  height?: number;
  waveform?: number[];
}

export interface AttachmentUploadRequest {
  conversationId: string;
  filename: string;
  contentType: string;
  size: number;
  checksum?: string;
}

export interface AttachmentUploadResponse {
  uploadId: string;
  presignedUrl: string;
  attachment: Partial<ChatAttachment>;
  expiresAt: string;
}

// ============================================================================
// SERVICE
// ============================================================================

@Injectable()
export class ChatAttachmentService {
  private readonly logger = new Logger(ChatAttachmentService.name);

  // Allowed MIME types by category
  private readonly allowedTypes = {
    image: [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/heic',
      'image/heif',
    ],
    video: ['video/mp4', 'video/webm', 'video/quicktime', 'video/3gpp'],
    audio: [
      'audio/mpeg',
      'audio/wav',
      'audio/ogg',
      'audio/m4a',
      'audio/aac',
      'audio/webm',
    ],
    voice: ['audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/wav'],
    file: [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/zip',
      'application/x-rar-compressed',
      'text/plain',
      'text/csv',
    ],
  };

  // Size limits by type (in bytes)
  private readonly sizeLimits = {
    image: 10 * 1024 * 1024, // 10MB
    video: 100 * 1024 * 1024, // 100MB
    audio: 25 * 1024 * 1024, // 25MB
    voice: 10 * 1024 * 1024, // 10MB (voice notes limited)
    file: 50 * 1024 * 1024, // 50MB
  };

  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
    private presignedUploadService: PresignedUploadService,
  ) {}

  // ============================================
  // ATTACHMENT TYPE DETECTION
  // ============================================

  /**
   * Detect attachment type from MIME type
   */
  detectAttachmentType(mimeType: string, isVoiceNote = false): AttachmentType {
    if (isVoiceNote && this.allowedTypes.voice.includes(mimeType)) {
      return AttachmentType.VOICE;
    }

    if (this.allowedTypes.image.includes(mimeType)) {
      return AttachmentType.IMAGE;
    }

    if (this.allowedTypes.video.includes(mimeType)) {
      return AttachmentType.VIDEO;
    }

    if (this.allowedTypes.audio.includes(mimeType)) {
      return AttachmentType.AUDIO;
    }

    if (this.allowedTypes.file.includes(mimeType)) {
      return AttachmentType.FILE;
    }

    // Default to FILE for unknown types
    return AttachmentType.FILE;
  }

  /**
   * Validate attachment file
   */
  validateAttachment(
    mimeType: string,
    size: number,
    type?: AttachmentType,
  ): { valid: boolean; error?: string; type: AttachmentType } {
    const detectedType = type || this.detectAttachmentType(mimeType);

    // Check if type is allowed
    const typeCategory =
      detectedType.toLowerCase() as keyof typeof this.sizeLimits;
    const sizeLimit = this.sizeLimits[typeCategory] || this.sizeLimits.file;

    // Check all allowed types
    const allAllowedTypes = [
      ...this.allowedTypes.image,
      ...this.allowedTypes.video,
      ...this.allowedTypes.audio,
      ...this.allowedTypes.file,
    ];

    if (!allAllowedTypes.includes(mimeType)) {
      return {
        valid: false,
        error: `File type ${mimeType} is not allowed`,
        type: detectedType,
      };
    }

    // Check size limit
    if (size > sizeLimit) {
      const limitMB = Math.round(sizeLimit / (1024 * 1024));
      return {
        valid: false,
        error: `File too large. Maximum size for ${detectedType} is ${limitMB}MB`,
        type: detectedType,
      };
    }

    return { valid: true, type: detectedType };
  }

  // ============================================
  // UPLOAD FLOW
  // ============================================

  /**
   * Request presigned URL for attachment upload
   */
  async requestAttachmentUpload(
    userId: number,
    request: AttachmentUploadRequest,
  ): Promise<AttachmentUploadResponse> {
    const { conversationId, filename, contentType, size, checksum } = request;

    // Validate conversation access
    await this.validateConversationAccess(userId, conversationId);

    // Validate attachment
    const validation = this.validateAttachment(contentType, size);
    if (!validation.valid) {
      throw new BadRequestException(validation.error);
    }

    // Request presigned URL
    const presignResult =
      await this.presignedUploadService.requestPresignedUpload(userId, {
        filename,
        contentType,
        size,
        checksum,
        checksumAlgorithm: checksum ? 'sha256' : undefined,
        context: FileContext.CONVERSATION,
        contextId: undefined, // Will be stored separately
        folder: `chat-attachments/${conversationId}`,
      });

    // Create pending attachment record
    const attachmentId = `att_${Date.now()}_${Math.random().toString(36).slice(2)}`;

    return {
      uploadId: presignResult.uploadId,
      presignedUrl: presignResult.uploadUrl,
      attachment: {
        id: attachmentId,
        type: validation.type,
        filename,
        mimeType: contentType,
        size,
      },
      expiresAt: presignResult.expiresAt.toISOString(),
    };
  }

  /**
   * Complete attachment upload and get final URL
   */
  async completeAttachmentUpload(
    userId: number,
    uploadId: string,
    checksum?: string,
    metadata?: {
      duration?: number;
      width?: number;
      height?: number;
      waveform?: number[];
    },
  ): Promise<ChatAttachment> {
    // Complete presigned upload
    const completeResult =
      await this.presignedUploadService.completePresignedUpload(userId, {
        uploadId,
        checksum: checksum || '',
      });

    // Determine type from mimetype
    const type = this.detectAttachmentType(completeResult.contentType);

    // Generate thumbnail URL if applicable
    let thumbnailUrl: string | undefined;
    if (type === AttachmentType.IMAGE || type === AttachmentType.VIDEO) {
      // For now, use the same URL - thumbnail service can process later
      thumbnailUrl = completeResult.url;
    }

    const attachment: ChatAttachment = {
      id: `att_${Date.now()}`,
      type,
      url: completeResult.url,
      thumbnailUrl,
      filename: completeResult.filename,
      mimeType: completeResult.contentType,
      size: completeResult.size,
      duration: metadata?.duration,
      width: metadata?.width,
      height: metadata?.height,
      waveform: metadata?.waveform,
      createdAt: new Date(),
    };

    this.logger.log(`Attachment completed: ${attachment.id} (${type})`);

    return attachment;
  }

  // ============================================
  // VOICE MESSAGE HELPERS
  // ============================================

  /**
   * Request upload URL for voice message
   */
  async requestVoiceMessageUpload(
    userId: number,
    conversationId: string,
    duration: number,
    waveform?: number[],
  ): Promise<AttachmentUploadResponse> {
    const filename = `voice_${Date.now()}.webm`;
    const estimatedSize = Math.ceil(duration * 8000); // ~8KB per second

    const result = await this.requestAttachmentUpload(userId, {
      conversationId,
      filename,
      contentType: 'audio/webm',
      size: estimatedSize,
    });

    return {
      ...result,
      attachment: {
        ...result.attachment,
        type: AttachmentType.VOICE,
        duration,
        waveform,
      },
    };
  }

  // ============================================
  // CONVERSATION ACCESS
  // ============================================

  /**
   * Validate user has access to conversation
   */
  private async validateConversationAccess(
    userId: number,
    conversationId: string,
  ): Promise<void> {
    const participant = await this.prisma.conversationParticipant.findFirst({
      where: {
        conversationId,
        userId,
        leftAt: null,
        removedAt: null,
      },
    });

    if (!participant) {
      throw new NotFoundException('Conversation not found or access denied');
    }
  }

  // ============================================
  // ATTACHMENT MANAGEMENT
  // ============================================

  /**
   * Get attachments for a conversation
   */
  async getConversationAttachments(
    userId: number,
    conversationId: string,
    options: {
      type?: AttachmentType;
      limit?: number;
      cursor?: string;
    } = {},
  ) {
    await this.validateConversationAccess(userId, conversationId);

    const { type, limit = 50, cursor } = options;

    // Query messages with attachments
    const messages = await this.prisma.conversationMessage.findMany({
      where: {
        conversationId,
        isDeleted: false,
        attachments: { not: Prisma.JsonNull },
        ...(type && {
          type: type as any,
        }),
        ...(cursor && {
          sentAt: { lt: new Date(cursor) },
        }),
      },
      orderBy: { sentAt: 'desc' },
      take: limit,
      select: {
        id: true,
        attachments: true,
        type: true,
        sentAt: true,
        senderId: true,
      },
    });

    // Extract attachments from messages
    const attachments = messages
      .filter((m) => m.attachments)
      .flatMap((m) => {
        const atts = m.attachments as unknown as ChatAttachment[];
        return atts.map((att) => ({
          ...att,
          messageId: m.id,
          senderId: m.senderId,
          senderName: '',
          sentAt: m.sentAt,
        }));
      });

    const nextCursor =
      messages.length === limit
        ? messages[messages.length - 1].sentAt.toISOString()
        : null;

    return {
      attachments,
      nextCursor,
      hasMore: !!nextCursor,
    };
  }

  /**
   * Delete attachment from message
   */
  async deleteAttachment(
    userId: number,
    messageId: string,
    attachmentId: string,
  ): Promise<void> {
    const message = await this.prisma.conversationMessage.findFirst({
      where: {
        id: messageId,
        senderId: userId,
        isDeleted: false,
      },
    });

    if (!message) {
      throw new NotFoundException('Message not found or not authorized');
    }

    const attachments =
      (message.attachments as unknown as ChatAttachment[]) || [];
    const updatedAttachments = attachments.filter((a) => a.id !== attachmentId);

    await this.prisma.conversationMessage.update({
      where: { id: messageId },
      data: { attachments: updatedAttachments as unknown as Prisma.JsonArray },
    });

    this.logger.log(
      `Attachment deleted: ${attachmentId} from message ${messageId}`,
    );
  }
}
