/**
 * Message Search Service (MSG-006)
 * =================================
 *
 * Full-text search across chat messages
 * - Search by keyword
 * - Filter by conversation, date, attachment type
 * - Highlight matching text
 * - Pagination with cursor
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

// ============================================================================
// TYPES
// ============================================================================

export interface SearchMessagesDto {
  query: string;
  conversationId?: string;
  senderId?: number;
  dateFrom?: Date;
  dateTo?: Date;
  hasAttachment?: boolean;
  attachmentType?: 'IMAGE' | 'VIDEO' | 'FILE' | 'VOICE';
  limit?: number;
  cursor?: string;
}

export interface MessageSearchResult {
  id: string;
  conversationId: string;
  content: string;
  highlightedContent: string;
  type: string;
  senderId: number;
  senderName: string;
  senderAvatar?: string;
  sentAt: Date;
  matchCount: number;
  // Context
  conversationTitle?: string;
  hasAttachments: boolean;
  attachmentTypes?: string[];
}

export interface SearchResponse {
  results: MessageSearchResult[];
  total: number;
  nextCursor: string | null;
  hasMore: boolean;
  query: string;
  searchTime: number;
}

// ============================================================================
// SERVICE
// ============================================================================

@Injectable()
export class MessageSearchService {
  private readonly logger = new Logger(MessageSearchService.name);

  // Cache for search results (production: use Redis)
  private searchCache = new Map<
    string,
    { results: SearchResponse; timestamp: number }
  >();
  private readonly cacheTTL = 60 * 1000; // 1 minute

  constructor(private prisma: PrismaService) {}

  // ============================================
  // SEARCH
  // ============================================

  /**
   * Search messages with filters
   */
  async searchMessages(
    userId: number,
    dto: SearchMessagesDto,
  ): Promise<SearchResponse> {
    const startTime = Date.now();
    const {
      query,
      conversationId,
      senderId,
      dateFrom,
      dateTo,
      hasAttachment,
      attachmentType,
      limit = 20,
      cursor,
    } = dto;

    // Check cache
    const cacheKey = this.generateCacheKey(userId, dto);
    const cached = this.searchCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.results;
    }

    // Get user's accessible conversations
    const userConversationIds = await this.getUserConversationIds(userId);

    if (userConversationIds.length === 0) {
      return {
        results: [],
        total: 0,
        nextCursor: null,
        hasMore: false,
        query,
        searchTime: Date.now() - startTime,
      };
    }

    // Filter by specific conversation if provided
    const conversationFilter = conversationId
      ? [conversationId]
      : userConversationIds;

    // Build where clause
    const whereClause: Prisma.ConversationMessageWhereInput = {
      conversationId: { in: conversationFilter },
      isDeleted: false,
      // Full-text search on content
      content: {
        contains: query,
        mode: 'insensitive',
      },
      // Optional filters
      ...(senderId && { senderId }),
      ...(dateFrom && { sentAt: { gte: dateFrom } }),
      ...(dateTo && { sentAt: { lte: dateTo } }),
      ...(hasAttachment !== undefined && {
        attachments: hasAttachment
          ? { not: Prisma.DbNull }
          : { equals: Prisma.DbNull },
      }),
      ...(attachmentType && { type: attachmentType }),
      ...(cursor && { sentAt: { lt: new Date(cursor) } }),
    };

    // Count total matches
    const total = await this.prisma.conversationMessage.count({
      where: whereClause,
    });

    // Get results
    const messages = await this.prisma.conversationMessage.findMany({
      where: whereClause,
      orderBy: [{ sentAt: 'desc' }],
      take: limit + 1, // +1 to check hasMore
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        conversation: {
          select: {
            id: true,
            title: true,
            type: true,
          },
        },
      },
    });

    const hasMore = messages.length > limit;
    const resultMessages = hasMore ? messages.slice(0, limit) : messages;

    // Transform to search results
    const results: MessageSearchResult[] = resultMessages.map((msg) => {
      const { highlightedContent, matchCount } = this.highlightMatches(
        msg.content,
        query,
      );

      // Extract attachment types
      const attachments = msg.attachments as any[] | null;
      const attachmentTypes = attachments?.map((a) => a.type) || [];

      return {
        id: msg.id,
        conversationId: msg.conversationId,
        content: msg.content,
        highlightedContent,
        type: msg.type,
        senderId: msg.senderId,
        senderName: msg.sender.name || 'Unknown',
        senderAvatar: msg.sender.avatar || undefined,
        sentAt: msg.sentAt,
        matchCount,
        conversationTitle: msg.conversation.title || undefined,
        hasAttachments: !!attachments && attachments.length > 0,
        attachmentTypes:
          attachmentTypes.length > 0 ? attachmentTypes : undefined,
      };
    });

    const nextCursor = hasMore
      ? resultMessages[resultMessages.length - 1].sentAt.toISOString()
      : null;

    const response: SearchResponse = {
      results,
      total,
      nextCursor,
      hasMore,
      query,
      searchTime: Date.now() - startTime,
    };

    // Cache results
    this.searchCache.set(cacheKey, {
      results: response,
      timestamp: Date.now(),
    });

    this.logger.log(
      `Search "${query}" returned ${results.length}/${total} results in ${response.searchTime}ms`,
    );

    return response;
  }

  /**
   * Search messages within a specific conversation
   */
  async searchInConversation(
    userId: number,
    conversationId: string,
    query: string,
    limit = 20,
    cursor?: string,
  ): Promise<SearchResponse> {
    // Validate access
    await this.validateConversationAccess(userId, conversationId);

    return this.searchMessages(userId, {
      query,
      conversationId,
      limit,
      cursor,
    });
  }

  // ============================================
  // SEARCH SUGGESTIONS
  // ============================================

  /**
   * Get search suggestions based on partial query
   */
  async getSearchSuggestions(
    userId: number,
    partialQuery: string,
    limit = 5,
  ): Promise<string[]> {
    if (partialQuery.length < 2) {
      return [];
    }

    const userConversationIds = await this.getUserConversationIds(userId);

    // Get distinct words from recent messages
    const messages = await this.prisma.conversationMessage.findMany({
      where: {
        conversationId: { in: userConversationIds },
        isDeleted: false,
        content: {
          contains: partialQuery,
          mode: 'insensitive',
        },
      },
      orderBy: { sentAt: 'desc' },
      take: 100,
      select: { content: true },
    });

    // Extract matching words
    const regex = new RegExp(`\\b${this.escapeRegex(partialQuery)}\\w*`, 'gi');
    const wordSet = new Set<string>();

    messages.forEach((msg) => {
      const matches = msg.content.match(regex) || [];
      matches.forEach((word) => wordSet.add(word.toLowerCase()));
    });

    return Array.from(wordSet).slice(0, limit);
  }

  // ============================================
  // RECENT SEARCHES
  // ============================================

  /**
   * Save recent search (in-memory for now, production: user prefs in DB)
   */
  private userRecentSearches = new Map<number, string[]>();

  async saveRecentSearch(userId: number, query: string): Promise<void> {
    const searches = this.userRecentSearches.get(userId) || [];

    // Remove if exists, add to front
    const filtered = searches.filter(
      (s) => s.toLowerCase() !== query.toLowerCase(),
    );
    filtered.unshift(query);

    // Keep only last 10
    this.userRecentSearches.set(userId, filtered.slice(0, 10));
  }

  async getRecentSearches(userId: number): Promise<string[]> {
    return this.userRecentSearches.get(userId) || [];
  }

  async clearRecentSearches(userId: number): Promise<void> {
    this.userRecentSearches.delete(userId);
  }

  // ============================================
  // HELPERS
  // ============================================

  /**
   * Get all conversation IDs user has access to
   */
  private async getUserConversationIds(userId: number): Promise<string[]> {
    const participants = await this.prisma.conversationParticipant.findMany({
      where: {
        userId,
        leftAt: null,
        removedAt: null,
      },
      select: { conversationId: true },
    });

    return participants.map((p) => p.conversationId);
  }

  /**
   * Validate user has access to conversation
   */
  private async validateConversationAccess(
    userId: number,
    conversationId: string,
  ): Promise<void> {
    const participant = await this.prisma.conversationParticipant.findFirst({
      where: {
        conversationId,
        userId,
        leftAt: null,
        removedAt: null,
      },
    });

    if (!participant) {
      throw new NotFoundException('Conversation not found or access denied');
    }
  }

  /**
   * Highlight search matches in content
   */
  private highlightMatches(
    content: string,
    query: string,
  ): { highlightedContent: string; matchCount: number } {
    const words = query
      .toLowerCase()
      .split(/\s+/)
      .filter((w) => w.length > 0);
    let highlighted = content;
    let matchCount = 0;

    words.forEach((word) => {
      const regex = new RegExp(`(${this.escapeRegex(word)})`, 'gi');
      const matches = content.match(regex);
      if (matches) {
        matchCount += matches.length;
        highlighted = highlighted.replace(regex, '**$1**');
      }
    });

    return { highlightedContent: highlighted, matchCount };
  }

  /**
   * Escape special regex characters
   */
  private escapeRegex(str: string): string {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Generate cache key for search
   */
  private generateCacheKey(userId: number, dto: SearchMessagesDto): string {
    return `search:${userId}:${JSON.stringify(dto)}`;
  }

  /**
   * Clear search cache
   */
  clearCache(): void {
    this.searchCache.clear();
  }
}
