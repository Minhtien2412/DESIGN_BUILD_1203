import { Module } from '@nestjs/common';
import { ChatDeltaSyncController } from './chat-delta-sync.controller';
import { ChatDeltaSyncService } from './chat-delta-sync.service';

@Module({
  controllers: [ChatDeltaSyncController],
  providers: [ChatDeltaSyncService],
  exports: [ChatDeltaSyncService],
})
export class ChatSyncModule {}
