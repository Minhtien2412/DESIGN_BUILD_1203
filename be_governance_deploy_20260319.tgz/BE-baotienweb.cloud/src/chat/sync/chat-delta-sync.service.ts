import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
    DeltaConversationDto,
    DeltaMessageDto,
    DeltaSyncRequestDto,
    DeltaSyncResponseDto,
} from '../dto/delta-sync.dto';

/**
 * Support Users - Các user CSKH luôn online
 * Admin có thể vào check và trả lời tin nhắn từ các user này
 */
const SUPPORT_USERS = [
  {
    id: 'support-cskh-main',
    numericId: 100001,
    name: 'CSKH Design Build',
    avatar:
      'https://ui-avatars.com/api/?name=CSKH&background=007AFF&color=fff&size=128&bold=true',
    role: 'support',
    department: 'Chăm sóc khách hàng',
    isAlwaysOnline: true,
    welcomeMessage:
      'Xin chào! Tôi là CSKH Design Build. Tôi có thể giúp gì cho bạn hôm nay?',
    responseTime: 'Thường trả lời trong 5-10 phút',
  },
  {
    id: 'support-hotro-kh',
    numericId: 100002,
    name: 'Hỗ Trợ KH Design Build',
    avatar:
      'https://ui-avatars.com/api/?name=HT&background=34C759&color=fff&size=128&bold=true',
    role: 'support',
    department: 'Hỗ trợ khách hàng',
    isAlwaysOnline: true,
    welcomeMessage:
      'Chào bạn! Đội ngũ Hỗ Trợ KH Design Build sẵn sàng giúp đỡ bạn.',
    responseTime: 'Thường trả lời trong 10-15 phút',
  },
  {
    id: 'support-tuvan-thietke',
    numericId: 100003,
    name: 'Tư Vấn Thiết Kế',
    avatar:
      'https://ui-avatars.com/api/?name=TV&background=FF9500&color=fff&size=128&bold=true',
    role: 'consultant',
    department: 'Tư vấn thiết kế',
    isAlwaysOnline: true,
    welcomeMessage:
      'Xin chào! Tôi là chuyên viên Tư Vấn Thiết Kế. Bạn cần tư vấn về thiết kế gì?',
    responseTime: 'Thường trả lời trong 15-30 phút',
  },
  {
    id: 'support-kythuat',
    numericId: 100004,
    name: 'Hỗ Trợ Kỹ Thuật',
    avatar:
      'https://ui-avatars.com/api/?name=KT&background=5856D6&color=fff&size=128&bold=true',
    role: 'technical',
    department: 'Kỹ thuật',
    isAlwaysOnline: true,
    welcomeMessage:
      'Chào bạn! Đội ngũ Kỹ Thuật sẵn sàng hỗ trợ các vấn đề technical.',
    responseTime: 'Thường trả lời trong 20-30 phút',
  },
  {
    id: 'support-sales',
    numericId: 100005,
    name: 'Kinh Doanh Design Build',
    avatar:
      'https://ui-avatars.com/api/?name=KD&background=FF3B30&color=fff&size=128&bold=true',
    role: 'sales',
    department: 'Kinh doanh',
    isAlwaysOnline: true,
    welcomeMessage:
      'Xin chào! Tôi là đại diện Kinh Doanh. Tôi có thể tư vấn giá và các gói dịch vụ cho bạn.',
    responseTime: 'Thường trả lời trong 5-10 phút',
  },
];

@Injectable()
export class ChatDeltaSyncService {
  private readonly logger = new Logger(ChatDeltaSyncService.name);

  constructor(private prisma: PrismaService) {}

  /**
   * Delta sync - Chỉ lấy tin nhắn mới (seq > watermark)
   * Sử dụng batch queries và indexes cho hiệu suất cao
   */
  async deltaSync(
    userId: number,
    request: DeltaSyncRequestDto,
  ): Promise<DeltaSyncResponseDto> {
    const startTime = Date.now();
    const { watermarks, limit = 100, includeNewConversations = true } = request;

    try {
      // 1. Lấy tất cả conversation IDs của user trong 1 query
      const userConversations = await this.prisma.chatRoomMember.findMany({
        where: { userId },
        select: { roomId: true },
      });
      const userConvIds = userConversations.map((c) => c.roomId);

      // 2. Map watermarks theo conversationId
      const watermarkMap = new Map(
        watermarks.map((w) => [w.conversationId, w.lastSeq]),
      );

      // 3. Batch query - Lấy tất cả conversations với tin nhắn mới
      // Sử dụng raw query cho performance với số lượng lớn
      const conversations: DeltaConversationDto[] = [];
      let totalNewMessages = 0;

      // Batch lấy messages mới cho tất cả conversations cùng lúc
      const conversationsWithNewMessages = await this.prisma.chatRoom.findMany({
        where: {
          id: { in: userConvIds },
        },
        include: {
          project: { select: { id: true, title: true } },
          members: {
            include: {
              user: {
                select: { id: true, name: true, email: true },
              },
            },
          },
          messages: {
            orderBy: { createdAt: 'desc' },
            take: limit,
            include: {
              sender: {
                select: { id: true, name: true, email: true },
              },
            },
          },
        },
        orderBy: { updatedAt: 'desc' },
      });

      for (const conv of conversationsWithNewMessages) {
        const convIdStr = conv.id.toString();
        const clientWatermark = watermarkMap.get(convIdStr) ?? 0;

        // Lấy seq từ message ID (giả định message có seq)
        // Trong thực tế, cần thêm cột seq vào schema
        const newMessages = conv.messages.filter((msg) => {
          // Sử dụng message ID như pseudo-seq
          return msg.id > clientWatermark;
        });

        if (newMessages.length === 0 && !includeNewConversations) {
          continue;
        }

        const lastMessage = conv.messages[0];
        const deltaMessages: DeltaMessageDto[] = newMessages.map((msg) => ({
          id: msg.id.toString(),
          conversationId: convIdStr,
          seq: msg.id, // Sử dụng ID như seq
          senderId: msg.senderId,
          senderName: msg.sender?.name || undefined,
          senderAvatar: undefined,
          type: 'TEXT',
          content: msg.content || undefined,
          attachments: (msg.attachments as any[]) || undefined,
          createdAt: msg.createdAt.toISOString(),
          editedAt: undefined,
          isDeleted: false,
        }));

        totalNewMessages += deltaMessages.length;

        conversations.push({
          id: convIdStr,
          name: conv.name || conv.project?.title,
          type: 'group',
          avatar: undefined,
          lastSeq: lastMessage?.id || 0,
          unreadCount: newMessages.length,
          lastMessageTime: lastMessage?.createdAt.toISOString(),
          lastMessagePreview: lastMessage?.content?.substring(0, 50),
          messages: deltaMessages,
          members: conv.members.map((m) => ({
            userId: m.user.id,
            name: m.user.name || m.user.email,
            avatar: undefined,
            role: undefined,
          })),
        });
      }

      const elapsed = Date.now() - startTime;
      this.logger.log(
        `Delta sync completed: ${totalNewMessages} messages in ${elapsed}ms`,
      );

      return {
        success: true,
        conversations,
        syncTimestamp: new Date().toISOString(),
        totalNewMessages,
        hasMore: false,
        deletedConversations: [],
      };
    } catch (error) {
      this.logger.error('Delta sync failed', error);
      throw error;
    }
  }

  /**
   * Full sync - Lấy toàn bộ conversations (dùng khi reset local DB)
   */
  async fullSync(
    userId: number,
    conversationLimit: number,
    messagesPerConv: number,
  ): Promise<DeltaSyncResponseDto> {
    return this.deltaSync(userId, {
      watermarks: [], // Empty watermarks = lấy tất cả
      limit: messagesPerConv,
      includeNewConversations: true,
    });
  }

  /**
   * Lấy danh sách support users luôn online
   */
  getSupportUsers() {
    return {
      success: true,
      users: SUPPORT_USERS.map((u) => ({
        ...u,
        status: 'online',
        lastSeen: new Date().toISOString(),
      })),
    };
  }

  /**
   * Tạo hoặc lấy conversation với support user
   */
  async getOrCreateSupportConversation(userId: number, supportUserId: string) {
    const supportUser = SUPPORT_USERS.find((u) => u.id === supportUserId);
    if (!supportUser) {
      return {
        success: false,
        error: 'Support user not found',
      };
    }

    // Tìm conversation đã tồn tại
    // Trong thực tế cần schema riêng cho support conversations
    // Tạm thời trả về thông tin để FE xử lý local

    return {
      success: true,
      conversation: {
        id: `support_${userId}_${supportUserId}`,
        type: 'support',
        supportUser: {
          ...supportUser,
          status: 'online',
          lastSeen: new Date().toISOString(),
        },
        welcomeMessage: supportUser.welcomeMessage,
        createdAt: new Date().toISOString(),
      },
    };
  }
}
