import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import {
    DeltaSyncRequestDto,
    DeltaSyncResponseDto,
} from '../dto/delta-sync.dto';
import { ChatDeltaSyncService } from './chat-delta-sync.service';

@ApiTags('Chat Sync')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'chat/sync', version: '1' })
export class ChatDeltaSyncController {
  constructor(private readonly deltaSyncService: ChatDeltaSyncService) {}

  @Post('delta')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Delta sync - Lấy tin nhắn mới từ server',
    description: `
      Endpoint cho delta sync protocol:
      1. Client gửi danh sách watermarks (lastSeq của mỗi conversation)
      2. Server trả về chỉ những tin nhắn mới (seq > watermark)
      3. Client merge vào local database và update watermarks
      
      Sử dụng batch queries và indexes cho hiệu suất cao với số lượng lớn.
    `,
  })
  @ApiResponse({
    status: 200,
    description: 'Delta sync thành công',
    type: DeltaSyncResponseDto,
  })
  async deltaSync(
    @Body() request: DeltaSyncRequestDto,
    @CurrentUser('id') userId: number,
  ): Promise<DeltaSyncResponseDto> {
    return this.deltaSyncService.deltaSync(userId, request);
  }

  @Get('full')
  @ApiOperation({
    summary: 'Full sync - Lấy toàn bộ conversations',
    description: 'Dùng khi client cần sync lại từ đầu (reset local DB)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    example: 50,
    description: 'Số conversations tối đa',
  })
  @ApiQuery({
    name: 'messagesPerConversation',
    required: false,
    type: Number,
    example: 30,
    description: 'Số tin nhắn gần nhất mỗi conversation',
  })
  @ApiResponse({
    status: 200,
    description: 'Full sync thành công',
    type: DeltaSyncResponseDto,
  })
  async fullSync(
    @CurrentUser('id') userId: number,
    @Query('limit') limit?: number,
    @Query('messagesPerConversation') messagesPerConv?: number,
  ): Promise<DeltaSyncResponseDto> {
    return this.deltaSyncService.fullSync(
      userId,
      limit || 50,
      messagesPerConv || 30,
    );
  }

  @Get('support-users')
  @ApiOperation({
    summary: 'Lấy danh sách support users',
    description:
      'Trả về danh sách các user hỗ trợ khách hàng luôn online (CSKH, Hỗ trợ KH,...)',
  })
  @ApiResponse({
    status: 200,
    description: 'Danh sách support users',
  })
  async getSupportUsers() {
    return this.deltaSyncService.getSupportUsers();
  }

  @Post('support-conversation')
  @ApiOperation({
    summary: 'Tạo hoặc lấy conversation với support user',
    description:
      'Tạo conversation mới nếu chưa có, hoặc trả về conversation hiện có',
  })
  @ApiResponse({
    status: 200,
    description: 'Conversation với support user',
  })
  async getOrCreateSupportConversation(
    @CurrentUser('id') userId: number,
    @Body() body: { supportUserId: string },
  ) {
    return this.deltaSyncService.getOrCreateSupportConversation(
      userId,
      body.supportUserId,
    );
  }
}
