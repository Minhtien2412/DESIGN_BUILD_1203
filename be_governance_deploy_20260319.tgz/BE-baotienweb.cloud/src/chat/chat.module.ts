import { Module } from '@nestjs/common';
import { MarketplaceGovernanceModule } from '../marketplace-governance/marketplace-governance.module';
import { PrismaModule } from '../prisma/prisma.module';
import { UploadModule } from '../upload/upload.module';
import { ChatAttachmentController } from './chat-attachment.controller';
import { ChatAttachmentService } from './chat-attachment.service';
import { ChatController } from './chat.controller';
import { ChatGateway } from './chat.gateway';
import { ChatService } from './chat.service';
import { MessageSearchController } from './message-search.controller';
import { MessageSearchService } from './message-search.service';
import { ChatDeltaSyncController } from './sync/chat-delta-sync.controller';
import { ChatDeltaSyncService } from './sync/chat-delta-sync.service';

@Module({
  imports: [PrismaModule, UploadModule, MarketplaceGovernanceModule],
  controllers: [
    ChatController,
    ChatAttachmentController,
    MessageSearchController,
    ChatDeltaSyncController,
  ],
  providers: [
    ChatGateway,
    ChatService,
    ChatAttachmentService,
    MessageSearchService,
    ChatDeltaSyncService,
  ],
  exports: [
    ChatService,
    ChatAttachmentService,
    MessageSearchService,
    ChatDeltaSyncService,
  ],
})
export class ChatModule {}
