/**
 * Message Search Controller (MSG-006)
 * ====================================
 *
 * REST endpoints for message search
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    MessageSearchService,
    SearchMessagesDto,
} from './message-search.service';

// ============================================================================
// DTOs
// ============================================================================

class SearchRequestDto {
  query: string;
  conversationId?: string;
  senderId?: number;
  dateFrom?: string;
  dateTo?: string;
  hasAttachment?: boolean;
  attachmentType?: 'IMAGE' | 'VIDEO' | 'FILE' | 'VOICE';
  limit?: number;
  cursor?: string;
}

// ============================================================================
// CONTROLLER
// ============================================================================

@ApiTags('Message Search')
@ApiBearerAuth()
@Controller('chat/search')
@UseGuards(JwtAuthGuard)
export class MessageSearchController {
  constructor(private readonly searchService: MessageSearchService) {}

  /**
   * Search messages across all conversations
   */
  @Post()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Search messages across all conversations' })
  @ApiResponse({ status: 200, description: 'Search results' })
  async searchMessages(
    @CurrentUser('id') userId: number,
    @Body() dto: SearchRequestDto,
  ) {
    const searchDto: SearchMessagesDto = {
      query: dto.query,
      conversationId: dto.conversationId,
      senderId: dto.senderId,
      dateFrom: dto.dateFrom ? new Date(dto.dateFrom) : undefined,
      dateTo: dto.dateTo ? new Date(dto.dateTo) : undefined,
      hasAttachment: dto.hasAttachment,
      attachmentType: dto.attachmentType,
      limit: dto.limit,
      cursor: dto.cursor,
    };

    // Save recent search
    await this.searchService.saveRecentSearch(userId, dto.query);

    const results = await this.searchService.searchMessages(userId, searchDto);
    return {
      success: true,
      data: results,
    };
  }

  /**
   * Search messages within a specific conversation
   */
  @Get('conversation/:conversationId')
  @ApiOperation({ summary: 'Search messages within a specific conversation' })
  @ApiQuery({ name: 'query', required: true, type: String })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'cursor', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Search results' })
  async searchInConversation(
    @CurrentUser('id') userId: number,
    @Param('conversationId') conversationId: string,
    @Query('query') query: string,
    @Query('limit') limit?: string,
    @Query('cursor') cursor?: string,
  ) {
    const results = await this.searchService.searchInConversation(
      userId,
      conversationId,
      query,
      limit ? parseInt(limit, 10) : undefined,
      cursor,
    );
    return {
      success: true,
      data: results,
    };
  }

  /**
   * Get search suggestions
   */
  @Get('suggestions')
  @ApiOperation({ summary: 'Get search suggestions based on partial query' })
  @ApiQuery({ name: 'q', required: true, type: String })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'Search suggestions' })
  async getSearchSuggestions(
    @CurrentUser('id') userId: number,
    @Query('q') partialQuery: string,
    @Query('limit') limit?: string,
  ) {
    const suggestions = await this.searchService.getSearchSuggestions(
      userId,
      partialQuery,
      limit ? parseInt(limit, 10) : undefined,
    );
    return {
      success: true,
      data: { suggestions },
    };
  }

  /**
   * Get recent searches
   */
  @Get('recent')
  @ApiOperation({ summary: 'Get recent search queries' })
  @ApiResponse({ status: 200, description: 'Recent searches' })
  async getRecentSearches(@CurrentUser('id') userId: number) {
    const searches = await this.searchService.getRecentSearches(userId);
    return {
      success: true,
      data: { searches },
    };
  }

  /**
   * Clear recent searches
   */
  @Delete('recent')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Clear recent search history' })
  @ApiResponse({ status: 200, description: 'Recent searches cleared' })
  async clearRecentSearches(@CurrentUser('id') userId: number) {
    await this.searchService.clearRecentSearches(userId);
    return {
      success: true,
      message: 'Recent searches cleared',
    };
  }
}
