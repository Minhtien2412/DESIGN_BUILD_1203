import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsString,
  IsArray,
  IsOptional,
} from 'class-validator';

export class SendMessageDto {
  @ApiProperty({ description: 'ID của chat room', example: 1 })
  @IsInt()
  @IsNotEmpty()
  roomId: number;

  @ApiProperty({
    description: 'Nội dung tin nhắn',
    example: 'Xin chào, tôi cần hỗ trợ!',
  })
  @IsString()
  @IsNotEmpty()
  content: string;

  @ApiPropertyOptional({
    description: 'Danh sách đường dẫn file đính kèm',
    example: ['uploads/image1.jpg', 'uploads/image2.png'],
    type: [String],
  })
  @IsArray()
  @IsOptional()
  @IsString({ each: true })
  attachments?: string[];
}
