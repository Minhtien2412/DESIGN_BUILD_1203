import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class MarkAsReadDto {
  @ApiProperty({ description: 'ID của tin nhắn', example: 1 })
  @IsInt()
  @IsNotEmpty()
  messageId: number;
}
