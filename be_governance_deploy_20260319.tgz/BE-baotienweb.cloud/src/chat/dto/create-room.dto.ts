import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class CreateRoomDto {
  @ApiProperty({ description: 'ID của project', example: 1 })
  @IsInt()
  @IsNotEmpty()
  projectId: number;

  @ApiProperty({ description: 'Tên chat room', example: 'Project Chat Room' })
  @IsString()
  @IsNotEmpty()
  name: string;
}
