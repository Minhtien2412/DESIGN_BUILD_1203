import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsNumber, IsOptional, ValidateNested } from 'class-validator';

/**
 * DTO cho watermark của từng conversation
 */
export class ConversationWatermarkDto {
  @ApiProperty({ example: 'conv_123', description: 'ID của conversation' })
  conversationId: string;

  @ApiProperty({
    example: 150,
    description: 'Sequence number cuối cùng đã sync',
  })
  @IsNumber()
  lastSeq: number;
}

/**
 * Request DTO cho delta sync
 */
export class DeltaSyncRequestDto {
  @ApiProperty({
    type: [ConversationWatermarkDto],
    description: 'Danh sách watermarks của client (lastSeq mỗi conversation)',
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ConversationWatermarkDto)
  watermarks: ConversationWatermarkDto[];

  @ApiPropertyOptional({
    example: 100,
    description: 'Số tin nhắn tối đa trả về mỗi conversation',
    default: 100,
  })
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional({
    example: true,
    description: 'Có bao gồm conversations mới không',
    default: true,
  })
  @IsOptional()
  includeNewConversations?: boolean;
}

/**
 * Message trong delta sync response
 */
export class DeltaMessageDto {
  @ApiProperty({ example: 'msg_abc123' })
  id: string;

  @ApiProperty({ example: 'conv_123' })
  conversationId: string;

  @ApiProperty({ example: 151, description: 'Sequence number' })
  seq: number;

  @ApiProperty({ example: 1 })
  senderId: number;

  @ApiPropertyOptional({ example: 'Nguyen Van A' })
  senderName?: string;

  @ApiPropertyOptional({ example: 'https://...' })
  senderAvatar?: string;

  @ApiProperty({
    example: 'TEXT',
    enum: ['TEXT', 'IMAGE', 'VIDEO', 'AUDIO', 'FILE', 'STICKER', 'LOCATION'],
  })
  type: string;

  @ApiPropertyOptional({ example: 'Hello!' })
  content?: string;

  @ApiPropertyOptional({ type: [Object] })
  attachments?: any[];

  @ApiProperty({ example: '2025-01-27T10:30:00.000Z' })
  createdAt: string;

  @ApiPropertyOptional({ example: '2025-01-27T10:35:00.000Z' })
  editedAt?: string;

  @ApiPropertyOptional({ example: false })
  isDeleted?: boolean;
}

/**
 * Conversation trong delta sync response
 */
export class DeltaConversationDto {
  @ApiProperty({ example: 'conv_123' })
  id: string;

  @ApiPropertyOptional({ example: 'Project Alpha Chat' })
  name?: string;

  @ApiProperty({ example: 'group', enum: ['direct', 'group', 'support'] })
  type: 'direct' | 'group' | 'support';

  @ApiPropertyOptional({ example: 'https://...' })
  avatar?: string;

  @ApiProperty({ example: 160, description: 'Seq mới nhất của conversation' })
  lastSeq: number;

  @ApiProperty({ example: 5, description: 'Số tin chưa đọc' })
  unreadCount: number;

  @ApiPropertyOptional({
    example: '2025-01-27T10:30:00.000Z',
    description: 'Thời điểm tin nhắn cuối',
  })
  lastMessageTime?: string;

  @ApiPropertyOptional({
    example: 'Đã gửi file báo cáo',
    description: 'Preview tin nhắn cuối',
  })
  lastMessagePreview?: string;

  @ApiProperty({
    type: [DeltaMessageDto],
    description: 'Các tin nhắn mới (seq > watermark)',
  })
  messages: DeltaMessageDto[];

  @ApiPropertyOptional({
    description: 'Thành viên conversation (cho group/support)',
    type: [Object],
  })
  members?: Array<{
    userId: number;
    name: string;
    avatar?: string;
    role?: string;
  }>;
}

/**
 * Response DTO cho delta sync
 */
export class DeltaSyncResponseDto {
  @ApiProperty({ example: true })
  success: boolean;

  @ApiProperty({
    type: [DeltaConversationDto],
    description: 'Danh sách conversations với messages mới',
  })
  conversations: DeltaConversationDto[];

  @ApiProperty({
    example: '2025-01-27T10:35:00.000Z',
    description: 'Timestamp của sync này (dùng cho lần sync tiếp theo)',
  })
  syncTimestamp: string;

  @ApiProperty({
    example: 15,
    description: 'Tổng số tin nhắn mới đã sync',
  })
  totalNewMessages: number;

  @ApiProperty({
    example: false,
    description: 'Còn dữ liệu chưa sync không (pagination)',
  })
  hasMore: boolean;

  @ApiPropertyOptional({
    description: 'Danh sách conversation IDs đã bị xóa',
    type: [String],
  })
  deletedConversations?: string[];
}
