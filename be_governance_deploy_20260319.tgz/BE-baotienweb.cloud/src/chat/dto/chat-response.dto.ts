import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class MessageResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 'Xin chào, tôi cần hỗ trợ!' })
  content: string;

  @ApiPropertyOptional({
    example: ['uploads/image1.jpg'],
    type: [String],
  })
  attachments?: string[];

  @ApiProperty({ example: 1 })
  roomId: number;

  @ApiProperty({ example: 1 })
  senderId: number;

  @ApiProperty({
    example: { id: 1, name: 'Nguyen Van A', email: 'user@example.com' },
  })
  sender: {
    id: number;
    name: string | null;
    email: string;
  };

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'Danh sách user đã đọc tin nhắn',
    example: [
      { userId: 2, readAt: '2024-01-01T00:05:00.000Z' },
      { userId: 3, readAt: '2024-01-01T00:10:00.000Z' },
    ],
  })
  readBy?: Array<{
    userId: number;
    readAt: Date;
  }>;
}

export class RoomResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 'Project Chat Room' })
  name: string;

  @ApiProperty({ example: 1 })
  projectId: number;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'Danh sách thành viên',
    example: [
      { id: 1, name: 'User 1', email: 'user1@example.com' },
      { id: 2, name: 'User 2', email: 'user2@example.com' },
    ],
  })
  members?: Array<{
    id: number;
    name: string | null;
    email: string;
  }>;
}
