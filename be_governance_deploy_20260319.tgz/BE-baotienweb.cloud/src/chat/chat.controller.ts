import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  UseGuards,
  ParseIntPipe,
  DefaultValuePipe,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { ChatService } from './chat.service';
import {
  CreateRoomDto,
  SendMessageDto,
  MessageResponseDto,
  RoomResponseDto,
} from './dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@ApiTags('Chat')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'chat', version: '1' })
export class ChatController {
  constructor(private readonly chatService: ChatService) {}

  @Post('rooms')
  @ApiOperation({ summary: 'Tạo chat room cho project' })
  @ApiResponse({
    status: 201,
    description: 'Chat room đã được tạo',
    type: RoomResponseDto,
  })
  async createRoom(
    @Body() createRoomDto: CreateRoomDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.chatService.createRoom(createRoomDto, userId);
  }

  @Get('rooms')
  @ApiOperation({ summary: 'Lấy danh sách chat rooms của user' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách chat rooms',
    type: [RoomResponseDto],
  })
  async getUserRooms(@CurrentUser('id') userId: number) {
    return this.chatService.getUserRooms(userId);
  }

  @Get('rooms/:roomId/messages')
  @ApiOperation({ summary: 'Lấy tin nhắn trong room' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách tin nhắn',
    type: [MessageResponseDto],
  })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 50 })
  @ApiQuery({ name: 'offset', required: false, type: Number, example: 0 })
  async getRoomMessages(
    @Param('roomId', ParseIntPipe) roomId: number,
    @CurrentUser('id') userId: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
    @Query('offset', new DefaultValuePipe(0), ParseIntPipe) offset: number,
  ) {
    return this.chatService.getRoomMessages(roomId, userId, limit, offset);
  }

  @Post('messages')
  @ApiOperation({
    summary: 'Gửi tin nhắn (REST API - có thể dùng WebSocket thay thế)',
  })
  @ApiResponse({
    status: 201,
    description: 'Tin nhắn đã được gửi',
    type: MessageResponseDto,
  })
  async sendMessage(
    @Body() sendMessageDto: SendMessageDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.chatService.sendMessage(sendMessageDto, userId);
  }

  @Post('messages/:messageId/read')
  @ApiOperation({ summary: 'Đánh dấu tin nhắn đã đọc' })
  @ApiResponse({ status: 200, description: 'Tin nhắn đã được đánh dấu đã đọc' })
  async markAsRead(
    @Param('messageId', ParseIntPipe) messageId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.chatService.markAsRead(messageId, userId);
  }

  @Post('rooms/:roomId/members/:memberId')
  @ApiOperation({ summary: 'Thêm thành viên vào room' })
  @ApiResponse({ status: 200, description: 'Thành viên đã được thêm' })
  async addMemberToRoom(
    @Param('roomId', ParseIntPipe) roomId: number,
    @Param('memberId', ParseIntPipe) memberId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.chatService.addMemberToRoom(roomId, userId, memberId);
  }
}
