import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Max,
    MaxLength,
    Min
} from 'class-validator';

export enum JobStatusDto {
  CREATED = 'CREATED',
  ASSIGNED = 'ASSIGNED',
  EN_ROUTE = 'EN_ROUTE',
  ARRIVED = 'ARRIVED',
  IN_PROGRESS = 'IN_PROGRESS',
  PAUSED = 'PAUSED',
  WAITING_CONFIRMATION = 'WAITING_CONFIRMATION',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

export enum JobEventTypeDto {
  CREATED = 'CREATED',
  MATCHED = 'MATCHED',
  WORKER_ASSIGNED = 'WORKER_ASSIGNED',
  EN_ROUTE = 'EN_ROUTE',
  ARRIVED = 'ARRIVED',
  STARTED = 'STARTED',
  UPDATE = 'UPDATE',
  PHOTO_ADDED = 'PHOTO_ADDED',
  COST_ADDED = 'COST_ADDED',
  CUSTOMER_NOTE = 'CUSTOMER_NOTE',
  CUSTOMER_CONFIRMED = 'CUSTOMER_CONFIRMED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
  WARRANTY_CREATED = 'WARRANTY_CREATED',
}

export enum JobCostTypeDto {
  LABOR = 'LABOR',
  MATERIAL = 'MATERIAL',
  TRANSPORT = 'TRANSPORT',
  EQUIPMENT = 'EQUIPMENT',
  OTHER = 'OTHER',
  DISCOUNT = 'DISCOUNT',
}

export class JobQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ enum: JobStatusDto })
  @IsOptional()
  @IsEnum(JobStatusDto)
  status?: JobStatusDto;
}

export class JobActionDto {
  @ApiPropertyOptional({ description: 'Ghi chú đi kèm action' })
  @IsOptional()
  @IsString()
  note?: string;

  @ApiPropertyOptional({ description: 'Metadata bổ sung cho action' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}

export class CreateJobEventDto {
  @ApiProperty({ enum: JobEventTypeDto })
  @IsEnum(JobEventTypeDto)
  type: JobEventTypeDto;

  @ApiProperty({ description: 'Nội dung event' })
  @IsString()
  @IsNotEmpty()
  message: string;

  @ApiPropertyOptional({ description: 'Metadata event' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}

export class AddJobCostItemDto {
  @ApiProperty({ enum: JobCostTypeDto })
  @IsEnum(JobCostTypeDto)
  type: JobCostTypeDto;

  @ApiProperty({ description: 'Tên dòng chi phí' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(160)
  title: string;

  @ApiPropertyOptional({ description: 'Mô tả dòng chi phí' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ description: 'Số lượng', default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  quantity?: number;

  @ApiPropertyOptional({ description: 'Đơn giá', default: 0 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  unitPrice?: number;
}

export class CompleteJobDto {
  @ApiPropertyOptional({ description: 'Tổng tiền cuối cùng' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  finalAmount?: number;

  @ApiPropertyOptional({ description: 'Phương thức thanh toán cuối cùng' })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  paymentMethod?: string;

  @ApiPropertyOptional({
    description: 'Số ngày bảo hành được ghi nhận lên job',
    default: 30,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  warrantyDays?: number;

  @ApiPropertyOptional({ description: 'Ghi chú hoàn thành' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CancelJobDto {
  @ApiPropertyOptional({ description: 'Lý do hủy job' })
  @IsOptional()
  @IsString()
  reason?: string;
}

export class CreateJobReviewDto {
  @ApiProperty({ description: 'Điểm đánh giá từ 1-5' })
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(5)
  rating: number;

  @ApiPropertyOptional({ description: 'Nhận xét của khách hàng' })
  @IsOptional()
  @IsString()
  comment?: string;

  @ApiPropertyOptional({ description: 'Metadata bổ sung cho review' })
  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}
