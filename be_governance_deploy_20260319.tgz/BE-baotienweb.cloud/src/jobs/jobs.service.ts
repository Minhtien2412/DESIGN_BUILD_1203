import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { JobCostType, JobEventType, JobStatus, Prisma } from '@prisma/client';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import {
    AddJobCostItemDto,
    CancelJobDto,
    CompleteJobDto,
    CreateJobEventDto,
    CreateJobReviewDto,
    JobActionDto,
    JobQueryDto,
    JobStatusDto,
} from './dto';

const jobDetailInclude = {
  booking: true,
  events: {
    orderBy: { createdAt: 'desc' as const },
  },
  costItems: {
    orderBy: { createdAt: 'asc' as const },
  },
  review: true,
  warranties: {
    include: { policy: true },
    orderBy: { createdAt: 'desc' as const },
  },
};

@Injectable()
export class JobsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async getMyJobs(userId: number, query: JobQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const workerIds = await this.getWorkerIdsForUser(userId);
    const where = this.buildUserJobWhere(userId, workerIds, query.status);

    const [data, total] = await Promise.all([
      this.prisma.job.findMany({
        where,
        include: jobDetailInclude,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.job.count({ where }),
    ]);

    return {
      data,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getJobDetail(id: number, userId: number) {
    const access = await this.getJobAccess(id, userId);
    return access.job;
  }

  async markEnRoute(id: number, userId: number, dto: JobActionDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['worker']);
    this.ensureStatus(access.job.status, [
      JobStatus.CREATED,
      JobStatus.ASSIGNED,
    ]);

    await this.prisma.job.update({
      where: { id },
      data: { status: JobStatus.EN_ROUTE },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.EN_ROUTE,
      actorUserId: userId,
      actorWorkerId: access.job.workerId,
      message: dto.note ?? 'Worker đang trên đường đến địa điểm làm việc.',
      metadata: dto.metadata,
    });

    await this.notifySafely(
      access.job.customerId,
      'Thợ đang trên đường',
      `Job ${access.job.jobCode} đã chuyển sang trạng thái đang di chuyển.`,
      { jobId: access.job.id, jobCode: access.job.jobCode },
    );

    return this.getJobDetail(id, userId);
  }

  async markArrived(id: number, userId: number, dto: JobActionDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['worker']);
    this.ensureStatus(access.job.status, [JobStatus.EN_ROUTE]);

    await this.prisma.job.update({
      where: { id },
      data: {
        status: JobStatus.ARRIVED,
        arrivedAt: new Date(),
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.ARRIVED,
      actorUserId: userId,
      actorWorkerId: access.job.workerId,
      message: dto.note ?? 'Worker đã đến địa điểm làm việc.',
      metadata: dto.metadata,
    });

    await this.notifySafely(
      access.job.customerId,
      'Thợ đã đến nơi',
      `Job ${access.job.jobCode} đã cập nhật trạng thái đã đến nơi.`,
      { jobId: access.job.id, jobCode: access.job.jobCode },
    );

    return this.getJobDetail(id, userId);
  }

  async startJob(id: number, userId: number, dto: JobActionDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['worker']);
    this.ensureStatus(access.job.status, [
      JobStatus.EN_ROUTE,
      JobStatus.ARRIVED,
    ]);

    await this.prisma.job.update({
      where: { id },
      data: {
        status: JobStatus.IN_PROGRESS,
        startedAt: access.job.startedAt ?? new Date(),
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.STARTED,
      actorUserId: userId,
      actorWorkerId: access.job.workerId,
      message: dto.note ?? 'Job đã bắt đầu thi công/xử lý.',
      metadata: dto.metadata,
    });

    await this.notifySafely(
      access.job.customerId,
      'Job đã bắt đầu',
      `Worker đã bắt đầu xử lý job ${access.job.jobCode}.`,
      { jobId: access.job.id, jobCode: access.job.jobCode },
    );

    return this.getJobDetail(id, userId);
  }

  async addEvent(id: number, userId: number, dto: CreateJobEventDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['customer', 'worker']);

    await this.recordJobEvent(id, {
      type: dto.type as unknown as JobEventType,
      actorUserId: userId,
      actorWorkerId: access.isWorker ? access.job.workerId : undefined,
      message: dto.message,
      metadata: dto.metadata,
    });

    return this.getJobDetail(id, userId);
  }

  async addCostItem(id: number, userId: number, dto: AddJobCostItemDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['worker']);
    const closedStatuses: JobStatus[] = [
      JobStatus.COMPLETED,
      JobStatus.CANCELLED,
    ];

    if (closedStatuses.includes(access.job.status)) {
      throw new BadRequestException('Không thể thêm chi phí cho job đã đóng.');
    }

    const quantity = new Prisma.Decimal(dto.quantity ?? 1);
    const unitPrice = new Prisma.Decimal(dto.unitPrice ?? 0);
    const totalPrice = quantity.mul(unitPrice);

    await this.prisma.jobCostItem.create({
      data: {
        jobId: id,
        type: dto.type as unknown as JobCostType,
        title: dto.title,
        description: dto.description,
        quantity,
        unitPrice,
        totalPrice,
        createdById: userId,
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.COST_ADDED,
      actorUserId: userId,
      actorWorkerId: access.job.workerId,
      message: `Đã thêm chi phí ${dto.title} với giá trị ${totalPrice.toString()}.`,
      metadata: {
        type: dto.type,
        quantity: quantity.toString(),
        unitPrice: unitPrice.toString(),
        totalPrice: totalPrice.toString(),
      },
    });

    return this.getJobDetail(id, userId);
  }

  async completeJob(id: number, userId: number, dto: CompleteJobDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['worker']);
    this.ensureStatus(access.job.status, [
      JobStatus.IN_PROGRESS,
      JobStatus.ARRIVED,
    ]);

    const warrantyUntil =
      dto.warrantyDays !== undefined
        ? this.addDays(new Date(), dto.warrantyDays)
        : access.job.warrantyUntil;

    await this.prisma.job.update({
      where: { id },
      data: {
        status: JobStatus.WAITING_CONFIRMATION,
        completedAt: new Date(),
        finalAmount:
          dto.finalAmount !== undefined
            ? new Prisma.Decimal(dto.finalAmount)
            : access.job.finalAmount,
        paymentMethod: dto.paymentMethod ?? access.job.paymentMethod,
        notes: dto.notes ?? access.job.notes,
        warrantyUntil,
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.COMPLETED,
      actorUserId: userId,
      actorWorkerId: access.job.workerId,
      message:
        dto.notes ??
        'Worker đã đánh dấu job hoàn tất và đang chờ khách hàng xác nhận.',
      metadata: {
        finalAmount: dto.finalAmount,
        paymentMethod: dto.paymentMethod,
        warrantyDays: dto.warrantyDays,
      },
    });

    await this.notifySafely(
      access.job.customerId,
      'Job chờ xác nhận hoàn thành',
      `Job ${access.job.jobCode} đã được worker đánh dấu hoàn tất.`,
      { jobId: access.job.id, jobCode: access.job.jobCode },
    );

    return this.getJobDetail(id, userId);
  }

  async confirmCompletion(id: number, userId: number, dto: JobActionDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['customer']);
    this.ensureStatus(access.job.status, [JobStatus.WAITING_CONFIRMATION]);

    await this.prisma.job.update({
      where: { id },
      data: {
        status: JobStatus.COMPLETED,
        customerConfirmedAt: new Date(),
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.CUSTOMER_CONFIRMED,
      actorUserId: userId,
      message: dto.note ?? 'Khách hàng đã xác nhận job hoàn tất.',
      metadata: dto.metadata,
    });

    const worker = await this.prisma.worker.findUnique({
      where: { id: access.job.workerId },
      select: { userId: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Khách hàng đã xác nhận hoàn thành',
        `Job ${access.job.jobCode} đã được khách hàng xác nhận hoàn tất.`,
        { jobId: access.job.id, jobCode: access.job.jobCode },
      );
    }

    return this.getJobDetail(id, userId);
  }

  async cancelJob(id: number, userId: number, dto: CancelJobDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['customer', 'worker']);

    if (access.job.status === JobStatus.COMPLETED) {
      throw new BadRequestException('Job đã hoàn tất nên không thể hủy.');
    }

    if (access.job.status === JobStatus.CANCELLED) {
      return access.job;
    }

    await this.prisma.job.update({
      where: { id },
      data: {
        status: JobStatus.CANCELLED,
        cancelledAt: new Date(),
        cancellationReason: dto.reason,
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.CANCELLED,
      actorUserId: userId,
      actorWorkerId: access.isWorker ? access.job.workerId : undefined,
      message: dto.reason ?? 'Job đã bị hủy.',
    });

    const notificationTargets = new Set<number>([access.job.customerId]);
    const worker = await this.prisma.worker.findUnique({
      where: { id: access.job.workerId },
      select: { userId: true },
    });
    if (worker?.userId) {
      notificationTargets.add(worker.userId);
    }

    await Promise.all(
      Array.from(notificationTargets)
        .filter((targetUserId) => targetUserId !== userId)
        .map((targetUserId) =>
          this.notifySafely(
            targetUserId,
            'Job đã bị hủy',
            `Job ${access.job.jobCode} đã bị hủy.`,
            { jobId: access.job.id, jobCode: access.job.jobCode },
          ),
        ),
    );

    return this.getJobDetail(id, userId);
  }

  async createReview(id: number, userId: number, dto: CreateJobReviewDto) {
    const access = await this.getJobAccess(id, userId);
    this.ensureRole(access, ['customer']);
    this.ensureStatus(access.job.status, [JobStatus.COMPLETED]);

    const existingReview = await this.prisma.jobReview.findUnique({
      where: { jobId: id },
      select: { id: true },
    });

    if (existingReview) {
      throw new BadRequestException('Job này đã có đánh giá trước đó.');
    }

    await this.prisma.jobReview.create({
      data: {
        jobId: id,
        customerId: access.job.customerId,
        workerId: access.job.workerId,
        rating: dto.rating,
        comment: dto.comment,
        metadata: this.toJsonValue(dto.metadata),
      },
    });

    const aggregate = await this.prisma.jobReview.aggregate({
      where: { workerId: access.job.workerId },
      _avg: { rating: true },
      _count: { rating: true },
    });

    await this.prisma.worker.update({
      where: { id: access.job.workerId },
      data: {
        rating: aggregate._avg.rating ?? 0,
        totalReviews: aggregate._count.rating,
      },
    });

    await this.recordJobEvent(id, {
      type: JobEventType.UPDATE,
      actorUserId: userId,
      message: 'Khách hàng đã gửi đánh giá sau khi hoàn thành job.',
      metadata: {
        rating: dto.rating,
      },
    });

    const worker = await this.prisma.worker.findUnique({
      where: { id: access.job.workerId },
      select: { userId: true },
    });

    if (worker?.userId) {
      await this.notifySafely(
        worker.userId,
        'Bạn vừa nhận được đánh giá mới',
        `Khách hàng đã đánh giá job ${access.job.jobCode} với ${dto.rating}/5 sao.`,
        {
          jobId: access.job.id,
          jobCode: access.job.jobCode,
          rating: dto.rating,
        },
      );
    }

    return this.getJobDetail(id, userId);
  }

  private async getJobAccess(id: number, userId: number) {
    const workerIds = await this.getWorkerIdsForUser(userId);
    const job = await this.prisma.job.findFirst({
      where: this.buildUserJobWhere(userId, workerIds, undefined, id),
      include: jobDetailInclude,
    });

    if (!job) {
      throw new NotFoundException(`Job with ID ${id} not found`);
    }

    return {
      job,
      isCustomer: job.customerId === userId,
      isWorker: workerIds.includes(job.workerId),
    };
  }

  private buildUserJobWhere(
    userId: number,
    workerIds: number[],
    status?: JobStatusDto,
    jobId?: number,
  ): Prisma.JobWhereInput {
    const orConditions: Prisma.JobWhereInput[] = [{ customerId: userId }];

    if (workerIds.length > 0) {
      orConditions.push({ workerId: { in: workerIds } });
    }

    return {
      ...(jobId ? { id: jobId } : {}),
      ...(status ? { status: status as unknown as JobStatus } : {}),
      OR: orConditions,
    };
  }

  private async getWorkerIdsForUser(userId: number) {
    const workers = await this.prisma.worker.findMany({
      where: { userId },
      select: { id: true },
    });

    return workers.map((worker) => worker.id);
  }

  private ensureRole(
    access: { isCustomer: boolean; isWorker: boolean },
    allowedRoles: Array<'customer' | 'worker'>,
  ) {
    const granted =
      (allowedRoles.includes('customer') && access.isCustomer) ||
      (allowedRoles.includes('worker') && access.isWorker);

    if (!granted) {
      throw new ForbiddenException(
        'Bạn không có quyền thực hiện thao tác này.',
      );
    }
  }

  private ensureStatus(current: JobStatus, allowed: JobStatus[]) {
    if (!allowed.includes(current)) {
      throw new BadRequestException(
        `Không thể thực hiện chuyển trạng thái từ ${current}.`,
      );
    }
  }

  private async recordJobEvent(
    jobId: number,
    data: {
      type: JobEventType;
      actorUserId?: number;
      actorWorkerId?: number;
      message: string;
      metadata?: Record<string, unknown>;
    },
  ) {
    await this.prisma.jobEvent.create({
      data: {
        jobId,
        type: data.type,
        actorUserId: data.actorUserId,
        actorWorkerId: data.actorWorkerId,
        message: data.message,
        metadata: this.toJsonValue(data.metadata),
      },
    });
  }

  private toJsonValue(value?: Record<string, unknown>) {
    if (!value) {
      return undefined;
    }

    return value as Prisma.InputJsonValue;
  }

  private addDays(date: Date, days: number) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  private async notifySafely(
    userId: number,
    title: string,
    message: string,
    data?: Record<string, unknown>,
  ) {
    try {
      await this.notificationsService.create({
        userId,
        title,
        message,
        type: 'SYSTEM',
        priority: 'MEDIUM',
        data,
      });
    } catch (error) {
      console.error('[JobsService] Failed to send notification', error);
    }
  }
}
