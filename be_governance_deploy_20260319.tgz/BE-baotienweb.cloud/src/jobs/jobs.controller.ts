import {
    Body,
    Controller,
    Get,
    Param,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import {
    AddJobCostItemDto,
    CancelJobDto,
    CompleteJobDto,
    CreateJobEventDto,
    CreateJobReviewDto,
    JobActionDto,
    JobQueryDto,
} from './dto';
import { JobsService } from './jobs.service';

@ApiTags('Jobs - Marketplace lifecycle')
@Controller('jobs')
@UseGuards(ApiKeyGuard)
export class JobsController {
  constructor(private readonly jobsService: JobsService) {}

  @Get('mine')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách job của user hiện tại' })
  async getMyJobs(@Query() query: JobQueryDto, @CurrentUser() user: any) {
    return this.jobsService.getMyJobs(user.id, query);
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy chi tiết job' })
  async getJobDetail(@Param('id') id: string, @CurrentUser() user: any) {
    return this.jobsService.getJobDetail(parseInt(id, 10), user.id);
  }

  @Post(':id/en-route')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Worker xác nhận đang trên đường đến điểm làm việc',
  })
  async markEnRoute(
    @Param('id') id: string,
    @Body() dto: JobActionDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.markEnRoute(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/arrived')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Worker xác nhận đã đến nơi' })
  async markArrived(
    @Param('id') id: string,
    @Body() dto: JobActionDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.markArrived(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/start')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Bắt đầu job' })
  async startJob(
    @Param('id') id: string,
    @Body() dto: JobActionDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.startJob(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/events')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Thêm event thủ công vào job timeline' })
  async addEvent(
    @Param('id') id: string,
    @Body() dto: CreateJobEventDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.addEvent(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/cost-items')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Thêm dòng chi phí cho job' })
  async addCostItem(
    @Param('id') id: string,
    @Body() dto: AddJobCostItemDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.addCostItem(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/complete')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Đánh dấu job hoàn thành và chờ khách xác nhận' })
  async completeJob(
    @Param('id') id: string,
    @Body() dto: CompleteJobDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.completeJob(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/confirm')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khách hàng xác nhận job đã hoàn tất' })
  async confirmCompletion(
    @Param('id') id: string,
    @Body() dto: JobActionDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.confirmCompletion(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy job' })
  async cancelJob(
    @Param('id') id: string,
    @Body() dto: CancelJobDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.cancelJob(parseInt(id, 10), user.id, dto);
  }

  @Post(':id/review')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khách hàng đánh giá job sau khi hoàn thành' })
  async createReview(
    @Param('id') id: string,
    @Body() dto: CreateJobReviewDto,
    @CurrentUser() user: any,
  ) {
    return this.jobsService.createReview(parseInt(id, 10), user.id, dto);
  }
}
