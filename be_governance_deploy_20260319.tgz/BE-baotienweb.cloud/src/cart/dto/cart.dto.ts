import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsPositive } from 'class-validator';

export class AddToCartDto {
  @ApiProperty({ description: 'Product ID to add' })
  @IsInt()
  @IsNotEmpty()
  productId: number;

  @ApiProperty({ description: 'Quantity to add', default: 1 })
  @IsInt()
  @IsPositive()
  quantity: number = 1;
}

export class UpdateCartItemDto {
  @ApiProperty({ description: 'New quantity' })
  @IsInt()
  @IsPositive()
  quantity: number;
}

export class ApplyCouponDto {
  @ApiProperty({ description: 'Coupon code to apply' })
  @IsNotEmpty()
  couponCode: string;
}

export class CartItemResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  productId: number;

  @ApiProperty()
  product: {
    id: number;
    name: string;
    price: number;
    images: { url: string }[];
  };

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  price: number;

  @ApiProperty()
  addedAt: Date;
}

export class CartResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  userId: number;

  @ApiProperty({ type: [CartItemResponseDto] })
  items: CartItemResponseDto[];

  @ApiProperty()
  subtotal: number;

  @ApiProperty()
  discount: number;

  @ApiProperty()
  total: number;

  @ApiProperty()
  itemCount: number;

  @ApiPropertyOptional()
  couponCode?: string;

  @ApiProperty()
  updatedAt: Date;
}

export class CartSummaryDto {
  @ApiProperty()
  itemCount: number;

  @ApiProperty()
  subtotal: number;

  @ApiProperty()
  discount: number;

  @ApiProperty()
  shippingFee: number;

  @ApiProperty()
  total: number;
}

export class SyncCartDto {
  @ApiProperty({ type: [AddToCartDto] })
  items: AddToCartDto[];
}

export class ValidateCartResponseDto {
  @ApiProperty()
  valid: boolean;

  @ApiProperty({ type: [Object] })
  errors: Array<{ productId: number; message: string }>;

  @ApiProperty({ type: CartResponseDto })
  cart: CartResponseDto;
}
