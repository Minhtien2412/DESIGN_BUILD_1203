import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CartService } from './cart.service';
import {
    AddToCartDto,
    ApplyCouponDto,
    CartResponseDto,
    CartSummaryDto,
    SyncCartDto,
    UpdateCartItemDto,
    ValidateCartResponseDto,
} from './dto';

@ApiTags('Cart')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'cart', version: '1' })
export class CartController {
  constructor(private readonly cartService: CartService) {}

  @Get()
  @ApiOperation({ summary: 'Lấy giỏ hàng của user' })
  @ApiResponse({ status: 200, type: CartResponseDto })
  async getCart(@CurrentUser('id') userId: number) {
    return this.cartService.getCart(userId);
  }

  @Post('items')
  @ApiOperation({ summary: 'Thêm sản phẩm vào giỏ hàng' })
  @ApiResponse({ status: 201, type: CartResponseDto })
  async addToCart(
    @CurrentUser('id') userId: number,
    @Body() dto: AddToCartDto,
  ) {
    return this.cartService.addToCart(userId, dto);
  }

  @Patch('items/:itemId')
  @ApiOperation({ summary: 'Cập nhật số lượng sản phẩm' })
  @ApiParam({ name: 'itemId', type: Number })
  @ApiResponse({ status: 200, type: CartResponseDto })
  async updateCartItem(
    @CurrentUser('id') userId: number,
    @Param('itemId', ParseIntPipe) itemId: number,
    @Body() dto: UpdateCartItemDto,
  ) {
    return this.cartService.updateCartItem(userId, itemId, dto);
  }

  @Delete('items/:itemId')
  @ApiOperation({ summary: 'Xóa sản phẩm khỏi giỏ hàng' })
  @ApiParam({ name: 'itemId', type: Number })
  @ApiResponse({ status: 200, type: CartResponseDto })
  async removeFromCart(
    @CurrentUser('id') userId: number,
    @Param('itemId', ParseIntPipe) itemId: number,
  ) {
    return this.cartService.removeFromCart(userId, itemId);
  }

  @Delete()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Xóa toàn bộ giỏ hàng' })
  @ApiResponse({ status: 204, description: 'Giỏ hàng đã được xóa' })
  async clearCart(@CurrentUser('id') userId: number) {
    await this.cartService.clearCart(userId);
  }

  @Post('coupon')
  @ApiOperation({ summary: 'Áp dụng mã giảm giá' })
  @ApiResponse({ status: 200 })
  async applyCoupon(
    @CurrentUser('id') userId: number,
    @Body() dto: ApplyCouponDto,
  ) {
    return this.cartService.applyCoupon(userId, dto.couponCode);
  }

  @Delete('coupon')
  @ApiOperation({ summary: 'Xóa mã giảm giá' })
  @ApiResponse({ status: 200, type: CartResponseDto })
  async removeCoupon(@CurrentUser('id') userId: number) {
    return this.cartService.removeCoupon(userId);
  }

  @Get('summary')
  @ApiOperation({ summary: 'Lấy tổng quan giỏ hàng (nhẹ)' })
  @ApiResponse({ status: 200, type: CartSummaryDto })
  async getCartSummary(@CurrentUser('id') userId: number) {
    return this.cartService.getCartSummary(userId);
  }

  @Post('sync')
  @ApiOperation({ summary: 'Sync local cart khi đăng nhập' })
  @ApiResponse({ status: 200, type: CartResponseDto })
  async syncCart(@CurrentUser('id') userId: number, @Body() dto: SyncCartDto) {
    return this.cartService.syncCart(userId, dto.items);
  }

  @Post('validate')
  @ApiOperation({ summary: 'Validate giỏ hàng trước checkout' })
  @ApiResponse({ status: 200, type: ValidateCartResponseDto })
  async validateCart(@CurrentUser('id') userId: number) {
    return this.cartService.validateCart(userId);
  }
}
