import {
    BadRequestException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AddToCartDto, UpdateCartItemDto } from './dto';

@Injectable()
export class CartService {
  constructor(private prisma: PrismaService) {}

  /**
   * Lấy hoặc tạo giỏ hàng cho user
   */
  async getOrCreateCart(userId: number) {
    let cart = await this.prisma.cart.findUnique({
      where: { userId },
      include: {
        items: {
          include: {
            product: {
              include: {
                images: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!cart) {
      cart = await this.prisma.cart.create({
        data: { userId },
        include: {
          items: {
            include: {
              product: {
                include: {
                  images: true,
                },
              },
            },
          },
        },
      });
    }

    return this.formatCartResponse(cart);
  }

  /**
   * Lấy giỏ hàng của user
   */
  async getCart(userId: number) {
    return this.getOrCreateCart(userId);
  }

  /**
   * Thêm sản phẩm vào giỏ hàng
   */
  async addToCart(userId: number, dto: AddToCartDto) {
    const cart = await this.getOrCreateCart(userId);

    // Check product exists and in stock
    const product = await this.prisma.product.findUnique({
      where: { id: dto.productId },
    });

    if (!product) {
      throw new NotFoundException('Sản phẩm không tồn tại');
    }

    if (product.stock < dto.quantity) {
      throw new BadRequestException('Sản phẩm không đủ số lượng trong kho');
    }

    // Check if item already in cart
    const existingItem = await this.prisma.cartItem.findFirst({
      where: {
        cartId: cart.id,
        productId: dto.productId,
      },
    });

    if (existingItem) {
      // Update quantity
      await this.prisma.cartItem.update({
        where: { id: existingItem.id },
        data: { quantity: existingItem.quantity + dto.quantity },
      });
    } else {
      // Add new item
      await this.prisma.cartItem.create({
        data: {
          cartId: cart.id,
          productId: dto.productId,
          quantity: dto.quantity,
          price: Number(product.price),
        },
      });
    }

    return this.getCart(userId);
  }

  /**
   * Cập nhật số lượng sản phẩm
   */
  async updateCartItem(userId: number, itemId: number, dto: UpdateCartItemDto) {
    const cart = await this.getOrCreateCart(userId);

    const item = await this.prisma.cartItem.findFirst({
      where: { id: itemId, cartId: cart.id },
      include: { product: true },
    });

    if (!item) {
      throw new NotFoundException('Không tìm thấy sản phẩm trong giỏ hàng');
    }

    if (item.product.stock < dto.quantity) {
      throw new BadRequestException('Sản phẩm không đủ số lượng trong kho');
    }

    await this.prisma.cartItem.update({
      where: { id: itemId },
      data: { quantity: dto.quantity },
    });

    return this.getCart(userId);
  }

  /**
   * Xóa sản phẩm khỏi giỏ hàng
   */
  async removeFromCart(userId: number, itemId: number) {
    const cart = await this.getOrCreateCart(userId);

    const item = await this.prisma.cartItem.findFirst({
      where: { id: itemId, cartId: cart.id },
    });

    if (!item) {
      throw new NotFoundException('Không tìm thấy sản phẩm trong giỏ hàng');
    }

    await this.prisma.cartItem.delete({
      where: { id: itemId },
    });

    return this.getCart(userId);
  }

  /**
   * Xóa toàn bộ giỏ hàng
   */
  async clearCart(userId: number) {
    const cart = await this.getOrCreateCart(userId);

    await this.prisma.cartItem.deleteMany({
      where: { cartId: cart.id },
    });

    // Reset coupon
    await this.prisma.cart.update({
      where: { id: cart.id },
      data: { couponCode: null, discount: 0 },
    });

    return this.getCart(userId);
  }

  /**
   * Áp dụng mã giảm giá
   */
  async applyCoupon(userId: number, couponCode: string) {
    const cart = await this.getOrCreateCart(userId);

    // TODO: Implement coupon validation logic
    // For now, just apply a simple discount
    const discount = couponCode.toLowerCase() === 'sale10' ? 10 : 0;

    if (discount === 0) {
      throw new BadRequestException('Mã giảm giá không hợp lệ');
    }

    await this.prisma.cart.update({
      where: { id: cart.id },
      data: { couponCode, discount },
    });

    const updatedCart = await this.getCart(userId);
    return {
      cart: updatedCart,
      discount,
      message: `Đã áp dụng mã giảm giá ${couponCode} - Giảm ${discount}%`,
    };
  }

  /**
   * Xóa mã giảm giá
   */
  async removeCoupon(userId: number) {
    const cart = await this.getOrCreateCart(userId);

    await this.prisma.cart.update({
      where: { id: cart.id },
      data: { couponCode: null, discount: 0 },
    });

    return this.getCart(userId);
  }

  /**
   * Lấy tổng quan giỏ hàng
   */
  async getCartSummary(userId: number) {
    const cart = await this.getCart(userId);

    return {
      itemCount: cart.itemCount,
      subtotal: cart.subtotal,
      discount: cart.discount,
      shippingFee: cart.subtotal > 500000 ? 0 : 30000, // Free shipping > 500k
      total: cart.total,
    };
  }

  /**
   * Sync local cart với server
   */
  async syncCart(userId: number, items: AddToCartDto[]) {
    // Clear existing cart
    await this.clearCart(userId);

    // Add all items
    for (const item of items) {
      try {
        await this.addToCart(userId, item);
      } catch (error) {
        // Skip invalid items
        const message =
          error instanceof Error ? error.message : 'Unknown error';
        console.warn(`Skip invalid item ${item.productId}:`, message);
      }
    }

    return this.getCart(userId);
  }

  /**
   * Validate giỏ hàng trước checkout
   */
  async validateCart(userId: number) {
    const cart = await this.getCart(userId);
    const errors: Array<{ productId: number; message: string }> = [];

    for (const item of cart.items) {
      const product = await this.prisma.product.findUnique({
        where: { id: item.productId },
      });

      if (!product) {
        errors.push({
          productId: item.productId,
          message: 'Sản phẩm không còn tồn tại',
        });
      } else if (product.stock < item.quantity) {
        errors.push({
          productId: item.productId,
          message: `Chỉ còn ${product.stock} sản phẩm trong kho`,
        });
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      cart,
    };
  }

  /**
   * Format cart response
   */
  private formatCartResponse(cart: any) {
    const items = cart.items || [];
    const subtotal = items.reduce(
      (sum: number, item: any) => sum + item.price * item.quantity,
      0,
    );
    const discountAmount = (subtotal * (cart.discount || 0)) / 100;

    return {
      id: cart.id,
      userId: cart.userId,
      items: items.map((item: any) => ({
        id: item.id,
        productId: item.productId,
        product: item.product,
        quantity: item.quantity,
        price: item.price,
        addedAt: item.addedAt,
      })),
      subtotal,
      discount: discountAmount,
      total: subtotal - discountAmount,
      itemCount: items.reduce(
        (sum: number, item: any) => sum + item.quantity,
        0,
      ),
      couponCode: cart.couponCode,
      updatedAt: cart.updatedAt,
    };
  }
}
