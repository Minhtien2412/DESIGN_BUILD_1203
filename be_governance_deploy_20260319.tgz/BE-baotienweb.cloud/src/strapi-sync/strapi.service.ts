import { Injectable, Logger } from '@nestjs/common';
import { getErrorMessage, getAxiosErrorData, getErrorStatus, isAxiosError, logError } from '../utils/error-helpers';

import axios, { AxiosInstance } from 'axios';

@Injectable()
export class StrapiService {
  private readonly logger = new Logger(StrapiService.name);
  private readonly apiClient: AxiosInstance;

  constructor() {
    this.apiClient = axios.create({
      baseURL: (process.env.STRAPI_URL || 'http://localhost:1337') + '/api',
      headers: {
        'Authorization': `Bearer ${process.env.STRAPI_SYNC_TOKEN || 'strapi-sync-token-secret-change-this'}`,
        'Content-Type': 'application/json',
        'X-Backend-Sync': 'true'
      },
      timeout: 10000
    });

    // Log configuration
    this.logger.log(`Strapi service initialized: ${process.env.STRAPI_URL || 'http://localhost:1337'}`);
  }

  /**
   * Sync data từ Backend sang Strapi
   */
  async syncToStrapi(contentType: string, data: any): Promise<boolean> {
    try {
      this.logger.log(`[Backend → Strapi] Syncing ${contentType}...`, {
        id: data.id,
        name: data.name
      });

      const response = await this.apiClient.post('/sync/import', {
        contentType,
        data: {
          id: data.id,
          ...data,
          // Remove nested objects that Strapi doesn't handle
          createdBy: undefined,
          updatedBy: undefined
        }
      });

      this.logger.log(`[Backend → Strapi] ✅ Synced ${contentType} successfully:`, response.data);
      return true;

    } catch (error: unknown) {
      this.logger.error(`[Backend → Strapi] ❌ Failed to sync ${contentType}:`, {
        message: getErrorMessage(error),
        response: getAxiosErrorData(error),
        status: getErrorStatus(error)
      });
      
      // Không throw error để không block backend operations
      return false;
    }
  }

  /**
   * Batch sync nhiều items cùng lúc
   */
  async batchSyncToStrapi(contentType: string, items: any[]): Promise<{ success: number; failed: number }> {
    try {
      this.logger.log(`[Backend → Strapi] Batch syncing ${items.length} ${contentType}...`);

      const response = await this.apiClient.post('/sync/batch-import', {
        contentType,
        items: items.map(item => ({
          id: item.id,
          ...item,
          createdBy: undefined,
          updatedBy: undefined
        }))
      });

      const { results } = response.data;
      this.logger.log(`[Backend → Strapi] ✅ Batch sync completed:`, {
        success: results.success,
        failed: results.failed,
        errors: results.errors
      });

      return {
        success: results.success,
        failed: results.failed
      };

    } catch (error: unknown) {
      this.logger.error(`[Backend → Strapi] ❌ Batch sync failed:`, getErrorMessage(error));
      return {
        success: 0,
        failed: items.length
      };
    }
  }

  /**
   * Test connection với Strapi
   */
  async testConnection(): Promise<boolean> {
    try {
      await this.apiClient.get('/');
      this.logger.log('[Backend → Strapi] ✅ Connection successful');
      return true;
    } catch (error: unknown) {
      this.logger.error('[Backend → Strapi] ❌ Connection failed:', getErrorMessage(error));
      return false;
    }
  }
}
