import { Module } from '@nestjs/common';
import { ProductsModule } from '../products/products.module';
import { ProjectsModule } from '../projects/projects.module';
import { ServicesModule } from '../services/services.module';
import { TasksModule } from '../tasks/tasks.module';
import { StrapiSyncController } from './strapi-sync.controller';
import { StrapiService } from './strapi.service';

@Module({
  imports: [
    ProductsModule,
    ProjectsModule,
    ServicesModule,
    TasksModule,
  ],
  controllers: [StrapiSyncController],
  providers: [StrapiService],
  exports: [StrapiService], // Export để dùng trong các module khác
})
export class StrapiSyncModule {}
