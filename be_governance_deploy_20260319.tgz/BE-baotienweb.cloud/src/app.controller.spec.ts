import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './app.controller';
import { AppService } from './app.service';

describe('AppController', () => {
  let appController: AppController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [AppService],
    }).compile();

    appController = app.get<AppController>(AppController);
  });

  describe('root', () => {
    it('should return API landing page HTML', () => {
      const result = appController.getApiLanding();
      expect(result).toContain('Baotienweb API');
      expect(result).toContain('<!DOCTYPE html>');
    });
  });
});
