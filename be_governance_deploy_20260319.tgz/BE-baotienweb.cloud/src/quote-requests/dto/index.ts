import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEmail,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    MaxLength,
    Min,
    MinLength,
} from 'class-validator';

// ==================== CREATE ====================

export class CreateQuoteRequestDto {
  @ApiProperty({ description: 'Tên dự án' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  projectName: string;

  @ApiProperty({
    description: 'Loại dự án',
    enum: [
      'residential',
      'commercial',
      'office',
      'restaurant',
      'hotel',
      'other',
    ],
  })
  @IsString()
  @IsNotEmpty()
  projectType: string;

  @ApiPropertyOptional({ description: 'Label loại dự án' })
  @IsString()
  @IsOptional()
  projectTypeLabel?: string;

  @ApiPropertyOptional({ description: 'Diện tích (m2)' })
  @IsNumber()
  @IsOptional()
  @Min(0)
  area?: number;

  @ApiPropertyOptional({ description: 'Ngân sách dự kiến' })
  @IsString()
  @IsOptional()
  budget?: string;

  @ApiProperty({ description: 'Mô tả yêu cầu' })
  @IsString()
  @IsNotEmpty()
  @MinLength(10)
  description: string;

  @ApiPropertyOptional({ description: 'Địa chỉ công trình' })
  @IsString()
  @IsOptional()
  address?: string;

  @ApiProperty({ description: 'Tên người liên hệ' })
  @IsString()
  @IsNotEmpty()
  contactName: string;

  @ApiProperty({ description: 'Số điện thoại liên hệ' })
  @IsString()
  @IsNotEmpty()
  contactPhone: string;

  @ApiPropertyOptional({ description: 'Email liên hệ' })
  @IsEmail()
  @IsOptional()
  contactEmail?: string;
}

// ==================== UPDATE (Admin quote) ====================

export class QuoteResponseDto {
  @ApiProperty({ description: 'Giá báo giá' })
  @IsNumber()
  @Min(0)
  quotedPrice: number;

  @ApiPropertyOptional({ description: 'Ghi chú báo giá' })
  @IsString()
  @IsOptional()
  quotedNote?: string;
}

// ==================== REJECT ====================

export class RejectQuoteRequestDto {
  @ApiPropertyOptional({ description: 'Lý do từ chối' })
  @IsString()
  @IsOptional()
  reason?: string;
}

// ==================== QUERY ====================

export class QueryQuoteRequestsDto {
  @ApiPropertyOptional({
    enum: ['pending', 'quoted', 'accepted', 'rejected', 'cancelled', 'expired'],
  })
  @IsOptional()
  @IsEnum(['pending', 'quoted', 'accepted', 'rejected', 'cancelled', 'expired'])
  status?: string;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  limit?: number;

  @ApiPropertyOptional({ default: 0 })
  @IsOptional()
  offset?: number;
}
