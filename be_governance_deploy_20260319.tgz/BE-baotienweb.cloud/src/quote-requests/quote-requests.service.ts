/**
 * Quote Requests Service
 *
 * Business logic for customer quote requests:
 * - Create new quote request (customer)
 * - Get my requests (customer)
 * - Accept/Reject quote (customer)
 * - Cancel request (customer)
 * - Admin: List all, respond with quote
 *
 * @author AI Assistant
 * @date 03/02/2026
 */

import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { QuoteRequestStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateQuoteRequestDto,
    QueryQuoteRequestsDto,
    QuoteResponseDto,
    RejectQuoteRequestDto,
} from './dto';

@Injectable()
export class QuoteRequestsService {
  private readonly logger = new Logger(QuoteRequestsService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Generate unique quote code: QR-YYYYMMDD-XXXX
   */
  private async generateCode(): Promise<string> {
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const prefix = `QR-${dateStr}`;

    // Count today's requests
    const count = await this.prisma.quoteRequest.count({
      where: {
        code: {
          startsWith: prefix,
        },
      },
    });

    const sequence = String(count + 1).padStart(4, '0');
    return `${prefix}-${sequence}`;
  }

  /**
   * Create new quote request (Customer)
   */
  async create(userId: number | null, dto: CreateQuoteRequestDto) {
    this.logger.log(`Creating quote request for user ${userId || 'guest'}`);

    const code = await this.generateCode();

    const request = await this.prisma.quoteRequest.create({
      data: {
        code,
        userId,
        projectName: dto.projectName,
        projectType: dto.projectType,
        projectTypeLabel: dto.projectTypeLabel,
        area: dto.area,
        budget: dto.budget,
        description: dto.description,
        address: dto.address,
        contactName: dto.contactName,
        contactPhone: dto.contactPhone,
        contactEmail: dto.contactEmail,
        status: QuoteRequestStatus.pending,
      },
    });

    this.logger.log(`Created quote request ${request.code}`);

    return {
      id: request.id,
      code: request.code,
      status: request.status,
      createdAt: request.createdAt,
    };
  }

  /**
   * Get my quote requests (Customer)
   */
  async getMyRequests(userId: number, query: QueryQuoteRequestsDto) {
    const { status, limit = 20, offset = 0 } = query;

    const where: any = { userId };
    if (status) {
      where.status = status;
    }

    const [data, total] = await Promise.all([
      this.prisma.quoteRequest.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: +limit,
        skip: +offset,
        select: {
          id: true,
          code: true,
          projectName: true,
          projectType: true,
          projectTypeLabel: true,
          area: true,
          budget: true,
          status: true,
          quotedPrice: true,
          quotedAt: true,
          createdAt: true,
          updatedAt: true,
        },
      }),
      this.prisma.quoteRequest.count({ where }),
    ]);

    return { data, total };
  }

  /**
   * Get single quote request by ID
   */
  async getById(id: number, userId?: number) {
    const request = await this.prisma.quoteRequest.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
          },
        },
      },
    });

    if (!request) {
      throw new NotFoundException('Quote request not found');
    }

    // Check ownership if userId provided
    if (userId && request.userId !== userId) {
      throw new ForbiddenException(
        'You do not have access to this quote request',
      );
    }

    return request;
  }

  /**
   * Accept quote (Customer) - chuyển status sang accepted
   */
  async acceptQuote(id: number, userId: number) {
    const request = await this.getById(id, userId);

    if (request.status !== QuoteRequestStatus.quoted) {
      throw new BadRequestException('Can only accept a quoted request');
    }

    const updated = await this.prisma.quoteRequest.update({
      where: { id },
      data: { status: QuoteRequestStatus.accepted },
    });

    this.logger.log(`Quote request ${request.code} accepted by user ${userId}`);

    return {
      id: updated.id,
      code: updated.code,
      status: updated.status,
      message: 'Quote accepted successfully',
    };
  }

  /**
   * Reject quote (Customer)
   */
  async rejectQuote(id: number, userId: number, dto: RejectQuoteRequestDto) {
    const request = await this.getById(id, userId);

    if (request.status !== QuoteRequestStatus.quoted) {
      throw new BadRequestException('Can only reject a quoted request');
    }

    const updated = await this.prisma.quoteRequest.update({
      where: { id },
      data: {
        status: QuoteRequestStatus.rejected,
        rejectReason: dto.reason,
      },
    });

    this.logger.log(`Quote request ${request.code} rejected by user ${userId}`);

    return {
      id: updated.id,
      code: updated.code,
      status: updated.status,
      message: 'Quote rejected',
    };
  }

  /**
   * Cancel request (Customer) - chỉ cancel được khi pending
   */
  async cancelRequest(id: number, userId: number) {
    const request = await this.getById(id, userId);

    if (request.status !== QuoteRequestStatus.pending) {
      throw new BadRequestException('Can only cancel a pending request');
    }

    const updated = await this.prisma.quoteRequest.update({
      where: { id },
      data: { status: QuoteRequestStatus.cancelled },
    });

    this.logger.log(
      `Quote request ${request.code} cancelled by user ${userId}`,
    );

    return {
      id: updated.id,
      code: updated.code,
      status: updated.status,
      message: 'Request cancelled',
    };
  }

  /**
   * Delete request (Customer) - soft delete by cancelling
   */
  async deleteRequest(id: number, userId: number) {
    const request = await this.getById(id, userId);

    // Only allow delete pending/cancelled requests
    const allowedStatuses: QuoteRequestStatus[] = [
      QuoteRequestStatus.pending,
      QuoteRequestStatus.cancelled,
    ];
    if (!allowedStatuses.includes(request.status)) {
      throw new BadRequestException(
        'Cannot delete a request that has been quoted',
      );
    }

    await this.prisma.quoteRequest.delete({
      where: { id },
    });

    this.logger.log(`Quote request ${request.code} deleted by user ${userId}`);

    return {
      success: true,
      message: 'Request deleted',
    };
  }

  // ==================== ADMIN FUNCTIONS ====================

  /**
   * Get all quote requests (Admin)
   */
  async getAllRequests(query: QueryQuoteRequestsDto) {
    const { status, limit = 50, offset = 0 } = query;

    const where: any = {};
    if (status) {
      where.status = status;
    }

    const [data, total] = await Promise.all([
      this.prisma.quoteRequest.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: +limit,
        skip: +offset,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            },
          },
        },
      }),
      this.prisma.quoteRequest.count({ where }),
    ]);

    return { data, total };
  }

  /**
   * Respond with quote (Admin)
   */
  async respondWithQuote(id: number, adminId: number, dto: QuoteResponseDto) {
    const request = await this.prisma.quoteRequest.findUnique({
      where: { id },
    });

    if (!request) {
      throw new NotFoundException('Quote request not found');
    }

    if (request.status !== QuoteRequestStatus.pending) {
      throw new BadRequestException('Can only quote a pending request');
    }

    const updated = await this.prisma.quoteRequest.update({
      where: { id },
      data: {
        status: QuoteRequestStatus.quoted,
        quotedPrice: dto.quotedPrice,
        quotedNote: dto.quotedNote,
        quotedBy: adminId,
        quotedAt: new Date(),
      },
    });

    this.logger.log(`Quote request ${request.code} quoted by admin ${adminId}`);

    return {
      id: updated.id,
      code: updated.code,
      status: updated.status,
      quotedPrice: updated.quotedPrice,
      message: 'Quote sent to customer',
    };
  }
}
