/**
 * Quote Requests Module
 *
 * Module for customer quote requests feature
 *
 * @author AI Assistant
 * @date 03/02/2026
 */

import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import { PrismaModule } from '../prisma/prisma.module';
import { QuoteRequestsController } from './quote-requests.controller';
import { QuoteRequestsService } from './quote-requests.service';

@Module({
  imports: [
    PrismaModule,
    ConfigModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: '7d' },
      }),
      inject: [ConfigService],
    }),
  ],
  controllers: [QuoteRequestsController],
  providers: [QuoteRequestsService, OptionalAuthGuard],
  exports: [QuoteRequestsService],
})
export class QuoteRequestsModule {}
