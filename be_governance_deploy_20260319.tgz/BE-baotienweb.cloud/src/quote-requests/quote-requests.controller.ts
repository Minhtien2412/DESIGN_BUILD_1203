/**
 * Quote Requests Controller
 *
 * API Endpoints for customer quote requests:
 * - POST /quote-requests - Create new quote request
 * - GET /quote-requests/my - Get my quote requests
 * - GET /quote-requests/:id - Get quote request detail
 * - POST /quote-requests/:id/accept - Accept quote
 * - POST /quote-requests/:id/reject - Reject quote
 * - POST /quote-requests/:id/cancel - Cancel request
 * - DELETE /quote-requests/:id - Delete request
 *
 * Admin endpoints:
 * - GET /quote-requests/admin/all - Get all requests
 * - POST /quote-requests/:id/quote - Respond with quote
 *
 * @author AI Assistant
 * @date 03/02/2026
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Logger,
    Param,
    ParseIntPipe,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OptionalAuthGuard } from '../auth/guards/optional-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import {
    CreateQuoteRequestDto,
    QueryQuoteRequestsDto,
    QuoteResponseDto,
    RejectQuoteRequestDto,
} from './dto';
import { QuoteRequestsService } from './quote-requests.service';

@ApiTags('Quote Requests')
@Controller({ path: 'quote-requests', version: '1' })
export class QuoteRequestsController {
  private readonly logger = new Logger(QuoteRequestsController.name);

  constructor(private readonly quoteRequestsService: QuoteRequestsService) {}

  /**
   * Create new quote request
   * POST /api/v1/quote-requests
   * Can be called by guest or authenticated user
   */
  @Post()
  @UseGuards(OptionalAuthGuard)
  @ApiOperation({ summary: 'Tạo yêu cầu báo giá mới (customer/guest)' })
  async create(@Body() dto: CreateQuoteRequestDto, @Req() req: any) {
    const userId = req.user?.id || null;
    this.logger.log(`Creating quote request by user ${userId || 'guest'}`);

    return this.quoteRequestsService.create(userId, dto);
  }

  /**
   * Get my quote requests
   * GET /api/v1/quote-requests/my
   */
  @Get('my')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách yêu cầu báo giá của tôi' })
  async getMyRequests(@Query() query: QueryQuoteRequestsDto, @Req() req: any) {
    const userId = req.user.id;
    return this.quoteRequestsService.getMyRequests(userId, query);
  }

  /**
   * Get quote request by ID
   * GET /api/v1/quote-requests/:id
   */
  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy chi tiết yêu cầu báo giá' })
  async getById(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    const userId = req.user.id;
    return this.quoteRequestsService.getById(id, userId);
  }

  /**
   * Accept quote
   * POST /api/v1/quote-requests/:id/accept
   */
  @Post(':id/accept')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Chấp nhận báo giá' })
  async acceptQuote(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    const userId = req.user.id;
    return this.quoteRequestsService.acceptQuote(id, userId);
  }

  /**
   * Reject quote
   * POST /api/v1/quote-requests/:id/reject
   */
  @Post(':id/reject')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Từ chối báo giá' })
  async rejectQuote(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RejectQuoteRequestDto,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    return this.quoteRequestsService.rejectQuote(id, userId, dto);
  }

  /**
   * Cancel request
   * POST /api/v1/quote-requests/:id/cancel
   */
  @Post(':id/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Hủy yêu cầu báo giá' })
  async cancelRequest(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    const userId = req.user.id;
    return this.quoteRequestsService.cancelRequest(id, userId);
  }

  /**
   * Delete request
   * DELETE /api/v1/quote-requests/:id
   */
  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Xóa yêu cầu báo giá' })
  async deleteRequest(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    const userId = req.user.id;
    return this.quoteRequestsService.deleteRequest(id, userId);
  }

  // ==================== ADMIN ENDPOINTS ====================

  /**
   * Get all quote requests (Admin)
   * GET /api/v1/quote-requests/admin/all
   */
  @Get('admin/all')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN', 'STAFF')
  @ApiBearerAuth()
  @ApiOperation({ summary: '[Admin] Lấy tất cả yêu cầu báo giá' })
  async getAllRequests(@Query() query: QueryQuoteRequestsDto) {
    return this.quoteRequestsService.getAllRequests(query);
  }

  /**
   * Respond with quote (Admin)
   * POST /api/v1/quote-requests/:id/quote
   */
  @Post(':id/quote')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN', 'STAFF')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: '[Admin] Gửi báo giá cho khách hàng' })
  async respondWithQuote(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: QuoteResponseDto,
    @Req() req: any,
  ) {
    const adminId = req.user.id;
    return this.quoteRequestsService.respondWithQuote(id, adminId, dto);
  }
}
