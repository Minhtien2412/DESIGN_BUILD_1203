import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsDateString,
    IsEmail,
    IsEnum,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';
import {
    DocumentCategory,
    DocumentStatus,
    TransmittalPurpose,
    TransmittalStatus,
} from '../entities';

// ========== DOCUMENT DTOs ==========

export class CreateDocumentDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty()
  @IsString()
  documentNumber: string;

  @ApiProperty({ enum: DocumentCategory })
  @IsEnum(DocumentCategory)
  category: DocumentCategory;

  @ApiProperty()
  @IsString()
  fileUrl: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  fileSize?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  fileType?: string;

  @ApiProperty()
  @IsNumber()
  uploadedBy: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  expiryDate?: string;
}

export class UpdateDocumentDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: DocumentStatus })
  @IsOptional()
  @IsEnum(DocumentStatus)
  status?: DocumentStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  expiryDate?: string;
}

export class UploadRevisionDto {
  @ApiProperty()
  @IsString()
  changes: string;

  @ApiProperty()
  @IsString()
  fileUrl: string;

  @ApiProperty()
  @IsNumber()
  changedBy: number;
}

export class ReviewDocumentDto {
  @ApiProperty()
  @IsNumber()
  reviewedBy: number;

  @ApiProperty()
  @IsBoolean()
  approved: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;
}

export class QueryDocumentDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: DocumentStatus })
  @IsOptional()
  @IsEnum(DocumentStatus)
  status?: DocumentStatus;

  @ApiPropertyOptional({ enum: DocumentCategory })
  @IsOptional()
  @IsEnum(DocumentCategory)
  category?: DocumentCategory;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  offset?: number;
}

// ========== TRANSMITTAL DTOs ==========

export class CreateTransmittalDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  subject: string;

  @ApiProperty({ enum: TransmittalPurpose })
  @IsEnum(TransmittalPurpose)
  purpose: TransmittalPurpose;

  @ApiProperty()
  @IsString()
  fromCompany: string;

  @ApiProperty()
  @IsString()
  fromPerson: string;

  @ApiProperty()
  @IsString()
  toCompany: string;

  @ApiProperty()
  @IsString()
  toPerson: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  ccList?: string[];

  @ApiProperty({ type: [Number] })
  @IsArray()
  @IsNumber({}, { each: true })
  documents: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  remarks?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  responseRequired?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  responseDueDate?: string;

  @ApiProperty()
  @IsNumber()
  createdBy: number;
}

export class UpdateTransmittalDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  subject?: string;

  @ApiPropertyOptional({ enum: TransmittalStatus })
  @IsOptional()
  @IsEnum(TransmittalStatus)
  status?: TransmittalStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  remarks?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  documents?: number[];
}

export class SendTransmittalDto {
  @ApiProperty()
  @IsNumber()
  sentBy: number;
}

export class AcknowledgeTransmittalDto {
  @ApiProperty()
  @IsNumber()
  acknowledgedBy: number;
}

export class RespondTransmittalDto {
  @ApiProperty()
  @IsNumber()
  respondedBy: number;

  @ApiProperty()
  @IsString()
  responseRemarks: string;
}

export class QueryTransmittalDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: TransmittalStatus })
  @IsOptional()
  @IsEnum(TransmittalStatus)
  status?: TransmittalStatus;

  @ApiPropertyOptional({ enum: TransmittalPurpose })
  @IsOptional()
  @IsEnum(TransmittalPurpose)
  purpose?: TransmittalPurpose;
}

// ========== DISTRIBUTION DTOs ==========

export class DistributeDocumentDto {
  @ApiProperty()
  @IsNumber()
  recipientId: number;

  @ApiProperty()
  @IsString()
  recipientName: string;

  @ApiProperty()
  @IsEmail()
  recipientEmail: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

// ========== COMMENT DTOs ==========

/**
 * DTO for adding comments to documents
 * Renamed from AddCommentDto to avoid Swagger duplicate name conflict
 */
export class DocumentCommentDto {
  @ApiProperty({ description: 'User ID of the commenter' })
  @IsNumber()
  userId: number;

  @ApiProperty({ description: 'Comment text content' })
  @IsString()
  comment: string;

  @ApiPropertyOptional({ description: 'Page number for the comment' })
  @IsOptional()
  @IsNumber()
  pageNumber?: number;
}

export class ResolveCommentDto {
  @ApiProperty()
  @IsNumber()
  resolvedBy: number;
}
