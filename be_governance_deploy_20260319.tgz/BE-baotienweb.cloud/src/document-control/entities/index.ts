// Document Control Module Entities

export enum DocumentStatus {
  DRAFT = 'draft',
  REVIEW = 'review',
  APPROVED = 'approved',
  SUPERSEDED = 'superseded',
  OBSOLETE = 'obsolete',
}

export enum DocumentCategory {
  DESIGN = 'design',
  SPECIFICATION = 'specification',
  PROCEDURE = 'procedure',
  REPORT = 'report',
  CONTRACT = 'contract',
  CORRESPONDENCE = 'correspondence',
  SUBMITTAL = 'submittal',
  RFI = 'rfi',
  CHANGE_ORDER = 'change_order',
  MEETING_MINUTES = 'meeting_minutes',
}

export enum TransmittalStatus {
  DRAFT = 'draft',
  SENT = 'sent',
  ACKNOWLEDGED = 'acknowledged',
  RESPONDED = 'responded',
}

export enum TransmittalPurpose {
  FOR_APPROVAL = 'for_approval',
  FOR_REVIEW = 'for_review',
  FOR_INFORMATION = 'for_information',
  FOR_CONSTRUCTION = 'for_construction',
  AS_REQUESTED = 'as_requested',
}

export interface Document {
  id: number;
  projectId: number;
  title: string;
  description?: string;
  documentNumber: string;
  category: DocumentCategory;
  status: DocumentStatus;
  version: number;
  revision: string;
  fileUrl: string;
  fileSize: number;
  fileType: string;
  uploadedBy: number;
  uploadedByName: string;
  reviewedBy?: number;
  reviewedByName?: string;
  reviewedAt?: Date;
  approvedBy?: number;
  approvedByName?: string;
  approvedAt?: Date;
  tags?: string[];
  metadata?: Record<string, any>;
  expiryDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface DocumentRevision {
  id: number;
  documentId: number;
  revision: string;
  changes: string;
  changedBy: number;
  changedByName: string;
  fileUrl: string;
  createdAt: Date;
}

export interface Transmittal {
  id: number;
  projectId: number;
  transmittalNumber: string;
  subject: string;
  purpose: TransmittalPurpose;
  status: TransmittalStatus;
  fromCompany: string;
  fromPerson: string;
  toCompany: string;
  toPerson: string;
  ccList?: string[];
  documents: number[]; // Document IDs
  remarks?: string;
  responseRequired: boolean;
  responseDueDate?: Date;
  responseDate?: Date;
  responseRemarks?: string;
  sentDate?: Date;
  acknowledgedDate?: Date;
  createdBy: number;
  createdByName: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface DocumentDistribution {
  id: number;
  documentId: number;
  recipientId: number;
  recipientName: string;
  recipientEmail: string;
  sentDate: Date;
  acknowledgedDate?: Date;
  notes?: string;
}

export interface DocumentComment {
  id: number;
  documentId: number;
  userId: number;
  userName: string;
  comment: string;
  pageNumber?: number;
  resolved: boolean;
  resolvedBy?: number;
  resolvedAt?: Date;
  createdAt: Date;
}

export interface DocumentControlDashboard {
  totalDocuments: number;
  documentsByStatus: Record<DocumentStatus, number>;
  documentsByCategory: Record<DocumentCategory, number>;
  pendingReviews: number;
  pendingApprovals: number;
  totalTransmittals: number;
  pendingTransmittals: number;
  overdueResponses: number;
  recentDocuments: Document[];
}
