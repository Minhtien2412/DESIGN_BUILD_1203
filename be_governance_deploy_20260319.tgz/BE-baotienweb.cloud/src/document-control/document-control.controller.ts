import {
    Body,
    Controller,
    Get,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
} from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { DocumentControlService } from './document-control.service';
import {
    AcknowledgeTransmittalDto,
    CreateDocumentDto,
    CreateTransmittalDto,
    DistributeDocumentDto,
    DocumentCommentDto,
    QueryDocumentDto,
    QueryTransmittalDto,
    ResolveCommentDto,
    RespondTransmittalDto,
    ReviewDocumentDto,
    SendTransmittalDto,
    UpdateDocumentDto,
    UpdateTransmittalDto,
    UploadRevisionDto,
} from './dto';
import {
    DocumentCategory,
    DocumentStatus,
    TransmittalPurpose,
    TransmittalStatus,
} from './entities';

@ApiTags('Document Control')
@Controller('document-control')
export class DocumentControlController {
  constructor(
    private readonly documentControlService: DocumentControlService,
  ) {}

  // ========== DASHBOARD ==========

  @Get('dashboard')
  @ApiOperation({ summary: 'Get document control dashboard metrics' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Dashboard metrics retrieved',
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getDashboard(@Query('projectId') projectId?: string) {
    return this.documentControlService.getDashboard(
      projectId ? parseInt(projectId) : undefined,
    );
  }

  // ========== DOCUMENTS ==========

  @Get('documents')
  @ApiOperation({ summary: 'Get documents with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Documents retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: DocumentStatus })
  @ApiQuery({ name: 'category', required: false, enum: DocumentCategory })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'offset', required: false, type: Number })
  async getDocuments(@Query() query: QueryDocumentDto) {
    return this.documentControlService.getDocuments(query);
  }

  @Get('documents/:id')
  @ApiOperation({ summary: 'Get document by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Document retrieved' })
  async getDocumentById(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.getDocumentById(id);
  }

  @Post('documents')
  @ApiOperation({ summary: 'Create a new document' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Document created' })
  async createDocument(@Body() dto: CreateDocumentDto) {
    return this.documentControlService.createDocument(dto);
  }

  @Put('documents/:id')
  @ApiOperation({ summary: 'Update a document' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Document updated' })
  async updateDocument(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateDocumentDto,
  ) {
    return this.documentControlService.updateDocument(id, dto);
  }

  @Post('documents/:id/revisions')
  @ApiOperation({ summary: 'Upload a new revision' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Revision uploaded' })
  async uploadRevision(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UploadRevisionDto,
  ) {
    return this.documentControlService.uploadRevision(id, dto);
  }

  @Get('documents/:id/revisions')
  @ApiOperation({ summary: 'Get document revisions' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Revisions retrieved' })
  async getRevisions(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.getRevisions(id);
  }

  @Patch('documents/:id/submit-review')
  @ApiOperation({ summary: 'Submit document for review' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Document submitted for review',
  })
  async submitForReview(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.submitForReview(id);
  }

  @Patch('documents/:id/review')
  @ApiOperation({ summary: 'Review a document' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Document reviewed' })
  async reviewDocument(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ReviewDocumentDto,
  ) {
    return this.documentControlService.reviewDocument(id, dto);
  }

  // ========== DISTRIBUTION ==========

  @Post('documents/:id/distribute')
  @ApiOperation({ summary: 'Distribute document to recipient' })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Document distributed',
  })
  async distributeDocument(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: DistributeDocumentDto,
  ) {
    return this.documentControlService.distributeDocument(id, dto);
  }

  @Get('documents/:id/distributions')
  @ApiOperation({ summary: 'Get document distributions' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Distributions retrieved',
  })
  async getDistributions(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.getDistributions(id);
  }

  // ========== COMMENTS ==========

  @Get('documents/:id/comments')
  @ApiOperation({ summary: 'Get document comments' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Comments retrieved' })
  async getComments(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.getComments(id);
  }

  @Post('documents/:id/comments')
  @ApiOperation({ summary: 'Add comment to document' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Comment added' })
  async addComment(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: DocumentCommentDto,
  ) {
    return this.documentControlService.addComment(id, dto);
  }

  @Patch('documents/:documentId/comments/:commentId/resolve')
  @ApiOperation({ summary: 'Resolve a comment' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Comment resolved' })
  async resolveComment(
    @Param('documentId', ParseIntPipe) documentId: number,
    @Param('commentId', ParseIntPipe) commentId: number,
    @Body() dto: ResolveCommentDto,
  ) {
    return this.documentControlService.resolveComment(
      documentId,
      commentId,
      dto,
    );
  }

  // ========== TRANSMITTALS ==========

  @Get('transmittals')
  @ApiOperation({ summary: 'Get transmittals with filtering' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Transmittals retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: TransmittalStatus })
  @ApiQuery({ name: 'purpose', required: false, enum: TransmittalPurpose })
  async getTransmittals(@Query() query: QueryTransmittalDto) {
    return this.documentControlService.getTransmittals(query);
  }

  @Get('transmittals/:id')
  @ApiOperation({ summary: 'Get transmittal by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Transmittal retrieved' })
  async getTransmittalById(@Param('id', ParseIntPipe) id: number) {
    return this.documentControlService.getTransmittalById(id);
  }

  @Post('transmittals')
  @ApiOperation({ summary: 'Create a new transmittal' })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Transmittal created',
  })
  async createTransmittal(@Body() dto: CreateTransmittalDto) {
    return this.documentControlService.createTransmittal(dto);
  }

  @Put('transmittals/:id')
  @ApiOperation({ summary: 'Update a transmittal' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Transmittal updated' })
  async updateTransmittal(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateTransmittalDto,
  ) {
    return this.documentControlService.updateTransmittal(id, dto);
  }

  @Patch('transmittals/:id/send')
  @ApiOperation({ summary: 'Send a transmittal' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Transmittal sent' })
  async sendTransmittal(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: SendTransmittalDto,
  ) {
    return this.documentControlService.sendTransmittal(id, dto);
  }

  @Patch('transmittals/:id/acknowledge')
  @ApiOperation({ summary: 'Acknowledge a transmittal' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Transmittal acknowledged',
  })
  async acknowledgeTransmittal(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: AcknowledgeTransmittalDto,
  ) {
    return this.documentControlService.acknowledgeTransmittal(id, dto);
  }

  @Patch('transmittals/:id/respond')
  @ApiOperation({ summary: 'Respond to a transmittal' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Transmittal responded' })
  async respondTransmittal(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RespondTransmittalDto,
  ) {
    return this.documentControlService.respondTransmittal(id, dto);
  }

  // ========== HEALTH ==========

  @Get('health')
  @ApiOperation({ summary: 'Document control module health check' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Service is healthy' })
  async health() {
    return {
      status: 'ok',
      service: 'document-control',
      timestamp: new Date().toISOString(),
    };
  }
}
