import {
    BadRequestException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import {
    AcknowledgeTransmittalDto,
    CreateDocumentDto,
    CreateTransmittalDto,
    DistributeDocumentDto,
    DocumentCommentDto,
    QueryDocumentDto,
    QueryTransmittalDto,
    ResolveCommentDto,
    RespondTransmittalDto,
    ReviewDocumentDto,
    SendTransmittalDto,
    UpdateDocumentDto,
    UpdateTransmittalDto,
    UploadRevisionDto,
} from './dto';
import {
    Document,
    DocumentCategory,
    DocumentComment,
    DocumentControlDashboard,
    DocumentDistribution,
    DocumentRevision,
    DocumentStatus,
    Transmittal,
    TransmittalPurpose,
    TransmittalStatus,
} from './entities';

@Injectable()
export class DocumentControlService {
  private documents: Map<number, Document> = new Map();
  private revisions: Map<number, DocumentRevision> = new Map();
  private transmittals: Map<number, Transmittal> = new Map();
  private distributions: Map<number, DocumentDistribution> = new Map();
  private comments: Map<number, DocumentComment> = new Map();

  private documentIdCounter = 1;
  private revisionIdCounter = 1;
  private transmittalIdCounter = 1;
  private distributionIdCounter = 1;
  private commentIdCounter = 1;
  private transmittalCounter = 1;

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const now = new Date();
    const users = [
      { id: 1, name: 'KS. Nguyễn Văn Tài Liệu' },
      { id: 2, name: 'CN. Trần Thị Kiểm Soát' },
      { id: 3, name: 'KS. Lê Văn Duyệt' },
    ];

    const categories = Object.values(DocumentCategory);
    const statuses = Object.values(DocumentStatus);

    // Sample documents
    for (let i = 0; i < 20; i++) {
      const user = users[i % users.length];
      const category = categories[i % categories.length];
      const status = statuses[i % statuses.length];

      const doc: Document = {
        id: this.documentIdCounter++,
        projectId: (i % 3) + 1,
        title: `Tài liệu ${category} - ${i + 1}`,
        description: `Mô tả tài liệu ${category}`,
        documentNumber: `DOC-${category.toUpperCase().substring(0, 3)}-${String(i + 1).padStart(4, '0')}`,
        category,
        status,
        version: 1,
        revision: String.fromCharCode(65 + (i % 4)),
        fileUrl: `/uploads/documents/doc_${i + 1}.pdf`,
        fileSize: 1024 * 1024 * (1 + Math.random() * 5),
        fileType: 'application/pdf',
        uploadedBy: user.id,
        uploadedByName: user.name,
        reviewedBy:
          status !== DocumentStatus.DRAFT
            ? users[(i + 1) % users.length].id
            : undefined,
        reviewedByName:
          status !== DocumentStatus.DRAFT
            ? users[(i + 1) % users.length].name
            : undefined,
        reviewedAt:
          status !== DocumentStatus.DRAFT
            ? new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000)
            : undefined,
        approvedBy:
          status === DocumentStatus.APPROVED
            ? users[(i + 2) % users.length].id
            : undefined,
        approvedByName:
          status === DocumentStatus.APPROVED
            ? users[(i + 2) % users.length].name
            : undefined,
        approvedAt:
          status === DocumentStatus.APPROVED
            ? new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000)
            : undefined,
        tags: [category, `dự-án-${(i % 3) + 1}`],
        createdAt: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      };
      this.documents.set(doc.id, doc);

      // Add revisions
      if (i < 5) {
        for (let r = 0; r < 2; r++) {
          const revision: DocumentRevision = {
            id: this.revisionIdCounter++,
            documentId: doc.id,
            revision: String.fromCharCode(65 + r),
            changes: `Cập nhật nội dung revision ${String.fromCharCode(65 + r)}`,
            changedBy: user.id,
            changedByName: user.name,
            fileUrl: `/uploads/revisions/doc_${doc.id}_rev_${r}.pdf`,
            createdAt: new Date(now.getTime() - (i + r) * 24 * 60 * 60 * 1000),
          };
          this.revisions.set(revision.id, revision);
        }
      }

      // Add comments
      if (i < 3) {
        const comment: DocumentComment = {
          id: this.commentIdCounter++,
          documentId: doc.id,
          userId: users[(i + 1) % users.length].id,
          userName: users[(i + 1) % users.length].name,
          comment: 'Cần kiểm tra lại nội dung trang này',
          pageNumber: 5 + i,
          resolved: i === 0,
          resolvedBy: i === 0 ? user.id : undefined,
          resolvedAt: i === 0 ? new Date() : undefined,
          createdAt: new Date(),
        };
        this.comments.set(comment.id, comment);
      }
    }

    // Sample transmittals
    const purposes = Object.values(TransmittalPurpose);
    const transmittalStatuses = Object.values(TransmittalStatus);

    for (let i = 0; i < 8; i++) {
      const user = users[i % users.length];
      const transmittal: Transmittal = {
        id: this.transmittalIdCounter++,
        projectId: (i % 3) + 1,
        transmittalNumber: `TR-${now.getFullYear()}-${String(this.transmittalCounter++).padStart(4, '0')}`,
        subject: `Gửi tài liệu ${purposes[i % purposes.length]}`,
        purpose: purposes[i % purposes.length],
        status: transmittalStatuses[i % transmittalStatuses.length],
        fromCompany: 'Công ty TNHH ABC',
        fromPerson: user.name,
        toCompany: 'Chủ đầu tư XYZ',
        toPerson: 'Ông Nguyễn Văn A',
        ccList: ['cc1@example.com', 'cc2@example.com'],
        documents: [1, 2, 3].map((d) => d + i),
        remarks: `Ghi chú transmittal ${i + 1}`,
        responseRequired: i % 2 === 0,
        responseDueDate:
          i % 2 === 0
            ? new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
            : undefined,
        sentDate:
          i > 1 ? new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000) : undefined,
        acknowledgedDate:
          i > 2 ? new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000) : undefined,
        responseDate:
          i > 3 ? new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000) : undefined,
        responseRemarks: i > 3 ? 'Đã nhận và xem xét tài liệu' : undefined,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
        updatedAt: new Date(),
      };
      this.transmittals.set(transmittal.id, transmittal);
    }
  }

  // ========== DASHBOARD ==========

  async getDashboard(projectId?: number): Promise<DocumentControlDashboard> {
    let documents = Array.from(this.documents.values());
    let transmittals = Array.from(this.transmittals.values());

    if (projectId) {
      documents = documents.filter((d) => d.projectId === projectId);
      transmittals = transmittals.filter((t) => t.projectId === projectId);
    }

    const now = new Date();

    const documentsByStatus = Object.values(DocumentStatus).reduce(
      (acc, status) => {
        acc[status] = documents.filter((d) => d.status === status).length;
        return acc;
      },
      {} as Record<DocumentStatus, number>,
    );

    const documentsByCategory = Object.values(DocumentCategory).reduce(
      (acc, cat) => {
        acc[cat] = documents.filter((d) => d.category === cat).length;
        return acc;
      },
      {} as Record<DocumentCategory, number>,
    );

    const overdueResponses = transmittals.filter(
      (t) =>
        t.responseRequired &&
        t.responseDueDate &&
        t.responseDueDate < now &&
        !t.responseDate,
    ).length;

    return {
      totalDocuments: documents.length,
      documentsByStatus,
      documentsByCategory,
      pendingReviews: documents.filter(
        (d) => d.status === DocumentStatus.REVIEW,
      ).length,
      pendingApprovals: documents.filter(
        (d) => d.status === DocumentStatus.REVIEW && d.reviewedBy,
      ).length,
      totalTransmittals: transmittals.length,
      pendingTransmittals: transmittals.filter(
        (t) => t.status === TransmittalStatus.DRAFT,
      ).length,
      overdueResponses,
      recentDocuments: documents
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, 5),
    };
  }

  // ========== DOCUMENTS ==========

  async getDocuments(
    query: QueryDocumentDto,
  ): Promise<{ data: Document[]; total: number }> {
    let documents = Array.from(this.documents.values());

    if (query.projectId)
      documents = documents.filter((d) => d.projectId === query.projectId);
    if (query.status)
      documents = documents.filter((d) => d.status === query.status);
    if (query.category)
      documents = documents.filter((d) => d.category === query.category);
    if (query.search) {
      const search = query.search.toLowerCase();
      documents = documents.filter(
        (d) =>
          d.title.toLowerCase().includes(search) ||
          d.documentNumber.toLowerCase().includes(search) ||
          d.description?.toLowerCase().includes(search),
      );
    }

    const total = documents.length;
    const offset = query.offset || 0;
    const limit = query.limit || 50;

    return {
      data: documents
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(offset, offset + limit),
      total,
    };
  }

  async getDocumentById(id: number): Promise<Document> {
    const doc = this.documents.get(id);
    if (!doc) throw new NotFoundException(`Document ${id} not found`);
    return doc;
  }

  async createDocument(dto: CreateDocumentDto): Promise<Document> {
    const doc: Document = {
      id: this.documentIdCounter++,
      ...dto,
      status: DocumentStatus.DRAFT,
      version: 1,
      revision: 'A',
      fileSize: dto.fileSize || 0,
      fileType: dto.fileType || 'application/pdf',
      uploadedByName: `User ${dto.uploadedBy}`,
      expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.documents.set(doc.id, doc);
    return doc;
  }

  async updateDocument(id: number, dto: UpdateDocumentDto): Promise<Document> {
    const doc = await this.getDocumentById(id);

    if (dto.title) doc.title = dto.title;
    if (dto.description) doc.description = dto.description;
    if (dto.status) doc.status = dto.status;
    if (dto.tags) doc.tags = dto.tags;
    if (dto.metadata) doc.metadata = { ...doc.metadata, ...dto.metadata };
    if (dto.expiryDate) doc.expiryDate = new Date(dto.expiryDate);

    doc.updatedAt = new Date();
    this.documents.set(id, doc);
    return doc;
  }

  async uploadRevision(
    id: number,
    dto: UploadRevisionDto,
  ): Promise<DocumentRevision> {
    const doc = await this.getDocumentById(id);

    const revision: DocumentRevision = {
      id: this.revisionIdCounter++,
      documentId: id,
      revision: String.fromCharCode(65 + doc.version),
      changes: dto.changes,
      changedBy: dto.changedBy,
      changedByName: `User ${dto.changedBy}`,
      fileUrl: dto.fileUrl,
      createdAt: new Date(),
    };

    doc.version++;
    doc.revision = revision.revision;
    doc.fileUrl = dto.fileUrl;
    doc.status = DocumentStatus.DRAFT;
    doc.updatedAt = new Date();

    this.revisions.set(revision.id, revision);
    this.documents.set(id, doc);

    return revision;
  }

  async getRevisions(documentId: number): Promise<DocumentRevision[]> {
    await this.getDocumentById(documentId);
    return Array.from(this.revisions.values())
      .filter((r) => r.documentId === documentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async submitForReview(id: number): Promise<Document> {
    const doc = await this.getDocumentById(id);

    if (doc.status !== DocumentStatus.DRAFT) {
      throw new BadRequestException(
        'Only draft documents can be submitted for review',
      );
    }

    doc.status = DocumentStatus.REVIEW;
    doc.updatedAt = new Date();
    this.documents.set(id, doc);
    return doc;
  }

  async reviewDocument(id: number, dto: ReviewDocumentDto): Promise<Document> {
    const doc = await this.getDocumentById(id);

    doc.reviewedBy = dto.reviewedBy;
    doc.reviewedByName = `User ${dto.reviewedBy}`;
    doc.reviewedAt = new Date();

    if (dto.approved) {
      doc.status = DocumentStatus.APPROVED;
      doc.approvedBy = dto.reviewedBy;
      doc.approvedByName = `User ${dto.reviewedBy}`;
      doc.approvedAt = new Date();
    } else {
      doc.status = DocumentStatus.DRAFT;
    }

    doc.updatedAt = new Date();
    this.documents.set(id, doc);
    return doc;
  }

  // ========== TRANSMITTALS ==========

  async getTransmittals(query: QueryTransmittalDto): Promise<Transmittal[]> {
    let transmittals = Array.from(this.transmittals.values());

    if (query.projectId)
      transmittals = transmittals.filter(
        (t) => t.projectId === query.projectId,
      );
    if (query.status)
      transmittals = transmittals.filter((t) => t.status === query.status);
    if (query.purpose)
      transmittals = transmittals.filter((t) => t.purpose === query.purpose);

    return transmittals.sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
  }

  async getTransmittalById(id: number): Promise<Transmittal> {
    const transmittal = this.transmittals.get(id);
    if (!transmittal)
      throw new NotFoundException(`Transmittal ${id} not found`);
    return transmittal;
  }

  async createTransmittal(dto: CreateTransmittalDto): Promise<Transmittal> {
    const now = new Date();
    const transmittal: Transmittal = {
      id: this.transmittalIdCounter++,
      ...dto,
      transmittalNumber: `TR-${now.getFullYear()}-${String(this.transmittalCounter++).padStart(4, '0')}`,
      status: TransmittalStatus.DRAFT,
      responseRequired: dto.responseRequired ?? false,
      responseDueDate: dto.responseDueDate
        ? new Date(dto.responseDueDate)
        : undefined,
      createdByName: `User ${dto.createdBy}`,
      createdAt: now,
      updatedAt: now,
    };
    this.transmittals.set(transmittal.id, transmittal);
    return transmittal;
  }

  async updateTransmittal(
    id: number,
    dto: UpdateTransmittalDto,
  ): Promise<Transmittal> {
    const transmittal = await this.getTransmittalById(id);

    if (dto.subject) transmittal.subject = dto.subject;
    if (dto.status) transmittal.status = dto.status;
    if (dto.remarks) transmittal.remarks = dto.remarks;
    if (dto.documents) transmittal.documents = dto.documents;

    transmittal.updatedAt = new Date();
    this.transmittals.set(id, transmittal);
    return transmittal;
  }

  async sendTransmittal(
    id: number,
    dto: SendTransmittalDto,
  ): Promise<Transmittal> {
    const transmittal = await this.getTransmittalById(id);

    if (transmittal.status !== TransmittalStatus.DRAFT) {
      throw new BadRequestException('Only draft transmittals can be sent');
    }

    transmittal.status = TransmittalStatus.SENT;
    transmittal.sentDate = new Date();
    transmittal.updatedAt = new Date();

    this.transmittals.set(id, transmittal);
    return transmittal;
  }

  async acknowledgeTransmittal(
    id: number,
    dto: AcknowledgeTransmittalDto,
  ): Promise<Transmittal> {
    const transmittal = await this.getTransmittalById(id);

    transmittal.status = TransmittalStatus.ACKNOWLEDGED;
    transmittal.acknowledgedDate = new Date();
    transmittal.updatedAt = new Date();

    this.transmittals.set(id, transmittal);
    return transmittal;
  }

  async respondTransmittal(
    id: number,
    dto: RespondTransmittalDto,
  ): Promise<Transmittal> {
    const transmittal = await this.getTransmittalById(id);

    transmittal.status = TransmittalStatus.RESPONDED;
    transmittal.responseDate = new Date();
    transmittal.responseRemarks = dto.responseRemarks;
    transmittal.updatedAt = new Date();

    this.transmittals.set(id, transmittal);
    return transmittal;
  }

  // ========== DISTRIBUTION ==========

  async distributeDocument(
    documentId: number,
    dto: DistributeDocumentDto,
  ): Promise<DocumentDistribution> {
    await this.getDocumentById(documentId);

    const distribution: DocumentDistribution = {
      id: this.distributionIdCounter++,
      documentId,
      ...dto,
      sentDate: new Date(),
    };

    this.distributions.set(distribution.id, distribution);
    return distribution;
  }

  async getDistributions(documentId: number): Promise<DocumentDistribution[]> {
    await this.getDocumentById(documentId);
    return Array.from(this.distributions.values())
      .filter((d) => d.documentId === documentId)
      .sort((a, b) => b.sentDate.getTime() - a.sentDate.getTime());
  }

  // ========== COMMENTS ==========

  async getComments(documentId: number): Promise<DocumentComment[]> {
    await this.getDocumentById(documentId);
    return Array.from(this.comments.values())
      .filter((c) => c.documentId === documentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async addComment(
    documentId: number,
    dto: DocumentCommentDto,
  ): Promise<DocumentComment> {
    await this.getDocumentById(documentId);

    const comment: DocumentComment = {
      id: this.commentIdCounter++,
      documentId,
      userId: dto.userId,
      userName: `User ${dto.userId}`,
      comment: dto.comment,
      pageNumber: dto.pageNumber,
      resolved: false,
      createdAt: new Date(),
    };

    this.comments.set(comment.id, comment);
    return comment;
  }

  async resolveComment(
    documentId: number,
    commentId: number,
    dto: ResolveCommentDto,
  ): Promise<DocumentComment> {
    const comment = this.comments.get(commentId);
    if (!comment || comment.documentId !== documentId) {
      throw new NotFoundException(`Comment ${commentId} not found`);
    }

    comment.resolved = true;
    comment.resolvedBy = dto.resolvedBy;
    comment.resolvedAt = new Date();

    this.comments.set(commentId, comment);
    return comment;
  }
}
