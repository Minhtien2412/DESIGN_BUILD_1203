import { Injectable } from '@nestjs/common';

// Mock data for companies
const MOCK_COMPANIES = [
  {
    id: 1,
    name: 'Công ty Thiết kế A&A',
    slug: 'aa-design',
    logo: 'https://ui-avatars.com/api/?name=AA&background=0066CC&color=fff&size=128',
    coverImage:
      'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800',
    rating: 4.8,
    reviewCount: 256,
    projectCount: 150,
    establishedYear: 2015,
    location: 'Hà Nội',
    address: '123 Nguyễn Trãi, Thanh Xuân, Hà Nội',
    phone: '0123 456 789',
    email: 'contact@aanda.vn',
    website: 'https://aanda.vn',
    description:
      'Công ty thiết kế kiến trúc A&A chuyên cung cấp dịch vụ thiết kế nhà ở cao cấp, biệt thự, nhà phố.',
    specialties: ['Biệt thự', 'Nhà phố', 'Nhà vườn', 'Resort'],
    verified: true,
    type: 'design',
    services: [
      { id: 1, name: 'Thiết kế kiến trúc', price: '5.000.000₫/m²' },
      { id: 2, name: 'Thiết kế nội thất', price: '3.000.000₫/m²' },
      { id: 3, name: 'Thi công trọn gói', price: '8.000.000₫/m²' },
    ],
    portfolio: [
      {
        id: 1,
        title: 'Biệt thự hiện đại 2 tầng',
        location: 'Hà Nội',
        area: '250m²',
        year: 2024,
        image:
          'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400',
      },
    ],
    reviews: [],
  },
  {
    id: 2,
    name: 'Kiến trúc Bảo Tiên',
    slug: 'bao-tien',
    logo: 'https://ui-avatars.com/api/?name=BT&background=FF6600&color=fff&size=128',
    coverImage:
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
    rating: 4.9,
    reviewCount: 312,
    projectCount: 200,
    establishedYear: 2010,
    location: 'TP.HCM',
    address: '456 Lê Lợi, Quận 1, TP.HCM',
    phone: '0987 654 321',
    email: 'info@baotien.vn',
    website: 'https://baotien.vn',
    description: 'Kiến trúc Bảo Tiên - Thiết kế và thi công nội thất cao cấp.',
    specialties: ['Nội thất', 'Văn phòng', 'Showroom', 'Căn hộ'],
    verified: true,
    type: 'design',
    services: [
      { id: 1, name: 'Thiết kế nội thất', price: '4.000.000₫/m²' },
      { id: 2, name: 'Thi công nội thất', price: '6.000.000₫/m²' },
    ],
    portfolio: [],
    reviews: [],
  },
  {
    id: 3,
    name: 'Nội thất Đông Dương',
    slug: 'dong-duong',
    logo: 'https://ui-avatars.com/api/?name=DD&background=228B22&color=fff&size=128',
    coverImage:
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
    rating: 4.7,
    reviewCount: 189,
    projectCount: 120,
    establishedYear: 2018,
    location: 'Đà Nẵng',
    address: '789 Trần Hưng Đạo, Hải Châu, Đà Nẵng',
    phone: '0369 852 147',
    email: 'hello@dongduong.vn',
    website: 'https://dongduong.vn',
    description:
      'Nội thất Đông Dương chuyên thiết kế và thi công nội thất phong cách Đông Dương hiện đại.',
    specialties: ['Đông Dương', 'Indochine', 'Tropical', 'Modern'],
    verified: true,
    type: 'design',
    services: [
      { id: 1, name: 'Thiết kế kiến trúc', price: '4.500.000₫/m²' },
      { id: 2, name: 'Thiết kế nội thất', price: '3.500.000₫/m²' },
    ],
    portfolio: [],
    reviews: [],
  },
];

@Injectable()
export class CompaniesService {
  async findAll(query: { limit?: number; page?: number; type?: string }) {
    const { limit = 20, page = 1, type } = query;

    let filtered = MOCK_COMPANIES;
    if (type) {
      filtered = MOCK_COMPANIES.filter((c) => c.type === type);
    }

    const start = (page - 1) * limit;
    const end = start + limit;
    const data = filtered.slice(start, end).map((c) => ({
      id: c.id,
      name: c.name,
      logo: c.logo,
      rating: c.rating,
      reviewCount: c.reviewCount,
      location: c.location,
      specialties: c.specialties,
      verified: c.verified,
    }));

    return {
      data,
      meta: {
        total: filtered.length,
        page,
        limit,
        totalPages: Math.ceil(filtered.length / limit),
      },
    };
  }

  async findOne(id: number) {
    const company = MOCK_COMPANIES.find((c) => c.id === id);
    if (!company) {
      return null;
    }
    return {
      success: true,
      data: company,
    };
  }

  async findBySlug(slug: string) {
    const company = MOCK_COMPANIES.find((c) => c.slug === slug);
    if (!company) {
      return null;
    }
    return {
      success: true,
      data: company,
    };
  }
}
