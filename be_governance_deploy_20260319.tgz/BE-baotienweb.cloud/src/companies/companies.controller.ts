import {
    Controller,
    Get,
    NotFoundException,
    Param,
    Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CompaniesService } from './companies.service';

@ApiTags('Companies')
@Controller('companies')
export class CompaniesController {
  constructor(private readonly companiesService: CompaniesService) {}

  @Get()
  async findAll(
    @Query('limit') limit?: string,
    @Query('page') page?: string,
    @Query('type') type?: string,
  ) {
    return this.companiesService.findAll({
      limit: limit ? parseInt(limit, 10) : 20,
      page: page ? parseInt(page, 10) : 1,
      type,
    });
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    // Check if it's a slug or numeric id
    const isNumeric = /^\d+$/.test(id);

    let result;
    if (isNumeric) {
      result = await this.companiesService.findOne(parseInt(id, 10));
    } else {
      result = await this.companiesService.findBySlug(id);
    }

    if (!result) {
      throw new NotFoundException(`Company with id ${id} not found`);
    }

    return result;
  }
}
