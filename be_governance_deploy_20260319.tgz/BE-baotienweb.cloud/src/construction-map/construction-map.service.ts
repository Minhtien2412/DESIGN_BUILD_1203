import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateStageDto,
    CreateTaskDto,
    UpdateStageDto,
    UpdateStateDto,
    UpdateTaskDto,
    UpdateTaskPositionDto,
    UpdateTaskProgressDto,
    UpdateTaskStatusDto,
} from './dto';

@Injectable()
export class ConstructionMapService {
  // In-memory storage (replace with database when TypeORM is configured)
  private tasks: Map<number, any> = new Map();
  private stages: Map<number, any> = new Map();
  private states: Map<number, any> = new Map();
  private taskIdCounter = 1;
  private stageIdCounter = 1;

  constructor(private prisma: PrismaService) {
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample stages
    const sampleStages = [
      {
        id: 1,
        projectId: 1,
        name: 'Foundation',
        description: 'Foundation construction phase',
        status: 'active',
        orderIndex: 0,
        progress: 75,
        color: '#3B82F6',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        projectId: 1,
        name: 'Structure',
        description: 'Structural work phase',
        status: 'pending',
        orderIndex: 1,
        progress: 0,
        color: '#10B981',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 3,
        projectId: 1,
        name: 'MEP',
        description: 'Mechanical, Electrical, Plumbing',
        status: 'pending',
        orderIndex: 2,
        progress: 0,
        color: '#F59E0B',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    sampleStages.forEach((stage) => {
      this.stages.set(stage.id, stage);
      this.stageIdCounter = Math.max(this.stageIdCounter, stage.id + 1);
    });

    // Sample tasks
    const sampleTasks = [
      {
        id: 1,
        projectId: 1,
        stageId: 1,
        name: 'Site clearing',
        description: 'Clear site and prepare for excavation',
        status: 'completed',
        priority: 'high',
        progress: 100,
        positionX: 100,
        positionY: 100,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        projectId: 1,
        stageId: 1,
        name: 'Excavation',
        description: 'Excavate foundation to required depth',
        status: 'in_progress',
        priority: 'high',
        progress: 60,
        positionX: 300,
        positionY: 100,
        dependencies: [1],
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 3,
        projectId: 1,
        stageId: 1,
        name: 'Concrete pouring',
        description: 'Pour foundation concrete',
        status: 'not_started',
        priority: 'critical',
        progress: 0,
        positionX: 500,
        positionY: 100,
        dependencies: [2],
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    sampleTasks.forEach((task) => {
      this.tasks.set(task.id, task);
      this.taskIdCounter = Math.max(this.taskIdCounter, task.id + 1);
    });
  }

  // ============ PROJECT OVERVIEW ============

  async getProjectMap(projectId: number) {
    const projectTasks = Array.from(this.tasks.values()).filter(
      (t) => t.projectId === projectId,
    );
    const projectStages = Array.from(this.stages.values()).filter(
      (s) => s.projectId === projectId,
    );

    const totalTasks = projectTasks.length;
    const completedTasks = projectTasks.filter(
      (t) => t.status === 'completed',
    ).length;
    const overallProgress =
      totalTasks > 0
        ? projectTasks.reduce((sum, t) => sum + (t.progress || 0), 0) /
          totalTasks
        : 0;

    return {
      projectId,
      tasks: projectTasks,
      stages: projectStages,
      statistics: {
        totalTasks,
        completedTasks,
        inProgressTasks: projectTasks.filter((t) => t.status === 'in_progress')
          .length,
        notStartedTasks: projectTasks.filter((t) => t.status === 'not_started')
          .length,
        overallProgress: Math.round(overallProgress * 100) / 100,
      },
    };
  }

  async getProjectProgress(projectId: number) {
    const projectTasks = Array.from(this.tasks.values()).filter(
      (t) => t.projectId === projectId,
    );
    const projectStages = Array.from(this.stages.values()).filter(
      (s) => s.projectId === projectId,
    );

    const stageProgress = projectStages.map((stage) => {
      const stageTasks = projectTasks.filter((t) => t.stageId === stage.id);
      const progress =
        stageTasks.length > 0
          ? stageTasks.reduce((sum, t) => sum + (t.progress || 0), 0) /
            stageTasks.length
          : 0;
      return {
        stageId: stage.id,
        stageName: stage.name,
        progress: Math.round(progress * 100) / 100,
        taskCount: stageTasks.length,
        completedCount: stageTasks.filter((t) => t.status === 'completed')
          .length,
      };
    });

    return {
      projectId,
      overallProgress:
        stageProgress.reduce((sum, s) => sum + s.progress, 0) /
          stageProgress.length || 0,
      stages: stageProgress,
    };
  }

  async getProjectTasks(projectId: number) {
    return Array.from(this.tasks.values()).filter(
      (t) => t.projectId === projectId,
    );
  }

  // ============ TASKS ============

  async getTask(id: number) {
    const task = this.tasks.get(id);
    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    return task;
  }

  async createTask(dto: CreateTaskDto) {
    const task = {
      id: this.taskIdCounter++,
      ...dto,
      status: dto.status || 'not_started',
      priority: dto.priority || 'medium',
      progress: dto.progress || 0,
      positionX: dto.positionX || 0,
      positionY: dto.positionY || 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(task.id, task);
    return task;
  }

  async updateTask(id: number, dto: UpdateTaskDto) {
    const task = await this.getTask(id);
    const updated = {
      ...task,
      ...dto,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async updateTaskPosition(id: number, dto: UpdateTaskPositionDto) {
    const task = await this.getTask(id);
    const updated = {
      ...task,
      positionX: dto.x,
      positionY: dto.y,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async updateTaskStatus(id: number, dto: UpdateTaskStatusDto) {
    const task = await this.getTask(id);
    const updated = {
      ...task,
      status: dto.status,
      progress: dto.status === 'completed' ? 100 : task.progress,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async updateTaskProgress(id: number, dto: UpdateTaskProgressDto) {
    const task = await this.getTask(id);
    const status =
      dto.progress === 100
        ? 'completed'
        : dto.progress > 0
          ? 'in_progress'
          : task.status;
    const updated = {
      ...task,
      progress: dto.progress,
      status,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: number) {
    if (!this.tasks.has(id)) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    this.tasks.delete(id);
    return { deleted: true, id };
  }

  // ============ STAGES ============

  async getProjectStages(projectId: number) {
    return Array.from(this.stages.values())
      .filter((s) => s.projectId === projectId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getStage(id: number) {
    const stage = this.stages.get(id);
    if (!stage) {
      throw new NotFoundException(`Stage with ID ${id} not found`);
    }
    return stage;
  }

  async createStage(dto: CreateStageDto) {
    const existingStages = Array.from(this.stages.values()).filter(
      (s) => s.projectId === dto.projectId,
    );
    const maxOrder = Math.max(0, ...existingStages.map((s) => s.orderIndex));

    const stage = {
      id: this.stageIdCounter++,
      ...dto,
      status: dto.status || 'pending',
      orderIndex: dto.orderIndex ?? maxOrder + 1,
      progress: 0,
      color: dto.color || '#3B82F6',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.stages.set(stage.id, stage);
    return stage;
  }

  async updateStage(id: number, dto: UpdateStageDto) {
    const stage = await this.getStage(id);
    const updated = {
      ...stage,
      ...dto,
      updatedAt: new Date(),
    };
    this.stages.set(id, updated);
    return updated;
  }

  async deleteStage(id: number) {
    if (!this.stages.has(id)) {
      throw new NotFoundException(`Stage with ID ${id} not found`);
    }
    // Also update tasks to remove stage reference
    this.tasks.forEach((task, taskId) => {
      if (task.stageId === id) {
        this.tasks.set(taskId, { ...task, stageId: null });
      }
    });
    this.stages.delete(id);
    return { deleted: true, id };
  }

  async getStageTasks(stageId: number) {
    await this.getStage(stageId); // Verify stage exists
    return Array.from(this.tasks.values()).filter((t) => t.stageId === stageId);
  }

  // ============ STATE ============

  async getProjectState(projectId: number) {
    let state = this.states.get(projectId);
    if (!state) {
      state = {
        projectId,
        zoomLevel: 1,
        panX: 0,
        panY: 0,
        visibleLayers: ['tasks', 'stages', 'connections'],
        filters: {},
        settings: { showLabels: true, snapToGrid: false },
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.states.set(projectId, state);
    }
    return state;
  }

  async updateProjectState(projectId: number, dto: UpdateStateDto) {
    const current = await this.getProjectState(projectId);
    const updated = {
      ...current,
      ...dto,
      updatedAt: new Date(),
    };
    this.states.set(projectId, updated);
    return updated;
  }

  // ============ HEALTH CHECK ============

  getHealth() {
    return {
      status: 'ok',
      module: 'construction-map',
      timestamp: new Date().toISOString(),
      stats: {
        tasks: this.tasks.size,
        stages: this.stages.size,
        projects: new Set([
          ...Array.from(this.tasks.values()).map((t) => t.projectId),
          ...Array.from(this.stages.values()).map((s) => s.projectId),
        ]).size,
      },
    };
  }
}
