import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { ConstructionMapController } from './construction-map.controller';
import { ConstructionMapService } from './construction-map.service';

@Module({
  imports: [PrismaModule],
  controllers: [ConstructionMapController],
  providers: [ConstructionMapService],
  exports: [ConstructionMapService],
})
export class ConstructionMapModule {}
