import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { ConstructionMapService } from './construction-map.service';
import {
    CreateStageDto,
    CreateTaskDto,
    UpdateStageDto,
    UpdateStateDto,
    UpdateTaskDto,
    UpdateTaskPositionDto,
    UpdateTaskProgressDto,
    UpdateTaskStatusDto,
} from './dto';

@ApiTags('Construction Map')
@Controller('construction-map')
export class ConstructionMapController {
  constructor(private readonly service: ConstructionMapService) {}

  // ============ HEALTH CHECK ============

  @Get('health')
  @ApiOperation({ summary: 'Health check for Construction Map module' })
  @ApiResponse({ status: 200, description: 'Module is healthy' })
  getHealth() {
    return this.service.getHealth();
  }

  // ============ PROJECT OVERVIEW ============

  @Get(':projectId')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get construction map for a project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'Project map data' })
  getProjectMap(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectMap(projectId);
  }

  @Get(':projectId/progress')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get project progress overview' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'Progress statistics' })
  getProjectProgress(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectProgress(projectId);
  }

  @Get(':projectId/tasks')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all tasks for a project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'List of tasks' })
  getProjectTasks(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectTasks(projectId);
  }

  // ============ TASKS ============

  @Get('tasks/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get task by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Task details' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  getTask(@Param('id', ParseIntPipe) id: number) {
    return this.service.getTask(id);
  }

  @Post('tasks')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new task' })
  @ApiResponse({ status: 201, description: 'Task created successfully' })
  @HttpCode(HttpStatus.CREATED)
  createTask(@Body() dto: CreateTaskDto) {
    return this.service.createTask(dto);
  }

  @Put('tasks/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update task by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Task updated successfully' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  updateTask(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateTaskDto,
  ) {
    return this.service.updateTask(id, dto);
  }

  @Patch('tasks/:id/position')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update task position on map' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Position updated' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  updateTaskPosition(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateTaskPositionDto,
  ) {
    return this.service.updateTaskPosition(id, dto);
  }

  @Patch('tasks/:id/status')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update task status' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Status updated' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  updateTaskStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateTaskStatusDto,
  ) {
    return this.service.updateTaskStatus(id, dto);
  }

  @Patch('tasks/:id/progress')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update task progress' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Progress updated' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  updateTaskProgress(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateTaskProgressDto,
  ) {
    return this.service.updateTaskProgress(id, dto);
  }

  @Delete('tasks/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete task by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Task deleted' })
  @ApiResponse({ status: 404, description: 'Task not found' })
  deleteTask(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteTask(id);
  }

  // ============ STAGES ============

  @Get(':projectId/stages')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all stages for a project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'List of stages' })
  getProjectStages(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectStages(projectId);
  }

  @Get('stages/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get stage by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stage details' })
  @ApiResponse({ status: 404, description: 'Stage not found' })
  getStage(@Param('id', ParseIntPipe) id: number) {
    return this.service.getStage(id);
  }

  @Get('stages/:id/tasks')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get all tasks in a stage' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'List of tasks' })
  @ApiResponse({ status: 404, description: 'Stage not found' })
  getStageTasks(@Param('id', ParseIntPipe) id: number) {
    return this.service.getStageTasks(id);
  }

  @Post('stages')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new stage' })
  @ApiResponse({ status: 201, description: 'Stage created successfully' })
  @HttpCode(HttpStatus.CREATED)
  createStage(@Body() dto: CreateStageDto) {
    return this.service.createStage(dto);
  }

  @Put('stages/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update stage by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stage updated successfully' })
  @ApiResponse({ status: 404, description: 'Stage not found' })
  updateStage(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateStageDto,
  ) {
    return this.service.updateStage(id, dto);
  }

  @Delete('stages/:id')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete stage by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stage deleted' })
  @ApiResponse({ status: 404, description: 'Stage not found' })
  deleteStage(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteStage(id);
  }

  // ============ STATE ============

  @Get(':projectId/state')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get map state (zoom, pan, filters) for project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'Map state' })
  getProjectState(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectState(projectId);
  }

  @Put(':projectId/state')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update map state for project' })
  @ApiParam({ name: 'projectId', type: Number })
  @ApiResponse({ status: 200, description: 'State updated' })
  updateProjectState(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Body() dto: UpdateStateDto,
  ) {
    return this.service.updateProjectState(projectId, dto);
  }
}
