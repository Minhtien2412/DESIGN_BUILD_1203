// Entity definitions for future database integration
// Currently using in-memory storage

export enum TaskStatus {
  NOT_STARTED = 'not_started',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  ON_HOLD = 'on_hold',
  CANCELLED = 'cancelled',
}

export enum TaskPriority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}

export interface ConstructionTask {
  id: number;
  projectId: number;
  stageId?: number;
  name: string;
  description?: string;
  status: TaskStatus;
  priority: TaskPriority;
  progress: number;
  positionX: number;
  positionY: number;
  startDate?: Date;
  endDate?: Date;
  assignedTo?: number;
  dependencies?: number[];
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export enum StageStatus {
  PENDING = 'pending',
  ACTIVE = 'active',
  COMPLETED = 'completed',
}

export interface ConstructionStage {
  id: number;
  projectId: number;
  name: string;
  description?: string;
  status: StageStatus;
  orderIndex: number;
  progress: number;
  startDate?: Date;
  endDate?: Date;
  color: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface ConstructionState {
  id?: number;
  projectId: number;
  zoomLevel: number;
  panX: number;
  panY: number;
  visibleLayers?: string[];
  filters?: Record<string, any>;
  settings?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}
