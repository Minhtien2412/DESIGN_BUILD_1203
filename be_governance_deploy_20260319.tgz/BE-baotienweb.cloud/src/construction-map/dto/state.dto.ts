import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsNumber, IsOptional, IsString } from 'class-validator';

export class UpdateStateDto {
  @ApiPropertyOptional({ description: 'Zoom level', example: 1.5 })
  @IsOptional()
  @IsNumber()
  zoomLevel?: number;

  @ApiPropertyOptional({ description: 'Pan X offset', example: 100 })
  @IsOptional()
  @IsNumber()
  panX?: number;

  @ApiPropertyOptional({ description: 'Pan Y offset', example: 50 })
  @IsOptional()
  @IsNumber()
  panY?: number;

  @ApiPropertyOptional({
    description: 'Visible layer names',
    type: [String],
    example: ['tasks', 'stages', 'grid'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  visibleLayers?: string[];

  @ApiPropertyOptional({
    description: 'Filter settings',
    example: { status: 'in_progress', priority: 'high' },
  })
  @IsOptional()
  filters?: Record<string, any>;

  @ApiPropertyOptional({
    description: 'Additional settings',
    example: { showLabels: true, snapToGrid: false },
  })
  @IsOptional()
  settings?: Record<string, any>;
}
