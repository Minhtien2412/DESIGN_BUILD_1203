import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsDate,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    Max,
    Min,
} from 'class-validator';
import { TaskPriority, TaskStatus } from '../entities';

export class CreateTaskDto {
  @ApiProperty({ description: 'Project ID', example: 1 })
  @IsNumber()
  projectId: number;

  @ApiPropertyOptional({ description: 'Stage ID', example: 1 })
  @IsOptional()
  @IsNumber()
  stageId?: number;

  @ApiProperty({ description: 'Task name', example: 'Foundation excavation' })
  @IsString()
  name: string;

  @ApiPropertyOptional({
    description: 'Task description',
    example: 'Excavate foundation to 2m depth',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    enum: TaskStatus,
    default: TaskStatus.NOT_STARTED,
  })
  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @ApiPropertyOptional({
    enum: TaskPriority,
    default: TaskPriority.MEDIUM,
  })
  @IsOptional()
  @IsEnum(TaskPriority)
  priority?: TaskPriority;

  @ApiPropertyOptional({ description: 'Progress percentage', example: 0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  progress?: number;

  @ApiPropertyOptional({ description: 'X position on map', example: 100 })
  @IsOptional()
  @IsNumber()
  positionX?: number;

  @ApiPropertyOptional({ description: 'Y position on map', example: 200 })
  @IsOptional()
  @IsNumber()
  positionY?: number;

  @ApiPropertyOptional({ description: 'Start date' })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  startDate?: Date;

  @ApiPropertyOptional({ description: 'End date' })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  endDate?: Date;

  @ApiPropertyOptional({ description: 'Assigned user ID' })
  @IsOptional()
  @IsNumber()
  assignedTo?: number;

  @ApiPropertyOptional({ description: 'Dependent task IDs', type: [Number] })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  dependencies?: number[];
}

export class UpdateTaskDto {
  @ApiPropertyOptional({ description: 'Task name' })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional({ description: 'Task description' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: TaskStatus })
  @IsOptional()
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @ApiPropertyOptional({ enum: TaskPriority })
  @IsOptional()
  @IsEnum(TaskPriority)
  priority?: TaskPriority;

  @ApiPropertyOptional({ description: 'Progress percentage' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  progress?: number;

  @ApiPropertyOptional({ description: 'X position on map' })
  @IsOptional()
  @IsNumber()
  positionX?: number;

  @ApiPropertyOptional({ description: 'Y position on map' })
  @IsOptional()
  @IsNumber()
  positionY?: number;

  @ApiPropertyOptional({ description: 'Start date' })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  startDate?: Date;

  @ApiPropertyOptional({ description: 'End date' })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  endDate?: Date;

  @ApiPropertyOptional({ description: 'Assigned user ID' })
  @IsOptional()
  @IsNumber()
  assignedTo?: number;

  @ApiPropertyOptional({ description: 'Dependent task IDs', type: [Number] })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  dependencies?: number[];

  @ApiPropertyOptional({ description: 'Stage ID' })
  @IsOptional()
  @IsNumber()
  stageId?: number;
}

export class UpdateTaskPositionDto {
  @ApiProperty({ description: 'X position on map', example: 150 })
  @IsNumber()
  x: number;

  @ApiProperty({ description: 'Y position on map', example: 250 })
  @IsNumber()
  y: number;
}

export class UpdateTaskStatusDto {
  @ApiProperty({ enum: TaskStatus, example: TaskStatus.IN_PROGRESS })
  @IsEnum(TaskStatus)
  status: TaskStatus;
}

export class UpdateTaskProgressDto {
  @ApiProperty({ description: 'Progress percentage', example: 50 })
  @IsNumber()
  @Min(0)
  @Max(100)
  progress: number;
}
