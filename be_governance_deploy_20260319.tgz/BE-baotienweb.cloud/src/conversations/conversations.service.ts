/**
 * Conversations Service
 * ======================
 *
 * Business logic cho conversations
 * - Tạo conversation 1-1 (DIRECT) với directKey unique
 * - Tạo conversation nhóm (GROUP)
 * - Quản lý participants (add/remove/leave)
 * - Đánh dấu đã đọc với cursor-based tracking
 * - Tính unreadCount tối ưu
 *
 * @author ThietKeResort Team
 * @created 2025-01-20
 */

import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import {
    AddParticipantsDto,
    CreateDirectConversationDto,
    CreateGroupConversationDto,
    GetConversationsQueryDto,
    MarkReadDto
} from './dto';

@Injectable()
export class ConversationsService {
  constructor(private readonly prisma: PrismaService) {}

  // ============================================
  // CONVERSATION CREATION
  // ============================================

  /**
   * Tạo hoặc lấy conversation 1-1 (DIRECT)
   * Đảm bảo chỉ có 1 conversation giữa 2 users
   */
  async createOrGetDirectConversation(
    userId: number,
    dto: CreateDirectConversationDto,
  ) {
    const { targetUserId } = dto;

    // Không thể chat với chính mình
    if (userId === targetUserId) {
      throw new BadRequestException(
        'Không thể tạo conversation với chính mình',
      );
    }

    // Tạo directKey duy nhất (hash của 2 userIds sắp xếp)
    const directKey = this.generateDirectKey(userId, targetUserId);

    // Kiểm tra conversation đã tồn tại
    const existingConversation = await this.prisma.conversation.findUnique({
      where: { directKey },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
      },
    });

    if (existingConversation) {
      // Kiểm tra xem user có bị removed không
      const myParticipant = existingConversation.participants.find(
        (p) => p.userId === userId,
      );

      if (myParticipant?.removedAt) {
        // Rejoin nếu đã bị removed
        await this.prisma.conversationParticipant.update({
          where: { id: myParticipant.id },
          data: {
            removedAt: null,
            removedBy: null,
            leftAt: null,
            joinedAt: new Date(),
          },
        });
      }

      return this.formatConversation(existingConversation, userId);
    }

    // Kiểm tra target user tồn tại
    const targetUser = await this.prisma.user.findUnique({
      where: { id: targetUserId },
    });

    if (!targetUser) {
      throw new NotFoundException(`User với ID ${targetUserId} không tồn tại`);
    }

    // Tạo conversation mới
    const conversation = await this.prisma.conversation.create({
      data: {
        type: 'DIRECT',
        directKey,
        createdBy: userId,
        participants: {
          create: [
            { userId, role: 'MEMBER' },
            { userId: targetUserId, role: 'MEMBER' },
          ],
        },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
      },
    });

    return this.formatConversation(conversation, userId);
  }

  /**
   * Tạo conversation nhóm
   */
  async createGroupConversation(
    userId: number,
    dto: CreateGroupConversationDto,
  ) {
    const { title, description, participantIds, avatarUrl } = dto;

    // Validate participants
    if (!participantIds || participantIds.length < 1) {
      throw new BadRequestException('Nhóm cần ít nhất 1 thành viên khác');
    }

    // Thêm creator vào danh sách
    const allParticipantIds = [...new Set([userId, ...participantIds])];

    // Kiểm tra tất cả users tồn tại
    const users = await this.prisma.user.findMany({
      where: { id: { in: allParticipantIds } },
    });

    if (users.length !== allParticipantIds.length) {
      throw new BadRequestException('Một số user không tồn tại');
    }

    // Tạo conversation
    const conversation = await this.prisma.conversation.create({
      data: {
        type: 'GROUP',
        title,
        description,
        avatarUrl,
        createdBy: userId,
        participants: {
          create: allParticipantIds.map((participantId) => ({
            userId: participantId,
            role: participantId === userId ? 'OWNER' : 'MEMBER',
          })),
        },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
      },
    });

    return this.formatConversation(conversation, userId);
  }

  // ============================================
  // CONVERSATION RETRIEVAL
  // ============================================

  /**
   * Lấy danh sách conversations của user
   * Với pagination và unread count
   */
  async getConversations(userId: number, query: GetConversationsQueryDto) {
    const { limit = 20, cursor, type, search, unreadOnly = false } = query;

    const where: Prisma.ConversationWhereInput = {
      participants: {
        some: {
          userId,
          leftAt: null,
          removedAt: null,
        },
      },
      ...(type && { type }),
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          {
            participants: {
              some: {
                user: {
                  name: { contains: search, mode: 'insensitive' },
                },
              },
            },
          },
        ],
      }),
    };

    // Filter unread only
    if (unreadOnly) {
      where.participants = {
        some: {
          userId,
          leftAt: null,
          removedAt: null,
          unreadCount: { gt: 0 },
        },
      };
    }

    const conversations = await this.prisma.conversation.findMany({
      where,
      orderBy: { lastMessageAt: 'desc' },
      take: limit + 1, // +1 để check có next page
      ...(cursor && {
        cursor: { id: cursor },
        skip: 1,
      }),
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
      },
    });

    const hasNextPage = conversations.length > limit;
    const items = hasNextPage ? conversations.slice(0, limit) : conversations;

    return {
      items: items.map((conv) => this.formatConversation(conv, userId)),
      nextCursor: hasNextPage ? items[items.length - 1].id : null,
      hasNextPage,
    };
  }

  /**
   * Lấy chi tiết conversation
   */
  async getConversation(conversationId: string, userId: number) {
    const conversation = await this.prisma.conversation.findFirst({
      where: {
        id: conversationId,
        participants: {
          some: {
            userId,
            leftAt: null,
            removedAt: null,
          },
        },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
                email: true,
              },
            },
          },
          orderBy: { joinedAt: 'asc' },
        },
      },
    });

    if (!conversation) {
      throw new NotFoundException(
        'Conversation không tồn tại hoặc bạn không có quyền truy cập',
      );
    }

    return this.formatConversation(conversation, userId);
  }

  // ============================================
  // PARTICIPANT MANAGEMENT
  // ============================================

  /**
   * Thêm participants vào group
   */
  async addParticipants(
    conversationId: string,
    userId: number,
    dto: AddParticipantsDto,
  ) {
    const conversation = await this.getConversationWithAuth(
      conversationId,
      userId,
      ['OWNER', 'ADMIN'],
    );

    if (conversation.type !== 'GROUP') {
      throw new BadRequestException('Chỉ có thể thêm thành viên vào nhóm');
    }

    const { participantIds } = dto;

    // Filter out existing participants
    const existingIds = conversation.participants.map((p) => p.userId);
    const newIds = participantIds.filter((id) => !existingIds.includes(id));

    if (newIds.length === 0) {
      throw new BadRequestException('Tất cả users đã là thành viên');
    }

    // Validate users exist
    const users = await this.prisma.user.findMany({
      where: { id: { in: newIds } },
    });

    if (users.length !== newIds.length) {
      throw new BadRequestException('Một số user không tồn tại');
    }

    // Add participants
    await this.prisma.conversationParticipant.createMany({
      data: newIds.map((id) => ({
        conversationId,
        userId: id,
        role: 'MEMBER',
      })),
    });

    return this.getConversation(conversationId, userId);
  }

  /**
   * Rời khỏi conversation
   */
  async leaveConversation(conversationId: string, userId: number) {
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
      include: {
        conversation: true,
      },
    });

    if (!participant) {
      throw new NotFoundException(
        'Bạn không phải thành viên của conversation này',
      );
    }

    // DIRECT conversations: không thể leave, chỉ có thể delete
    if (participant.conversation.type === 'DIRECT') {
      throw new BadRequestException('Không thể rời khỏi chat 1-1');
    }

    // Owner không thể leave trừ khi chuyển quyền
    if (participant.role === 'OWNER') {
      throw new BadRequestException(
        'Owner phải chuyển quyền trước khi rời nhóm',
      );
    }

    // Soft leave
    await this.prisma.conversationParticipant.update({
      where: { id: participant.id },
      data: {
        leftAt: new Date(),
      },
    });

    return { success: true, message: 'Đã rời khỏi nhóm' };
  }

  /**
   * Kick participant (admin/owner only)
   */
  async removeParticipant(
    conversationId: string,
    userId: number,
    targetUserId: number,
  ) {
    const conversation = await this.getConversationWithAuth(
      conversationId,
      userId,
      ['OWNER', 'ADMIN'],
    );

    if (conversation.type !== 'GROUP') {
      throw new BadRequestException('Chỉ có thể xóa thành viên khỏi nhóm');
    }

    const targetParticipant = conversation.participants.find(
      (p) => p.userId === targetUserId,
    );

    if (!targetParticipant) {
      throw new NotFoundException('User không phải thành viên của nhóm');
    }

    // Không thể kick owner
    if (targetParticipant.role === 'OWNER') {
      throw new ForbiddenException('Không thể xóa owner khỏi nhóm');
    }

    // Admin không thể kick admin khác (trừ owner)
    const myRole = conversation.participants.find(
      (p) => p.userId === userId,
    )?.role;
    if (myRole === 'ADMIN' && targetParticipant.role === 'ADMIN') {
      throw new ForbiddenException('Admin không thể xóa admin khác');
    }

    // Soft remove
    await this.prisma.conversationParticipant.update({
      where: { id: targetParticipant.id },
      data: {
        removedAt: new Date(),
        removedBy: userId,
      },
    });

    return { success: true, message: 'Đã xóa thành viên khỏi nhóm' };
  }

  // ============================================
  // READ STATE MANAGEMENT
  // ============================================

  /**
   * Đánh dấu đã đọc tin nhắn
   * Cập nhật lastReadSeq và reset unreadCount
   */
  async markAsRead(conversationId: string, userId: number, dto: MarkReadDto) {
    const { lastReadMessageId, lastReadSeq } = dto;

    // Verify participant
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant || participant.leftAt || participant.removedAt) {
      throw new ForbiddenException(
        'Bạn không phải thành viên của conversation này',
      );
    }

    // Get the message to validate
    let message;
    if (lastReadMessageId) {
      message = await this.prisma.conversationMessage.findFirst({
        where: {
          id: lastReadMessageId,
          conversationId,
        },
      });
    } else if (lastReadSeq) {
      message = await this.prisma.conversationMessage.findFirst({
        where: {
          conversationId,
          seq: lastReadSeq,
        },
      });
    }

    if (!message) {
      throw new NotFoundException('Message không tồn tại');
    }

    // Update participant read state
    const updatedParticipant = await this.prisma.conversationParticipant.update(
      {
        where: { id: participant.id },
        data: {
          lastReadMessageId: message.id,
          lastReadSeq: message.seq,
          lastReadAt: new Date(),
          unreadCount: 0,
        },
      },
    );

    return {
      conversationId,
      userId,
      lastReadMessageId: message.id,
      lastReadSeq: message.seq,
      lastReadAt: updatedParticipant.lastReadAt,
    };
  }

  /**
   * Tính unread count cho user trong conversation
   * (Fallback khi cache không khớp)
   */
  async calculateUnreadCount(
    conversationId: string,
    userId: number,
  ): Promise<number> {
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId,
        },
      },
    });

    if (!participant || participant.leftAt || participant.removedAt) {
      return 0;
    }

    const lastReadSeq = participant.lastReadSeq || 0;

    const count = await this.prisma.conversationMessage.count({
      where: {
        conversationId,
        seq: { gt: lastReadSeq },
        senderId: { not: userId },
        deletedAt: null,
      },
    });

    // Update cache
    await this.prisma.conversationParticipant.update({
      where: { id: participant.id },
      data: { unreadCount: count },
    });

    return count;
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  /**
   * Generate unique directKey for 1-1 conversations
   */
  private generateDirectKey(userIdA: number, userIdB: number): string {
    const sorted = [userIdA, userIdB].sort((a, b) => a - b);
    return crypto
      .createHash('sha256')
      .update(`direct:${sorted[0]}:${sorted[1]}`)
      .digest('hex');
  }

  /**
   * Get conversation with authorization check
   */
  private async getConversationWithAuth(
    conversationId: string,
    userId: number,
    requiredRoles?: string[],
  ) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      include: {
        participants: {
          include: {
            user: {
              select: { id: true, name: true, avatar: true },
            },
          },
        },
      },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation không tồn tại');
    }

    const participant = conversation.participants.find(
      (p) => p.userId === userId && !p.leftAt && !p.removedAt,
    );

    if (!participant) {
      throw new ForbiddenException(
        'Bạn không có quyền truy cập conversation này',
      );
    }

    if (requiredRoles && !requiredRoles.includes(participant.role)) {
      throw new ForbiddenException(
        'Bạn không có quyền thực hiện hành động này',
      );
    }

    return conversation;
  }

  /**
   * Format conversation response
   * - Cho DIRECT: thêm otherUser info
   * - Thêm unread count và last message
   */
  private formatConversation(conversation: any, userId: number) {
    const myParticipant = conversation.participants.find(
      (p: any) => p.userId === userId,
    );

    // For DIRECT chat, get the other user's info
    let displayName = conversation.title;
    let displayAvatar = conversation.avatarUrl;

    if (conversation.type === 'DIRECT') {
      const otherParticipant = conversation.participants.find(
        (p: any) => p.userId !== userId,
      );
      displayName = otherParticipant?.user?.name || 'Unknown';
      displayAvatar = otherParticipant?.user?.avatar;
    }

    return {
      id: conversation.id,
      type: conversation.type,
      title: displayName,
      description: conversation.description,
      avatarUrl: displayAvatar,
      lastMessagePreview: conversation.lastMessagePreview,
      lastMessageAt: conversation.lastMessageAt,
      unreadCount: myParticipant?.unreadCount || 0,
      isMuted: myParticipant?.isMuted || false,
      isPinned: conversation.isPinned,
      createdAt: conversation.createdAt,
      participants: conversation.participants.map((p: any) => ({
        userId: p.userId,
        name: p.user?.name,
        avatar: p.user?.avatar,
        role: p.role,
        joinedAt: p.joinedAt,
        isActive: !p.leftAt && !p.removedAt,
      })),
      myRole: myParticipant?.role,
      lastReadSeq: myParticipant?.lastReadSeq,
    };
  }
}
