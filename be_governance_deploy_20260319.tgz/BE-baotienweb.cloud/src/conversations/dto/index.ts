/**
 * Conversations DTOs
 * ===================
 *
 * Data Transfer Objects cho Conversations API
 *
 * @author ThietKeResort Team
 * @created 2025-01-20
 */

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
    ArrayMinSize,
    IsArray,
    IsBoolean,
    IsEnum,
    IsInt,
    IsOptional,
    IsString,
    Max,
    Min,
    MinLength
} from 'class-validator';

// ============================================
// CREATE CONVERSATION DTOs
// ============================================

export class CreateDirectConversationDto {
  @ApiProperty({ description: 'ID của user muốn chat' })
  @IsInt()
  @Type(() => Number)
  targetUserId: number;
}

export class CreateGroupConversationDto {
  @ApiProperty({ description: 'Tên nhóm' })
  @IsString()
  @MinLength(1)
  title: string;

  @ApiPropertyOptional({ description: 'Mô tả nhóm' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ description: 'Avatar URL của nhóm' })
  @IsOptional()
  @IsString()
  avatarUrl?: string;

  @ApiProperty({ description: 'Danh sách user IDs', type: [Number] })
  @IsArray()
  @IsInt({ each: true })
  @ArrayMinSize(1)
  @Type(() => Number)
  participantIds: number[];
}

export class UpdateConversationDto {
  @ApiPropertyOptional({ description: 'Tên nhóm mới' })
  @IsOptional()
  @IsString()
  @MinLength(1)
  title?: string;

  @ApiPropertyOptional({ description: 'Mô tả nhóm mới' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ description: 'Avatar URL mới' })
  @IsOptional()
  @IsString()
  avatarUrl?: string;
}

// ============================================
// PARTICIPANT DTOs
// ============================================

export class AddParticipantsDto {
  @ApiProperty({ description: 'Danh sách user IDs để thêm', type: [Number] })
  @IsArray()
  @IsInt({ each: true })
  @ArrayMinSize(1)
  @Type(() => Number)
  participantIds: number[];
}

export class UpdateParticipantRoleDto {
  @ApiProperty({
    description: 'Role mới',
    enum: ['ADMIN', 'MEMBER'],
  })
  @IsString()
  @IsEnum(['ADMIN', 'MEMBER'])
  role: 'ADMIN' | 'MEMBER';
}

// ============================================
// READ STATE DTOs
// ============================================

export class MarkReadDto {
  @ApiPropertyOptional({ description: 'ID tin nhắn đọc cuối' })
  @IsOptional()
  @IsString()
  lastReadMessageId?: string;

  @ApiPropertyOptional({ description: 'Sequence number đọc cuối' })
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  lastReadSeq?: number;
}

// ============================================
// QUERY DTOs
// ============================================

export class GetConversationsQueryDto {
  @ApiPropertyOptional({
    description: 'Số lượng tối đa',
    default: 20,
  })
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(100)
  @Type(() => Number)
  limit?: number = 20;

  @ApiPropertyOptional({ description: 'Cursor để pagination' })
  @IsOptional()
  @IsString()
  cursor?: string;

  @ApiPropertyOptional({
    description: 'Loại conversation',
    enum: ['DIRECT', 'GROUP'],
  })
  @IsOptional()
  @IsEnum(['DIRECT', 'GROUP'])
  type?: 'DIRECT' | 'GROUP';

  @ApiPropertyOptional({ description: 'Tìm kiếm theo tên' })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({
    description: 'Chỉ lấy conversations có unread',
    default: false,
  })
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === 'true' || value === true)
  unreadOnly?: boolean = false;
}

// ============================================
// RESPONSE DTOs
// ============================================

export class ParticipantResponseDto {
  @ApiProperty()
  userId: number;

  @ApiProperty()
  name: string;

  @ApiProperty({ nullable: true })
  avatar: string | null;

  @ApiProperty()
  role: string;

  @ApiProperty()
  joinedAt: Date;

  @ApiProperty()
  isActive: boolean;
}

export class ConversationResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty({ enum: ['DIRECT', 'GROUP'] })
  type: string;

  @ApiProperty()
  title: string;

  @ApiProperty({ nullable: true })
  description: string | null;

  @ApiProperty({ nullable: true })
  avatarUrl: string | null;

  @ApiProperty({ nullable: true })
  lastMessagePreview: string | null;

  @ApiProperty({ nullable: true })
  lastMessageAt: Date | null;

  @ApiProperty()
  unreadCount: number;

  @ApiProperty()
  isMuted: boolean;

  @ApiProperty()
  isPinned: boolean;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty({ type: [ParticipantResponseDto] })
  participants: ParticipantResponseDto[];

  @ApiProperty()
  myRole: string;

  @ApiProperty({ nullable: true })
  lastReadSeq: number | null;
}

export class ConversationListResponseDto {
  @ApiProperty({ type: [ConversationResponseDto] })
  items: ConversationResponseDto[];

  @ApiProperty({ nullable: true })
  nextCursor: string | null;

  @ApiProperty()
  hasNextPage: boolean;
}

export class MarkReadResponseDto {
  @ApiProperty()
  conversationId: string;

  @ApiProperty()
  userId: number;

  @ApiProperty()
  lastReadMessageId: string;

  @ApiProperty()
  lastReadSeq: number;

  @ApiProperty()
  lastReadAt: Date;
}

// Export all
export * from './index';
