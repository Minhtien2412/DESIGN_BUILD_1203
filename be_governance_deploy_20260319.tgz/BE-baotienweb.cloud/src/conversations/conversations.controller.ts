/**
 * Conversations Controller
 * =========================
 *
 * REST API endpoints cho conversations
 *
 * Endpoints:
 * - POST   /conversations/direct     - Tạo/lấy chat 1-1
 * - POST   /conversations/group      - Tạo nhóm chat
 * - GET    /conversations            - Danh sách conversations
 * - GET    /conversations/:id        - Chi tiết conversation
 * - PATCH  /conversations/:id        - Cập nhật conversation
 * - DELETE /conversations/:id        - Xóa conversation
 * - POST   /conversations/:id/participants - Thêm thành viên
 * - DELETE /conversations/:id/participants/:userId - Xóa thành viên
 * - POST   /conversations/:id/leave  - Rời nhóm
 * - POST   /conversations/:id/read   - Đánh dấu đã đọc
 *
 * @author ThietKeResort Team
 * @created 2025-01-20
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Query,
    Request,
    UseGuards
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ConversationsService } from './conversations.service';
import {
    AddParticipantsDto,
    ConversationListResponseDto,
    ConversationResponseDto,
    CreateDirectConversationDto,
    CreateGroupConversationDto,
    GetConversationsQueryDto,
    MarkReadDto,
    MarkReadResponseDto
} from './dto';

@ApiTags('Conversations')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'conversations', version: '1' })
export class ConversationsController {
  constructor(private readonly conversationsService: ConversationsService) {}

  // ============================================
  // CREATE CONVERSATIONS
  // ============================================

  @Post('direct')
  @ApiOperation({
    summary: 'Tạo hoặc lấy conversation 1-1',
    description:
      'Nếu đã tồn tại conversation giữa 2 users, trả về conversation đó',
  })
  @ApiResponse({
    status: 200,
    description: 'Conversation đã tồn tại hoặc vừa được tạo',
    type: ConversationResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Dữ liệu không hợp lệ' })
  @ApiResponse({ status: 404, description: 'User không tồn tại' })
  async createOrGetDirect(
    @Request() req: any,
    @Body() dto: CreateDirectConversationDto,
  ) {
    return this.conversationsService.createOrGetDirectConversation(
      req.user.id,
      dto,
    );
  }

  @Post('group')
  @ApiOperation({ summary: 'Tạo conversation nhóm' })
  @ApiResponse({
    status: 201,
    description: 'Nhóm được tạo thành công',
    type: ConversationResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Dữ liệu không hợp lệ' })
  async createGroup(
    @Request() req: any,
    @Body() dto: CreateGroupConversationDto,
  ) {
    return this.conversationsService.createGroupConversation(req.user.id, dto);
  }

  // ============================================
  // GET CONVERSATIONS
  // ============================================

  @Get()
  @ApiOperation({
    summary: 'Lấy danh sách conversations',
    description: 'Pagination với cursor, có thể filter theo type và unread',
  })
  @ApiResponse({
    status: 200,
    description: 'Danh sách conversations',
    type: ConversationListResponseDto,
  })
  async getConversations(
    @Request() req: any,
    @Query() query: GetConversationsQueryDto,
  ) {
    return this.conversationsService.getConversations(req.user.id, query);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Lấy chi tiết conversation' })
  @ApiParam({ name: 'id', description: 'Conversation ID' })
  @ApiResponse({
    status: 200,
    description: 'Chi tiết conversation',
    type: ConversationResponseDto,
  })
  @ApiResponse({ status: 404, description: 'Conversation không tồn tại' })
  async getConversation(@Request() req: any, @Param('id') id: string) {
    return this.conversationsService.getConversation(id, req.user.id);
  }

  // ============================================
  // PARTICIPANT MANAGEMENT
  // ============================================

  @Post(':id/participants')
  @ApiOperation({ summary: 'Thêm thành viên vào nhóm' })
  @ApiParam({ name: 'id', description: 'Conversation ID' })
  @ApiResponse({
    status: 200,
    description: 'Thêm thành công',
    type: ConversationResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Chỉ áp dụng cho nhóm' })
  @ApiResponse({ status: 403, description: 'Không có quyền' })
  async addParticipants(
    @Request() req: any,
    @Param('id') id: string,
    @Body() dto: AddParticipantsDto,
  ) {
    return this.conversationsService.addParticipants(id, req.user.id, dto);
  }

  @Delete(':id/participants/:userId')
  @ApiOperation({ summary: 'Xóa thành viên khỏi nhóm' })
  @ApiParam({ name: 'id', description: 'Conversation ID' })
  @ApiParam({ name: 'userId', description: 'User ID cần xóa' })
  @ApiResponse({ status: 200, description: 'Xóa thành công' })
  @ApiResponse({ status: 403, description: 'Không có quyền' })
  @HttpCode(HttpStatus.OK)
  async removeParticipant(
    @Request() req: any,
    @Param('id') id: string,
    @Param('userId') targetUserId: string,
  ) {
    return this.conversationsService.removeParticipant(
      id,
      req.user.id,
      parseInt(targetUserId),
    );
  }

  @Post(':id/leave')
  @ApiOperation({ summary: 'Rời khỏi nhóm' })
  @ApiParam({ name: 'id', description: 'Conversation ID' })
  @ApiResponse({ status: 200, description: 'Rời thành công' })
  @ApiResponse({
    status: 400,
    description: 'Không thể rời chat 1-1 hoặc owner',
  })
  @HttpCode(HttpStatus.OK)
  async leaveConversation(@Request() req: any, @Param('id') id: string) {
    return this.conversationsService.leaveConversation(id, req.user.id);
  }

  // ============================================
  // READ STATE
  // ============================================

  @Post(':id/read')
  @ApiOperation({
    summary: 'Đánh dấu đã đọc',
    description: 'Cập nhật lastReadSeq và reset unreadCount',
  })
  @ApiParam({ name: 'id', description: 'Conversation ID' })
  @ApiResponse({
    status: 200,
    description: 'Đánh dấu thành công',
    type: MarkReadResponseDto,
  })
  @HttpCode(HttpStatus.OK)
  async markAsRead(
    @Request() req: any,
    @Param('id') id: string,
    @Body() dto: MarkReadDto,
  ) {
    return this.conversationsService.markAsRead(id, req.user.id, dto);
  }
}
