/**
 * Conversation Module
 * ====================
 *
 * Quản lý conversations (1-1 và nhóm)
 * - Tạo/xóa conversation
 * - Quản lý participants
 * - Lấy danh sách conversations
 *
 * @author ThietKeResort Team
 * @created 2025-01-20
 */

import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { ConversationsController } from './conversations.controller';
import { ConversationsService } from './conversations.service';
import { WelcomeMessageService } from './welcome-message.service';

@Module({
  imports: [PrismaModule],
  controllers: [ConversationsController],
  providers: [ConversationsService, WelcomeMessageService],
  exports: [ConversationsService, WelcomeMessageService],
})
export class ConversationsModule {}
