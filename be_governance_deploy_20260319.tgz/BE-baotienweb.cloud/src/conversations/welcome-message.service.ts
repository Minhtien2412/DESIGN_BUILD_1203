/**
 * Welcome Message Service
 * =======================
 *
 * Tự động gửi tin nhắn chào mừng từ ADMIN khi user đăng ký thành công
 *
 * Features:
 * - Tạo conversation DIRECT giữa user mới và ADMIN
 * - Gửi tin nhắn chào mừng với hướng dẫn sử dụng
 * - Kèm đường dẫn CSKH để user có thể trao đổi trực tiếp
 *
 * @author ThietKeResort Team
 */

import { Injectable, Logger } from '@nestjs/common';
import { getErrorMessage } from '../utils/error-helpers';

import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';

// ============================================
// CONFIG
// ============================================

// ID của ADMIN DESIGN BUILD - Thay đổi theo DB thực tế
const ADMIN_DESIGN_BUILD_ID = 1;
const ADMIN_DESIGN_BUILD_NAME = 'ADMIN DESIGN BUILD';

// ============================================
// WELCOME MESSAGE CONTENT
// ============================================

const WELCOME_MESSAGE_CONTENT = `🎉 **Chào mừng bạn đến với Design Build App!**

Cảm ơn bạn đã đăng ký tài khoản. Chúng tôi rất vui được đồng hành cùng bạn trong hành trình xây dựng và thiết kế.

📱 **Hướng dẫn sử dụng app:**

1️⃣ **Khám phá dự án**: Xem các dự án thiết kế & xây dựng tại mục "Dự án"

2️⃣ **Dịch vụ**: Tìm hiểu các dịch vụ thiết kế, thi công tại mục "Dịch vụ"

3️⃣ **Sản phẩm**: Mua sắm vật liệu, nội thất tại mục "Cửa hàng"

4️⃣ **Công cụ tính toán**: 
   • Tính chi phí xây dựng
   • Tính vật liệu cần dùng
   • Dự toán ngân sách

5️⃣ **AI Kiến trúc sư**: Tư vấn thiết kế thông minh với AI

6️⃣ **AR Viewer**: Xem mô hình 3D thực tế ảo

🔗 **Các đường dẫn hữu ích:**
• Trang chủ: /home
• Dự án: /projects  
• Dịch vụ: /services
• Cửa hàng: /shop
• Công cụ tính toán: /calculators
• AI Kiến trúc: /ai-architect
• Hồ sơ cá nhân: /profile

💬 **Hỗ trợ khách hàng:**
Bạn có thể nhắn tin trực tiếp cho tôi tại đây bất cứ lúc nào!
Đội ngũ CSKH sẵn sàng hỗ trợ bạn 24/7.

📞 Hotline: 1900-xxxx
📧 Email: support@designbuild.app

Chúc bạn có trải nghiệm tuyệt vời! 🏠✨`;

// ============================================
// SERVICE
// ============================================

@Injectable()
export class WelcomeMessageService {
  private readonly logger = new Logger(WelcomeMessageService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Gửi tin nhắn chào mừng cho user mới đăng ký
   *
   * @param newUserId - ID của user vừa đăng ký
   * @param userName - Tên của user (để cá nhân hóa tin nhắn)
   */
  async sendWelcomeMessage(
    newUserId: number,
    userName?: string,
  ): Promise<void> {
    try {
      this.logger.log(`Sending welcome message to user ${newUserId}`);

      // 1. Kiểm tra ADMIN có tồn tại không
      const admin = await this.prisma.user.findUnique({
        where: { id: ADMIN_DESIGN_BUILD_ID },
      });

      if (!admin) {
        this.logger.warn(
          `ADMIN DESIGN BUILD (ID: ${ADMIN_DESIGN_BUILD_ID}) not found, skipping welcome message`,
        );
        return;
      }

      // 2. Tạo hoặc lấy conversation DIRECT giữa user và ADMIN
      const conversation = await this.createOrGetDirectConversation(
        newUserId,
        ADMIN_DESIGN_BUILD_ID,
      );

      // 3. Tạo tin nhắn chào mừng cá nhân hóa
      const personalizedMessage = userName
        ? `Xin chào ${userName}! 👋\n\n${WELCOME_MESSAGE_CONTENT}`
        : `Xin chào bạn! 👋\n\n${WELCOME_MESSAGE_CONTENT}`;

      // 4. Gửi tin nhắn
      await this.sendMessage(
        conversation.id,
        ADMIN_DESIGN_BUILD_ID,
        personalizedMessage,
      );

      this.logger.log(
        `Welcome message sent successfully to user ${newUserId} in conversation ${conversation.id}`,
      );
    } catch (error: unknown) {
      this.logger.error(
        `Failed to send welcome message to user ${newUserId}: ${getErrorMessage(error)}`,
      );
      // Không throw error để không ảnh hưởng flow đăng ký
    }
  }

  /**
   * Tạo hoặc lấy conversation DIRECT giữa 2 users
   */
  private async createOrGetDirectConversation(
    userId1: number,
    userId2: number,
  ): Promise<{ id: string }> {
    // Tạo directKey unique cho cặp users
    const directKey = this.generateDirectKey(userId1, userId2);

    // Kiểm tra conversation đã tồn tại chưa
    const existing = await this.prisma.conversation.findUnique({
      where: { directKey },
      select: { id: true },
    });

    if (existing) {
      return existing;
    }

    // Tạo conversation mới
    const conversation = await this.prisma.conversation.create({
      data: {
        type: 'DIRECT',
        directKey,
        createdBy: userId1,
        participants: {
          create: [
            {
              userId: userId1,
              role: 'MEMBER',
            },
            {
              userId: userId2,
              role: 'MEMBER',
            },
          ],
        },
      },
      select: { id: true },
    });

    return conversation;
  }

  /**
   * Gửi tin nhắn vào conversation
   */
  private async sendMessage(
    conversationId: string,
    senderId: number,
    content: string,
  ): Promise<void> {
    const clientMessageId = `welcome-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Lấy sequence number tiếp theo
    const lastMessage = await this.prisma.conversationMessage.findFirst({
      where: { conversationId },
      orderBy: { seq: 'desc' },
      select: { seq: true },
    });

    const seq = (lastMessage?.seq || 0) + 1;

    // Tạo tin nhắn
    const message = await this.prisma.conversationMessage.create({
      data: {
        conversationId,
        senderId,
        clientMessageId,
        seq,
        type: 'TEXT',
        content,
      },
    });

    // Cập nhật conversation
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: {
        lastMessageId: message.id,
        lastMessageAt: new Date(),
        lastMessagePreview: content.substring(0, 100),
        version: { increment: 1 },
      },
    });

    // Cập nhật unread count cho user nhận
    await this.prisma.conversationParticipant.updateMany({
      where: {
        conversationId,
        userId: { not: senderId },
      },
      data: {
        unreadCount: { increment: 1 },
      },
    });
  }

  /**
   * Tạo directKey unique cho cặp users
   */
  private generateDirectKey(userId1: number, userId2: number): string {
    const sortedIds = [userId1, userId2].sort((a, b) => a - b);
    return crypto
      .createHash('sha256')
      .update(sortedIds.join(':'))
      .digest('hex')
      .substring(0, 32);
  }

  /**
   * Gửi tin nhắn thông báo từ ADMIN
   * Có thể dùng để gửi thông báo khuyến mãi, cập nhật, etc.
   */
  async sendAdminNotification(
    userId: number,
    message: string,
  ): Promise<boolean> {
    try {
      const conversation = await this.createOrGetDirectConversation(
        userId,
        ADMIN_DESIGN_BUILD_ID,
      );

      await this.sendMessage(conversation.id, ADMIN_DESIGN_BUILD_ID, message);

      return true;
    } catch (error: unknown) {
      this.logger.error(`Failed to send admin notification: ${getErrorMessage(error)}`);
      return false;
    }
  }

  /**
   * Gửi tin nhắn broadcast đến nhiều users
   */
  async broadcastToUsers(userIds: number[], message: string): Promise<void> {
    for (const userId of userIds) {
      await this.sendAdminNotification(userId, message);
    }
  }
}
