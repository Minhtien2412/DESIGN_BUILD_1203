import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ReviewKycDto, SubmitKycDto } from './dto/submit-kyc.dto';
import { KycService } from './kyc.service';

@ApiTags('KYC / Verification')
@Controller({ path: 'profile', version: '1' })
export class KycController {
  constructor(private readonly kycService: KycService) {}

  @Post('verification')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Submit KYC verification request' })
  @ApiResponse({ status: 201, description: 'KYC submitted successfully' })
  async submitVerification(
    @CurrentUser('id') userId: number,
    @Body() dto: SubmitKycDto,
  ) {
    return this.kycService.submitVerification(userId, dto);
  }

  @Get('verification/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get KYC verification status' })
  @ApiResponse({ status: 200, description: 'KYC status retrieved' })
  async getVerificationStatus(@CurrentUser('id') userId: number) {
    return this.kycService.getVerificationStatus(userId);
  }
}

// Admin controller for KYC management
@ApiTags('Admin - KYC')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'admin/kyc', version: '1' })
export class KycAdminController {
  constructor(private readonly kycService: KycService) {}

  @Get()
  @ApiOperation({ summary: 'List all KYC verifications (Admin)' })
  @ApiQuery({
    name: 'status',
    required: false,
    enum: ['PENDING', 'APPROVED', 'REJECTED'],
  })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async listVerifications(
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.kycService.listVerifications(
      status as any,
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 20,
    );
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Review KYC verification (Admin)' })
  @ApiParam({ name: 'id', type: Number })
  async reviewVerification(
    @CurrentUser('id') adminId: number,
    @Param('id', ParseIntPipe) kycId: number,
    @Body() dto: ReviewKycDto,
  ) {
    return this.kycService.reviewVerification(kycId, adminId, dto);
  }
}
