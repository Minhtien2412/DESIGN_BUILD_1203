import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { KycAdminController, KycController } from './kyc.controller';
import { KycService } from './kyc.service';

@Module({
  imports: [PrismaModule],
  controllers: [KycController, KycAdminController],
  providers: [KycService],
  exports: [KycService],
})
export class KycModule {}
