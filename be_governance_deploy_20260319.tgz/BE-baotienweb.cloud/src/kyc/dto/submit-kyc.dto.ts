import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    ArrayMinSize,
    IsArray,
    IsEmail,
    IsNotEmpty,
    IsOptional,
    IsString,
} from 'class-validator';

export class SubmitKycDto {
  @ApiProperty({ example: 'Nguyễn Văn A' })
  @IsString()
  @IsNotEmpty()
  fullName: string;

  @ApiProperty({ example: '012345678901' })
  @IsString()
  @IsNotEmpty()
  idNumber: string;

  @ApiProperty({ example: '123 Nguyễn Huệ, Q.1, TP.HCM' })
  @IsString()
  @IsNotEmpty()
  address: string;

  @ApiProperty({ example: '0901234567' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ example: 'user@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: ['Cá nhân', 'Chủ đầu tư'] })
  @IsArray()
  @ArrayMinSize(1)
  @IsString({ each: true })
  accountTypes: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  idFrontImage?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  idBackImage?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  selfieImage?: string;
}

export class ReviewKycDto {
  @ApiProperty({ enum: ['APPROVED', 'REJECTED'] })
  @IsString()
  @IsNotEmpty()
  status: 'APPROVED' | 'REJECTED';

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  adminNote?: string;
}
