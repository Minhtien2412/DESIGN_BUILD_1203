import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { KycStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ReviewKycDto, SubmitKycDto } from './dto/submit-kyc.dto';

@Injectable()
export class KycService {
  private readonly logger = new Logger(KycService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Submit KYC verification request
   */
  async submitVerification(userId: number, dto: SubmitKycDto) {
    // Check if user already has a KYC verification
    const existing = await this.prisma.kycVerification.findUnique({
      where: { userId },
    });

    if (existing) {
      if (existing.status === KycStatus.APPROVED) {
        throw new BadRequestException('Tài khoản đã được xác minh');
      }
      if (existing.status === KycStatus.PENDING) {
        throw new BadRequestException('Yêu cầu xác minh đang chờ duyệt');
      }
      // If REJECTED, allow resubmission - update existing record
      const updated = await this.prisma.kycVerification.update({
        where: { userId },
        data: {
          fullName: dto.fullName,
          idNumber: dto.idNumber,
          address: dto.address,
          phone: dto.phone,
          email: dto.email,
          accountTypes: dto.accountTypes,
          idFrontImage: dto.idFrontImage,
          idBackImage: dto.idBackImage,
          selfieImage: dto.selfieImage,
          status: KycStatus.PENDING,
          adminNote: null,
          reviewedAt: null,
          reviewedBy: null,
          submittedAt: new Date(),
        },
      });

      this.logger.log(`KYC resubmitted for user ${userId}`);
      return {
        success: true,
        message: 'Đã gửi lại yêu cầu xác minh',
        data: this.formatKycResponse(updated),
      };
    }

    // Create new KYC verification
    const kyc = await this.prisma.kycVerification.create({
      data: {
        userId,
        fullName: dto.fullName,
        idNumber: dto.idNumber,
        address: dto.address,
        phone: dto.phone,
        email: dto.email,
        accountTypes: dto.accountTypes,
        idFrontImage: dto.idFrontImage,
        idBackImage: dto.idBackImage,
        selfieImage: dto.selfieImage,
      },
    });

    this.logger.log(`KYC submitted for user ${userId}`);
    return {
      success: true,
      message: 'Đã gửi yêu cầu xác minh thành công',
      data: this.formatKycResponse(kyc),
    };
  }

  /**
   * Get KYC verification status
   */
  async getVerificationStatus(userId: number) {
    const kyc = await this.prisma.kycVerification.findUnique({
      where: { userId },
    });

    if (!kyc) {
      return {
        success: true,
        data: {
          status: 'NOT_SUBMITTED',
          message: 'Chưa gửi yêu cầu xác minh',
        },
      };
    }

    return {
      success: true,
      data: this.formatKycResponse(kyc),
    };
  }

  /**
   * Admin: Review KYC verification
   */
  async reviewVerification(kycId: number, adminId: number, dto: ReviewKycDto) {
    const kyc = await this.prisma.kycVerification.findUnique({
      where: { id: kycId },
    });

    if (!kyc) {
      throw new NotFoundException('Không tìm thấy yêu cầu xác minh');
    }

    if (kyc.status !== KycStatus.PENDING) {
      throw new BadRequestException('Yêu cầu này đã được xử lý');
    }

    const updated = await this.prisma.kycVerification.update({
      where: { id: kycId },
      data: {
        status: dto.status as KycStatus,
        adminNote: dto.adminNote,
        reviewedAt: new Date(),
        reviewedBy: adminId,
      },
    });

    this.logger.log(`KYC ${kycId} ${dto.status} by admin ${adminId}`);

    return {
      success: true,
      message:
        dto.status === 'APPROVED' ? 'Đã duyệt xác minh' : 'Đã từ chối xác minh',
      data: this.formatKycResponse(updated),
    };
  }

  /**
   * Admin: List all KYC verifications
   */
  async listVerifications(status?: KycStatus, page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const where: any = {};
    if (status) where.status = status;

    const [items, total] = await Promise.all([
      this.prisma.kycVerification.findMany({
        where,
        skip,
        take: limit,
        orderBy: { submittedAt: 'desc' },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
              role: true,
            },
          },
        },
      }),
      this.prisma.kycVerification.count({ where }),
    ]);

    return {
      success: true,
      data: items,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    };
  }

  private formatKycResponse(kyc: any) {
    return {
      id: kyc.id,
      userId: kyc.userId,
      fullName: kyc.fullName,
      idNumber: kyc.idNumber,
      address: kyc.address,
      phone: kyc.phone,
      email: kyc.email,
      accountTypes: kyc.accountTypes,
      status: kyc.status,
      idFrontImage: kyc.idFrontImage,
      idBackImage: kyc.idBackImage,
      selfieImage: kyc.selfieImage,
      adminNote: kyc.adminNote,
      submittedAt: kyc.submittedAt,
      reviewedAt: kyc.reviewedAt,
    };
  }
}
