import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Request,
    UseGuards,
    ValidationPipe,
} from '@nestjs/common';
import {
    ApiBody,
    ApiOperation,
    ApiQuery,
    ApiTags
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreatePostDto, UpdatePostDto } from './dto';
import { PostsService } from './posts.service';

@ApiTags('Posts (CMS)')
@Controller({ path: 'posts', version: '1' })
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  // ========================================
  // PUBLIC ENDPOINTS (for app / web)
  // ========================================

  @Get('published')
  @ApiOperation({ summary: 'Danh sách bài viết đã xuất bản (public)' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'category', required: false })
  async getPublished(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('category') category?: string,
  ) {
    return this.postsService.findPublished({
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
      category: category as any,
    });
  }

  @Get('slug/:slug')
  @ApiOperation({ summary: 'Đọc bài viết theo slug (public)' })
  async getBySlug(@Param('slug') slug: string) {
    return this.postsService.findBySlug(slug);
  }

  // ========================================
  // ADMIN ENDPOINTS
  // ========================================

  @Get('admin/list')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: '[Admin] Danh sách tất cả bài viết' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'category', required: false })
  @ApiQuery({ name: 'search', required: false })
  async adminList(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
    @Query('category') category?: string,
    @Query('search') search?: string,
  ) {
    return this.postsService.findAllAdmin({
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20,
      status: status as any,
      category: category as any,
      search,
    });
  }

  @Get('admin/stats')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: '[Admin] Thống kê bài viết' })
  async adminStats() {
    return this.postsService.getStats();
  }

  @Get('admin/:id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: '[Admin] Xem chi tiết bài viết' })
  async adminFindOne(@Param('id', ParseIntPipe) id: number) {
    return this.postsService.findOne(id);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: '[Admin] Tạo bài viết mới' })
  @ApiBody({ type: CreatePostDto })
  async create(
    @Request() req: any,
    @Body(new ValidationPipe({ whitelist: true })) dto: CreatePostDto,
  ) {
    const authorId = req.user?.id || req.user?.userId;
    return this.postsService.create(authorId, dto);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: '[Admin] Cập nhật bài viết' })
  @ApiBody({ type: UpdatePostDto })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body(new ValidationPipe({ whitelist: true })) dto: UpdatePostDto,
  ) {
    return this.postsService.update(id, dto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: '[Admin] Xóa bài viết' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.postsService.remove(id);
  }
}
