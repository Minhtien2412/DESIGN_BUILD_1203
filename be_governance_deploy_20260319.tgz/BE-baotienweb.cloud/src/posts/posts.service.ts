import { Injectable, NotFoundException } from '@nestjs/common';
import { PostCategory, PostStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePostDto } from './dto/create-post.dto';
import { UpdatePostDto } from './dto/update-post.dto';

@Injectable()
export class PostsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Generate URL-friendly slug from title
   */
  private generateSlug(title: string): string {
    return (
      title
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
        .replace(/đ/g, 'd')
        .replace(/Đ/g, 'D')
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim()
        .substring(0, 200) +
      '-' +
      Date.now().toString(36)
    );
  }

  // ========================================
  // ADMIN: Create post
  // ========================================
  async create(authorId: number, dto: CreatePostDto) {
    const slug = dto.slug || this.generateSlug(dto.title);

    return this.prisma.post.create({
      data: {
        title: dto.title,
        slug,
        excerpt: dto.excerpt,
        content: dto.content,
        coverImage: dto.coverImage,
        images: dto.images || [],
        status: (dto.status as PostStatus) || 'DRAFT',
        category: (dto.category as PostCategory) || 'NEWS',
        tags: dto.tags || [],
        isPinned: dto.isPinned || false,
        authorId,
        publishedAt: dto.status === 'PUBLISHED' ? new Date() : null,
      },
      include: {
        author: {
          select: { id: true, name: true, avatar: true, role: true },
        },
      },
    });
  }

  // ========================================
  // ADMIN: Update post
  // ========================================
  async update(id: number, dto: UpdatePostDto) {
    const post = await this.prisma.post.findUnique({ where: { id } });
    if (!post) throw new NotFoundException(`Post #${id} not found`);

    const data: any = { ...dto };

    // Set publishedAt when transitioning to PUBLISHED
    if (dto.status === 'PUBLISHED' && post.status !== 'PUBLISHED') {
      data.publishedAt = new Date();
    }

    // Map enum string values
    if (dto.status) data.status = dto.status as PostStatus;
    if (dto.category) data.category = dto.category as PostCategory;

    return this.prisma.post.update({
      where: { id },
      data,
      include: {
        author: {
          select: { id: true, name: true, avatar: true, role: true },
        },
      },
    });
  }

  // ========================================
  // ADMIN: Delete post
  // ========================================
  async remove(id: number) {
    const post = await this.prisma.post.findUnique({ where: { id } });
    if (!post) throw new NotFoundException(`Post #${id} not found`);

    await this.prisma.post.delete({ where: { id } });
    return { message: `Post #${id} deleted` };
  }

  // ========================================
  // ADMIN: Paginated list with filters
  // ========================================
  async findAllAdmin(
    options: {
      page?: number;
      limit?: number;
      status?: PostStatus;
      category?: PostCategory;
      search?: string;
    } = {},
  ) {
    const { page = 1, limit = 20, status, category, search } = options;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (status) where.status = status;
    if (category) where.category = category;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { excerpt: { contains: search, mode: 'insensitive' } },
        { content: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [posts, total] = await Promise.all([
      this.prisma.post.findMany({
        where,
        include: {
          author: {
            select: { id: true, name: true, avatar: true, role: true },
          },
        },
        orderBy: [{ isPinned: 'desc' }, { createdAt: 'desc' }],
        skip,
        take: limit,
      }),
      this.prisma.post.count({ where }),
    ]);

    return {
      posts,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  // ========================================
  // PUBLIC: Published posts (for app/web)
  // ========================================
  async findPublished(
    options: {
      page?: number;
      limit?: number;
      category?: PostCategory;
    } = {},
  ) {
    const { page = 1, limit = 10, category } = options;
    const skip = (page - 1) * limit;

    const where: any = { status: 'PUBLISHED' };
    if (category) where.category = category;

    const [posts, total] = await Promise.all([
      this.prisma.post.findMany({
        where,
        select: {
          id: true,
          title: true,
          slug: true,
          excerpt: true,
          coverImage: true,
          category: true,
          tags: true,
          isPinned: true,
          viewCount: true,
          publishedAt: true,
          author: {
            select: { id: true, name: true, avatar: true },
          },
        },
        orderBy: [{ isPinned: 'desc' }, { publishedAt: 'desc' }],
        skip,
        take: limit,
      }),
      this.prisma.post.count({ where }),
    ]);

    return { posts, total, page, limit };
  }

  // ========================================
  // PUBLIC: Get single post by slug
  // ========================================
  async findBySlug(slug: string) {
    const post = await this.prisma.post.findUnique({
      where: { slug },
      include: {
        author: {
          select: { id: true, name: true, avatar: true },
        },
      },
    });

    if (!post || post.status !== 'PUBLISHED') {
      throw new NotFoundException('Post not found');
    }

    // Increment view count
    await this.prisma.post.update({
      where: { id: post.id },
      data: { viewCount: { increment: 1 } },
    });

    return post;
  }

  // ========================================
  // ADMIN: Get single post by ID
  // ========================================
  async findOne(id: number) {
    const post = await this.prisma.post.findUnique({
      where: { id },
      include: {
        author: {
          select: { id: true, name: true, avatar: true, role: true },
        },
      },
    });

    if (!post) throw new NotFoundException(`Post #${id} not found`);
    return post;
  }

  // ========================================
  // ADMIN: Stats
  // ========================================
  async getStats() {
    const [total, published, draft, archived, categoryStats] =
      await Promise.all([
        this.prisma.post.count(),
        this.prisma.post.count({ where: { status: 'PUBLISHED' } }),
        this.prisma.post.count({ where: { status: 'DRAFT' } }),
        this.prisma.post.count({ where: { status: 'ARCHIVED' } }),
        this.prisma.post.groupBy({
          by: ['category'],
          _count: { id: true },
        }),
      ]);

    return {
      total,
      published,
      draft,
      archived,
      byCategory: categoryStats.reduce(
        (acc, c) => {
          acc[c.category] = c._count.id;
          return acc;
        },
        {} as Record<string, number>,
      ),
    };
  }
}
