import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNotEmpty,
    IsOptional,
    IsString,
    MaxLength,
} from 'class-validator';

export enum PostStatusDto {
  DRAFT = 'DRAFT',
  PUBLISHED = 'PUBLISHED',
  ARCHIVED = 'ARCHIVED',
}

export enum PostCategoryDto {
  ANNOUNCEMENT = 'ANNOUNCEMENT',
  NEWS = 'NEWS',
  PROMOTION = 'PROMOTION',
  TUTORIAL = 'TUTORIAL',
  BLOG = 'BLOG',
  UPDATE = 'UPDATE',
  EVENT = 'EVENT',
}

export class CreatePostDto {
  @ApiProperty({
    description: 'Tiêu đề bài viết',
    example: 'Khuyến mãi mùa hè 2025',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(500)
  title: string;

  @ApiPropertyOptional({ description: 'URL slug (auto-generated if empty)' })
  @IsString()
  @IsOptional()
  @MaxLength(600)
  slug?: string;

  @ApiPropertyOptional({ description: 'Tóm tắt bài viết' })
  @IsString()
  @IsOptional()
  @MaxLength(1000)
  excerpt?: string;

  @ApiProperty({ description: 'Nội dung bài viết (HTML/Markdown)' })
  @IsString()
  @IsNotEmpty()
  content: string;

  @ApiPropertyOptional({ description: 'Ảnh bìa URL' })
  @IsString()
  @IsOptional()
  coverImage?: string;

  @ApiPropertyOptional({ description: 'Danh sách ảnh bổ sung', type: [String] })
  @IsArray()
  @IsOptional()
  images?: string[];

  @ApiPropertyOptional({ enum: PostStatusDto, default: PostStatusDto.DRAFT })
  @IsEnum(PostStatusDto)
  @IsOptional()
  status?: PostStatusDto;

  @ApiPropertyOptional({ enum: PostCategoryDto, default: PostCategoryDto.NEWS })
  @IsEnum(PostCategoryDto)
  @IsOptional()
  category?: PostCategoryDto;

  @ApiPropertyOptional({ description: 'Tags', type: [String] })
  @IsArray()
  @IsOptional()
  tags?: string[];

  @ApiPropertyOptional({ description: 'Ghim bài viết lên đầu', default: false })
  @IsBoolean()
  @IsOptional()
  isPinned?: boolean;
}
