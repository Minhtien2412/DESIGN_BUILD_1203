import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    AddFindingDto,
    CreateAuditDto,
    CreateIncidentDto,
    CreateTrainingDto,
    DistributePPEDto,
    QueryAuditDto,
    QueryIncidentDto,
    RecordAttendanceDto,
    ReturnPPEDto,
    UpdateAuditDto,
    UpdateIncidentDto,
    UpdateTrainingDto,
} from './dto';
import {
    AuditFinding,
    AuditStatus,
    IncidentSeverity,
    IncidentStatus,
    PPEDistribution as PPEDistEntity,
    PPEType,
    SafetyAudit,
    SafetyDashboard,
    SafetyIncident,
    SafetyTraining,
    TrainingAttendee,
    TrainingStatus,
} from './entities';

@Injectable()
export class SafetyService {
  constructor(private readonly prisma: PrismaService) {}

  // ========== DASHBOARD ==========

  async getDashboard(projectId?: number): Promise<SafetyDashboard> {
    const where = projectId ? { projectId } : {};

    const [audits, incidents, ppes, trainings] = await Promise.all([
      this.prisma.safetyAudit.findMany({ where }),
      this.prisma.safetyIncident.findMany({ where }),
      this.prisma.pPEDistribution.findMany({ where }),
      this.prisma.safetyTraining.findMany({
        where,
        include: { attendees: true },
      }),
    ]);

    const completedAudits = audits.filter((a) => a.status === 'COMPLETED');
    const scores = completedAudits
      .filter((a) => a.score !== null)
      .map((a) => a.score!);
    const avgScore =
      scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

    const incidentsBySeverity = Object.values(IncidentSeverity).reduce(
      (acc, sev) => {
        acc[sev] = incidents.filter(
          (i) => i.severity === sev.toUpperCase(),
        ).length;
        return acc;
      },
      {} as Record<IncidentSeverity, number>,
    );

    const ppeByType = Object.values(PPEType).reduce(
      (acc, type) => {
        acc[type] = ppes
          .filter((p) => p.ppeType === type)
          .reduce((sum, p) => sum + p.quantity, 0);
        return acc;
      },
      {} as Record<PPEType, number>,
    );

    const completedTrainings = trainings.filter(
      (t) => t.status === 'COMPLETED',
    );
    const certifiedWorkers = new Set(
      completedTrainings.flatMap((t) =>
        t.attendees.filter((a) => a.passedExam === true).map((a) => a.workerId),
      ),
    ).size;

    return {
      totalAudits: audits.length,
      completedAudits: completedAudits.length,
      averageScore: Math.round(avgScore * 10) / 10,
      totalIncidents: incidents.length,
      openIncidents: incidents.filter(
        (i) => i.status !== 'CLOSED' && i.status !== 'RESOLVED',
      ).length,
      incidentsBySeverity,
      totalPPEDistributed: ppes.reduce((sum, p) => sum + p.quantity, 0),
      ppeByType,
      totalTrainings: trainings.length,
      completedTrainings: completedTrainings.length,
      certifiedWorkers,
    };
  }

  // ========== AUDITS ==========

  async getAudits(query: QueryAuditDto): Promise<SafetyAudit[]> {
    const where: Record<string, unknown> = {};

    if (query.projectId) where.projectId = query.projectId;
    if (query.status) where.status = query.status.toUpperCase();
    if (query.auditType) where.auditType = query.auditType.toUpperCase();
    if (query.fromDate || query.toDate) {
      where.scheduledDate = {
        ...(query.fromDate && { gte: new Date(query.fromDate) }),
        ...(query.toDate && { lte: new Date(query.toDate) }),
      };
    }

    const rows = await this.prisma.safetyAudit.findMany({
      where,
      include: { findings: true },
      orderBy: { scheduledDate: 'desc' },
    });

    return rows.map((r) => this.mapAuditToEntity(r));
  }

  async getAuditById(id: number): Promise<SafetyAudit> {
    const row = await this.prisma.safetyAudit.findUnique({
      where: { id },
      include: { findings: true },
    });
    if (!row) throw new NotFoundException(`Audit ${id} not found`);
    return this.mapAuditToEntity(row);
  }

  async createAudit(dto: CreateAuditDto): Promise<SafetyAudit> {
    const row = await this.prisma.safetyAudit.create({
      data: {
        title: dto.title,
        description: dto.description,
        projectId: dto.projectId,
        auditorId: dto.auditorId,
        auditorName: `Auditor ${dto.auditorId}`,
        auditType: (dto.auditType as string).toUpperCase() as any,
        status: 'SCHEDULED',
        scheduledDate: new Date(dto.scheduledDate),
      },
      include: { findings: true },
    });
    return this.mapAuditToEntity(row);
  }

  async updateAudit(id: number, dto: UpdateAuditDto): Promise<SafetyAudit> {
    const existing = await this.prisma.safetyAudit.findUnique({
      where: { id },
    });
    if (!existing) throw new NotFoundException(`Audit ${id} not found`);

    const data: Record<string, unknown> = {};
    if (dto.title) data.title = dto.title;
    if (dto.description) data.description = dto.description;
    if (dto.status) data.status = dto.status.toUpperCase();
    if (dto.scheduledDate) data.scheduledDate = new Date(dto.scheduledDate);
    if (dto.completedDate) data.completedDate = new Date(dto.completedDate);
    if (dto.score !== undefined) data.score = dto.score;

    const row = await this.prisma.safetyAudit.update({
      where: { id },
      data,
      include: { findings: true },
    });
    return this.mapAuditToEntity(row);
  }

  async addFinding(auditId: number, dto: AddFindingDto): Promise<AuditFinding> {
    const audit = await this.prisma.safetyAudit.findUnique({
      where: { id: auditId },
    });
    if (!audit) throw new NotFoundException(`Audit ${auditId} not found`);

    const finding = await this.prisma.safetyFinding.create({
      data: {
        auditId,
        description: dto.description,
        severity: (dto.severity as string).toUpperCase() as any,
        status: 'OPEN',
        location: dto.category,
        resolution: dto.correctiveAction,
      },
    });

    return {
      id: finding.id,
      category: finding.location || '',
      description: finding.description,
      severity: dto.severity,
      correctiveAction: finding.resolution ?? undefined,
      resolved: false,
    };
  }

  async resolveFinding(
    auditId: number,
    findingId: number,
  ): Promise<AuditFinding> {
    const finding = await this.prisma.safetyFinding.findFirst({
      where: { id: findingId, auditId },
    });
    if (!finding) throw new NotFoundException(`Finding ${findingId} not found`);

    const updated = await this.prisma.safetyFinding.update({
      where: { id: findingId },
      data: { status: 'RESOLVED', resolvedAt: new Date() },
    });

    return {
      id: updated.id,
      category: updated.location || '',
      description: updated.description,
      severity: (updated.severity as string).toLowerCase() as IncidentSeverity,
      correctiveAction: updated.resolution ?? undefined,
      resolved: true,
      resolvedDate: updated.resolvedAt ?? undefined,
    };
  }

  // ========== INCIDENTS ==========

  async getIncidents(query: QueryIncidentDto): Promise<SafetyIncident[]> {
    const where: Record<string, unknown> = {};

    if (query.projectId) where.projectId = query.projectId;
    if (query.status) where.status = query.status.toUpperCase();
    if (query.severity) where.severity = query.severity.toUpperCase();
    if (query.fromDate || query.toDate) {
      where.occurredAt = {
        ...(query.fromDate && { gte: new Date(query.fromDate) }),
        ...(query.toDate && { lte: new Date(query.toDate) }),
      };
    }

    const rows = await this.prisma.safetyIncident.findMany({
      where,
      orderBy: { occurredAt: 'desc' },
    });

    return rows.map((r) => this.mapIncidentToEntity(r));
  }

  async getIncidentById(id: number): Promise<SafetyIncident> {
    const row = await this.prisma.safetyIncident.findUnique({ where: { id } });
    if (!row) throw new NotFoundException(`Incident ${id} not found`);
    return this.mapIncidentToEntity(row);
  }

  async createIncident(dto: CreateIncidentDto): Promise<SafetyIncident> {
    const row = await this.prisma.safetyIncident.create({
      data: {
        title: dto.title,
        description: dto.description,
        projectId: dto.projectId,
        location: dto.location,
        occurredAt: new Date(dto.incidentDate),
        reportedBy: dto.reportedBy,
        reporterName: `Reporter ${dto.reportedBy}`,
        severity: (dto.severity as string).toUpperCase() as any,
        status: 'REPORTED',
        injuries: dto.injuriesCount || 0,
        evidence: dto.witnesses ? (dto.witnesses as any) : undefined,
      },
    });
    return this.mapIncidentToEntity(row);
  }

  async updateIncident(
    id: number,
    dto: UpdateIncidentDto,
  ): Promise<SafetyIncident> {
    const existing = await this.prisma.safetyIncident.findUnique({
      where: { id },
    });
    if (!existing) throw new NotFoundException(`Incident ${id} not found`);

    const data: Record<string, unknown> = {};
    if (dto.title) data.title = dto.title;
    if (dto.description) data.description = dto.description;
    if (dto.status) data.status = dto.status.toUpperCase();
    if (dto.rootCause) data.rootCause = dto.rootCause;
    if (dto.correctiveActions)
      data.corrective = dto.correctiveActions.join('; ');

    if (
      dto.status === IncidentStatus.CLOSED ||
      dto.status === IncidentStatus.RESOLVED
    ) {
      data.resolvedAt = new Date();
    }

    const row = await this.prisma.safetyIncident.update({
      where: { id },
      data,
    });
    return this.mapIncidentToEntity(row);
  }

  // ========== PPE ==========

  async getPPEDistributions(
    projectId?: number,
    workerId?: number,
  ): Promise<PPEDistEntity[]> {
    const where: Record<string, unknown> = {};
    if (projectId) where.projectId = projectId;
    if (workerId) where.workerId = workerId;

    const rows = await this.prisma.pPEDistribution.findMany({
      where,
      orderBy: { distributedAt: 'desc' },
    });

    return rows.map((r) => ({
      id: r.id,
      workerId: r.workerId,
      workerName: r.workerName,
      projectId: r.projectId ?? 0,
      ppeType: r.ppeType as PPEType,
      quantity: r.quantity,
      distributedDate: r.distributedAt,
      distributedBy: r.distributedBy ?? 0,
      condition: r.condition as 'new' | 'good' | 'fair' | 'poor',
      notes: r.notes ?? undefined,
      returnDate: r.returnedAt ?? undefined,
      createdAt: r.createdAt,
    }));
  }

  async distributePPE(dto: DistributePPEDto): Promise<PPEDistEntity> {
    const row = await this.prisma.pPEDistribution.create({
      data: {
        workerId: dto.workerId,
        workerName: `Worker ${dto.workerId}`,
        projectId: dto.projectId,
        ppeType: dto.ppeType,
        quantity: dto.quantity,
        distributedBy: dto.distributedBy,
        condition: 'NEW',
        notes: dto.notes,
      },
    });

    return {
      id: row.id,
      workerId: row.workerId,
      workerName: row.workerName,
      projectId: row.projectId ?? 0,
      ppeType: row.ppeType as PPEType,
      quantity: row.quantity,
      distributedDate: row.distributedAt,
      distributedBy: row.distributedBy ?? 0,
      condition: 'new',
      notes: row.notes ?? undefined,
      createdAt: row.createdAt,
    };
  }

  async returnPPE(id: number, dto: ReturnPPEDto): Promise<PPEDistEntity> {
    const existing = await this.prisma.pPEDistribution.findUnique({
      where: { id },
    });
    if (!existing)
      throw new NotFoundException(`PPE distribution ${id} not found`);

    const row = await this.prisma.pPEDistribution.update({
      where: { id },
      data: {
        returnedAt: new Date(dto.returnDate),
        returnCondition: dto.condition,
        notes: dto.notes ?? existing.notes,
      },
    });

    return {
      id: row.id,
      workerId: row.workerId,
      workerName: row.workerName,
      projectId: row.projectId ?? 0,
      ppeType: row.ppeType as PPEType,
      quantity: row.quantity,
      distributedDate: row.distributedAt,
      distributedBy: row.distributedBy ?? 0,
      condition: (row.returnCondition ?? row.condition) as
        | 'new'
        | 'good'
        | 'fair'
        | 'poor',
      returnDate: row.returnedAt ?? undefined,
      notes: row.notes ?? undefined,
      createdAt: row.createdAt,
    };
  }

  // ========== TRAININGS ==========

  async getTrainings(
    projectId?: number,
    status?: TrainingStatus,
  ): Promise<SafetyTraining[]> {
    const where: Record<string, unknown> = {};
    if (projectId) where.projectId = projectId;
    if (status) where.status = status.toUpperCase();

    const rows = await this.prisma.safetyTraining.findMany({
      where,
      include: { attendees: true },
      orderBy: { scheduledDate: 'desc' },
    });

    return rows.map((r) => this.mapTrainingToEntity(r));
  }

  async getTrainingById(id: number): Promise<SafetyTraining> {
    const row = await this.prisma.safetyTraining.findUnique({
      where: { id },
      include: { attendees: true },
    });
    if (!row) throw new NotFoundException(`Training ${id} not found`);
    return this.mapTrainingToEntity(row);
  }

  async createTraining(dto: CreateTrainingDto): Promise<SafetyTraining> {
    const row = await this.prisma.safetyTraining.create({
      data: {
        title: dto.title,
        description: dto.description,
        projectId: dto.projectId,
        trainer: `Trainer ${dto.trainerId}`,
        status: 'SCHEDULED',
        scheduledDate: new Date(dto.scheduledDate),
        materials: dto.trainingType,
        attendees: {
          create: (dto.attendeeIds || []).map((wId) => ({
            workerId: wId,
            workerName: `Worker ${wId}`,
          })),
        },
      },
      include: { attendees: true },
    });
    return this.mapTrainingToEntity(row);
  }

  async updateTraining(
    id: number,
    dto: UpdateTrainingDto,
  ): Promise<SafetyTraining> {
    const existing = await this.prisma.safetyTraining.findUnique({
      where: { id },
    });
    if (!existing) throw new NotFoundException(`Training ${id} not found`);

    const data: Record<string, unknown> = {};
    if (dto.title) data.title = dto.title;
    if (dto.description) data.description = dto.description;
    if (dto.status) data.status = dto.status.toUpperCase();
    if (dto.scheduledDate) data.scheduledDate = new Date(dto.scheduledDate);
    if (dto.completedDate) data.completedDate = new Date(dto.completedDate);

    const row = await this.prisma.safetyTraining.update({
      where: { id },
      data,
      include: { attendees: true },
    });
    return this.mapTrainingToEntity(row);
  }

  async recordAttendance(
    trainingId: number,
    dto: RecordAttendanceDto,
  ): Promise<TrainingAttendee> {
    const training = await this.prisma.safetyTraining.findUnique({
      where: { id: trainingId },
    });
    if (!training)
      throw new NotFoundException(`Training ${trainingId} not found`);

    const row = await this.prisma.safetyTrainingAttendee.upsert({
      where: {
        trainingId_workerId: { trainingId, workerId: dto.workerId },
      },
      create: {
        trainingId,
        workerId: dto.workerId,
        workerName: `Worker ${dto.workerId}`,
        attended: dto.attended,
        score: dto.score,
        passedExam: dto.certified,
      },
      update: {
        attended: dto.attended,
        score: dto.score,
        passedExam: dto.certified,
      },
    });

    return {
      workerId: row.workerId,
      workerName: row.workerName,
      attended: row.attended,
      score: row.score ?? undefined,
      certified: row.passedExam ?? false,
    };
  }

  // ========== MAPPERS ==========

  private mapAuditToEntity(row: any): SafetyAudit {
    return {
      id: row.id,
      title: row.title,
      description: row.description ?? undefined,
      projectId: row.projectId ?? 0,
      auditorId: row.auditorId ?? 0,
      auditorName: row.auditorName ?? '',
      auditType: (row.auditType as string).toLowerCase() as any,
      status: (row.status as string).toLowerCase() as AuditStatus,
      scheduledDate: row.scheduledDate,
      completedDate: row.completedDate ?? undefined,
      findings: (row.findings || []).map((f: any) => ({
        id: f.id,
        category: f.location || '',
        description: f.description,
        severity: (f.severity as string).toLowerCase() as IncidentSeverity,
        correctiveAction: f.resolution ?? undefined,
        resolved: f.status === 'RESOLVED',
        resolvedDate: f.resolvedAt ?? undefined,
      })),
      score: row.score ?? undefined,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  private mapIncidentToEntity(row: any): SafetyIncident {
    return {
      id: row.id,
      title: row.title,
      description: row.description,
      projectId: row.projectId ?? 0,
      location: row.location ?? '',
      incidentDate: row.occurredAt,
      reportedBy: row.reportedBy ?? 0,
      reportedByName: row.reporterName ?? '',
      severity: (row.severity as string).toLowerCase() as IncidentSeverity,
      status: (row.status as string).toLowerCase() as IncidentStatus,
      injuriesCount: row.injuries,
      rootCause: row.rootCause ?? undefined,
      correctiveActions: row.corrective
        ? row.corrective.split('; ')
        : undefined,
      closedDate: row.resolvedAt ?? undefined,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  private mapTrainingToEntity(row: any): SafetyTraining {
    return {
      id: row.id,
      title: row.title,
      description: row.description ?? undefined,
      projectId: row.projectId ?? undefined,
      trainerId: 0,
      trainerName: row.trainer ?? '',
      trainingType: row.materials ?? '',
      status: (row.status as string).toLowerCase() as TrainingStatus,
      scheduledDate: row.scheduledDate,
      completedDate: row.completedDate ?? undefined,
      duration: 0,
      attendees: (row.attendees || []).map((a: any) => ({
        workerId: a.workerId,
        workerName: a.workerName,
        attended: a.attended,
        score: a.score ?? undefined,
        certified: a.passedExam ?? false,
      })),
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }
}
