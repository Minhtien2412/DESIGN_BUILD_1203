// Safety Module Entities

export enum AuditStatus {
  SCHEDULED = 'scheduled',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export enum AuditType {
  ROUTINE = 'routine',
  ANNUAL = 'annual',
  SPOT_CHECK = 'spot_check',
  INCIDENT_FOLLOW_UP = 'incident_follow_up',
  THIRD_PARTY = 'third_party',
}

export enum IncidentSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}

export enum IncidentStatus {
  REPORTED = 'reported',
  INVESTIGATING = 'investigating',
  RESOLVED = 'resolved',
  CLOSED = 'closed',
}

export enum PPEType {
  HELMET = 'helmet',
  GLOVES = 'gloves',
  SAFETY_GLASSES = 'safety_glasses',
  SAFETY_BOOTS = 'safety_boots',
  HIGH_VIS_VEST = 'high_vis_vest',
  HEARING_PROTECTION = 'hearing_protection',
  RESPIRATOR = 'respirator',
  HARNESS = 'harness',
}

export enum TrainingStatus {
  SCHEDULED = 'scheduled',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export interface SafetyAudit {
  id: number;
  title: string;
  description?: string;
  projectId: number;
  auditorId: number;
  auditorName: string;
  auditType: AuditType;
  status: AuditStatus;
  scheduledDate: Date;
  completedDate?: Date;
  findings: AuditFinding[];
  score?: number;
  maxScore?: number;
  recommendations?: string[];
  attachments?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface AuditFinding {
  id: number;
  category: string;
  description: string;
  severity: IncidentSeverity;
  correctiveAction?: string;
  deadline?: Date;
  resolved: boolean;
  resolvedDate?: Date;
}

export interface SafetyIncident {
  id: number;
  title: string;
  description: string;
  projectId: number;
  location: string;
  incidentDate: Date;
  reportedBy: number;
  reportedByName: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  injuriesCount: number;
  injuryDetails?: string;
  witnesses?: string[];
  rootCause?: string;
  correctiveActions?: string[];
  preventiveMeasures?: string[];
  attachments?: string[];
  investigatorId?: number;
  investigationNotes?: string;
  closedDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface PPEDistribution {
  id: number;
  workerId: number;
  workerName: string;
  projectId: number;
  ppeType: PPEType;
  quantity: number;
  distributedDate: Date;
  distributedBy: number;
  expiryDate?: Date;
  returnDate?: Date;
  condition: 'new' | 'good' | 'fair' | 'poor';
  notes?: string;
  createdAt: Date;
}

export interface SafetyTraining {
  id: number;
  title: string;
  description?: string;
  projectId?: number;
  trainerId: number;
  trainerName: string;
  trainingType: string;
  status: TrainingStatus;
  scheduledDate: Date;
  completedDate?: Date;
  duration: number; // in hours
  attendees: TrainingAttendee[];
  materials?: string[];
  passingScore?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface TrainingAttendee {
  workerId: number;
  workerName: string;
  attended: boolean;
  score?: number;
  certified: boolean;
  certificationExpiry?: Date;
}

export interface SafetyDashboard {
  totalAudits: number;
  completedAudits: number;
  averageScore: number;
  totalIncidents: number;
  openIncidents: number;
  incidentsBySeverity: Record<IncidentSeverity, number>;
  totalPPEDistributed: number;
  ppeByType: Record<PPEType, number>;
  totalTrainings: number;
  completedTrainings: number;
  certifiedWorkers: number;
}
