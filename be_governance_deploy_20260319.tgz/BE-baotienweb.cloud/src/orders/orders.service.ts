import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  CancelOrderDto,
  CreateOrderDto,
  CreateRefundDto,
  OrderQueryDto,
  OrderStatus,
  PaymentStatus,
  ReviewRefundDto,
} from './dto';

@Injectable()
export class OrdersService {
  private readonly logger = new Logger(OrdersService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Generate unique order number
   */
  private generateOrderNumber(): string {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `ORD-${timestamp}-${random}`;
  }

  /**
   * Create a new order
   */
  async createOrder(userId: number, dto: CreateOrderDto) {
    const { items, shippingAddress, paymentMethod, note, couponCode } = dto;

    // Validate products and calculate prices
    const productIds = items.map((item) => item.productId);
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds } },
      include: { images: { where: { isPrimary: true }, take: 1 } },
    });

    if (products.length !== productIds.length) {
      throw new BadRequestException('Some products not found');
    }

    // Check stock availability
    for (const item of items) {
      const product = products.find((p) => p.id === item.productId);
      if (!product) {
        throw new BadRequestException(`Product ${item.productId} not found`);
      }
      if (product.stock < item.quantity) {
        throw new BadRequestException(
          `Insufficient stock for product: ${product.name}`,
        );
      }
    }

    // Calculate totals
    let subtotal = 0;
    const orderItems = items.map((item) => {
      const product = products.find((p) => p.id === item.productId)!;
      const price = Number(product.price);
      const total = price * item.quantity;
      subtotal += total;

      return {
        productId: product.id,
        productName: product.name,
        productSku: product.strapiId,
        productImage: product.images[0]?.url || null,
        quantity: item.quantity,
        price,
        total,
      };
    });

    // Calculate shipping fee (free over 500k VND)
    const shippingFee = subtotal >= 500000 ? 0 : 30000;

    // Apply coupon discount (simplified - you can expand this)
    let discount = 0;
    if (couponCode) {
      // TODO: Validate coupon and calculate discount
      // For now, just a placeholder
      discount = 0;
    }

    const total = subtotal + shippingFee - discount;

    // Create order in transaction
    const order = await this.prisma.$transaction(async (tx) => {
      // Create order
      const newOrder = await tx.order.create({
        data: {
          orderNumber: this.generateOrderNumber(),
          userId,
          shippingAddress: shippingAddress as any,
          subtotal,
          shippingFee,
          discount,
          total,
          paymentMethod,
          note,
          couponCode,
          items: {
            create: orderItems,
          },
        },
        include: {
          items: true,
        },
      });

      // Update product stock
      for (const item of items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stock: { decrement: item.quantity },
            soldCount: { increment: item.quantity },
          },
        });
      }

      // Clear user's cart after order
      await tx.cart.deleteMany({
        where: { userId },
      });

      return newOrder;
    });

    this.logger.log(`Order created: ${order.orderNumber} for user ${userId}`);

    return this.formatOrderResponse(order);
  }

  /**
   * Get user's orders with pagination
   */
  async getUserOrders(userId: number, query: OrderQueryDto) {
    const { page = 1, limit = 20, status, startDate, endDate } = query;
    const skip = (page - 1) * limit;

    const where: any = { userId };

    if (status) {
      where.status = status;
    }

    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) {
        where.createdAt.gte = new Date(startDate);
      }
      if (endDate) {
        where.createdAt.lte = new Date(endDate);
      }
    }

    const [orders, total] = await Promise.all([
      this.prisma.order.findMany({
        where,
        include: {
          items: true,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.order.count({ where }),
    ]);

    return {
      orders: orders.map((order: any) => this.formatOrderResponse(order)),
      total,
      page,
      limit,
      hasMore: skip + orders.length < total,
    };
  }

  /**
   * Get single order by ID
   */
  async getOrderById(userId: number, orderId: number) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        items: true,
      },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    return this.formatOrderResponse(order);
  }

  /**
   * Get order by order number
   */
  async getOrderByNumber(userId: number, orderNumber: string) {
    const order = await this.prisma.order.findUnique({
      where: { orderNumber },
      include: {
        items: true,
      },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    return this.formatOrderResponse(order);
  }

  /**
   * Cancel an order
   */
  async cancelOrder(userId: number, orderId: number, dto: CancelOrderDto) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    // Check if order can be cancelled
    const cancelableStatuses: string[] = [
      OrderStatus.PENDING,
      OrderStatus.CONFIRMED,
      OrderStatus.PROCESSING,
    ];
    if (!cancelableStatuses.includes(order.status)) {
      throw new BadRequestException(
        'Order cannot be cancelled in current status',
      );
    }

    // Cancel order and restore stock
    const updatedOrder = await this.prisma.$transaction(async (tx) => {
      // Update order status
      const cancelled = await tx.order.update({
        where: { id: orderId },
        data: {
          status: OrderStatus.CANCELLED,
          cancelReason: dto.reason,
          cancelledAt: new Date(),
        },
        include: { items: true },
      });

      // Restore product stock
      for (const item of order.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stock: { increment: item.quantity },
            soldCount: { decrement: item.quantity },
          },
        });
      }

      return cancelled;
    });

    this.logger.log(`Order cancelled: ${order.orderNumber}`);

    return this.formatOrderResponse(updatedOrder);
  }

  /**
   * Get order tracking info
   */
  async getOrderTracking(userId: number, orderId: number) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    // Generate mock tracking history based on order status
    const history = this.generateTrackingHistory(order);

    return {
      trackingNumber: order.trackingNumber || 'Pending',
      carrier: order.carrier || 'TBD',
      status: order.status,
      history,
    };
  }

  /**
   * Generate mock tracking history
   */
  private generateTrackingHistory(order: any) {
    const history: any[] = [];
    const createdAt = new Date(order.createdAt);

    history.push({
      status: 'Order placed',
      location: 'Online',
      timestamp: createdAt,
    });

    if (
      [
        'CONFIRMED',
        'PROCESSING',
        'SHIPPING',
        'DELIVERED',
        'COMPLETED',
      ].includes(order.status)
    ) {
      history.push({
        status: 'Order confirmed',
        location: 'Warehouse',
        timestamp: new Date(createdAt.getTime() + 30 * 60 * 1000),
      });
    }

    if (
      ['PROCESSING', 'SHIPPING', 'DELIVERED', 'COMPLETED'].includes(
        order.status,
      )
    ) {
      history.push({
        status: 'Processing',
        location: 'Warehouse',
        timestamp: new Date(createdAt.getTime() + 2 * 60 * 60 * 1000),
      });
    }

    if (['SHIPPING', 'DELIVERED', 'COMPLETED'].includes(order.status)) {
      history.push({
        status: 'Shipped',
        location: 'In Transit',
        timestamp: new Date(createdAt.getTime() + 24 * 60 * 60 * 1000),
      });
    }

    if (['DELIVERED', 'COMPLETED'].includes(order.status)) {
      history.push({
        status: 'Delivered',
        location: order.shippingAddress?.city || 'Destination',
        timestamp: order.deliveredAt || new Date(),
      });
    }

    return history.reverse();
  }

  /**
   * Get payment URL for VNPAY
   */
  async getVnpayPaymentUrl(userId: number, orderId: number) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    if (order.paymentStatus === 'PAID') {
      throw new BadRequestException('Order already paid');
    }

    // TODO: Integrate with real VNPAY API
    // For now, return mock URL
    const paymentUrl = `https://sandbox.vnpayment.vn/paymentv2/Transaction/PaymentMethod.html?token=${order.orderNumber}`;

    return { paymentUrl };
  }

  /**
   * Get payment URL for MoMo
   */
  async getMomoPaymentUrl(userId: number, orderId: number) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    if (order.userId !== userId) {
      throw new ForbiddenException('Access denied to this order');
    }

    if (order.paymentStatus === 'PAID') {
      throw new BadRequestException('Order already paid');
    }

    // TODO: Integrate with real MoMo API
    // For now, return mock URLs
    const paymentUrl = `https://test-payment.momo.vn/v2/gateway/pay?token=${order.orderNumber}`;
    const deeplink = `momo://pay?token=${order.orderNumber}`;

    return { paymentUrl, deeplink };
  }

  /**
   * Handle payment callback (webhook)
   */
  async handlePaymentCallback(provider: 'vnpay' | 'momo', payload: any) {
    // TODO: Verify payment signature
    // TODO: Update order payment status

    const orderNumber = payload.orderNumber || payload.orderId;

    const order = await this.prisma.order.findUnique({
      where: { orderNumber },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    // Update order payment status
    await this.prisma.order.update({
      where: { id: order.id },
      data: {
        paymentStatus: PaymentStatus.PAID,
        paidAt: new Date(),
        transactionId: payload.transactionId,
        status: OrderStatus.CONFIRMED,
      },
    });

    this.logger.log(`Payment received for order: ${orderNumber}`);

    return { success: true };
  }

  /**
   * Format order response
   */
  private formatOrderResponse(order: any) {
    return {
      id: order.id,
      orderNumber: order.orderNumber,
      userId: order.userId,
      items:
        order.items?.map((item: any) => ({
          id: item.id,
          productId: item.productId,
          product: {
            id: item.productId,
            name: item.productName,
            price: Number(item.price),
            images: item.productImage ? [{ url: item.productImage }] : [],
          },
          quantity: item.quantity,
          price: Number(item.price),
          total: Number(item.total),
        })) || [],
      shippingAddress: order.shippingAddress,
      subtotal: Number(order.subtotal),
      shippingFee: Number(order.shippingFee),
      discount: Number(order.discount),
      total: Number(order.total),
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      status: order.status,
      note: order.note,
      trackingNumber: order.trackingNumber,
      estimatedDelivery: order.estimatedDelivery,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,
    };
  }

  // =====================================================
  // REFUND / COMPLAINT METHODS
  // =====================================================

  /**
   * Request a refund for an order
   */
  async requestRefund(userId: number, orderId: number, dto: CreateRefundDto) {
    const order = await this.prisma.order.findFirst({
      where: { id: orderId, userId },
    });

    if (!order) {
      throw new NotFoundException('Không tìm thấy đơn hàng');
    }

    // Only allow refund for DELIVERED or COMPLETED orders
    const allowedStatuses = ['DELIVERED', 'COMPLETED'];
    if (!allowedStatuses.includes(order.status)) {
      throw new BadRequestException(
        'Chỉ có thể yêu cầu hoàn tiền cho đơn hàng đã giao/hoàn thành',
      );
    }

    // Check if there's already a pending refund
    const existingRefund = await this.prisma.refundRequest.findFirst({
      where: {
        orderId,
        status: { in: ['PENDING', 'PROCESSING'] },
      },
    });

    if (existingRefund) {
      throw new BadRequestException('Đã có yêu cầu hoàn tiền đang chờ xử lý');
    }

    // Use order total if amount not specified
    const refundAmount = dto.amount || Number(order.total);

    const refund = await this.prisma.refundRequest.create({
      data: {
        orderId,
        userId,
        reason: dto.reason,
        reasonType: dto.reasonType,
        evidenceUrls: dto.evidenceUrls || [],
        amount: refundAmount,
      },
    });

    this.logger.log(
      `Refund request created: ${refund.id} for order ${orderId}`,
    );

    return {
      success: true,
      message: 'Đã gửi yêu cầu hoàn tiền',
      data: this.formatRefundResponse(refund),
    };
  }

  /**
   * Get refund requests for an order
   */
  async getOrderRefunds(userId: number, orderId: number) {
    const order = await this.prisma.order.findFirst({
      where: { id: orderId, userId },
    });

    if (!order) {
      throw new NotFoundException('Không tìm thấy đơn hàng');
    }

    const refunds = await this.prisma.refundRequest.findMany({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    });

    return {
      success: true,
      data: refunds.map((r) => this.formatRefundResponse(r)),
    };
  }

  /**
   * Get all refund requests for a user
   */
  async getUserRefunds(userId: number, page = 1, limit = 20) {
    const skip = (page - 1) * limit;

    const [refunds, total] = await Promise.all([
      this.prisma.refundRequest.findMany({
        where: { userId },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          order: {
            select: {
              id: true,
              orderNumber: true,
              total: true,
              status: true,
            },
          },
        },
      }),
      this.prisma.refundRequest.count({ where: { userId } }),
    ]);

    return {
      success: true,
      data: refunds.map((r) => ({
        ...this.formatRefundResponse(r),
        order: {
          id: r.order.id,
          orderNumber: r.order.orderNumber,
          total: Number(r.order.total),
          status: r.order.status,
        },
      })),
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Admin: Review refund request
   */
  async reviewRefund(refundId: number, adminId: number, dto: ReviewRefundDto) {
    const refund = await this.prisma.refundRequest.findUnique({
      where: { id: refundId },
      include: { order: true },
    });

    if (!refund) {
      throw new NotFoundException('Không tìm thấy yêu cầu hoàn tiền');
    }

    if (refund.status !== 'PENDING') {
      throw new BadRequestException('Yêu cầu này đã được xử lý');
    }

    const updatedRefund = await this.prisma.$transaction(async (tx) => {
      const updated = await tx.refundRequest.update({
        where: { id: refundId },
        data: {
          status: dto.status === 'APPROVED' ? 'APPROVED' : 'REJECTED',
          adminNote: dto.adminNote,
          resolvedAt: new Date(),
          resolvedBy: adminId,
        },
      });

      // If approved, update order status to REFUNDED
      if (dto.status === 'APPROVED') {
        await tx.order.update({
          where: { id: refund.orderId },
          data: {
            status: 'REFUNDED',
            paymentStatus: 'REFUNDED',
          },
        });
      }

      return updated;
    });

    this.logger.log(`Refund ${refundId} ${dto.status} by admin ${adminId}`);

    return {
      success: true,
      message:
        dto.status === 'APPROVED'
          ? 'Đã duyệt hoàn tiền'
          : 'Đã từ chối hoàn tiền',
      data: this.formatRefundResponse(updatedRefund),
    };
  }

  /**
   * Admin: List all refund requests
   */
  async listAllRefunds(status?: string, page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const where: any = {};
    if (status) where.status = status;

    const [refunds, total] = await Promise.all([
      this.prisma.refundRequest.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          order: {
            select: { id: true, orderNumber: true, total: true, status: true },
          },
          user: {
            select: { id: true, name: true, email: true },
          },
        },
      }),
      this.prisma.refundRequest.count({ where }),
    ]);

    return {
      success: true,
      data: refunds.map((r) => ({
        ...this.formatRefundResponse(r),
        order: {
          id: r.order.id,
          orderNumber: r.order.orderNumber,
          total: Number(r.order.total),
          status: r.order.status,
        },
        user: r.user,
      })),
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    };
  }

  private formatRefundResponse(refund: any) {
    return {
      id: refund.id,
      orderId: refund.orderId,
      userId: refund.userId,
      reason: refund.reason,
      reasonType: refund.reasonType,
      evidenceUrls: refund.evidenceUrls,
      amount: Number(refund.amount),
      status: refund.status,
      adminNote: refund.adminNote,
      createdAt: refund.createdAt,
      resolvedAt: refund.resolvedAt,
    };
  }
}
