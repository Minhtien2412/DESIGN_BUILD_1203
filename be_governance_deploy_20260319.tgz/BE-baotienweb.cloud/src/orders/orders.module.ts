import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { OrdersController, RefundAdminController } from './orders.controller';
import { OrdersService } from './orders.service';

@Module({
  imports: [PrismaModule],
  controllers: [OrdersController, RefundAdminController],
  providers: [OrdersService],
  exports: [OrdersService],
})
export class OrdersModule {}
