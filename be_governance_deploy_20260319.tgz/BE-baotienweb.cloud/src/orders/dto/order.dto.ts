import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    OrderStatus as PrismaOrderStatus,
    PaymentMethod as PrismaPaymentMethod,
    PaymentStatus as PrismaPaymentStatus,
} from '@prisma/client';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsOptional,
    IsPositive,
    IsString,
    ValidateNested,
} from 'class-validator';

// Re-export Prisma enums for convenience
export const OrderStatus = PrismaOrderStatus;
export type OrderStatus = PrismaOrderStatus;

export const PaymentMethod = PrismaPaymentMethod;
export type PaymentMethod = PrismaPaymentMethod;

export const PaymentStatus = PrismaPaymentStatus;
export type PaymentStatus = PrismaPaymentStatus;

export class ShippingAddressDto {
  @ApiProperty()
  @IsNotEmpty()
  fullName: string;

  @ApiProperty()
  @IsNotEmpty()
  phone: string;

  @ApiProperty()
  @IsNotEmpty()
  address: string;

  @ApiPropertyOptional()
  @IsOptional()
  ward?: string;

  @ApiPropertyOptional()
  @IsOptional()
  district?: string;

  @ApiProperty()
  @IsNotEmpty()
  city: string;

  @ApiPropertyOptional()
  @IsOptional()
  note?: string;
}

export class OrderItemDto {
  @ApiProperty()
  @IsInt()
  productId: number;

  @ApiProperty()
  @IsInt()
  @IsPositive()
  quantity: number;
}

export class CreateOrderDto {
  @ApiProperty({ type: [OrderItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => OrderItemDto)
  items: OrderItemDto[];

  @ApiProperty({ type: ShippingAddressDto })
  @ValidateNested()
  @Type(() => ShippingAddressDto)
  shippingAddress: ShippingAddressDto;

  @ApiProperty({ enum: PaymentMethod })
  @IsEnum(PaymentMethod)
  paymentMethod: PaymentMethod;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  note?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  couponCode?: string;
}

export class OrderQueryDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  page?: number = 1;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  limit?: number = 20;

  @ApiPropertyOptional({ enum: OrderStatus })
  @IsOptional()
  @IsEnum(OrderStatus)
  status?: OrderStatus;

  @ApiPropertyOptional()
  @IsOptional()
  startDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  endDate?: string;
}

export class CancelOrderDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reason?: string;
}

export class OrderItemResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  productId: number;

  @ApiProperty()
  product: {
    id: number;
    name: string;
    price: number;
    images: { url: string }[];
  };

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  price: number;

  @ApiProperty()
  total: number;
}

export class OrderResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  orderNumber: string;

  @ApiProperty()
  userId: number;

  @ApiProperty({ type: [OrderItemResponseDto] })
  items: OrderItemResponseDto[];

  @ApiProperty({ type: ShippingAddressDto })
  shippingAddress: ShippingAddressDto;

  @ApiProperty()
  subtotal: number;

  @ApiProperty()
  shippingFee: number;

  @ApiProperty()
  discount: number;

  @ApiProperty()
  total: number;

  @ApiProperty({ enum: PaymentMethod })
  paymentMethod: PaymentMethod;

  @ApiProperty({ enum: PaymentStatus })
  paymentStatus: PaymentStatus;

  @ApiProperty({ enum: OrderStatus })
  status: OrderStatus;

  @ApiPropertyOptional()
  note?: string;

  @ApiPropertyOptional()
  trackingNumber?: string;

  @ApiPropertyOptional()
  estimatedDelivery?: string;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class OrdersListResponseDto {
  @ApiProperty({ type: [OrderResponseDto] })
  orders: OrderResponseDto[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  page: number;

  @ApiProperty()
  limit: number;

  @ApiProperty()
  hasMore: boolean;
}

export class TrackingHistoryDto {
  @ApiProperty()
  status: string;

  @ApiProperty()
  location: string;

  @ApiProperty()
  timestamp: Date;
}

export class OrderTrackingResponseDto {
  @ApiProperty()
  trackingNumber: string;

  @ApiProperty()
  carrier: string;

  @ApiProperty()
  status: string;

  @ApiProperty({ type: [TrackingHistoryDto] })
  history: TrackingHistoryDto[];
}

export class PaymentUrlResponseDto {
  @ApiProperty()
  paymentUrl: string;

  @ApiPropertyOptional()
  deeplink?: string;
}

export class PaymentStatusResponseDto {
  @ApiProperty()
  paid: boolean;

  @ApiProperty({ enum: PaymentStatus })
  paymentStatus: PaymentStatus;

  @ApiPropertyOptional()
  transactionId?: string;

  @ApiPropertyOptional()
  paidAt?: Date;
}
