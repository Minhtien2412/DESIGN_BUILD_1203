import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

export class CreateRefundDto {
  @ApiProperty({ example: 'Sản phẩm bị lỗi' })
  @IsString()
  @IsNotEmpty()
  reason: string;

  @ApiProperty({
    example: 'DAMAGED',
    enum: ['DAMAGED', 'WRONG_ITEM', 'NOT_RECEIVED', 'QUALITY', 'OTHER'],
  })
  @IsString()
  @IsNotEmpty()
  reasonType: string;

  @ApiPropertyOptional({
    example: ['https://example.com/evidence1.jpg'],
    type: [String],
  })
  @IsArray()
  @IsOptional()
  @IsString({ each: true })
  evidenceUrls?: string[];

  @ApiPropertyOptional({ example: 150000 })
  @IsNumber()
  @IsOptional()
  @Min(0)
  amount?: number;
}

export class ReviewRefundDto {
  @ApiProperty({ enum: ['APPROVED', 'REJECTED'] })
  @IsString()
  @IsNotEmpty()
  status: 'APPROVED' | 'REJECTED';

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  adminNote?: string;
}
