import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CancelOrderDto,
    CreateOrderDto,
    CreateRefundDto,
    OrderQueryDto,
    OrderResponseDto,
    OrdersListResponseDto,
    OrderStatus,
    OrderTrackingResponseDto,
    PaymentUrlResponseDto,
    ReviewRefundDto,
} from './dto';
import { OrdersService } from './orders.service';

@ApiTags('Orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new order' })
  @ApiResponse({ status: 201, type: OrderResponseDto })
  async createOrder(
    @CurrentUser('id') userId: number,
    @Body() dto: CreateOrderDto,
  ) {
    return this.ordersService.createOrder(userId, dto);
  }

  @Get()
  @ApiOperation({ summary: 'Get user orders' })
  @ApiResponse({ status: 200, type: OrdersListResponseDto })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: OrderStatus })
  @ApiQuery({ name: 'startDate', required: false, type: String })
  @ApiQuery({ name: 'endDate', required: false, type: String })
  async getUserOrders(
    @CurrentUser('id') userId: number,
    @Query() query: OrderQueryDto,
  ) {
    return this.ordersService.getUserOrders(userId, query);
  }

  @Get('my/refunds')
  @ApiOperation({ summary: 'Get all my refund requests' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getMyRefunds(
    @CurrentUser('id') userId: number,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.ordersService.getUserRefunds(
      userId,
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 20,
    );
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get order by ID' })
  @ApiResponse({ status: 200, type: OrderResponseDto })
  @ApiParam({ name: 'id', type: Number })
  async getOrderById(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
  ) {
    return this.ordersService.getOrderById(userId, orderId);
  }

  @Get('number/:orderNumber')
  @ApiOperation({ summary: 'Get order by order number' })
  @ApiResponse({ status: 200, type: OrderResponseDto })
  @ApiParam({ name: 'orderNumber', type: String })
  async getOrderByNumber(
    @CurrentUser('id') userId: number,
    @Param('orderNumber') orderNumber: string,
  ) {
    return this.ordersService.getOrderByNumber(userId, orderNumber);
  }

  @Post(':id/cancel')
  @ApiOperation({ summary: 'Cancel an order' })
  @ApiResponse({ status: 200, type: OrderResponseDto })
  @ApiParam({ name: 'id', type: Number })
  async cancelOrder(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
    @Body() dto: CancelOrderDto,
  ) {
    return this.ordersService.cancelOrder(userId, orderId, dto);
  }

  @Get(':id/tracking')
  @ApiOperation({ summary: 'Get order tracking info' })
  @ApiResponse({ status: 200, type: OrderTrackingResponseDto })
  @ApiParam({ name: 'id', type: Number })
  async getOrderTracking(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
  ) {
    return this.ordersService.getOrderTracking(userId, orderId);
  }

  @Post(':id/pay/vnpay')
  @ApiOperation({ summary: 'Get VNPAY payment URL' })
  @ApiResponse({ status: 200, type: PaymentUrlResponseDto })
  @ApiParam({ name: 'id', type: Number })
  async getVnpayPaymentUrl(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
  ) {
    return this.ordersService.getVnpayPaymentUrl(userId, orderId);
  }

  @Post(':id/pay/momo')
  @ApiOperation({ summary: 'Get MoMo payment URL' })
  @ApiResponse({ status: 200, type: PaymentUrlResponseDto })
  @ApiParam({ name: 'id', type: Number })
  async getMomoPaymentUrl(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
  ) {
    return this.ordersService.getMomoPaymentUrl(userId, orderId);
  }

  // ==================== REFUND ENDPOINTS ====================

  @Post(':id/refund')
  @ApiOperation({ summary: 'Request a refund for an order' })
  @ApiParam({ name: 'id', type: Number })
  async requestRefund(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
    @Body() dto: CreateRefundDto,
  ) {
    return this.ordersService.requestRefund(userId, orderId, dto);
  }

  @Get(':id/refund')
  @ApiOperation({ summary: 'Get refund requests for an order' })
  @ApiParam({ name: 'id', type: Number })
  async getOrderRefunds(
    @CurrentUser('id') userId: number,
    @Param('id', ParseIntPipe) orderId: number,
  ) {
    return this.ordersService.getOrderRefunds(userId, orderId);
  }
}

// Admin refund management controller
@ApiTags('Admin - Refunds')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('admin/refunds')
export class RefundAdminController {
  constructor(private readonly ordersService: OrdersService) {}

  @Get()
  @ApiOperation({ summary: 'List all refund requests (Admin)' })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async listAllRefunds(
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.ordersService.listAllRefunds(
      status,
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 20,
    );
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Review a refund request (Admin)' })
  @ApiParam({ name: 'id', type: Number })
  async reviewRefund(
    @CurrentUser('id') adminId: number,
    @Param('id', ParseIntPipe) refundId: number,
    @Body() dto: ReviewRefundDto,
  ) {
    return this.ordersService.reviewRefund(refundId, adminId, dto);
  }
}
