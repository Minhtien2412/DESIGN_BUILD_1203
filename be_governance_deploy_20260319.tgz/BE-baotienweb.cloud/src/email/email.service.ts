import { Injectable, Logger } from '@nestjs/common';
import { getErrorMessage } from '../utils/error-helpers';

import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';

interface EmailOptions {
  to: string | string[];
  subject: string;
  text?: string;
  html?: string;
  attachments?: Array<{
    filename: string;
    path?: string;
    content?: Buffer | string;
  }>;
}

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);

  constructor(private configService: ConfigService) {}

  /**
   * Send email using SMTP (Nodemailer)
   * Requires: npm install nodemailer @types/nodemailer
   */
  async sendEmail(options: EmailOptions): Promise<boolean> {
    try {
      const smtpUser = this.configService.get('SMTP_USER');
      const smtpPass = this.configService.get('SMTP_PASS');
      const smtpSecure = this.configService.get('SMTP_SECURE') === 'true';

      const transportConfig: nodemailer.TransportOptions = {
        host: this.configService.get('SMTP_HOST'),
        port: parseInt(this.configService.get('SMTP_PORT') || '25'),
        secure: smtpSecure,
        tls: {
          rejectUnauthorized: false,
        },
      } as nodemailer.TransportOptions;

      // Only add auth if credentials provided
      if (smtpUser && smtpPass) {
        (transportConfig as any).auth = {
          user: smtpUser,
          pass: smtpPass,
        };
      }

      const transporter = nodemailer.createTransport(transportConfig);

      await transporter.sendMail({
        from: this.configService.get('SMTP_FROM'),
        ...options,
      });

      this.logger.log(`Email sent to: ${options.to}`);
      this.logger.debug(`Subject: ${options.subject}`);

      return true;
    } catch (error: unknown) {
      this.logger.error(`Failed to send email: ${getErrorMessage(error)}`);
      return false;
    }
  }

  /**
   * Send welcome email to new user
   */
  async sendWelcomeEmail(email: string, name: string): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: 'Chào mừng đến với BaoTienWeb',
      html: `
        <h1>Xin chào ${name}!</h1>
        <p>Cảm ơn bạn đã đăng ký sử dụng hệ thống quản lý dự án xây dựng BaoTienWeb.</p>
        <p>Bạn có thể bắt đầu sử dụng ngay tại: <a href="${this.configService.get('APP_URL')}">${this.configService.get('APP_URL')}</a></p>
        <p>Trân trọng,<br/>BaoTienWeb Team</p>
      `,
    });
  }

  /**
   * Send contract signature notification
   */
  async sendContractSignedNotification(
    email: string,
    contractNo: string,
    contractTitle: string,
    pdfUrl: string,
  ): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: `Hợp đồng ${contractNo} đã được ký`,
      html: `
        <h2>Hợp đồng đã được ký thành công</h2>
        <p><strong>Số hợp đồng:</strong> ${contractNo}</p>
        <p><strong>Tiêu đề:</strong> ${contractTitle}</p>
        <p>Bạn có thể tải hợp đồng đã ký tại: <a href="${pdfUrl}">Tải xuống</a></p>
        <p>Trân trọng,<br/>BaoTienWeb Team</p>
      `,
    });
  }

  /**
   * Send QC bug notification
   */
  async sendQCBugNotification(
    assigneeEmail: string,
    bugTitle: string,
    severity: string,
    projectName: string,
    dueDate?: Date,
  ): Promise<void> {
    await this.sendEmail({
      to: assigneeEmail,
      subject: `[QC] Lỗi mới được giao: ${bugTitle}`,
      html: `
        <h2>Bạn được giao sửa lỗi QC</h2>
        <p><strong>Dự án:</strong> ${projectName}</p>
        <p><strong>Tiêu đề:</strong> ${bugTitle}</p>
        <p><strong>Mức độ:</strong> <span style="color: ${severity === 'CRITICAL' ? 'red' : severity === 'HIGH' ? 'orange' : 'blue'}">${severity}</span></p>
        ${dueDate ? `<p><strong>Deadline:</strong> ${dueDate.toLocaleDateString('vi-VN')}</p>` : ''}
        <p>Vui lòng xử lý sớm nhất có thể.</p>
        <p>Trân trọng,<br/>BaoTienWeb Team</p>
      `,
    });
  }

  /**
   * Send timeline phase delay notification
   */
  async sendPhaseDelayNotification(
    email: string,
    phaseName: string,
    projectName: string,
    expectedDate: Date,
    actualProgress: number,
  ): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: `[Cảnh báo] Giai đoạn "${phaseName}" bị trễ tiến độ`,
      html: `
        <h2 style="color: red;">⚠️ Cảnh báo trễ tiến độ</h2>
        <p><strong>Dự án:</strong> ${projectName}</p>
        <p><strong>Giai đoạn:</strong> ${phaseName}</p>
        <p><strong>Ngày dự kiến hoàn thành:</strong> ${expectedDate.toLocaleDateString('vi-VN')}</p>
        <p><strong>Tiến độ hiện tại:</strong> ${actualProgress}%</p>
        <p>Vui lòng kiểm tra và điều chỉnh kế hoạch.</p>
        <p>Trân trọng,<br/>BaoTienWeb Team</p>
      `,
    });
  }

  /**
   * Send payment reminder
   */
  async sendPaymentReminder(
    email: string,
    phaseName: string,
    amount: number,
    dueDate: Date,
    contractNo: string,
  ): Promise<void> {
    await this.sendEmail({
      to: email,
      subject: `Nhắc nhở thanh toán: ${phaseName}`,
      html: `
        <h2>Nhắc nhở thanh toán</h2>
        <p><strong>Hợp đồng:</strong> ${contractNo}</p>
        <p><strong>Đợt thanh toán:</strong> ${phaseName}</p>
        <p><strong>Số tiền:</strong> ${amount.toLocaleString('vi-VN')} VND</p>
        <p><strong>Hạn thanh toán:</strong> ${dueDate.toLocaleDateString('vi-VN')}</p>
        <p>Vui lòng thanh toán đúng hạn để tránh ảnh hưởng đến tiến độ dự án.</p>
        <p>Trân trọng,<br/>BaoTienWeb Team</p>
      `,
    });
  }

  /**
   * Send AI daily report
   */
  async sendAIDailyReport(
    emails: string[],
    projectName: string,
    reportDate: Date,
    summary: string,
    reportUrl: string,
  ): Promise<void> {
    await this.sendEmail({
      to: emails,
      subject: `[AI Report] Báo cáo ngày ${reportDate.toLocaleDateString('vi-VN')} - ${projectName}`,
      html: `
        <h2>🤖 Báo cáo hàng ngày từ AI</h2>
        <p><strong>Dự án:</strong> ${projectName}</p>
        <p><strong>Ngày báo cáo:</strong> ${reportDate.toLocaleDateString('vi-VN')}</p>
        <h3>Tóm tắt:</h3>
        <p>${summary}</p>
        <p><a href="${reportUrl}">Xem báo cáo chi tiết</a></p>
        <p>Trân trọng,<br/>BaoTienWeb AI Assistant</p>
      `,
    });
  }

  /**
   * Send password reset email with OTP code
   */
  async sendPasswordResetOTP(
    email: string,
    otpCode: string,
    expiresInMinutes: number = 10,
  ): Promise<boolean> {
    return this.sendEmail({
      to: email,
      subject: '[AppDesignBuild] Mã xác nhận đặt lại mật khẩu',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #2563eb;">🔐 Đặt lại mật khẩu</h2>
          <p>Bạn đã yêu cầu đặt lại mật khẩu cho tài khoản của mình.</p>
          <p>Mã xác nhận của bạn là:</p>
          <div style="background-color: #f3f4f6; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
            <span style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #1f2937;">${otpCode}</span>
          </div>
          <p style="color: #6b7280;">Mã này sẽ hết hạn sau <strong>${expiresInMinutes} phút</strong>.</p>
          <p style="color: #6b7280;">Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.</p>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #9ca3af; font-size: 12px;">AppDesignBuild - Nền tảng thiết kế & xây dựng</p>
        </div>
      `,
    });
  }

  /**
   * Send password reset confirmation
   */
  async sendPasswordResetConfirmation(email: string): Promise<boolean> {
    return this.sendEmail({
      to: email,
      subject: '[AppDesignBuild] Mật khẩu đã được thay đổi',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #16a34a;">✅ Mật khẩu đã được cập nhật</h2>
          <p>Mật khẩu tài khoản của bạn đã được thay đổi thành công.</p>
          <p>Nếu bạn không thực hiện thay đổi này, vui lòng liên hệ ngay với bộ phận hỗ trợ.</p>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #9ca3af; font-size: 12px;">AppDesignBuild - Nền tảng thiết kế & xây dựng</p>
        </div>
      `,
    });
  }

  /**
   * Send registration OTP for 2FA
   */
  async sendRegistrationOTP(
    email: string,
    otpCode: string,
    expiresInMinutes: number = 10,
  ): Promise<boolean> {
    return this.sendEmail({
      to: email,
      subject: '[AppDesignBuild] Mã xác nhận đăng ký tài khoản',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #2563eb;">📧 Xác nhận đăng ký tài khoản</h2>
          <p>Chào mừng bạn đến với AppDesignBuild!</p>
          <p>Để hoàn tất đăng ký, vui lòng nhập mã xác nhận dưới đây:</p>
          <div style="background-color: #f3f4f6; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
            <span style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #1f2937;">${otpCode}</span>
          </div>
          <p style="color: #6b7280;">Mã này sẽ hết hạn sau <strong>${expiresInMinutes} phút</strong>.</p>
          <p style="color: #6b7280;">Nếu bạn không yêu cầu đăng ký, vui lòng bỏ qua email này.</p>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #9ca3af; font-size: 12px;">AppDesignBuild - Nền tảng thiết kế & xây dựng</p>
        </div>
      `,
    });
  }

  /**
   * Send login OTP for 2FA authentication
   */
  async sendLoginOTP(
    email: string,
    otpCode: string,
    expiresInMinutes: number = 5,
  ): Promise<boolean> {
    return this.sendEmail({
      to: email,
      subject: '[AppDesignBuild] Mã xác nhận đăng nhập',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #7c3aed;">🔐 Xác nhận đăng nhập</h2>
          <p>Bạn vừa yêu cầu đăng nhập vào tài khoản AppDesignBuild.</p>
          <p>Mã xác nhận của bạn là:</p>
          <div style="background-color: #f3f4f6; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
            <span style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #1f2937;">${otpCode}</span>
          </div>
          <p style="color: #6b7280;">Mã này sẽ hết hạn sau <strong>${expiresInMinutes} phút</strong>.</p>
          <p style="color: #dc2626; font-size: 14px;">⚠️ Nếu bạn không đăng nhập, có thể ai đó đang cố truy cập tài khoản của bạn. Vui lòng đổi mật khẩu ngay.</p>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #9ca3af; font-size: 12px;">AppDesignBuild - Nền tảng thiết kế & xây dựng</p>
        </div>
      `,
    });
  }

  /**
   * Send welcome email after successful registration
   */
  async sendRegistrationSuccess(email: string, name: string): Promise<boolean> {
    return this.sendEmail({
      to: email,
      subject: '[AppDesignBuild] Chào mừng bạn!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #16a34a;">🎉 Chào mừng ${name || 'bạn'}!</h2>
          <p>Tài khoản của bạn đã được tạo thành công.</p>
          <p>Bạn có thể bắt đầu sử dụng các tính năng của AppDesignBuild ngay bây giờ:</p>
          <ul style="color: #374151; line-height: 1.8;">
            <li>Quản lý dự án xây dựng</li>
            <li>Theo dõi tiến độ công trình</li>
            <li>Trao đổi với đội ngũ thi công</li>
            <li>Xem báo giá và hợp đồng</li>
          </ul>
          <a href="${this.configService.get('APP_URL') || 'https://appdesignbuild.com'}" 
             style="display: inline-block; background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 16px;">
            Bắt đầu sử dụng
          </a>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
          <p style="color: #9ca3af; font-size: 12px;">AppDesignBuild - Nền tảng thiết kế & xây dựng</p>
        </div>
      `,
    });
  }
}
