import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import OpenAI from 'openai';
import * as os from 'os';
import * as path from 'path';
import {
    TranscribeAudioDto,
    TranscribeResponseDto,
    VoiceSearchDto,
    VoiceSearchResponseDto,
} from './dto';

@Injectable()
export class SpeechService {
  private readonly logger = new Logger(SpeechService.name);
  private openai: OpenAI | null = null;

  constructor(private configService: ConfigService) {
    const apiKey = this.configService.get<string>('OPENAI_API_KEY');
    if (!apiKey) {
      this.logger.warn(
        '⚠️ OPENAI_API_KEY not configured - Speech features disabled',
      );
    } else {
      this.openai = new OpenAI({ apiKey });
      this.logger.log('✅ Speech service initialized with OpenAI Whisper');
    }
  }

  private ensureAIConfigured() {
    if (!this.openai) {
      throw new BadRequestException(
        'Speech service not configured. Please set OPENAI_API_KEY.',
      );
    }
  }

  /**
   * Transcribe audio to text using OpenAI Whisper
   */
  async transcribeAudio(
    dto: TranscribeAudioDto,
  ): Promise<TranscribeResponseDto> {
    this.ensureAIConfigured();
    const startTime = Date.now();

    try {
      let audioFilePath: string;
      let shouldCleanup = false;

      // Handle base64 audio
      if (dto.audioBase64) {
        audioFilePath = await this.saveBase64ToFile(
          dto.audioBase64,
          dto.mimeType || 'audio/wav',
        );
        shouldCleanup = true;
      } else if (dto.audioUrl) {
        audioFilePath = await this.downloadAudioFile(dto.audioUrl);
        shouldCleanup = true;
      } else {
        throw new BadRequestException(
          'Either audioBase64 or audioUrl must be provided',
        );
      }

      // Transcribe with Whisper
      const transcription = await this.openai!.audio.transcriptions.create({
        file: fs.createReadStream(audioFilePath),
        model: 'whisper-1',
        language: dto.language || 'vi',
        response_format: 'verbose_json',
      });

      // Cleanup temp file
      if (shouldCleanup) {
        try {
          fs.unlinkSync(audioFilePath);
        } catch (e) {
          this.logger.warn(`Failed to cleanup temp file: ${audioFilePath}`);
        }
      }

      const processingTimeMs = Date.now() - startTime;

      this.logger.log(
        `✅ Transcribed audio in ${processingTimeMs}ms: "${transcription.text?.substring(0, 50)}..."`,
      );

      return {
        text: transcription.text || '',
        confidence: 0.95, // Whisper doesn't return confidence, using high default
        detectedLanguage: transcription.language,
        processingTimeMs,
      };
    } catch (error) {
      this.logger.error('Failed to transcribe audio:', error);
      throw new BadRequestException(
        `Transcription failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
    }
  }

  /**
   * Voice search: transcribe audio and enhance with AI
   */
  async voiceSearch(dto: VoiceSearchDto): Promise<VoiceSearchResponseDto> {
    this.ensureAIConfigured();
    const startTime = Date.now();

    try {
      // Step 1: Transcribe audio
      const transcription = await this.transcribeAudio({
        audioBase64: dto.audioBase64,
        audioUrl: dto.audioUrl,
        mimeType: dto.mimeType,
        language: dto.language,
      });

      if (!transcription.text || transcription.text.trim() === '') {
        return {
          query: '',
          confidence: 0,
          suggestions: [],
          intent: 'empty',
          category: dto.category || 'all',
          processingTimeMs: Date.now() - startTime,
        };
      }

      // Step 2: Enhance with AI for search optimization
      const enhancedSearch = await this.enhanceSearchQuery(
        transcription.text,
        dto.category,
      );

      const processingTimeMs = Date.now() - startTime;

      return {
        query: transcription.text,
        confidence: transcription.confidence || 0.95,
        suggestions: enhancedSearch.suggestions,
        intent: enhancedSearch.intent,
        category: enhancedSearch.category,
        processingTimeMs,
      };
    } catch (error) {
      this.logger.error('Voice search failed:', error);
      throw new BadRequestException(
        `Voice search failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
    }
  }

  /**
   * Enhance search query with AI
   */
  private async enhanceSearchQuery(
    query: string,
    category?: string,
  ): Promise<{
    suggestions: string[];
    intent: string;
    category: string;
  }> {
    try {
      const systemPrompt = `Bạn là AI phân tích tìm kiếm cho ứng dụng xây dựng. Phân tích câu tìm kiếm bằng giọng nói và trả về JSON:
{
  "intent": "mô tả ngắn ý định tìm kiếm",
  "category": "villa/design/construction/material/worker/all",
  "suggestions": ["gợi ý tìm kiếm 1", "gợi ý 2", "gợi ý 3"]
}
Chỉ trả về JSON, không có text khác.`;

      const userPrompt = `Câu tìm kiếm bằng giọng nói: "${query}"${category ? `\nCategory hint: ${category}` : ''}`;

      const completion = await this.openai!.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        max_tokens: 200,
        temperature: 0.3,
      });

      const responseText = completion.choices[0]?.message?.content || '{}';

      // Parse JSON response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          intent: parsed.intent || 'general_search',
          category: parsed.category || category || 'all',
          suggestions: parsed.suggestions || [
            `${query} giá rẻ`,
            `${query} chất lượng cao`,
            `${query} uy tín`,
          ],
        };
      }

      return {
        intent: 'general_search',
        category: category || 'all',
        suggestions: [query],
      };
    } catch (error) {
      this.logger.warn('AI enhancement failed, using basic response:', error);
      return {
        intent: 'general_search',
        category: category || 'all',
        suggestions: [query],
      };
    }
  }

  /**
   * Save base64 audio to temp file
   */
  private async saveBase64ToFile(
    base64Data: string,
    mimeType: string,
  ): Promise<string> {
    const extension = this.getExtensionFromMime(mimeType);
    const tempPath = path.join(os.tmpdir(), `voice_${Date.now()}.${extension}`);

    // Remove data URL prefix if present
    const base64Clean = base64Data.replace(/^data:audio\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Clean, 'base64');

    fs.writeFileSync(tempPath, buffer);
    return tempPath;
  }

  /**
   * Download audio file from URL
   */
  private async downloadAudioFile(url: string): Promise<string> {
    const response = await fetch(url);
    if (!response.ok) {
      throw new BadRequestException(`Failed to download audio from URL`);
    }

    const contentType = response.headers.get('content-type') || 'audio/wav';
    const extension = this.getExtensionFromMime(contentType);
    const tempPath = path.join(os.tmpdir(), `voice_${Date.now()}.${extension}`);

    const buffer = Buffer.from(await response.arrayBuffer());
    fs.writeFileSync(tempPath, buffer);

    return tempPath;
  }

  /**
   * Get file extension from mime type
   */
  private getExtensionFromMime(mimeType: string): string {
    const mimeMap: Record<string, string> = {
      'audio/wav': 'wav',
      'audio/wave': 'wav',
      'audio/x-wav': 'wav',
      'audio/mp3': 'mp3',
      'audio/mpeg': 'mp3',
      'audio/m4a': 'm4a',
      'audio/mp4': 'm4a',
      'audio/webm': 'webm',
      'audio/ogg': 'ogg',
    };
    return mimeMap[mimeType] || 'wav';
  }

  /**
   * Get supported languages
   */
  getSupportedLanguages(): { code: string; name: string }[] {
    return [
      { code: 'vi', name: 'Tiếng Việt' },
      { code: 'en', name: 'English' },
      { code: 'zh', name: '中文' },
      { code: 'ja', name: '日本語' },
      { code: 'ko', name: '한국어' },
    ];
  }
}
