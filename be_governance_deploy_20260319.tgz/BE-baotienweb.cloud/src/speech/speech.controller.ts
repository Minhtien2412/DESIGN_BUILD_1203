import {
    BadRequestException,
    Body,
    Controller,
    Get,
    Post,
    UploadedFile,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
    ApiBearerAuth,
    ApiBody,
    ApiConsumes,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    TranscribeAudioDto,
    TranscribeResponseDto,
    VoiceSearchDto,
    VoiceSearchResponseDto,
} from './dto';
import { SpeechService } from './speech.service';

// Define Multer file interface to avoid Express type issues
interface MulterFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}

@ApiTags('Speech & Voice Search')
@Controller({ path: 'speech', version: '1' })
export class SpeechController {
  constructor(private readonly speechService: SpeechService) {}

  @Post('transcribe')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Chuyển đổi giọng nói thành văn bản (Speech-to-Text)',
    description:
      'Sử dụng OpenAI Whisper để transcribe audio. Hỗ trợ base64 hoặc URL.',
  })
  @ApiResponse({ status: 201, type: TranscribeResponseDto })
  async transcribe(
    @Body() dto: TranscribeAudioDto,
  ): Promise<TranscribeResponseDto> {
    return this.speechService.transcribeAudio(dto);
  }

  @Post('transcribe/upload')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @UseInterceptors(FileInterceptor('audio'))
  @ApiOperation({
    summary: 'Upload file audio để transcribe',
    description: 'Upload file audio trực tiếp (WAV, MP3, M4A, WebM)',
  })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        audio: {
          type: 'string',
          format: 'binary',
        },
        language: {
          type: 'string',
          default: 'vi',
        },
      },
    },
  })
  @ApiResponse({ status: 201, type: TranscribeResponseDto })
  async transcribeUpload(
    @UploadedFile() file: MulterFile,
    @Body('language') language?: string,
  ): Promise<TranscribeResponseDto> {
    if (!file) {
      throw new BadRequestException('No audio file uploaded');
    }

    return this.speechService.transcribeAudio({
      audioBase64: file.buffer.toString('base64'),
      mimeType: file.mimetype,
      language: language || 'vi',
    });
  }

  @Post('voice-search')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Tìm kiếm bằng giọng nói',
    description:
      'Transcribe audio và enhance với AI để tạo search query tối ưu',
  })
  @ApiResponse({ status: 201, type: VoiceSearchResponseDto })
  async voiceSearch(
    @Body() dto: VoiceSearchDto,
  ): Promise<VoiceSearchResponseDto> {
    return this.speechService.voiceSearch(dto);
  }

  @Post('voice-search/upload')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @UseInterceptors(FileInterceptor('audio'))
  @ApiOperation({
    summary: 'Tìm kiếm bằng giọng nói (upload file)',
    description: 'Upload file audio để tìm kiếm',
  })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        audio: {
          type: 'string',
          format: 'binary',
        },
        language: {
          type: 'string',
          default: 'vi',
        },
        category: {
          type: 'string',
        },
      },
    },
  })
  @ApiResponse({ status: 201, type: VoiceSearchResponseDto })
  async voiceSearchUpload(
    @UploadedFile() file: MulterFile,
    @Body('language') language?: string,
    @Body('category') category?: string,
  ): Promise<VoiceSearchResponseDto> {
    if (!file) {
      throw new BadRequestException('No audio file uploaded');
    }

    return this.speechService.voiceSearch({
      audioBase64: file.buffer.toString('base64'),
      mimeType: file.mimetype,
      language: language || 'vi',
      category,
    });
  }

  @Get('languages')
  @ApiOperation({
    summary: 'Lấy danh sách ngôn ngữ hỗ trợ',
  })
  @ApiResponse({
    status: 200,
    schema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          code: { type: 'string' },
          name: { type: 'string' },
        },
      },
    },
  })
  getSupportedLanguages(): { code: string; name: string }[] {
    return this.speechService.getSupportedLanguages();
  }
}
