import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class TranscribeAudioDto {
  @ApiProperty({
    description: 'Base64 encoded audio data',
    required: false,
    example: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAABCxAgACABAAZGF0YQAAAAA=',
  })
  @IsOptional()
  @IsString()
  audioBase64?: string;

  @ApiProperty({
    description: 'Audio file URL (alternative to base64)',
    required: false,
    example: 'https://example.com/audio.wav',
  })
  @IsOptional()
  @IsString()
  audioUrl?: string;

  @ApiProperty({
    description: 'Audio format/mime type',
    default: 'audio/wav',
    enum: ['audio/wav', 'audio/mp3', 'audio/m4a', 'audio/webm', 'audio/ogg'],
  })
  @IsOptional()
  @IsEnum(['audio/wav', 'audio/mp3', 'audio/m4a', 'audio/webm', 'audio/ogg'])
  mimeType?: string = 'audio/wav';

  @ApiProperty({
    description: 'Language code for transcription',
    default: 'vi',
    example: 'vi',
  })
  @IsOptional()
  @IsString()
  language?: string = 'vi';
}

export class TranscribeResponseDto {
  @ApiProperty({ description: 'Transcribed text from audio' })
  text: string;

  @ApiProperty({ description: 'Confidence score (0-1)', required: false })
  confidence?: number;

  @ApiProperty({ description: 'Detected language', required: false })
  detectedLanguage?: string;

  @ApiProperty({ description: 'Processing time in milliseconds' })
  processingTimeMs: number;
}

export class VoiceSearchDto {
  @ApiProperty({
    description: 'Base64 encoded audio data',
    required: false,
  })
  @IsOptional()
  @IsString()
  audioBase64?: string;

  @ApiProperty({
    description: 'Audio file URL',
    required: false,
  })
  @IsOptional()
  @IsString()
  audioUrl?: string;

  @ApiProperty({
    description: 'Audio format/mime type',
    default: 'audio/wav',
  })
  @IsOptional()
  @IsString()
  mimeType?: string = 'audio/wav';

  @ApiProperty({
    description: 'Language code',
    default: 'vi',
  })
  @IsOptional()
  @IsString()
  language?: string = 'vi';

  @ApiProperty({
    description: 'Search category filter',
    required: false,
    example: 'villa',
  })
  @IsOptional()
  @IsString()
  category?: string;
}

export class VoiceSearchResponseDto {
  @ApiProperty({ description: 'Transcribed search query' })
  query: string;

  @ApiProperty({ description: 'Confidence score' })
  confidence: number;

  @ApiProperty({ description: 'AI-enhanced search suggestions' })
  suggestions: string[];

  @ApiProperty({ description: 'Detected search intent' })
  intent: string;

  @ApiProperty({ description: 'Recommended category' })
  category: string;

  @ApiProperty({ description: 'Processing time in milliseconds' })
  processingTimeMs: number;
}
