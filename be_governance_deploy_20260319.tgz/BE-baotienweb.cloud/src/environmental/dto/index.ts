import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsDateString,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';
import {
    EmissionType,
    MonitoringStatus,
    PermitStatus,
    WasteCategory,
} from '../entities';

// ========== EMISSION DTOs ==========

export class CreateEmissionDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty({ enum: EmissionType })
  @IsEnum(EmissionType)
  emissionType: EmissionType;

  @ApiProperty()
  @IsString()
  source: string;

  @ApiProperty()
  @IsNumber()
  measuredValue: number;

  @ApiProperty()
  @IsString()
  unit: string;

  @ApiProperty()
  @IsNumber()
  limitValue: number;

  @ApiProperty()
  @IsNumber()
  measuredBy: number;

  @ApiProperty()
  @IsString()
  location: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  equipment?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

export class QueryEmissionDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: EmissionType })
  @IsOptional()
  @IsEnum(EmissionType)
  emissionType?: EmissionType;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  fromDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  toDate?: string;
}

// ========== MONITORING DTOs ==========

export class CreateMonitoringDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ enum: EmissionType })
  @IsEnum(EmissionType)
  emissionType: EmissionType;

  @ApiProperty()
  @IsString()
  frequency: string;

  @ApiProperty()
  @IsDateString()
  nextDueDate: string;

  @ApiProperty()
  @IsNumber()
  assignedTo: number;

  @ApiProperty()
  @IsString()
  location: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  equipment?: string;
}

export class UpdateMonitoringDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: MonitoringStatus })
  @IsOptional()
  @IsEnum(MonitoringStatus)
  status?: MonitoringStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  nextDueDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  assignedTo?: number;
}

export class CompleteMonitoringDto {
  @ApiProperty()
  @IsNumber()
  completedBy: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

// ========== WASTE DTOs ==========

export class CreateWasteDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty({ enum: WasteCategory })
  @IsEnum(WasteCategory)
  wasteCategory: WasteCategory;

  @ApiProperty()
  @IsString()
  wasteType: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsString()
  unit: string;

  @ApiProperty()
  @IsString()
  source: string;

  @ApiProperty()
  @IsString()
  disposalMethod: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  disposalVendor?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  disposalDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  manifestNumber?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  cost?: number;

  @ApiProperty()
  @IsNumber()
  recordedBy: number;
}

export class QueryWasteDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: WasteCategory })
  @IsOptional()
  @IsEnum(WasteCategory)
  wasteCategory?: WasteCategory;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  fromDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  toDate?: string;
}

// ========== PERMIT DTOs ==========

export class CreatePermitDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  permitType: string;

  @ApiProperty()
  @IsString()
  permitNumber: string;

  @ApiProperty()
  @IsString()
  issuingAuthority: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  applicationDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  issueDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  expiryDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  conditions?: string[];

  @ApiProperty()
  @IsNumber()
  responsiblePerson: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

export class UpdatePermitDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  permitType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  permitNumber?: string;

  @ApiPropertyOptional({ enum: PermitStatus })
  @IsOptional()
  @IsEnum(PermitStatus)
  status?: PermitStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  issueDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  expiryDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  renewalDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  conditions?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

export class QueryPermitDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ enum: PermitStatus })
  @IsOptional()
  @IsEnum(PermitStatus)
  status?: PermitStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  permitType?: string;
}

// ========== INCIDENT DTOs ==========

export class CreateIncidentDto {
  @ApiProperty()
  @IsNumber()
  projectId: number;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiProperty()
  @IsString()
  description: string;

  @ApiProperty({ enum: EmissionType })
  @IsEnum(EmissionType)
  incidentType: EmissionType;

  @ApiProperty({ enum: ['low', 'medium', 'high', 'critical'] })
  @IsString()
  severity: 'low' | 'medium' | 'high' | 'critical';

  @ApiProperty()
  @IsString()
  location: string;

  @ApiProperty()
  @IsDateString()
  incidentDate: string;

  @ApiProperty()
  @IsNumber()
  reportedBy: number;
}

export class UpdateIncidentDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    enum: ['reported', 'investigating', 'resolved', 'closed'],
  })
  @IsOptional()
  @IsString()
  status?: 'reported' | 'investigating' | 'resolved' | 'closed';

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  rootCause?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  correctiveActions?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  preventiveMeasures?: string[];
}
