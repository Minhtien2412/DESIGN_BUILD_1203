// Environmental Module Entities

export enum EmissionType {
  AIR = 'air',
  WATER = 'water',
  NOISE = 'noise',
  DUST = 'dust',
  VIBRATION = 'vibration',
}

export enum MonitoringStatus {
  SCHEDULED = 'scheduled',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  OVERDUE = 'overdue',
}

export enum WasteCategory {
  HAZARDOUS = 'hazardous',
  NON_HAZARDOUS = 'non_hazardous',
  RECYCLABLE = 'recyclable',
  CONSTRUCTION = 'construction',
  ORGANIC = 'organic',
}

export enum PermitStatus {
  DRAFT = 'draft',
  SUBMITTED = 'submitted',
  UNDER_REVIEW = 'under_review',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  EXPIRED = 'expired',
}

export enum ComplianceStatus {
  COMPLIANT = 'compliant',
  NON_COMPLIANT = 'non_compliant',
  WARNING = 'warning',
  PENDING = 'pending',
}

export interface EmissionRecord {
  id: number;
  projectId: number;
  emissionType: EmissionType;
  source: string;
  measuredValue: number;
  unit: string;
  limitValue: number;
  complianceStatus: ComplianceStatus;
  measuredBy: number;
  measuredByName: string;
  measuredAt: Date;
  location: string;
  equipment?: string;
  notes?: string;
  attachments?: string[];
  createdAt: Date;
}

export interface MonitoringSchedule {
  id: number;
  projectId: number;
  title: string;
  description?: string;
  emissionType: EmissionType;
  frequency: string; // daily, weekly, monthly
  status: MonitoringStatus;
  nextDueDate: Date;
  lastCompletedDate?: Date;
  assignedTo: number;
  assignedToName: string;
  location: string;
  equipment?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WasteRecord {
  id: number;
  projectId: number;
  wasteCategory: WasteCategory;
  wasteType: string;
  quantity: number;
  unit: string;
  source: string;
  disposalMethod: string;
  disposalVendor?: string;
  disposalDate?: Date;
  manifestNumber?: string;
  cost?: number;
  recordedBy: number;
  recordedByName: string;
  attachments?: string[];
  createdAt: Date;
}

export interface EnvironmentalPermit {
  id: number;
  projectId: number;
  permitType: string;
  permitNumber: string;
  issuingAuthority: string;
  status: PermitStatus;
  applicationDate?: Date;
  issueDate?: Date;
  expiryDate?: Date;
  renewalDate?: Date;
  conditions?: string[];
  attachments?: string[];
  responsiblePerson: number;
  responsiblePersonName: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface EnvironmentalIncident {
  id: number;
  projectId: number;
  title: string;
  description: string;
  incidentType: EmissionType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'reported' | 'investigating' | 'resolved' | 'closed';
  location: string;
  incidentDate: Date;
  reportedBy: number;
  reportedByName: string;
  rootCause?: string;
  correctiveActions?: string[];
  preventiveMeasures?: string[];
  attachments?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface EnvironmentalDashboard {
  totalEmissions: number;
  emissionsByType: Record<EmissionType, number>;
  complianceRate: number;
  totalWaste: number;
  wasteByCategory: Record<WasteCategory, number>;
  activePermits: number;
  expiringPermits: number;
  overdueMonitoring: number;
  recentIncidents: number;
}
