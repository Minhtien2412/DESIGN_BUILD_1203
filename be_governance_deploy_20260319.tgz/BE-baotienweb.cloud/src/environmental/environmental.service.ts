import { Injectable, NotFoundException } from '@nestjs/common';
import {
    CompleteMonitoringDto,
    CreateEmissionDto,
    CreateIncidentDto,
    CreateMonitoringDto,
    CreatePermitDto,
    CreateWasteDto,
    QueryEmissionDto,
    QueryPermitDto,
    QueryWasteDto,
    UpdateIncidentDto,
    UpdateMonitoringDto,
    UpdatePermitDto,
} from './dto';
import {
    ComplianceStatus,
    EmissionRecord,
    EmissionType,
    EnvironmentalDashboard,
    EnvironmentalIncident,
    EnvironmentalPermit,
    MonitoringSchedule,
    MonitoringStatus,
    PermitStatus,
    WasteCategory,
    WasteRecord,
} from './entities';

@Injectable()
export class EnvironmentalService {
  private emissions: Map<number, EmissionRecord> = new Map();
  private monitorings: Map<number, MonitoringSchedule> = new Map();
  private wastes: Map<number, WasteRecord> = new Map();
  private permits: Map<number, EnvironmentalPermit> = new Map();
  private incidents: Map<number, EnvironmentalIncident> = new Map();

  private emissionIdCounter = 1;
  private monitoringIdCounter = 1;
  private wasteIdCounter = 1;
  private permitIdCounter = 1;
  private incidentIdCounter = 1;

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const now = new Date();
    const users = [
      { id: 1, name: 'KS. Nguyễn Văn Môi Trường' },
      { id: 2, name: 'CN. Trần Thị Giám Sát' },
    ];

    // Sample emissions
    const emissionTypes = Object.values(EmissionType);
    for (let i = 0; i < 20; i++) {
      const user = users[i % users.length];
      const type = emissionTypes[i % emissionTypes.length];
      const measuredValue = Math.random() * 100;
      const limitValue = 80 + Math.random() * 40;

      const emission: EmissionRecord = {
        id: this.emissionIdCounter++,
        projectId: (i % 3) + 1,
        emissionType: type,
        source: `Nguồn phát thải ${i + 1}`,
        measuredValue: Math.round(measuredValue * 10) / 10,
        unit:
          type === EmissionType.NOISE
            ? 'dB'
            : type === EmissionType.DUST
              ? 'mg/m³'
              : 'ppm',
        limitValue: Math.round(limitValue * 10) / 10,
        complianceStatus:
          measuredValue <= limitValue
            ? ComplianceStatus.COMPLIANT
            : ComplianceStatus.NON_COMPLIANT,
        measuredBy: user.id,
        measuredByName: user.name,
        measuredAt: new Date(now.getTime() - i * 24 * 60 * 60 * 1000),
        location: `Khu vực ${String.fromCharCode(65 + (i % 5))}`,
        equipment: `Thiết bị đo ${type}`,
        createdAt: new Date(),
      };
      this.emissions.set(emission.id, emission);
    }

    // Sample monitoring schedules
    for (let i = 0; i < 10; i++) {
      const user = users[i % users.length];
      const monitoring: MonitoringSchedule = {
        id: this.monitoringIdCounter++,
        projectId: (i % 3) + 1,
        title: `Giám sát ${emissionTypes[i % emissionTypes.length]} định kỳ`,
        description: `Lịch giám sát môi trường định kỳ`,
        emissionType: emissionTypes[i % emissionTypes.length],
        frequency: ['daily', 'weekly', 'monthly'][i % 3],
        status: Object.values(MonitoringStatus)[i % 4],
        nextDueDate: new Date(
          now.getTime() + (i - 5) * 7 * 24 * 60 * 60 * 1000,
        ),
        lastCompletedDate:
          i > 3 ? new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000) : undefined,
        assignedTo: user.id,
        assignedToName: user.name,
        location: `Khu vực ${String.fromCharCode(65 + (i % 5))}`,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.monitorings.set(monitoring.id, monitoring);
    }

    // Sample waste records
    const wasteCategories = Object.values(WasteCategory);
    const wasteTypes = [
      'Bê tông phế thải',
      'Sắt thép phế liệu',
      'Gỗ phế thải',
      'Nhựa phế thải',
      'Dầu thải',
    ];
    for (let i = 0; i < 15; i++) {
      const user = users[i % users.length];
      const waste: WasteRecord = {
        id: this.wasteIdCounter++,
        projectId: (i % 3) + 1,
        wasteCategory: wasteCategories[i % wasteCategories.length],
        wasteType: wasteTypes[i % wasteTypes.length],
        quantity: 100 + Math.floor(Math.random() * 900),
        unit: 'kg',
        source: `Công trình tầng ${(i % 5) + 1}`,
        disposalMethod: ['Thu gom tái chế', 'Xử lý chôn lấp', 'Đốt tiêu hủy'][
          i % 3
        ],
        disposalVendor: `Công ty TNHH Môi Trường ${i + 1}`,
        disposalDate:
          i < 10
            ? new Date(now.getTime() - i * 3 * 24 * 60 * 60 * 1000)
            : undefined,
        manifestNumber: `MT-${now.getFullYear()}-${String(i + 1).padStart(4, '0')}`,
        cost: 500000 + Math.floor(Math.random() * 2000000),
        recordedBy: user.id,
        recordedByName: user.name,
        createdAt: new Date(),
      };
      this.wastes.set(waste.id, waste);
    }

    // Sample permits
    const permitTypes = [
      'Giấy phép xả thải',
      'Giấy phép khai thác nước',
      'Đánh giá tác động môi trường',
      'Giấy phép vận chuyển chất thải nguy hại',
    ];
    for (let i = 0; i < 6; i++) {
      const user = users[i % users.length];
      const permit: EnvironmentalPermit = {
        id: this.permitIdCounter++,
        projectId: (i % 3) + 1,
        permitType: permitTypes[i % permitTypes.length],
        permitNumber: `GP-MT-${now.getFullYear()}-${String(i + 1).padStart(3, '0')}`,
        issuingAuthority: 'Sở Tài nguyên và Môi trường',
        status: Object.values(PermitStatus)[i % 6],
        applicationDate: new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000),
        issueDate:
          i < 4
            ? new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000)
            : undefined,
        expiryDate:
          i < 4
            ? new Date(now.getTime() + (365 - i * 30) * 24 * 60 * 60 * 1000)
            : undefined,
        conditions: [
          'Tuân thủ QCVN',
          'Báo cáo định kỳ hàng quý',
          'Lắp đặt hệ thống quan trắc tự động',
        ],
        responsiblePerson: user.id,
        responsiblePersonName: user.name,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.permits.set(permit.id, permit);
    }

    // Sample incidents
    for (let i = 0; i < 4; i++) {
      const user = users[i % users.length];
      const incident: EnvironmentalIncident = {
        id: this.incidentIdCounter++,
        projectId: (i % 3) + 1,
        title: `Sự cố môi trường ${i + 1}`,
        description: `Mô tả chi tiết sự cố môi trường`,
        incidentType: emissionTypes[i % emissionTypes.length],
        severity: (['low', 'medium', 'high', 'critical'] as const)[i % 4],
        status: (['reported', 'investigating', 'resolved', 'closed'] as const)[
          i % 4
        ],
        location: `Khu vực ${String.fromCharCode(65 + i)}`,
        incidentDate: new Date(now.getTime() - i * 7 * 24 * 60 * 60 * 1000),
        reportedBy: user.id,
        reportedByName: user.name,
        rootCause: i > 0 ? 'Hỏng thiết bị xử lý' : undefined,
        correctiveActions:
          i > 0 ? ['Sửa chữa thiết bị', 'Tăng cường giám sát'] : undefined,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.incidents.set(incident.id, incident);
    }
  }

  // ========== DASHBOARD ==========

  async getDashboard(projectId?: number): Promise<EnvironmentalDashboard> {
    let emissions = Array.from(this.emissions.values());
    let wastes = Array.from(this.wastes.values());
    let permits = Array.from(this.permits.values());
    let monitorings = Array.from(this.monitorings.values());
    let incidents = Array.from(this.incidents.values());

    if (projectId) {
      emissions = emissions.filter((e) => e.projectId === projectId);
      wastes = wastes.filter((w) => w.projectId === projectId);
      permits = permits.filter((p) => p.projectId === projectId);
      monitorings = monitorings.filter((m) => m.projectId === projectId);
      incidents = incidents.filter((i) => i.projectId === projectId);
    }

    const now = new Date();
    const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const emissionsByType = Object.values(EmissionType).reduce(
      (acc, type) => {
        acc[type] = emissions.filter((e) => e.emissionType === type).length;
        return acc;
      },
      {} as Record<EmissionType, number>,
    );

    const wasteByCategory = Object.values(WasteCategory).reduce(
      (acc, cat) => {
        acc[cat] = wastes
          .filter((w) => w.wasteCategory === cat)
          .reduce((sum, w) => sum + w.quantity, 0);
        return acc;
      },
      {} as Record<WasteCategory, number>,
    );

    const compliantCount = emissions.filter(
      (e) => e.complianceStatus === ComplianceStatus.COMPLIANT,
    ).length;
    const complianceRate =
      emissions.length > 0
        ? Math.round((compliantCount / emissions.length) * 100)
        : 100;

    return {
      totalEmissions: emissions.length,
      emissionsByType,
      complianceRate,
      totalWaste: wastes.reduce((sum, w) => sum + w.quantity, 0),
      wasteByCategory,
      activePermits: permits.filter((p) => p.status === PermitStatus.APPROVED)
        .length,
      expiringPermits: permits.filter(
        (p) =>
          p.expiryDate && p.expiryDate <= thirtyDaysLater && p.expiryDate > now,
      ).length,
      overdueMonitoring: monitorings.filter(
        (m) =>
          m.status === MonitoringStatus.OVERDUE ||
          (m.nextDueDate < now && m.status !== MonitoringStatus.COMPLETED),
      ).length,
      recentIncidents: incidents.filter((i) => i.status !== 'closed').length,
    };
  }

  // ========== EMISSIONS ==========

  async getEmissions(query: QueryEmissionDto): Promise<EmissionRecord[]> {
    let emissions = Array.from(this.emissions.values());

    if (query.projectId)
      emissions = emissions.filter((e) => e.projectId === query.projectId);
    if (query.emissionType)
      emissions = emissions.filter(
        (e) => e.emissionType === query.emissionType,
      );
    if (query.fromDate) {
      const from = new Date(query.fromDate);
      emissions = emissions.filter((e) => e.measuredAt >= from);
    }
    if (query.toDate) {
      const to = new Date(query.toDate);
      emissions = emissions.filter((e) => e.measuredAt <= to);
    }

    return emissions.sort(
      (a, b) => b.measuredAt.getTime() - a.measuredAt.getTime(),
    );
  }

  async createEmission(dto: CreateEmissionDto): Promise<EmissionRecord> {
    const emission: EmissionRecord = {
      id: this.emissionIdCounter++,
      ...dto,
      complianceStatus:
        dto.measuredValue <= dto.limitValue
          ? ComplianceStatus.COMPLIANT
          : ComplianceStatus.NON_COMPLIANT,
      measuredByName: `User ${dto.measuredBy}`,
      measuredAt: new Date(),
      createdAt: new Date(),
    };
    this.emissions.set(emission.id, emission);
    return emission;
  }

  // ========== MONITORING ==========

  async getMonitorings(
    projectId?: number,
    status?: MonitoringStatus,
  ): Promise<MonitoringSchedule[]> {
    let monitorings = Array.from(this.monitorings.values());

    if (projectId)
      monitorings = monitorings.filter((m) => m.projectId === projectId);
    if (status) monitorings = monitorings.filter((m) => m.status === status);

    return monitorings.sort(
      (a, b) => a.nextDueDate.getTime() - b.nextDueDate.getTime(),
    );
  }

  async getMonitoringById(id: number): Promise<MonitoringSchedule> {
    const monitoring = this.monitorings.get(id);
    if (!monitoring) throw new NotFoundException(`Monitoring ${id} not found`);
    return monitoring;
  }

  async createMonitoring(
    dto: CreateMonitoringDto,
  ): Promise<MonitoringSchedule> {
    const monitoring: MonitoringSchedule = {
      id: this.monitoringIdCounter++,
      ...dto,
      status: MonitoringStatus.SCHEDULED,
      nextDueDate: new Date(dto.nextDueDate),
      assignedToName: `User ${dto.assignedTo}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.monitorings.set(monitoring.id, monitoring);
    return monitoring;
  }

  async updateMonitoring(
    id: number,
    dto: UpdateMonitoringDto,
  ): Promise<MonitoringSchedule> {
    const monitoring = await this.getMonitoringById(id);

    if (dto.title) monitoring.title = dto.title;
    if (dto.description) monitoring.description = dto.description;
    if (dto.status) monitoring.status = dto.status;
    if (dto.nextDueDate) monitoring.nextDueDate = new Date(dto.nextDueDate);
    if (dto.assignedTo) {
      monitoring.assignedTo = dto.assignedTo;
      monitoring.assignedToName = `User ${dto.assignedTo}`;
    }

    monitoring.updatedAt = new Date();
    this.monitorings.set(id, monitoring);
    return monitoring;
  }

  async completeMonitoring(
    id: number,
    dto: CompleteMonitoringDto,
  ): Promise<MonitoringSchedule> {
    const monitoring = await this.getMonitoringById(id);

    monitoring.status = MonitoringStatus.COMPLETED;
    monitoring.lastCompletedDate = new Date();
    monitoring.updatedAt = new Date();

    // Schedule next monitoring based on frequency
    const days =
      monitoring.frequency === 'daily'
        ? 1
        : monitoring.frequency === 'weekly'
          ? 7
          : 30;
    monitoring.nextDueDate = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    monitoring.status = MonitoringStatus.SCHEDULED;

    this.monitorings.set(id, monitoring);
    return monitoring;
  }

  // ========== WASTE ==========

  async getWastes(query: QueryWasteDto): Promise<WasteRecord[]> {
    let wastes = Array.from(this.wastes.values());

    if (query.projectId)
      wastes = wastes.filter((w) => w.projectId === query.projectId);
    if (query.wasteCategory)
      wastes = wastes.filter((w) => w.wasteCategory === query.wasteCategory);
    if (query.fromDate) {
      const from = new Date(query.fromDate);
      wastes = wastes.filter((w) => w.createdAt >= from);
    }
    if (query.toDate) {
      const to = new Date(query.toDate);
      wastes = wastes.filter((w) => w.createdAt <= to);
    }

    return wastes.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createWaste(dto: CreateWasteDto): Promise<WasteRecord> {
    const waste: WasteRecord = {
      id: this.wasteIdCounter++,
      ...dto,
      disposalDate: dto.disposalDate ? new Date(dto.disposalDate) : undefined,
      recordedByName: `User ${dto.recordedBy}`,
      createdAt: new Date(),
    };
    this.wastes.set(waste.id, waste);
    return waste;
  }

  // ========== PERMITS ==========

  async getPermits(query: QueryPermitDto): Promise<EnvironmentalPermit[]> {
    let permits = Array.from(this.permits.values());

    if (query.projectId)
      permits = permits.filter((p) => p.projectId === query.projectId);
    if (query.status)
      permits = permits.filter((p) => p.status === query.status);
    if (query.permitType)
      permits = permits.filter((p) => p.permitType.includes(query.permitType!));

    return permits.sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
  }

  async getPermitById(id: number): Promise<EnvironmentalPermit> {
    const permit = this.permits.get(id);
    if (!permit) throw new NotFoundException(`Permit ${id} not found`);
    return permit;
  }

  async createPermit(dto: CreatePermitDto): Promise<EnvironmentalPermit> {
    const permit: EnvironmentalPermit = {
      id: this.permitIdCounter++,
      ...dto,
      status: PermitStatus.DRAFT,
      applicationDate: dto.applicationDate
        ? new Date(dto.applicationDate)
        : undefined,
      issueDate: dto.issueDate ? new Date(dto.issueDate) : undefined,
      expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : undefined,
      responsiblePersonName: `User ${dto.responsiblePerson}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.permits.set(permit.id, permit);
    return permit;
  }

  async updatePermit(
    id: number,
    dto: UpdatePermitDto,
  ): Promise<EnvironmentalPermit> {
    const permit = await this.getPermitById(id);

    if (dto.permitType) permit.permitType = dto.permitType;
    if (dto.permitNumber) permit.permitNumber = dto.permitNumber;
    if (dto.status) permit.status = dto.status;
    if (dto.issueDate) permit.issueDate = new Date(dto.issueDate);
    if (dto.expiryDate) permit.expiryDate = new Date(dto.expiryDate);
    if (dto.renewalDate) permit.renewalDate = new Date(dto.renewalDate);
    if (dto.conditions) permit.conditions = dto.conditions;
    if (dto.notes) permit.notes = dto.notes;

    permit.updatedAt = new Date();
    this.permits.set(id, permit);
    return permit;
  }

  // ========== INCIDENTS ==========

  async getIncidents(projectId?: number): Promise<EnvironmentalIncident[]> {
    let incidents = Array.from(this.incidents.values());

    if (projectId)
      incidents = incidents.filter((i) => i.projectId === projectId);

    return incidents.sort(
      (a, b) => b.incidentDate.getTime() - a.incidentDate.getTime(),
    );
  }

  async getIncidentById(id: number): Promise<EnvironmentalIncident> {
    const incident = this.incidents.get(id);
    if (!incident) throw new NotFoundException(`Incident ${id} not found`);
    return incident;
  }

  async createIncident(dto: CreateIncidentDto): Promise<EnvironmentalIncident> {
    const incident: EnvironmentalIncident = {
      id: this.incidentIdCounter++,
      ...dto,
      status: 'reported',
      incidentDate: new Date(dto.incidentDate),
      reportedByName: `User ${dto.reportedBy}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.incidents.set(incident.id, incident);
    return incident;
  }

  async updateIncident(
    id: number,
    dto: UpdateIncidentDto,
  ): Promise<EnvironmentalIncident> {
    const incident = await this.getIncidentById(id);

    if (dto.title) incident.title = dto.title;
    if (dto.description) incident.description = dto.description;
    if (dto.status) incident.status = dto.status;
    if (dto.rootCause) incident.rootCause = dto.rootCause;
    if (dto.correctiveActions)
      incident.correctiveActions = dto.correctiveActions;
    if (dto.preventiveMeasures)
      incident.preventiveMeasures = dto.preventiveMeasures;

    incident.updatedAt = new Date();
    this.incidents.set(id, incident);
    return incident;
  }
}
