import {
    Body,
    Controller,
    Get,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
} from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import {
    CompleteMonitoringDto,
    CreateEmissionDto,
    CreateIncidentDto,
    CreateMonitoringDto,
    CreatePermitDto,
    CreateWasteDto,
    QueryEmissionDto,
    QueryPermitDto,
    QueryWasteDto,
    UpdateIncidentDto,
    UpdateMonitoringDto,
    UpdatePermitDto,
} from './dto';
import {
    EmissionType,
    MonitoringStatus,
    PermitStatus,
    WasteCategory,
} from './entities';
import { EnvironmentalService } from './environmental.service';

@ApiTags('Environmental')
@Controller('environmental')
export class EnvironmentalController {
  constructor(private readonly environmentalService: EnvironmentalService) {}

  // ========== DASHBOARD ==========

  @Get('dashboard')
  @ApiOperation({ summary: 'Get environmental dashboard metrics' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Dashboard metrics retrieved',
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getDashboard(@Query('projectId') projectId?: string) {
    return this.environmentalService.getDashboard(
      projectId ? parseInt(projectId) : undefined,
    );
  }

  // ========== EMISSIONS ==========

  @Get('emissions')
  @ApiOperation({ summary: 'Get emission records' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Emissions retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'emissionType', required: false, enum: EmissionType })
  @ApiQuery({ name: 'fromDate', required: false, type: String })
  @ApiQuery({ name: 'toDate', required: false, type: String })
  async getEmissions(@Query() query: QueryEmissionDto) {
    return this.environmentalService.getEmissions(query);
  }

  @Post('emissions')
  @ApiOperation({ summary: 'Record a new emission measurement' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Emission recorded' })
  async createEmission(@Body() dto: CreateEmissionDto) {
    return this.environmentalService.createEmission(dto);
  }

  // ========== MONITORING ==========

  @Get('monitoring')
  @ApiOperation({ summary: 'Get monitoring schedules' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Monitoring schedules retrieved',
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: MonitoringStatus })
  async getMonitorings(
    @Query('projectId') projectId?: string,
    @Query('status') status?: MonitoringStatus,
  ) {
    return this.environmentalService.getMonitorings(
      projectId ? parseInt(projectId) : undefined,
      status,
    );
  }

  @Get('monitoring/:id')
  @ApiOperation({ summary: 'Get monitoring schedule by ID' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Monitoring schedule retrieved',
  })
  async getMonitoringById(@Param('id', ParseIntPipe) id: number) {
    return this.environmentalService.getMonitoringById(id);
  }

  @Post('monitoring')
  @ApiOperation({ summary: 'Create a monitoring schedule' })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Monitoring schedule created',
  })
  async createMonitoring(@Body() dto: CreateMonitoringDto) {
    return this.environmentalService.createMonitoring(dto);
  }

  @Put('monitoring/:id')
  @ApiOperation({ summary: 'Update a monitoring schedule' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Monitoring schedule updated',
  })
  async updateMonitoring(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateMonitoringDto,
  ) {
    return this.environmentalService.updateMonitoring(id, dto);
  }

  @Patch('monitoring/:id/complete')
  @ApiOperation({ summary: 'Mark monitoring as complete' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Monitoring marked complete',
  })
  async completeMonitoring(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CompleteMonitoringDto,
  ) {
    return this.environmentalService.completeMonitoring(id, dto);
  }

  // ========== WASTE ==========

  @Get('waste')
  @ApiOperation({ summary: 'Get waste records' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Waste records retrieved',
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'wasteCategory', required: false, enum: WasteCategory })
  @ApiQuery({ name: 'fromDate', required: false, type: String })
  @ApiQuery({ name: 'toDate', required: false, type: String })
  async getWastes(@Query() query: QueryWasteDto) {
    return this.environmentalService.getWastes(query);
  }

  @Post('waste')
  @ApiOperation({ summary: 'Record waste disposal' })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Waste record created',
  })
  async createWaste(@Body() dto: CreateWasteDto) {
    return this.environmentalService.createWaste(dto);
  }

  // ========== PERMITS ==========

  @Get('permits')
  @ApiOperation({ summary: 'Get environmental permits' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Permits retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: PermitStatus })
  @ApiQuery({ name: 'permitType', required: false, type: String })
  async getPermits(@Query() query: QueryPermitDto) {
    return this.environmentalService.getPermits(query);
  }

  @Get('permits/:id')
  @ApiOperation({ summary: 'Get permit by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Permit retrieved' })
  async getPermitById(@Param('id', ParseIntPipe) id: number) {
    return this.environmentalService.getPermitById(id);
  }

  @Post('permits')
  @ApiOperation({ summary: 'Create an environmental permit' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Permit created' })
  async createPermit(@Body() dto: CreatePermitDto) {
    return this.environmentalService.createPermit(dto);
  }

  @Put('permits/:id')
  @ApiOperation({ summary: 'Update an environmental permit' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Permit updated' })
  async updatePermit(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdatePermitDto,
  ) {
    return this.environmentalService.updatePermit(id, dto);
  }

  // ========== INCIDENTS ==========

  @Get('incidents')
  @ApiOperation({ summary: 'Get environmental incidents' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incidents retrieved' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getIncidents(@Query('projectId') projectId?: string) {
    return this.environmentalService.getIncidents(
      projectId ? parseInt(projectId) : undefined,
    );
  }

  @Get('incidents/:id')
  @ApiOperation({ summary: 'Get incident by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incident retrieved' })
  async getIncidentById(@Param('id', ParseIntPipe) id: number) {
    return this.environmentalService.getIncidentById(id);
  }

  @Post('incidents')
  @ApiOperation({ summary: 'Report an environmental incident' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Incident reported' })
  async createIncident(@Body() dto: CreateIncidentDto) {
    return this.environmentalService.createIncident(dto);
  }

  @Put('incidents/:id')
  @ApiOperation({ summary: 'Update an environmental incident' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Incident updated' })
  async updateIncident(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateIncidentDto,
  ) {
    return this.environmentalService.updateIncident(id, dto);
  }

  // ========== HEALTH ==========

  @Get('health')
  @ApiOperation({ summary: 'Environmental module health check' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Service is healthy' })
  async health() {
    return {
      status: 'ok',
      service: 'environmental',
      timestamp: new Date().toISOString(),
    };
  }
}
