import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsOptional,
    IsString,
    Max,
    MaxLength,
    Min,
} from 'class-validator';

/**
 * File context types for permission checking
 */
export enum FileContext {
  PROJECT = 'project',
  CONVERSATION = 'conversation',
  PROFILE = 'profile',
  GENERAL = 'general',
}

/**
 * Request presigned URL for upload
 */
export class PresignedUploadRequestDto {
  @ApiProperty({ description: 'Original filename', example: 'document.pdf' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  filename: string;

  @ApiProperty({
    description: 'Content type (MIME type)',
    example: 'application/pdf',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contentType: string;

  @ApiProperty({ description: 'File size in bytes', example: 1024000 })
  @IsInt()
  @Min(1)
  @Max(500 * 1024 * 1024) // 500MB max
  size: number;

  @ApiPropertyOptional({
    description: 'Optional checksum (SHA256 or MD5)',
    example: 'a1b2c3d4...',
  })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  checksum?: string;

  @ApiPropertyOptional({
    description: 'Checksum algorithm used',
    enum: ['sha256', 'md5'],
  })
  @IsOptional()
  @IsString()
  checksumAlgorithm?: 'sha256' | 'md5';

  @ApiPropertyOptional({
    description: 'Upload context type',
    enum: FileContext,
  })
  @IsOptional()
  @IsEnum(FileContext)
  context?: FileContext;

  @ApiPropertyOptional({
    description: 'Context ID (project ID, conversation ID, etc.)',
  })
  @IsOptional()
  @IsInt()
  contextId?: number;

  @ApiPropertyOptional({
    description: 'Optional folder path',
    example: 'documents/2024',
  })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  folder?: string;
}

/**
 * Presigned URL response
 */
export class PresignedUploadResponseDto {
  @ApiProperty({ description: 'Unique upload ID for tracking' })
  uploadId: string;

  @ApiProperty({ description: 'Presigned URL for PUT upload' })
  uploadUrl: string;

  @ApiProperty({ description: 'URL expiration timestamp' })
  expiresAt: Date;

  @ApiProperty({ description: 'Final file URL after upload completes' })
  fileUrl: string;

  @ApiProperty({ description: 'Required headers for upload' })
  headers: Record<string, string>;
}

/**
 * Complete presigned upload
 */
export class CompletePresignedUploadDto {
  @ApiProperty({ description: 'Upload ID from presign request' })
  @IsString()
  @IsNotEmpty()
  uploadId: string;

  @ApiProperty({
    description: 'Checksum of uploaded file (SHA256 or MD5)',
    example: 'a1b2c3d4...',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(128)
  checksum: string;

  @ApiPropertyOptional({
    description: 'Checksum algorithm used',
    enum: ['sha256', 'md5'],
  })
  @IsOptional()
  @IsString()
  checksumAlgorithm?: 'sha256' | 'md5';

  @ApiPropertyOptional({ description: 'Optional metadata to store with file' })
  @IsOptional()
  metadata?: Record<string, any>;
}

/**
 * Complete upload response
 */
export class CompleteUploadResponseDto {
  @ApiProperty({
    description: 'Legacy File ID (integer) — deprecated, use managedFileId',
  })
  fileId: number;

  @ApiProperty({
    description:
      'Canonical ManagedFile UUID — use this for /api/v1/files endpoints',
  })
  managedFileId: string;

  @ApiProperty({ description: 'Final file URL' })
  url: string;

  @ApiProperty({ description: 'Original filename' })
  filename: string;

  @ApiProperty({ description: 'File size in bytes' })
  size: number;

  @ApiProperty({ description: 'Content type' })
  contentType: string;

  @ApiProperty({ description: 'Checksum verified' })
  checksumVerified: boolean;
}

// =====================================================================
// MULTIPART (CHUNKED) UPLOAD DTOs
// =====================================================================

/**
 * Initiate multipart upload
 */
export class InitiateMultipartUploadDto {
  @ApiProperty({ description: 'Original filename' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  filename: string;

  @ApiProperty({ description: 'Content type', example: 'video/mp4' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contentType: string;

  @ApiProperty({ description: 'Total file size in bytes' })
  @IsInt()
  @Min(1)
  totalSize: number;

  @ApiPropertyOptional({ description: 'Chunk size (5MB-100MB, default 10MB)' })
  @IsOptional()
  @IsInt()
  @Min(5 * 1024 * 1024) // 5MB min
  @Max(100 * 1024 * 1024) // 100MB max
  chunkSize?: number;

  @ApiPropertyOptional({ description: 'Upload context', enum: FileContext })
  @IsOptional()
  @IsEnum(FileContext)
  context?: FileContext;

  @ApiPropertyOptional({ description: 'Context ID' })
  @IsOptional()
  @IsInt()
  contextId?: number;

  @ApiPropertyOptional({ description: 'Folder path' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  folder?: string;
}

/**
 * Multipart upload initiation response
 */
export class InitiateMultipartResponseDto {
  @ApiProperty({ description: 'Multipart upload ID' })
  uploadId: string;

  @ApiProperty({ description: 'S3 multipart upload ID (if using S3)' })
  s3UploadId?: string;

  @ApiProperty({ description: 'Total number of parts' })
  totalParts: number;

  @ApiProperty({ description: 'Chunk size in bytes' })
  chunkSize: number;

  @ApiProperty({ description: 'Upload expires at' })
  expiresAt: Date;

  @ApiProperty({ description: 'Presigned URLs for each part' })
  partUrls: PartUploadInfo[];
}

/**
 * Part upload info
 */
export class PartUploadInfo {
  @ApiProperty({ description: 'Part number (1-based)' })
  partNumber: number;

  @ApiProperty({ description: 'Presigned URL for this part' })
  uploadUrl: string;

  @ApiProperty({ description: 'Start byte offset' })
  startByte: number;

  @ApiProperty({ description: 'End byte offset' })
  endByte: number;

  @ApiProperty({ description: 'Expected part size' })
  size: number;
}

/**
 * Upload single part (for direct upload to BE instead of S3)
 */
export class UploadPartDto {
  @ApiProperty({ description: 'Multipart upload ID' })
  @IsString()
  @IsNotEmpty()
  uploadId: string;

  @ApiProperty({ description: 'Part number (1-based)' })
  @IsInt()
  @Min(1)
  @Max(10000)
  partNumber: number;

  @ApiPropertyOptional({ description: 'Part checksum' })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  checksum?: string;
}

/**
 * Part upload result
 */
export class PartUploadResultDto {
  @ApiProperty({ description: 'Part number' })
  partNumber: number;

  @ApiProperty({ description: 'ETag from storage' })
  etag: string;

  @ApiProperty({ description: 'Part size' })
  size: number;
}

/**
 * Complete multipart upload
 */
export class CompleteMultipartUploadDto {
  @ApiProperty({ description: 'Multipart upload ID' })
  @IsString()
  @IsNotEmpty()
  uploadId: string;

  @ApiProperty({
    description: 'Completed parts info',
    type: [PartUploadResultDto],
  })
  parts: PartUploadResultDto[];

  @ApiPropertyOptional({ description: 'Final file checksum' })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  finalChecksum?: string;

  @ApiPropertyOptional({ description: 'Optional metadata' })
  @IsOptional()
  metadata?: Record<string, any>;
}

/**
 * Abort multipart upload
 */
export class AbortMultipartUploadDto {
  @ApiProperty({ description: 'Multipart upload ID to abort' })
  @IsString()
  @IsNotEmpty()
  uploadId: string;
}

/**
 * Multipart upload status
 */
export class MultipartUploadStatusDto {
  @ApiProperty({ description: 'Upload ID' })
  uploadId: string;

  @ApiProperty({ description: 'Upload status' })
  status: 'pending' | 'in-progress' | 'completed' | 'aborted' | 'expired';

  @ApiProperty({ description: 'Filename' })
  filename: string;

  @ApiProperty({ description: 'Total size' })
  totalSize: number;

  @ApiProperty({ description: 'Uploaded size' })
  uploadedSize: number;

  @ApiProperty({ description: 'Total parts' })
  totalParts: number;

  @ApiProperty({ description: 'Completed parts' })
  completedParts: number[];

  @ApiProperty({ description: 'Progress percentage (0-100)' })
  progress: number;

  @ApiProperty({ description: 'Created at' })
  createdAt: Date;

  @ApiProperty({ description: 'Expires at' })
  expiresAt: Date;
}
