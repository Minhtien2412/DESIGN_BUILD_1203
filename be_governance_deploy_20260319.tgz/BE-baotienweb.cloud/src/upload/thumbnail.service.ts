import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { existsSync } from 'fs';
import * as fs from 'fs/promises';
import * as path from 'path';
import sharp from 'sharp';
import { v4 as uuidv4 } from 'uuid';

export interface ThumbnailOptions {
  width?: number;
  height?: number;
  fit?: 'cover' | 'contain' | 'fill' | 'inside' | 'outside';
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp';
}

export interface ThumbnailResult {
  url: string;
  width: number;
  height: number;
  size: number;
  format: string;
}

export interface VideoThumbnailResult extends ThumbnailResult {
  duration?: number;
  timestamp?: number;
}

export enum ThumbnailSize {
  SMALL = 'small', // 100x100
  MEDIUM = 'medium', // 300x300
  LARGE = 'large', // 600x600
}

const THUMBNAIL_SIZES: Record<
  ThumbnailSize,
  { width: number; height: number }
> = {
  [ThumbnailSize.SMALL]: { width: 100, height: 100 },
  [ThumbnailSize.MEDIUM]: { width: 300, height: 300 },
  [ThumbnailSize.LARGE]: { width: 600, height: 600 },
};

@Injectable()
export class ThumbnailService {
  private readonly logger = new Logger(ThumbnailService.name);
  private readonly thumbnailPath: string;
  private readonly baseUrl: string;

  constructor(private configService: ConfigService) {
    this.thumbnailPath = path.join(process.cwd(), 'uploads', 'thumbnails');
    this.baseUrl = this.configService.get<string>(
      'APP_URL',
      'http://localhost:3000',
    );
    this.ensureDirectory();
  }

  private async ensureDirectory(): Promise<void> {
    if (!existsSync(this.thumbnailPath)) {
      await fs.mkdir(this.thumbnailPath, { recursive: true });
    }
  }

  /**
   * Generate thumbnail from image buffer
   */
  async generateImageThumbnail(
    buffer: Buffer,
    filename: string,
    options: ThumbnailOptions = {},
  ): Promise<ThumbnailResult> {
    const {
      width = 300,
      height = 300,
      fit = 'cover',
      quality = 80,
      format = 'jpeg',
    } = options;

    const thumbnailId = uuidv4();
    const outputFilename = `${thumbnailId}.${format}`;
    const outputPath = path.join(this.thumbnailPath, outputFilename);

    try {
      let sharpInstance = sharp(buffer).resize(width, height, {
        fit,
        position: 'center',
      });

      // Apply format and quality
      switch (format) {
        case 'jpeg':
          sharpInstance = sharpInstance.jpeg({ quality });
          break;
        case 'png':
          sharpInstance = sharpInstance.png({ quality });
          break;
        case 'webp':
          sharpInstance = sharpInstance.webp({ quality });
          break;
      }

      const outputBuffer = await sharpInstance.toBuffer();
      const metadata = await sharp(outputBuffer).metadata();

      await fs.writeFile(outputPath, outputBuffer);

      const url = `uploads/thumbnails/${outputFilename}`;

      this.logger.log(`Generated thumbnail: ${url}`);

      return {
        url,
        width: metadata.width || width,
        height: metadata.height || height,
        size: outputBuffer.length,
        format,
      };
    } catch (error: unknown) {
      this.logger.error(
        `Failed to generate thumbnail: ${(error as Error).message}`,
      );
      throw new BadRequestException('Failed to generate thumbnail');
    }
  }

  /**
   * Generate multiple thumbnail sizes
   */
  async generateMultipleSizes(
    buffer: Buffer,
    filename: string,
    sizes: ThumbnailSize[] = [
      ThumbnailSize.SMALL,
      ThumbnailSize.MEDIUM,
      ThumbnailSize.LARGE,
    ],
  ): Promise<Record<ThumbnailSize, ThumbnailResult>> {
    const results: Partial<Record<ThumbnailSize, ThumbnailResult>> = {};

    for (const size of sizes) {
      const dimensions = THUMBNAIL_SIZES[size];
      results[size] = await this.generateImageThumbnail(buffer, filename, {
        width: dimensions.width,
        height: dimensions.height,
      });
    }

    return results as Record<ThumbnailSize, ThumbnailResult>;
  }

  /**
   * Generate thumbnail from file path
   */
  async generateFromFile(
    filePath: string,
    options: ThumbnailOptions = {},
  ): Promise<ThumbnailResult> {
    if (!existsSync(filePath)) {
      throw new NotFoundException('Source file not found');
    }

    const buffer = await fs.readFile(filePath);
    const filename = path.basename(filePath);
    return this.generateImageThumbnail(buffer, filename, options);
  }

  /**
   * Generate video poster/thumbnail (placeholder - requires FFmpeg)
   * In production, use fluent-ffmpeg or spawn FFmpeg process
   */
  async generateVideoThumbnail(
    videoPath: string,
    timestamp: number = 1,
    options: ThumbnailOptions = {},
  ): Promise<VideoThumbnailResult> {
    // Placeholder - requires FFmpeg installation
    // In production:
    // 1. Install ffmpeg: npm install fluent-ffmpeg @types/fluent-ffmpeg
    // 2. Ensure FFmpeg binary is in PATH

    this.logger.warn('Video thumbnail generation requires FFmpeg installation');

    // For now, return a placeholder
    const placeholderPath = path.join(
      this.thumbnailPath,
      'video-placeholder.png',
    );

    // Create a simple placeholder if it doesn't exist
    if (!existsSync(placeholderPath)) {
      const placeholder = await sharp({
        create: {
          width: options.width || 300,
          height: options.height || 169,
          channels: 4,
          background: { r: 50, g: 50, b: 50, alpha: 1 },
        },
      })
        .png()
        .toBuffer();

      await fs.writeFile(placeholderPath, placeholder);
    }

    return {
      url: 'uploads/thumbnails/video-placeholder.png',
      width: options.width || 300,
      height: options.height || 169,
      size: 0,
      format: 'png',
      timestamp,
    };
  }

  /**
   * Generate PDF first page thumbnail (placeholder - requires pdf-lib or poppler)
   */
  async generatePdfThumbnail(
    pdfPath: string,
    options: ThumbnailOptions = {},
  ): Promise<ThumbnailResult> {
    // Placeholder - requires PDF rendering library
    // Options:
    // 1. pdf-lib + canvas
    // 2. pdf-poppler (uses poppler binaries)
    // 3. pdf2pic

    this.logger.warn('PDF thumbnail generation requires PDF rendering library');

    // Create a placeholder
    const { width = 300, height = 400 } = options;

    const placeholder = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 255, g: 255, b: 255, alpha: 1 },
      },
    })
      .jpeg({ quality: 80 })
      .toBuffer();

    const thumbnailId = uuidv4();
    const outputFilename = `${thumbnailId}.jpeg`;
    const outputPath = path.join(this.thumbnailPath, outputFilename);

    await fs.writeFile(outputPath, placeholder);

    return {
      url: `uploads/thumbnails/${outputFilename}`,
      width,
      height,
      size: placeholder.length,
      format: 'jpeg',
    };
  }

  /**
   * Generate thumbnail based on MIME type
   */
  async generateThumbnailForFile(
    filePath: string,
    mimeType: string,
    options: ThumbnailOptions = {},
  ): Promise<ThumbnailResult | null> {
    if (mimeType.startsWith('image/')) {
      return this.generateFromFile(filePath, options);
    }

    if (mimeType.startsWith('video/')) {
      return this.generateVideoThumbnail(filePath, 1, options);
    }

    if (mimeType === 'application/pdf') {
      return this.generatePdfThumbnail(filePath, options);
    }

    // No thumbnail for other types
    return null;
  }

  /**
   * Delete thumbnail
   */
  async deleteThumbnail(thumbnailUrl: string): Promise<void> {
    const filename = path.basename(thumbnailUrl);
    const filePath = path.join(this.thumbnailPath, filename);

    if (existsSync(filePath)) {
      await fs.unlink(filePath);
      this.logger.log(`Deleted thumbnail: ${filename}`);
    }
  }

  /**
   * Cleanup old thumbnails (orphaned files)
   */
  async cleanupOrphanedThumbnails(validUrls: string[]): Promise<number> {
    const validFilenames = new Set(validUrls.map((url) => path.basename(url)));

    const files = await fs.readdir(this.thumbnailPath);
    let deletedCount = 0;

    for (const file of files) {
      if (!validFilenames.has(file)) {
        await fs.unlink(path.join(this.thumbnailPath, file));
        deletedCount++;
      }
    }

    this.logger.log(`Cleaned up ${deletedCount} orphaned thumbnails`);
    return deletedCount;
  }

  /**
   * Get thumbnail URL with CDN prefix if configured
   */
  getThumbnailUrl(relativePath: string): string {
    const cdnUrl = this.configService.get<string>('CDN_URL');
    if (cdnUrl) {
      return `${cdnUrl}/${relativePath}`;
    }
    return `${this.baseUrl}/${relativePath}`;
  }
}
