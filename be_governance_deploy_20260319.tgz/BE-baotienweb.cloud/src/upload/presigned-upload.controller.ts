import {
    Body,
    Controller,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Put,
    Req,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import type { Request as ExpressRequest } from 'express';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Public } from '../common/decorators/public.decorator';
import {
    ApiCrudErrors,
    ApiStandardErrors,
} from '../shared/decorators/api-error-responses.decorator';
import {
    AbortMultipartUploadDto,
    CompleteMultipartUploadDto,
    CompletePresignedUploadDto,
    CompleteUploadResponseDto,
    InitiateMultipartResponseDto,
    InitiateMultipartUploadDto,
    MultipartUploadStatusDto,
    PresignedUploadRequestDto,
    PresignedUploadResponseDto,
} from './dto/presigned-upload.dto';
import { PresignedUploadService } from './presigned-upload.service';

interface AuthRequest extends Request {
  user: { id: number; email: string };
}

@ApiTags('Presigned Upload')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'upload', version: '1' })
export class PresignedUploadController {
  constructor(
    private readonly presignedUploadService: PresignedUploadService,
  ) {}

  // =====================================================================
  // PRESIGNED SINGLE UPLOAD
  // =====================================================================

  @Post('presign')
  @ApiOperation({
    summary: 'Request presigned URL for file upload',
    description:
      'Get a presigned URL to upload a file directly to storage. Client uploads to the URL, then calls /complete.',
  })
  @ApiResponse({
    status: 201,
    description: 'Presigned URL generated',
    type: PresignedUploadResponseDto,
  })
  @ApiStandardErrors()
  async requestPresignedUpload(
    @Request() req: AuthRequest,
    @Body() dto: PresignedUploadRequestDto,
  ): Promise<PresignedUploadResponseDto> {
    return this.presignedUploadService.requestPresignedUpload(req.user.id, dto);
  }

  @Post('presign/complete')
  @ApiOperation({
    summary: 'Complete presigned upload',
    description:
      'Confirm upload completion, verify checksum, and save file metadata to database.',
  })
  @ApiResponse({
    status: 201,
    description: 'Upload completed and saved',
    type: CompleteUploadResponseDto,
  })
  @ApiCrudErrors()
  async completePresignedUpload(
    @Request() req: AuthRequest,
    @Body() dto: CompletePresignedUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    return this.presignedUploadService.completePresignedUpload(
      req.user.id,
      dto,
    );
  }

  @Put('presign/upload/:uploadId')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Upload file data (local storage)',
    description:
      'PUT binary file data for local storage presigned uploads. Used when S3 is not configured.',
  })
  @ApiResponse({ status: 200, description: 'File uploaded successfully' })
  @ApiCrudErrors()
  async handleLocalPresignedUpload(
    @Param('uploadId') uploadId: string,
    @Req() req: ExpressRequest,
  ): Promise<{ message: string }> {
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
      chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
    }
    const fileBuffer = Buffer.concat(chunks);
    const contentType = req.headers['content-type'] || '';
    await this.presignedUploadService.handleLocalUpload(
      uploadId,
      fileBuffer,
      contentType,
    );
    return { message: 'File uploaded successfully' };
  }

  // =====================================================================
  // MULTIPART (CHUNKED) UPLOAD
  // =====================================================================

  @Post('multipart/initiate')
  @ApiOperation({
    summary: 'Initiate multipart upload',
    description:
      'Start a chunked upload for large files. Returns presigned URLs for each part.',
  })
  @ApiResponse({
    status: 201,
    description: 'Multipart upload initiated',
    type: InitiateMultipartResponseDto,
  })
  @ApiStandardErrors()
  async initiateMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: InitiateMultipartUploadDto,
  ): Promise<InitiateMultipartResponseDto> {
    return this.presignedUploadService.initiateMultipartUpload(
      req.user.id,
      dto,
    );
  }

  @Post('multipart/part/complete')
  @ApiOperation({
    summary: 'Record completed part',
    description:
      'Record that a part was successfully uploaded (called after uploading to presigned URL).',
  })
  @ApiResponse({ status: 200, description: 'Part recorded' })
  @ApiStandardErrors()
  @HttpCode(HttpStatus.OK)
  async recordCompletedPart(
    @Request() req: AuthRequest,
    @Body()
    body: { uploadId: string; partNumber: number; etag: string; size: number },
  ): Promise<{ success: boolean }> {
    await this.presignedUploadService.recordCompletedPart(
      req.user.id,
      body.uploadId,
      body.partNumber,
      body.etag,
      body.size,
    );
    return { success: true };
  }

  @Post('multipart/complete')
  @ApiOperation({
    summary: 'Complete multipart upload',
    description: 'Finalize the multipart upload after all parts are uploaded.',
  })
  @ApiResponse({
    status: 201,
    description: 'Multipart upload completed',
    type: CompleteUploadResponseDto,
  })
  @ApiCrudErrors()
  async completeMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: CompleteMultipartUploadDto,
  ): Promise<CompleteUploadResponseDto> {
    return this.presignedUploadService.completeMultipartUpload(
      req.user.id,
      dto,
    );
  }

  @Post('multipart/abort')
  @ApiOperation({
    summary: 'Abort multipart upload',
    description:
      'Cancel an in-progress multipart upload and clean up uploaded parts.',
  })
  @ApiResponse({ status: 200, description: 'Upload aborted' })
  @ApiCrudErrors()
  @HttpCode(HttpStatus.OK)
  async abortMultipartUpload(
    @Request() req: AuthRequest,
    @Body() dto: AbortMultipartUploadDto,
  ): Promise<{ success: boolean }> {
    await this.presignedUploadService.abortMultipartUpload(
      req.user.id,
      dto.uploadId,
    );
    return { success: true };
  }

  @Get('multipart/:uploadId/status')
  @ApiOperation({
    summary: 'Get multipart upload status',
    description: 'Get the current status and progress of a multipart upload.',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload status',
    type: MultipartUploadStatusDto,
  })
  @ApiCrudErrors()
  async getMultipartUploadStatus(
    @Request() req: AuthRequest,
    @Param('uploadId') uploadId: string,
  ): Promise<MultipartUploadStatusDto> {
    return this.presignedUploadService.getMultipartUploadStatus(
      req.user.id,
      uploadId,
    );
  }

  @Get('multipart/pending')
  @ApiOperation({
    summary: 'List pending uploads',
    description:
      'Get all pending/in-progress multipart uploads for the current user.',
  })
  @ApiResponse({
    status: 200,
    description: 'List of pending uploads',
    type: [MultipartUploadStatusDto],
  })
  @ApiStandardErrors()
  async listPendingUploads(
    @Request() req: AuthRequest,
  ): Promise<MultipartUploadStatusDto[]> {
    return this.presignedUploadService.listPendingUploads(req.user.id);
  }
}
