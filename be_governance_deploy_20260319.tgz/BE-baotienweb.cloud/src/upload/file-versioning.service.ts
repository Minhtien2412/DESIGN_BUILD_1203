/**
 * File Versioning Service
 * Story 2.3: File Metadata & Versioning (UPLOAD-003)
 *
 * Provides file versioning, soft delete, and retention policy management.
 */

import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';

// ============ Types & Interfaces ============

export interface FileVersion {
  id: string;
  fileId: string;
  version: number;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  checksum: string;
  storageKey: string;
  createdAt: Date;
  createdBy: string;
  metadata?: Record<string, unknown>;
}

export interface FileWithVersions {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  currentVersion: number;
  isDeleted: boolean;
  deletedAt?: Date;
  retentionDays: number;
  ownerId: string;
  projectId?: string;
  conversationId?: string;
  createdAt: Date;
  updatedAt: Date;
  versions: FileVersion[];
}

export interface CreateFileDto {
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  checksum: string;
  storageKey: string;
  ownerId: string;
  projectId?: string;
  conversationId?: string;
  metadata?: Record<string, unknown>;
}

export interface UpdateFileDto {
  filename?: string;
  originalName?: string;
  mimeType?: string;
  size?: number;
  checksum?: string;
  storageKey?: string;
  metadata?: Record<string, unknown>;
}

export interface FileAccessLog {
  id: string;
  fileId: string;
  userId: string;
  action: 'view' | 'download' | 'upload' | 'delete' | 'restore' | 'share';
  ipAddress?: string;
  userAgent?: string;
  timestamp: Date;
}

export interface RetentionPolicy {
  defaultRetentionDays: number;
  deletedFileRetentionDays: number;
  maxVersionsPerFile: number;
}

// ============ Default Configuration ============

const DEFAULT_RETENTION_POLICY: RetentionPolicy = {
  defaultRetentionDays: 365, // 1 year
  deletedFileRetentionDays: 30, // 30 days after soft delete
  maxVersionsPerFile: 10, // Keep max 10 versions
};

// ============ Service Implementation ============
@Injectable()
export class FileVersioningService {
  private readonly logger = new Logger(FileVersioningService.name);
  private retentionPolicy: RetentionPolicy = DEFAULT_RETENTION_POLICY;

  constructor(private readonly prisma: PrismaService) {
    this.initializeTables();
  }

  // ============ Initialization ============

  private async initializeTables(): Promise<void> {
    try {
      // Check if file_versions table exists, create if not
      await this.prisma.$executeRaw`
        CREATE TABLE IF NOT EXISTS file_versions (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          file_id UUID NOT NULL,
          version INT NOT NULL,
          filename VARCHAR(255) NOT NULL,
          original_name VARCHAR(255) NOT NULL,
          mime_type VARCHAR(100) NOT NULL,
          size BIGINT NOT NULL,
          checksum VARCHAR(128) NOT NULL,
          storage_key VARCHAR(512) NOT NULL,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          created_by UUID NOT NULL,
          metadata JSONB,
          UNIQUE(file_id, version)
        )
      `;

      // Check if file_access_logs table exists
      await this.prisma.$executeRaw`
        CREATE TABLE IF NOT EXISTS file_access_logs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          file_id UUID NOT NULL,
          user_id UUID NOT NULL,
          action VARCHAR(20) NOT NULL,
          ip_address VARCHAR(45),
          user_agent TEXT,
          timestamp TIMESTAMPTZ DEFAULT NOW()
        )
      `;

      // Add versioning columns to files table if not exists
      await this.prisma.$executeRaw`
        ALTER TABLE files ADD COLUMN IF NOT EXISTS current_version INT DEFAULT 1
      `;
      await this.prisma.$executeRaw`
        ALTER TABLE files ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE
      `;
      await this.prisma.$executeRaw`
        ALTER TABLE files ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ
      `;
      await this.prisma.$executeRaw`
        ALTER TABLE files ADD COLUMN IF NOT EXISTS retention_days INT DEFAULT 365
      `;

      this.logger.log('File versioning tables initialized');
    } catch (error) {
      this.logger.warn('Could not initialize versioning tables:', error);
    }
  }

  // ============ File Operations ============

  /**
   * Create a new file with initial version
   */
  async createFile(data: CreateFileDto): Promise<FileWithVersions> {
    const fileId = crypto.randomUUID();
    const versionId = crypto.randomUUID();
    const now = new Date();

    try {
      // Create file record
      await this.prisma.$executeRaw`
        INSERT INTO files (id, filename, original_name, mime_type, size, checksum, storage_key, owner_id, project_id, conversation_id, current_version, is_deleted, retention_days, created_at, updated_at)
        VALUES (${fileId}::uuid, ${data.filename}, ${data.originalName}, ${data.mimeType}, ${data.size}, ${data.checksum}, ${data.storageKey}, ${data.ownerId}::uuid, ${data.projectId ? data.projectId : null}::uuid, ${data.conversationId ? data.conversationId : null}::uuid, 1, false, ${this.retentionPolicy.defaultRetentionDays}, ${now}, ${now})
      `;

      // Create first version
      await this.prisma.$executeRaw`
        INSERT INTO file_versions (id, file_id, version, filename, original_name, mime_type, size, checksum, storage_key, created_at, created_by, metadata)
        VALUES (${versionId}::uuid, ${fileId}::uuid, 1, ${data.filename}, ${data.originalName}, ${data.mimeType}, ${data.size}, ${data.checksum}, ${data.storageKey}, ${now}, ${data.ownerId}::uuid, ${data.metadata ? JSON.stringify(data.metadata) : null}::jsonb)
      `;

      // Log access
      await this.logAccess(fileId, data.ownerId, 'upload');

      return (await this.getFileWithVersions(fileId))!;
    } catch (error) {
      this.logger.error(`Failed to create file: ${error}`);
      throw error;
    }
  }

  /**
   * Create a new version of existing file
   */
  async createVersion(
    fileId: string,
    data: UpdateFileDto,
    userId: string,
  ): Promise<FileVersion> {
    const file = await this.getFileWithVersions(fileId);

    if (!file) {
      throw new NotFoundException(`File not found: ${fileId}`);
    }

    if (file.isDeleted) {
      throw new BadRequestException('Cannot create version of deleted file');
    }

    const newVersion = file.currentVersion + 1;
    const versionId = crypto.randomUUID();
    const now = new Date();

    // Create new version
    await this.prisma.$executeRaw`
      INSERT INTO file_versions (id, file_id, version, filename, original_name, mime_type, size, checksum, storage_key, created_at, created_by, metadata)
      VALUES (${versionId}::uuid, ${fileId}::uuid, ${newVersion}, ${data.filename || file.filename}, ${data.originalName || file.originalName}, ${data.mimeType || file.mimeType}, ${data.size || file.size}, ${data.checksum || ''}, ${data.storageKey || ''}, ${now}, ${userId}::uuid, ${data.metadata ? JSON.stringify(data.metadata) : null}::jsonb)
    `;

    // Update file current version
    await this.prisma.$executeRaw`
      UPDATE files SET current_version = ${newVersion}, updated_at = ${now}
      WHERE id = ${fileId}::uuid
    `;

    // Log access
    await this.logAccess(fileId, userId, 'upload');

    // Cleanup old versions if exceeds max
    await this.cleanupOldVersions(fileId);

    return (await this.getVersion(fileId, newVersion))!;
  }

  /**
   * Get file with all versions
   */
  async getFileWithVersions(fileId: string): Promise<FileWithVersions | null> {
    try {
      const files = await this.prisma.$queryRaw<FileWithVersions[]>`
        SELECT 
          f.id, f.filename, f.original_name as "originalName", f.mime_type as "mimeType",
          f.size, f.current_version as "currentVersion", f.is_deleted as "isDeleted",
          f.deleted_at as "deletedAt", f.retention_days as "retentionDays",
          f.owner_id as "ownerId", f.project_id as "projectId", f.conversation_id as "conversationId",
          f.created_at as "createdAt", f.updated_at as "updatedAt"
        FROM files f
        WHERE f.id = ${fileId}::uuid
      `;

      if (!files || files.length === 0) {
        return null;
      }

      const file = files[0];

      // Get versions
      const versions = await this.prisma.$queryRaw<FileVersion[]>`
        SELECT 
          id, file_id as "fileId", version, filename, original_name as "originalName",
          mime_type as "mimeType", size, checksum, storage_key as "storageKey",
          created_at as "createdAt", created_by as "createdBy", metadata
        FROM file_versions
        WHERE file_id = ${fileId}::uuid
        ORDER BY version DESC
      `;

      return { ...file, versions };
    } catch (error) {
      this.logger.error(`Failed to get file: ${error}`);
      return null;
    }
  }

  /**
   * Get specific version
   */
  async getVersion(
    fileId: string,
    version: number,
  ): Promise<FileVersion | null> {
    try {
      const versions = await this.prisma.$queryRaw<FileVersion[]>`
        SELECT 
          id, file_id as "fileId", version, filename, original_name as "originalName",
          mime_type as "mimeType", size, checksum, storage_key as "storageKey",
          created_at as "createdAt", created_by as "createdBy", metadata
        FROM file_versions
        WHERE file_id = ${fileId}::uuid AND version = ${version}
      `;

      return versions?.[0] || null;
    } catch (error) {
      this.logger.error(`Failed to get version: ${error}`);
      return null;
    }
  }

  /**
   * List all versions for a file
   */
  async listVersions(fileId: string): Promise<FileVersion[]> {
    try {
      return await this.prisma.$queryRaw<FileVersion[]>`
        SELECT 
          id, file_id as "fileId", version, filename, original_name as "originalName",
          mime_type as "mimeType", size, checksum, storage_key as "storageKey",
          created_at as "createdAt", created_by as "createdBy", metadata
        FROM file_versions
        WHERE file_id = ${fileId}::uuid
        ORDER BY version DESC
      `;
    } catch (error) {
      this.logger.error(`Failed to list versions: ${error}`);
      return [];
    }
  }

  // ============ Soft Delete & Restore ============

  /**
   * Soft delete a file
   */
  async softDelete(fileId: string, userId: string): Promise<void> {
    const now = new Date();

    await this.prisma.$executeRaw`
      UPDATE files SET is_deleted = true, deleted_at = ${now}, updated_at = ${now}
      WHERE id = ${fileId}::uuid AND is_deleted = false
    `;

    await this.logAccess(fileId, userId, 'delete');
    this.logger.log(`File soft deleted: ${fileId}`);
  }

  /**
   * Restore a soft-deleted file
   */
  async restore(fileId: string, userId: string): Promise<void> {
    const file = await this.getFileWithVersions(fileId);

    if (!file) {
      throw new NotFoundException(`File not found: ${fileId}`);
    }

    if (!file.isDeleted) {
      throw new BadRequestException('File is not deleted');
    }

    // Check if within retention period
    if (file.deletedAt) {
      const expiryDate = new Date(file.deletedAt);
      expiryDate.setDate(
        expiryDate.getDate() + this.retentionPolicy.deletedFileRetentionDays,
      );

      if (new Date() > expiryDate) {
        throw new BadRequestException(
          'File has exceeded retention period and cannot be restored',
        );
      }
    }

    const now = new Date();
    await this.prisma.$executeRaw`
      UPDATE files SET is_deleted = false, deleted_at = null, updated_at = ${now}
      WHERE id = ${fileId}::uuid
    `;

    await this.logAccess(fileId, userId, 'restore');
    this.logger.log(`File restored: ${fileId}`);
  }

  /**
   * Permanently delete a file and all versions
   */
  async permanentDelete(fileId: string): Promise<void> {
    try {
      // Delete all versions
      await this.prisma.$executeRaw`
        DELETE FROM file_versions WHERE file_id = ${fileId}::uuid
      `;

      // Delete access logs
      await this.prisma.$executeRaw`
        DELETE FROM file_access_logs WHERE file_id = ${fileId}::uuid
      `;

      // Delete file record
      await this.prisma.$executeRaw`
        DELETE FROM files WHERE id = ${fileId}::uuid
      `;

      this.logger.log(`File permanently deleted: ${fileId}`);
    } catch (error) {
      this.logger.error(`Failed to permanently delete file: ${error}`);
      throw error;
    }
  }

  // ============ Access Logging ============

  /**
   * Log file access
   */
  async logAccess(
    fileId: string,
    userId: string,
    action: FileAccessLog['action'],
    ipAddress?: string,
    userAgent?: string,
  ): Promise<void> {
    try {
      const id = crypto.randomUUID();
      await this.prisma.$executeRaw`
        INSERT INTO file_access_logs (id, file_id, user_id, action, ip_address, user_agent, timestamp)
        VALUES (${id}::uuid, ${fileId}::uuid, ${userId}::uuid, ${action}, ${ipAddress || null}, ${userAgent || null}, NOW())
      `;
    } catch (error) {
      this.logger.warn(`Failed to log access: ${error}`);
    }
  }

  /**
   * Get access logs for a file
   */
  async getAccessLogs(fileId: string, limit = 100): Promise<FileAccessLog[]> {
    try {
      return await this.prisma.$queryRaw<FileAccessLog[]>`
        SELECT id, file_id as "fileId", user_id as "userId", action, ip_address as "ipAddress", user_agent as "userAgent", timestamp
        FROM file_access_logs
        WHERE file_id = ${fileId}::uuid
        ORDER BY timestamp DESC
        LIMIT ${limit}
      `;
    } catch (error) {
      this.logger.error(`Failed to get access logs: ${error}`);
      return [];
    }
  }

  // ============ Retention & Cleanup ============

  /**
   * Cleanup old versions exceeding max limit
   */
  private async cleanupOldVersions(fileId: string): Promise<void> {
    try {
      const versions = await this.listVersions(fileId);

      if (versions.length > this.retentionPolicy.maxVersionsPerFile) {
        const versionsToDelete = versions.slice(
          this.retentionPolicy.maxVersionsPerFile,
        );

        for (const version of versionsToDelete) {
          await this.prisma.$executeRaw`
            DELETE FROM file_versions WHERE id = ${version.id}::uuid
          `;
          this.logger.log(
            `Deleted old version ${version.version} of file ${fileId}`,
          );
        }
      }
    } catch (error) {
      this.logger.error(`Failed to cleanup old versions: ${error}`);
    }
  }

  /**
   * Scheduled cleanup of expired deleted files
   * Runs daily at 3 AM
   */
  @Cron(CronExpression.EVERY_DAY_AT_3AM)
  async cleanupExpiredFiles(): Promise<void> {
    this.logger.log('Starting cleanup of expired deleted files...');

    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(
        cutoffDate.getDate() - this.retentionPolicy.deletedFileRetentionDays,
      );

      // Get expired files
      const expiredFiles = await this.prisma.$queryRaw<{ id: string }[]>`
        SELECT id FROM files
        WHERE is_deleted = true AND deleted_at < ${cutoffDate}
      `;

      let deletedCount = 0;
      for (const file of expiredFiles) {
        await this.permanentDelete(file.id);
        deletedCount++;
      }

      this.logger.log(
        `Cleanup complete: ${deletedCount} expired files permanently deleted`,
      );
    } catch (error) {
      this.logger.error(`Cleanup failed: ${error}`);
    }
  }

  /**
   * Get retention policy
   */
  getRetentionPolicy(): RetentionPolicy {
    return { ...this.retentionPolicy };
  }

  /**
   * Update retention policy
   */
  setRetentionPolicy(policy: Partial<RetentionPolicy>): void {
    this.retentionPolicy = { ...this.retentionPolicy, ...policy };
    this.logger.log(
      `Retention policy updated: ${JSON.stringify(this.retentionPolicy)}`,
    );
  }

  // ============ Statistics ============

  /**
   * Get file statistics
   */
  async getStats(): Promise<{
    totalFiles: number;
    totalSize: number;
    deletedFiles: number;
    totalVersions: number;
  }> {
    try {
      const stats = await this.prisma.$queryRaw<
        {
          total_files: number;
          total_size: number;
          deleted_files: number;
        }[]
      >`
        SELECT 
          COUNT(*) as total_files,
          COALESCE(SUM(size), 0) as total_size,
          COUNT(*) FILTER (WHERE is_deleted = true) as deleted_files
        FROM files
      `;

      const versionStats = await this.prisma.$queryRaw<
        { total_versions: number }[]
      >`
        SELECT COUNT(*) as total_versions FROM file_versions
      `;

      return {
        totalFiles: Number(stats[0]?.total_files || 0),
        totalSize: Number(stats[0]?.total_size || 0),
        deletedFiles: Number(stats[0]?.deleted_files || 0),
        totalVersions: Number(versionStats[0]?.total_versions || 0),
      };
    } catch (error) {
      this.logger.error(`Failed to get stats: ${error}`);
      return { totalFiles: 0, totalSize: 0, deletedFiles: 0, totalVersions: 0 };
    }
  }
}
