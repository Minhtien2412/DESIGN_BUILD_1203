import {
    DeleteObjectCommand,
    PutObjectCommand,
    S3Client,
} from '@aws-sdk/client-s3';
import {
    getErrorMessage
} from '../utils/error-helpers';

import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { BadRequestException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { v2 as cloudinary } from 'cloudinary';
import * as ExifParser from 'exif-parser';
import { existsSync } from 'fs';
import { mkdir, unlink, writeFile } from 'fs/promises';
import { join } from 'path';
import sharp from 'sharp';
import { v4 as uuidv4 } from 'uuid';

export enum StorageProvider {
  LOCAL = 'local',
  S3 = 's3',
  CLOUDINARY = 'cloudinary',
}

export interface UploadOptions {
  folder?: string;
  maxSize?: number; // bytes
  allowedMimeTypes?: string[];
  provider?: StorageProvider;
}

export interface UploadResult {
  url: string;
  publicId?: string;
  filename: string;
  size: number;
  mimetype: string;
  provider: StorageProvider;
}

@Injectable()
export class UploadService {
  private readonly uploadPath = join(process.cwd(), 'uploads');
  private s3Client: S3Client;
  private defaultProvider: StorageProvider;

  constructor(private configService: ConfigService) {
    this.ensureUploadDirectory();
    this.initializeCloudProviders();
  }

  private async ensureUploadDirectory() {
    if (!existsSync(this.uploadPath)) {
      await mkdir(this.uploadPath, { recursive: true });
    }
  }

  private initializeCloudProviders() {
    // Determine default provider from environment
    const providerEnv = this.configService.get<string>(
      'STORAGE_PROVIDER',
      'local',
    );
    this.defaultProvider = providerEnv as StorageProvider;

    // Initialize AWS S3
    const awsRegion = this.configService.get<string>('AWS_REGION');
    const awsAccessKeyId = this.configService.get<string>('AWS_ACCESS_KEY_ID');
    const awsSecretAccessKey = this.configService.get<string>(
      'AWS_SECRET_ACCESS_KEY',
    );

    if (awsRegion && awsAccessKeyId && awsSecretAccessKey) {
      this.s3Client = new S3Client({
        region: awsRegion,
        credentials: {
          accessKeyId: awsAccessKeyId,
          secretAccessKey: awsSecretAccessKey,
        },
      });
    }

    // Initialize Cloudinary
    const cloudinaryCloudName = this.configService.get<string>(
      'CLOUDINARY_CLOUD_NAME',
    );
    const cloudinaryApiKey =
      this.configService.get<string>('CLOUDINARY_API_KEY');
    const cloudinaryApiSecret = this.configService.get<string>(
      'CLOUDINARY_API_SECRET',
    );

    if (cloudinaryCloudName && cloudinaryApiKey && cloudinaryApiSecret) {
      cloudinary.config({
        cloud_name: cloudinaryCloudName,
        api_key: cloudinaryApiKey,
        api_secret: cloudinaryApiSecret,
      });
    }
  }

  /**
   * Upload a single file to the configured storage provider
   */
  async uploadFile(
    file: Express.Multer.File,
    options: UploadOptions = {},
  ): Promise<UploadResult> {
    if (!file) {
      throw new BadRequestException('No file provided');
    }

    // Validate file
    this.validateFile(file, options);

    // Determine provider
    const provider = options.provider || this.defaultProvider;

    // Upload based on provider
    switch (provider) {
      case StorageProvider.S3:
        return this.uploadToS3(file, options);
      case StorageProvider.CLOUDINARY:
        return this.uploadToCloudinary(file, options);
      case StorageProvider.LOCAL:
      default:
        return this.uploadToLocal(file, options);
    }
  }

  /**
   * Upload multiple files
   */
  async uploadFiles(
    files: Express.Multer.File[],
    options: UploadOptions = {},
  ): Promise<UploadResult[]> {
    if (!files || files.length === 0) {
      throw new BadRequestException('No files provided');
    }

    const uploadPromises = files.map((file) => this.uploadFile(file, options));
    return Promise.all(uploadPromises);
  }

  /**
   * Delete file from storage provider
   */
  async deleteFile(url: string, provider: StorageProvider): Promise<void> {
    switch (provider) {
      case StorageProvider.S3:
        await this.deleteFromS3(url);
        break;
      case StorageProvider.CLOUDINARY:
        await this.deleteFromCloudinary(url);
        break;
      case StorageProvider.LOCAL:
        await this.deleteFromLocal(url);
        break;
    }
  }

  /**
   * Validate file type and size
   */
  private validateFile(file: Express.Multer.File, options: UploadOptions) {
    // Validate file type
    const allowedMimeTypes = options.allowedMimeTypes || [
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/svg+xml',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain',
      'text/csv',
    ];

    if (!allowedMimeTypes.includes(file.mimetype)) {
      throw new BadRequestException(
        `Invalid file type. Allowed types: ${allowedMimeTypes.join(', ')}`,
      );
    }

    // Validate file size (default 10MB)
    const maxSize = options.maxSize || 10 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new BadRequestException(
        `File size exceeds ${maxSize / 1024 / 1024}MB limit`,
      );
    }
  }

  /**
   * Upload to local filesystem
   */
  private async uploadToLocal(
    file: Express.Multer.File,
    options: UploadOptions,
  ): Promise<UploadResult> {
    const fileExtension = file.originalname.split('.').pop();
    const fileName = `${uuidv4()}.${fileExtension}`;

    // Create folder if specified
    let targetPath = this.uploadPath;
    if (options.folder) {
      targetPath = join(this.uploadPath, options.folder);
      if (!existsSync(targetPath)) {
        await mkdir(targetPath, { recursive: true });
      }
    }

    const filePath = join(targetPath, fileName);
    await writeFile(filePath, file.buffer);

    // Build full URL
    const baseUrl = this.configService.get<string>(
      'APP_URL',
      'https://baotienweb.cloud',
    );
    const relativePath = options.folder
      ? `/uploads/${options.folder}/${fileName}`
      : `/uploads/${fileName}`;

    return {
      url: `${baseUrl}${relativePath}`,
      filename: fileName,
      size: file.size,
      mimetype: file.mimetype,
      provider: StorageProvider.LOCAL,
    };
  }

  /**
   * Upload to AWS S3
   */
  private async uploadToS3(
    file: Express.Multer.File,
    options: UploadOptions,
  ): Promise<UploadResult> {
    if (!this.s3Client) {
      throw new BadRequestException('AWS S3 is not configured');
    }

    const bucket = this.configService.get<string>('AWS_S3_BUCKET');
    if (!bucket) {
      throw new BadRequestException('AWS S3 bucket not configured');
    }

    const fileExtension = file.originalname.split('.').pop();
    const fileName = `${uuidv4()}.${fileExtension}`;
    const key = options.folder ? `${options.folder}/${fileName}` : fileName;

    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: 'public-read', // or 'private' based on your needs
    });

    await this.s3Client.send(command);

    // Generate public URL
    const region = this.configService.get<string>('AWS_REGION');
    const url = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;

    return {
      url,
      publicId: key,
      filename: fileName,
      size: file.size,
      mimetype: file.mimetype,
      provider: StorageProvider.S3,
    };
  }

  /**
   * Upload to Cloudinary
   */
  private async uploadToCloudinary(
    file: Express.Multer.File,
    options: UploadOptions,
  ): Promise<UploadResult> {
    if (!cloudinary.config().cloud_name) {
      throw new BadRequestException('Cloudinary is not configured');
    }

    return new Promise((resolve, reject) => {
      const uploadOptions: any = {
        resource_type: 'auto',
        folder: options.folder || 'baotienweb',
      };

      const uploadStream = cloudinary.uploader.upload_stream(
        uploadOptions,
        (error, result) => {
          if (error) {
            reject(
              new BadRequestException(
                `Cloudinary upload failed: ${getErrorMessage(error)}`,
              ),
            );
          } else if (result) {
            resolve({
              url: result.secure_url,
              publicId: result.public_id,
              filename: result.original_filename,
              size: file.size,
              mimetype: file.mimetype,
              provider: StorageProvider.CLOUDINARY,
            });
          } else {
            reject(
              new BadRequestException(
                'Cloudinary upload failed: No result returned',
              ),
            );
          }
        },
      );

      uploadStream.end(file.buffer);
    });
  }

  /**
   * Generate presigned URL for S3 (for private files)
   */
  async generatePresignedUrl(key: string, expiresIn = 3600): Promise<string> {
    if (!this.s3Client) {
      throw new BadRequestException('AWS S3 is not configured');
    }

    const bucket = this.configService.get<string>('AWS_S3_BUCKET');
    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
    });

    return getSignedUrl(this.s3Client, command, { expiresIn });
  }

  /**
   * Delete file from S3
   */
  private async deleteFromS3(url: string): Promise<void> {
    if (!this.s3Client) return;

    const bucket = this.configService.get<string>('AWS_S3_BUCKET');
    const key = url.split('.amazonaws.com/')[1];

    const command = new DeleteObjectCommand({
      Bucket: bucket,
      Key: key,
    });

    await this.s3Client.send(command);
  }

  /**
   * Delete file from Cloudinary
   */
  private async deleteFromCloudinary(publicId: string): Promise<void> {
    if (!cloudinary.config().cloud_name) return;

    await cloudinary.uploader.destroy(publicId);
  }

  /**
   * Delete file from local filesystem
   */
  private async deleteFromLocal(relativePath: string): Promise<void> {
    const filePath = join(process.cwd(), relativePath);
    if (existsSync(filePath)) {
      await unlink(filePath);
    }
  }

  /**
   * Get file URL (useful for local files to generate full URL)
   */
  getFileUrl(path: string, provider: StorageProvider): string {
    if (provider === StorageProvider.LOCAL) {
      const baseUrl = this.configService.get<string>(
        'APP_URL',
        'http://localhost:3000',
      );
      return `${baseUrl}/${path}`;
    }
    return path; // For S3 and Cloudinary, path is already full URL
  }

  /**
   * Extract EXIF metadata including GPS from image
   */
  async extractMetadata(file: Express.Multer.File): Promise<any> {
    const metadata: any = {};

    try {
      // Use Sharp to get image dimensions and basic info
      const imageInfo = await sharp(file.buffer).metadata();
      metadata.width = imageInfo.width;
      metadata.height = imageInfo.height;
      metadata.format = imageInfo.format;
      metadata.space = imageInfo.space;

      // Try to extract EXIF data including GPS
      if (file.buffer && file.buffer.length > 0) {
        try {
          const parser = ExifParser.create(file.buffer);
          const exifData = parser.parse();

          if (exifData.tags) {
            // Camera info
            if (exifData.tags.Make) metadata.cameraMake = exifData.tags.Make;
            if (exifData.tags.Model) metadata.cameraModel = exifData.tags.Model;
            if (exifData.tags.DateTime)
              metadata.dateTime = new Date(exifData.tags.DateTime * 1000);
            if (exifData.tags.Orientation)
              metadata.orientation = exifData.tags.Orientation;

            // GPS coordinates
            if (exifData.tags.GPSLatitude && exifData.tags.GPSLongitude) {
              metadata.gps = {
                latitude: exifData.tags.GPSLatitude,
                longitude: exifData.tags.GPSLongitude,
                altitude: exifData.tags.GPSAltitude,
              };
            }
          }
        } catch (exifError) {
          // EXIF might not exist or be corrupted, continue anyway
          console.warn('Failed to extract EXIF:', exifError.message);
        }
      }
    } catch (error: unknown) {
      console.error('Failed to extract metadata:', getErrorMessage(error));
    }

    return metadata;
  }

  /**
   * Generate thumbnail for image
   */
  async generateThumbnail(
    file: Express.Multer.File,
    width = 200,
    height = 200,
  ): Promise<Buffer> {
    return sharp(file.buffer)
      .resize(width, height, {
        fit: 'cover',
        position: 'centre',
      })
      .jpeg({ quality: 80 })
      .toBuffer();
  }

  /**
   * Upload file with metadata extraction (for images)
   */
  async uploadWithMetadata(
    file: Express.Multer.File,
    options: UploadOptions = {},
  ): Promise<UploadResult & { metadata?: any; thumbnailUrl?: string }> {
    // Upload original file
    const uploadResult = await this.uploadFile(file, options);

    // Extract metadata if it's an image
    let metadata: any = undefined;
    let thumbnailUrl: string | undefined;

    if (file.mimetype.startsWith('image/')) {
      try {
        metadata = await this.extractMetadata(file);

        // Generate and upload thumbnail
        const thumbnailBuffer = await this.generateThumbnail(file);
        const thumbnailFile = {
          ...file,
          buffer: thumbnailBuffer,
          originalname: `thumb_${file.originalname}`,
          size: thumbnailBuffer.length,
        } as Express.Multer.File;

        const thumbnailOptions = {
          ...options,
          folder: options.folder
            ? `${options.folder}/thumbnails`
            : 'thumbnails',
        };

        const thumbnailResult = await this.uploadFile(
          thumbnailFile,
          thumbnailOptions,
        );
        thumbnailUrl = thumbnailResult.url;
      } catch (error: unknown) {
        console.error(
          'Failed to extract metadata or generate thumbnail:',
          getErrorMessage(error),
        );
      }
    }

    return {
      ...uploadResult,
      metadata,
      thumbnailUrl,
    };
  }
}
