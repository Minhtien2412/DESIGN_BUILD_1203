import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from '../prisma/prisma.module';
import { FileMetadataController } from './file-metadata.controller';
import { FileMetadataService } from './file-metadata.service';
import { FileVersioningController } from './file-versioning.controller';
import { FileVersioningService } from './file-versioning.service';
import { PresignedUploadController } from './presigned-upload.controller';
import { PresignedUploadService } from './presigned-upload.service';
import { ThumbnailController } from './thumbnail.controller';
import { ThumbnailService } from './thumbnail.service';
import { UploadController } from './upload.controller';
import { UploadService } from './upload.service';

@Module({
  imports: [ConfigModule, PrismaModule],
  controllers: [
    UploadController,
    PresignedUploadController,
    FileMetadataController,
    FileVersioningController,
    ThumbnailController,
  ],
  providers: [
    UploadService,
    PresignedUploadService,
    FileMetadataService,
    FileVersioningService,
    ThumbnailService,
  ],
  exports: [
    UploadService,
    PresignedUploadService,
    FileMetadataService,
    FileVersioningService,
    ThumbnailService,
  ],
})
export class UploadModule {}
