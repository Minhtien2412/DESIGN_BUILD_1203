/**
 * File Versioning Controller
 * Story 2.3: File Metadata & Versioning (UPLOAD-003)
 *
 * REST API endpoints for file versioning, soft delete, and restore operations.
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseUUIDPipe,
    Post,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiPropertyOptional,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    ApiCrudErrors,
    ApiDeleteResponse,
    ApiStandardErrors,
} from '../shared/decorators/api-error-responses.decorator';
import {
    FileVersioningService,
    UpdateFileDto,
} from './file-versioning.service';

// ============ DTOs ============

class CreateFileVersionDto {
  @ApiPropertyOptional({ description: 'Filename' })
  filename?: string;

  @ApiPropertyOptional({ description: 'Original name' })
  originalName?: string;

  @ApiPropertyOptional({ description: 'MIME type' })
  mimeType?: string;

  @ApiPropertyOptional({ description: 'File size in bytes' })
  size?: number;

  @ApiPropertyOptional({ description: 'SHA256 checksum' })
  checksum?: string;

  @ApiPropertyOptional({ description: 'Storage key/path' })
  storageKey?: string;

  @ApiPropertyOptional({ description: 'Additional metadata' })
  metadata?: Record<string, unknown>;
}

class UpdateRetentionDto {
  @ApiPropertyOptional({ description: 'Default retention days' })
  defaultRetentionDays?: number;

  @ApiPropertyOptional({ description: 'Deleted file retention days' })
  deletedFileRetentionDays?: number;

  @ApiPropertyOptional({ description: 'Max versions per file' })
  maxVersionsPerFile?: number;
}

// ============ Controller ============

@ApiTags('File Versioning (legacy)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('file-versioning')
export class FileVersioningController {
  constructor(private readonly fileVersioningService: FileVersioningService) {}

  // ============ File Operations ============

  @Get(':fileId')
  @ApiOperation({ summary: 'Get file with all versions' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiResponse({ status: 200, description: 'File with versions retrieved' })
  @ApiCrudErrors()
  async getFile(@Param('fileId', ParseUUIDPipe) fileId: string) {
    const file = await this.fileVersioningService.getFileWithVersions(fileId);
    if (!file) {
      return { success: false, error: 'File not found' };
    }
    return { success: true, data: file };
  }

  // ============ Version Operations ============

  @Get(':fileId/versions')
  @ApiOperation({ summary: 'List all versions of a file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiResponse({ status: 200, description: 'Versions list retrieved' })
  @ApiCrudErrors()
  async listVersions(@Param('fileId', ParseUUIDPipe) fileId: string) {
    const versions = await this.fileVersioningService.listVersions(fileId);
    return { success: true, data: versions };
  }

  @Get(':fileId/versions/:version')
  @ApiOperation({ summary: 'Get specific version of a file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiParam({ name: 'version', type: 'number' })
  @ApiResponse({ status: 200, description: 'Version retrieved' })
  @ApiCrudErrors()
  async getVersion(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @Param('version') version: string,
  ) {
    const versionNum = parseInt(version, 10);
    const fileVersion = await this.fileVersioningService.getVersion(
      fileId,
      versionNum,
    );
    if (!fileVersion) {
      return { success: false, error: 'Version not found' };
    }
    return { success: true, data: fileVersion };
  }

  @Post(':fileId/versions')
  @ApiOperation({ summary: 'Create new version of a file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiResponse({ status: 201, description: 'New version created' })
  @ApiCrudErrors()
  async createVersion(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @Body() data: CreateFileVersionDto,
    @Request() req,
  ) {
    try {
      const version = await this.fileVersioningService.createVersion(
        fileId,
        data as UpdateFileDto,
        req.user.id,
      );
      return { success: true, data: version };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // ============ Soft Delete & Restore ============

  @Delete(':fileId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Soft delete a file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiDeleteResponse()
  async softDelete(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @Request() req,
  ) {
    await this.fileVersioningService.softDelete(fileId, req.user.id);
    return { success: true, message: 'File moved to trash' };
  }

  @Post(':fileId/restore')
  @ApiOperation({ summary: 'Restore a soft-deleted file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiResponse({ status: 200, description: 'File restored' })
  @ApiCrudErrors()
  async restore(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @Request() req,
  ) {
    try {
      await this.fileVersioningService.restore(fileId, req.user.id);
      return { success: true, message: 'File restored' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @Delete(':fileId/permanent')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Permanently delete a file and all versions' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiDeleteResponse()
  async permanentDelete(@Param('fileId', ParseUUIDPipe) fileId: string) {
    await this.fileVersioningService.permanentDelete(fileId);
    return { success: true, message: 'File permanently deleted' };
  }

  // ============ Access Logs ============

  @Get(':fileId/access-logs')
  @ApiOperation({ summary: 'Get access logs for a file' })
  @ApiParam({ name: 'fileId', type: 'string', format: 'uuid' })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: 'number',
    description: 'Max logs to return',
  })
  @ApiResponse({ status: 200, description: 'Access logs retrieved' })
  @ApiCrudErrors()
  async getAccessLogs(
    @Param('fileId', ParseUUIDPipe) fileId: string,
    @Query('limit') limit?: string,
  ) {
    const logs = await this.fileVersioningService.getAccessLogs(
      fileId,
      limit ? parseInt(limit, 10) : 100,
    );
    return { success: true, data: logs };
  }

  // ============ Retention Policy ============

  @Get('admin/retention-policy')
  @ApiOperation({ summary: 'Get current retention policy' })
  @ApiResponse({ status: 200, description: 'Retention policy retrieved' })
  @ApiStandardErrors()
  async getRetentionPolicy() {
    const policy = this.fileVersioningService.getRetentionPolicy();
    return { success: true, data: policy };
  }

  @Post('admin/retention-policy')
  @ApiOperation({ summary: 'Update retention policy' })
  @ApiResponse({ status: 200, description: 'Retention policy updated' })
  @ApiStandardErrors()
  async updateRetentionPolicy(@Body() data: UpdateRetentionDto) {
    this.fileVersioningService.setRetentionPolicy(data);
    const policy = this.fileVersioningService.getRetentionPolicy();
    return { success: true, data: policy, message: 'Retention policy updated' };
  }

  // ============ Statistics ============

  @Get('admin/stats')
  @ApiOperation({ summary: 'Get file storage statistics' })
  @ApiResponse({ status: 200, description: 'Statistics retrieved' })
  @ApiStandardErrors()
  async getStats() {
    const stats = await this.fileVersioningService.getStats();
    return { success: true, data: stats };
  }

  // ============ Manual Cleanup ============

  @Post('admin/cleanup')
  @ApiOperation({ summary: 'Manually trigger cleanup of expired files' })
  @ApiResponse({ status: 200, description: 'Cleanup triggered' })
  async triggerCleanup() {
    await this.fileVersioningService.cleanupExpiredFiles();
    return { success: true, message: 'Cleanup completed' };
  }
}
