import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateFileMetadataDto,
    CreateFileVersionDto,
    FileAccessType,
    FileStatus,
    ListFilesQueryDto,
    UpdateFileMetadataDto,
} from './dto/file-metadata.dto';

// Extended File type with versioning fields (to be added to Prisma schema)
export interface FileWithVersioning {
  id: number;
  filename: string;
  url: string;
  mimeType: string;
  size: number;
  checksum?: string;
  thumbnailUrl?: string;
  status: string;
  version: number;
  ownerId?: number;
  projectId?: number;
  taskId?: number;
  conversationId?: number;
  metadata?: any;
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date;
}

export interface FileVersion {
  id: number;
  fileId: number;
  version: number;
  url: string;
  size: number;
  checksum?: string;
  comment?: string;
  createdById?: number;
  createdAt: Date;
}

export interface FileAccessLog {
  id: number;
  fileId: number;
  userId: number;
  accessType: string;
  accessedAt: Date;
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class FileMetadataService {
  private readonly logger = new Logger(FileMetadataService.name);

  // Default retention period for deleted files (30 days)
  private readonly RETENTION_DAYS = 30;

  constructor(private prisma: PrismaService) {}

  /**
   * Create file metadata record
   */
  async createFile(
    userId: number,
    dto: CreateFileMetadataDto,
  ): Promise<FileWithVersioning> {
    const file = await this.prisma.file.create({
      data: {
        filename: dto.filename,
        url: dto.url,
        mimeType: dto.mimeType,
        size: dto.size,
        projectId: dto.projectId,
        taskId: dto.taskId,
      },
    });

    // Log access
    await this.logAccess(file.id, userId, FileAccessType.EDIT);

    this.logger.log(`Created file: ${file.id} - ${dto.filename}`);

    return this.toFileWithVersioning(file);
  }

  /**
   * Get file by ID
   */
  async getFile(fileId: number, userId: number): Promise<FileWithVersioning> {
    const file = await this.prisma.file.findUnique({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    // Log access
    await this.logAccess(fileId, userId, FileAccessType.VIEW);

    return this.toFileWithVersioning(file);
  }

  /**
   * List files with filters
   */
  async listFiles(
    userId: number,
    query: ListFilesQueryDto,
  ): Promise<{
    files: FileWithVersioning[];
    total: number;
    page: number;
    limit: number;
  }> {
    const page = query.page || 1;
    const limit = query.limit || 20;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (query.projectId) {
      where.projectId = query.projectId;
    }

    if (query.taskId) {
      where.taskId = query.taskId;
    }

    if (query.mimeType) {
      if (query.mimeType.endsWith('/*')) {
        const prefix = query.mimeType.replace('/*', '');
        where.mimeType = { startsWith: prefix };
      } else {
        where.mimeType = query.mimeType;
      }
    }

    if (query.search) {
      where.filename = { contains: query.search, mode: 'insensitive' };
    }

    const orderBy: any = {};
    if (query.sortBy) {
      orderBy[query.sortBy] = query.sortOrder || 'desc';
    } else {
      orderBy.createdAt = 'desc';
    }

    const [files, total] = await Promise.all([
      this.prisma.file.findMany({
        where,
        orderBy,
        skip,
        take: limit,
      }),
      this.prisma.file.count({ where }),
    ]);

    return {
      files: files.map((f) => this.toFileWithVersioning(f)),
      total,
      page,
      limit,
    };
  }

  /**
   * Update file metadata
   */
  async updateFile(
    fileId: number,
    userId: number,
    dto: UpdateFileMetadataDto,
  ): Promise<FileWithVersioning> {
    const file = await this.prisma.file.findUnique({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    const updatedFile = await this.prisma.file.update({
      where: { id: fileId },
      data: {
        filename: dto.filename,
      },
    });

    await this.logAccess(fileId, userId, FileAccessType.EDIT);

    this.logger.log(`Updated file: ${fileId}`);

    return this.toFileWithVersioning(updatedFile);
  }

  /**
   * Soft delete file
   */
  async softDeleteFile(fileId: number, userId: number): Promise<void> {
    const file = await this.prisma.file.findUnique({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    // For now, we'll just delete the file
    // In production, you'd want to add a deletedAt field to the File model
    await this.prisma.file.delete({
      where: { id: fileId },
    });

    await this.logAccess(fileId, userId, FileAccessType.DELETE);

    this.logger.log(`Soft deleted file: ${fileId}`);
  }

  /**
   * Restore deleted file (placeholder - requires schema update)
   */
  async restoreFile(
    fileId: number,
    userId: number,
    version?: number,
  ): Promise<FileWithVersioning> {
    // This would restore a soft-deleted file
    // Requires deletedAt field in schema
    throw new BadRequestException('File restoration requires schema update');
  }

  /**
   * Create new version (placeholder - requires FileVersion model)
   */
  async createVersion(
    fileId: number,
    userId: number,
    dto: CreateFileVersionDto,
  ): Promise<FileVersion> {
    const file = await this.prisma.file.findUnique({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    // Update the file with new URL and size
    await this.prisma.file.update({
      where: { id: fileId },
      data: {
        url: dto.url,
        size: dto.size,
      },
    });

    this.logger.log(`Created new version for file: ${fileId}`);

    // Return mock version (requires FileVersion model)
    return {
      id: 1,
      fileId,
      version: 2,
      url: dto.url,
      size: dto.size,
      checksum: dto.checksum,
      comment: dto.comment,
      createdById: userId,
      createdAt: new Date(),
    };
  }

  /**
   * Get file versions (placeholder - requires FileVersion model)
   */
  async getVersions(fileId: number): Promise<FileVersion[]> {
    const file = await this.prisma.file.findUnique({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    // Return current version as single version
    return [
      {
        id: 1,
        fileId,
        version: 1,
        url: file.url,
        size: file.size,
        createdAt: file.createdAt,
      },
    ];
  }

  /**
   * Log file access
   */
  private async logAccess(
    fileId: number,
    userId: number,
    accessType: FileAccessType,
    ipAddress?: string,
    userAgent?: string,
  ): Promise<void> {
    // In production, this would insert into FileAccessLog table
    this.logger.debug(
      `Access log: file=${fileId}, user=${userId}, type=${accessType}`,
    );
  }

  /**
   * Get access logs for file (placeholder - requires FileAccessLog model)
   */
  async getAccessLogs(fileId: number): Promise<FileAccessLog[]> {
    // Placeholder - requires FileAccessLog model
    return [];
  }

  /**
   * Cleanup expired deleted files (runs daily)
   */
  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async cleanupExpiredFiles(): Promise<void> {
    this.logger.log('Running expired files cleanup...');

    // This would delete files where deletedAt < now - RETENTION_DAYS
    // Requires deletedAt field in schema

    this.logger.log('Expired files cleanup complete');
  }

  /**
   * Get storage usage stats
   */
  async getStorageStats(
    userId?: number,
    projectId?: number,
  ): Promise<{
    totalFiles: number;
    totalSize: number;
    byMimeType: Record<string, { count: number; size: number }>;
  }> {
    const where: any = {};
    if (projectId) where.projectId = projectId;

    const files = await this.prisma.file.findMany({
      where,
      select: { mimeType: true, size: true },
    });

    const byMimeType: Record<string, { count: number; size: number }> = {};

    for (const file of files) {
      const category = file.mimeType.split('/')[0];
      if (!byMimeType[category]) {
        byMimeType[category] = { count: 0, size: 0 };
      }
      byMimeType[category].count++;
      byMimeType[category].size += file.size;
    }

    return {
      totalFiles: files.length,
      totalSize: files.reduce((sum, f) => sum + f.size, 0),
      byMimeType,
    };
  }

  /**
   * Convert Prisma File to FileWithVersioning
   */
  private toFileWithVersioning(file: any): FileWithVersioning {
    return {
      id: file.id,
      filename: file.filename,
      url: file.url,
      mimeType: file.mimeType,
      size: file.size,
      status: FileStatus.ACTIVE,
      version: 1,
      projectId: file.projectId,
      taskId: file.taskId,
      createdAt: file.createdAt,
      updatedAt: file.createdAt, // File model doesn't have updatedAt yet
    };
  }
}
