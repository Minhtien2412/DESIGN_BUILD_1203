import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    ApiCrudErrors,
    ApiDeleteResponse,
    ApiStandardErrors,
} from '../shared/decorators/api-error-responses.decorator';
import {
    CreateFileMetadataDto,
    CreateFileVersionDto,
    FileResponseDto,
    FileVersionResponseDto,
    ListFilesQueryDto,
    RestoreFileDto,
    UpdateFileMetadataDto,
} from './dto/file-metadata.dto';
import { FileMetadataService } from './file-metadata.service';

interface AuthRequest extends Request {
  user: { id: number; email: string };
}

@ApiTags('File Records (legacy)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'file-records', version: '1' })
export class FileMetadataController {
  constructor(private readonly fileMetadataService: FileMetadataService) {}

  @Post()
  @ApiOperation({ summary: 'Create file metadata record' })
  @ApiResponse({
    status: 201,
    description: 'File created',
    type: FileResponseDto,
  })
  @ApiStandardErrors()
  async createFile(
    @Request() req: AuthRequest,
    @Body() dto: CreateFileMetadataDto,
  ): Promise<FileResponseDto> {
    return this.fileMetadataService.createFile(
      req.user.id,
      dto,
    ) as Promise<FileResponseDto>;
  }

  @Get()
  @ApiOperation({ summary: 'List files with filters' })
  @ApiResponse({ status: 200, description: 'Files list' })
  @ApiStandardErrors()
  async listFiles(
    @Request() req: AuthRequest,
    @Query() query: ListFilesQueryDto,
  ) {
    return this.fileMetadataService.listFiles(req.user.id, query);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get storage statistics' })
  @ApiResponse({ status: 200, description: 'Storage stats' })
  @ApiStandardErrors()
  async getStorageStats(
    @Request() req: AuthRequest,
    @Query('projectId') projectId?: number,
  ) {
    return this.fileMetadataService.getStorageStats(req.user.id, projectId);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get file by ID' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({
    status: 200,
    description: 'File details',
    type: FileResponseDto,
  })
  @ApiCrudErrors()
  async getFile(
    @Request() req: AuthRequest,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<FileResponseDto> {
    return this.fileMetadataService.getFile(
      id,
      req.user.id,
    ) as Promise<FileResponseDto>;
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update file metadata' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({
    status: 200,
    description: 'File updated',
    type: FileResponseDto,
  })
  @ApiCrudErrors()
  async updateFile(
    @Request() req: AuthRequest,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateFileMetadataDto,
  ): Promise<FileResponseDto> {
    return this.fileMetadataService.updateFile(
      id,
      req.user.id,
      dto,
    ) as Promise<FileResponseDto>;
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete file' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({ status: 200, description: 'File deleted' })
  @ApiDeleteResponse()
  async deleteFile(
    @Request() req: AuthRequest,
    @Param('id', ParseIntPipe) id: number,
  ): Promise<{ success: boolean }> {
    await this.fileMetadataService.softDeleteFile(id, req.user.id);
    return { success: true };
  }

  @Post(':id/restore')
  @ApiOperation({ summary: 'Restore deleted file' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({
    status: 200,
    description: 'File restored',
    type: FileResponseDto,
  })
  @ApiCrudErrors()
  async restoreFile(
    @Request() req: AuthRequest,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RestoreFileDto,
  ): Promise<FileResponseDto> {
    return this.fileMetadataService.restoreFile(
      id,
      req.user.id,
      dto.version,
    ) as Promise<FileResponseDto>;
  }

  // =====================================================================
  // VERSIONING ENDPOINTS
  // =====================================================================

  @Get(':id/versions')
  @ApiOperation({ summary: 'Get file versions' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({
    status: 200,
    description: 'Version list',
    type: [FileVersionResponseDto],
  })
  @ApiCrudErrors()
  async getVersions(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<FileVersionResponseDto[]> {
    return this.fileMetadataService.getVersions(id) as Promise<
      FileVersionResponseDto[]
    >;
  }

  @Post(':id/versions')
  @ApiOperation({ summary: 'Create new file version' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({
    status: 201,
    description: 'Version created',
    type: FileVersionResponseDto,
  })
  @ApiStandardErrors()
  async createVersion(
    @Request() req: AuthRequest,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CreateFileVersionDto,
  ): Promise<FileVersionResponseDto> {
    return this.fileMetadataService.createVersion(
      id,
      req.user.id,
      dto,
    ) as Promise<FileVersionResponseDto>;
  }

  // =====================================================================
  // ACCESS LOGS
  // =====================================================================

  @Get(':id/access-logs')
  @ApiOperation({ summary: 'Get file access logs' })
  @ApiParam({ name: 'id', type: 'number' })
  @ApiResponse({ status: 200, description: 'Access logs' })
  @ApiStandardErrors()
  async getAccessLogs(@Param('id', ParseIntPipe) id: number) {
    return this.fileMetadataService.getAccessLogs(id);
  }
}
