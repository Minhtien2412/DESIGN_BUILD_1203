import {
    BadRequestException,
    Body,
    Controller,
    Delete,
    Get,
    Headers,
    Param,
    ParseIntPipe,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiExcludeEndpoint,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import type { Request } from 'express';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { AcbPaymentService } from './acb-payment.service';
import {
    CreatePaymentDto,
    CreateSubscriptionDto,
    InitPaymentDto,
    PaymentIntentResponseDto,
    PaymentResponseDto,
    PaymentStatusDto,
    SubscriptionResponseDto,
} from './dto';
import { MomoPaymentService } from './momo-payment.service';
import { PaymentService } from './payment.service';
import { VnpayPaymentService } from './vnpay-payment.service';

@ApiTags('Payment')
@Controller({ path: 'payment', version: '1' })
export class PaymentController {
  constructor(
    private readonly paymentService: PaymentService,
    private readonly acbPaymentService: AcbPaymentService,
    private readonly vnpayPaymentService: VnpayPaymentService,
    private readonly momoPaymentService: MomoPaymentService,
  ) {}

  // ========================
  // Unified Payment Gateway
  // ========================

  @Post('init')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khởi tạo thanh toán (Unified - tất cả gateway)' })
  @ApiResponse({
    status: 201,
    description: 'Payment đã được khởi tạo',
    type: PaymentStatusDto,
  })
  async initPayment(
    @Body() dto: InitPaymentDto,
    @CurrentUser('id') userId: number,
  ): Promise<PaymentStatusDto> {
    switch (dto.gateway) {
      case 'VNPAY': {
        const result = await this.vnpayPaymentService.createPaymentUrl({
          amount: dto.amount,
          orderId: dto.orderId,
          description: dto.description,
          returnUrl: dto.returnUrl,
          ipnUrl: dto.notifyUrl,
          bankCode: dto.bankCode,
          locale: dto.locale,
          userId,
          projectId: dto.projectId,
        });
        return {
          transactionId: result.transactionId,
          orderId: result.orderId,
          amount: result.amount,
          status: 'PENDING',
          gateway: 'VNPAY',
          paymentUrl: result.paymentUrl,
          message: result.message,
        };
      }
      case 'ACB': {
        const result = await this.acbPaymentService.initiatePayment({
          amount: dto.amount,
          orderId: dto.orderId,
          description: dto.description,
          returnUrl: dto.returnUrl,
          notifyUrl: dto.notifyUrl,
          userId,
          projectId: dto.projectId,
        });
        return {
          transactionId: result.transactionId,
          orderId: result.orderId,
          amount: result.amount,
          status: 'PENDING',
          gateway: 'ACB',
          paymentUrl: result.paymentUrl,
          qrCodeUrl: result.qrCodeUrl,
          message: result.message,
        };
      }
      case 'STRIPE': {
        const intent = await this.paymentService.createPaymentIntent(
          {
            amount: dto.amount,
            currency: 'VND',
            paymentMethod: 'STRIPE',
            projectId: dto.projectId,
            description: dto.description,
          },
          userId,
        );
        return {
          transactionId: intent.paymentIntentId,
          orderId: dto.orderId,
          amount: dto.amount,
          status: 'PENDING',
          gateway: 'STRIPE',
          paymentUrl: intent.clientSecret,
          message: 'Use Stripe SDK with clientSecret',
        };
      }
      case 'MOMO': {
        const result = await this.momoPaymentService.createPayment({
          amount: dto.amount,
          orderId: dto.orderId,
          description: dto.description,
          returnUrl: dto.returnUrl,
          ipnUrl: dto.notifyUrl,
          userId,
          projectId: dto.projectId,
          lang: dto.locale,
        });
        return {
          transactionId: result.transactionId,
          orderId: result.orderId,
          amount: result.amount,
          status: 'PENDING',
          gateway: 'MOMO',
          paymentUrl: result.paymentUrl,
          qrCodeUrl: result.qrCodeUrl,
          message: result.message,
        };
      }
      default:
        throw new BadRequestException(
          `Gateway ${dto.gateway} not supported via unified endpoint`,
        );
    }
  }

  @Get('status/:orderId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Kiểm tra trạng thái thanh toán theo orderId' })
  @ApiResponse({
    status: 200,
    description: 'Trạng thái thanh toán',
    type: PaymentStatusDto,
  })
  async getPaymentStatus(@Param('orderId') orderId: string) {
    // Check VNPay first, then fall through to Prisma payment records
    const payment = await this.paymentService.findByOrderId(orderId);
    if (!payment) {
      throw new BadRequestException(`No payment found for order ${orderId}`);
    }
    return {
      transactionId: payment.transactionId || payment.stripePaymentIntentId,
      orderId: payment.orderId || orderId,
      amount: payment.amount,
      status: payment.status,
      gateway: payment.gateway || 'UNKNOWN',
      paidAt: payment.paidAt || payment.updatedAt,
      message:
        payment.status === 'COMPLETED' ? 'Thanh toán thành công' : 'Đang xử lý',
    };
  }

  // ========================
  // Stripe Endpoints
  // ========================

  @Post('stripe/intent')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo Payment Intent (one-time payment)' })
  @ApiResponse({
    status: 201,
    description: 'Payment Intent đã được tạo',
    type: PaymentIntentResponseDto,
  })
  async createPaymentIntent(
    @Body() createPaymentDto: CreatePaymentDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.createPaymentIntent(createPaymentDto, userId);
  }

  @Post('stripe/intent/:paymentIntentId/confirm')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Confirm payment sau khi client hoàn thành trên Stripe',
  })
  @ApiResponse({
    status: 200,
    description: 'Payment đã được confirm',
    type: PaymentResponseDto,
  })
  async confirmPayment(@Param('paymentIntentId') paymentIntentId: string) {
    return this.paymentService.confirmPayment(paymentIntentId);
  }

  @Post('stripe/subscription')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo subscription (recurring payment)' })
  @ApiResponse({
    status: 201,
    description: 'Subscription đã được tạo',
    type: SubscriptionResponseDto,
  })
  async createSubscription(
    @Body() createSubscriptionDto: CreateSubscriptionDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.createSubscription(
      createSubscriptionDto,
      userId,
    );
  }

  @Delete('stripe/subscription/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy subscription' })
  @ApiResponse({ status: 200, description: 'Subscription đã được hủy' })
  async cancelSubscription(
    @Param('id', ParseIntPipe) subscriptionId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.cancelSubscription(subscriptionId, userId);
  }

  @Get('history')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy lịch sử thanh toán của user' })
  @ApiResponse({
    status: 200,
    description: 'Lịch sử thanh toán',
    type: [PaymentResponseDto],
  })
  async getPaymentHistory(@CurrentUser('id') userId: number) {
    return this.paymentService.getPaymentHistory(userId);
  }

  @Get('subscriptions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách subscriptions của user' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách subscriptions',
    type: [SubscriptionResponseDto],
  })
  async getUserSubscriptions(@CurrentUser('id') userId: number) {
    return this.paymentService.getUserSubscriptions(userId);
  }

  @Post('stripe/refund/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Refund payment' })
  @ApiResponse({
    status: 200,
    description: 'Payment đã được refund',
    type: PaymentResponseDto,
  })
  async refundPayment(
    @Param('id', ParseIntPipe) paymentId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.refundPayment(paymentId, userId);
  }

  @Post('stripe/webhook')
  @ApiExcludeEndpoint()
  async handleWebhook(
    @Headers('stripe-signature') signature: string,
    @Req() req: Request & { rawBody?: Buffer },
  ) {
    if (!req.rawBody) {
      throw new BadRequestException('Raw body is required for webhook');
    }
    return this.paymentService.handleWebhook(signature, req.rawBody);
  }

  // ========================
  // ACB ONE Connect Endpoints
  // ========================

  @Post('acb/init')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Khởi tạo thanh toán ACB ONE Connect' })
  @ApiResponse({ status: 201, description: 'ACB payment đã được khởi tạo' })
  async initiateAcbPayment(
    @Body()
    body: {
      amount: number;
      orderId: string;
      description: string;
      returnUrl?: string;
      notifyUrl?: string;
      projectId?: number;
    },
    @CurrentUser('id') userId: number,
  ) {
    return this.acbPaymentService.initiatePayment({
      ...body,
      userId,
    });
  }

  @Post('acb/qr')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo QR code thanh toán ACB (VietQR)' })
  @ApiResponse({ status: 201, description: 'QR code đã được tạo' })
  async generateAcbQr(
    @Body()
    body: {
      amount: number;
      orderId: string;
      description: string;
      projectId?: number;
    },
    @CurrentUser('id') userId: number,
  ) {
    return this.acbPaymentService.generateQrCode({
      ...body,
      userId,
    });
  }

  @Get('acb/verify/:transactionId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Kiểm tra trạng thái thanh toán ACB' })
  @ApiResponse({ status: 200, description: 'Trạng thái thanh toán' })
  async verifyAcbPayment(@Param('transactionId') transactionId: string) {
    return this.acbPaymentService.verifyPayment(transactionId);
  }

  @Post('acb/callback')
  @ApiExcludeEndpoint()
  async handleAcbCallback(@Body() body: any) {
    return this.acbPaymentService.handleCallback(body);
  }

  // ========================
  // VNPay Endpoints
  // ========================

  @Post('vnpay/init')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo URL thanh toán VNPay' })
  @ApiResponse({ status: 201, description: 'VNPay payment URL đã được tạo' })
  async initiateVnpayPayment(
    @Body()
    body: {
      amount: number;
      orderId: string;
      description: string;
      returnUrl?: string;
      ipnUrl?: string;
      bankCode?: string;
      locale?: string;
      orderType?: string;
      projectId?: number;
    },
    @CurrentUser('id') userId: number,
  ) {
    return this.vnpayPaymentService.createPaymentUrl({
      ...body,
      userId,
    });
  }

  @Get('vnpay/return')
  @ApiOperation({ summary: 'VNPay Return URL - xác minh kết quả thanh toán' })
  @ApiResponse({ status: 200, description: 'Kết quả xác minh' })
  async vnpayReturn(@Query() query: Record<string, string>) {
    return this.vnpayPaymentService.verifyReturnUrl(query);
  }

  @Get('vnpay/ipn')
  @ApiExcludeEndpoint()
  async vnpayIpn(@Query() query: Record<string, string>) {
    return this.vnpayPaymentService.handleIpn(query);
  }

  @Post('vnpay/query')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Truy vấn kết quả giao dịch VNPay' })
  @ApiResponse({ status: 200, description: 'Kết quả truy vấn giao dịch' })
  async vnpayQuery(@Body() body: { orderId: string; transDate: string }) {
    return this.vnpayPaymentService.queryTransaction(
      body.orderId,
      body.transDate,
    );
  }

  @Post('vnpay/refund')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hoàn tiền giao dịch VNPay' })
  @ApiResponse({ status: 200, description: 'Kết quả hoàn tiền' })
  async vnpayRefund(
    @Body()
    body: {
      orderId: string;
      amount: number;
      transactionNo: string;
      transDate: string;
      transactionType?: '02' | '03';
    },
    @CurrentUser('id') userId: number,
  ) {
    return this.vnpayPaymentService.refundTransaction({
      ...body,
      createBy: `user-${userId}`,
    });
  }

  @Get('vnpay/banks')
  @ApiOperation({ summary: 'Danh sách ngân hàng hỗ trợ VNPay' })
  @ApiResponse({ status: 200, description: 'Danh sách ngân hàng' })
  async vnpayBanks() {
    return this.vnpayPaymentService.getSupportedBanks();
  }

  // ========================
  // MoMo Endpoints
  // ========================

  @Post('momo/init')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Tạo thanh toán MoMo (captureWallet / payWithMethod)',
  })
  @ApiResponse({ status: 201, description: 'MoMo payment đã được tạo' })
  async initiateMomoPayment(
    @Body()
    body: {
      amount: number;
      orderId: string;
      description: string;
      returnUrl?: string;
      ipnUrl?: string;
      requestType?: 'captureWallet' | 'payWithMethod';
      projectId?: number;
    },
    @CurrentUser('id') userId: number,
  ) {
    return this.momoPaymentService.createPayment({
      ...body,
      userId,
    });
  }

  @Get('momo/return')
  @ApiOperation({ summary: 'MoMo Return URL - xác minh kết quả thanh toán' })
  @ApiResponse({ status: 200, description: 'Kết quả xác minh' })
  async momoReturn(@Query() query: Record<string, string>) {
    return this.momoPaymentService.verifyReturn(query);
  }

  @Post('momo/ipn')
  @ApiExcludeEndpoint()
  async momoIpn(@Body() body: any) {
    return this.momoPaymentService.handleIpn(body);
  }

  @Post('momo/query')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Truy vấn trạng thái giao dịch MoMo' })
  @ApiResponse({ status: 200, description: 'Kết quả truy vấn' })
  async momoQuery(@Body() body: { orderId: string }) {
    return this.momoPaymentService.queryTransaction(body.orderId);
  }

  @Post('momo/refund')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hoàn tiền giao dịch MoMo' })
  @ApiResponse({ status: 200, description: 'Kết quả hoàn tiền' })
  async momoRefund(
    @Body()
    body: {
      orderId: string;
      amount: number;
      transId: number;
      description?: string;
    },
  ) {
    return this.momoPaymentService.refundTransaction(body);
  }
}
