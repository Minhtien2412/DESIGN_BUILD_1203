import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { AcbPaymentService } from './acb-payment.service';
import { MomoPaymentService } from './momo-payment.service';
import { PaymentController } from './payment.controller';
import { PaymentService } from './payment.service';
import { VnpayPaymentService } from './vnpay-payment.service';

@Module({
  imports: [PrismaModule],
  controllers: [PaymentController],
  providers: [
    PaymentService,
    AcbPaymentService,
    VnpayPaymentService,
    MomoPaymentService,
  ],
  exports: [
    PaymentService,
    AcbPaymentService,
    VnpayPaymentService,
    MomoPaymentService,
  ],
})
export class PaymentModule {}
