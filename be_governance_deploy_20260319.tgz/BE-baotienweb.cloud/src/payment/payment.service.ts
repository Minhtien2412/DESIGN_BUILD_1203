import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePaymentDto, CreateSubscriptionDto } from './dto';

@Injectable()
export class PaymentService {
  private stripe: Stripe | null = null;
  private readonly logger = new Logger(PaymentService.name);

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    const stripeSecretKey = this.configService.get<string>('STRIPE_SECRET_KEY');
    if (!stripeSecretKey) {
      this.logger.warn(
        '⚠️ STRIPE_SECRET_KEY not configured - Payment features disabled',
      );
    } else {
      this.stripe = new Stripe(stripeSecretKey, {
        apiVersion: '2025-11-17.clover',
      });
    }
  }

  private ensureStripeConfigured() {
    if (!this.stripe) {
      throw new BadRequestException(
        'Payment system not configured. Please set STRIPE_SECRET_KEY.',
      );
    }
  }

  // Tạo Payment Intent (cho one-time payment)
  async createPaymentIntent(
    createPaymentDto: CreatePaymentDto,
    userId: number,
  ) {
    this.ensureStripeConfigured();
    const {
      amount,
      currency = 'VND',
      paymentMethod,
      projectId,
      description,
    } = createPaymentDto;

    // Kiểm tra project nếu có
    if (projectId) {
      const project = await this.prisma.project.findUnique({
        where: { id: projectId },
      });
      if (!project) {
        throw new NotFoundException(
          `Project với ID ${projectId} không tồn tại`,
        );
      }
    }

    // Tạo Payment Intent với Stripe
    const paymentIntent = await this.stripe!.paymentIntents.create({
      amount: Math.round(amount), // Stripe yêu cầu số nguyên (smallest currency unit)
      currency: currency.toLowerCase(),
      metadata: {
        userId: userId.toString(),
        projectId: projectId?.toString() || '',
        paymentMethod,
      },
      description: description || 'Payment for project',
    });

    // Lưu vào database
    const payment = await this.prisma.payment.create({
      data: {
        amount,
        currency,
        status: 'PENDING',
        paymentMethod: paymentMethod as any,
        stripePaymentId: paymentIntent.id,
        description,
        userId,
        projectId,
        metadata: {
          clientSecret: paymentIntent.client_secret,
        },
      },
    });

    return {
      paymentIntentId: paymentIntent.id,
      clientSecret: paymentIntent.client_secret,
      amount,
      currency,
      paymentId: payment.id,
    };
  }

  // Confirm Payment (sau khi client confirm trên Stripe)
  async confirmPayment(paymentIntentId: string) {
    const payment = await this.prisma.payment.findUnique({
      where: { stripePaymentId: paymentIntentId },
    });

    if (!payment) {
      throw new NotFoundException('Payment không tồn tại');
    }

    // Retrieve payment intent từ Stripe
    this.ensureStripeConfigured();
    const paymentIntent =
      await this.stripe!.paymentIntents.retrieve(paymentIntentId);

    let status: 'PENDING' | 'COMPLETED' | 'FAILED' = 'PENDING';
    if (paymentIntent.status === 'succeeded') {
      status = 'COMPLETED';
    } else if (
      paymentIntent.status === 'canceled' ||
      paymentIntent.status === 'requires_payment_method'
    ) {
      status = 'FAILED';
    }

    // Cập nhật status
    const updatedPayment = await this.prisma.payment.update({
      where: { id: payment.id },
      data: {
        status,
        paidAt: status === 'COMPLETED' ? new Date() : null,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        project: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    return updatedPayment;
  }

  // Tạo Subscription
  async createSubscription(
    createSubscriptionDto: CreateSubscriptionDto,
    userId: number,
  ) {
    const {
      planName,
      amount,
      currency = 'VND',
      interval,
    } = createSubscriptionDto;

    // Lấy user để có email
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException('User không tồn tại');
    }

    // Tạo hoặc lấy Stripe Customer
    this.ensureStripeConfigured();
    let customer: Stripe.Customer;
    const existingCustomers = await this.stripe!.customers.list({
      email: user.email,
      limit: 1,
    });

    if (existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await this.stripe!.customers.create({
        email: user.email,
        name: user.name || undefined,
        metadata: {
          userId: userId.toString(),
        },
      });
    }

    // Tạo Price (product pricing)
    const price = await this.stripe!.prices.create({
      unit_amount: Math.round(amount),
      currency: currency.toLowerCase(),
      recurring: {
        interval: interval as 'month' | 'year',
      },
      product_data: {
        name: planName,
      },
    });

    // Tạo Subscription
    const subscription = await this.stripe!.subscriptions.create({
      customer: customer.id,
      items: [{ price: price.id }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
    });

    // Lưu vào database
    const currentPeriodStart = new Date(
      (subscription as any).current_period_start * 1000,
    );
    const currentPeriodEnd = new Date(
      (subscription as any).current_period_end * 1000,
    );

    const subscriptionRecord = await this.prisma.subscription.create({
      data: {
        planName,
        amount,
        currency,
        interval,
        status: 'ACTIVE',
        stripeSubscriptionId: subscription.id,
        currentPeriodStart,
        currentPeriodEnd,
        userId,
      },
    });

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const paymentIntent = (invoice as any)
      ?.payment_intent as Stripe.PaymentIntent;

    return {
      subscriptionId: subscriptionRecord.id,
      stripeSubscriptionId: subscription.id,
      clientSecret: paymentIntent?.client_secret,
      currentPeriodStart,
      currentPeriodEnd,
    };
  }

  // Cancel Subscription
  async cancelSubscription(subscriptionId: number, userId: number) {
    const subscription = await this.prisma.subscription.findFirst({
      where: {
        id: subscriptionId,
        userId,
      },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription không tồn tại');
    }

    if (subscription.status === 'CANCELLED') {
      throw new BadRequestException('Subscription đã bị hủy');
    }

    // Cancel trên Stripe
    if (subscription.stripeSubscriptionId) {
      this.ensureStripeConfigured();
      await this.stripe!.subscriptions.cancel(
        subscription.stripeSubscriptionId,
      );
    }

    // Cập nhật database
    const updatedSubscription = await this.prisma.subscription.update({
      where: { id: subscriptionId },
      data: {
        status: 'CANCELLED',
        canceledAt: new Date(),
      },
    });

    return updatedSubscription;
  }

  // Lấy payment history của user
  async getPaymentHistory(userId: number) {
    const payments = await this.prisma.payment.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        project: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    return payments;
  }

  // Tìm payment theo orderId
  async findByOrderId(orderId: string) {
    return this.prisma.payment.findFirst({
      where: {
        OR: [
          { orderId },
          { transactionId: orderId },
          { stripePaymentId: orderId },
          { stripePaymentIntentId: orderId },
        ],
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  // Lấy subscriptions của user
  async getUserSubscriptions(userId: number) {
    const subscriptions = await this.prisma.subscription.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    return subscriptions;
  }

  // Handle Stripe Webhook
  async handleWebhook(signature: string, rawBody: Buffer) {
    const webhookSecret = this.configService.get<string>(
      'STRIPE_WEBHOOK_SECRET',
    );
    if (!webhookSecret) {
      throw new BadRequestException('STRIPE_WEBHOOK_SECRET is not configured');
    }

    this.ensureStripeConfigured();
    let event: Stripe.Event;

    try {
      event = this.stripe!.webhooks.constructEvent(
        rawBody,
        signature,
        webhookSecret,
      );
    } catch (err) {
      throw new BadRequestException(
        `Webhook signature verification failed: ${err.message}`,
      );
    }

    // Handle different event types
    switch (event.type) {
      case 'payment_intent.succeeded':
        await this.handlePaymentIntentSucceeded(event.data.object);
        break;

      case 'payment_intent.payment_failed':
        await this.handlePaymentIntentFailed(event.data.object);
        break;

      case 'invoice.payment_succeeded':
        await this.handleInvoicePaymentSucceeded(event.data.object);
        break;

      case 'customer.subscription.updated':
        await this.handleSubscriptionUpdated(event.data.object);
        break;

      case 'customer.subscription.deleted':
        await this.handleSubscriptionDeleted(event.data.object);
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return { received: true };
  }

  private async handlePaymentIntentSucceeded(
    paymentIntent: Stripe.PaymentIntent,
  ) {
    await this.prisma.payment.updateMany({
      where: { stripePaymentId: paymentIntent.id },
      data: {
        status: 'COMPLETED',
        paidAt: new Date(),
      },
    });
  }

  private async handlePaymentIntentFailed(paymentIntent: Stripe.PaymentIntent) {
    await this.prisma.payment.updateMany({
      where: { stripePaymentId: paymentIntent.id },
      data: {
        status: 'FAILED',
      },
    });
  }

  private async handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
    if ((invoice as any).subscription) {
      await this.prisma.subscription.updateMany({
        where: {
          stripeSubscriptionId: (invoice as any).subscription as string,
        },
        data: {
          status: 'ACTIVE',
        },
      });
    }
  }

  private async handleSubscriptionUpdated(subscription: Stripe.Subscription) {
    const currentPeriodStart = new Date(
      (subscription as any).current_period_start * 1000,
    );
    const currentPeriodEnd = new Date(
      (subscription as any).current_period_end * 1000,
    );

    let status: 'ACTIVE' | 'CANCELLED' | 'EXPIRED' | 'PAST_DUE' = 'ACTIVE';
    if (subscription.status === 'canceled') {
      status = 'CANCELLED';
    } else if (subscription.status === 'past_due') {
      status = 'PAST_DUE';
    }

    await this.prisma.subscription.updateMany({
      where: { stripeSubscriptionId: subscription.id },
      data: {
        status,
        currentPeriodStart,
        currentPeriodEnd,
      },
    });
  }

  private async handleSubscriptionDeleted(subscription: Stripe.Subscription) {
    await this.prisma.subscription.updateMany({
      where: { stripeSubscriptionId: subscription.id },
      data: {
        status: 'CANCELLED',
        canceledAt: new Date(),
      },
    });
  }

  // Refund payment
  async refundPayment(paymentId: number, userId: number) {
    const payment = await this.prisma.payment.findFirst({
      where: {
        id: paymentId,
        userId,
      },
    });

    if (!payment) {
      throw new NotFoundException('Payment không tồn tại');
    }

    if (payment.status !== 'COMPLETED') {
      throw new BadRequestException('Chỉ có thể refund payment đã hoàn thành');
    }

    if (!payment.stripePaymentId) {
      throw new BadRequestException('Payment không có Stripe Payment ID');
    }

    // Tạo refund trên Stripe
    this.ensureStripeConfigured();
    const refund = await this.stripe!.refunds.create({
      payment_intent: payment.stripePaymentId,
    });

    // Cập nhật database
    const updatedPayment = await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        status: 'REFUNDED',
        metadata: {
          ...(payment.metadata as any),
          refundId: refund.id,
          refundedAt: new Date().toISOString(),
        },
      },
    });

    return updatedPayment;
  }
}
