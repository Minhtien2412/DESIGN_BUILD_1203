import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

/**
 * Unified Payment Init DTO
 * Dùng cho tất cả gateway: VNPay, ACB, MoMo, Stripe
 */

export enum UnifiedPaymentGateway {
  VNPAY = 'VNPAY',
  ACB = 'ACB',
  MOMO = 'MOMO',
  STRIPE = 'STRIPE',
  BANK_TRANSFER = 'BANK_TRANSFER',
}

export class InitPaymentDto {
  @ApiProperty({ description: 'Cổng thanh toán', enum: UnifiedPaymentGateway })
  @IsEnum(UnifiedPaymentGateway)
  @IsNotEmpty()
  gateway: UnifiedPaymentGateway;

  @ApiProperty({ description: 'Số tiền thanh toán (VND)', example: 500000 })
  @IsNumber()
  @Min(1000)
  amount: number;

  @ApiProperty({ description: 'Mã đơn hàng', example: 'ORD-20260307-001' })
  @IsString()
  @IsNotEmpty()
  orderId: string;

  @ApiProperty({
    description: 'Mô tả thanh toán',
    example: 'Thanh toán đơn hàng ORD-001',
  })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiPropertyOptional({ description: 'URL trả về sau thanh toán' })
  @IsString()
  @IsOptional()
  returnUrl?: string;

  @ApiPropertyOptional({ description: 'URL webhook/IPN' })
  @IsString()
  @IsOptional()
  notifyUrl?: string;

  @ApiPropertyOptional({ description: 'ID project (nếu có)' })
  @IsNumber()
  @IsOptional()
  projectId?: number;

  @ApiPropertyOptional({ description: 'Mã ngân hàng (VNPay)', example: 'NCB' })
  @IsString()
  @IsOptional()
  bankCode?: string;

  @ApiPropertyOptional({ description: 'Ngôn ngữ', example: 'vn' })
  @IsString()
  @IsOptional()
  locale?: string;
}

export class PaymentStatusDto {
  @ApiProperty({ description: 'Mã giao dịch' })
  transactionId: string;

  @ApiProperty({ description: 'Mã đơn hàng' })
  orderId: string;

  @ApiProperty({ description: 'Số tiền' })
  amount: number;

  @ApiProperty({ description: 'Trạng thái', example: 'PAID' })
  status: string;

  @ApiProperty({ description: 'Cổng thanh toán' })
  gateway: string;

  @ApiPropertyOptional({ description: 'Thời gian thanh toán' })
  paidAt?: string;

  @ApiPropertyOptional({ description: 'URL thanh toán (nếu pending)' })
  paymentUrl?: string;

  @ApiPropertyOptional({ description: 'QR code URL' })
  qrCodeUrl?: string;

  @ApiProperty({ description: 'Thông báo' })
  message: string;
}
