import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsNumber,
  IsEnum,
  IsOptional,
  Min,
} from 'class-validator';

export class CreateSubscriptionDto {
  @ApiProperty({ description: 'Tên gói đăng ký', example: 'Premium Plan' })
  @IsString()
  @IsNotEmpty()
  planName: string;

  @ApiProperty({ description: 'Số tiền', example: 299000 })
  @IsNumber()
  @IsNotEmpty()
  @Min(1000)
  amount: number;

  @ApiPropertyOptional({
    description: 'Đơn vị tiền tệ',
    example: 'VND',
    default: 'VND',
  })
  @IsString()
  @IsOptional()
  currency?: string;

  @ApiProperty({
    description: 'Chu kỳ thanh toán',
    example: 'monthly',
    enum: ['monthly', 'yearly'],
  })
  @IsEnum(['monthly', 'yearly'])
  @IsNotEmpty()
  interval: string;
}
