import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

export class CreatePaymentDto {
  @ApiProperty({ description: 'Số tiền thanh toán', example: 500000 })
  @IsNumber()
  @IsNotEmpty()
  @Min(1000)
  amount: number;

  @ApiPropertyOptional({
    description: 'Đơn vị tiền tệ',
    example: 'VND',
    default: 'VND',
  })
  @IsString()
  @IsOptional()
  currency?: string;

  @ApiProperty({
    description: 'Phương thức thanh toán',
    example: 'STRIPE',
    enum: ['CREDIT_CARD', 'BANK_TRANSFER', 'PAYPAL', 'STRIPE', 'ACB'],
  })
  @IsEnum(['CREDIT_CARD', 'BANK_TRANSFER', 'PAYPAL', 'STRIPE', 'ACB'])
  @IsNotEmpty()
  paymentMethod: string;

  @ApiPropertyOptional({
    description: 'ID của project (nếu thanh toán cho project)',
    example: 1,
  })
  @IsInt()
  @IsOptional()
  projectId?: number;

  @ApiPropertyOptional({
    description: 'Mô tả thanh toán',
    example: 'Thanh toán cho dự án Website',
  })
  @IsString()
  @IsOptional()
  description?: string;
}
