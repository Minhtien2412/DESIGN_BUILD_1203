import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class PaymentResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 500000 })
  amount: number;

  @ApiProperty({ example: 'VND' })
  currency: string;

  @ApiProperty({
    example: 'COMPLETED',
    enum: ['PENDING', 'COMPLETED', 'FAILED', 'REFUNDED', 'CANCELLED'],
  })
  status: string;

  @ApiProperty({
    example: 'STRIPE',
    enum: ['CREDIT_CARD', 'BANK_TRANSFER', 'PAYPAL', 'STRIPE'],
  })
  paymentMethod: string;

  @ApiPropertyOptional({ example: 'pi_1234567890' })
  stripePaymentId?: string;

  @ApiPropertyOptional({ example: 'Thanh toán cho dự án Website' })
  description?: string;

  @ApiProperty({ example: 1 })
  userId: number;

  @ApiPropertyOptional({ example: 1 })
  projectId?: number;

  @ApiPropertyOptional({ example: '2024-01-01T00:00:00.000Z' })
  paidAt?: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  updatedAt: Date;
}

export class SubscriptionResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 'Premium Plan' })
  planName: string;

  @ApiProperty({ example: 299000 })
  amount: number;

  @ApiProperty({ example: 'VND' })
  currency: string;

  @ApiProperty({ example: 'monthly' })
  interval: string;

  @ApiProperty({
    example: 'ACTIVE',
    enum: ['ACTIVE', 'CANCELLED', 'EXPIRED', 'PAST_DUE'],
  })
  status: string;

  @ApiPropertyOptional({ example: 'sub_1234567890' })
  stripeSubscriptionId?: string;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  currentPeriodStart: Date;

  @ApiProperty({ example: '2024-02-01T00:00:00.000Z' })
  currentPeriodEnd: Date;

  @ApiProperty({ example: 1 })
  userId: number;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  createdAt: Date;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  updatedAt: Date;
}

export class PaymentIntentResponseDto {
  @ApiProperty({ example: 'pi_1234567890' })
  paymentIntentId: string;

  @ApiProperty({ example: 'client_secret_1234567890' })
  clientSecret: string;

  @ApiProperty({ example: 500000 })
  amount: number;

  @ApiProperty({ example: 'VND' })
  currency: string;
}
