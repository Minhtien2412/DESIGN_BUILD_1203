import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';

/**
 * VNPay Payment Service
 * =====================
 * Tích hợp Cổng thanh toán VNPAY (v2.1.0)
 * Docs: https://sandbox.vnpayment.vn/apis/docs/thanh-toan-pay/pay.html
 *
 * Hỗ trợ:
 * - Thanh toán PAY (one-time)
 * - Thanh toán bằng mã Token
 * - Truy vấn kết quả giao dịch (querydr)
 * - Hoàn tiền (refund)
 * - Danh sách ngân hàng
 */

export interface VnpayPaymentInitDto {
  amount: number;
  orderId: string;
  description: string;
  returnUrl?: string;
  ipnUrl?: string;
  userId?: number;
  projectId?: number;
  bankCode?: string; // Mã ngân hàng (NCB, VNPAYQR, etc.)
  locale?: string; // vn | en
  orderType?: string; // topup | billpayment | fashion | other
}

export interface VnpayPaymentResult {
  gateway: 'VNPAY';
  paymentUrl: string;
  transactionId: string;
  orderId: string;
  amount: number;
  message: string;
}

export interface VnpayQueryResult {
  transactionId: string;
  orderId: string;
  amount: number;
  status: string; // 00 = success, others = fail
  bankCode?: string;
  bankTranNo?: string;
  cardType?: string;
  payDate?: string;
  message: string;
}

export interface VnpayRefundResult {
  success: boolean;
  refundId: string;
  amount: number;
  message: string;
}

@Injectable()
export class VnpayPaymentService {
  private readonly logger = new Logger(VnpayPaymentService.name);

  private readonly tmnCode: string;
  private readonly hashSecret: string;
  private readonly payUrl: string;
  private readonly apiUrl: string;
  private readonly defaultReturnUrl: string;
  private readonly defaultIpnUrl: string;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.tmnCode = this.configService.get<string>('VNPAY_TMN_CODE') || '';
    this.hashSecret = this.configService.get<string>('VNPAY_HASH_SECRET') || '';
    this.payUrl =
      this.configService.get<string>('VNPAY_URL') ||
      'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html';
    this.apiUrl =
      this.configService.get<string>('VNPAY_API_URL') ||
      'https://sandbox.vnpayment.vn/merchant_webapi/api/transaction';
    this.defaultReturnUrl =
      this.configService.get<string>('VNPAY_RETURN_URL') || '';
    this.defaultIpnUrl = this.configService.get<string>('VNPAY_IPN_URL') || '';

    if (!this.tmnCode || !this.hashSecret) {
      this.logger.warn(
        '⚠️ VNPAY credentials not configured - VNPay payment disabled',
      );
    } else {
      this.logger.log('✅ VNPay payment gateway initialized');
    }
  }

  private isConfigured(): boolean {
    return !!(this.tmnCode && this.hashSecret);
  }

  private ensureConfigured() {
    if (!this.isConfigured()) {
      throw new BadRequestException(
        'VNPay payment gateway not configured. Please set VNPAY_TMN_CODE and VNPAY_HASH_SECRET.',
      );
    }
  }

  /**
   * Sort object keys alphabetically
   */
  private sortObject(obj: Record<string, any>): Record<string, any> {
    const sorted: Record<string, any> = {};
    const keys = Object.keys(obj).sort();
    keys.forEach((key) => {
      sorted[key] = obj[key];
    });
    return sorted;
  }

  /**
   * Generate HMAC-SHA512 signature (VNPay standard)
   */
  private generateSignature(data: string): string {
    return crypto
      .createHmac('sha512', this.hashSecret)
      .update(Buffer.from(data, 'utf-8'))
      .digest('hex');
  }

  /**
   * Format date to VNPay format: yyyyMMddHHmmss
   */
  private formatDate(date: Date): string {
    return date
      .toISOString()
      .replace(/[-:T.Z]/g, '')
      .slice(0, 14);
  }

  // ================================================================
  // 1. THANH TOÁN PAY - Create Payment URL
  // ================================================================

  /**
   * Tạo URL thanh toán VNPay
   * User sẽ được redirect đến VNPay để thanh toán
   */
  async createPaymentUrl(
    dto: VnpayPaymentInitDto,
  ): Promise<VnpayPaymentResult> {
    this.ensureConfigured();

    const transactionId = `VNPAY-${dto.orderId}-${Date.now()}`;
    const createDate = this.formatDate(new Date());
    const expireDate = this.formatDate(new Date(Date.now() + 15 * 60 * 1000)); // 15 minutes

    let vnpParams: Record<string, any> = {
      vnp_Version: '2.1.0',
      vnp_Command: 'pay',
      vnp_TmnCode: this.tmnCode,
      vnp_Locale: dto.locale || 'vn',
      vnp_CurrCode: 'VND',
      vnp_TxnRef: dto.orderId,
      vnp_OrderInfo: (
        dto.description || `Thanh toan don hang ${dto.orderId}`
      ).slice(0, 255),
      vnp_OrderType: dto.orderType || 'other',
      vnp_Amount: Math.round(dto.amount) * 100, // VNPay yêu cầu amount * 100
      vnp_ReturnUrl: dto.returnUrl || this.defaultReturnUrl,
      vnp_IpAddr: '127.0.0.1',
      vnp_CreateDate: createDate,
      vnp_ExpireDate: expireDate,
    };

    // Optional: specify bank code for direct bank payment
    if (dto.bankCode) {
      vnpParams['vnp_BankCode'] = dto.bankCode;
    }

    // IPN URL for server-to-server notification
    if (dto.ipnUrl || this.defaultIpnUrl) {
      vnpParams['vnp_IpnUrl'] = dto.ipnUrl || this.defaultIpnUrl;
    }

    // Sort params and generate signature
    vnpParams = this.sortObject(vnpParams);
    const signData = new URLSearchParams(vnpParams).toString();
    const secureHash = this.generateSignature(signData);

    vnpParams['vnp_SecureHash'] = secureHash;

    const paymentUrl = `${this.payUrl}?${new URLSearchParams(vnpParams).toString()}`;

    // Save payment record
    await this.savePaymentRecord({
      transactionId,
      orderId: dto.orderId,
      amount: dto.amount,
      userId: dto.userId,
      projectId: dto.projectId,
      status: 'PENDING',
    });

    this.logger.log(
      `VNPay payment created: ${dto.orderId}, amount: ${dto.amount}`,
    );

    return {
      gateway: 'VNPAY',
      paymentUrl,
      transactionId,
      orderId: dto.orderId,
      amount: dto.amount,
      message: 'Redirect to VNPay for payment',
    };
  }

  // ================================================================
  // 2. XỬ LÝ RETURN URL - Verify Payment Return
  // ================================================================

  /**
   * Xác minh kết quả thanh toán từ VNPay Return URL
   * Gọi khi user redirect về từ VNPay
   */
  verifyReturnUrl(params: Record<string, string>): {
    isValid: boolean;
    responseCode: string;
    orderId: string;
    amount: number;
    transactionNo: string;
    bankCode: string;
    payDate: string;
    message: string;
  } {
    this.ensureConfigured();

    const secureHash = params['vnp_SecureHash'];
    const { vnp_SecureHash, vnp_SecureHashType, ...vnpParams } = params;

    const sortedParams = this.sortObject(vnpParams);
    const signData = new URLSearchParams(sortedParams).toString();
    const expectedHash = this.generateSignature(signData);

    const isValid = secureHash === expectedHash;
    const responseCode = params['vnp_ResponseCode'] || '99';

    const errorMessages: Record<string, string> = {
      '00': 'Giao dịch thành công',
      '07': 'Trừ tiền thành công. Giao dịch bị nghi ngờ (liên quan tới lừa đảo, giao dịch bất thường).',
      '09': 'Thẻ/Tài khoản chưa đăng ký dịch vụ InternetBanking tại ngân hàng.',
      '10': 'Xác thực thông tin thẻ/tài khoản không đúng quá 3 lần',
      '11': 'Đã hết hạn chờ thanh toán. Xin quý khách vui lòng thực hiện lại giao dịch.',
      '12': 'Thẻ/Tài khoản bị khóa.',
      '13': 'Quý khách nhập sai mật khẩu xác thực giao dịch (OTP).',
      '24': 'Quý khách hủy giao dịch.',
      '51': 'Tài khoản không đủ số dư để thực hiện giao dịch.',
      '65': 'Tài khoản đã vượt quá hạn mức giao dịch trong ngày.',
      '75': 'Ngân hàng thanh toán đang bảo trì.',
      '79': 'Nhập sai mật khẩu thanh toán quá số lần quy định.',
      '99': 'Các lỗi khác (lỗi còn lại, không có trong danh sách mã lỗi).',
    };

    return {
      isValid,
      responseCode,
      orderId: params['vnp_TxnRef'] || '',
      amount: parseInt(params['vnp_Amount'] || '0', 10) / 100,
      transactionNo: params['vnp_TransactionNo'] || '',
      bankCode: params['vnp_BankCode'] || '',
      payDate: params['vnp_PayDate'] || '',
      message: errorMessages[responseCode] || 'Lỗi không xác định',
    };
  }

  // ================================================================
  // 3. XỬ LÝ IPN - Instant Payment Notification (Server-to-Server)
  // ================================================================

  /**
   * Xử lý IPN callback từ VNPay (server-to-server)
   * VNPay gọi endpoint này để thông báo kết quả thanh toán
   * Response: { RspCode: '00', Message: 'success' }
   */
  async handleIpn(
    params: Record<string, string>,
  ): Promise<{ RspCode: string; Message: string }> {
    this.ensureConfigured();

    // 1. Verify checksum
    const secureHash = params['vnp_SecureHash'];
    const { vnp_SecureHash, vnp_SecureHashType, ...vnpParams } = params;
    const sortedParams = this.sortObject(vnpParams);
    const signData = new URLSearchParams(sortedParams).toString();
    const expectedHash = this.generateSignature(signData);

    if (secureHash !== expectedHash) {
      this.logger.warn('VNPay IPN: Invalid checksum');
      return { RspCode: '97', Message: 'Invalid Checksum' };
    }

    const orderId = params['vnp_TxnRef'];
    const rspCode = params['vnp_ResponseCode'];
    const amount = parseInt(params['vnp_Amount'] || '0', 10) / 100;
    const transactionNo = params['vnp_TransactionNo'];

    // 2. Check if order exists
    const payment = await this.prisma.payment.findFirst({
      where: {
        stripePaymentId: { startsWith: `VNPAY-${orderId}` },
      },
    });

    if (!payment) {
      this.logger.warn(`VNPay IPN: Order not found: ${orderId}`);
      return { RspCode: '01', Message: 'Order not found' };
    }

    // 3. Check amount
    if (Number(payment.amount) !== amount) {
      this.logger.warn(
        `VNPay IPN: Amount mismatch for ${orderId}: expected ${payment.amount}, got ${amount}`,
      );
      return { RspCode: '04', Message: 'Invalid Amount' };
    }

    // 4. Check if already processed
    if (payment.status === 'PAID') {
      this.logger.log(`VNPay IPN: Order already confirmed: ${orderId}`);
      return { RspCode: '02', Message: 'Order already confirmed' };
    }

    // 5. Update payment status
    const status = rspCode === '00' ? 'PAID' : 'FAILED';
    await this.prisma.payment.update({
      where: { id: payment.id },
      data: {
        status: status as any,
        metadata: {
          ...((payment.metadata as any) || {}),
          vnp_TransactionNo: transactionNo,
          vnp_BankCode: params['vnp_BankCode'],
          vnp_CardType: params['vnp_CardType'],
          vnp_PayDate: params['vnp_PayDate'],
          vnp_ResponseCode: rspCode,
        },
      },
    });

    this.logger.log(`VNPay IPN: Order ${orderId} updated to ${status}`);
    return { RspCode: '00', Message: 'Confirm Success' };
  }

  // ================================================================
  // 4. TRUY VẤN KẾT QUẢ GIAO DỊCH (querydr)
  // ================================================================

  /**
   * Truy vấn kết quả giao dịch từ VNPay
   * Dùng khi không nhận được IPN hoặc cần verify lại
   */
  async queryTransaction(
    orderId: string,
    transDate: string,
  ): Promise<VnpayQueryResult> {
    this.ensureConfigured();

    const requestId = crypto.randomUUID().replace(/-/g, '').slice(0, 32);
    const createDate = this.formatDate(new Date());

    const requestData = {
      vnp_RequestId: requestId,
      vnp_Version: '2.1.0',
      vnp_Command: 'querydr',
      vnp_TmnCode: this.tmnCode,
      vnp_TxnRef: orderId,
      vnp_OrderInfo: `Truy van GD: ${orderId}`,
      vnp_TransDate: transDate,
      vnp_CreateDate: createDate,
      vnp_IpAddr: '127.0.0.1',
    };

    // Generate checksum: requestId|version|command|tmnCode|txnRef|transDate|createDate|ipAddr|orderInfo
    const checksumData = [
      requestData.vnp_RequestId,
      requestData.vnp_Version,
      requestData.vnp_Command,
      requestData.vnp_TmnCode,
      requestData.vnp_TxnRef,
      requestData.vnp_TransDate,
      requestData.vnp_CreateDate,
      requestData.vnp_IpAddr,
      requestData.vnp_OrderInfo,
    ].join('|');

    const secureHash = this.generateSignature(checksumData);

    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...requestData,
          vnp_SecureHash: secureHash,
        }),
      });

      const result = await response.json();

      return {
        transactionId: result.vnp_TransactionNo || '',
        orderId: result.vnp_TxnRef || orderId,
        amount: parseInt(result.vnp_Amount || '0', 10) / 100,
        status: result.vnp_TransactionStatus || result.vnp_ResponseCode || '99',
        bankCode: result.vnp_BankCode,
        bankTranNo: result.vnp_BankTranNo,
        cardType: result.vnp_CardType,
        payDate: result.vnp_PayDate,
        message: result.vnp_Message || 'Query completed',
      };
    } catch (error: any) {
      this.logger.error(`VNPay query failed: ${error.message}`);
      throw new BadRequestException(`VNPay query error: ${error.message}`);
    }
  }

  // ================================================================
  // 5. HOÀN TIỀN (Refund)
  // ================================================================

  /**
   * Thực hiện hoàn tiền giao dịch VNPay
   * TransactionType: '02' = hoàn toàn bộ, '03' = hoàn một phần
   */
  async refundTransaction(params: {
    orderId: string;
    amount: number;
    transactionNo: string;
    transDate: string;
    createBy: string;
    transactionType?: '02' | '03'; // 02 = full, 03 = partial
  }): Promise<VnpayRefundResult> {
    this.ensureConfigured();

    const requestId = crypto.randomUUID().replace(/-/g, '').slice(0, 32);
    const createDate = this.formatDate(new Date());
    const transactionType = params.transactionType || '02';

    const requestData = {
      vnp_RequestId: requestId,
      vnp_Version: '2.1.0',
      vnp_Command: 'refund',
      vnp_TmnCode: this.tmnCode,
      vnp_TransactionType: transactionType,
      vnp_TxnRef: params.orderId,
      vnp_Amount: Math.round(params.amount) * 100,
      vnp_OrderInfo: `Hoan tien GD: ${params.orderId}`,
      vnp_TransactionNo: params.transactionNo,
      vnp_TransactionDate: params.transDate,
      vnp_CreateBy: params.createBy,
      vnp_CreateDate: createDate,
      vnp_IpAddr: '127.0.0.1',
    };

    // Checksum for refund
    const checksumData = [
      requestData.vnp_RequestId,
      requestData.vnp_Version,
      requestData.vnp_Command,
      requestData.vnp_TmnCode,
      requestData.vnp_TransactionType,
      requestData.vnp_TxnRef,
      requestData.vnp_Amount,
      requestData.vnp_TransactionNo,
      requestData.vnp_TransactionDate,
      requestData.vnp_CreateBy,
      requestData.vnp_CreateDate,
      requestData.vnp_IpAddr,
      requestData.vnp_OrderInfo,
    ].join('|');

    const secureHash = this.generateSignature(checksumData);

    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...requestData,
          vnp_SecureHash: secureHash,
        }),
      });

      const result = await response.json();
      const isSuccess = result.vnp_ResponseCode === '00';

      // Update local record if success
      if (isSuccess) {
        await this.updatePaymentStatus(`VNPAY-${params.orderId}`, 'REFUNDED');
      }

      return {
        success: isSuccess,
        refundId: result.vnp_TransactionNo || requestId,
        amount: params.amount,
        message:
          result.vnp_Message ||
          (isSuccess ? 'Hoàn tiền thành công' : 'Hoàn tiền thất bại'),
      };
    } catch (error: any) {
      this.logger.error(`VNPay refund failed: ${error.message}`);
      throw new BadRequestException(`VNPay refund error: ${error.message}`);
    }
  }

  // ================================================================
  // 6. DANH SÁCH NGÂN HÀNG HỖ TRỢ
  // ================================================================

  /**
   * Lấy danh sách ngân hàng hỗ trợ thanh toán VNPay
   */
  getSupportedBanks(): Array<{ code: string; name: string; type: string }> {
    return [
      // Thanh toán QR
      { code: 'VNPAYQR', name: 'Thanh toán quét mã QR', type: 'qr' },
      // Ví điện tử
      { code: 'VNMART', name: 'Ví VnMart', type: 'wallet' },
      { code: 'VIETTEL_MONEY', name: 'Ví Viettel Money', type: 'wallet' },
      // Ngân hàng nội địa
      { code: 'NCB', name: 'Ngân hàng NCB', type: 'domestic' },
      { code: 'SCB', name: 'Ngân hàng SCB', type: 'domestic' },
      { code: 'SACOMBANK', name: 'Ngân hàng SACOMBANK', type: 'domestic' },
      { code: 'EXIMBANK', name: 'Ngân hàng EXIMBANK', type: 'domestic' },
      { code: 'MSBANK', name: 'Ngân hàng MSBANK', type: 'domestic' },
      { code: 'NAMABANK', name: 'Ngân hàng NAMABANK', type: 'domestic' },
      { code: 'VNBC', name: 'Ngân hàng VNBC/VietNam BC', type: 'domestic' },
      { code: 'VIETINBANK', name: 'Ngân hàng Vietinbank', type: 'domestic' },
      { code: 'VIETCOMBANK', name: 'Ngân hàng Vietcombank', type: 'domestic' },
      { code: 'HDBANK', name: 'Ngân hàng HD Bank', type: 'domestic' },
      { code: 'DONGABANK', name: 'Ngân hàng Đông Á', type: 'domestic' },
      { code: 'TPBANK', name: 'Ngân hàng TPBank', type: 'domestic' },
      { code: 'OJB', name: 'Ngân hàng OJB/OceanBank', type: 'domestic' },
      { code: 'BIDV', name: 'Ngân hàng BIDV', type: 'domestic' },
      { code: 'TECHCOMBANK', name: 'Ngân hàng Techcombank', type: 'domestic' },
      { code: 'VPBANK', name: 'Ngân hàng VPBank', type: 'domestic' },
      { code: 'AGRIBANK', name: 'Ngân hàng Agribank', type: 'domestic' },
      { code: 'MBBANK', name: 'Ngân hàng MBBank', type: 'domestic' },
      { code: 'ACB', name: 'Ngân hàng ACB', type: 'domestic' },
      { code: 'OCB', name: 'Ngân hàng OCB', type: 'domestic' },
      { code: 'SHB', name: 'Ngân hàng SHB', type: 'domestic' },
      { code: 'IVB', name: 'Ngân hàng IVB', type: 'domestic' },
      // Thẻ quốc tế
      { code: 'VISA', name: 'Thẻ Visa', type: 'international' },
      { code: 'MASTERCARD', name: 'Thẻ Mastercard', type: 'international' },
      { code: 'JCB', name: 'Thẻ JCB', type: 'international' },
    ];
  }

  // ================================================================
  // Database Helpers
  // ================================================================

  /**
   * Save payment record to database
   */
  private async savePaymentRecord(data: {
    transactionId: string;
    orderId: string;
    amount: number;
    userId?: number;
    projectId?: number;
    status: string;
  }) {
    try {
      await this.prisma.payment.create({
        data: {
          amount: data.amount,
          currency: 'VND',
          status: data.status as any,
          paymentMethod: 'VNPAY' as any,
          gateway: 'VNPAY',
          orderId: data.orderId,
          transactionId: data.transactionId,
          stripePaymentId: data.transactionId, // backward compat
          description: `VNPay - Đơn hàng ${data.orderId}`,
          userId: data.userId || 0,
          projectId: data.projectId,
          metadata: {
            gateway: 'VNPAY',
            orderId: data.orderId,
          },
        },
      });
    } catch (error: any) {
      this.logger.error(
        `Failed to save VNPay payment record: ${error.message}`,
      );
    }
  }

  /**
   * Update payment status in database
   */
  private async updatePaymentStatus(transactionId: string, status: string) {
    try {
      const payment = await this.prisma.payment.findFirst({
        where: {
          OR: [{ transactionId }, { stripePaymentId: transactionId }],
        },
      });
      if (payment) {
        await this.prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: status as any,
            ...(status === 'COMPLETED' ? { paidAt: new Date() } : {}),
          },
        });
      }
    } catch (error: any) {
      this.logger.error(
        `Failed to update VNPay payment status: ${error.message}`,
      );
    }
  }
}
