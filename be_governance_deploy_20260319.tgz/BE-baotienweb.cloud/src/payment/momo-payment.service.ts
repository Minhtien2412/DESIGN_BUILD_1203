import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';

/**
 * MoMo Payment Service
 * ====================
 * Tích hợp Cổng thanh toán MoMo API v3
 * Docs: https://developers.momo.vn/v3/docs/payment/api/wallet/
 *
 * Hỗ trợ:
 * - captureWallet (thanh toán ví MoMo)
 * - payWithMethod (nhiều phương thức)
 * - Truy vấn trạng thái giao dịch
 * - Hoàn tiền (refund)
 * - IPN callback (server-to-server)
 */

export interface MomoPaymentInitDto {
  amount: number;
  orderId: string;
  description: string;
  returnUrl?: string;
  ipnUrl?: string;
  userId?: number;
  projectId?: number;
  requestType?: 'captureWallet' | 'payWithMethod';
  extraData?: string;
  lang?: string;
}

export interface MomoPaymentResult {
  gateway: 'MOMO';
  paymentUrl: string;
  deeplink: string;
  qrCodeUrl: string;
  transactionId: string;
  orderId: string;
  amount: number;
  message: string;
}

export interface MomoQueryResult {
  transactionId: string;
  orderId: string;
  amount: number;
  resultCode: number;
  message: string;
  transId: number;
  payType: string;
  responseTime: number;
}

export interface MomoRefundResult {
  success: boolean;
  transactionId: string;
  amount: number;
  message: string;
}

@Injectable()
export class MomoPaymentService {
  private readonly logger = new Logger(MomoPaymentService.name);

  private readonly partnerCode: string;
  private readonly accessKey: string;
  private readonly secretKey: string;
  private readonly apiUrl: string;
  private readonly defaultReturnUrl: string;
  private readonly defaultIpnUrl: string;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.partnerCode =
      this.configService.get<string>('MOMO_PARTNER_CODE') || '';
    this.accessKey = this.configService.get<string>('MOMO_ACCESS_KEY') || '';
    this.secretKey = this.configService.get<string>('MOMO_SECRET_KEY') || '';
    this.apiUrl =
      this.configService.get<string>('MOMO_API_URL') ||
      'https://test-payment.momo.vn/v2/gateway/api';
    this.defaultReturnUrl =
      this.configService.get<string>('MOMO_RETURN_URL') ||
      'https://baotienweb.cloud/api/v1/payment/momo/return';
    this.defaultIpnUrl =
      this.configService.get<string>('MOMO_IPN_URL') ||
      'https://baotienweb.cloud/api/v1/payment/momo/ipn';

    if (!this.partnerCode || !this.accessKey || !this.secretKey) {
      this.logger.warn(
        '⚠️ MoMo credentials not configured - MoMo payment disabled',
      );
    } else {
      this.logger.log('✅ MoMo payment gateway initialized');
    }
  }

  private isConfigured(): boolean {
    return !!(this.partnerCode && this.accessKey && this.secretKey);
  }

  private ensureConfigured() {
    if (!this.isConfigured()) {
      throw new BadRequestException(
        'MoMo payment gateway not configured. Please set MOMO_PARTNER_CODE, MOMO_ACCESS_KEY, and MOMO_SECRET_KEY.',
      );
    }
  }

  /**
   * Generate HMAC-SHA256 signature (MoMo standard)
   */
  private generateSignature(data: string): string {
    return crypto
      .createHmac('sha256', this.secretKey)
      .update(Buffer.from(data, 'utf-8'))
      .digest('hex');
  }

  // ================================================================
  // 1. TẠO THANH TOÁN - Create Payment (captureWallet / payWithMethod)
  // ================================================================

  /**
   * Tạo yêu cầu thanh toán MoMo
   * Trả về payUrl (web), deeplink (app), qrCodeUrl (QR)
   */
  async createPayment(dto: MomoPaymentInitDto): Promise<MomoPaymentResult> {
    this.ensureConfigured();

    const requestId = `${this.partnerCode}-${dto.orderId}-${Date.now()}`;
    const orderId = dto.orderId;
    const requestType = dto.requestType || 'captureWallet';
    const extraData = dto.extraData || '';
    const returnUrl = dto.returnUrl || this.defaultReturnUrl;
    const ipnUrl = dto.ipnUrl || this.defaultIpnUrl;
    const orderInfo = (
      dto.description || `Thanh toan don hang ${dto.orderId}`
    ).slice(0, 255);

    // Build raw signature string (alphabetical order per MoMo docs)
    const rawSignature = [
      `accessKey=${this.accessKey}`,
      `amount=${dto.amount}`,
      `extraData=${extraData}`,
      `ipnUrl=${ipnUrl}`,
      `orderId=${orderId}`,
      `orderInfo=${orderInfo}`,
      `partnerCode=${this.partnerCode}`,
      `redirectUrl=${returnUrl}`,
      `requestId=${requestId}`,
      `requestType=${requestType}`,
    ].join('&');

    const signature = this.generateSignature(rawSignature);

    const requestBody = {
      partnerCode: this.partnerCode,
      partnerName: 'Bao Tien Web',
      storeId: `${this.partnerCode}_Store`,
      requestId,
      amount: dto.amount,
      orderId,
      orderInfo,
      redirectUrl: returnUrl,
      ipnUrl,
      lang: dto.lang || 'vi',
      requestType,
      autoCapture: true,
      extraData,
      signature,
    };

    try {
      const response = await fetch(`${this.apiUrl}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      const result = await response.json();

      if (result.resultCode !== 0) {
        this.logger.error(
          `MoMo create payment failed: ${result.resultCode} - ${result.message}`,
        );
        throw new BadRequestException(
          `MoMo payment failed: ${result.message || 'Unknown error'} (code: ${result.resultCode})`,
        );
      }

      // Save payment record
      await this.savePaymentRecord({
        transactionId: requestId,
        orderId,
        amount: dto.amount,
        userId: dto.userId,
        projectId: dto.projectId,
        status: 'PENDING',
        metadata: {
          momoRequestId: requestId,
          requestType,
        },
      });

      this.logger.log(
        `MoMo payment created: ${orderId}, amount: ${dto.amount}`,
      );

      return {
        gateway: 'MOMO',
        paymentUrl: result.payUrl || '',
        deeplink: result.deeplink || '',
        qrCodeUrl: result.qrCodeUrl || '',
        transactionId: requestId,
        orderId,
        amount: dto.amount,
        message: 'Redirect to MoMo for payment',
      };
    } catch (error: any) {
      if (error instanceof BadRequestException) throw error;
      this.logger.error(`MoMo API call failed: ${error.message}`);
      throw new BadRequestException(`MoMo payment error: ${error.message}`);
    }
  }

  // ================================================================
  // 2. XỬ LÝ IPN - Instant Payment Notification (Server-to-Server)
  // ================================================================

  /**
   * Xử lý IPN callback từ MoMo (server-to-server)
   * MoMo gọi endpoint này để thông báo kết quả thanh toán
   */
  async handleIpn(body: {
    partnerCode: string;
    orderId: string;
    requestId: string;
    amount: number;
    orderInfo: string;
    orderType: string;
    transId: number;
    resultCode: number;
    message: string;
    payType: string;
    responseTime: number;
    extraData: string;
    signature: string;
  }): Promise<{ resultCode: number; message: string }> {
    this.ensureConfigured();

    // 1. Verify signature
    const rawSignature = [
      `accessKey=${this.accessKey}`,
      `amount=${body.amount}`,
      `extraData=${body.extraData}`,
      `message=${body.message}`,
      `orderId=${body.orderId}`,
      `orderInfo=${body.orderInfo}`,
      `orderType=${body.orderType}`,
      `partnerCode=${body.partnerCode}`,
      `payType=${body.payType}`,
      `requestId=${body.requestId}`,
      `responseTime=${body.responseTime}`,
      `resultCode=${body.resultCode}`,
      `transId=${body.transId}`,
    ].join('&');

    const expectedSignature = this.generateSignature(rawSignature);

    if (body.signature !== expectedSignature) {
      this.logger.warn(`MoMo IPN: Invalid signature for order ${body.orderId}`);
      return { resultCode: 1, message: 'Invalid signature' };
    }

    // 2. Find payment record
    const payment = await this.prisma.payment.findFirst({
      where: {
        orderId: body.orderId,
        gateway: 'MOMO',
      },
    });

    if (!payment) {
      this.logger.warn(`MoMo IPN: Order not found: ${body.orderId}`);
      return { resultCode: 1, message: 'Order not found' };
    }

    // 3. Check amount
    if (Number(payment.amount) !== body.amount) {
      this.logger.warn(
        `MoMo IPN: Amount mismatch for ${body.orderId}: expected ${payment.amount}, got ${body.amount}`,
      );
      return { resultCode: 1, message: 'Invalid amount' };
    }

    // 4. Check if already processed
    if (payment.status === 'PAID') {
      this.logger.log(`MoMo IPN: Order already confirmed: ${body.orderId}`);
      return { resultCode: 0, message: 'Order already confirmed' };
    }

    // 5. Update payment status
    // resultCode 0 = success, others = failure
    const status = body.resultCode === 0 ? 'PAID' : 'FAILED';
    await this.prisma.payment.update({
      where: { id: payment.id },
      data: {
        status: status as any,
        paidAt: body.resultCode === 0 ? new Date() : undefined,
        metadata: {
          ...((payment.metadata as any) || {}),
          momoTransId: body.transId,
          momoPayType: body.payType,
          momoResultCode: body.resultCode,
          momoMessage: body.message,
          momoResponseTime: body.responseTime,
        },
      },
    });

    this.logger.log(
      `MoMo IPN: Order ${body.orderId} updated to ${status} (resultCode: ${body.resultCode})`,
    );

    return { resultCode: 0, message: 'Success' };
  }

  // ================================================================
  // 3. XỬ LÝ RETURN URL - Verify Payment Return
  // ================================================================

  /**
   * Xác minh kết quả thanh toán khi user redirect về
   */
  verifyReturn(params: Record<string, string>): {
    isValid: boolean;
    resultCode: number;
    orderId: string;
    amount: number;
    transId: string;
    message: string;
  } {
    this.ensureConfigured();

    // Build raw signature from return params (alphabetical)
    const rawSignature = [
      `accessKey=${this.accessKey}`,
      `amount=${params.amount || ''}`,
      `extraData=${params.extraData || ''}`,
      `message=${params.message || ''}`,
      `orderId=${params.orderId || ''}`,
      `orderInfo=${params.orderInfo || ''}`,
      `orderType=${params.orderType || ''}`,
      `partnerCode=${params.partnerCode || ''}`,
      `payType=${params.payType || ''}`,
      `requestId=${params.requestId || ''}`,
      `responseTime=${params.responseTime || ''}`,
      `resultCode=${params.resultCode || ''}`,
      `transId=${params.transId || ''}`,
    ].join('&');

    const expectedSignature = this.generateSignature(rawSignature);
    const isValid = params.signature === expectedSignature;
    const resultCode = parseInt(params.resultCode || '-1', 10);

    const errorMessages: Record<number, string> = {
      0: 'Giao dịch thành công',
      9000: 'Giao dịch đã được xác nhận thành công',
      8000: 'Giao dịch đang xử lý',
      7000: 'Giao dịch đang xử lý bởi cổng thanh toán',
      1000: 'Giao dịch đã được khởi tạo, đang chờ thanh toán',
      11: 'Truy cập bị từ chối',
      12: 'Phiên bản API không hỗ trợ',
      13: 'Xác thực thương nhân thất bại',
      20: 'Yêu cầu sai định dạng',
      21: 'Số tiền giao dịch không hợp lệ',
      40: 'Đơn hàng bị trùng',
      41: 'Đơn hàng không tồn tại hoặc đã bị hủy',
      42: 'Đơn hàng không hợp lệ hoặc đã bị hủy',
      43: 'Giao dịch bị từ chối bởi MoMo',
      1001: 'Giao dịch thất bại do tài khoản không đủ tiền',
      1002: 'Giao dịch bị từ chối bởi hệ thống MoMo',
      1003: 'Giao dịch bị hủy bởi người dùng',
      1004: 'Giao dịch thất bại do quá thời gian',
      1005: 'Giao dịch thất bại do URL hoặc QR hết hạn',
      1006: 'Giao dịch thất bại do sai mật khẩu OTP',
      1007: 'Giao dịch bị từ chối vì spam phát hiện',
    };

    return {
      isValid,
      resultCode,
      orderId: params.orderId || '',
      amount: parseInt(params.amount || '0', 10),
      transId: params.transId || '',
      message:
        errorMessages[resultCode] || params.message || 'Lỗi không xác định',
    };
  }

  // ================================================================
  // 4. TRUY VẤN TRẠNG THÁI GIAO DỊCH (Query Transaction Status)
  // ================================================================

  /**
   * Truy vấn trạng thái giao dịch MoMo
   * Dùng khi không nhận được IPN hoặc cần verify lại
   */
  async queryTransaction(orderId: string): Promise<MomoQueryResult> {
    this.ensureConfigured();

    const requestId = `${this.partnerCode}-query-${Date.now()}`;

    const rawSignature = [
      `accessKey=${this.accessKey}`,
      `orderId=${orderId}`,
      `partnerCode=${this.partnerCode}`,
      `requestId=${requestId}`,
    ].join('&');

    const signature = this.generateSignature(rawSignature);

    try {
      const response = await fetch(`${this.apiUrl}/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          partnerCode: this.partnerCode,
          requestId,
          orderId,
          signature,
          lang: 'vi',
        }),
      });

      const result = await response.json();

      return {
        transactionId: requestId,
        orderId: result.orderId || orderId,
        amount: result.amount || 0,
        resultCode: result.resultCode,
        message: result.message || 'Query completed',
        transId: result.transId || 0,
        payType: result.payType || '',
        responseTime: result.responseTime || 0,
      };
    } catch (error: any) {
      this.logger.error(`MoMo query failed: ${error.message}`);
      throw new BadRequestException(`MoMo query error: ${error.message}`);
    }
  }

  // ================================================================
  // 5. HOÀN TIỀN (Refund)
  // ================================================================

  /**
   * Thực hiện hoàn tiền giao dịch MoMo
   */
  async refundTransaction(params: {
    orderId: string;
    amount: number;
    transId: number;
    description?: string;
  }): Promise<MomoRefundResult> {
    this.ensureConfigured();

    const requestId = `${this.partnerCode}-refund-${Date.now()}`;
    const description =
      params.description || `Hoan tien don hang ${params.orderId}`;

    const rawSignature = [
      `accessKey=${this.accessKey}`,
      `amount=${params.amount}`,
      `description=${description}`,
      `orderId=${params.orderId}`,
      `partnerCode=${this.partnerCode}`,
      `requestId=${requestId}`,
      `transId=${params.transId}`,
    ].join('&');

    const signature = this.generateSignature(rawSignature);

    try {
      const response = await fetch(`${this.apiUrl}/refund`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          partnerCode: this.partnerCode,
          orderId: params.orderId,
          requestId,
          amount: params.amount,
          transId: params.transId,
          lang: 'vi',
          description,
          signature,
        }),
      });

      const result = await response.json();
      const isSuccess = result.resultCode === 0;

      // Update local record if success
      if (isSuccess) {
        await this.updatePaymentStatus(params.orderId, 'REFUNDED');
      }

      return {
        success: isSuccess,
        transactionId: result.transId?.toString() || requestId,
        amount: params.amount,
        message:
          result.message ||
          (isSuccess ? 'Hoàn tiền thành công' : 'Hoàn tiền thất bại'),
      };
    } catch (error: any) {
      this.logger.error(`MoMo refund failed: ${error.message}`);
      throw new BadRequestException(`MoMo refund error: ${error.message}`);
    }
  }

  // ================================================================
  // Database Helpers
  // ================================================================

  private async savePaymentRecord(data: {
    transactionId: string;
    orderId: string;
    amount: number;
    userId?: number;
    projectId?: number;
    status: string;
    metadata?: Record<string, any>;
  }) {
    try {
      await this.prisma.payment.create({
        data: {
          amount: data.amount,
          currency: 'VND',
          status: data.status as any,
          paymentMethod: 'MOMO' as any,
          gateway: 'MOMO',
          orderId: data.orderId,
          transactionId: data.transactionId,
          stripePaymentId: data.transactionId, // backward compat
          description: `MoMo - Đơn hàng ${data.orderId}`,
          userId: data.userId || 0,
          projectId: data.projectId,
          metadata: {
            gateway: 'MOMO',
            orderId: data.orderId,
            ...(data.metadata || {}),
          },
        },
      });
    } catch (error: any) {
      this.logger.error(`Failed to save MoMo payment record: ${error.message}`);
    }
  }

  private async updatePaymentStatus(orderId: string, status: string) {
    try {
      const payment = await this.prisma.payment.findFirst({
        where: {
          orderId,
          gateway: 'MOMO',
        },
      });
      if (payment) {
        await this.prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: status as any,
            ...(status === 'REFUNDED' ? {} : { paidAt: new Date() }),
          },
        });
      }
    } catch (error: any) {
      this.logger.error(
        `Failed to update MoMo payment status: ${error.message}`,
      );
    }
  }
}
