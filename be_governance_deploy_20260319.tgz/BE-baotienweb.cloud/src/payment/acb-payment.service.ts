import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';

export interface AcbPaymentInitDto {
  amount: number;
  orderId: string;
  description: string;
  returnUrl?: string;
  notifyUrl?: string;
  userId?: number;
  projectId?: number;
}

export interface AcbPaymentResult {
  gateway: 'ACB';
  paymentUrl?: string;
  qrCodeUrl?: string;
  qrContent?: string;
  transactionId: string;
  orderId: string;
  amount: number;
  message: string;
}

export interface AcbTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

@Injectable()
export class AcbPaymentService {
  private readonly logger = new Logger(AcbPaymentService.name);
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;

  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly apiUrl: string;
  private readonly merchantId: string;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.clientId = this.configService.get<string>('ACB_CLIENT_ID') || '';
    this.clientSecret =
      this.configService.get<string>('ACB_CLIENT_SECRET') || '';
    this.apiUrl =
      this.configService.get<string>('ACB_API_URL') ||
      'https://apiconnect.acb.com.vn';
    this.merchantId = this.configService.get<string>('ACB_MERCHANT_ID') || '';

    if (!this.clientId || !this.clientSecret) {
      this.logger.warn(
        '⚠️ ACB ONE Connect credentials not configured - ACB payment disabled',
      );
    } else {
      this.logger.log('✅ ACB ONE Connect payment gateway initialized');
    }
  }

  private isConfigured(): boolean {
    return !!(this.clientId && this.clientSecret);
  }

  private ensureConfigured() {
    if (!this.isConfigured()) {
      throw new BadRequestException(
        'ACB payment gateway not configured. Please set ACB_CLIENT_ID and ACB_CLIENT_SECRET.',
      );
    }
  }

  /**
   * Get OAuth2 access token from ACB ONE Connect
   * Uses client_credentials grant type
   */
  async getAccessToken(): Promise<string> {
    // Return cached token if still valid (with 60s buffer)
    if (this.accessToken && Date.now() < this.tokenExpiry - 60000) {
      return this.accessToken;
    }

    this.ensureConfigured();

    const tokenUrl = `${this.apiUrl}/oauth/token`;

    try {
      const response = await fetch(tokenUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64')}`,
        },
        body: new URLSearchParams({
          grant_type: 'client_credentials',
          scope: 'payment',
        }).toString(),
      });

      if (!response.ok) {
        const errorText = await response.text();
        this.logger.error(`ACB token error: ${response.status} - ${errorText}`);
        throw new BadRequestException(
          'Failed to authenticate with ACB ONE Connect',
        );
      }

      const data: AcbTokenResponse = await response.json();
      this.accessToken = data.access_token;
      this.tokenExpiry = Date.now() + data.expires_in * 1000;

      this.logger.log('ACB ONE Connect token obtained successfully');
      return this.accessToken;
    } catch (error: any) {
      if (error instanceof BadRequestException) throw error;
      this.logger.error(`ACB token request failed: ${error.message}`);
      throw new BadRequestException('ACB ONE Connect authentication failed');
    }
  }

  /**
   * Generate HMAC-SHA256 signature for request integrity
   */
  private generateSignature(data: string): string {
    return crypto
      .createHmac('sha256', this.clientSecret)
      .update(data)
      .digest('hex');
  }

  /**
   * Initiate ACB payment - creates payment order and returns QR/URL
   */
  async initiatePayment(dto: AcbPaymentInitDto): Promise<AcbPaymentResult> {
    this.ensureConfigured();

    const transactionId = `ACB-${dto.orderId}-${Date.now()}`;

    // If credentials not fully configured, return mock for development
    if (!this.merchantId) {
      this.logger.warn('ACB_MERCHANT_ID not set - returning mock payment data');
      return this.createMockPayment(dto, transactionId);
    }

    try {
      const token = await this.getAccessToken();
      const requestId = crypto.randomUUID();

      const paymentBody = {
        requestId,
        merchantId: this.merchantId,
        transactionId,
        amount: dto.amount,
        currency: 'VND',
        description: dto.description,
        returnUrl: dto.returnUrl || '',
        notifyUrl: dto.notifyUrl || '',
        orderInfo: dto.orderId,
        extraData: JSON.stringify({
          userId: dto.userId,
          projectId: dto.projectId,
        }),
      };

      // Generate signature from sorted request body
      const signatureData = Object.entries(paymentBody)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([k, v]) => `${k}=${v}`)
        .join('&');
      const signature = this.generateSignature(signatureData);

      const response = await fetch(`${this.apiUrl}/api/v1/payments/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'X-Request-Id': requestId,
          'X-Signature': signature,
        },
        body: JSON.stringify(paymentBody),
      });

      if (!response.ok) {
        const errorData = await response.text();
        this.logger.error(
          `ACB payment creation failed: ${response.status} - ${errorData}`,
        );
        throw new BadRequestException(`ACB payment failed: ${errorData}`);
      }

      const result = await response.json();

      // Save payment record to database
      await this.savePaymentRecord({
        transactionId,
        orderId: dto.orderId,
        amount: dto.amount,
        userId: dto.userId,
        projectId: dto.projectId,
        status: 'PENDING',
        gateway: 'ACB',
        metadata: result,
      });

      return {
        gateway: 'ACB',
        paymentUrl: result.paymentUrl || result.payUrl,
        qrCodeUrl: result.qrCodeUrl || result.qrUrl,
        qrContent: result.qrContent || result.qrData,
        transactionId,
        orderId: dto.orderId,
        amount: dto.amount,
        message: 'Redirect to ACB for payment',
      };
    } catch (error: any) {
      if (error instanceof BadRequestException) throw error;
      this.logger.error(`ACB payment initiation failed: ${error.message}`);
      throw new BadRequestException(`ACB payment error: ${error.message}`);
    }
  }

  /**
   * Generate VietQR code for ACB bank transfer
   * Uses VietQR standard (widely supported by ACB)
   */
  async generateQrCode(dto: AcbPaymentInitDto): Promise<AcbPaymentResult> {
    const transactionId = `ACB-QR-${dto.orderId}-${Date.now()}`;

    // VietQR format for ACB
    const acbBin = '970416'; // ACB bank BIN code (Napas)
    const accountNo = this.configService.get<string>('ACB_ACCOUNT_NO') || '';
    const accountName =
      this.configService.get<string>('ACB_ACCOUNT_NAME') || 'APP DESIGN BUILD';

    // VietQR standard QR content
    const qrContent = [
      `00020101021238`, // Header
      `53037045405${dto.amount}`,
      `5802VN`,
      `62${dto.description.length.toString().padStart(2, '0')}${dto.description}`,
    ].join('');

    // Use VietQR API to generate QR image
    const qrCodeUrl = accountNo
      ? `https://img.vietqr.io/image/${acbBin}-${accountNo}-compact2.jpg?amount=${dto.amount}&addInfo=${encodeURIComponent(dto.description)}&accountName=${encodeURIComponent(accountName)}`
      : undefined;

    await this.savePaymentRecord({
      transactionId,
      orderId: dto.orderId,
      amount: dto.amount,
      userId: dto.userId,
      projectId: dto.projectId,
      status: 'PENDING',
      gateway: 'ACB',
      metadata: { type: 'QR', qrContent },
    });

    return {
      gateway: 'ACB',
      qrCodeUrl,
      qrContent,
      transactionId,
      orderId: dto.orderId,
      amount: dto.amount,
      message: 'Scan QR code to complete ACB payment',
    };
  }

  /**
   * Verify payment status with ACB
   */
  async verifyPayment(transactionId: string): Promise<{
    transactionId: string;
    status: string;
    amount: number;
    paidAt?: string;
  }> {
    this.ensureConfigured();

    try {
      const token = await this.getAccessToken();
      const requestId = crypto.randomUUID();

      const response = await fetch(
        `${this.apiUrl}/api/v1/payments/status/${transactionId}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
            'X-Request-Id': requestId,
          },
        },
      );

      if (!response.ok) {
        // Fallback: check local database
        return this.getLocalPaymentStatus(transactionId);
      }

      const result = await response.json();

      // Update local record
      await this.updatePaymentStatus(
        transactionId,
        result.status === 'SUCCESS' ? 'PAID' : result.status,
      );

      return {
        transactionId,
        status: result.status,
        amount: result.amount,
        paidAt: result.paidAt || result.completedAt,
      };
    } catch (error: any) {
      this.logger.error(`ACB verify failed: ${error.message}`);
      return this.getLocalPaymentStatus(transactionId);
    }
  }

  /**
   * Handle ACB webhook/callback notification
   */
  async handleCallback(data: {
    transactionId: string;
    status: string;
    amount: number;
    signature?: string;
    [key: string]: any;
  }): Promise<{ success: boolean; message: string }> {
    this.logger.log(
      `ACB callback received: ${JSON.stringify({ transactionId: data.transactionId, status: data.status })}`,
    );

    // Verify signature if provided
    if (data.signature) {
      const expectedData = `${data.transactionId}|${data.amount}|${data.status}`;
      const expectedSignature = this.generateSignature(expectedData);
      if (data.signature !== expectedSignature) {
        this.logger.warn('ACB callback signature mismatch');
        throw new BadRequestException('Invalid callback signature');
      }
    }

    const status =
      data.status === 'SUCCESS' || data.status === '00' ? 'PAID' : 'FAILED';
    await this.updatePaymentStatus(data.transactionId, status);

    return {
      success: status === 'PAID',
      message: `Payment ${data.transactionId} updated to ${status}`,
    };
  }

  /**
   * Mock payment for development when ACB_MERCHANT_ID is not set
   */
  private createMockPayment(
    dto: AcbPaymentInitDto,
    transactionId: string,
  ): AcbPaymentResult {
    return {
      gateway: 'ACB',
      paymentUrl: `https://developer.acb.com.vn/sandbox/pay?txn=${transactionId}`,
      qrCodeUrl: `https://img.vietqr.io/image/970416-0000000000-compact2.jpg?amount=${dto.amount}&addInfo=${encodeURIComponent(dto.description)}`,
      qrContent: `ACB_MOCK_QR_${transactionId}`,
      transactionId,
      orderId: dto.orderId,
      amount: dto.amount,
      message: 'Mock: ACB_MERCHANT_ID not configured. Using sandbox mode.',
    };
  }

  /**
   * Save payment record to database
   */
  private async savePaymentRecord(data: {
    transactionId: string;
    orderId: string;
    amount: number;
    userId?: number;
    projectId?: number;
    status: string;
    gateway: string;
    metadata?: any;
  }) {
    try {
      await this.prisma.payment.create({
        data: {
          amount: data.amount,
          currency: 'VND',
          status: data.status as any,
          paymentMethod: 'BANK_TRANSFER',
          stripePaymentId: data.transactionId, // Reuse field for ACB transaction ID
          description: `ACB Payment - Order ${data.orderId}`,
          userId: data.userId || 0,
          projectId: data.projectId,
          metadata: {
            gateway: data.gateway,
            orderId: data.orderId,
            ...data.metadata,
          },
        },
      });
    } catch (error: any) {
      this.logger.error(`Failed to save ACB payment record: ${error.message}`);
    }
  }

  /**
   * Update payment status in database
   */
  private async updatePaymentStatus(transactionId: string, status: string) {
    try {
      const payment = await this.prisma.payment.findFirst({
        where: { stripePaymentId: transactionId },
      });

      if (payment) {
        await this.prisma.payment.update({
          where: { id: payment.id },
          data: { status: status as any },
        });
      }
    } catch (error: any) {
      this.logger.error(`Failed to update payment status: ${error.message}`);
    }
  }

  /**
   * Get payment status from local database
   */
  private async getLocalPaymentStatus(transactionId: string) {
    const payment = await this.prisma.payment.findFirst({
      where: { stripePaymentId: transactionId },
    });

    return {
      transactionId,
      status: payment?.status || 'UNKNOWN',
      amount: payment?.amount ? Number(payment.amount) : 0,
    };
  }
}
