import { Module } from '@nestjs/common';
import { QCController } from './qc.controller';
import { QCService } from './qc.service';
import { PrismaService } from '../prisma/prisma.service';

@Module({
  controllers: [QCController],
  providers: [QCService, PrismaService],
  exports: [QCService],
})
export class QCModule {}
