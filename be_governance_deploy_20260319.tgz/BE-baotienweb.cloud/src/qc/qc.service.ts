import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    BugFilterDto,
    BugSeverity,
    BugStatus,
    CompleteInspectionDto,
    CreateBugDto,
    CreateInspectionDto,
    CreateQCCategoryDto,
    CreateQCChecklistDto,
    QCStatus,
    UpdateBugDto,
    UpdateInspectionDto,
    UpdateInspectionItemDto,
    UpdateQCCategoryDto,
    UpdateQCChecklistDto,
} from './dto';

@Injectable()
export class QCService {
  constructor(private prisma: PrismaService) {}

  // ==================== Category Management ====================

  async createCategory(data: CreateQCCategoryDto) {
    return this.prisma.qCCategory.create({
      data: {
        name: data.name,
        description: data.description,
        icon: data.icon,
        order: data.order ?? 0,
        isActive: data.isActive ?? true,
      },
    });
  }

  async getCategories(includeInactive = false) {
    return this.prisma.qCCategory.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { order: 'asc' },
      include: {
        _count: {
          select: { checklists: true },
        },
      },
    });
  }

  async getCategoryById(id: number) {
    return this.prisma.qCCategory.findUnique({
      where: { id },
      include: {
        checklists: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });
  }

  async updateCategory(id: number, data: UpdateQCCategoryDto) {
    return this.prisma.qCCategory.update({
      where: { id },
      data,
    });
  }

  async deleteCategory(id: number) {
    return this.prisma.qCCategory.delete({
      where: { id },
    });
  }

  // ==================== Checklist Management ====================

  async createChecklist(data: CreateQCChecklistDto) {
    return this.prisma.qCChecklist.create({
      data: {
        title: data.title,
        description: data.description,
        items: data.items,
        categoryId: data.categoryId,
        projectId: data.projectId,
        isTemplate: data.isTemplate ?? false,
      },
      include: {
        category: true,
        project: true,
      },
    });
  }

  async getChecklists(
    projectId?: number,
    categoryId?: number,
    isTemplate?: boolean,
  ) {
    return this.prisma.qCChecklist.findMany({
      where: {
        projectId,
        categoryId,
        isTemplate,
      },
      include: {
        category: true,
        project: true,
        _count: {
          select: { inspections: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getChecklistById(id: number) {
    return this.prisma.qCChecklist.findUnique({
      where: { id },
      include: {
        category: true,
        project: true,
        inspections: {
          orderBy: { inspectionDate: 'desc' },
          include: {
            inspector: {
              select: { id: true, name: true, email: true },
            },
          },
        },
      },
    });
  }

  async updateChecklist(id: number, data: UpdateQCChecklistDto) {
    return this.prisma.qCChecklist.update({
      where: { id },
      data,
      include: {
        category: true,
      },
    });
  }

  async deleteChecklist(id: number) {
    return this.prisma.qCChecklist.delete({
      where: { id },
    });
  }

  // ==================== Inspection Management ====================

  async createInspection(data: CreateInspectionDto) {
    // Get checklist items to create inspection items
    const checklist = await this.prisma.qCChecklist.findUnique({
      where: { id: data.checklistId },
    });

    if (!checklist) {
      throw new Error('Checklist not found');
    }

    // Create inspection with items
    const inspection = await this.prisma.qCInspection.create({
      data: {
        title: data.title,
        description: data.description,
        checklistId: data.checklistId,
        projectId: data.projectId,
        phaseId: data.phaseId,
        inspectorId: data.inspectorId,
        inspectionDate: data.inspectionDate
          ? new Date(data.inspectionDate)
          : new Date(),
        notes: data.notes,
        status: QCStatus.PENDING,
        items: {
          create: checklist.items.map((itemName, index) => ({
            itemName,
            itemOrder: index,
            status: QCStatus.PENDING,
          })),
        },
      },
      include: {
        checklist: true,
        project: true,
        phase: true,
        inspector: {
          select: { id: true, name: true, email: true },
        },
        items: {
          orderBy: { itemOrder: 'asc' },
        },
      },
    });

    return inspection;
  }

  async getInspections(
    projectId?: number,
    phaseId?: number,
    status?: QCStatus,
  ) {
    return this.prisma.qCInspection.findMany({
      where: {
        projectId,
        phaseId,
        status,
      },
      include: {
        checklist: {
          include: { category: true },
        },
        project: true,
        phase: true,
        inspector: {
          select: { id: true, name: true, email: true },
        },
        items: {
          orderBy: { itemOrder: 'asc' },
        },
        _count: {
          select: { bugs: true },
        },
      },
      orderBy: { inspectionDate: 'desc' },
    });
  }

  async getInspectionById(id: number) {
    return this.prisma.qCInspection.findUnique({
      where: { id },
      include: {
        checklist: {
          include: { category: true },
        },
        project: true,
        phase: true,
        inspector: {
          select: { id: true, name: true, email: true, role: true },
        },
        items: {
          orderBy: { itemOrder: 'asc' },
        },
        bugs: {
          include: {
            assignee: {
              select: { id: true, name: true, email: true },
            },
            reporter: {
              select: { id: true, name: true, email: true },
            },
          },
        },
      },
    });
  }

  async updateInspection(id: number, data: UpdateInspectionDto) {
    return this.prisma.qCInspection.update({
      where: { id },
      data: {
        title: data.title,
        description: data.description,
        status: data.status,
        notes: data.notes,
        overallResult: data.overallResult,
        completedAt: data.completedAt ? new Date(data.completedAt) : undefined,
      },
      include: {
        items: {
          orderBy: { itemOrder: 'asc' },
        },
      },
    });
  }

  async deleteInspection(id: number) {
    return this.prisma.qCInspection.delete({
      where: { id },
    });
  }

  // ==================== Inspection Item Management ====================

  async updateInspectionItem(itemId: number, data: UpdateInspectionItemDto) {
    const item = await this.prisma.qCChecklistItem.update({
      where: { id: itemId },
      data: {
        status: data.status,
        result: data.result,
        beforeImages: data.beforeImages,
        afterImages: data.afterImages,
        beforeVideos: data.beforeVideos,
        afterVideos: data.afterVideos,
        notes: data.notes,
        measurements: data.measurements,
        checkedAt: data.checkedAt ? new Date(data.checkedAt) : new Date(),
      },
      include: {
        inspection: true,
      },
    });

    // Auto-update inspection status
    await this.updateInspectionStatus(item.inspectionId);

    return item;
  }

  private async updateInspectionStatus(inspectionId: number) {
    const inspection = await this.prisma.qCInspection.findUnique({
      where: { id: inspectionId },
      include: {
        items: true,
      },
    });

    if (!inspection) return;

    const totalItems = inspection.items.length;
    const checkedItems = inspection.items.filter(
      (item) => item.status !== QCStatus.PENDING,
    ).length;
    const passedItems = inspection.items.filter(
      (item) => item.result === 'PASS',
    ).length;
    const failedItems = inspection.items.filter(
      (item) => item.result === 'FAIL',
    ).length;

    let status = inspection.status;
    let overallResult = inspection.overallResult;

    if (checkedItems === 0) {
      status = QCStatus.PENDING;
    } else if (checkedItems < totalItems) {
      status = QCStatus.IN_PROGRESS;
    } else {
      // All items checked
      if (failedItems === 0) {
        status = QCStatus.PASSED;
        overallResult = 'PASS';
      } else if (passedItems === 0) {
        status = QCStatus.FAILED;
        overallResult = 'FAIL';
      } else {
        status = QCStatus.NEED_RECHECK;
        overallResult = 'PARTIAL';
      }
    }

    await this.prisma.qCInspection.update({
      where: { id: inspectionId },
      data: {
        status,
        overallResult,
      },
    });
  }

  async completeInspection(inspectionId: number, data: CompleteInspectionDto) {
    const inspection = await this.prisma.qCInspection.update({
      where: { id: inspectionId },
      data: {
        overallResult: data.overallResult,
        notes: data.notes,
        completedAt: new Date(),
        status:
          data.overallResult === 'PASS'
            ? QCStatus.PASSED
            : data.overallResult === 'FAIL'
              ? QCStatus.FAILED
              : QCStatus.NEED_RECHECK,
      },
      include: {
        items: true,
        project: true,
      },
    });

    // Auto-create bugs for failed items
    if (data.autoCreateBugs) {
      await this.autoCreateBugsFromInspection(inspectionId);
    }

    return inspection;
  }

  private async autoCreateBugsFromInspection(inspectionId: number) {
    const inspection = await this.prisma.qCInspection.findUnique({
      where: { id: inspectionId },
      include: {
        items: true,
        inspector: true,
      },
    });

    if (!inspection) return;

    const failedItems = inspection.items.filter(
      (item) => item.result === 'FAIL',
    );

    const bugs = await Promise.all(
      failedItems.map((item) =>
        this.prisma.qCBug.create({
          data: {
            title: `[QC FAIL] ${item.itemName}`,
            description:
              item.notes ||
              `Hạng mục "${item.itemName}" không đạt yêu cầu trong đợt kiểm tra "${inspection.title}"`,
            severity: BugSeverity.MEDIUM,
            status: BugStatus.OPEN,
            projectId: inspection.projectId,
            inspectionId: inspection.id,
            reporterId: inspection.inspectorId,
            images: item.afterImages,
            videos: item.afterVideos,
          },
        }),
      ),
    );

    return bugs;
  }

  // ==================== Bug Management ====================

  async createBug(data: CreateBugDto) {
    return this.prisma.qCBug.create({
      data: {
        title: data.title,
        description: data.description,
        severity: data.severity,
        projectId: data.projectId,
        inspectionId: data.inspectionId,
        location: data.location,
        images: data.images ?? [],
        videos: data.videos ?? [],
        reporterId: data.reporterId,
        assigneeId: data.assigneeId,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
        status: BugStatus.OPEN,
      },
      include: {
        project: true,
        inspection: true,
        reporter: {
          select: { id: true, name: true, email: true },
        },
        assignee: {
          select: { id: true, name: true, email: true },
        },
      },
    });
  }

  async getAllBugs(projectId?: number, filters?: BugFilterDto) {
    return this.prisma.qCBug.findMany({
      where: {
        ...(projectId && { projectId }),
        status: filters?.status,
        severity: filters?.severity,
      },
      include: {
        project: true,
        inspection: {
          include: {
            checklist: {
              include: { category: true },
            },
          },
        },
        reporter: {
          select: { id: true, name: true, email: true },
        },
        assignee: {
          select: { id: true, name: true, email: true },
        },
      },
      orderBy: [{ severity: 'desc' }, { createdAt: 'desc' }],
      take: 100,
    });
  }

  async getBugs(projectId: number, filters?: BugFilterDto) {
    return this.prisma.qCBug.findMany({
      where: {
        projectId,
        status: filters?.status,
        severity: filters?.severity,
        assigneeId: filters?.assigneeId,
        reporterId: filters?.reporterId,
      },
      include: {
        project: true,
        inspection: {
          include: {
            checklist: {
              include: { category: true },
            },
          },
        },
        reporter: {
          select: { id: true, name: true, email: true },
        },
        assignee: {
          select: { id: true, name: true, email: true },
        },
      },
      orderBy: [{ severity: 'desc' }, { createdAt: 'desc' }],
    });
  }

  async getBugById(id: number) {
    return this.prisma.qCBug.findUnique({
      where: { id },
      include: {
        project: true,
        inspection: {
          include: {
            checklist: {
              include: { category: true },
            },
            items: true,
          },
        },
        reporter: {
          select: { id: true, name: true, email: true, role: true },
        },
        assignee: {
          select: { id: true, name: true, email: true, role: true },
        },
      },
    });
  }

  async updateBug(id: number, data: UpdateBugDto) {
    return this.prisma.qCBug.update({
      where: { id },
      data: {
        title: data.title,
        description: data.description,
        severity: data.severity,
        status: data.status,
        location: data.location,
        images: data.images,
        videos: data.videos,
        assigneeId: data.assigneeId,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
        resolution: data.resolution,
        resolutionImages: data.resolutionImages,
        resolutionVideos: data.resolutionVideos,
        resolvedAt: data.resolvedAt ? new Date(data.resolvedAt) : undefined,
        verifiedAt: data.verifiedAt ? new Date(data.verifiedAt) : undefined,
      },
      include: {
        assignee: {
          select: { id: true, name: true, email: true },
        },
      },
    });
  }

  async deleteBug(id: number) {
    return this.prisma.qCBug.delete({
      where: { id },
    });
  }

  // ==================== QC Reports & Statistics ====================

  async getProjectQCReport(projectId: number) {
    const [
      totalInspections,
      passedInspections,
      failedInspections,
      inProgressInspections,
      totalBugs,
      openBugs,
      criticalBugs,
      resolvedBugs,
      inspections,
    ] = await Promise.all([
      this.prisma.qCInspection.count({ where: { projectId } }),
      this.prisma.qCInspection.count({
        where: { projectId, status: QCStatus.PASSED },
      }),
      this.prisma.qCInspection.count({
        where: { projectId, status: QCStatus.FAILED },
      }),
      this.prisma.qCInspection.count({
        where: { projectId, status: QCStatus.IN_PROGRESS },
      }),
      this.prisma.qCBug.count({ where: { projectId } }),
      this.prisma.qCBug.count({
        where: { projectId, status: BugStatus.OPEN },
      }),
      this.prisma.qCBug.count({
        where: { projectId, severity: BugSeverity.CRITICAL },
      }),
      this.prisma.qCBug.count({
        where: { projectId, status: BugStatus.RESOLVED },
      }),
      this.prisma.qCInspection.findMany({
        where: { projectId },
        include: {
          checklist: {
            include: { category: true },
          },
          phase: true,
          inspector: {
            select: { id: true, name: true, email: true },
          },
          items: true,
          _count: {
            select: { bugs: true },
          },
        },
        orderBy: { inspectionDate: 'desc' },
        take: 10, // Latest 10 inspections
      }),
    ]);

    const passRate =
      totalInspections > 0 ? (passedInspections / totalInspections) * 100 : 0;
    const bugResolutionRate =
      totalBugs > 0 ? (resolvedBugs / totalBugs) * 100 : 0;

    return {
      summary: {
        totalInspections,
        passedInspections,
        failedInspections,
        inProgressInspections,
        passRate: Math.round(passRate * 100) / 100,
        totalBugs,
        openBugs,
        criticalBugs,
        resolvedBugs,
        bugResolutionRate: Math.round(bugResolutionRate * 100) / 100,
      },
      recentInspections: inspections,
    };
  }

  async getPhaseQCStats(phaseId: number) {
    const [totalInspections, passedInspections, totalBugs, openBugs] =
      await Promise.all([
        this.prisma.qCInspection.count({ where: { phaseId } }),
        this.prisma.qCInspection.count({
          where: { phaseId, status: QCStatus.PASSED },
        }),
        this.prisma.qCBug.count({
          where: {
            inspection: {
              phaseId,
            },
          },
        }),
        this.prisma.qCBug.count({
          where: {
            inspection: {
              phaseId,
            },
            status: BugStatus.OPEN,
          },
        }),
      ]);

    const passRate =
      totalInspections > 0 ? (passedInspections / totalInspections) * 100 : 0;

    return {
      totalInspections,
      passedInspections,
      passRate: Math.round(passRate * 100) / 100,
      totalBugs,
      openBugs,
    };
  }
}
