import {
  IsString,
  IsOptional,
  IsInt,
  IsBoolean,
  IsArray,
  IsEnum,
  IsDateString,
  ValidateNested,
  IsNumber,
  IsObject,
  Min,
  Max,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

// ==================== Enums ====================

export enum QCStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  PASSED = 'PASSED',
  FAILED = 'FAILED',
  NEED_RECHECK = 'NEED_RECHECK',
}

export enum BugSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

export enum BugStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  VERIFIED = 'VERIFIED',
  CLOSED = 'CLOSED',
  REOPENED = 'REOPENED',
}

// ==================== Category DTOs ====================

export class CreateQCCategoryDto {
  @ApiProperty({ example: 'Móng' })
  @IsString()
  name: string;

  @ApiPropertyOptional({ example: 'Kiểm tra chất lượng móng công trình' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ example: '🏗️' })
  @IsOptional()
  @IsString()
  icon?: string;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  order?: number;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class UpdateQCCategoryDto {
  @ApiPropertyOptional({ example: 'Móng và nền' })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  icon?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  order?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

// ==================== Checklist DTOs ====================

export class CreateQCChecklistDto {
  @ApiProperty({ example: 'Nghiệm thu móng' })
  @IsString()
  title: string;

  @ApiPropertyOptional({ example: 'Checklist nghiệm thu móng và đà giáo' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    example: [
      'Kiểm tra kích thước móng',
      'Kiểm tra độ sâu móng',
      'Kiểm tra chất lượng bê tông',
      'Kiểm tra cốt thép',
      'Kiểm tra độ phẳng mặt móng',
    ],
  })
  @IsArray()
  @IsString({ each: true })
  items: string[];

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  categoryId?: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  projectId?: number;

  @ApiPropertyOptional({ example: false })
  @IsOptional()
  @IsBoolean()
  isTemplate?: boolean;
}

export class UpdateQCChecklistDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  items?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  categoryId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isTemplate?: boolean;
}

// ==================== Inspection DTOs ====================

export class CreateInspectionDto {
  @ApiProperty({ example: 'Nghiệm thu móng - Lần 1' })
  @IsString()
  title: string;

  @ApiPropertyOptional({ example: 'Kiểm tra móng cột A1-A5' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: 1 })
  @IsInt()
  checklistId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  projectId: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  phaseId?: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  inspectorId?: number;

  @ApiPropertyOptional({ example: '2025-01-15T09:00:00.000Z' })
  @IsOptional()
  @IsDateString()
  inspectionDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

export class UpdateInspectionDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: QCStatus })
  @IsOptional()
  @IsEnum(QCStatus)
  status?: QCStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({ example: 'PASS' })
  @IsOptional()
  @IsString()
  overallResult?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  completedAt?: string;
}

export class UpdateInspectionItemDto {
  @ApiPropertyOptional({ enum: QCStatus })
  @IsOptional()
  @IsEnum(QCStatus)
  status?: QCStatus;

  @ApiPropertyOptional({ example: 'PASS' })
  @IsOptional()
  @IsString()
  result?: string;

  @ApiPropertyOptional({
    example: [
      'https://example.com/before-1.jpg',
      'https://example.com/before-2.jpg',
    ],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  beforeImages?: string[];

  @ApiPropertyOptional({
    example: [
      'https://example.com/after-1.jpg',
      'https://example.com/after-2.jpg',
    ],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  afterImages?: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/before-video.mp4'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  beforeVideos?: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/after-video.mp4'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  afterVideos?: string[];

  @ApiPropertyOptional({
    example: 'Kích thước móng đúng theo thiết kế. Bê tông đạt chất lượng.',
  })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    example: { length: 10, width: 5, depth: 2 },
  })
  @IsOptional()
  @IsObject()
  measurements?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  checkedAt?: string;
}

export class CompleteInspectionDto {
  @ApiProperty({ example: 'PASS' })
  @IsString()
  overallResult: string;

  @ApiPropertyOptional({ example: 'Tất cả hạng mục đều đạt yêu cầu' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    example: true,
    description: 'Tự động tạo bug cho các item FAIL',
  })
  @IsOptional()
  @IsBoolean()
  autoCreateBugs?: boolean;
}

// ==================== Bug DTOs ====================

export class CreateBugDto {
  @ApiProperty({ example: 'Móng bị lệch kích thước' })
  @IsString()
  title: string;

  @ApiProperty({ example: 'Móng cột A1 bị lệch 5cm so với thiết kế' })
  @IsString()
  description: string;

  @ApiProperty({ enum: BugSeverity, example: BugSeverity.HIGH })
  @IsEnum(BugSeverity)
  severity: BugSeverity;

  @ApiProperty({ example: 1 })
  @IsInt()
  projectId: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  inspectionId?: number;

  @ApiPropertyOptional({ example: 'Móng cột A1' })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional({
    example: ['https://example.com/bug-1.jpg', 'https://example.com/bug-2.jpg'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  images?: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/bug-video.mp4'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  videos?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  reporterId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  assigneeId?: number;

  @ApiPropertyOptional({ example: '2025-01-20T00:00:00.000Z' })
  @IsOptional()
  @IsDateString()
  dueDate?: string;
}

export class UpdateBugDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: BugSeverity })
  @IsOptional()
  @IsEnum(BugSeverity)
  severity?: BugSeverity;

  @ApiPropertyOptional({ enum: BugStatus })
  @IsOptional()
  @IsEnum(BugStatus)
  status?: BugStatus;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  images?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  videos?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  assigneeId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  dueDate?: string;

  @ApiPropertyOptional({
    example: 'Đã sửa lại móng theo đúng kích thước thiết kế',
  })
  @IsOptional()
  @IsString()
  resolution?: string;

  @ApiPropertyOptional({
    example: ['https://example.com/fix-1.jpg', 'https://example.com/fix-2.jpg'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  resolutionImages?: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/fix-video.mp4'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  resolutionVideos?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  resolvedAt?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  verifiedAt?: string;
}

export class BugFilterDto {
  @ApiPropertyOptional({ enum: BugStatus })
  @IsOptional()
  @IsEnum(BugStatus)
  status?: BugStatus;

  @ApiPropertyOptional({ enum: BugSeverity })
  @IsOptional()
  @IsEnum(BugSeverity)
  severity?: BugSeverity;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  assigneeId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  reporterId?: number;
}
