/**
 * App Module for VPS - Minimal version
 * =====================================
 * Only includes modules that exist on VPS dist folder
 */

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AnalyticsModule } from './analytics/analytics.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AsBuiltModule } from './as-built/as-built.module';
import { AuditLogModule } from './audit/audit-log.module';
import { AuthModule } from './auth/auth.module';
import { AuthorizationModule } from './authorization/authorization.module';
import { CallModule } from './call/call.module';
import { ChatModule } from './chat/chat.module';
import { ConstructionMapModule } from './construction-map/construction-map.module';
import { ConversationMessagesModule } from './conversation-messages/conversation-messages.module';
import { ConversationsModule } from './conversations/conversations.module';
import { DocumentControlModule } from './document-control/document-control.module';
import { EnvironmentalModule } from './environmental/environmental.module';
import { HomeContentModule } from './home-content/home-content.module';
import { LaborModule } from './labor/labor.module';
import { MessagesModule } from './messages/messages.module';
import { PrismaModule } from './prisma/prisma.module';
import { ProductsModule } from './products/products.module';
import { ProfileModule } from './profile/profile.module';
import { QCModule } from './qc/qc.module';
import { ReelsModule } from './reels/reels.module';
import { SafetyModule } from './safety/safety.module';
import { ServicesModule } from './services/services.module';
import { StrapiSyncModule } from './strapi-sync/strapi-sync.module';
import { TimelineModule } from './timeline/timeline.module';
import { UploadModule } from './upload/upload.module';
import { UsersModule } from './users/users.module';
import { UtilitiesModule } from './utilities/utilities.module';
import { ZaloModule } from './zalo/zalo.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 100,
      },
    ]),
    PrismaModule,
    AuditLogModule,
    AuthorizationModule,
    UsersModule,
    AuthModule,
    CallModule,
    ChatModule,
    ConversationsModule,
    ConversationMessagesModule,
    MessagesModule,
    UploadModule,
    ProductsModule,
    ProfileModule,
    TimelineModule,
    QCModule,
    ServicesModule,
    StrapiSyncModule,
    UtilitiesModule,
    ZaloModule,
    ReelsModule,
    ConstructionMapModule,
    LaborModule,
    AnalyticsModule,
    SafetyModule,
    AsBuiltModule,
    EnvironmentalModule,
    DocumentControlModule,
    HomeContentModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
