/**
 * Zalo Module
 * Module tích hợp Zalo API:
 * - Zalo Notification Service (ZNS) - Gửi thông báo qua Zalo
 * - Zalo OA (Official Account) - Quản lý OA
 * - Zalo Login - Đăng nhập bằng Zalo
 */

import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { PrismaModule } from '../prisma/prisma.module';
import { ZaloAuthService } from './zalo-auth.service';
import { ZaloController } from './zalo.controller';
import { ZaloService } from './zalo.service';
import { ZnsService } from './zns.service';

@Module({
  imports: [
    ConfigModule,
    HttpModule.register({
      timeout: 10000,
      maxRedirects: 5,
    }),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get('JWT_SECRET'),
        signOptions: { expiresIn: configService.get('JWT_EXPIRES_IN') || '7d' },
      }),
      inject: [ConfigService],
    }),
    PrismaModule,
  ],
  controllers: [ZaloController],
  providers: [ZaloService, ZnsService, ZaloAuthService],
  exports: [ZaloService, ZnsService, ZaloAuthService],
})
export class ZaloModule {}
