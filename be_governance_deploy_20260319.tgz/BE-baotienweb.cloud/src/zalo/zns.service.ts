/**
 * Zalo Notification Service (ZNS)
 * Service gửi thông báo qua Zalo
 *
 * Tài liệu: https://developers.zalo.me/docs/zalo-notification-service
 *
 * QUAN TRỌNG - Cập nhật 30/11/2025:
 * - Quyền sở hữu Template đã thay đổi: Template thuộc sở hữu OA (không còn đồng sở hữu OA + App)
 * - API filterPreset mới cho lấy danh sách template
 * - Tham khảo: https://developers.zalo.me/changelog/v251115-cap-nhat-quyen-so-huu-template-cua-oa-tu-ngay-30112025-7799
 */

import { HttpService } from '@nestjs/axios';
import {
    getAxiosErrorData
} from '../utils/error-helpers';

import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { firstValueFrom } from 'rxjs';
import {
    SendZnsDto,
    SendZnsOtpDto,
    ZnsSendResponseDto,
    ZnsTemplateDto,
} from './dto/zalo.dto';

// API Endpoints
const ZNS_API = {
  // Gửi ZNS
  SEND: 'https://business.openapi.zalo.me/message/template',
  SEND_HASH: 'https://business.openapi.zalo.me/message/template/hashphone',
  SEND_DEV: 'https://business.openapi.zalo.me/message/template/development',

  // Template Management
  TEMPLATE_LIST: 'https://business.openapi.zalo.me/template/all',
  TEMPLATE_DETAIL: 'https://business.openapi.zalo.me/template/info',
  TEMPLATE_SAMPLE: 'https://business.openapi.zalo.me/template/sample-data',

  // OA API
  OA_INFO: 'https://openapi.zalo.me/v2.0/oa/getoa',
  OA_FOLLOWER: 'https://openapi.zalo.me/v2.0/oa/getfollowers',
  OA_MESSAGE: 'https://openapi.zalo.me/v2.0/oa/message',

  // Token
  REFRESH_TOKEN: 'https://oauth.zaloapp.com/v4/oa/access_token',
};

// Error codes
const ZNS_ERROR = {
  SUCCESS: 0,
  INVALID_ACCESS_TOKEN: -124,
  INVALID_TEMPLATE: -207,
  INVALID_PHONE: -208,
  QUOTA_EXCEEDED: -210,
  TEMPLATE_NOT_APPROVED: -211,
  USER_NOT_RECEIVE: -212, // User chặn OA hoặc chưa follow
  RATE_LIMIT: -213,
  INVALID_DATA: -214,
};

export interface ZnsConfig {
  appId: string;
  appSecret: string;
  oaAccessToken: string;
  oaRefreshToken?: string;
  oaSecretKey?: string;
  defaultOtpTemplateId?: string;
}

@Injectable()
export class ZnsService {
  private readonly logger = new Logger(ZnsService.name);
  private config: ZnsConfig;
  private cachedToken: { token: string; expiresAt: number } | null = null;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {
    this.config = {
      appId: this.configService.get('ZALO_APP_ID') || '',
      appSecret: this.configService.get('ZALO_APP_SECRET') || '',
      oaAccessToken: this.configService.get('ZALO_OA_ACCESS_TOKEN') || '',
      oaRefreshToken: this.configService.get('ZALO_OA_REFRESH_TOKEN'),
      oaSecretKey: this.configService.get('ZALO_OA_SECRET_KEY'),
      defaultOtpTemplateId: this.configService.get('ZALO_OTP_TEMPLATE_ID'),
    };
  }

  // ============================================
  // ACCESS TOKEN MANAGEMENT
  // ============================================

  /**
   * Lấy Access Token (có cache)
   */
  private async getAccessToken(): Promise<string> {
    // Check cache
    if (this.cachedToken && this.cachedToken.expiresAt > Date.now()) {
      return this.cachedToken.token;
    }

    // Nếu có refresh token, làm mới
    if (this.config.oaRefreshToken) {
      try {
        const newToken = await this.refreshAccessToken();
        return newToken;
      } catch (error: unknown) {
        this.logger.warn('Failed to refresh token, using configured token');
      }
    }

    return this.config.oaAccessToken;
  }

  /**
   * Refresh Access Token
   * Token mới có thời hạn 90 ngày
   */
  async refreshAccessToken(): Promise<string> {
    if (!this.config.oaRefreshToken) {
      throw new HttpException(
        'Refresh token not configured',
        HttpStatus.BAD_REQUEST,
      );
    }

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          ZNS_API.REFRESH_TOKEN,
          new URLSearchParams({
            app_id: this.config.appId,
            grant_type: 'refresh_token',
            refresh_token: this.config.oaRefreshToken,
          }).toString(),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              secret_key: this.config.appSecret,
            },
          },
        ),
      );

      const data = response.data;
      if (data.error) {
        throw new HttpException(
          `Zalo token refresh failed: ${data.error_description}`,
          HttpStatus.UNAUTHORIZED,
        );
      }

      // Cache token (expire 90 ngày, refresh trước 1 ngày)
      this.cachedToken = {
        token: data.access_token,
        expiresAt: Date.now() + 89 * 24 * 60 * 60 * 1000,
      };

      this.logger.log('Zalo access token refreshed successfully');
      return data.access_token;
    } catch (error: unknown) {
      this.logger.error('Failed to refresh Zalo token', error);
      throw error;
    }
  }

  /**
   * Tính app_secret_proof (HMAC-SHA256)
   * Bắt buộc từ v240409
   */
  private generateSecretProof(accessToken: string): string {
    return crypto
      .createHmac('sha256', this.config.appSecret)
      .update(accessToken)
      .digest('hex');
  }

  // ============================================
  // SEND ZNS
  // ============================================

  /**
   * Gửi ZNS thông thường
   */
  async sendZns(dto: SendZnsDto): Promise<ZnsSendResponseDto> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);

    // Format phone to 84xxx
    const phone = this.formatPhone(dto.phone);

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          ZNS_API.SEND,
          {
            phone,
            template_id: dto.templateId,
            template_data: dto.templateData,
            tracking_id: dto.trackingId,
          },
          {
            headers: {
              'Content-Type': 'application/json',
              access_token: accessToken,
              appsecret_proof: secretProof,
            },
          },
        ),
      );

      const result = this.parseZnsResponse(response.data);
      this.logger.log(
        `ZNS sent to ${this.maskPhone(phone)}: ${result.message}`,
      );
      return result;
    } catch (error: unknown) {
      this.logger.error('Send ZNS failed', error);
      throw this.handleZnsError(error);
    }
  }

  /**
   * Gửi ZNS với Development Mode
   * Chỉ gửi tới số đã đăng ký test
   */
  async sendZnsDevelopment(dto: SendZnsDto): Promise<ZnsSendResponseDto> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);
    const phone = this.formatPhone(dto.phone);

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          ZNS_API.SEND_DEV,
          {
            phone,
            template_id: dto.templateId,
            template_data: dto.templateData,
            tracking_id: dto.trackingId,
          },
          {
            headers: {
              'Content-Type': 'application/json',
              access_token: accessToken,
              appsecret_proof: secretProof,
            },
          },
        ),
      );

      return this.parseZnsResponse(response.data);
    } catch (error: unknown) {
      throw this.handleZnsError(error);
    }
  }

  /**
   * Gửi ZNS OTP
   * Sử dụng template OTP đã đăng ký
   */
  async sendOtpZns(dto: SendZnsOtpDto): Promise<ZnsSendResponseDto> {
    const templateId = dto.templateId || this.config.defaultOtpTemplateId;

    if (!templateId) {
      throw new HttpException(
        'OTP Template ID không được cấu hình',
        HttpStatus.BAD_REQUEST,
      );
    }

    // OTP template thường có các param: otp, name, expire_time
    const templateData: Record<string, string | number> = {
      otp: dto.otp,
    };

    if (dto.recipientName) {
      templateData.customer_name = dto.recipientName;
    }

    if (dto.expiresInMinutes) {
      templateData.expire_time = `${dto.expiresInMinutes} phút`;
    }

    return this.sendZns({
      phone: dto.phone,
      templateId,
      templateData,
      trackingId: `otp_${Date.now()}`,
    });
  }

  /**
   * Gửi ZNS với hash phone (SHA256)
   * Sử dụng khi không muốn gửi phone qua API
   */
  async sendZnsHashPhone(
    hashedPhone: string,
    templateId: string,
    templateData: Record<string, string | number>,
    trackingId?: string,
  ): Promise<ZnsSendResponseDto> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          ZNS_API.SEND_HASH,
          {
            phone: hashedPhone,
            template_id: templateId,
            template_data: templateData,
            tracking_id: trackingId,
          },
          {
            headers: {
              'Content-Type': 'application/json',
              access_token: accessToken,
              appsecret_proof: secretProof,
            },
          },
        ),
      );

      return this.parseZnsResponse(response.data);
    } catch (error: unknown) {
      throw this.handleZnsError(error);
    }
  }

  // ============================================
  // TEMPLATE MANAGEMENT
  // ============================================

  /**
   * Lấy danh sách templates
   *
   * Cập nhật 30/11/2025:
   * - filterPreset=0: Tất cả template của OA
   * - filterPreset=1: Chỉ template do App hiện tại tạo
   */
  async getTemplateList(
    offset = 0,
    limit = 100,
    filterPreset?: 0 | 1,
  ): Promise<{ templates: ZnsTemplateDto[]; total: number }> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);

    try {
      let url = `${ZNS_API.TEMPLATE_LIST}?offset=${offset}&limit=${limit}`;
      if (filterPreset !== undefined) {
        url += `&filterPreset=${filterPreset}`;
      }

      const response = await firstValueFrom(
        this.httpService.get(url, {
          headers: {
            access_token: accessToken,
            appsecret_proof: secretProof,
          },
        }),
      );

      const data = response.data;
      if (data.error !== 0) {
        throw new HttpException(data.message, HttpStatus.BAD_REQUEST);
      }

      return {
        templates: data.data?.map(this.mapTemplateResponse) || [],
        total: data.data?.length || 0,
      };
    } catch (error: unknown) {
      throw this.handleZnsError(error);
    }
  }

  /**
   * Lấy chi tiết template
   */
  async getTemplateDetail(templateId: string): Promise<ZnsTemplateDto | null> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);

    try {
      const response = await firstValueFrom(
        this.httpService.get(
          `${ZNS_API.TEMPLATE_DETAIL}?template_id=${templateId}`,
          {
            headers: {
              access_token: accessToken,
              appsecret_proof: secretProof,
            },
          },
        ),
      );

      const data = response.data;
      if (data.error !== 0) {
        return null;
      }

      return this.mapTemplateResponse(data.data);
    } catch (error: unknown) {
      this.logger.error(`Get template ${templateId} failed`, error);
      return null;
    }
  }

  /**
   * Lấy dữ liệu mẫu của template
   */
  async getTemplateSampleData(
    templateId: string,
  ): Promise<Record<string, string> | null> {
    const accessToken = await this.getAccessToken();
    const secretProof = this.generateSecretProof(accessToken);

    try {
      const response = await firstValueFrom(
        this.httpService.get(
          `${ZNS_API.TEMPLATE_SAMPLE}?template_id=${templateId}`,
          {
            headers: {
              access_token: accessToken,
              appsecret_proof: secretProof,
            },
          },
        ),
      );

      if (response.data.error !== 0) {
        return null;
      }

      return response.data.data;
    } catch (error: unknown) {
      return null;
    }
  }

  // ============================================
  // OA MANAGEMENT
  // ============================================

  /**
   * Lấy thông tin OA
   */
  async getOaInfo(): Promise<any> {
    const accessToken = await this.getAccessToken();

    try {
      const response = await firstValueFrom(
        this.httpService.get(ZNS_API.OA_INFO, {
          headers: {
            access_token: accessToken,
          },
        }),
      );

      return response.data.data;
    } catch (error: unknown) {
      throw this.handleZnsError(error);
    }
  }

  /**
   * Gửi tin nhắn từ OA tới user
   */
  async sendOaMessage(
    userId: string,
    message: string,
    type: 'text' | 'image' = 'text',
    attachmentUrl?: string,
  ): Promise<any> {
    const accessToken = await this.getAccessToken();

    const body: any = {
      recipient: { user_id: userId },
      message: {},
    };

    if (type === 'text') {
      body.message.text = message;
    } else if (type === 'image' && attachmentUrl) {
      body.message.attachment = {
        type: 'template',
        payload: {
          template_type: 'media',
          elements: [{ media_type: 'image', url: attachmentUrl }],
        },
      };
    }

    try {
      const response = await firstValueFrom(
        this.httpService.post(ZNS_API.OA_MESSAGE, body, {
          headers: {
            'Content-Type': 'application/json',
            access_token: accessToken,
          },
        }),
      );

      return response.data;
    } catch (error: unknown) {
      throw this.handleZnsError(error);
    }
  }

  // ============================================
  // UTILITIES
  // ============================================

  /**
   * Format số điện thoại về dạng 84xxx
   */
  formatPhone(phone: string): string {
    const cleaned = phone.replace(/\D/g, '');

    if (cleaned.startsWith('84')) {
      return cleaned;
    }

    if (cleaned.startsWith('0')) {
      return '84' + cleaned.substring(1);
    }

    return '84' + cleaned;
  }

  /**
   * Hash số điện thoại (SHA256)
   */
  hashPhone(phone: string): string {
    const formatted = this.formatPhone(phone);
    return crypto.createHash('sha256').update(formatted).digest('hex');
  }

  /**
   * Mask số điện thoại cho log
   */
  private maskPhone(phone: string): string {
    if (phone.length < 6) return '****';
    return phone.substring(0, 4) + '****' + phone.substring(phone.length - 3);
  }

  /**
   * Parse response từ Zalo API
   */
  private parseZnsResponse(data: any): ZnsSendResponseDto {
    return {
      error: data.error || 0,
      message: data.message || 'Success',
      msg_id: data.data?.msg_id,
      remaining_quota: data.data?.remaining_quota,
      sent_time: data.data?.sent_time,
    };
  }

  /**
   * Map template response
   */
  private mapTemplateResponse(data: any): ZnsTemplateDto {
    return {
      templateId: data.template_id || data.templateId,
      templateName: data.template_name || data.templateName,
      templateTag: data.template_tag || data.templateTag,
      status: data.status,
      previewUrl: data.preview_url || data.previewUrl,
      createdTime: data.created_time || data.createdTime,
      params: data.list_params?.map((p: any) => p.name) || [],
    };
  }

  /**
   * Handle Zalo API errors
   */
  private handleZnsError(error: any): HttpException {
    if (error instanceof HttpException) {
      return error;
    }

    const response = getAxiosErrorData(error) as
      | { error?: number; message?: string }
      | undefined;
    if (response) {
      const errorCode = response.error;
      let message = response.message || 'Zalo API error';
      let status = HttpStatus.BAD_REQUEST;

      switch (errorCode) {
        case ZNS_ERROR.INVALID_ACCESS_TOKEN:
          message = 'Access token không hợp lệ hoặc hết hạn';
          status = HttpStatus.UNAUTHORIZED;
          break;
        case ZNS_ERROR.INVALID_TEMPLATE:
          message = 'Template không tồn tại hoặc không được duyệt';
          break;
        case ZNS_ERROR.INVALID_PHONE:
          message = 'Số điện thoại không hợp lệ';
          break;
        case ZNS_ERROR.QUOTA_EXCEEDED:
          message = 'Đã vượt quá hạn mức gửi ZNS';
          status = HttpStatus.TOO_MANY_REQUESTS;
          break;
        case ZNS_ERROR.USER_NOT_RECEIVE:
          message =
            'Người dùng không nhận thông báo (chặn OA hoặc chưa follow)';
          break;
        case ZNS_ERROR.RATE_LIMIT:
          message = 'Vượt quá giới hạn request';
          status = HttpStatus.TOO_MANY_REQUESTS;
          break;
      }

      return new HttpException({ error: errorCode, message }, status);
    }

    return new HttpException(
      'Không thể kết nối tới Zalo API',
      HttpStatus.SERVICE_UNAVAILABLE,
    );
  }
}
