/**
 * Zalo Service
 * Service tổng hợp các chức năng Zalo
 */

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ZaloAuthService } from './zalo-auth.service';
import { ZnsService } from './zns.service';

@Injectable()
export class ZaloService {
  private readonly logger = new Logger(ZaloService.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly znsService: ZnsService,
    private readonly zaloAuthService: ZaloAuthService,
  ) {}

  /**
   * Check Zalo configuration status
   */
  async getConfigStatus(): Promise<{
    zaloAppConfigured: boolean;
    znsConfigured: boolean;
    otpConfigured: boolean;
  }> {
    const zaloAppId = this.configService.get('ZALO_APP_ID');
    const zaloAppSecret = this.configService.get('ZALO_APP_SECRET');
    const oaAccessToken = this.configService.get('ZALO_OA_ACCESS_TOKEN');
    const getOtpKey = this.configService.get('GETOTP_API_KEY');

    return {
      zaloAppConfigured: !!(zaloAppId && zaloAppSecret),
      znsConfigured: !!(oaAccessToken),
      otpConfigured: !!(getOtpKey || oaAccessToken),
    };
  }

  /**
   * Get Zalo integration info
   */
  getIntegrationInfo(): {
    features: string[];
    documentation: string[];
    endpoints: { method: string; path: string; description: string }[];
  } {
    return {
      features: [
        'Zalo Login (OAuth 2.0 + PKCE)',
        'Phone OTP Authentication',
        'Zalo Notification Service (ZNS)',
        'OA Message API',
        'Template Management',
      ],
      documentation: [
        'https://developers.zalo.me/docs/zalo-login',
        'https://developers.zalo.me/docs/zalo-notification-service',
        'https://developers.zalo.me/docs/official-account-api',
      ],
      endpoints: [
        { method: 'POST', path: '/v1/zalo/login', description: 'Đăng nhập bằng Zalo' },
        { method: 'POST', path: '/v1/zalo/send-otp', description: 'Gửi OTP tới số điện thoại' },
        { method: 'POST', path: '/v1/zalo/verify-otp', description: 'Xác thực OTP' },
        { method: 'POST', path: '/v1/zalo/register-phone', description: 'Đăng ký bằng số điện thoại' },
        { method: 'POST', path: '/v1/zalo/send-zns', description: 'Gửi ZNS notification' },
        { method: 'GET', path: '/v1/zalo/templates', description: 'Lấy danh sách templates' },
        { method: 'POST', path: '/v1/zalo/webhook', description: 'Zalo webhook receiver' },
      ],
    };
  }
}
