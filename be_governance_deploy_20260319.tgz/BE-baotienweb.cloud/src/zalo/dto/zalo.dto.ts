/**
 * Zalo DTOs
 * Data Transfer Objects cho Zalo API integration
 */

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Length,
    Matches,
    Max,
    Min
} from 'class-validator';

// ============================================
// ZALO LOGIN DTOs
// ============================================

export class ZaloLoginDto {
  @ApiProperty({ description: 'Zalo OAuth code từ mobile/web SDK' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiPropertyOptional({ description: 'Code verifier cho PKCE flow' })
  @IsString()
  @IsOptional()
  codeVerifier?: string;

  @ApiPropertyOptional({ description: 'Redirect URI đã đăng ký' })
  @IsString()
  @IsOptional()
  redirectUri?: string;
}

export class ZaloUserInfoDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  name: string;

  @ApiPropertyOptional()
  picture?: {
    data: {
      url: string;
    };
  };

  @ApiPropertyOptional()
  birthday?: string;

  @ApiPropertyOptional()
  gender?: string;
}

// ============================================
// PHONE OTP DTOs
// ============================================

export class SendOtpDto {
  @ApiProperty({ 
    description: 'Số điện thoại Việt Nam (84xxx hoặc 0xxx)',
    example: '0912345678'
  })
  @IsString()
  @IsNotEmpty()
  @Matches(/^(0|84|\+84)?[35789][0-9]{8}$/, {
    message: 'Số điện thoại không hợp lệ. Phải là số điện thoại Việt Nam',
  })
  phone: string;

  @ApiPropertyOptional({ 
    description: 'Kênh gửi OTP',
    enum: ['sms', 'voice', 'viber', 'zalo'],
    default: 'sms'
  })
  @IsString()
  @IsOptional()
  @IsEnum(['sms', 'voice', 'viber', 'zalo'])
  channel?: 'sms' | 'voice' | 'viber' | 'zalo';
}

export class VerifyOtpDto {
  @ApiProperty({ description: 'Số điện thoại đã gửi OTP' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ description: 'Mã OTP 6 chữ số', example: '123456' })
  @IsString()
  @IsNotEmpty()
  @Length(6, 6, { message: 'OTP phải có đúng 6 chữ số' })
  @Matches(/^[0-9]{6}$/, { message: 'OTP chỉ chứa chữ số' })
  otp: string;

  @ApiPropertyOptional({ description: 'Session ID từ bước gửi OTP' })
  @IsString()
  @IsOptional()
  sessionId?: string;
}

export class PhoneRegisterDto {
  @ApiProperty({ description: 'Số điện thoại đã xác thực' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ description: 'Tên hiển thị' })
  @IsString()
  @IsNotEmpty()
  @Length(2, 100)
  name: string;

  @ApiPropertyOptional({ description: 'Email (optional)' })
  @IsString()
  @IsOptional()
  email?: string;

  @ApiPropertyOptional({ description: 'Mật khẩu (optional cho guest)' })
  @IsString()
  @IsOptional()
  @Length(6, 100)
  password?: string;

  @ApiPropertyOptional({ description: 'Mã giới thiệu' })
  @IsString()
  @IsOptional()
  referralCode?: string;

  @ApiPropertyOptional({ description: 'Zalo ID nếu đăng nhập qua Zalo' })
  @IsString()
  @IsOptional()
  zaloId?: string;
}

// ============================================
// ZNS (ZALO NOTIFICATION SERVICE) DTOs
// ============================================

export enum ZnsTemplateTag {
  OTP = 'OTP',                           // Mã xác thực
  TRANSACTION = 'transaction',           // Giao dịch
  FOLLOW_UP = 'follow_up',               // Theo dõi
  PROMOTION = 'promotion',               // Khuyến mãi (cần điểm Quality Score)
  CUSTOMER_CARE = 'customer_care',       // Chăm sóc khách hàng
  GENERAL_UPDATE = 'general_update',     // Cập nhật chung
}

export class ZnsTemplateDataDto {
  @ApiProperty({ description: 'Key-value data cho template' })
  @IsObject()
  data: Record<string, string | number>;
}

export class SendZnsDto {
  @ApiProperty({ 
    description: 'Số điện thoại người nhận (84xxx)',
    example: '84912345678'
  })
  @IsString()
  @IsNotEmpty()
  @Matches(/^84[35789][0-9]{8}$/, {
    message: 'Số điện thoại phải ở định dạng 84xxx',
  })
  phone: string;

  @ApiProperty({ 
    description: 'Template ID đã được duyệt',
    example: '123456'
  })
  @IsString()
  @IsNotEmpty()
  templateId: string;

  @ApiProperty({ 
    description: 'Dữ liệu điền vào template',
    example: { otp: '123456', name: 'Nguyễn Văn A' }
  })
  @IsObject()
  templateData: Record<string, string | number>;

  @ApiPropertyOptional({ 
    description: 'Tracking ID để theo dõi',
    example: 'order_123'
  })
  @IsString()
  @IsOptional()
  trackingId?: string;
}

export class SendZnsHashPhoneDto extends SendZnsDto {
  @ApiProperty({ 
    description: 'Số điện thoại đã hash SHA256',
    example: '5a1f8b9c...'
  })
  @IsString()
  @IsNotEmpty()
  @Matches(/^[a-f0-9]{64}$/, { message: 'Hash phone không hợp lệ' })
  declare phone: string;
}

export class SendZnsOtpDto {
  @ApiProperty({ description: 'Số điện thoại người nhận' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ description: 'Mã OTP để gửi' })
  @IsString()
  @IsNotEmpty()
  @Length(4, 8)
  otp: string;

  @ApiPropertyOptional({ description: 'Tên người nhận (optional)' })
  @IsString()
  @IsOptional()
  recipientName?: string;

  @ApiPropertyOptional({ 
    description: 'Template ID cho OTP (mặc định: OTP_TEMPLATE)',
    example: '282448'
  })
  @IsString()
  @IsOptional()
  templateId?: string;

  @ApiPropertyOptional({ 
    description: 'Thời gian hết hạn OTP (phút)',
    default: 5
  })
  @IsNumber()
  @IsOptional()
  @Min(1)
  @Max(30)
  expiresInMinutes?: number;
}

// ============================================
// ZNS TEMPLATE DTOs
// ============================================

export class CreateZnsTemplateDto {
  @ApiProperty({ description: 'Tên template' })
  @IsString()
  @IsNotEmpty()
  @Length(3, 100)
  templateName: string;

  @ApiProperty({ 
    description: 'Loại template',
    enum: ZnsTemplateTag
  })
  @IsEnum(ZnsTemplateTag)
  templateTag: ZnsTemplateTag;

  @ApiProperty({ description: 'Nội dung template với placeholder {{param}}' })
  @IsString()
  @IsNotEmpty()
  content: string;

  @ApiPropertyOptional({ description: 'Ghi chú mục đích sử dụng' })
  @IsString()
  @IsOptional()
  note?: string;
}

export class ZnsTemplateDto {
  @ApiProperty()
  templateId: string;

  @ApiProperty()
  templateName: string;

  @ApiProperty({ enum: ZnsTemplateTag })
  templateTag: ZnsTemplateTag;

  @ApiProperty({ enum: ['ENABLE', 'PENDING', 'DISABLE', 'REJECT'] })
  status: 'ENABLE' | 'PENDING' | 'DISABLE' | 'REJECT';

  @ApiProperty()
  previewUrl: string;

  @ApiPropertyOptional()
  createdTime?: number;

  @ApiPropertyOptional()
  params?: string[];
}

export class ZnsTemplateListResponseDto {
  @ApiProperty({ type: [ZnsTemplateDto] })
  data: ZnsTemplateDto[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  offset: number;

  @ApiProperty()
  limit: number;
}

// ============================================
// ZNS RESPONSE DTOs
// ============================================

export class ZnsSendResponseDto {
  @ApiProperty({ description: 'Mã lỗi (0 = thành công)' })
  error: number;

  @ApiProperty({ description: 'Thông báo kết quả' })
  message: string;

  @ApiPropertyOptional({ description: 'Message ID để tracking' })
  msg_id?: string;

  @ApiPropertyOptional({ description: 'Số dư còn lại' })
  remaining_quota?: number;

  @ApiPropertyOptional({ description: 'Thời gian gửi (ms)' })
  sent_time?: number;
}

// ============================================
// WEBHOOK DTOs
// ============================================

export enum ZnsWebhookEvent {
  ZNS_SENT = 'zns_sent',
  ZNS_DELIVERED = 'zns_delivered',
  ZNS_CLICKED = 'zns_clicked',
  ZNS_FAILED = 'zns_failed',
  TEMPLATE_STATUS_CHANGE = 'template_status_change',
  USER_FOLLOW = 'user_follow_oa',
  USER_UNFOLLOW = 'user_unfollow_oa',
  USER_SEND_TEXT = 'user_send_text',
}

export class ZnsWebhookPayloadDto {
  @ApiProperty({ description: 'Loại sự kiện' })
  @IsString()
  event_name: string;

  @ApiProperty({ description: 'OA ID' })
  @IsString()
  oa_id: string;

  @ApiProperty({ description: 'App ID' })
  @IsString()
  app_id: string;

  @ApiProperty({ description: 'Timestamp' })
  @IsNumber()
  timestamp: number;

  @ApiPropertyOptional({ description: 'User ID (nếu có)' })
  @IsString()
  @IsOptional()
  user_id?: string;

  @ApiPropertyOptional({ description: 'Message ID' })
  @IsString()
  @IsOptional()
  msg_id?: string;

  @ApiPropertyOptional({ description: 'Tracking ID' })
  @IsString()
  @IsOptional()
  tracking_id?: string;

  @ApiPropertyOptional({ description: 'Extra data' })
  @IsObject()
  @IsOptional()
  data?: Record<string, any>;
}

// ============================================
// OA (OFFICIAL ACCOUNT) DTOs
// ============================================

export class OaInfoDto {
  @ApiProperty()
  oaId: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  description?: string;

  @ApiProperty()
  avatar?: string;

  @ApiProperty()
  cover?: string;

  @ApiProperty()
  isVerified: boolean;

  @ApiProperty()
  oaType: 'PERSONAL' | 'BUSINESS';

  @ApiProperty()
  cateId?: number;

  @ApiProperty()
  numFollower?: number;
}

export class OaFollowerDto {
  @ApiProperty()
  userId: string;

  @ApiProperty()
  displayName: string;

  @ApiProperty()
  avatar?: string;

  @ApiProperty()
  followedDate: number;

  @ApiProperty()
  tags?: string[];
}

export class OaMessageDto {
  @ApiProperty({ description: 'User ID người nhận' })
  @IsString()
  @IsNotEmpty()
  userId: string;

  @ApiProperty({ description: 'Nội dung tin nhắn' })
  @IsString()
  @IsNotEmpty()
  @Length(1, 2000)
  message: string;

  @ApiPropertyOptional({ description: 'Loại tin nhắn', default: 'text' })
  @IsString()
  @IsOptional()
  @IsEnum(['text', 'image', 'file', 'sticker'])
  type?: 'text' | 'image' | 'file' | 'sticker';

  @ApiPropertyOptional({ description: 'Attachment URL (cho image/file)' })
  @IsString()
  @IsOptional()
  attachmentUrl?: string;
}
