/**
 * Zalo Authentication Service
 * Xử lý Zalo OAuth và Phone OTP login
 *
 * Hỗ trợ:
 * - Zalo Login (OAuth 2.0 + PKCE)
 * - Phone OTP (qua GetOTP hoặc Zalo ZNS)
 */

import { HttpService } from '@nestjs/axios';
import {
    getAxiosErrorData,
    getErrorMessage
} from '../utils/error-helpers';

import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { firstValueFrom } from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';
import { ZnsService } from './zns.service';

// Zalo OAuth endpoints
const ZALO_AUTH = {
  ACCESS_TOKEN: 'https://oauth.zaloapp.com/v4/access_token',
  USER_INFO: 'https://graph.zalo.me/v2.0/me',
};

// OTP Providers - GetOTP API v1 (https://otp.dev/en/docs/)
const OTP_PROVIDERS = {
  GETOTP: 'https://api.otp.dev/v1/verifications',
  GETOTP_VERIFY: 'https://api.otp.dev/v1/verifications',
};

export interface ZaloUserInfo {
  id: string;
  name: string;
  picture?: {
    data: {
      url: string;
    };
  };
  birthday?: string;
  gender?: string;
}

export interface OtpSession {
  phone: string;
  otp?: string;
  sessionId: string;
  provider: 'getotp' | 'zalo';
  expiresAt: number;
  attempts: number;
  lastSent: number;
  verified: boolean;
}

@Injectable()
export class ZaloAuthService {
  private readonly logger = new Logger(ZaloAuthService.name);
  private otpSessions: Map<string, OtpSession> = new Map();

  // Config
  private zaloAppId: string;
  private zaloAppSecret: string;
  private getOtpApiKey: string;
  private otpProvider: 'getotp' | 'zalo';

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
    private readonly jwtService: JwtService,
    private readonly prisma: PrismaService,
    private readonly znsService: ZnsService,
  ) {
    this.zaloAppId = this.configService.get('ZALO_APP_ID') || '';
    this.zaloAppSecret = this.configService.get('ZALO_APP_SECRET') || '';
    this.getOtpApiKey = this.configService.get('GETOTP_API_KEY') || '';
    this.otpProvider =
      (this.configService.get('OTP_PROVIDER') as 'getotp' | 'zalo') || 'getotp';
  }

  // ============================================
  // ZALO OAUTH LOGIN
  // ============================================

  /**
   * Exchange Zalo auth code for tokens và user info
   */
  async zaloLogin(
    code: string,
    codeVerifier?: string,
    redirectUri?: string,
  ): Promise<{ accessToken: string; refreshToken: string; user: any }> {
    try {
      // 1. Exchange code for Zalo access token
      const tokenResponse = await this.exchangeZaloCode(
        code,
        codeVerifier,
        redirectUri,
      );

      // 2. Get user info from Zalo
      const zaloUser = await this.getZaloUserInfo(tokenResponse.access_token);

      // 3. Find or create user in our DB
      let user = await this.prisma.user.findFirst({
        where: {
          OR: [
            { zaloId: zaloUser.id },
            // { email: `zalo_${zaloUser.id}@zalo.me` }, // Fallback email
          ],
        },
      });

      if (!user) {
        // Create new user
        const randomPassword = await this.hashPassword(
          `zalo_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`,
        );

        user = await this.prisma.user.create({
          data: {
            name: zaloUser.name,
            email: `zalo_${zaloUser.id}@zalo.me`,
            password: randomPassword,
            role: Role.CLIENT,
            zaloId: zaloUser.id,
            avatar: zaloUser.picture?.data?.url,
          },
        });
      } else if (!user.zaloId) {
        // Link existing user with Zalo
        user = await this.prisma.user.update({
          where: { id: user.id },
          data: {
            zaloId: zaloUser.id,
            avatar: user.avatar || zaloUser.picture?.data?.url,
          },
        });
      }

      // 4. Generate our JWT tokens
      const tokens = await this.generateTokens(user.id, user.email, user.role);
      await this.updateRefreshToken(user.id, tokens.refreshToken);

      return {
        ...tokens,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          zaloId: user.zaloId,
          avatar: user.avatar,
          phone: user.phone,
        },
      };
    } catch (error: unknown) {
      this.logger.error('Zalo login failed', error);
      throw new HttpException(
        getErrorMessage(error) || 'Đăng nhập Zalo thất bại',
        HttpStatus.UNAUTHORIZED,
      );
    }
  }

  /**
   * Exchange Zalo OAuth code for access token
   */
  private async exchangeZaloCode(
    code: string,
    codeVerifier?: string,
    redirectUri?: string,
  ): Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
  }> {
    const body: any = {
      app_id: this.zaloAppId,
      grant_type: 'authorization_code',
      code,
    };

    if (codeVerifier) {
      body.code_verifier = codeVerifier;
    }

    if (redirectUri) {
      body.redirect_uri = redirectUri;
    }

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          ZALO_AUTH.ACCESS_TOKEN,
          new URLSearchParams(body).toString(),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              secret_key: this.zaloAppSecret,
            },
          },
        ),
      );

      if (response.data.error) {
        throw new Error(response.data.error_description || 'Invalid Zalo code');
      }

      return response.data;
    } catch (error: unknown) {
      throw new HttpException(
        'Invalid Zalo authorization code',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  /**
   * Exchange OA Authorization Code for Access Token
   * Dùng để lấy access token cho Official Account
   * API: https://oauth.zaloapp.com/v4/oa/access_token
   */
  async exchangeOaCode(code: string): Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
  }> {
    const OA_TOKEN_URL = 'https://oauth.zaloapp.com/v4/oa/access_token';

    try {
      this.logger.log(`Exchanging OA code: ${code.substring(0, 20)}...`);

      const response = await firstValueFrom(
        this.httpService.post(
          OA_TOKEN_URL,
          new URLSearchParams({
            app_id: this.zaloAppId,
            code: code,
            grant_type: 'authorization_code',
          }).toString(),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              secret_key: this.zaloAppSecret,
            },
          },
        ),
      );

      this.logger.log('OA token response:', JSON.stringify(response.data));

      if (response.data.error) {
        throw new HttpException(
          response.data.error_description ||
            `Zalo OA error: ${response.data.error}`,
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        access_token: response.data.access_token,
        refresh_token: response.data.refresh_token,
        expires_in: response.data.expires_in || 90 * 24 * 60 * 60, // 90 days default
      };
    } catch (error: unknown) {
      this.logger.error(
        'Exchange OA code failed:',
        getAxiosErrorData(error) || getErrorMessage(error),
      );
      const axiosData = getAxiosErrorData(error) as
        | { error_description?: string }
        | undefined;
      throw new HttpException(
        axiosData?.error_description ||
          getErrorMessage(error) ||
          'Không thể lấy OA access token',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  /**
   * Get Zalo user info using access token
   */
  private async getZaloUserInfo(accessToken: string): Promise<ZaloUserInfo> {
    try {
      const response = await firstValueFrom(
        this.httpService.get(ZALO_AUTH.USER_INFO, {
          params: { fields: 'id,name,picture,birthday,gender' },
          headers: { access_token: accessToken },
        }),
      );

      if (response.data.error) {
        throw new Error('Failed to get Zalo user info');
      }

      return response.data;
    } catch (error: unknown) {
      throw new HttpException(
        'Không thể lấy thông tin từ Zalo',
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  // ============================================
  // PHONE OTP LOGIN
  // ============================================

  /**
   * Gửi OTP qua SMS
   */
  async sendOtp(
    phone: string,
    channel: 'sms' | 'voice' | 'viber' | 'zalo' = 'sms',
  ): Promise<{
    success: boolean;
    sessionId: string;
    message: string;
    cooldownRemaining?: number;
  }> {
    const formattedPhone = this.formatPhone(phone);
    const sessionKey = `otp_${formattedPhone}`;

    // Check existing session for cooldown
    const existingSession = this.otpSessions.get(sessionKey);
    if (existingSession) {
      const cooldown = 60 * 1000; // 60 seconds
      const timeSinceLast = Date.now() - existingSession.lastSent;

      if (timeSinceLast < cooldown) {
        return {
          success: false,
          sessionId: existingSession.sessionId,
          message: 'Vui lòng chờ trước khi gửi lại OTP',
          cooldownRemaining: Math.ceil((cooldown - timeSinceLast) / 1000),
        };
      }
    }

    let result: { success: boolean; sessionId: string; message: string };

    if (channel === 'zalo') {
      result = await this.sendOtpViaZalo(formattedPhone);
    } else {
      result = await this.sendOtpViaGetOtp(formattedPhone, channel);
    }

    if (result.success) {
      // Store session
      this.otpSessions.set(sessionKey, {
        phone: formattedPhone,
        sessionId: result.sessionId,
        provider: channel === 'zalo' ? 'zalo' : 'getotp',
        expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
        attempts: 0,
        lastSent: Date.now(),
        verified: false,
      });
    }

    return result;
  }

  /**
   * Gửi OTP qua GetOTP (otp.dev)
   * API: POST https://api.otp.dev/v1/verifications
   * Docs: https://otp.dev/en/docs/sms-otp/
   */
  private async sendOtpViaGetOtp(
    phone: string,
    channel: 'sms' | 'voice' | 'viber',
  ): Promise<{ success: boolean; sessionId: string; message: string }> {
    try {
      // GetOTP default template ID (created via dashboard.otp.dev)
      const templateId =
        this.configService.get('GETOTP_TEMPLATE_ID') ||
        'ea458d21-7337-452e-a0fa-7cc2554114f9';
      // GetOTP sender name (registered on dashboard.otp.dev)
      const senderName = this.configService.get('GETOTP_SENDER') || 'OTP Dev';

      const response = await firstValueFrom(
        this.httpService.post(
          OTP_PROVIDERS.GETOTP,
          {
            data: {
              phone,
              channel,
              sender: senderName,
              template: templateId,
              code_length: 6,
            },
          },
          {
            headers: {
              'X-OTP-Key': this.getOtpApiKey,
              'Content-Type': 'application/json',
              Accept: 'application/json',
            },
          },
        ),
      );

      // GetOTP response: { data: { account_id, message_id, phone, create_date, expire_date } }
      const responseData = response.data?.data || response.data;
      if (responseData?.message_id) {
        return {
          success: true,
          sessionId: responseData.message_id,
          message: 'OTP đã được gửi',
        };
      } else {
        throw new Error(
          response.data.errors?.[0]?.message || 'Không thể gửi OTP',
        );
      }
    } catch (error: unknown) {
      this.logger.error(
        'GetOTP send failed',
        getAxiosErrorData(error) || error,
      );
      throw new HttpException(
        'Không thể gửi OTP. Vui lòng thử lại.',
        HttpStatus.SERVICE_UNAVAILABLE,
      );
    }
  }

  /**
   * Gửi OTP qua Zalo ZNS
   */
  private async sendOtpViaZalo(
    phone: string,
  ): Promise<{ success: boolean; sessionId: string; message: string }> {
    try {
      // Generate OTP
      const otp = this.generateOtp();
      const sessionId = `zalo_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;

      // Send via ZNS
      const result = await this.znsService.sendOtpZns({
        phone,
        otp,
        expiresInMinutes: 5,
      });

      if (result.error !== 0) {
        throw new Error(result.message);
      }

      // Store OTP for verification
      const sessionKey = `otp_${phone}`;
      this.otpSessions.set(sessionKey, {
        phone,
        otp,
        sessionId,
        provider: 'zalo',
        expiresAt: Date.now() + 5 * 60 * 1000,
        attempts: 0,
        lastSent: Date.now(),
        verified: false,
      });

      return {
        success: true,
        sessionId,
        message: 'OTP đã được gửi qua Zalo',
      };
    } catch (error: unknown) {
      this.logger.error('Zalo OTP send failed', error);

      // Fallback to GetOTP
      this.logger.warn('Falling back to GetOTP');
      return this.sendOtpViaGetOtp(phone, 'sms');
    }
  }

  /**
   * Xác thực OTP
   */
  async verifyOtp(
    phone: string,
    otp: string,
    sessionId?: string,
  ): Promise<{
    success: boolean;
    isNewUser: boolean;
    message: string;
    accessToken?: string;
    refreshToken?: string;
    user?: any;
  }> {
    const formattedPhone = this.formatPhone(phone);
    const sessionKey = `otp_${formattedPhone}`;
    const session = this.otpSessions.get(sessionKey);

    if (!session) {
      throw new HttpException(
        'Phiên OTP không tồn tại hoặc đã hết hạn',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Check expiry
    if (Date.now() > session.expiresAt) {
      this.otpSessions.delete(sessionKey);
      throw new HttpException('OTP đã hết hạn', HttpStatus.BAD_REQUEST);
    }

    // Check attempts
    if (session.attempts >= 5) {
      this.otpSessions.delete(sessionKey);
      throw new HttpException(
        'Quá nhiều lần thử. Vui lòng gửi lại OTP.',
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    session.attempts++;

    // Verify OTP
    let verified = false;

    if (session.provider === 'zalo' && session.otp) {
      // Local verification for Zalo
      verified = session.otp === otp;
    } else {
      // Verify via GetOTP
      verified = await this.verifyOtpViaGetOtp(
        formattedPhone,
        otp,
        session.sessionId,
      );
    }

    if (!verified) {
      throw new HttpException(
        `OTP không chính xác. Còn ${5 - session.attempts} lần thử.`,
        HttpStatus.BAD_REQUEST,
      );
    }

    // OTP verified - mark session
    session.verified = true;

    // Check if user exists
    let user = await this.prisma.user.findFirst({
      where: { phone: formattedPhone },
    });

    const isNewUser = !user;

    if (user) {
      // Generate tokens for existing user
      const tokens = await this.generateTokens(user.id, user.email, user.role);
      await this.updateRefreshToken(user.id, tokens.refreshToken);

      // Clean up session
      this.otpSessions.delete(sessionKey);

      return {
        success: true,
        isNewUser: false,
        message: 'Đăng nhập thành công',
        ...tokens,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          phone: user.phone,
          avatar: user.avatar,
        },
      };
    }

    // New user - return success without tokens
    // Client will need to complete registration
    return {
      success: true,
      isNewUser: true,
      message: 'OTP xác thực thành công. Vui lòng hoàn tất đăng ký.',
    };
  }

  /**
   * Verify OTP via GetOTP API
   * API: GET https://api.otp.dev/v1/verifications?code=xxx&phone=xxx
   * Docs: https://otp.dev/en/docs/verifying-otp/
   */
  private async verifyOtpViaGetOtp(
    phone: string,
    otp: string,
    sessionId: string,
  ): Promise<boolean> {
    try {
      const response = await firstValueFrom(
        this.httpService.get(OTP_PROVIDERS.GETOTP_VERIFY, {
          params: {
            code: otp,
            phone,
          },
          headers: {
            'X-OTP-Key': this.getOtpApiKey,
            Accept: 'application/json',
          },
        }),
      );

      // If data array is not empty, code is valid
      return response.data.data && response.data.data.length > 0;
    } catch (error: unknown) {
      this.logger.error(
        'GetOTP verify failed',
        getAxiosErrorData(error) || error,
      );
      return false;
    }
  }

  /**
   * Đăng ký user mới bằng phone
   */
  async registerWithPhone(
    phone: string,
    name: string,
    email?: string,
    password?: string,
    zaloId?: string,
  ): Promise<{ accessToken: string; refreshToken: string; user: any }> {
    const formattedPhone = this.formatPhone(phone);
    const sessionKey = `otp_${formattedPhone}`;
    const session = this.otpSessions.get(sessionKey);

    // Verify OTP was completed
    if (!session || !session.verified) {
      throw new HttpException(
        'Vui lòng xác thực OTP trước khi đăng ký',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Check if phone already registered
    const existingUser = await this.prisma.user.findFirst({
      where: { phone: formattedPhone },
    });

    if (existingUser) {
      throw new HttpException(
        'Số điện thoại đã được đăng ký',
        HttpStatus.CONFLICT,
      );
    }

    // Generate email if not provided
    const userEmail = email || `phone_${formattedPhone}@baotienweb.cloud`;

    // Generate password if not provided
    const hashedPassword = await this.hashPassword(
      password ||
        `phone_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`,
    );

    // Create user
    const user = await this.prisma.user.create({
      data: {
        name,
        email: userEmail,
        password: hashedPassword,
        phone: formattedPhone,
        role: Role.CLIENT,
        zaloId,
      },
    });

    // Generate tokens
    const tokens = await this.generateTokens(user.id, user.email, user.role);
    await this.updateRefreshToken(user.id, tokens.refreshToken);

    // Clean up OTP session
    this.otpSessions.delete(sessionKey);

    return {
      ...tokens,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        phone: user.phone,
      },
    };
  }

  /**
   * Liên kết số điện thoại với tài khoản hiện tại
   */
  async linkPhone(userId: number, phone: string): Promise<any> {
    const formattedPhone = this.formatPhone(phone);
    const sessionKey = `otp_${formattedPhone}`;
    const session = this.otpSessions.get(sessionKey);

    if (!session || !session.verified) {
      throw new HttpException(
        'Vui lòng xác thực OTP trước',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Check if phone used by another user
    const existingUser = await this.prisma.user.findFirst({
      where: {
        phone: formattedPhone,
        id: { not: userId },
      },
    });

    if (existingUser) {
      throw new HttpException(
        'Số điện thoại đã được sử dụng bởi tài khoản khác',
        HttpStatus.CONFLICT,
      );
    }

    // Update user
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: { phone: formattedPhone },
    });

    // Clean up session
    this.otpSessions.delete(sessionKey);

    return {
      success: true,
      message: 'Liên kết số điện thoại thành công',
      phone: formattedPhone,
    };
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  private formatPhone(phone: string): string {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.startsWith('84')) {
      return cleaned;
    }
    if (cleaned.startsWith('0')) {
      return '84' + cleaned.substring(1);
    }
    return '84' + cleaned;
  }

  private generateOtp(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  private async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 10);
  }

  private async generateTokens(
    userId: number,
    email: string,
    role: Role,
  ): Promise<{ accessToken: string; refreshToken: string }> {
    const payload = { sub: userId, email, role: role.toString() };

    const accessToken = await this.jwtService.signAsync(payload, {
      secret: this.configService.get('JWT_SECRET'),
      expiresIn: this.configService.get('JWT_EXPIRES_IN') || '7d',
    });

    const refreshToken = await this.jwtService.signAsync(payload, {
      secret:
        this.configService.get('JWT_REFRESH_SECRET') ||
        this.configService.get('JWT_SECRET'),
      expiresIn: this.configService.get('JWT_REFRESH_EXPIRES_IN') || '30d',
    });

    return { accessToken, refreshToken };
  }

  private async updateRefreshToken(
    userId: number,
    refreshToken: string,
  ): Promise<void> {
    const hashedRT = await bcrypt.hash(refreshToken, 10);
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: hashedRT },
    });
  }
}
