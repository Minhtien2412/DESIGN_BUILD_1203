/**
 * Zalo Controller
 * API endpoints cho Zalo integration
 */

import {
    Body,
    Controller,
    Get,
    Headers,
    HttpCode,
    HttpStatus,
    Logger,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators';
import { getErrorMessage, getAxiosErrorData, getErrorStatus, isAxiosError, logError } from '../utils/error-helpers';

import { JwtAuthGuard } from '../auth/guards';
import {
    OaMessageDto,
    PhoneRegisterDto,
    SendOtpDto,
    SendZnsDto,
    SendZnsOtpDto,
    VerifyOtpDto,
    ZaloLoginDto
} from './dto/zalo.dto';
import { ZaloAuthService } from './zalo-auth.service';
import { ZaloService } from './zalo.service';
import { ZnsService } from './zns.service';

@ApiTags('Zalo')
@Controller({ path: 'zalo', version: '1' })
export class ZaloController {
  private readonly logger = new Logger(ZaloController.name);

  constructor(
    private readonly zaloService: ZaloService,
    private readonly znsService: ZnsService,
    private readonly zaloAuthService: ZaloAuthService,
  ) {}

  // ============================================
  // AUTHENTICATION
  // ============================================

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Đăng nhập bằng Zalo',
    description: 'Exchange Zalo OAuth code lấy JWT tokens',
  })
  @ApiBody({ type: ZaloLoginDto })
  @ApiResponse({ status: 200, description: 'Đăng nhập thành công' })
  @ApiResponse({ status: 401, description: 'Mã xác thực không hợp lệ' })
  async zaloLogin(@Body() dto: ZaloLoginDto) {
    return this.zaloAuthService.zaloLogin(
      dto.code,
      dto.codeVerifier,
      dto.redirectUri,
    );
  }

  @Post('send-otp')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Gửi OTP đến số điện thoại',
    description: 'Hỗ trợ SMS, Voice, Viber, Zalo',
  })
  @ApiBody({ type: SendOtpDto })
  @ApiResponse({ status: 200, description: 'OTP đã được gửi' })
  @ApiResponse({ status: 400, description: 'Số điện thoại không hợp lệ' })
  @ApiResponse({ status: 429, description: 'Gửi quá nhiều, vui lòng chờ' })
  async sendOtp(@Body() dto: SendOtpDto) {
    return this.zaloAuthService.sendOtp(dto.phone, dto.channel);
  }

  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Xác thực OTP',
    description: 'Trả về tokens nếu user đã tồn tại, hoặc isNewUser=true nếu cần đăng ký',
  })
  @ApiBody({ type: VerifyOtpDto })
  @ApiResponse({ status: 200, description: 'OTP xác thực thành công' })
  @ApiResponse({ status: 400, description: 'OTP không đúng hoặc hết hạn' })
  async verifyOtp(@Body() dto: VerifyOtpDto) {
    return this.zaloAuthService.verifyOtp(dto.phone, dto.otp, dto.sessionId);
  }

  @Post('register-phone')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ 
    summary: 'Đăng ký tài khoản bằng số điện thoại',
    description: 'Yêu cầu: đã verify OTP trước đó',
  })
  @ApiBody({ type: PhoneRegisterDto })
  @ApiResponse({ status: 201, description: 'Đăng ký thành công' })
  @ApiResponse({ status: 400, description: 'Chưa xác thực OTP' })
  @ApiResponse({ status: 409, description: 'Số điện thoại đã được đăng ký' })
  async registerWithPhone(@Body() dto: PhoneRegisterDto) {
    return this.zaloAuthService.registerWithPhone(
      dto.phone,
      dto.name,
      dto.email,
      dto.password,
      dto.zaloId,
    );
  }

  @Post('link-phone')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ 
    summary: 'Liên kết số điện thoại với tài khoản',
    description: 'Yêu cầu: đăng nhập + đã verify OTP',
  })
  @ApiResponse({ status: 200, description: 'Liên kết thành công' })
  async linkPhone(
    @CurrentUser() user: any,
    @Body() body: { phone: string },
  ) {
    return this.zaloAuthService.linkPhone(user.id, body.phone);
  }

  // ============================================
  // ZNS (NOTIFICATION SERVICE)
  // ============================================

  @Post('send-zns')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ 
    summary: 'Gửi ZNS notification',
    description: 'Gửi thông báo qua Zalo Notification Service',
  })
  @ApiBody({ type: SendZnsDto })
  @ApiResponse({ status: 200, description: 'ZNS đã được gửi' })
  @ApiResponse({ status: 400, description: 'Template hoặc dữ liệu không hợp lệ' })
  async sendZns(@Body() dto: SendZnsDto) {
    return this.znsService.sendZns(dto);
  }

  @Post('send-zns-otp')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Gửi OTP qua ZNS',
    description: 'Gửi mã OTP qua Zalo (yêu cầu template OTP đã duyệt)',
  })
  @ApiBody({ type: SendZnsOtpDto })
  @ApiResponse({ status: 200, description: 'OTP đã được gửi qua Zalo' })
  async sendZnsOtp(@Body() dto: SendZnsOtpDto) {
    return this.znsService.sendOtpZns(dto);
  }

  @Post('send-zns-dev')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth()
  @ApiOperation({ 
    summary: 'Gửi ZNS (Development Mode)',
    description: 'Chỉ gửi tới số điện thoại test đã đăng ký',
  })
  @ApiBody({ type: SendZnsDto })
  async sendZnsDev(@Body() dto: SendZnsDto) {
    return this.znsService.sendZnsDevelopment(dto);
  }

  // ============================================
  // TEMPLATE MANAGEMENT
  // ============================================

  @Get('templates')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ 
    summary: 'Lấy danh sách ZNS templates',
    description: 'filterPreset=0: tất cả, filterPreset=1: chỉ app tạo',
  })
  @ApiQuery({ name: 'offset', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'filterPreset', required: false, enum: [0, 1] })
  @ApiResponse({ status: 200, description: 'Danh sách templates' })
  async getTemplates(
    @Query('offset') offset?: number,
    @Query('limit') limit?: number,
    @Query('filterPreset') filterPreset?: 0 | 1,
  ) {
    return this.znsService.getTemplateList(
      offset || 0,
      limit || 100,
      filterPreset,
    );
  }

  @Get('templates/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy chi tiết template' })
  @ApiResponse({ status: 200, description: 'Chi tiết template' })
  async getTemplateDetail(@Query('id') templateId: string) {
    return this.znsService.getTemplateDetail(templateId);
  }

  @Get('templates/:id/sample')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy dữ liệu mẫu của template' })
  async getTemplateSample(@Query('id') templateId: string) {
    return this.znsService.getTemplateSampleData(templateId);
  }

  // ============================================
  // OA (OFFICIAL ACCOUNT)
  // ============================================

  @Get('oa-info')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy thông tin Official Account' })
  async getOaInfo() {
    return this.znsService.getOaInfo();
  }

  @Post('oa-message')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Gửi tin nhắn từ OA' })
  @ApiBody({ type: OaMessageDto })
  async sendOaMessage(@Body() dto: OaMessageDto) {
    return this.znsService.sendOaMessage(
      dto.userId,
      dto.message,
      dto.type as 'text' | 'image' | undefined,
      dto.attachmentUrl,
    );
  }

  // ============================================
  // OAUTH CALLBACK (Lấy Access Token cho OA)
  // ============================================

  @Get('oauth/callback')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Zalo OAuth Callback',
    description: 'Nhận authorization code và đổi lấy access token',
  })
  @ApiQuery({ name: 'code', required: false, description: 'Authorization code từ Zalo' })
  @ApiQuery({ name: 'oa_id', required: false, description: 'OA ID' })
  async oauthCallback(
    @Query('code') code?: string,
    @Query('oa_id') oaId?: string,
  ) {
    this.logger.log(`OAuth callback received - code: ${code?.substring(0, 20)}..., oa_id: ${oaId}`);
    
    if (!code) {
      return {
        success: false,
        message: 'Missing authorization code',
        instruction: 'Please authorize the app at Zalo Developer Console',
      };
    }

    // Exchange code for access token
    try {
      const tokens = await this.zaloAuthService.exchangeOaCode(code);
      return {
        success: true,
        message: 'Lấy Access Token thành công! Hãy lưu các giá trị này vào .env trên VPS',
        data: {
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          expires_in: tokens.expires_in,
          oa_id: oaId,
        },
        instruction: `
          Thêm vào .env trên VPS:
          ZALO_OA_ACCESS_TOKEN=${tokens.access_token}
          ZALO_OA_REFRESH_TOKEN=${tokens.refresh_token}
        `,
      };
    } catch (error: unknown) {
      this.logger.error('OAuth callback failed', error);
      return {
        success: false,
        message: getErrorMessage(error) || 'Không thể lấy access token',
        code,
        oa_id: oaId,
      };
    }
  }

  // ============================================
  // WEBHOOK
  // ============================================

  @Get('webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Zalo Webhook verification (GET)',
    description: 'Zalo sử dụng GET để verify webhook URL',
  })
  verifyWebhook() {
    this.logger.log('Zalo webhook verification (GET)');
    return { success: true, message: 'Webhook is active' };
  }

  @Post('webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ 
    summary: 'Zalo Webhook receiver',
    description: 'Nhận events từ Zalo (ZNS status, OA events)',
  })
  async handleWebhook(
    @Headers('x-zalo-signature') signature: string,
    @Body() payload: any,
    @Req() req: Request,
  ) {
    // Zalo verification request (empty or test payload)
    if (!payload || Object.keys(payload).length === 0) {
      this.logger.log('Zalo webhook verification (POST empty)');
      return { success: true, message: 'Webhook verified' };
    }

    this.logger.log(`Zalo webhook event: ${payload.event_name || 'unknown'}`);

    // TODO: Verify signature
    // TODO: Process events (ZNS delivery, OA follow/unfollow, etc.)

    // Log event for debugging
    this.logger.debug('Webhook payload:', JSON.stringify(payload));

    return { success: true };
  }

  // ============================================
  // STATUS & INFO
  // ============================================

  @Get('status')
  @ApiOperation({ summary: 'Kiểm tra trạng thái cấu hình Zalo' })
  @ApiResponse({ status: 200, description: 'Trạng thái cấu hình' })
  async getStatus() {
    return this.zaloService.getConfigStatus();
  }

  @Get('info')
  @ApiOperation({ summary: 'Thông tin integration Zalo' })
  @ApiResponse({ status: 200, description: 'Thông tin endpoints và features' })
  getInfo() {
    return this.zaloService.getIntegrationInfo();
  }
}
