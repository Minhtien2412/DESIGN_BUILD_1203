import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CallService } from './call.service';
import {
    CallResponseDto,
    EndCallDto,
    StartCallDto
} from './dto';

@ApiTags('Call')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'call', version: '1' })
export class CallController {
  constructor(private readonly callService: CallService) {}

  @Post('start')
  @ApiOperation({ summary: 'Bắt đầu cuộc gọi 1-1' })
  @ApiResponse({
    status: 201,
    description: 'Cuộc gọi đã được tạo',
    type: CallResponseDto,
  })
  async startCall(
    @Body() startCallDto: StartCallDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.callService.startCall(
      userId,
      startCallDto.calleeId,
      startCallDto.type,
    );
  }

  @Post('accept/:callId')
  @ApiOperation({ summary: 'Chấp nhận cuộc gọi đến' })
  @ApiResponse({
    status: 200,
    description: 'Cuộc gọi đã được chấp nhận',
    type: CallResponseDto,
  })
  async acceptCall(
    @Param('callId', ParseIntPipe) callId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.callService.acceptCall(callId, userId);
  }

  @Post('reject/:callId')
  @ApiOperation({ summary: 'Từ chối cuộc gọi đến' })
  @ApiResponse({
    status: 200,
    description: 'Cuộc gọi đã bị từ chối',
    type: CallResponseDto,
  })
  async rejectCall(
    @Param('callId', ParseIntPipe) callId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.callService.rejectCall(callId, userId);
  }

  @Post('end')
  @ApiOperation({ summary: 'Kết thúc cuộc gọi' })
  @ApiResponse({
    status: 200,
    description: 'Cuộc gọi đã kết thúc',
    type: CallResponseDto,
  })
  async endCall(
    @Body() endCallDto: EndCallDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.callService.endCall(endCallDto.roomId, userId);
  }

  @Get('history')
  @ApiOperation({ summary: 'Lấy lịch sử cuộc gọi' })
  @ApiResponse({
    status: 200,
    description: 'Danh sách cuộc gọi',
    type: [CallResponseDto],
  })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getCallHistory(
    @CurrentUser('id') userId: number,
    @Query('limit') limit?: number,
  ) {
    return this.callService.getCallHistory(userId, limit || 50);
  }

  @Get('active')
  @ApiOperation({ summary: 'Lấy cuộc gọi đang active' })
  @ApiResponse({
    status: 200,
    description: 'Cuộc gọi đang active (nếu có)',
    type: CallResponseDto,
  })
  async getActiveCall(@CurrentUser('id') userId: number) {
    return this.callService.getActiveCall(userId);
  }

  @Get(':callId')
  @ApiOperation({ summary: 'Lấy thông tin chi tiết cuộc gọi' })
  @ApiResponse({
    status: 200,
    description: 'Thông tin cuộc gọi',
    type: CallResponseDto,
  })
  async getCallById(@Param('callId', ParseIntPipe) callId: number) {
    return this.callService.getCallById(callId);
  }

  @Post('missed/:callId/read')
  @ApiOperation({ summary: 'Đánh dấu cuộc gọi nhỡ đã đọc' })
  @ApiResponse({
    status: 200,
    description: 'Đã đánh dấu',
  })
  async markMissedCallAsRead(
    @Param('callId', ParseIntPipe) callId: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.callService.markMissedCallAsRead(callId, userId);
  }
}
