import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CallService {
  constructor(private prisma: PrismaService) {}

  // Start a new call
  async startCall(callerId: number, calleeId: number, type: string = 'video') {
    // Validate callee exists
    const callee = await this.prisma.user.findUnique({
      where: { id: calleeId },
      select: { id: true, name: true, email: true },
    });

    if (!callee) {
      throw new NotFoundException(`User với ID ${calleeId} không tồn tại`);
    }

    // Cannot call yourself
    if (callerId === calleeId) {
      throw new BadRequestException('Không thể gọi cho chính mình');
    }

    // Check if there's already an active call between these users
    const existingCall = await this.prisma.call.findFirst({
      where: {
        OR: [
          { callerId, calleeId, status: { in: ['pending', 'active'] } },
          { callerId: calleeId, calleeId: callerId, status: { in: ['pending', 'active'] } },
        ],
      },
    });

    if (existingCall) {
      throw new BadRequestException('Đã có cuộc gọi đang diễn ra với người dùng này');
    }

    // Create unique room ID
    const roomId = `call_${callerId}_${calleeId}_${Date.now()}`;

    // Create call record
    const call = await this.prisma.call.create({
      data: {
        callerId,
        calleeId,
        roomId,
        type,
        status: 'pending',
      },
      include: {
        caller: {
          select: { id: true, name: true, email: true },
        },
        callee: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    return call;
  }

  // Accept a call
  async acceptCall(callId: number, userId: number) {
    const call = await this.prisma.call.findUnique({
      where: { id: callId },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi ID ${callId} không tồn tại`);
    }

    // Only callee can accept
    if (call.calleeId !== userId) {
      throw new ForbiddenException('Bạn không thể accept cuộc gọi này');
    }

    if (call.status !== 'pending') {
      throw new BadRequestException('Cuộc gọi không ở trạng thái chờ');
    }

    // Update call status
    const updatedCall = await this.prisma.call.update({
      where: { id: callId },
      data: {
        status: 'active',
        startedAt: new Date(),
      },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    return updatedCall;
  }

  // Reject a call
  async rejectCall(callId: number, userId: number) {
    const call = await this.prisma.call.findUnique({
      where: { id: callId },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi ID ${callId} không tồn tại`);
    }

    // Only callee can reject
    if (call.calleeId !== userId) {
      throw new ForbiddenException('Bạn không thể từ chối cuộc gọi này');
    }

    if (call.status !== 'pending') {
      throw new BadRequestException('Cuộc gọi không ở trạng thái chờ');
    }

    // Update call status
    const updatedCall = await this.prisma.call.update({
      where: { id: callId },
      data: {
        status: 'missed',
        endedAt: new Date(),
      },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    return updatedCall;
  }

  // End a call
  async endCall(roomId: string, userId: number) {
    const call = await this.prisma.call.findUnique({
      where: { roomId },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi với roomId ${roomId} không tồn tại`);
    }

    // Only caller or callee can end
    if (call.callerId !== userId && call.calleeId !== userId) {
      throw new ForbiddenException('Bạn không thể kết thúc cuộc gọi này');
    }

    // Calculate duration
    let duration: number | null = null;
    if (call.startedAt) {
      duration = Math.round((Date.now() - call.startedAt.getTime()) / 1000);
    }

    // Update call
    const updatedCall = await this.prisma.call.update({
      where: { roomId },
      data: {
        status: 'ended',
        endedAt: new Date(),
        duration,
      },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    return updatedCall;
  }

  // Get call history for a user
  async getCallHistory(userId: number, limit: number = 50) {
    const calls = await this.prisma.call.findMany({
      where: {
        OR: [{ callerId: userId }, { calleeId: userId }],
      },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return calls;
  }

  // Get active call for a user
  async getActiveCall(userId: number) {
    const call = await this.prisma.call.findFirst({
      where: {
        OR: [{ callerId: userId }, { calleeId: userId }],
        status: { in: ['pending', 'active'] },
      },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    return call;
  }

  // Get call by ID
  async getCallById(callId: number) {
    const call = await this.prisma.call.findUnique({
      where: { id: callId },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi ID ${callId} không tồn tại`);
    }

    return call;
  }

  // Get call by room ID
  async getCallByRoomId(roomId: string) {
    const call = await this.prisma.call.findUnique({
      where: { roomId },
      include: {
        caller: { select: { id: true, name: true, email: true } },
        callee: { select: { id: true, name: true, email: true } },
      },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi với roomId ${roomId} không tồn tại`);
    }

    return call;
  }

  // Mark missed call as read
  async markMissedCallAsRead(callId: number, userId: number) {
    const call = await this.prisma.call.findUnique({
      where: { id: callId },
    });

    if (!call) {
      throw new NotFoundException(`Cuộc gọi ID ${callId} không tồn tại`);
    }

    // Only callee can mark as read
    if (call.calleeId !== userId) {
      throw new ForbiddenException('Bạn không thể đánh dấu cuộc gọi này');
    }

    // For now just return success - can add 'readAt' field later if needed
    return { success: true, callId };
  }
}
