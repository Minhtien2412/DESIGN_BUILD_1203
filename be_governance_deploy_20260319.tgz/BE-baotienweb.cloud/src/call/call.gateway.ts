import { Injectable, Logger, UsePipes } from '@nestjs/common';
import { getErrorMessage } from '../utils/error-helpers';

import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
    WsException,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { MetricsService } from '../metrics/metrics.service';
import {
    AcceptCallDto,
    CallSignalDto,
    JoinCallDto,
    LeaveCallDto,
    RegisterUserDto,
    RejectCallDto,
} from '../shared/dto/ws.dto';
import { WsValidationPipe } from '../shared/pipes/ws-validation.pipe';
import { CallService } from './call.service';

interface ConnectedUser {
  socketId: string;
  userId: number;
}

@Injectable()
@WebSocketGateway({
  namespace: '/call',
  cors: {
    origin: '*',
    credentials: true,
  },
})
export class CallGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private logger = new Logger('CallGateway');
  private connectedUsers: Map<number, string> = new Map(); // userId -> socketId
  private socketToUser: Map<string, number> = new Map(); // socketId -> userId

  constructor(
    private callService: CallService,
    private jwtService: JwtService,
    private configService: ConfigService,
    private metricsService: MetricsService,
  ) {}

  async handleConnection(client: Socket) {
    this.metricsService.recordWsConnect('call');
    try {
      // Extract token from auth or query
      const token =
        client.handshake.auth?.token ||
        client.handshake.query?.token ||
        client.handshake.headers?.authorization?.replace('Bearer ', '');

      if (!token) {
        this.logger.warn(`Client ${client.id} connected without token`);
        client.emit('error', { message: 'Authentication required' });
        client.disconnect();
        return;
      }

      // Verify token
      const secret = this.configService.get<string>(
        'JWT_SECRET',
        'supersecret',
      );
      const payload = this.jwtService.verify(token, { secret });
      const userId = payload.sub;

      // Store connection
      this.connectedUsers.set(userId, client.id);
      this.socketToUser.set(client.id, userId);

      this.logger.log(`User ${userId} connected via socket ${client.id}`);
      client.emit('connected', { userId, socketId: client.id });
    } catch (error: unknown) {
      this.logger.error(`Connection error: ${getErrorMessage(error)}`);
      client.emit('error', { message: 'Invalid token' });
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    this.metricsService.recordWsDisconnect('call');
    const userId = this.socketToUser.get(client.id);
    if (userId) {
      this.connectedUsers.delete(userId);
      this.socketToUser.delete(client.id);
      this.logger.log(`User ${userId} disconnected`);
    }
  }

  // Client registers with userId (fallback if token auth fails)
  @SubscribeMessage('register')
  @UsePipes(new WsValidationPipe())
  handleRegister(
    @MessageBody() data: RegisterUserDto,
    @ConnectedSocket() client: Socket,
  ) {
    const { userId } = data;
    this.connectedUsers.set(userId, client.id);
    this.socketToUser.set(client.id, userId);
    this.logger.log(`User ${userId} registered via socket ${client.id}`);
    return { success: true, userId };
  }

  // Join a call room
  @SubscribeMessage('join_call')
  @UsePipes(new WsValidationPipe())
  handleJoinCall(
    @MessageBody() data: JoinCallDto,
    @ConnectedSocket() client: Socket,
  ) {
    const { roomId } = data;
    client.join(roomId);
    this.logger.log(`Socket ${client.id} joined room ${roomId}`);

    // Notify others in room
    client.to(roomId).emit('user_joined', {
      socketId: client.id,
      userId: this.socketToUser.get(client.id),
    });

    return { success: true, roomId };
  }

  // Leave a call room
  @SubscribeMessage('leave_call')
  @UsePipes(new WsValidationPipe())
  handleLeaveCall(
    @MessageBody() data: LeaveCallDto,
    @ConnectedSocket() client: Socket,
  ) {
    const { roomId } = data;
    client.leave(roomId);
    this.logger.log(`Socket ${client.id} left room ${roomId}`);

    // Notify others in room
    client.to(roomId).emit('user_left', {
      socketId: client.id,
      userId: this.socketToUser.get(client.id),
    });

    return { success: true };
  }

  // WebRTC signaling - relay signals between peers
  @SubscribeMessage('call_signal')
  @UsePipes(new WsValidationPipe())
  handleSignal(
    @MessageBody() data: CallSignalDto,
    @ConnectedSocket() client: Socket,
  ) {
    const { to, signal } = data;
    const toSocketId = this.connectedUsers.get(to);
    const fromUserId = this.socketToUser.get(client.id);

    if (toSocketId) {
      this.server.to(toSocketId).emit('call_signal', {
        from: fromUserId,
        signal,
      });
      this.logger.log(`Signal relayed from ${fromUserId} to ${to}`);
      return { success: true };
    } else {
      this.logger.warn(`User ${to} not connected for signaling`);
      return { success: false, error: 'User not connected' };
    }
  }

  // Accept call via WebSocket
  @SubscribeMessage('accept_call')
  @UsePipes(new WsValidationPipe())
  async handleAcceptCall(
    @MessageBody() data: AcceptCallDto,
    @ConnectedSocket() client: Socket,
  ) {
    const userId = this.socketToUser.get(client.id);
    if (!userId) {
      throw new WsException('User not authenticated');
    }

    try {
      const call = await this.callService.acceptCall(data.callId, userId);

      // Notify caller (emit both notations for FE compatibility)
      const callerSocketId = this.connectedUsers.get(call.caller.id);
      if (callerSocketId) {
        const payload = {
          callId: call.id,
          roomId: call.roomId,
          callee: call.callee,
        };
        this.server.to(callerSocketId).emit('call_accepted', payload);
        this.server.to(callerSocketId).emit('call:accepted', payload);
      }

      return { success: true, call };
    } catch (error: unknown) {
      this.logger.error(`Accept call error: ${getErrorMessage(error)}`);
      throw new WsException(getErrorMessage(error));
    }
  }

  // Reject call via WebSocket
  @SubscribeMessage('reject_call')
  @UsePipes(new WsValidationPipe())
  async handleRejectCall(
    @MessageBody() data: RejectCallDto,
    @ConnectedSocket() client: Socket,
  ) {
    const userId = this.socketToUser.get(client.id);
    if (!userId) {
      throw new WsException('User not authenticated');
    }

    try {
      const call = await this.callService.rejectCall(data.callId, userId);

      // Notify caller (emit both notations for FE compatibility)
      const callerSocketId = this.connectedUsers.get(call.caller.id);
      if (callerSocketId) {
        const payload = {
          callId: call.id,
          callee: call.callee,
        };
        this.server.to(callerSocketId).emit('call_rejected', payload);
        this.server.to(callerSocketId).emit('call:rejected', payload);
      }

      return { success: true };
    } catch (error: unknown) {
      this.logger.error(`Reject call error: ${getErrorMessage(error)}`);
      throw new WsException(getErrorMessage(error));
    }
  }

  // Helper method to notify user of incoming call (called from controller)
  notifyIncomingCall(calleeId: number, callData: any) {
    const socketId = this.connectedUsers.get(calleeId);
    if (socketId) {
      this.server.to(socketId).emit('incoming_call', callData);
      this.server.to(socketId).emit('call:incoming', callData);
      this.logger.log(`Notified user ${calleeId} of incoming call`);
      return true;
    }
    this.logger.warn(`User ${calleeId} not connected for incoming call`);
    return false;
  }

  // Helper to notify call ended
  notifyCallEnded(userIds: number[], callData: any) {
    userIds.forEach((userId) => {
      const socketId = this.connectedUsers.get(userId);
      if (socketId) {
        this.server.to(socketId).emit('call_ended', callData);
        this.server.to(socketId).emit('call:ended', callData);
      }
    });
  }

  // Check if user is online
  isUserOnline(userId: number): boolean {
    return this.connectedUsers.has(userId);
  }
}
