import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsInt, IsOptional, IsString } from 'class-validator';

// DTO for starting a call
export class StartCallDto {
  @ApiProperty({ description: 'ID of the user to call' })
  @IsInt()
  calleeId: number;

  @ApiPropertyOptional({ 
    description: 'Type of call', 
    enum: ['video', 'audio'],
    default: 'video'
  })
  @IsOptional()
  @IsString()
  @IsIn(['video', 'audio'])
  type?: string = 'video';
}

// DTO for ending a call
export class EndCallDto {
  @ApiProperty({ description: 'Room ID of the call to end' })
  @IsString()
  roomId: string;
}

// DTO for rejecting a call
export class RejectCallDto {
  @ApiPropertyOptional({ description: 'Reason for rejection' })
  @IsOptional()
  @IsString()
  reason?: string;
}

// DTO for accepting a call
export class AcceptCallDto {
  @ApiProperty({ description: 'Call ID to accept' })
  @IsInt()
  callId: number;
}

// Response DTOs
export class CallUserDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  name: string;

  @ApiProperty()
  email: string;
}

export class CallResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  roomId: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  type: string;

  @ApiPropertyOptional()
  startedAt?: Date;

  @ApiPropertyOptional()
  endedAt?: Date;

  @ApiPropertyOptional()
  duration?: number;

  @ApiProperty({ type: () => CallUserDto })
  caller: CallUserDto;

  @ApiProperty({ type: () => CallUserDto })
  callee: CallUserDto;

  @ApiProperty()
  createdAt: Date;
}

export class CallHistoryResponseDto {
  @ApiProperty({ type: [CallResponseDto] })
  calls: CallResponseDto[];

  @ApiProperty()
  total: number;
}
