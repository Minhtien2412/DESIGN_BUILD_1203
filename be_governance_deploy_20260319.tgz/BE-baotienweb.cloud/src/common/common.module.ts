import { Global, Module } from '@nestjs/common';
import { ApiKeyGuard } from './guards';

/**
 * Common Module - Global utilities, guards, interceptors
 * @Global decorator makes guards/services available everywhere
 */
@Global()
@Module({
  providers: [ApiKeyGuard],
  exports: [ApiKeyGuard],
})
export class CommonModule {}
