/**
 * Request ID Middleware (OBS-001)
 * ================================
 *
 * Adds unique request ID and correlation ID to each request
 * for distributed tracing and log aggregation.
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import { Injectable, NestMiddleware } from '@nestjs/common';
import * as crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';

// Extend Express Request to include our custom properties
declare global {
  namespace Express {
    interface Request {
      requestId: string;
      correlationId: string;
      requestStartTime: number;
    }
  }
}

@Injectable()
export class RequestIdMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    // Generate or use existing request ID
    const requestId =
      (req.headers['x-request-id'] as string) ||
      `req_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;

    // Correlation ID can be passed from upstream services or generated
    const correlationId =
      (req.headers['x-correlation-id'] as string) ||
      (req.headers['x-trace-id'] as string) ||
      requestId;

    // Attach to request object
    req.requestId = requestId;
    req.correlationId = correlationId;
    req.requestStartTime = Date.now();

    // Set response headers for tracing
    res.setHeader('X-Request-Id', requestId);
    res.setHeader('X-Correlation-Id', correlationId);

    next();
  }
}
