import { SetMetadata } from '@nestjs/common';

/**
 * Public route decorator
 * Use @Public() to skip authentication guards
 * Example:
 *   @Public()
 *   @Get('health')
 *   getHealth() { return 'OK'; }
 */
export const Public = () => SetMetadata('isPublic', true);
