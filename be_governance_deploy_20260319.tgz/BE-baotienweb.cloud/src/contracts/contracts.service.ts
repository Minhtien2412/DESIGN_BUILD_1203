import { Injectable, NotFoundException } from '@nestjs/common';
import { ContractStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateContractDto,
    CreateFromTemplateDto,
    CreateMilestoneDto,
    RejectSignatureDto,
    SignContractDto,
    UpdateContractDto,
    UpdateMilestoneDto,
    UploadDocumentDto,
} from './dto';

@Injectable()
export class ContractsService {
  constructor(private prisma: PrismaService) {}

  // ── Contracts CRUD ──
  async findAll(query: {
    projectId?: number;
    status?: string;
    page?: number;
    limit?: number;
  }) {
    const { projectId, status, page = 1, limit = 20 } = query;
    const where: any = {};
    if (projectId) where.projectId = projectId;
    if (status) where.status = status as ContractStatus;

    const [data, total] = await Promise.all([
      this.prisma.contract.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          milestones: true,
          documents: true,
          signatures: true,
          paymentSchedules: true,
        },
      }),
      this.prisma.contract.count({ where }),
    ]);
    return { data, total, page, limit };
  }

  async findOne(id: number) {
    const contract = await this.prisma.contract.findUnique({
      where: { id },
      include: {
        milestones: true,
        documents: true,
        signatures: true,
        paymentSchedules: true,
      },
    });
    if (!contract) throw new NotFoundException('Contract not found');
    return contract;
  }

  async create(dto: CreateContractDto) {
    const contractNo = dto.contractNo ?? `CTR-${Date.now()}`;
    return this.prisma.contract.create({
      data: {
        contractNo,
        title: dto.title,
        content: dto.content,
        contractValue: dto.contractValue,
        description: dto.description,
        type: dto.type,
        currency: dto.currency ?? 'VND',
        paymentTerms: dto.paymentTerms,
        startDate: dto.startDate ? new Date(dto.startDate) : new Date(),
        endDate: dto.endDate
          ? new Date(dto.endDate)
          : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
        projectId: dto.projectId,
        clientId: dto.clientId,
        terms: dto.terms,
        notes: dto.notes,
        quotationId: dto.quotationId,
      },
    });
  }

  async update(id: number, dto: UpdateContractDto) {
    await this.findOne(id);
    const data: any = { ...dto };
    if (dto.status) data.status = dto.status as ContractStatus;
    if (dto.startDate) data.startDate = new Date(dto.startDate);
    if (dto.endDate) data.endDate = new Date(dto.endDate);
    return this.prisma.contract.update({ where: { id }, data });
  }

  async remove(id: number) {
    await this.findOne(id);
    return this.prisma.contract.delete({ where: { id } });
  }

  async getStats(projectId?: number) {
    const where: any = {};
    if (projectId) where.projectId = projectId;

    const contracts = await this.prisma.contract.findMany({
      where,
      select: { status: true, contractValue: true },
    });
    const total = contracts.length;
    const totalValue = contracts.reduce(
      (s, c) => s + Number(c.contractValue ?? 0),
      0,
    );
    const byStatus: Record<string, number> = {};
    for (const c of contracts) {
      byStatus[c.status] = (byStatus[c.status] || 0) + 1;
    }
    return { total, totalValue, byStatus };
  }

  // ── Templates ──
  async getTemplates(query: { category?: string }) {
    const where: any = { isActive: true };
    if (query.category) where.category = query.category;
    return this.prisma.contractTemplate.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  async getTemplate(id: number) {
    const t = await this.prisma.contractTemplate.findUnique({ where: { id } });
    if (!t) throw new NotFoundException('Template not found');
    return t;
  }

  async createFromTemplate(
    templateId: number,
    userId: number,
    dto: CreateFromTemplateDto,
  ) {
    const template = await this.getTemplate(templateId);
    const contractNo = `CTR-${Date.now()}`;
    return this.prisma.contract.create({
      data: {
        contractNo,
        title: template.name,
        content: template.content,
        contractValue: dto.contractValue ?? 0,
        currency: 'VND',
        startDate: dto.startDate ? new Date(dto.startDate) : new Date(),
        endDate: dto.endDate ? new Date(dto.endDate) : new Date(),
        projectId: dto.projectId,
        clientId: dto.clientId,
        terms: template.description
          ? { templateDescription: template.description }
          : undefined,
      },
    });
  }

  // ── Signatures ──
  async getSignatures(contractId: number) {
    await this.findOne(contractId);
    return this.prisma.contractSignature.findMany({
      where: { contractId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async sign(contractId: number, userId: number, dto: SignContractDto) {
    await this.findOne(contractId);
    return this.prisma.contractSignature.create({
      data: {
        contractId,
        signedById: userId,
        partyName: dto.partyName,
        partyRole: dto.partyRole,
        signature: dto.signature,
        status: 'SIGNED',
        signedAt: new Date(),
      },
    });
  }

  async rejectSignature(
    contractId: number,
    signatureId: number,
    dto: RejectSignatureDto,
  ) {
    await this.findOne(contractId);
    return this.prisma.contractSignature.update({
      where: { id: signatureId },
      data: {
        status: 'REJECTED',
        rejectedAt: new Date(),
        rejectReason: dto.reason,
      },
    });
  }

  // ── Milestones ──
  async getMilestones(contractId: number) {
    await this.findOne(contractId);
    return this.prisma.contractMilestone.findMany({
      where: { contractId },
      orderBy: { dueDate: 'asc' },
    });
  }

  async createMilestone(contractId: number, dto: CreateMilestoneDto) {
    await this.findOne(contractId);
    return this.prisma.contractMilestone.create({
      data: {
        contractId,
        title: dto.title,
        description: dto.description,
        dueDate: new Date(dto.dueDate),
        amount: dto.amount,
        percentage: dto.percentage,
        requirements: dto.requirements,
        deliverables: dto.deliverables,
      },
    });
  }

  async getMilestone(contractId: number, milestoneId: number) {
    const m = await this.prisma.contractMilestone.findFirst({
      where: { id: milestoneId, contractId },
    });
    if (!m) throw new NotFoundException('Milestone not found');
    return m;
  }

  async updateMilestone(
    contractId: number,
    milestoneId: number,
    dto: UpdateMilestoneDto,
  ) {
    await this.getMilestone(contractId, milestoneId);
    const data: any = { ...dto };
    if (dto.dueDate) data.dueDate = new Date(dto.dueDate);
    return this.prisma.contractMilestone.update({
      where: { id: milestoneId },
      data,
    });
  }

  async deleteMilestone(contractId: number, milestoneId: number) {
    await this.getMilestone(contractId, milestoneId);
    return this.prisma.contractMilestone.delete({ where: { id: milestoneId } });
  }

  async completeMilestone(contractId: number, milestoneId: number) {
    await this.getMilestone(contractId, milestoneId);
    return this.prisma.contractMilestone.update({
      where: { id: milestoneId },
      data: { status: 'COMPLETED', completedAt: new Date() },
    });
  }

  async getMilestoneStats(contractId: number) {
    const milestones = await this.prisma.contractMilestone.findMany({
      where: { contractId },
    });
    const total = milestones.length;
    const completed = milestones.filter((m) => m.status === 'COMPLETED').length;
    const totalAmount = milestones.reduce(
      (s, m) => s + Number(m.amount ?? 0),
      0,
    );
    const paidAmount = milestones
      .filter((m) => m.status === 'COMPLETED')
      .reduce((s, m) => s + Number(m.amount ?? 0), 0);
    return {
      total,
      completed,
      pending: total - completed,
      totalAmount,
      paidAmount,
    };
  }

  // ── Documents ──
  async getDocuments(contractId: number) {
    await this.findOne(contractId);
    return this.prisma.contractDocument.findMany({
      where: { contractId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async uploadDocument(
    contractId: number,
    userId: number,
    dto: UploadDocumentDto,
  ) {
    await this.findOne(contractId);
    return this.prisma.contractDocument.create({
      data: {
        contractId,
        uploadedById: userId,
        url: dto.url,
        name: dto.name,
        type: dto.type,
        mimeType: dto.mimeType,
        size: dto.size,
        version: dto.version ?? 1,
      },
    });
  }

  async deleteDocument(contractId: number, documentId: number) {
    const d = await this.prisma.contractDocument.findFirst({
      where: { id: documentId, contractId },
    });
    if (!d) throw new NotFoundException('Document not found');
    return this.prisma.contractDocument.delete({ where: { id: documentId } });
  }

  // ── PDF ──
  async generatePdf(contractId: number) {
    const contract = await this.findOne(contractId);
    return {
      contractId,
      title: contract.title,
      generatedAt: new Date().toISOString(),
      pdfUrl: contract.pdfUrl,
      data: contract,
    };
  }
}
