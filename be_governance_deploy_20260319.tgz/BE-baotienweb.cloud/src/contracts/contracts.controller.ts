import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ContractsService } from './contracts.service';
import {
    CreateContractDto,
    CreateFromTemplateDto,
    CreateMilestoneDto,
    RejectSignatureDto,
    SignContractDto,
    UpdateContractDto,
    UpdateMilestoneDto,
    UploadDocumentDto,
} from './dto';

@ApiTags('Contracts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'contracts', version: '1' })
export class ContractsController {
  constructor(private readonly service: ContractsService) {}

  // ── CRUD ──
  @Get()
  @ApiOperation({ summary: 'List contracts' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  findAll(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.service.findAll({
      projectId: projectId ? +projectId : undefined,
      status,
      page: page ? +page : undefined,
      limit: limit ? +limit : undefined,
    });
  }

  @Get('stats')
  @ApiOperation({ summary: 'Contract statistics' })
  @ApiQuery({ name: 'projectId', required: false })
  getStats(@Query('projectId') projectId?: string) {
    return this.service.getStats(projectId ? +projectId : undefined);
  }

  @Get('templates')
  @ApiOperation({ summary: 'List contract templates' })
  @ApiQuery({ name: 'category', required: false })
  getTemplates(@Query('category') category?: string) {
    return this.service.getTemplates({ category });
  }

  @Get('templates/:id')
  @ApiOperation({ summary: 'Get template by id' })
  getTemplate(@Param('id', ParseIntPipe) id: number) {
    return this.service.getTemplate(id);
  }

  @Post('templates/:id/create')
  @ApiOperation({ summary: 'Create contract from template' })
  createFromTemplate(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() dto: CreateFromTemplateDto,
  ) {
    return this.service.createFromTemplate(
      id,
      req.user.id ?? req.user.sub,
      dto,
    );
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get contract by id' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create contract' })
  create(@Body() dto: CreateContractDto) {
    return this.service.create(dto);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update contract' })
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateContractDto,
  ) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete contract' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.remove(id);
  }

  // ── Signatures ──
  @Get(':id/signatures')
  @ApiOperation({ summary: 'Get contract signatures' })
  getSignatures(@Param('id', ParseIntPipe) id: number) {
    return this.service.getSignatures(id);
  }

  @Post(':id/sign')
  @ApiOperation({ summary: 'Sign contract' })
  sign(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() dto: SignContractDto,
  ) {
    return this.service.sign(id, req.user.id ?? req.user.sub, dto);
  }

  @Post(':id/signatures/:partyId/reject')
  @ApiOperation({ summary: 'Reject signature' })
  rejectSignature(
    @Param('id', ParseIntPipe) id: number,
    @Param('partyId', ParseIntPipe) partyId: number,
    @Body() dto: RejectSignatureDto,
  ) {
    return this.service.rejectSignature(id, partyId, dto);
  }

  // ── Milestones ──
  @Get(':id/milestones')
  @ApiOperation({ summary: 'List milestones for contract' })
  getMilestones(@Param('id', ParseIntPipe) id: number) {
    return this.service.getMilestones(id);
  }

  @Get(':id/milestones/stats')
  @ApiOperation({ summary: 'Get milestone stats' })
  getMilestoneStats(@Param('id', ParseIntPipe) id: number) {
    return this.service.getMilestoneStats(id);
  }

  @Post(':id/milestones')
  @ApiOperation({ summary: 'Create milestone' })
  createMilestone(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CreateMilestoneDto,
  ) {
    return this.service.createMilestone(id, dto);
  }

  @Get(':id/milestones/:mid')
  @ApiOperation({ summary: 'Get milestone' })
  getMilestone(
    @Param('id', ParseIntPipe) id: number,
    @Param('mid', ParseIntPipe) mid: number,
  ) {
    return this.service.getMilestone(id, mid);
  }

  @Patch(':id/milestones/:mid')
  @ApiOperation({ summary: 'Update milestone' })
  updateMilestone(
    @Param('id', ParseIntPipe) id: number,
    @Param('mid', ParseIntPipe) mid: number,
    @Body() dto: UpdateMilestoneDto,
  ) {
    return this.service.updateMilestone(id, mid, dto);
  }

  @Delete(':id/milestones/:mid')
  @ApiOperation({ summary: 'Delete milestone' })
  deleteMilestone(
    @Param('id', ParseIntPipe) id: number,
    @Param('mid', ParseIntPipe) mid: number,
  ) {
    return this.service.deleteMilestone(id, mid);
  }

  @Post(':id/milestones/:mid/complete')
  @ApiOperation({ summary: 'Complete milestone' })
  completeMilestone(
    @Param('id', ParseIntPipe) id: number,
    @Param('mid', ParseIntPipe) mid: number,
  ) {
    return this.service.completeMilestone(id, mid);
  }

  // ── Documents ──
  @Get(':id/documents')
  @ApiOperation({ summary: 'List contract documents' })
  getDocuments(@Param('id', ParseIntPipe) id: number) {
    return this.service.getDocuments(id);
  }

  @Post(':id/documents')
  @ApiOperation({ summary: 'Upload document' })
  uploadDocument(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() dto: UploadDocumentDto,
  ) {
    return this.service.uploadDocument(id, req.user.id ?? req.user.sub, dto);
  }

  @Delete(':id/documents/:did')
  @ApiOperation({ summary: 'Delete document' })
  deleteDocument(
    @Param('id', ParseIntPipe) id: number,
    @Param('did', ParseIntPipe) did: number,
  ) {
    return this.service.deleteDocument(id, did);
  }

  // ── PDF ──
  @Get(':id/pdf')
  @ApiOperation({ summary: 'Generate contract PDF' })
  generatePdf(@Param('id', ParseIntPipe) id: number) {
    return this.service.generatePdf(id);
  }
}
