/**
 * Type-safe error handling utilities for strict TypeScript mode
 *
 * These helpers resolve "error is of type 'unknown'" issues in catch blocks
 * while maintaining type safety and runtime checks.
 */

/**
 * Type guard to check if a value is an Error instance
 */
export function isError(error: unknown): error is Error {
  return error instanceof Error;
}

/**
 * Type guard to check if a value is an object with a message property
 */
export function isErrorWithMessage(
  error: unknown,
): error is { message: string } {
  return (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof (error as Record<string, unknown>).message === 'string'
  );
}

/**
 * Type guard for Axios-like errors with response property
 */
export function isAxiosError(error: unknown): error is {
  response?: {
    data?: unknown;
    status?: number;
    statusText?: string;
  };
  message: string;
} {
  return (
    typeof error === 'object' &&
    error !== null &&
    'response' in error &&
    'message' in error
  );
}

/**
 * Safely extract error message from unknown error
 *
 * @param error - Unknown error object
 * @param fallback - Fallback message if error cannot be parsed
 * @returns Error message string
 */
export function getErrorMessage(
  error: unknown,
  fallback = 'An unknown error occurred',
): string {
  if (isErrorWithMessage(error)) {
    return error.message;
  }

  if (typeof error === 'string') {
    return error;
  }

  return fallback;
}

/**
 * Safely extract Axios response data from error
 *
 * @param error - Unknown error object
 * @returns Response data or undefined
 */
export function getAxiosErrorData(error: unknown): unknown {
  if (isAxiosError(error)) {
    return error.response?.data;
  }
  return undefined;
}

/**
 * Convert unknown error to Error instance
 *
 * @param error - Unknown error object
 * @returns Error instance
 */
export function toError(error: unknown): Error {
  if (isError(error)) {
    return error;
  }

  if (isErrorWithMessage(error)) {
    return new Error(getErrorMessage(error));
  }

  if (typeof error === 'string') {
    return new Error(error);
  }

  return new Error('An unknown error occurred');
}

/**
 * Type-safe error logger helper
 *
 * Usage in catch blocks:
 * ```typescript
 * try {
 *   // ... code
 * } catch (error: unknown) {
 *   logError(this.logger, 'Operation failed', error);
 * }
 * ```
 */
export function logError(
  logger: { error: (message: string, trace?: string) => void },
  context: string,
  error: unknown,
): void {
  const message = getErrorMessage(error);
  const trace = isError(error) ? error.stack : undefined;
  logger.error(`${context}: ${message}`, trace);
}

/**
 * Extract status code from Axios error
 */
export function getErrorStatus(error: unknown): number | undefined {
  if (isAxiosError(error)) {
    return error.response?.status;
  }
  return undefined;
}

/**
 * Extract error stack trace safely
 */
export function getErrorStack(error: unknown): string | undefined {
  if (isError(error)) {
    return error.stack;
  }
  return undefined;
}
