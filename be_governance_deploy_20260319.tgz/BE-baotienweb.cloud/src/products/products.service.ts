import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { MarketplaceGovernanceService } from '../marketplace-governance/governance.service';
import { GovernancePersistenceService } from '../marketplace-governance/services/governance-persistence.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { UpdateProductDto } from './dto/update-product.dto';

@Injectable()
export class ProductsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly marketplaceGovernanceService: MarketplaceGovernanceService,
    private readonly governancePersistenceService: GovernancePersistenceService,
  ) {}

  async findAll(query: ProductQueryDto) {
    const {
      page = 1,
      limit = 20,
      category,
      search,
      status,
      minPrice,
      maxPrice,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = query;

    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = {};

    if (category) {
      where.category = category;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (status) {
      where.status = status;
    }

    if (minPrice !== undefined || maxPrice !== undefined) {
      where.price = {};
      if (minPrice !== undefined) {
        where.price.gte = minPrice;
      }
      if (maxPrice !== undefined) {
        where.price.lte = maxPrice;
      }
    }

    // Get total count
    const total = await this.prisma.product.count({ where });

    // Get products
    const products = await this.prisma.product.findMany({
      where,
      skip,
      take: limit,
      orderBy: {
        [sortBy]: sortOrder,
      },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    // Transform to match API contract (rename createdBy user to seller)
    const transformedProducts = products.map((product) => ({
      ...product,
      seller: product.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    }));

    return {
      data: transformedProducts,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: number) {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Transform to match API contract
    return {
      ...product,
      seller: product.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
    };
  }

  async create(createProductDto: CreateProductDto, createdBy: number) {
    // Validate price
    if (createProductDto.price <= 0) {
      throw new BadRequestException('Price must be greater than 0');
    }

    // Validate stock if provided
    if (createProductDto.stock !== undefined && createProductDto.stock < 0) {
      throw new BadRequestException('Stock cannot be negative');
    }

    const product = await this.prisma.$transaction(async (tx) => {
      const created = await tx.product.create({
        data: {
          name: createProductDto.name,
          description: createProductDto.description || '',
          price: createProductDto.price,
          category: createProductDto.category,
          brand: createProductDto.brand,
          model: createProductDto.model,
          stock: createProductDto.stock || 0,
          unit: createProductDto.unit,
          tags: createProductDto.tags || [],
          createdBy,
          status: 'PENDING',
          updatedAt: new Date(),
        },
      });

      await this.replaceProductImages(tx, created.id, createProductDto.images);

      return created;
    });

    const governance = await this.assessAndPersistProduct(product.id);
    const productWithRelations = await this.getProductWithRelations(product.id);

    return this.mapProductResponse(productWithRelations, { governance });
  }

  async update(id: number, updateProductDto: UpdateProductDto, user: any) {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        images: true,
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Check permissions: only owner or ADMIN can update
    if (product.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException(
        'You do not have permission to update this product',
      );
    }

    if (updateProductDto.status !== undefined) {
      throw new ForbiddenException(
        'Product status can only be changed through the dedicated approval flow',
      );
    }

    // Validate price if provided
    if (updateProductDto.price !== undefined && updateProductDto.price <= 0) {
      throw new BadRequestException('Price must be greater than 0');
    }

    // Validate stock if provided
    if (updateProductDto.stock !== undefined && updateProductDto.stock < 0) {
      throw new BadRequestException('Stock cannot be negative');
    }

    await this.prisma.$transaction(async (tx) => {
      if (
        updateProductDto.price !== undefined &&
        Number(product.price) !== updateProductDto.price
      ) {
        await tx.priceHistory.create({
          data: {
            productId: id,
            oldPrice: Number(product.price),
            newPrice: updateProductDto.price,
            changedBy: user.id,
            reason: 'Product price updated',
          },
        });

        if (!product.originalPrice) {
          await tx.product.update({
            where: { id },
            data: { originalPrice: Number(product.price) },
          });
        }
      }

      await tx.product.update({
        where: { id },
        data: {
          ...(updateProductDto.name !== undefined && {
            name: updateProductDto.name,
          }),
          ...(updateProductDto.description !== undefined && {
            description: updateProductDto.description || '',
          }),
          ...(updateProductDto.price !== undefined && {
            price: updateProductDto.price,
          }),
          ...(updateProductDto.category !== undefined && {
            category: updateProductDto.category,
          }),
          ...(updateProductDto.brand !== undefined && {
            brand: updateProductDto.brand,
          }),
          ...(updateProductDto.model !== undefined && {
            model: updateProductDto.model,
          }),
          ...(updateProductDto.stock !== undefined && {
            stock: updateProductDto.stock,
          }),
          ...(updateProductDto.unit !== undefined && {
            unit: updateProductDto.unit,
          }),
          ...(updateProductDto.tags !== undefined && {
            tags: updateProductDto.tags,
          }),
          status: 'PENDING',
          reviewedBy: null,
          reviewedAt: null,
          rejectionReason: null,
          updatedAt: new Date(),
        },
      });

      if (updateProductDto.images !== undefined) {
        await this.replaceProductImages(tx, id, updateProductDto.images);
      }
    });

    const governance = await this.assessAndPersistProduct(id);
    const updated = await this.getProductWithRelations(id);

    return this.mapProductResponse(updated, { governance });
  }

  async remove(id: number, user: any) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Check permissions: only owner or ADMIN can delete
    if (product.createdBy !== user.id && user.role !== Role.ADMIN) {
      throw new ForbiddenException(
        'You do not have permission to delete this product',
      );
    }

    await this.prisma.product.delete({
      where: { id },
    });
  }

  async updateStatus(
    id: number,
    status: 'APPROVED' | 'REJECTED' | 'PENDING',
    reason?: string,
    actor?: { id?: number },
  ) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    let governance:
      | Awaited<ReturnType<ProductsService['assessAndPersistProduct']>>
      | undefined;

    if (status === 'APPROVED') {
      governance = await this.assessAndPersistProduct(id);
      const eligibility =
        await this.governancePersistenceService.ensureSellerEligibleForPublication(
          id,
          product.createdBy,
        );

      if (!eligibility.eligible) {
        throw new ForbiddenException({
          message: 'Seller is not eligible for publication',
          blockingReasons: eligibility.blockingReasons,
          governance,
        });
      }

      await this.governancePersistenceService.resolveReviewQueueForProduct({
        productId: id,
        resolvedById: actor?.id,
        status: 'APPROVED',
      });
    }

    if (status === 'REJECTED') {
      await this.governancePersistenceService.resolveReviewQueueForProduct({
        productId: id,
        resolvedById: actor?.id,
        status: 'REJECTED',
      });
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: {
        status,
        reviewedBy: actor?.id,
        reviewedAt: status === 'PENDING' ? null : new Date(),
        rejectionReason: status === 'REJECTED' ? reason : null,
        updatedAt: new Date(),
      },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    return this.mapProductResponse(updated, {
      ...(governance ? { governance } : {}),
      message:
        status === 'APPROVED'
          ? 'Sản phẩm đã được duyệt'
          : status === 'REJECTED'
            ? `Sản phẩm bị từ chối. Lý do: ${reason || 'Không đủ điều kiện'}`
            : 'Sản phẩm đang chờ duyệt',
    });
  }

  // ==================== NEW METHODS ====================

  /**
   * Get featured products
   */
  async getFeatured() {
    const products = await this.prisma.product.findMany({
      where: {
        status: 'APPROVED',
        isBestseller: true,
      },
      take: 12,
      orderBy: {
        soldCount: 'desc',
      },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });

    return {
      data: products.map((p) => ({
        ...p,
        seller: p.users_products_createdByTousers,
        users_products_createdByTousers: undefined,
      })),
      meta: { total: products.length },
    };
  }

  /**
   * Get best selling products
   */
  async getBestSellers(limit: number = 10) {
    const products = await this.prisma.product.findMany({
      where: {
        status: 'APPROVED',
      },
      take: limit,
      orderBy: {
        soldCount: 'desc',
      },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });

    return {
      data: products.map((p) => ({
        ...p,
        seller: p.users_products_createdByTousers,
        users_products_createdByTousers: undefined,
      })),
      meta: { total: products.length },
    };
  }

  /**
   * Get new arrival products
   */
  async getNewArrivals(limit: number = 10) {
    const products = await this.prisma.product.findMany({
      where: {
        status: 'APPROVED',
        isNew: true,
      },
      take: limit,
      orderBy: {
        createdAt: 'desc',
      },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });

    return {
      data: products.map((p) => ({
        ...p,
        seller: p.users_products_createdByTousers,
        users_products_createdByTousers: undefined,
      })),
      meta: { total: products.length },
    };
  }

  /**
   * Get related products (same category)
   */
  async getRelated(productId: number, limit: number = 8) {
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${productId} not found`);
    }

    const related = await this.prisma.product.findMany({
      where: {
        status: 'APPROVED',
        category: product.category,
        id: { not: productId },
      },
      take: limit,
      orderBy: {
        soldCount: 'desc',
      },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });

    return {
      data: related.map((p) => ({
        ...p,
        seller: p.users_products_createdByTousers,
        users_products_createdByTousers: undefined,
      })),
      meta: { total: related.length },
    };
  }

  /**
   * Get pending products for admin approval
   */
  async getPending() {
    const products = await this.prisma.product.findMany({
      where: {
        status: 'PENDING',
      },
      orderBy: {
        createdAt: 'asc',
      },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });

    return {
      data: products.map((p) => ({
        ...p,
        seller: p.users_products_createdByTousers,
        users_products_createdByTousers: undefined,
      })),
      meta: { total: products.length },
    };
  }

  /**
   * Toggle featured status
   */
  async toggleFeatured(id: number) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: {
        isBestseller: !product.isBestseller,
        updatedAt: new Date(),
      },
    });

    return {
      id: updated.id,
      featured: updated.isBestseller,
      message: updated.isBestseller
        ? 'Đã đánh dấu nổi bật'
        : 'Đã bỏ đánh dấu nổi bật',
    };
  }

  // ==================== STRAPI SYNC METHODS ====================

  /**
   * Find product by Strapi ID
   */
  async findByStrapiId(strapiId: string) {
    return this.prisma.product.findUnique({
      where: { strapiId },
      include: {
        users_products_createdByTousers: {
          select: { id: true, name: true, email: true },
        },
        images: true,
      },
    });
  }

  /**
   * Create product from Strapi sync (without user requirement)
   */
  async createFromStrapi(data: any) {
    return this.prisma.product.create({
      data: {
        name: data.name,
        description: data.description || '',
        price: data.price,
        category: data.category,
        brand: data.brand,
        model: data.model,
        stock: data.stock || 0,
        unit: data.unit,
        tags: data.tags || [],
        status: data.status || 'PENDING',
        viewCount: data.viewCount || 0,
        soldCount: data.soldCount || 0,
        isBestseller: data.isBestseller || false,
        isNew: data.isNew || true,
        strapiId: data.strapiId,
        createdBy: data.createdBy || 1, // Default to admin
        updatedAt: new Date(),
      },
    });
  }

  /**
   * Update product from Strapi sync
   */
  async updateFromStrapi(id: number, data: any) {
    return this.prisma.product.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        price: data.price,
        category: data.category,
        brand: data.brand,
        model: data.model,
        stock: data.stock,
        unit: data.unit,
        tags: data.tags,
        status: data.status,
        viewCount: data.viewCount,
        soldCount: data.soldCount,
        isBestseller: data.isBestseller,
        isNew: data.isNew,
        updatedAt: new Date(),
      },
    });
  }

  /**
   * Delete product by ID (without user requirement for sync)
   */
  async removeById(id: number) {
    await this.prisma.product.delete({ where: { id } });
    return { deleted: true, id };
  }

  // =====================================================
  // PRICE HISTORY
  // =====================================================

  /**
   * Get price history for a product
   */
  async getPriceHistory(productId: number, limit = 30) {
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
      select: { id: true, name: true, price: true, originalPrice: true },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${productId} not found`);
    }

    const history = await this.prisma.priceHistory.findMany({
      where: { productId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return {
      success: true,
      data: {
        productId,
        productName: product.name,
        currentPrice: Number(product.price),
        originalPrice: product.originalPrice
          ? Number(product.originalPrice)
          : null,
        history: history.map((h) => ({
          id: h.id,
          oldPrice: Number(h.oldPrice),
          newPrice: Number(h.newPrice),
          changedBy: h.changedBy,
          reason: h.reason,
          createdAt: h.createdAt,
        })),
      },
    };
  }

  private async getProductWithRelations(id: number) {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        users_products_createdByTousers: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        images: true,
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    return product;
  }

  private mapProductResponse(
    product: any,
    extras: Record<string, unknown> = {},
  ) {
    return {
      ...product,
      seller: product.users_products_createdByTousers,
      users_products_createdByTousers: undefined,
      ...extras,
    };
  }

  private async replaceProductImages(
    tx: PrismaService | any,
    productId: number,
    images?: string[],
  ) {
    if (images === undefined) {
      return;
    }

    await tx.productImage.deleteMany({
      where: { productId },
    });

    if (images.length === 0) {
      return;
    }

    await tx.productImage.createMany({
      data: images.map((url, index) => ({
        productId,
        url,
        isPrimary: index === 0,
        displayOrder: index,
      })),
    });
  }

  private async assessAndPersistProduct(productId: number) {
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
      include: {
        images: true,
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${productId} not found`);
    }

    const policyAcceptance =
      await this.governancePersistenceService.getLatestPolicyAcceptance(
        productId,
        product.createdBy,
      );
    const candidates =
      await this.governancePersistenceService.listProductMasterCandidates({
        category: product.category,
        brand: product.brand || undefined,
        model: product.model || undefined,
      });
    const marketOffers =
      await this.governancePersistenceService.listComparableOffers({
        productId,
        category: product.category,
        brand: product.brand,
        model: product.model,
      });

    const assessment =
      await this.marketplaceGovernanceService.assessSellerOffer({
        offer: {
          sellerId: product.createdBy,
          productMasterId: product.productMasterId || undefined,
          sellerSku: `product-${product.id}`,
          sellerTitle: product.name,
          sellerDescription: product.description,
          salePrice: Number(product.price),
          stockQuantity: product.stock,
          condition: this.resolveCondition(product.tags),
          warrantyPolicy: undefined,
          shippingInfo: undefined,
          sellerImages: product.images.map((image) => image.url),
          verifiedFlags: product.tags.includes('official_store')
            ? ['OFFICIAL_STORE']
            : [],
          declaredBrand: product.brand || 'unknown',
          declaredModel: product.model || product.name,
          declaredCategory: product.category,
          variantAttributes: product.unit ? { unit: product.unit } : {},
          technicalSpecs: {},
          premiumReason: undefined,
          evidenceNotes: undefined,
          liabilityAccepted: Boolean(policyAcceptance),
          liabilityPolicyVersion: policyAcceptance?.policyVersion,
        },
        candidates,
        marketOffers,
      });

    const persisted =
      await this.governancePersistenceService.syncProductGovernanceAssessment({
        productId,
        sellerId: product.createdBy,
        topMatch: assessment.topMatch,
        pricing: assessment.pricing,
        compliance: assessment.compliance,
        reviewQueue: assessment.reviewQueue,
      });

    return {
      ...assessment,
      policyAccepted: Boolean(policyAcceptance),
      persisted,
    };
  }

  private resolveCondition(tags: string[]) {
    if (tags.includes('refurbished')) {
      return 'REFURBISHED' as const;
    }
    if (tags.includes('used')) {
      return 'USED' as const;
    }
    return 'NEW' as const;
  }
}
