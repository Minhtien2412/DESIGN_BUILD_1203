import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Patch,
    Post,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CanApproveProduct,
    CanCreateProduct,
    CanRejectProduct,
    CanViewPendingProducts,
    Permission,
    RequirePermission,
} from '../authorization';
import {
    PermissionGuard,
    ProductApprovalGuard,
} from '../authorization/guards/permission.guard';
import { CreateProductDto } from './dto/create-product.dto';
import { ProductCategory, ProductQueryDto } from './dto/product-query.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductsService } from './products.service';

@ApiTags('Products')
@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  // ==================== PUBLIC ENDPOINTS ====================

  /**
   * GET /products
   * Public endpoint - anyone can view products
   */
  @Get()
  @ApiOperation({ summary: 'Get all products with filters' })
  async findAll(@Query() query: ProductQueryDto) {
    return this.productsService.findAll(query);
  }

  /**
   * GET /products/:id/price-history
   * Public - view price history for a product
   */
  @Get(':id/price-history')
  @ApiOperation({ summary: 'Get product price history' })
  async getPriceHistory(
    @Param('id') id: string,
    @Query('limit') limit?: string,
  ) {
    return this.productsService.getPriceHistory(
      +id,
      limit ? parseInt(limit) : 30,
    );
  }

  /**
   * GET /products/categories
   * Get all product categories
   */
  @Get('categories')
  @ApiOperation({ summary: 'Get all product categories' })
  getCategories() {
    return Object.entries(ProductCategory).map(([key, value]) => ({
      id: key,
      value: value,
      label: this.getCategoryLabel(value),
      icon: this.getCategoryIcon(value),
    }));
  }

  /**
   * GET /products/featured
   * Get featured products
   */
  @Get('featured')
  @ApiOperation({ summary: 'Get featured products' })
  async getFeaturedProducts() {
    return this.productsService.getFeatured();
  }

  /**
   * GET /products/best-sellers
   * Get best selling products
   */
  @Get('best-sellers')
  @ApiOperation({ summary: 'Get best selling products' })
  async getBestSellers(@Query('limit') limit?: number) {
    return this.productsService.getBestSellers(limit || 10);
  }

  /**
   * GET /products/new-arrivals
   * Get newest products
   */
  @Get('new-arrivals')
  @ApiOperation({ summary: 'Get new arrival products' })
  async getNewArrivals(@Query('limit') limit?: number) {
    return this.productsService.getNewArrivals(limit || 10);
  }

  /**
   * GET /products/:id
   * Public endpoint - anyone can view product details
   */
  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  async findOne(@Param('id') id: string) {
    return this.productsService.findOne(+id);
  }

  /**
   * GET /products/:id/related
   * Get related products
   */
  @Get(':id/related')
  @ApiOperation({ summary: 'Get related products' })
  async getRelatedProducts(
    @Param('id') id: string,
    @Query('limit') limit?: number,
  ) {
    return this.productsService.getRelated(+id, limit || 8);
  }

  // ==================== PROTECTED ENDPOINTS ====================

  /**
   * POST /products
   * Protected - requires PRODUCT_CREATE permission
   * Mọi user đăng nhập có thể tạo, nhưng sẽ chờ duyệt
   */
  @Post()
  @UseGuards(JwtAuthGuard, PermissionGuard)
  @CanCreateProduct()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new product (requires approval)' })
  @ApiResponse({
    status: 201,
    description: 'Product created - pending approval',
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - no permission' })
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createProductDto: CreateProductDto, @Request() req) {
    return this.productsService.create(createProductDto, req.user.id);
  }

  /**
   * PATCH /products/:id
   * Protected - requires owner or ADMIN
   */
  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update a product' })
  @ApiResponse({ status: 200, description: 'Product updated successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - not owner or admin' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
    @Request() req,
  ) {
    return this.productsService.update(+id, updateProductDto, req.user);
  }

  /**
   * DELETE /products/:id
   * Protected - requires owner or ADMIN
   */
  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete a product' })
  @ApiResponse({ status: 204, description: 'Product deleted successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - not owner or admin' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(@Param('id') id: string, @Request() req) {
    await this.productsService.remove(+id, req.user);
  }

  // ==================== ADMIN ENDPOINTS ====================

  /**
   * GET /products/admin/pending
   * Get pending products for admin approval
   * Requires PRODUCT_VIEW_PENDING permission
   */
  @Get('admin/pending')
  @UseGuards(JwtAuthGuard, PermissionGuard)
  @CanViewPendingProducts()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get pending products (Staff+ only)' })
  async getPendingProducts() {
    return this.productsService.getPending();
  }

  /**
   * PATCH /products/:id/approve
   * Approve a pending product
   * Requires PRODUCT_APPROVE permission (ADMIN, STAFF)
   */
  @Patch(':id/approve')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @CanApproveProduct()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Approve a product (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Product approved successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({
    status: 403,
    description: 'Forbidden - no approval permission',
  })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async approveProduct(@Param('id') id: string, @Request() req) {
    return this.productsService.updateStatus(
      +id,
      'APPROVED',
      undefined,
      req.user,
    );
  }

  /**
   * PATCH /products/:id/reject
   * Reject a pending product
   * Requires PRODUCT_REJECT permission (ADMIN, STAFF)
   */
  @Patch(':id/reject')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @CanRejectProduct()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Reject a product (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Product rejected successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({
    status: 403,
    description: 'Forbidden - no rejection permission',
  })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async rejectProduct(
    @Param('id') id: string,
    @Body('reason') reason: string,
    @Request() req,
  ) {
    return this.productsService.updateStatus(+id, 'REJECTED', reason, req.user);
  }

  /**
   * PATCH /products/:id/status
   * Update product status (legacy endpoint)
   * Requires PRODUCT_APPROVE permission
   */
  @Patch(':id/status')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @RequirePermission(Permission.PRODUCT_APPROVE)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update product status (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Status updated successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - staff+ only' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async updateStatus(
    @Param('id') id: string,
    @Body('status') status: 'APPROVED' | 'REJECTED' | 'PENDING',
    @Body('reason') reason?: string,
    @Request() req?,
  ) {
    return this.productsService.updateStatus(+id, status, reason, req?.user);
  }

  /**
   * PATCH /products/:id/feature
   * Toggle featured status
   * Requires PRODUCT_FEATURE permission (ADMIN only)
   */
  @Patch(':id/feature')
  @UseGuards(JwtAuthGuard, PermissionGuard)
  @RequirePermission(Permission.PRODUCT_FEATURE)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Toggle product featured status (Admin only)' })
  @HttpCode(HttpStatus.OK)
  async toggleFeatured(@Param('id') id: string) {
    return this.productsService.toggleFeatured(+id);
  }

  // ==================== HELPER METHODS ====================

  private getCategoryLabel(category: ProductCategory): string {
    const labels: Record<ProductCategory, string> = {
      [ProductCategory.CONSTRUCTION_EQUIPMENT]: 'Thiết bị xây dựng',
      [ProductCategory.POWER_TOOLS]: 'Dụng cụ điện',
      [ProductCategory.HAND_TOOLS]: 'Dụng cụ cầm tay',
      [ProductCategory.SAFETY_EQUIPMENT]: 'Thiết bị an toàn',
      [ProductCategory.MEASURING_TOOLS]: 'Dụng cụ đo lường',
      [ProductCategory.CEMENT_CONCRETE]: 'Xi măng & Bê tông',
      [ProductCategory.STEEL_IRON]: 'Thép & Sắt',
      [ProductCategory.BRICKS_TILES]: 'Gạch & Ngói',
      [ProductCategory.WOOD_TIMBER]: 'Gỗ & Ván',
      [ProductCategory.SAND_GRAVEL]: 'Cát & Đá',
      [ProductCategory.PAINT_COATING]: 'Sơn & Phủ',
      [ProductCategory.ELECTRICAL]: 'Thiết bị điện',
      [ProductCategory.PLUMBING]: 'Thiết bị nước',
      [ProductCategory.LIGHTING]: 'Đèn chiếu sáng',
      [ProductCategory.FURNITURE]: 'Nội thất',
      [ProductCategory.FLOORING]: 'Sàn & Lát',
      [ProductCategory.DOORS_WINDOWS]: 'Cửa & Cửa sổ',
      [ProductCategory.KITCHEN_BATHROOM]: 'Bếp & Phòng tắm',
      [ProductCategory.DECORATION]: 'Trang trí',
      [ProductCategory.RENTAL_EQUIPMENT]: 'Cho thuê thiết bị',
      [ProductCategory.USED_EQUIPMENT]: 'Thiết bị đã qua sử dụng',
      [ProductCategory.OTHER]: 'Khác',
    };
    return labels[category] || category;
  }

  private getCategoryIcon(category: ProductCategory): string {
    const icons: Record<ProductCategory, string> = {
      [ProductCategory.CONSTRUCTION_EQUIPMENT]: 'hard-hat',
      [ProductCategory.POWER_TOOLS]: 'zap',
      [ProductCategory.HAND_TOOLS]: 'wrench',
      [ProductCategory.SAFETY_EQUIPMENT]: 'shield',
      [ProductCategory.MEASURING_TOOLS]: 'ruler',
      [ProductCategory.CEMENT_CONCRETE]: 'package',
      [ProductCategory.STEEL_IRON]: 'link',
      [ProductCategory.BRICKS_TILES]: 'grid',
      [ProductCategory.WOOD_TIMBER]: 'layers',
      [ProductCategory.SAND_GRAVEL]: 'mountain',
      [ProductCategory.PAINT_COATING]: 'brush',
      [ProductCategory.ELECTRICAL]: 'plug',
      [ProductCategory.PLUMBING]: 'droplet',
      [ProductCategory.LIGHTING]: 'sun',
      [ProductCategory.FURNITURE]: 'sofa',
      [ProductCategory.FLOORING]: 'square',
      [ProductCategory.DOORS_WINDOWS]: 'door-open',
      [ProductCategory.KITCHEN_BATHROOM]: 'bath',
      [ProductCategory.DECORATION]: 'image',
      [ProductCategory.RENTAL_EQUIPMENT]: 'clock',
      [ProductCategory.USED_EQUIPMENT]: 'refresh-cw',
      [ProductCategory.OTHER]: 'more-horizontal',
    };
    return icons[category] || 'package';
  }
}
