/**
 * Products Controller
 * ===================
 * Controller quản lý sản phẩm với phân quyền chi tiết
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Patch,
    Post,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CanApproveProduct,
    CanCreateProduct,
    Permission,
    RequirePermission,
} from '../authorization';
import {
    PermissionGuard,
    ProductApprovalGuard,
} from '../authorization/guards/permission.guard';
import { CreateProductDto } from './dto/create-product.dto';
import { ProductQueryDto } from './dto/product-query.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProductsService } from './products.service';

@ApiTags('Products')
@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  // ==================== PUBLIC ENDPOINTS ====================

  /**
   * GET /products
   * Public endpoint - anyone can view products
   */
  @Get()
  @ApiOperation({ summary: 'Get all products with filters' })
  async findAll(@Query() query: ProductQueryDto) {
    return this.productsService.findAll(query);
  }

  /**
   * GET /products/:id
   * Public endpoint - anyone can view product details
   */
  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  async findOne(@Param('id') id: string) {
    return this.productsService.findOne(+id);
  }

  // ==================== PROTECTED ENDPOINTS ====================

  /**
   * POST /products
   * Protected - requires PRODUCT_CREATE permission
   * Mọi user đăng nhập có thể tạo, nhưng sẽ chờ duyệt
   */
  @Post()
  @UseGuards(JwtAuthGuard, PermissionGuard)
  @CanCreateProduct()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new product (requires approval)' })
  @ApiResponse({
    status: 201,
    description: 'Product created - pending approval',
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - no permission' })
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createProductDto: CreateProductDto, @Request() req) {
    return this.productsService.create(createProductDto, req.user.id);
  }

  /**
   * PATCH /products/:id
   * Protected - requires owner or ADMIN
   */
  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update a product' })
  @ApiResponse({ status: 200, description: 'Product updated successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - not owner or admin' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
    @Request() req,
  ) {
    return this.productsService.update(+id, updateProductDto, req.user);
  }

  /**
   * DELETE /products/:id
   * Protected - requires owner or ADMIN
   */
  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete a product' })
  @ApiResponse({ status: 204, description: 'Product deleted successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - not owner or admin' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(@Param('id') id: string, @Request() req) {
    await this.productsService.remove(+id, req.user);
  }

  // ==================== ADMIN ENDPOINTS ====================

  /**
   * GET /products/admin/pending
   * Get pending products for admin approval
   * Requires PRODUCT_VIEW_PENDING permission
   */
  @Get('admin/pending')
  @UseGuards(JwtAuthGuard, PermissionGuard)
  @RequirePermission(Permission.PRODUCT_VIEW_PENDING)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get pending products (Staff+ only)' })
  async getPendingProducts(@Query() query: ProductQueryDto) {
    // Set status to PENDING and call findAll
    return this.productsService.findAll({ ...query, status: 'PENDING' });
  }

  /**
   * PATCH /products/:id/approve
   * Approve a pending product
   * Requires PRODUCT_APPROVE permission (ADMIN, STAFF)
   */
  @Patch(':id/approve')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @CanApproveProduct()
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Approve a product (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Product approved successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({
    status: 403,
    description: 'Forbidden - no approval permission',
  })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async approveProduct(@Param('id') id: string, @Request() req) {
    return this.productsService.updateStatus(
      +id,
      'APPROVED',
      undefined,
      req.user,
    );
  }

  /**
   * PATCH /products/:id/reject
   * Reject a pending product
   * Requires PRODUCT_REJECT permission (ADMIN, STAFF)
   */
  @Patch(':id/reject')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @RequirePermission(Permission.PRODUCT_REJECT)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Reject a product (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Product rejected successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({
    status: 403,
    description: 'Forbidden - no rejection permission',
  })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async rejectProduct(@Param('id') id: string, @Request() req) {
    return this.productsService.updateStatus(
      +id,
      'REJECTED',
      undefined,
      req.user,
    );
  }

  /**
   * PATCH /products/:id/status
   * Update product status (legacy endpoint)
   * Requires PRODUCT_APPROVE permission
   */
  @Patch(':id/status')
  @UseGuards(JwtAuthGuard, ProductApprovalGuard)
  @RequirePermission(Permission.PRODUCT_APPROVE)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update product status (Staff+ only)' })
  @ApiResponse({ status: 200, description: 'Status updated successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 403, description: 'Forbidden - staff+ only' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @HttpCode(HttpStatus.OK)
  async updateStatus(
    @Param('id') id: string,
    @Body('status') status: 'APPROVED' | 'REJECTED' | 'PENDING',
    @Request() req,
  ) {
    return this.productsService.updateStatus(+id, status, undefined, req.user);
  }
}
