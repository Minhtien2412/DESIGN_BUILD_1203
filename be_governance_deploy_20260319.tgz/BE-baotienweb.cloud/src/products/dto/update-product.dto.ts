import { PartialType } from '@nestjs/mapped-types';
import { CreateProductDto } from './create-product.dto';
import { IsEnum, IsOptional } from 'class-validator';

export enum ProductStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export class UpdateProductDto extends PartialType(CreateProductDto) {
  @IsEnum(ProductStatus)
  @IsOptional()
  status?: ProductStatus;
}
