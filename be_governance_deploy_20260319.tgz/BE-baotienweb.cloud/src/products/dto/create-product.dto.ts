import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

export enum ProductCategory {
  ELECTRONICS = 'ELECTRONICS',
  FASHION = 'FASHION',
  HOME = 'HOME',
  BEAUTY = 'BEAUTY',
  SPORTS = 'SPORTS',
  BOOKS = 'BOOKS',
  TOYS = 'TOYS',
  FOOD = 'FOOD',
  OTHER = 'OTHER',
}

export class CreateProductDto {
  @ApiProperty({ example: 'iPhone 15 Pro Max', description: 'Tên sản phẩm' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({
    example: 'Điện thoại thông minh cao cấp từ Apple',
    description: 'Mô tả sản phẩm',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: 35990000, description: 'Giá sản phẩm (VND)' })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  price: number;

  @ApiProperty({
    enum: ProductCategory,
    example: 'ELECTRONICS',
    description: 'Danh mục sản phẩm',
  })
  @IsEnum(ProductCategory)
  @IsNotEmpty()
  category: ProductCategory;

  @ApiPropertyOptional({
    example: ['https://example.com/img1.jpg'],
    description: 'Danh sách URL hình ảnh',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  images?: string[];

  @ApiPropertyOptional({ example: 100, description: 'Số lượng tồn kho' })
  @IsOptional()
  @IsInt()
  @Min(0)
  stock?: number;

  @ApiPropertyOptional({ example: 'Chiếc', description: 'Đơn vị tính' })
  @IsOptional()
  @IsString()
  unit?: string;

  @ApiPropertyOptional({ example: 'Apple', description: 'Thương hiệu' })
  @IsOptional()
  @IsString()
  brand?: string;

  @ApiPropertyOptional({ example: 'A3106', description: 'Mã model' })
  @IsOptional()
  @IsString()
  model?: string;

  @ApiPropertyOptional({
    example: ['điện thoại', 'apple', 'cao cấp'],
    description: 'Tags/Nhãn',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}
