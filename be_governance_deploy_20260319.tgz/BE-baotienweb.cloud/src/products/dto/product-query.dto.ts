import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsBoolean,
    IsEnum,
    IsInt,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

// Equipment/Construction specific categories
export enum ProductCategory {
  // Thiết bị xây dựng
  CONSTRUCTION_EQUIPMENT = 'CONSTRUCTION_EQUIPMENT',
  POWER_TOOLS = 'POWER_TOOLS',
  HAND_TOOLS = 'HAND_TOOLS',
  SAFETY_EQUIPMENT = 'SAFETY_EQUIPMENT',
  MEASURING_TOOLS = 'MEASURING_TOOLS',

  // Vật liệu xây dựng
  CEMENT_CONCRETE = 'CEMENT_CONCRETE',
  STEEL_IRON = 'STEEL_IRON',
  BRICKS_TILES = 'BRICKS_TILES',
  WOOD_TIMBER = 'WOOD_TIMBER',
  SAND_GRAVEL = 'SAND_GRAVEL',
  PAINT_COATING = 'PAINT_COATING',

  // Điện nước
  ELECTRICAL = 'ELECTRICAL',
  PLUMBING = 'PLUMBING',
  LIGHTING = 'LIGHTING',

  // Hoàn thiện
  FURNITURE = 'FURNITURE',
  FLOORING = 'FLOORING',
  DOORS_WINDOWS = 'DOORS_WINDOWS',
  KITCHEN_BATHROOM = 'KITCHEN_BATHROOM',
  DECORATION = 'DECORATION',

  // Khác
  RENTAL_EQUIPMENT = 'RENTAL_EQUIPMENT',
  USED_EQUIPMENT = 'USED_EQUIPMENT',
  OTHER = 'OTHER',
}

export class ProductQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number = 20;

  @ApiPropertyOptional({
    enum: ProductCategory,
    description: 'Product category',
  })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiPropertyOptional({ description: 'Search by name, description' })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({ enum: ['PENDING', 'APPROVED', 'REJECTED'] })
  @IsOptional()
  @IsEnum(['PENDING', 'APPROVED', 'REJECTED'])
  status?: string;

  @ApiPropertyOptional({ description: 'Minimum price' })
  @IsOptional()
  @Type(() => Number)
  minPrice?: number;

  @ApiPropertyOptional({ description: 'Maximum price' })
  @IsOptional()
  @Type(() => Number)
  maxPrice?: number;

  @ApiPropertyOptional({ description: 'Filter by seller ID' })
  @IsOptional()
  @IsString()
  sellerId?: string;

  @ApiPropertyOptional({ description: 'Filter by location' })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiPropertyOptional({ description: 'Only featured products' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  featured?: boolean;

  @ApiPropertyOptional({ description: 'Only in-stock products' })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  inStock?: boolean;

  @ApiPropertyOptional({
    description: 'Product condition',
    enum: ['NEW', 'USED', 'REFURBISHED'],
  })
  @IsOptional()
  @IsString()
  condition?: string;

  @ApiPropertyOptional({
    default: 'createdAt',
    enum: ['createdAt', 'price', 'name', 'rating', 'sales'],
  })
  @IsOptional()
  @IsEnum(['createdAt', 'price', 'name', 'rating', 'sales'])
  sortBy?: string = 'createdAt';

  @ApiPropertyOptional({ default: 'desc', enum: ['asc', 'desc'] })
  @IsOptional()
  @IsEnum(['asc', 'desc'])
  sortOrder?: 'asc' | 'desc' = 'desc';
}
