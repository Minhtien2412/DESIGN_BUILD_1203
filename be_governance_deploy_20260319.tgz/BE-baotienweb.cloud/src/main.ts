import { ValidationPipe, VersioningType } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { join } from 'path';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Serve static files from public directory
  app.useStaticAssets(join(__dirname, '..', 'public'));

  // Serve uploaded files with proper caching
  app.useStaticAssets(join(__dirname, '..', 'uploads'), {
    prefix: '/uploads/',
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days cache
    etag: true,
    lastModified: true,
  });

  // Enable global validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Security headers (Helmet)
  app.use(
    helmet({
      contentSecurityPolicy: false, // Disable CSP for Swagger UI
      crossOriginEmbedderPolicy: false,
    }),
  );

  // Enable CORS - locked to specific origins
  app.enableCors({
    origin: [
      'https://baotienweb.cloud',
      'https://www.baotienweb.cloud',
      'http://localhost:3000',
      'http://localhost:8081',
      'http://localhost:19006',
      // Expo dev client
      /^exp:\/\//,
      /^https?:\/\/.*\.exp\.direct/,
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-API-Key',
      'X-Requested-With',
      'X-Request-Id',
      'X-Correlation-Id',
    ],
    maxAge: 86400,
  });

  // API Versioning
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
    prefix: 'api/v',
  });

  // Swagger configuration
  const config = new DocumentBuilder()
    .setTitle('Baotienweb API')
    .setDescription(
      'API documentation for Baotienweb backend - Project Management System',
    )
    .setVersion('1.0')
    .addServer('https://baotienweb.cloud', 'Production')
    .addServer('http://localhost:3000', 'Development')
    .addTag('Users')
    .addTag('Authentication')
    .addTag('Projects')
    .addTag('Tasks')
    .addTag('Comments')
    .addTag('Chat')
    .addTag('Upload')
    .addTag('Video Call')
    .addTag('Payment')
    .addTag('AI Agent')
    .addTag('Dashboard')
    .addTag('Reels')
    .addBearerAuth()
    .addApiKey({ type: 'apiKey', name: 'X-API-Key', in: 'header' }, 'X-API-Key')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  await app.listen(process.env.PORT ?? 3000);
  console.log(
    `Application is running on: http://localhost:${process.env.PORT ?? 3000}`,
  );
  console.log(
    `Swagger docs available at: http://localhost:${process.env.PORT ?? 3000}/api/docs`,
  );
  console.log(
    `API v1 endpoints: http://localhost:${process.env.PORT ?? 3000}/api/v1/`,
  );
}
bootstrap();
