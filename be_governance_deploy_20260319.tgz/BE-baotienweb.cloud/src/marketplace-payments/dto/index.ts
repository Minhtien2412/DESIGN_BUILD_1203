import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsEnum,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';
import { MarketplaceGateway } from '../enums';

// =====================================================
// Payment DTOs
// =====================================================

export class CreateMarketplacePaymentDto {
  @ApiProperty({ description: 'Booking ID', example: 123 })
  @IsInt()
  @IsNotEmpty()
  bookingId: number;

  @ApiProperty({
    description: 'Cổng thanh toán',
    enum: MarketplaceGateway,
    example: 'MOMO',
  })
  @IsEnum(MarketplaceGateway)
  @IsNotEmpty()
  gateway: MarketplaceGateway;

  @ApiProperty({
    description: 'Phương thức thanh toán',
    example: 'momo',
  })
  @IsString()
  @IsNotEmpty()
  paymentMethod: string;

  @ApiPropertyOptional({
    description: 'Mã khuyến mãi',
    example: 'WELCOME50',
  })
  @IsString()
  @IsOptional()
  promoCode?: string;

  @ApiPropertyOptional({ description: 'URL trả về sau thanh toán' })
  @IsString()
  @IsOptional()
  returnUrl?: string;

  @ApiPropertyOptional({ description: 'Idempotency key' })
  @IsString()
  @IsOptional()
  idempotencyKey?: string;
}

export class PaymentHistoryQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Filter by status' })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({ description: 'Filter by gateway' })
  @IsOptional()
  @IsString()
  gateway?: string;
}

export class CancelPaymentDto {
  @ApiPropertyOptional({ description: 'Lý do hủy' })
  @IsString()
  @IsOptional()
  reason?: string;
}

export class RefundPaymentDto {
  @ApiPropertyOptional({
    description: 'Số tiền refund (bỏ trống = full refund)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  amount?: number;

  @ApiProperty({ description: 'Lý do refund' })
  @IsString()
  @IsNotEmpty()
  reason: string;
}

// =====================================================
// Escrow DTOs
// =====================================================

export class ReleaseEscrowDto {
  @ApiProperty({ description: 'Lý do release' })
  @IsString()
  @IsNotEmpty()
  reason: string;
}

export class RefundEscrowDto {
  @ApiPropertyOptional({
    description: 'Số tiền refund (bỏ trống = full refund)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  amount?: number;

  @ApiProperty({ description: 'Lý do refund' })
  @IsString()
  @IsNotEmpty()
  reason: string;
}

export class CreateDisputeDto {
  @ApiProperty({ description: 'Escrow ID liên quan' })
  @IsInt()
  @IsNotEmpty()
  escrowId: number;

  @ApiProperty({ description: 'Lý do khiếu nại' })
  @IsString()
  @IsNotEmpty()
  reason: string;

  @ApiProperty({ description: 'Mô tả chi tiết' })
  @IsString()
  @IsNotEmpty()
  description: string;
}

export class EscrowQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Filter by status' })
  @IsOptional()
  @IsString()
  status?: string;
}

// =====================================================
// Wallet DTOs
// =====================================================

export class TopupWalletDto {
  @ApiProperty({ description: 'Số tiền nạp', example: 500000 })
  @IsNumber()
  @Min(10000)
  amount: number;

  @ApiPropertyOptional({ description: 'Phương thức nạp' })
  @IsString()
  @IsOptional()
  method?: string;
}

export class WithdrawWalletDto {
  @ApiProperty({ description: 'Số tiền rút', example: 200000 })
  @IsNumber()
  @Min(10000)
  amount: number;

  @ApiPropertyOptional({ description: 'Thông tin ngân hàng' })
  @IsString()
  @IsOptional()
  bankInfo?: string;
}

export class TransferWalletDto {
  @ApiProperty({ description: 'User ID nhận' })
  @IsInt()
  @IsNotEmpty()
  toUserId: number;

  @ApiProperty({ description: 'Số tiền chuyển' })
  @IsNumber()
  @Min(1000)
  amount: number;

  @ApiPropertyOptional({ description: 'Mô tả' })
  @IsString()
  @IsOptional()
  description?: string;
}

export class WalletTransactionQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Filter by type' })
  @IsOptional()
  @IsString()
  type?: string;
}

// =====================================================
// Promo DTOs
// =====================================================

export class ValidatePromoDto {
  @ApiProperty({ description: 'Mã promo', example: 'WELCOME50' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'Booking ID', example: 123 })
  @IsInt()
  @IsNotEmpty()
  bookingId: number;
}

export class CreatePromoDto {
  @ApiProperty({ description: 'Mã promo', example: 'WELCOME50' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'Tên promo' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'Loại: FIXED | PERCENT',
    enum: ['FIXED', 'PERCENT'],
  })
  @IsEnum(['FIXED', 'PERCENT'])
  type: string;

  @ApiProperty({ description: 'Giá trị giảm giá', example: 50000 })
  @IsNumber()
  @Min(1)
  value: number;

  @ApiPropertyOptional({ description: 'Đơn hàng tối thiểu' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  minOrderAmount?: number;

  @ApiPropertyOptional({ description: 'Giảm tối đa' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  maxDiscountAmount?: number;

  @ApiPropertyOptional({ description: 'Số lần dùng tối đa' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  usageLimit?: number;

  @ApiPropertyOptional({ description: 'Ngày bắt đầu' })
  @IsOptional()
  @IsString()
  startsAt?: string;

  @ApiPropertyOptional({ description: 'Ngày kết thúc' })
  @IsOptional()
  @IsString()
  endsAt?: string;
}

// =====================================================
// Invoice DTOs
// =====================================================

export class InvoiceQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Filter by customer ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  customerId?: number;
}

// =====================================================
// Dispute DTOs
// =====================================================

export class ResolveDisputeDto {
  @ApiProperty({
    description: 'Resolution: REFUND_FULL | REFUND_PARTIAL | RELEASE_FULL',
    example: 'REFUND_FULL',
  })
  @IsString()
  @IsNotEmpty()
  resolution: string;

  @ApiPropertyOptional({
    description: 'Số tiền refund (nếu partial)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  refundAmount?: number;

  @ApiPropertyOptional({ description: 'Ghi chú resolution' })
  @IsOptional()
  @IsString()
  notes?: string;
}
