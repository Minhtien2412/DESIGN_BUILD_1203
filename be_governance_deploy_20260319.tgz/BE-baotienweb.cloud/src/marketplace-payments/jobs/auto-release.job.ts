import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { EscrowService } from '../services/escrow.service';

@Injectable()
export class AutoReleaseJob {
  private readonly logger = new Logger(AutoReleaseJob.name);

  constructor(private readonly escrowService: EscrowService) {}

  /**
   * Every 10 minutes, check for escrows due for auto-release
   * Escrows with autoReleaseAt <= now, status = HELD, no active dispute
   */
  @Cron(CronExpression.EVERY_10_MINUTES)
  async handleAutoRelease() {
    this.logger.log('Running auto-release escrow cron job...');
    try {
      const result = await this.escrowService.autoReleaseEscrows();
      this.logger.log(`Auto-release completed: processed=${result.processed}`);
    } catch (error) {
      this.logger.error('Auto-release cron failed', error);
    }
  }
}
