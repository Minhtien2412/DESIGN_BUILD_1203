import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { Roles } from '../../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../../auth/guards/roles.guard';
import { CreateDisputeDto, ResolveDisputeDto } from '../dto';
import { DisputeService } from '../services/dispute.service';

@ApiTags('Marketplace Dispute')
@Controller({ path: 'marketplace-payments/dispute', version: '1' })
export class DisputeController {
  constructor(private readonly disputeService: DisputeService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Mở dispute (customer)' })
  @ApiResponse({ status: 201, description: 'Dispute created' })
  async createDispute(
    @Body() dto: CreateDisputeDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.disputeService.createDispute(
      dto.escrowId,
      userId,
      dto.reason,
      dto.description,
    );
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Danh sách dispute' })
  @ApiResponse({ status: 200, description: 'Dispute list' })
  async listDisputes(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('status') status?: string,
  ) {
    return this.disputeService.listDisputes({ page, limit, status });
  }

  @Post(':id/resolve')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Admin giải quyết dispute' })
  @ApiResponse({ status: 200, description: 'Dispute resolved' })
  async resolveDispute(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ResolveDisputeDto,
    @CurrentUser('id') adminId: number,
  ) {
    return this.disputeService.resolveDispute(
      id,
      adminId,
      dto.resolution,
      dto.refundAmount,
      dto.notes,
    );
  }
}
