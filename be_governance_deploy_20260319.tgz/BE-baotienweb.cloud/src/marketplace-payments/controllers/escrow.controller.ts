import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { Roles } from '../../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../../auth/guards/roles.guard';
import { EscrowQueryDto, RefundEscrowDto, ReleaseEscrowDto } from '../dto';
import { EscrowService } from '../services/escrow.service';

@ApiTags('Marketplace Escrow')
@Controller({ path: 'marketplace-payments/escrow', version: '1' })
export class EscrowController {
  constructor(private readonly escrowService: EscrowService) {}

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Xem chi tiết escrow' })
  @ApiResponse({ status: 200, description: 'Escrow detail' })
  async getEscrow(@Param('id', ParseIntPipe) id: number) {
    return this.escrowService.getEscrowById(id);
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Danh sách escrow (admin)' })
  @ApiResponse({ status: 200, description: 'Escrow list' })
  async listEscrows(@Query() query: EscrowQueryDto) {
    return this.escrowService.listEscrows(query);
  }

  @Get(':id/logs')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lịch sử escrow logs' })
  @ApiResponse({ status: 200, description: 'Escrow logs' })
  async getEscrowLogs(@Param('id', ParseIntPipe) id: number) {
    return this.escrowService.getEscrowLogs(id);
  }

  @Post(':id/release')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Release escrow → chuyển tiền cho worker' })
  @ApiResponse({ status: 200, description: 'Escrow released' })
  async releaseEscrow(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ReleaseEscrowDto,
    @CurrentUser('id') userId: number,
    @CurrentUser('role') userRole: string,
  ) {
    return this.escrowService.releaseEscrow(id, userId, userRole, dto.reason);
  }

  @Post(':id/refund')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Refund escrow → hoàn tiền customer' })
  @ApiResponse({ status: 200, description: 'Escrow refunded' })
  async refundEscrow(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: RefundEscrowDto,
    @CurrentUser('id') userId: number,
    @CurrentUser('role') userRole: string,
  ) {
    return this.escrowService.refundEscrow(
      id,
      userId,
      userRole,
      dto.amount,
      dto.reason,
    );
  }

  @Post('auto-release')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Trigger auto-release thủ công (admin)' })
  @ApiResponse({ status: 200, description: 'Auto-release results' })
  async triggerAutoRelease() {
    return this.escrowService.autoReleaseEscrows();
  }
}
