import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { Roles } from '../../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../../auth/guards/roles.guard';
import { PrismaService } from '../../prisma/prisma.service';
import { CreatePromoDto, ValidatePromoDto } from '../dto';
import { PromoService } from '../services/promo.service';

@ApiTags('Marketplace Promo')
@Controller({ path: 'marketplace-payments/promo', version: '1' })
export class PromoController {
  constructor(
    private readonly promoService: PromoService,
    private readonly prisma: PrismaService,
  ) {}

  @Post('validate')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Kiểm tra mã giảm giá' })
  @ApiResponse({ status: 200, description: 'Promo validation result' })
  async validatePromo(
    @Body() dto: ValidatePromoDto,
    @CurrentUser('id') userId: number,
  ) {
    const booking = await this.prisma.booking.findUnique({
      where: { id: dto.bookingId },
      include: { offers: { where: { status: 'SELECTED' } } },
    });
    const subtotal = booking?.offers?.[0]?.price
      ? Number(booking.offers[0].price)
      : Number(booking?.estimatedBudget || 0);
    return this.promoService.validatePromo(
      dto.code,
      dto.bookingId,
      userId,
      subtotal,
    );
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Danh sách mã giảm giá active' })
  @ApiResponse({ status: 200, description: 'Active promo list' })
  async listPromos() {
    return this.promoService.listPromos();
  }

  @Post('admin/create')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Admin tạo mã giảm giá mới' })
  @ApiResponse({ status: 201, description: 'Promo created' })
  async createPromo(@Body() dto: CreatePromoDto) {
    return this.promoService.createPromo(dto);
  }
}
