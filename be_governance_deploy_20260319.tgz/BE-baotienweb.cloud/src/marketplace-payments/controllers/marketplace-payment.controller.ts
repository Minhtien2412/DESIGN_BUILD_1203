import {
    Body,
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import {
    CancelPaymentDto,
    CreateMarketplacePaymentDto,
    PaymentHistoryQueryDto,
} from '../dto';
import { MarketplacePaymentService } from '../services/marketplace-payment.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';

@ApiTags('Marketplace Payments')
@Controller({ path: 'marketplace-payments', version: '1' })
export class MarketplacePaymentController {
  constructor(
    private readonly paymentService: MarketplacePaymentService,
    private readonly gatewayService: PaymentGatewayService,
  ) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Tạo thanh toán marketplace (booking → payment)' })
  @ApiResponse({ status: 201, description: 'Payment intent created' })
  async createPayment(
    @Body() dto: CreateMarketplacePaymentDto,
    @CurrentUser('id') userId: number,
  ) {
    const payment = await this.paymentService.createPayment(dto, userId);

    // If gateway payment (non-wallet), create gateway URL
    if (dto.gateway !== 'WALLET' && payment.paymentId) {
      let gatewayResult: {
        paymentUrl: string;
        qrCodeUrl?: string;
        orderId: string;
      } | null = null;
      if (dto.gateway === 'MOMO') {
        gatewayResult = await this.gatewayService.createMomoPayment(
          payment.paymentId,
          dto.returnUrl,
        );
      } else if (dto.gateway === 'VNPAY') {
        gatewayResult = await this.gatewayService.createVnpayPayment(
          payment.paymentId,
          dto.returnUrl,
        );
      }
      return { ...payment, ...(gatewayResult || {}) };
    }

    return payment;
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Xem chi tiết payment' })
  @ApiResponse({ status: 200, description: 'Payment detail' })
  async getPayment(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.getPaymentById(id, userId);
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lịch sử thanh toán' })
  @ApiResponse({ status: 200, description: 'Payment history' })
  async getHistory(
    @Query() query: PaymentHistoryQueryDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.getPaymentHistory(userId, query);
  }

  @Post(':id/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy payment đang pending' })
  @ApiResponse({ status: 200, description: 'Payment cancelled' })
  async cancelPayment(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CancelPaymentDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.paymentService.cancelPayment(id, userId, dto.reason);
  }
}
