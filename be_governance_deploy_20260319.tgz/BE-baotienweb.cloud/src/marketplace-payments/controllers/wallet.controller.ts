import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import { Roles } from '../../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../../auth/guards/roles.guard';
import {
    TopupWalletDto,
    TransferWalletDto,
    WalletTransactionQueryDto,
    WithdrawWalletDto,
} from '../dto';
import { WalletService } from '../services/wallet.service';

@ApiTags('Marketplace Wallet')
@Controller({ path: 'marketplace-payments/wallet', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Get('balance')
  @ApiOperation({ summary: 'Xem số dư ví' })
  @ApiResponse({ status: 200, description: 'Wallet balance' })
  async getBalance(@CurrentUser('id') userId: number) {
    return this.walletService.getBalance(userId);
  }

  @Get('transactions')
  @ApiOperation({ summary: 'Lịch sử giao dịch ví' })
  @ApiResponse({ status: 200, description: 'Transaction history' })
  async getTransactions(
    @Query() query: WalletTransactionQueryDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.walletService.getTransactions(userId, query);
  }

  @Post('topup')
  @ApiOperation({ summary: 'Nạp tiền vào ví' })
  @ApiResponse({ status: 201, description: 'Topup successful' })
  async topup(@Body() dto: TopupWalletDto, @CurrentUser('id') userId: number) {
    return this.walletService.topup(userId, dto.amount, dto.method);
  }

  @Post('withdraw')
  @ApiOperation({ summary: 'Rút tiền từ ví' })
  @ApiResponse({ status: 201, description: 'Withdrawal initiated' })
  async withdraw(
    @Body() dto: WithdrawWalletDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.walletService.withdraw(userId, dto.amount, dto.bankInfo);
  }

  @Post('transfer')
  @ApiOperation({ summary: 'Chuyển tiền giữa ví' })
  @ApiResponse({ status: 201, description: 'Transfer successful' })
  async transfer(
    @Body() dto: TransferWalletDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.walletService.transfer(
      userId,
      dto.toUserId,
      dto.amount,
      dto.description,
    );
  }

  @Post('admin/adjust')
  @UseGuards(RolesGuard)
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Admin điều chỉnh số dư ví user' })
  @ApiResponse({ status: 200, description: 'Balance adjusted' })
  async adminAdjust(
    @Body() body: { userId: number; amount: number; reason: string },
    @CurrentUser('id') adminId: number,
  ) {
    return this.walletService.adminAdjust(
      body.userId,
      body.amount,
      body.reason,
      adminId,
    );
  }
}
