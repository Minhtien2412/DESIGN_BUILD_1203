import {
    Body,
    Controller,
    Headers,
    Post,
    RawBodyRequest,
    Req,
} from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { Public } from '../../common/decorators/public.decorator';
import { PaymentGatewayService } from '../services/payment-gateway.service';

@ApiTags('Marketplace Payment Gateways')
@Controller({ path: 'marketplace-payments/gateway', version: '1' })
export class PaymentGatewayController {
  constructor(private readonly gatewayService: PaymentGatewayService) {}

  // =====================================================
  // MoMo Callback (public — called by MoMo server)
  // =====================================================

  @Post('momo/callback')
  @Public()
  @ApiOperation({ summary: 'MoMo IPN callback (server-to-server)' })
  @ApiResponse({ status: 200, description: 'Callback processed' })
  async momoCallback(
    @Body() body: Record<string, any>,
    @Headers() headers: Record<string, string>,
  ) {
    return this.gatewayService.handleMomoCallback(body, headers);
  }

  // =====================================================
  // VNPay Return / IPN (public — called by VNPay server)
  // =====================================================

  @Post('vnpay/callback')
  @Public()
  @ApiOperation({ summary: 'VNPay IPN callback (server-to-server)' })
  @ApiResponse({ status: 200, description: 'Callback processed' })
  async vnpayCallback(@Body() body: Record<string, any>) {
    return this.gatewayService.handleVnpayCallback(body);
  }

  // =====================================================
  // Stripe Webhook (public — called by Stripe)
  // =====================================================

  @Post('stripe/webhook')
  @Public()
  @ApiOperation({ summary: 'Stripe webhook callback' })
  @ApiResponse({ status: 200, description: 'Webhook processed' })
  async stripeWebhook(
    @Headers('stripe-signature') signature: string,
    @Req() req: RawBodyRequest<Request>,
  ) {
    const rawBody = req.rawBody;
    if (!rawBody) {
      return { error: 'Missing raw body' };
    }
    return this.gatewayService.handleStripeWebhook(signature, rawBody);
  }
}
