import {
    Controller,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { Roles } from '../../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../../auth/guards/roles.guard';
import { InvoiceQueryDto } from '../dto';
import { InvoiceService } from '../services/invoice.service';

@ApiTags('Marketplace Invoice')
@Controller({ path: 'marketplace-payments/invoice', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class InvoiceController {
  constructor(private readonly invoiceService: InvoiceService) {}

  @Get(':id')
  @ApiOperation({ summary: 'Xem chi tiết hóa đơn' })
  @ApiResponse({ status: 200, description: 'Invoice detail' })
  async getInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.invoiceService.getInvoiceById(id);
  }

  @Get()
  @ApiOperation({ summary: 'Danh sách hóa đơn' })
  @ApiResponse({ status: 200, description: 'Invoice list' })
  async listInvoices(@Query() query: InvoiceQueryDto) {
    return this.invoiceService.listInvoices(query);
  }

  @Post(':id/issue')
  @UseGuards(RolesGuard)
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Admin phát hành hóa đơn' })
  @ApiResponse({ status: 200, description: 'Invoice issued' })
  async issueInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.invoiceService.issueInvoice(id);
  }

  @Post(':id/void')
  @UseGuards(RolesGuard)
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Admin void hóa đơn' })
  @ApiResponse({ status: 200, description: 'Invoice voided' })
  async voidInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.invoiceService.voidInvoice(id);
  }
}
