import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { EscrowAction, EscrowStatus } from '../enums';
import { WalletService } from './wallet.service';

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

@Injectable()
export class EscrowService {
  private readonly logger = new Logger(EscrowService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly walletService: WalletService,
  ) {}

  /**
   * Create escrow hold from a paid payment
   * MUST be called inside a $transaction
   */
  async createEscrowHold(tx: TxClient, payment: any) {
    const grossAmount = Number(payment.totalAmount || payment.amount);
    const platformFee = Number(payment.platformFee || 0);
    const serviceFee = Number(payment.serviceFee || 0);
    const taxAmount = Number(payment.taxAmount || 0);
    const netWorkerAmount = grossAmount - platformFee - serviceFee - taxAmount;

    // Auto-release after 72 hours by default
    const autoReleaseAt = new Date();
    autoReleaseAt.setHours(autoReleaseAt.getHours() + 72);

    const escrow = await tx.escrow.create({
      data: {
        bookingId: payment.bookingId,
        paymentId: payment.id,
        customerId: payment.userId,
        workerId: payment.workerId,
        status: 'HELD',
        grossAmount: new Prisma.Decimal(grossAmount),
        platformFee: new Prisma.Decimal(platformFee),
        serviceFee: new Prisma.Decimal(serviceFee),
        taxAmount: new Prisma.Decimal(taxAmount),
        netWorkerAmount: new Prisma.Decimal(netWorkerAmount),
        heldAt: new Date(),
        autoReleaseAt,
      },
    });

    // Log the hold action
    await tx.escrowLog.create({
      data: {
        escrowId: escrow.id,
        action: EscrowAction.HOLD,
        oldStatus: '',
        newStatus: EscrowStatus.HELD,
        amount: new Prisma.Decimal(grossAmount),
        reason: `Payment #${payment.id} succeeded`,
      },
    });

    this.logger.log(
      `Escrow #${escrow.id} created for booking #${payment.bookingId}, gross=${grossAmount}, net=${netWorkerAmount}`,
    );

    return escrow;
  }

  /**
   * Release escrow to worker
   */
  async releaseEscrow(
    escrowId: number,
    userId: number,
    userRole: string,
    reason: string,
  ) {
    const escrow = await this.prisma.escrow.findUnique({
      where: { id: escrowId },
      include: { booking: true },
    });

    if (!escrow) throw new NotFoundException('Escrow không tồn tại');

    if (escrow.status !== 'HELD') {
      throw new BadRequestException(
        `Không thể release escrow ở trạng thái ${escrow.status}`,
      );
    }

    // Only customer who owns the booking or admin can release
    if (
      userRole !== 'ADMIN' &&
      userRole !== 'SUPER_ADMIN' &&
      escrow.customerId !== userId
    ) {
      throw new BadRequestException('Bạn không có quyền release escrow này');
    }

    return this.prisma.$transaction(async (tx) => {
      const netAmount = Number(escrow.netWorkerAmount);

      // Update escrow
      const updated = await tx.escrow.update({
        where: { id: escrowId },
        data: {
          status: 'RELEASED',
          releasedAmount: escrow.netWorkerAmount,
          releasedAt: new Date(),
        },
      });

      // Credit worker wallet
      if (escrow.workerId) {
        await this.walletService.creditWallet(tx, escrow.workerId, netAmount, {
          type: 'ESCROW_RELEASE',
          bookingId: escrow.bookingId,
          paymentId: escrow.paymentId,
          escrowId: escrow.id,
          reference: `ESC-REL-${escrow.id}`,
          description: `Nhận tiền từ booking #${escrow.bookingId}`,
        });
      }

      // Update booking
      await tx.booking.update({
        where: { id: escrow.bookingId },
        data: { status: 'COMPLETED', completedAt: new Date() },
      });

      // Log
      await tx.escrowLog.create({
        data: {
          escrowId: escrow.id,
          action: EscrowAction.RELEASE,
          oldStatus: 'HELD',
          newStatus: 'RELEASED',
          amount: new Prisma.Decimal(netAmount),
          reason,
          performedByUserId: userId,
          performedByRole: userRole,
        },
      });

      this.logger.log(
        `Escrow #${escrowId} released. Worker #${escrow.workerId} +${netAmount} VND`,
      );

      return updated;
    });
  }

  /**
   * Auto-release escrow (called by cron)
   */
  async autoReleaseEscrows() {
    const now = new Date();
    const eligibleEscrows = await this.prisma.escrow.findMany({
      where: {
        status: 'HELD',
        autoReleaseAt: { lte: now },
      },
      include: { booking: true },
    });

    this.logger.log(
      `Auto-release: found ${eligibleEscrows.length} eligible escrows`,
    );

    const results = [];
    for (const escrow of eligibleEscrows) {
      try {
        await this.prisma.$transaction(async (tx) => {
          const netAmount = Number(escrow.netWorkerAmount);

          await tx.escrow.update({
            where: { id: escrow.id },
            data: {
              status: 'AUTO_RELEASED',
              releasedAmount: escrow.netWorkerAmount,
              releasedAt: new Date(),
            },
          });

          // Credit worker wallet
          if (escrow.workerId) {
            await this.walletService.creditWallet(
              tx,
              escrow.workerId,
              netAmount,
              {
                type: 'ESCROW_RELEASE',
                bookingId: escrow.bookingId,
                paymentId: escrow.paymentId,
                escrowId: escrow.id,
                reference: `ESC-AUTO-${escrow.id}`,
                description: `Auto-release từ booking #${escrow.bookingId}`,
              },
            );
          }

          // Update booking
          await tx.booking.update({
            where: { id: escrow.bookingId },
            data: { status: 'COMPLETED', completedAt: new Date() },
          });

          // Log
          await tx.escrowLog.create({
            data: {
              escrowId: escrow.id,
              action: EscrowAction.AUTO_RELEASE,
              oldStatus: 'HELD',
              newStatus: 'AUTO_RELEASED',
              amount: new Prisma.Decimal(netAmount),
              reason: `Auto-released after ${escrow.autoReleaseAt}`,
            },
          });
        });

        results.push({ escrowId: escrow.id, status: 'released' });
        this.logger.log(`Auto-released escrow #${escrow.id}`);
      } catch (err) {
        results.push({
          escrowId: escrow.id,
          status: 'error',
          error: err.message,
        });
        this.logger.error(`Failed to auto-release escrow #${escrow.id}`, err);
      }
    }

    return { processed: results.length, results };
  }

  /**
   * Refund from escrow (full or partial)
   */
  async refundEscrow(
    escrowId: number,
    userId: number,
    userRole: string,
    amount?: number,
    reason?: string,
  ) {
    const escrow = await this.prisma.escrow.findUnique({
      where: { id: escrowId },
    });

    if (!escrow) throw new NotFoundException('Escrow không tồn tại');

    if (escrow.status !== 'HELD' && escrow.status !== 'DISPUTED') {
      throw new BadRequestException(
        `Không thể refund escrow ở trạng thái ${escrow.status}`,
      );
    }

    const grossAmount = Number(escrow.grossAmount);
    const refundAmount = amount || grossAmount;

    if (refundAmount > grossAmount) {
      throw new BadRequestException(
        `Refund amount (${refundAmount}) vượt quá gross amount (${grossAmount})`,
      );
    }

    const isFullRefund = refundAmount >= grossAmount;

    return this.prisma.$transaction(async (tx) => {
      const newStatus = isFullRefund ? 'REFUNDED' : 'PARTIALLY_REFUNDED';

      // Update escrow
      const updated = await tx.escrow.update({
        where: { id: escrowId },
        data: {
          status: newStatus,
          refundAmount: new Prisma.Decimal(refundAmount),
          refundedAt: new Date(),
          releasedAmount: isFullRefund
            ? new Prisma.Decimal(0)
            : new Prisma.Decimal(grossAmount - refundAmount),
        },
      });

      // Credit customer wallet
      await this.walletService.creditWallet(
        tx,
        escrow.customerId,
        refundAmount,
        {
          type: 'ESCROW_REFUND',
          bookingId: escrow.bookingId,
          paymentId: escrow.paymentId,
          escrowId: escrow.id,
          reference: `ESC-RFND-${escrow.id}`,
          description: `Hoàn tiền từ booking #${escrow.bookingId}`,
        },
      );

      // If partial refund, release remaining to worker
      if (!isFullRefund && escrow.workerId) {
        const workerAmount = grossAmount - refundAmount;
        await this.walletService.creditWallet(
          tx,
          escrow.workerId,
          workerAmount,
          {
            type: 'ESCROW_RELEASE',
            bookingId: escrow.bookingId,
            paymentId: escrow.paymentId,
            escrowId: escrow.id,
            reference: `ESC-PREL-${escrow.id}`,
            description: `Nhận tiền (partial) từ booking #${escrow.bookingId}`,
          },
        );
      }

      // Update payment & booking
      await tx.payment.update({
        where: { id: escrow.paymentId },
        data: { status: isFullRefund ? 'REFUNDED' : 'PARTIALLY_REFUNDED' },
      });

      await tx.booking.update({
        where: { id: escrow.bookingId },
        data: { status: isFullRefund ? 'REFUNDED' : 'COMPLETED' },
      });

      // Create refund record
      await tx.bookingRefund.create({
        data: {
          paymentId: escrow.paymentId,
          escrowId: escrow.id,
          bookingId: escrow.bookingId,
          customerId: escrow.customerId,
          gateway: 'WALLET',
          type: isFullRefund ? 'FULL' : 'PARTIAL',
          status: 'SUCCESS',
          amount: new Prisma.Decimal(refundAmount),
          reason: reason || 'Admin refund',
          processedAt: new Date(),
        },
      });

      // Log
      await tx.escrowLog.create({
        data: {
          escrowId: escrow.id,
          action: isFullRefund
            ? EscrowAction.REFUND
            : EscrowAction.PARTIAL_REFUND,
          oldStatus: escrow.status,
          newStatus,
          amount: new Prisma.Decimal(refundAmount),
          reason: reason || 'Admin refund',
          performedByUserId: userId,
          performedByRole: userRole,
        },
      });

      this.logger.log(
        `Escrow #${escrowId} ${isFullRefund ? 'fully' : 'partially'} refunded: ${refundAmount} VND`,
      );

      return updated;
    });
  }

  /**
   * Get escrow by ID
   */
  async getEscrowById(escrowId: number) {
    const escrow = await this.prisma.escrow.findUnique({
      where: { id: escrowId },
      include: {
        booking: true,
        escrowLogs: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!escrow) throw new NotFoundException('Escrow không tồn tại');
    return escrow;
  }

  /**
   * List escrows with pagination
   */
  async listEscrows(query: { page?: number; limit?: number; status?: string }) {
    const page = query.page || 1;
    const limit = query.limit || 20;
    const where: any = {};
    if (query.status) where.status = query.status;

    const [data, total] = await Promise.all([
      this.prisma.escrow.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { booking: true },
      }),
      this.prisma.escrow.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Get escrow logs
   */
  async getEscrowLogs(escrowId: number) {
    const escrow = await this.prisma.escrow.findUnique({
      where: { id: escrowId },
    });
    if (!escrow) throw new NotFoundException('Escrow không tồn tại');

    return this.prisma.escrowLog.findMany({
      where: { escrowId },
      orderBy: { createdAt: 'desc' },
    });
  }
}
