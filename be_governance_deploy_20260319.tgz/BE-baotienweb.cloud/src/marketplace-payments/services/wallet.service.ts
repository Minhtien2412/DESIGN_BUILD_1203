import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

interface WalletTxInput {
  type: string;
  bookingId?: number;
  paymentId?: number;
  escrowId?: number;
  reference: string;
  description?: string;
}

@Injectable()
export class WalletService {
  private readonly logger = new Logger(WalletService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Get or create wallet for user
   */
  async getOrCreateWallet(userId: number) {
    let wallet = await this.prisma.wallet.findUnique({
      where: { userId },
    });

    if (!wallet) {
      wallet = await this.prisma.wallet.create({
        data: {
          userId,
          availableBalance: new Prisma.Decimal(0),
          heldBalance: new Prisma.Decimal(0),
          totalEarned: new Prisma.Decimal(0),
          totalSpent: new Prisma.Decimal(0),
          currency: 'VND',
        },
      });
      this.logger.log(`Created wallet for user #${userId}`);
    }

    return wallet;
  }

  /**
   * Get wallet balance
   */
  async getBalance(userId: number) {
    const wallet = await this.getOrCreateWallet(userId);
    return {
      availableBalance: Number(wallet.availableBalance),
      heldBalance: Number(wallet.heldBalance),
      totalEarned: Number(wallet.totalEarned),
      totalSpent: Number(wallet.totalSpent),
      currency: wallet.currency,
    };
  }

  /**
   * Debit wallet (inside transaction)
   */
  async debitWallet(
    tx: TxClient,
    userId: number,
    amount: number,
    input: WalletTxInput,
  ) {
    const wallet = await tx.wallet.findUnique({ where: { userId } });
    if (!wallet) throw new NotFoundException('Wallet không tồn tại');

    const available = Number(wallet.availableBalance);
    if (available < amount) {
      throw new BadRequestException('Số dư ví không đủ');
    }

    const balanceBefore = available;
    const balanceAfter = available - amount;

    await tx.wallet.update({
      where: { userId },
      data: {
        availableBalance: new Prisma.Decimal(balanceAfter),
        totalSpent: { increment: new Prisma.Decimal(amount) },
      },
    });

    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        userId,
        bookingId: input.bookingId,
        paymentId: input.paymentId,
        escrowId: input.escrowId,
        type: input.type as any,
        direction: 'DEBIT',
        amount: new Prisma.Decimal(amount),
        balanceBefore: new Prisma.Decimal(balanceBefore),
        balanceAfter: new Prisma.Decimal(balanceAfter),
        reference: input.reference,
        description: input.description,
      },
    });

    this.logger.log(`Wallet user #${userId}: -${amount} VND (${input.type})`);
  }

  /**
   * Credit wallet (inside transaction)
   */
  async creditWallet(
    tx: TxClient,
    userId: number,
    amount: number,
    input: WalletTxInput,
  ) {
    // Ensure wallet exists
    let wallet = await tx.wallet.findUnique({ where: { userId } });
    if (!wallet) {
      wallet = await tx.wallet.create({
        data: {
          userId,
          availableBalance: new Prisma.Decimal(0),
          heldBalance: new Prisma.Decimal(0),
          totalEarned: new Prisma.Decimal(0),
          totalSpent: new Prisma.Decimal(0),
          currency: 'VND',
        },
      });
    }

    const balanceBefore = Number(wallet.availableBalance);
    const balanceAfter = balanceBefore + amount;

    await tx.wallet.update({
      where: { userId },
      data: {
        availableBalance: new Prisma.Decimal(balanceAfter),
        totalEarned: { increment: new Prisma.Decimal(amount) },
      },
    });

    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        userId,
        bookingId: input.bookingId,
        paymentId: input.paymentId,
        escrowId: input.escrowId,
        type: input.type as any,
        direction: 'CREDIT',
        amount: new Prisma.Decimal(amount),
        balanceBefore: new Prisma.Decimal(balanceBefore),
        balanceAfter: new Prisma.Decimal(balanceAfter),
        reference: input.reference,
        description: input.description,
      },
    });

    this.logger.log(`Wallet user #${userId}: +${amount} VND (${input.type})`);
  }

  /**
   * Topup wallet
   */
  async topup(userId: number, amount: number, method?: string) {
    const wallet = await this.getOrCreateWallet(userId);

    return this.prisma.$transaction(async (tx) => {
      const balanceBefore = Number(wallet.availableBalance);
      const balanceAfter = balanceBefore + amount;

      await tx.wallet.update({
        where: { userId },
        data: {
          availableBalance: new Prisma.Decimal(balanceAfter),
          totalEarned: { increment: new Prisma.Decimal(amount) },
        },
      });

      await tx.walletTransaction.create({
        data: {
          walletId: wallet.id,
          userId,
          type: 'TOPUP',
          direction: 'CREDIT',
          amount: new Prisma.Decimal(amount),
          balanceBefore: new Prisma.Decimal(balanceBefore),
          balanceAfter: new Prisma.Decimal(balanceAfter),
          reference: `TOPUP-${Date.now()}`,
          description: `Nạp tiền ${method || 'manual'}`,
        },
      });

      return { balance: balanceAfter, amount, method };
    });
  }

  /**
   * Withdraw from wallet
   */
  async withdraw(userId: number, amount: number, bankInfo?: string) {
    const wallet = await this.getOrCreateWallet(userId);
    const available = Number(wallet.availableBalance);

    if (available < amount) {
      throw new BadRequestException(
        `Không đủ số dư. Hiện có ${available.toLocaleString()} VND`,
      );
    }

    return this.prisma.$transaction(async (tx) => {
      const balanceBefore = available;
      const balanceAfter = available - amount;

      await tx.wallet.update({
        where: { userId },
        data: {
          availableBalance: new Prisma.Decimal(balanceAfter),
          totalSpent: { increment: new Prisma.Decimal(amount) },
        },
      });

      await tx.walletTransaction.create({
        data: {
          walletId: wallet.id,
          userId,
          type: 'WITHDRAW',
          direction: 'DEBIT',
          amount: new Prisma.Decimal(amount),
          balanceBefore: new Prisma.Decimal(balanceBefore),
          balanceAfter: new Prisma.Decimal(balanceAfter),
          reference: `WDR-${Date.now()}`,
          description: `Rút tiền${bankInfo ? ` - ${bankInfo}` : ''}`,
          metadata: bankInfo ? { bankInfo } : undefined,
        },
      });

      return { balance: balanceAfter, withdrawn: amount };
    });
  }

  /**
   * Transfer between wallets
   */
  async transfer(
    fromUserId: number,
    toUserId: number,
    amount: number,
    description?: string,
  ) {
    if (fromUserId === toUserId) {
      throw new BadRequestException('Không thể chuyển cho chính mình');
    }

    const fromWallet = await this.getOrCreateWallet(fromUserId);
    const fromAvailable = Number(fromWallet.availableBalance);

    if (fromAvailable < amount) {
      throw new BadRequestException('Số dư không đủ');
    }

    return this.prisma.$transaction(async (tx) => {
      // Debit sender
      await this.debitWallet(tx, fromUserId, amount, {
        type: 'ADJUSTMENT',
        reference: `TRF-OUT-${Date.now()}`,
        description: description || `Chuyển tiền cho user #${toUserId}`,
      });

      // Credit receiver
      await this.creditWallet(tx, toUserId, amount, {
        type: 'ADJUSTMENT',
        reference: `TRF-IN-${Date.now()}`,
        description: description || `Nhận tiền từ user #${fromUserId}`,
      });

      return { from: fromUserId, to: toUserId, amount };
    });
  }

  /**
   * Get transaction history
   */
  async getTransactions(
    userId: number,
    query: { page?: number; limit?: number; type?: string },
  ) {
    const page = query.page || 1;
    const limit = query.limit || 20;

    const wallet = await this.getOrCreateWallet(userId);

    const where: any = { walletId: wallet.id };
    if (query.type) where.type = query.type;

    const [data, total] = await Promise.all([
      this.prisma.walletTransaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.walletTransaction.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Admin: adjust wallet balance
   */
  async adminAdjust(
    userId: number,
    amount: number,
    reason: string,
    adminId: number,
  ) {
    const wallet = await this.getOrCreateWallet(userId);
    const direction = amount >= 0 ? 'CREDIT' : 'DEBIT';
    const absAmount = Math.abs(amount);

    return this.prisma.$transaction(async (tx) => {
      const balanceBefore = Number(wallet.availableBalance);
      const balanceAfter = balanceBefore + amount;

      if (balanceAfter < 0) {
        throw new BadRequestException('Adjustment would make balance negative');
      }

      await tx.wallet.update({
        where: { userId },
        data: {
          availableBalance: new Prisma.Decimal(balanceAfter),
        },
      });

      await tx.walletTransaction.create({
        data: {
          walletId: wallet.id,
          userId,
          type: 'ADJUSTMENT',
          direction,
          amount: new Prisma.Decimal(absAmount),
          balanceBefore: new Prisma.Decimal(balanceBefore),
          balanceAfter: new Prisma.Decimal(balanceAfter),
          reference: `ADJ-${Date.now()}`,
          description: reason,
          metadata: { adminId, reason },
        },
      });

      return { userId, balanceBefore, balanceAfter, adjustment: amount };
    });
  }
}
