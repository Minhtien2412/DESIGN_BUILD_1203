import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

@Injectable()
export class InvoiceService {
  private readonly logger = new Logger(InvoiceService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Create invoice from paid payment (inside transaction)
   * Idempotent: skips if invoice already exists for this payment
   */
  async createInvoiceFromPayment(tx: TxClient, payment: any) {
    // Idempotency: check if invoice already exists for this payment
    const existing = await tx.serviceInvoice.findFirst({
      where: { paymentId: payment.id },
    });
    if (existing) {
      this.logger.warn(
        `Invoice already exists for payment #${payment.id}, skipping`,
      );
      return existing;
    }

    const invoiceNumber = await this.generateInvoiceNumber(tx);

    const subtotal = Number(payment.subtotal || payment.amount);
    const discountAmount = Number(payment.discountAmount || 0);
    const platformFee = Number(payment.platformFee || 0);
    const serviceFee = Number(payment.serviceFee || 0);
    const taxAmount = Number(payment.taxAmount || 0);
    const totalAmount = Number(payment.totalAmount || payment.amount);

    const invoice = await tx.serviceInvoice.create({
      data: {
        bookingId: payment.bookingId,
        customerId: payment.userId,
        paymentId: payment.id,
        invoiceNumber,
        status: 'PAID',
        subtotal: new Prisma.Decimal(subtotal),
        discountAmount: new Prisma.Decimal(discountAmount),
        platformFee: new Prisma.Decimal(platformFee),
        serviceFee: new Prisma.Decimal(serviceFee),
        taxAmount: new Prisma.Decimal(taxAmount),
        totalAmount: new Prisma.Decimal(totalAmount),
        paidAmount: new Prisma.Decimal(totalAmount),
        amountDue: new Prisma.Decimal(0),
        issuedAt: new Date(),
        paidAt: new Date(),
      },
    });

    // Create invoice item
    await tx.serviceInvoiceItem.create({
      data: {
        invoiceId: invoice.id,
        name: `Dịch vụ booking #${payment.bookingId}`,
        description: payment.description,
        quantity: 1,
        unitPrice: new Prisma.Decimal(subtotal),
        lineTotal: new Prisma.Decimal(subtotal),
      },
    });

    this.logger.log(
      `Invoice ${invoiceNumber} created for payment #${payment.id}`,
    );

    return invoice;
  }

  /**
   * Get invoice by ID
   */
  async getInvoiceById(invoiceId: number) {
    const invoice = await this.prisma.serviceInvoice.findUnique({
      where: { id: invoiceId },
      include: {
        items: true,
        booking: true,
        payment: true,
      },
    });

    if (!invoice) {
      throw new NotFoundException('Invoice không tồn tại');
    }

    return invoice;
  }

  /**
   * List invoices
   */
  async listInvoices(query: {
    page?: number;
    limit?: number;
    customerId?: number;
  }) {
    const page = query.page || 1;
    const limit = query.limit || 20;
    const where: any = {};
    if (query.customerId) where.customerId = query.customerId;

    const [data, total] = await Promise.all([
      this.prisma.serviceInvoice.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { items: true },
      }),
      this.prisma.serviceInvoice.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Issue a draft invoice
   */
  async issueInvoice(invoiceId: number) {
    const invoice = await this.prisma.serviceInvoice.findUnique({
      where: { id: invoiceId },
    });
    if (!invoice) throw new NotFoundException('Invoice không tồn tại');

    return this.prisma.serviceInvoice.update({
      where: { id: invoiceId },
      data: { status: 'ISSUED', issuedAt: new Date() },
    });
  }

  /**
   * Void an invoice
   */
  async voidInvoice(invoiceId: number) {
    const invoice = await this.prisma.serviceInvoice.findUnique({
      where: { id: invoiceId },
    });
    if (!invoice) throw new NotFoundException('Invoice không tồn tại');

    return this.prisma.serviceInvoice.update({
      where: { id: invoiceId },
      data: { status: 'VOID', voidedAt: new Date() },
    });
  }

  private async generateInvoiceNumber(tx: TxClient): Promise<string> {
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const count = await tx.serviceInvoice.count({
      where: {
        createdAt: {
          gte: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
        },
      },
    });
    return `INV-${dateStr}-${String(count + 1).padStart(4, '0')}`;
  }
}
