import {
    BadRequestException,
    Injectable,
    Logger
} from '@nestjs/common';
import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

@Injectable()
export class PromoService {
  private readonly logger = new Logger(PromoService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Validate promo code - check eligibility and calculate discount
   */
  async validatePromo(
    code: string,
    bookingId: number,
    customerId: number,
    subtotal: number,
  ): Promise<{ valid: boolean; discountAmount: number; message: string }> {
    const promo = await this.prisma.promoCode.findUnique({
      where: { code: code.toUpperCase() },
    });

    if (!promo) {
      throw new BadRequestException('Mã khuyến mãi không tồn tại');
    }

    if (!promo.isActive) {
      throw new BadRequestException('Mã khuyến mãi đã bị vô hiệu hóa');
    }

    const now = new Date();
    if (promo.startsAt && now < promo.startsAt) {
      throw new BadRequestException('Mã khuyến mãi chưa có hiệu lực');
    }

    if (promo.endsAt && now > promo.endsAt) {
      throw new BadRequestException('Mã khuyến mãi đã hết hạn');
    }

    if (promo.usageLimit && promo.usedCount >= promo.usageLimit) {
      throw new BadRequestException('Mã khuyến mãi đã hết lượt sử dụng');
    }

    if (promo.minOrderAmount && subtotal < Number(promo.minOrderAmount)) {
      throw new BadRequestException(
        `Đơn hàng tối thiểu ${Number(promo.minOrderAmount).toLocaleString()} VND`,
      );
    }

    // Check if customer already used this promo on this booking
    const alreadyUsed = await this.prisma.appliedPromo.findFirst({
      where: { promoCodeId: promo.id, customerId, bookingId },
    });
    if (alreadyUsed) {
      throw new BadRequestException(
        'Bạn đã sử dụng mã này cho booking này rồi',
      );
    }

    // Calculate discount
    let discountAmount = 0;
    if (promo.type === 'FIXED') {
      discountAmount = Number(promo.value);
    } else if (promo.type === 'PERCENT') {
      discountAmount = Math.round((subtotal * Number(promo.value)) / 100);
    }

    // Cap at max discount
    if (promo.maxDiscountAmount) {
      discountAmount = Math.min(
        discountAmount,
        Number(promo.maxDiscountAmount),
      );
    }

    // Cap at subtotal
    discountAmount = Math.min(discountAmount, subtotal);

    return {
      valid: true,
      discountAmount,
      message: `Giảm ${discountAmount.toLocaleString()} VND`,
    };
  }

  /**
   * Apply promo (inside transaction) - record usage
   */
  async applyPromo(
    tx: TxClient,
    code: string,
    paymentId: number,
    bookingId: number,
    customerId: number,
    discountAmount: number,
  ) {
    const promo = await tx.promoCode.findUnique({
      where: { code: code.toUpperCase() },
    });

    if (!promo) return;

    // Increment usage
    await tx.promoCode.update({
      where: { id: promo.id },
      data: { usedCount: { increment: 1 } },
    });

    // Record applied promo
    await tx.appliedPromo.create({
      data: {
        promoCodeId: promo.id,
        paymentId,
        bookingId,
        customerId,
        discountAmount: new Prisma.Decimal(discountAmount),
      },
    });

    this.logger.log(
      `Promo ${code} applied: -${discountAmount} VND on booking #${bookingId}`,
    );
  }

  /**
   * List all promo codes (admin)
   */
  async listPromos() {
    return this.prisma.promoCode.findMany({
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Create promo code (admin)
   */
  async createPromo(data: {
    code: string;
    name: string;
    type: string;
    value: number;
    minOrderAmount?: number;
    maxDiscountAmount?: number;
    usageLimit?: number;
    startsAt?: string;
    endsAt?: string;
  }) {
    const existing = await this.prisma.promoCode.findUnique({
      where: { code: data.code.toUpperCase() },
    });
    if (existing) {
      throw new BadRequestException('Mã promo đã tồn tại');
    }

    return this.prisma.promoCode.create({
      data: {
        code: data.code.toUpperCase(),
        name: data.name,
        type: data.type as any,
        value: new Prisma.Decimal(data.value),
        minOrderAmount: data.minOrderAmount
          ? new Prisma.Decimal(data.minOrderAmount)
          : null,
        maxDiscountAmount: data.maxDiscountAmount
          ? new Prisma.Decimal(data.maxDiscountAmount)
          : null,
        usageLimit: data.usageLimit || null,
        startsAt: data.startsAt ? new Date(data.startsAt) : null,
        endsAt: data.endsAt ? new Date(data.endsAt) : null,
        isActive: true,
      },
    });
  }
}
