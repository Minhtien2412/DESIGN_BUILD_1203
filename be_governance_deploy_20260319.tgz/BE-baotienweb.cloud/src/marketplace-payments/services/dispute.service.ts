import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { EscrowService } from './escrow.service';

@Injectable()
export class DisputeService {
  private readonly logger = new Logger(DisputeService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly escrowService: EscrowService,
  ) {}

  /**
   * Create dispute on an escrow
   */
  async createDispute(
    escrowId: number,
    userId: number,
    reason: string,
    description: string,
  ) {
    const escrow = await this.prisma.escrow.findUnique({
      where: { id: escrowId },
      include: { booking: true },
    });

    if (!escrow) throw new NotFoundException('Escrow không tồn tại');

    if (escrow.status !== 'HELD') {
      throw new BadRequestException(
        `Không thể mở dispute khi escrow ở trạng thái ${escrow.status}`,
      );
    }

    if (escrow.customerId !== userId) {
      throw new BadRequestException('Chỉ khách hàng mới có thể mở dispute');
    }

    return this.prisma.$transaction(async (tx) => {
      // Create dispute record
      const dispute = await tx.bookingDispute.create({
        data: {
          bookingId: escrow.bookingId,
          paymentId: escrow.paymentId,
          escrowId: escrow.id,
          customerId: escrow.customerId,
          workerId: escrow.workerId,
          status: 'OPEN',
          reason,
          description,
        },
      });

      // Update escrow to DISPUTED (blocks auto-release)
      await tx.escrow.update({
        where: { id: escrowId },
        data: {
          status: 'DISPUTED',
          disputedAt: new Date(),
          autoReleaseAt: null, // Cancel auto-release
        },
      });

      // Update booking
      await tx.booking.update({
        where: { id: escrow.bookingId },
        data: { status: 'DISPUTED' },
      });

      // Log
      await tx.escrowLog.create({
        data: {
          escrowId: escrow.id,
          action: 'DISPUTE',
          oldStatus: 'HELD',
          newStatus: 'DISPUTED',
          amount: new Prisma.Decimal(0),
          reason,
          performedByUserId: userId,
          performedByRole: 'CLIENT',
        },
      });

      this.logger.log(`Dispute #${dispute.id} created for escrow #${escrowId}`);

      return dispute;
    });
  }

  /**
   * Admin resolve dispute
   */
  async resolveDispute(
    disputeId: number,
    adminId: number,
    resolution: string,
    refundAmount?: number,
    notes?: string,
  ) {
    const dispute = await this.prisma.bookingDispute.findUnique({
      where: { id: disputeId },
      include: { escrow: true },
    });

    if (!dispute) throw new NotFoundException('Dispute không tồn tại');

    if (dispute.status !== 'OPEN' && dispute.status !== 'UNDER_REVIEW') {
      throw new BadRequestException('Dispute đã được giải quyết');
    }

    const escrow = dispute.escrow;

    switch (resolution) {
      case 'REFUND_FULL':
        await this.escrowService.refundEscrow(
          escrow.id,
          adminId,
          'ADMIN',
          undefined,
          notes || 'Dispute resolved - full refund to customer',
        );

        await this.prisma.bookingDispute.update({
          where: { id: disputeId },
          data: {
            status: 'RESOLVED_CUSTOMER',
            resolution: notes || 'Full refund to customer',
            resolvedBy: adminId,
            resolvedAt: new Date(),
          },
        });
        break;

      case 'RELEASE_FULL':
        await this.escrowService.releaseEscrow(
          escrow.id,
          adminId,
          'ADMIN',
          notes || 'Dispute resolved - released to worker',
        );

        await this.prisma.bookingDispute.update({
          where: { id: disputeId },
          data: {
            status: 'RESOLVED_WORKER',
            resolution: notes || 'Full release to worker',
            resolvedBy: adminId,
            resolvedAt: new Date(),
          },
        });
        break;

      case 'REFUND_PARTIAL':
        if (!refundAmount || refundAmount <= 0) {
          throw new BadRequestException(
            'refundAmount bắt buộc cho partial refund',
          );
        }

        await this.escrowService.refundEscrow(
          escrow.id,
          adminId,
          'ADMIN',
          refundAmount,
          notes || `Partial refund: ${refundAmount}`,
        );

        await this.prisma.bookingDispute.update({
          where: { id: disputeId },
          data: {
            status: 'PARTIAL',
            resolution:
              notes || `Partial refund ${refundAmount} VND, rest to worker`,
            resolvedBy: adminId,
            resolvedAt: new Date(),
          },
        });
        break;

      default:
        throw new BadRequestException(
          'Resolution phải là REFUND_FULL, RELEASE_FULL, hoặc REFUND_PARTIAL',
        );
    }

    this.logger.log(
      `Dispute #${disputeId} resolved: ${resolution} by admin #${adminId}`,
    );

    return this.prisma.bookingDispute.findUnique({
      where: { id: disputeId },
      include: { escrow: true },
    });
  }

  /**
   * List disputes
   */
  async listDisputes(query: {
    page?: number;
    limit?: number;
    status?: string;
  }) {
    const page = query.page || 1;
    const limit = query.limit || 20;
    const where: any = {};
    if (query.status) where.status = query.status;

    const [data, total] = await Promise.all([
      this.prisma.bookingDispute.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { escrow: true, booking: true },
      }),
      this.prisma.bookingDispute.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }
}
