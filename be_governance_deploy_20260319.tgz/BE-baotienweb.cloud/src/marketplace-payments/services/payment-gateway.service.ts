import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { MomoPaymentService } from '../../payment/momo-payment.service';
import { VnpayPaymentService } from '../../payment/vnpay-payment.service';
import { PrismaService } from '../../prisma/prisma.service';
import { MarketplacePaymentService } from './marketplace-payment.service';

@Injectable()
export class PaymentGatewayService {
  private readonly logger = new Logger(PaymentGatewayService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly configService: ConfigService,
    private readonly marketplacePayment: MarketplacePaymentService,
    private readonly momoService: MomoPaymentService,
    private readonly vnpayService: VnpayPaymentService,
  ) {}

  // =====================================================
  // MoMo Gateway
  // =====================================================

  /**
   * Create MoMo payment URL for marketplace payment
   */
  async createMomoPayment(paymentId: number, returnUrl?: string) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
    });
    if (!payment) throw new BadRequestException('Payment not found');

    const amount = Number(payment.totalAmount || payment.amount);
    const orderId = payment.referenceId!;
    const baseReturnUrl =
      returnUrl ||
      this.configService.get('MOMO_RETURN_URL') ||
      `${this.configService.get('APP_URL')}/api/v1/payment-gateway/momo/return`;
    const ipnUrl =
      this.configService.get('MOMO_IPN_URL') ||
      `${this.configService.get('APP_URL')}/api/v1/payment-gateway/momo/callback`;

    try {
      const result = await this.momoService.createPayment({
        orderId,
        amount,
        description: `Thanh toán booking - ${orderId}`,
        returnUrl: baseReturnUrl,
        ipnUrl,
      });

      // Update payment with gateway info
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: {
          status: 'PROCESSING',
          gatewayOrderId: orderId,
          metadata: {
            ...(payment.metadata as any),
            momoTransactionId: result.transactionId,
          },
        },
      });

      return {
        paymentUrl: result.paymentUrl,
        qrCodeUrl: result.qrCodeUrl,
        orderId,
      };
    } catch (err) {
      this.logger.error('MoMo payment creation failed', err);
      throw new BadRequestException(`MoMo payment failed: ${err.message}`);
    }
  }

  /**
   * Handle MoMo IPN callback
   */
  async handleMomoCallback(body: any, headers: any) {
    // Log raw callback
    const callbackLog = await this.prisma.paymentCallback.create({
      data: {
        gateway: 'MOMO',
        eventType: 'IPN',
        gatewayTransactionId: body.transId?.toString(),
        rawPayload: body,
        headers: headers || {},
        signatureValid: false,
      },
    });

    try {
      // Verify MoMo signature
      const isValid = this.verifyMomoSignature(body);
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { signatureValid: isValid },
      });

      if (!isValid) {
        this.logger.warn('MoMo IPN: Invalid signature');
        await this.prisma.paymentCallback.update({
          where: { id: callbackLog.id },
          data: { errorMessage: 'Invalid signature' },
        });
        return { resultCode: 1, message: 'Invalid signature' };
      }

      // Find payment by orderId (referenceId)
      const payment = await this.prisma.payment.findFirst({
        where: {
          OR: [
            { referenceId: body.orderId },
            { gatewayOrderId: body.orderId },
            { orderId: body.orderId },
          ],
        },
      });

      if (!payment) {
        this.logger.warn(`MoMo IPN: Payment not found for ${body.orderId}`);
        await this.prisma.paymentCallback.update({
          where: { id: callbackLog.id },
          data: { errorMessage: 'Payment not found' },
        });
        return { resultCode: 1, message: 'Payment not found' };
      }

      // Link callback to payment
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { paymentId: payment.id },
      });

      // MoMo resultCode: 0 = success
      if (body.resultCode === 0) {
        // Idempotency: already processed
        if (payment.status === 'PAID' || payment.status === 'COMPLETED') {
          await this.prisma.paymentCallback.update({
            where: { id: callbackLog.id },
            data: { processed: true, processedAt: new Date() },
          });
          return { resultCode: 0, message: 'Already processed' };
        }

        await this.marketplacePayment.handleGatewayPaymentSuccess(
          payment.id,
          body.transId?.toString(),
        );

        await this.prisma.paymentCallback.update({
          where: { id: callbackLog.id },
          data: { processed: true, processedAt: new Date() },
        });

        return { resultCode: 0, message: 'Success' };
      } else {
        await this.marketplacePayment.handleGatewayPaymentFailure(
          payment.id,
          `MoMo error: ${body.resultCode} - ${body.message}`,
        );

        await this.prisma.paymentCallback.update({
          where: { id: callbackLog.id },
          data: {
            processed: true,
            processedAt: new Date(),
            errorMessage: body.message,
          },
        });

        return { resultCode: body.resultCode, message: body.message };
      }
    } catch (err) {
      this.logger.error('MoMo IPN processing error', err);
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { errorMessage: err.message },
      });
      throw err;
    }
  }

  private verifyMomoSignature(body: any): boolean {
    const secretKey = this.configService.get('MOMO_SECRET_KEY');
    if (!secretKey) return false;

    const rawSignature = `accessKey=${this.configService.get('MOMO_ACCESS_KEY')}&amount=${body.amount}&extraData=${body.extraData}&message=${body.message}&orderId=${body.orderId}&orderInfo=${body.orderInfo}&orderType=${body.orderType}&partnerCode=${body.partnerCode}&payType=${body.payType}&requestId=${body.requestId}&responseTime=${body.responseTime}&resultCode=${body.resultCode}&transId=${body.transId}`;

    const signature = crypto
      .createHmac('sha256', secretKey)
      .update(rawSignature)
      .digest('hex');

    return signature === body.signature;
  }

  // =====================================================
  // VNPay Gateway
  // =====================================================

  /**
   * Create VNPay payment URL
   */
  async createVnpayPayment(paymentId: number, returnUrl?: string) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
    });
    if (!payment) throw new BadRequestException('Payment not found');

    const amount = Number(payment.totalAmount || payment.amount);
    const orderId = payment.referenceId!;

    try {
      const result = await this.vnpayService.createPaymentUrl({
        amount,
        orderId,
        description: `Thanh toán booking - ${orderId}`,
        returnUrl:
          returnUrl ||
          this.configService.get('VNPAY_RETURN_URL') ||
          `${this.configService.get('APP_URL')}/api/v1/payment-gateway/vnpay/callback`,
        locale: 'vn',
        bankCode: '',
      });

      await this.prisma.payment.update({
        where: { id: paymentId },
        data: {
          status: 'PROCESSING',
          gatewayOrderId: orderId,
        },
      });

      return { paymentUrl: result.paymentUrl, orderId };
    } catch (err) {
      this.logger.error('VNPay payment creation failed', err);
      throw new BadRequestException(`VNPay payment failed: ${err.message}`);
    }
  }

  /**
   * Handle VNPay callback (return URL or IPN)
   */
  async handleVnpayCallback(query: any) {
    const callbackLog = await this.prisma.paymentCallback.create({
      data: {
        gateway: 'VNPAY',
        eventType: 'RETURN',
        gatewayTransactionId: query.vnp_TransactionNo,
        rawPayload: query,
        signatureValid: false,
      },
    });

    try {
      // Verify VNPay signature
      const isValid = this.verifyVnpaySignature(query);
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { signatureValid: isValid },
      });

      if (!isValid) {
        this.logger.warn('VNPay callback: Invalid signature');
        return { RspCode: '97', Message: 'Invalid Signature' };
      }

      const orderId = query.vnp_TxnRef;
      const payment = await this.prisma.payment.findFirst({
        where: {
          OR: [
            { referenceId: orderId },
            { gatewayOrderId: orderId },
            { orderId },
          ],
        },
      });

      if (!payment) {
        this.logger.warn(`VNPay: Payment not found for ${orderId}`);
        return { RspCode: '01', Message: 'Order not found' };
      }

      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { paymentId: payment.id },
      });

      // VNPay vnp_ResponseCode: '00' = success
      if (query.vnp_ResponseCode === '00') {
        if (payment.status === 'PAID' || payment.status === 'COMPLETED') {
          await this.prisma.paymentCallback.update({
            where: { id: callbackLog.id },
            data: { processed: true, processedAt: new Date() },
          });
          return { RspCode: '00', Message: 'Already processed' };
        }

        await this.marketplacePayment.handleGatewayPaymentSuccess(
          payment.id,
          query.vnp_TransactionNo,
        );

        await this.prisma.paymentCallback.update({
          where: { id: callbackLog.id },
          data: { processed: true, processedAt: new Date() },
        });

        return { RspCode: '00', Message: 'Confirm Success' };
      } else {
        await this.marketplacePayment.handleGatewayPaymentFailure(
          payment.id,
          `VNPay error: ${query.vnp_ResponseCode}`,
        );

        return { RspCode: '00', Message: 'Payment failed' };
      }
    } catch (err) {
      this.logger.error('VNPay callback error', err);
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { errorMessage: err.message },
      });
      return { RspCode: '99', Message: 'Error' };
    }
  }

  private verifyVnpaySignature(query: any): boolean {
    const hashSecret = this.configService.get('VNPAY_HASH_SECRET');
    if (!hashSecret) return false;

    const secureHash = query.vnp_SecureHash;
    const params = { ...query };
    delete params.vnp_SecureHash;
    delete params.vnp_SecureHashType;

    const sortedKeys = Object.keys(params).sort();
    const signData = sortedKeys
      .filter((key) => params[key] != null && params[key] !== '')
      .map(
        (key) =>
          `${key}=${encodeURIComponent(params[key]).replace(/%20/g, '+')}`,
      )
      .join('&');

    const signed = crypto
      .createHmac('sha512', hashSecret)
      .update(signData)
      .digest('hex');

    return signed === secureHash;
  }

  // =====================================================
  // Stripe Webhook
  // =====================================================

  /**
   * Handle Stripe webhook for marketplace payments
   */
  async handleStripeWebhook(signature: string, rawBody: Buffer) {
    const callbackLog = await this.prisma.paymentCallback.create({
      data: {
        gateway: 'STRIPE',
        eventType: 'webhook',
        rawPayload: { raw: 'Buffer data' },
        signatureValid: false,
      },
    });

    try {
      // Import Stripe dynamically
      const Stripe = (await import('stripe')).default;
      const stripe = new Stripe(this.configService.get('STRIPE_SECRET_KEY')!, {
        apiVersion: '2025-11-17.clover' as any,
      });

      const webhookSecret = this.configService.get('STRIPE_WEBHOOK_SECRET');
      if (!webhookSecret) {
        throw new BadRequestException('STRIPE_WEBHOOK_SECRET not configured');
      }

      const event = stripe.webhooks.constructEvent(
        rawBody,
        signature,
        webhookSecret,
      );

      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: {
          signatureValid: true,
          eventType: event.type,
        },
      });

      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object as any;
        const payment = await this.prisma.payment.findFirst({
          where: {
            OR: [
              { stripePaymentId: paymentIntent.id },
              { stripePaymentIntentId: paymentIntent.id },
            ],
          },
        });

        if (payment && payment.bookingId) {
          await this.prisma.paymentCallback.update({
            where: { id: callbackLog.id },
            data: { paymentId: payment.id },
          });

          if (payment.status !== 'PAID' && payment.status !== 'COMPLETED') {
            await this.marketplacePayment.handleGatewayPaymentSuccess(
              payment.id,
              paymentIntent.id,
            );
          }
        }
      }

      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { processed: true, processedAt: new Date() },
      });

      return { received: true };
    } catch (err) {
      this.logger.error('Stripe webhook error', err);
      await this.prisma.paymentCallback.update({
        where: { id: callbackLog.id },
        data: { errorMessage: err.message },
      });
      throw err;
    }
  }
}
