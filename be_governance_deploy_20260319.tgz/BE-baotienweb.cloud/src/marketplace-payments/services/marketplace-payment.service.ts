import {
    BadRequestException,
    ConflictException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateMarketplacePaymentDto } from '../dto';
import { MarketplaceGateway } from '../enums';
import { EscrowService } from './escrow.service';
import { InvoiceService } from './invoice.service';
import { PromoService } from './promo.service';
import { WalletService } from './wallet.service';

@Injectable()
export class MarketplacePaymentService {
  private readonly logger = new Logger(MarketplacePaymentService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly escrowService: EscrowService,
    private readonly walletService: WalletService,
    private readonly promoService: PromoService,
    private readonly invoiceService: InvoiceService,
  ) {}

  /**
   * Create marketplace payment intent
   * Flow: validate booking → apply promo → create payment → route to gateway
   */
  async createPayment(dto: CreateMarketplacePaymentDto, userId: number) {
    // Idempotency check
    if (dto.idempotencyKey) {
      const existing = await this.prisma.payment.findUnique({
        where: { idempotencyKey: dto.idempotencyKey },
      });
      if (existing) {
        this.logger.log(`Idempotent payment found: ${existing.id}`);
        return this.formatPaymentResponse(existing);
      }
    }

    // 1. Load and validate booking
    const booking = await this.prisma.booking.findUnique({
      where: { id: dto.bookingId },
      include: { offers: { where: { status: 'SELECTED' } } },
    });

    if (!booking) {
      throw new NotFoundException(`Booking #${dto.bookingId} không tồn tại`);
    }

    if (booking.customerId !== userId) {
      throw new BadRequestException('Bạn không phải chủ booking này');
    }

    // Check booking hasn't been paid
    if (booking.paymentStatus === 'PAID') {
      throw new ConflictException('Booking này đã được thanh toán');
    }

    const existingPaidPayment = await this.prisma.payment.findFirst({
      where: {
        bookingId: dto.bookingId,
        status: { in: ['PAID', 'COMPLETED'] },
      },
    });
    if (existingPaidPayment) {
      throw new ConflictException('Booking này đã có payment thành công');
    }

    // 2. Calculate amounts
    const selectedOffer = booking.offers[0];
    const subtotal = selectedOffer
      ? Number(selectedOffer.price || 0)
      : Number(booking.estimatedBudget || 0);

    if (subtotal <= 0) {
      throw new BadRequestException(
        'Booking chưa có giá. Vui lòng chờ báo giá từ thợ.',
      );
    }

    // Apply promo
    let discountAmount = 0;
    if (dto.promoCode) {
      const promoResult = await this.promoService.validatePromo(
        dto.promoCode,
        dto.bookingId,
        userId,
        subtotal,
      );
      discountAmount = promoResult.discountAmount;
    }

    const platformFee = Math.round(subtotal * 0.05); // 5% platform fee
    const serviceFee = Math.round(subtotal * 0.02); // 2% service fee
    const taxAmount = Math.round((subtotal - discountAmount) * 0.1); // 10% VAT
    const totalAmount =
      subtotal - discountAmount + platformFee + serviceFee + taxAmount;

    // 3. Generate reference ID
    const referenceId = await this.generateReferenceId();

    // 4. Map gateway to PaymentMethod enum
    const paymentMethodMap: Record<string, string> = {
      WALLET: 'WALLET',
      MOMO: 'MOMO',
      VNPAY: 'VNPAY',
      STRIPE: 'STRIPE',
      ACB: 'ACB',
    };

    // 5. Create payment record in transaction
    const result = await this.prisma.$transaction(async (tx) => {
      const payment = await tx.payment.create({
        data: {
          amount: new Prisma.Decimal(totalAmount),
          currency: 'VND',
          status: 'PENDING',
          paymentMethod: paymentMethodMap[dto.gateway] as any,
          gateway: dto.gateway,
          referenceId,
          description: `Thanh toán booking #${booking.bookingCode}`,
          userId,
          bookingId: dto.bookingId,
          workerId: booking.selectedWorkerId,
          subtotal: new Prisma.Decimal(subtotal),
          discountAmount: new Prisma.Decimal(discountAmount),
          platformFee: new Prisma.Decimal(platformFee),
          serviceFee: new Prisma.Decimal(serviceFee),
          taxAmount: new Prisma.Decimal(taxAmount),
          totalAmount: new Prisma.Decimal(totalAmount),
          idempotencyKey: dto.idempotencyKey || null,
          metadata: {
            bookingCode: booking.bookingCode,
            promoCode: dto.promoCode || null,
          },
        },
      });

      // Update booking payment status
      await tx.booking.update({
        where: { id: dto.bookingId },
        data: {
          paymentStatus: 'PENDING',
          status: 'PAYMENT_PENDING',
          subtotal: new Prisma.Decimal(subtotal),
          discountAmount: new Prisma.Decimal(discountAmount),
          platformFee: new Prisma.Decimal(platformFee),
          serviceFee: new Prisma.Decimal(serviceFee),
          taxAmount: new Prisma.Decimal(taxAmount),
          totalAmount: new Prisma.Decimal(totalAmount),
        },
      });

      // Apply promo record
      if (dto.promoCode && discountAmount > 0) {
        await this.promoService.applyPromo(
          tx,
          dto.promoCode,
          payment.id,
          dto.bookingId,
          userId,
          discountAmount,
        );
      }

      return payment;
    });

    // 6. Handle wallet payment immediately
    if (dto.gateway === MarketplaceGateway.WALLET) {
      return this.processWalletPayment(result.id, userId);
    }

    // 7. For external gateways, generate payment URL
    const paymentUrl = await this.generateGatewayPaymentUrl(
      dto.gateway,
      result,
      dto.returnUrl,
    );

    return {
      paymentId: result.id,
      referenceId: result.referenceId,
      status: result.status,
      gateway: dto.gateway,
      amount: totalAmount,
      currency: 'VND',
      paymentUrl,
    };
  }

  /**
   * Process wallet payment (instant)
   */
  private async processWalletPayment(paymentId: number, userId: number) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
    });
    if (!payment) throw new NotFoundException('Payment not found');

    const totalAmount = Number(payment.totalAmount || payment.amount);

    // Check wallet balance
    const wallet = await this.walletService.getOrCreateWallet(userId);
    if (Number(wallet.availableBalance) < totalAmount) {
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: {
          status: 'FAILED',
          failureReason: 'Số dư ví không đủ',
        },
      });
      throw new BadRequestException(
        `Số dư ví không đủ. Cần ${totalAmount.toLocaleString()} VND, hiện có ${Number(wallet.availableBalance).toLocaleString()} VND`,
      );
    }

    // Process in transaction
    return this.prisma.$transaction(async (tx) => {
      // Debit wallet
      await this.walletService.debitWallet(tx, userId, totalAmount, {
        type: 'PAYMENT_HOLD',
        bookingId: payment.bookingId!,
        paymentId: payment.id,
        reference: payment.referenceId!,
        description: `Thanh toán booking #${payment.bookingId}`,
      });

      // Mark payment as PAID
      const updatedPayment = await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: 'PAID',
          paidAt: new Date(),
          callbackVerified: true,
        },
      });

      // Create escrow
      await this.escrowService.createEscrowHold(tx, updatedPayment);

      // Update booking
      await tx.booking.update({
        where: { id: payment.bookingId! },
        data: {
          paymentStatus: 'PAID',
          status: 'CONFIRMED',
          confirmedAt: new Date(),
        },
      });

      // Create invoice
      await this.invoiceService.createInvoiceFromPayment(tx, updatedPayment);

      return this.formatPaymentResponse(updatedPayment);
    });
  }

  /**
   * Handle successful gateway callback
   * Called by payment-gateway.service after signature verification
   */
  async handleGatewayPaymentSuccess(
    paymentId: number,
    gatewayTransactionId: string,
  ) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
    });

    if (!payment) throw new NotFoundException('Payment not found');

    // Idempotency: already paid
    if (payment.status === 'PAID' || payment.status === 'COMPLETED') {
      this.logger.log(`Payment #${paymentId} already processed`);
      return { success: true, message: 'Already processed' };
    }

    return this.prisma.$transaction(async (tx) => {
      const updatedPayment = await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: 'PAID',
          paidAt: new Date(),
          gatewayTransactionId,
          callbackVerified: true,
        },
      });

      // Create escrow hold
      await this.escrowService.createEscrowHold(tx, updatedPayment);

      // Update booking
      await tx.booking.update({
        where: { id: payment.bookingId! },
        data: {
          paymentStatus: 'PAID',
          status: 'CONFIRMED',
          confirmedAt: new Date(),
        },
      });

      // Create invoice
      await this.invoiceService.createInvoiceFromPayment(tx, updatedPayment);

      this.logger.log(
        `Payment #${paymentId} processed successfully via ${payment.gateway}`,
      );

      return { success: true, paymentId: updatedPayment.id };
    });
  }

  /**
   * Handle gateway payment failure
   */
  async handleGatewayPaymentFailure(paymentId: number, reason: string) {
    return this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        status: 'FAILED',
        failureReason: reason,
      },
    });
  }

  /**
   * Get payment by ID
   */
  async getPaymentById(paymentId: number, userId?: number) {
    const where: any = { id: paymentId };
    if (userId) where.userId = userId;

    const payment = await this.prisma.payment.findFirst({
      where,
      include: {
        escrow: true,
        paymentCallbacks: { orderBy: { createdAt: 'desc' }, take: 5 },
        bookingRefunds: true,
      },
    });

    if (!payment) throw new NotFoundException('Payment không tồn tại');
    return payment;
  }

  /**
   * Get payment history with pagination
   */
  async getPaymentHistory(
    userId: number,
    query: { page?: number; limit?: number; status?: string; gateway?: string },
  ) {
    const page = query.page || 1;
    const limit = query.limit || 20;

    const where: Prisma.PaymentWhereInput = { userId };
    if (query.status) where.status = query.status as any;
    if (query.gateway) where.gateway = query.gateway;

    const [data, total] = await Promise.all([
      this.prisma.payment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { escrow: true },
      }),
      this.prisma.payment.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Cancel pending payment
   */
  async cancelPayment(paymentId: number, userId: number, reason?: string) {
    const payment = await this.prisma.payment.findFirst({
      where: { id: paymentId, userId },
    });

    if (!payment) throw new NotFoundException('Payment không tồn tại');

    if (payment.status !== 'PENDING') {
      throw new BadRequestException(
        `Không thể hủy payment ở trạng thái ${payment.status}`,
      );
    }

    return this.prisma.$transaction(async (tx) => {
      const updated = await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: 'CANCELLED',
          failureReason: reason || 'Customer cancelled',
        },
      });

      if (payment.bookingId) {
        await tx.booking.update({
          where: { id: payment.bookingId },
          data: { paymentStatus: 'UNPAID', status: 'QUOTED' },
        });
      }

      return updated;
    });
  }

  // =====================================================
  // Private helpers
  // =====================================================

  private async generateReferenceId(): Promise<string> {
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const count = await this.prisma.payment.count({
      where: {
        createdAt: {
          gte: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
        },
      },
    });
    return `PAY-${dateStr}-${String(count + 1).padStart(4, '0')}`;
  }

  private async generateGatewayPaymentUrl(
    gateway: MarketplaceGateway,
    payment: any,
    returnUrl?: string,
  ): Promise<string | null> {
    // Gateway URL generation is handled by payment-gateway service
    // This returns a placeholder; the controller will call the appropriate gateway service
    return null;
  }

  private formatPaymentResponse(payment: any) {
    return {
      paymentId: payment.id,
      referenceId: payment.referenceId,
      status: payment.status,
      gateway: payment.gateway,
      amount: Number(payment.totalAmount || payment.amount),
      currency: payment.currency,
      paymentUrl: null,
    };
  }
}
