import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { PaymentModule } from '../payment/payment.module';
import { DisputeController } from './controllers/dispute.controller';
import { EscrowController } from './controllers/escrow.controller';
import { InvoiceController } from './controllers/invoice.controller';
import { MarketplacePaymentController } from './controllers/marketplace-payment.controller';
import { PaymentGatewayController } from './controllers/payment-gateway.controller';
import { PromoController } from './controllers/promo.controller';
import { WalletController } from './controllers/wallet.controller';
import { AutoReleaseJob } from './jobs/auto-release.job';
import { DisputeService } from './services/dispute.service';
import { EscrowService } from './services/escrow.service';
import { InvoiceService } from './services/invoice.service';
import { MarketplacePaymentService } from './services/marketplace-payment.service';
import { PaymentGatewayService } from './services/payment-gateway.service';
import { PromoService } from './services/promo.service';
import { WalletService } from './services/wallet.service';

@Module({
  imports: [ScheduleModule.forRoot(), PaymentModule],
  controllers: [
    PaymentGatewayController,
    EscrowController,
    WalletController,
    PromoController,
    InvoiceController,
    DisputeController,
    MarketplacePaymentController,
  ],
  providers: [
    MarketplacePaymentService,
    PaymentGatewayService,
    EscrowService,
    WalletService,
    InvoiceService,
    PromoService,
    DisputeService,
    AutoReleaseJob,
  ],
  exports: [
    MarketplacePaymentService,
    PaymentGatewayService,
    EscrowService,
    WalletService,
    InvoiceService,
    PromoService,
    DisputeService,
  ],
})
export class MarketplacePaymentsModule {}
