// =====================================================
// Marketplace Payment Enums - Centralized
// =====================================================

export enum MarketplaceGateway {
  WALLET = 'WALLET',
  MOMO = 'MOMO',
  VNPAY = 'VNPAY',
  STRIPE = 'STRIPE',
  ACB = 'ACB',
}

export enum MarketplacePaymentStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  PAID = 'PAID',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
  REFUNDED = 'REFUNDED',
  PARTIALLY_REFUNDED = 'PARTIALLY_REFUNDED',
  DISPUTED = 'DISPUTED',
}

export enum EscrowStatus {
  HELD = 'HELD',
  RELEASED = 'RELEASED',
  AUTO_RELEASED = 'AUTO_RELEASED',
  DISPUTED = 'DISPUTED',
  REFUNDED = 'REFUNDED',
  PARTIALLY_REFUNDED = 'PARTIALLY_REFUNDED',
  CANCELLED = 'CANCELLED',
}

export enum WalletTransactionType {
  TOPUP = 'TOPUP',
  PAYMENT_HOLD = 'PAYMENT_HOLD',
  PAYMENT_RELEASE = 'PAYMENT_RELEASE',
  PAYMENT_REFUND = 'PAYMENT_REFUND',
  WITHDRAW = 'WITHDRAW',
  ADJUSTMENT = 'ADJUSTMENT',
  PROMO_CREDIT = 'PROMO_CREDIT',
  ESCROW_RELEASE = 'ESCROW_RELEASE',
  ESCROW_REFUND = 'ESCROW_REFUND',
}

export enum WalletTransactionDirection {
  CREDIT = 'CREDIT',
  DEBIT = 'DEBIT',
}

export enum ServiceInvoiceStatus {
  DRAFT = 'DRAFT',
  ISSUED = 'ISSUED',
  PAID = 'PAID',
  PARTIALLY_PAID = 'PARTIALLY_PAID',
  VOID = 'VOID',
  REFUNDED = 'REFUNDED',
}

export enum BookingRefundType {
  FULL = 'FULL',
  PARTIAL = 'PARTIAL',
}

export enum BookingRefundStatus {
  PENDING = 'PENDING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
}

export enum BookingDisputeStatus {
  OPEN = 'OPEN',
  UNDER_REVIEW = 'UNDER_REVIEW',
  RESOLVED_CUSTOMER = 'RESOLVED_CUSTOMER',
  RESOLVED_WORKER = 'RESOLVED_WORKER',
  PARTIAL = 'PARTIAL',
}

export enum PromoType {
  FIXED = 'FIXED',
  PERCENT = 'PERCENT',
}

export enum EscrowAction {
  HOLD = 'HOLD',
  RELEASE = 'RELEASE',
  AUTO_RELEASE = 'AUTO_RELEASE',
  REFUND = 'REFUND',
  PARTIAL_REFUND = 'PARTIAL_REFUND',
  DISPUTE = 'DISPUTE',
  CANCEL = 'CANCEL',
}
