import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Seed marketplace-payments test data:
 * - 3 PromoCode
 * - 4 Wallet (for users 1-4)
 *
 * Run: npx ts-node src/marketplace-payments/seed/marketplace-seed.ts
 */
async function main() {
  console.log('Seeding marketplace payment data...');

  // =============================
  // 1. Promo Codes
  // =============================
  const promos = [
    {
      code: 'WELCOME50',
      name: 'Chào mừng khách mới',
      type: 'PERCENT' as const,
      value: 50,
      maxDiscountAmount: 200000,
      minOrderAmount: 500000,
      usageLimit: 100,
      usedCount: 0,
      isActive: true,
      startsAt: new Date('2025-01-01'),
      endsAt: new Date('2025-12-31'),
    },
    {
      code: 'FLAT100K',
      name: 'Giảm 100K đơn đầu',
      type: 'FIXED' as const,
      value: 100000,
      maxDiscountAmount: 100000,
      minOrderAmount: 300000,
      usageLimit: 50,
      usedCount: 0,
      isActive: true,
      startsAt: new Date('2025-01-01'),
      endsAt: new Date('2025-12-31'),
    },
    {
      code: 'VIP20',
      name: 'VIP discount 20%',
      type: 'PERCENT' as const,
      value: 20,
      maxDiscountAmount: 500000,
      minOrderAmount: 1000000,
      usageLimit: 500,
      usedCount: 0,
      isActive: true,
      startsAt: new Date('2025-01-01'),
      endsAt: new Date('2026-06-30'),
    },
  ];

  for (const promo of promos) {
    await prisma.promoCode.upsert({
      where: { code: promo.code },
      update: promo,
      create: promo,
    });
    console.log(`  ✓ PromoCode: ${promo.code}`);
  }

  // =============================
  // 2. Wallets for existing users
  // =============================
  const walletUsers = [3, 4, 5, 6];
  for (const userId of walletUsers) {
    await prisma.wallet.upsert({
      where: { userId },
      update: {},
      create: {
        userId,
        availableBalance: 500000,
        heldBalance: 0,
        totalEarned: 0,
        totalSpent: 0,
        currency: 'VND',
        isActive: true,
      },
    });
    console.log(`  ✓ Wallet for userId=${userId}`);
  }

  console.log('\n✅ Marketplace seed complete!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
