import { ApiProperty } from '@nestjs/swagger';
import { ProjectStatus } from '@prisma/client';

export class ProjectResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty({ nullable: true })
  description: string | null;

  @ApiProperty({ enum: ProjectStatus })
  status: ProjectStatus;

  @ApiProperty({ nullable: true })
  budget: number | null;

  @ApiProperty({ nullable: true })
  startDate: Date | null;

  @ApiProperty({ nullable: true })
  endDate: Date | null;

  @ApiProperty({ type: [String] })
  images: string[];

  @ApiProperty({ nullable: true })
  clientId: number | null;

  @ApiProperty({ nullable: true })
  engineerId: number | null;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;

  @ApiProperty({ required: false })
  client?: {
    id: number;
    name: string | null;
    email: string;
  };

  @ApiProperty({ required: false })
  engineer?: {
    id: number;
    name: string | null;
    email: string;
  };

  @ApiProperty({ required: false, type: [Object] })
  tasks?: any[];

  @ApiProperty({ required: false })
  _count?: {
    tasks: number;
    comments: number;
    files: number;
  };
}
