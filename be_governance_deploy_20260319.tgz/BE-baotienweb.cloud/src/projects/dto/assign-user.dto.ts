import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsNotEmpty } from 'class-validator';

export class AssignUserDto {
  @ApiProperty({
    description: 'User ID to assign',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  userId: number;
}
