import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsEnum,
  IsNumber,
  IsDateString,
  IsArray,
} from 'class-validator';
import { ProjectStatus } from '@prisma/client';

export class CreateProjectDto {
  @ApiProperty({
    description: 'Project title',
    example: 'Website Redesign Project',
  })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({
    description: 'Project description',
    example: 'Complete redesign of company website with modern UI',
    required: false,
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({
    description: 'Project status',
    enum: ProjectStatus,
    example: ProjectStatus.PLANNING,
    required: false,
  })
  @IsEnum(ProjectStatus)
  @IsOptional()
  status?: ProjectStatus;

  @ApiProperty({
    description: 'Client user ID',
    example: 1,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  clientId?: number;

  @ApiProperty({
    description: 'Engineer user ID',
    example: 2,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  engineerId?: number;

  @ApiProperty({
    description: 'Project budget',
    example: 50000,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  budget?: number;

  @ApiProperty({
    description: 'Project start date',
    example: '2025-01-01',
    required: false,
  })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({
    description: 'Project end date',
    example: '2025-06-30',
    required: false,
  })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({
    description: 'Project image URLs',
    example: ['https://example.com/image1.jpg'],
    required: false,
    type: [String],
  })
  @IsArray()
  @IsOptional()
  images?: string[];
}
