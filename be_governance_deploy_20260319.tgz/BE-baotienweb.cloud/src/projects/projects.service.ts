import {
    BadRequestException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { Role, TimelineEventType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ProgressGateway } from '../progress/progress.gateway';
import { CreateProjectDto, UpdateProjectDto } from './dto';

@Injectable()
export class ProjectsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly progressGateway: ProgressGateway,
  ) {}

  async create(createProjectDto: CreateProjectDto, userId: number) {
    const { clientId, engineerId, startDate, endDate, ...projectData } =
      createProjectDto;

    // Validate users exist and have correct roles
    if (clientId) {
      await this.validateUserRole(clientId, Role.CLIENT);
    }
    if (engineerId) {
      await this.validateUserRole(engineerId, Role.ENGINEER);
    }

    const project = await this.prisma.project.create({
      data: {
        ...projectData,
        clientId,
        engineerId,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });

    // Create timeline event
    await this.createTimelineEvent(
      project.id,
      TimelineEventType.PROJECT_CREATED,
      `Project "${project.title}" was created`,
      userId,
    );

    return project;
  }

  async findAll(filters?: {
    status?: string;
    clientId?: number;
    engineerId?: number;
  }) {
    return this.prisma.project.findMany({
      where: {
        ...(filters?.status && { status: filters.status as any }),
        ...(filters?.clientId && { clientId: filters.clientId }),
        ...(filters?.engineerId && { engineerId: filters.engineerId }),
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
        _count: {
          select: {
            tasks: true,
            comments: true,
            files: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    const project = await this.prisma.project.findUnique({
      where: { id },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
        tasks: {
          include: {
            assignee: { select: { id: true, name: true, email: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: {
          select: {
            tasks: true,
            comments: true,
            files: true,
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException(`Project with ID ${id} not found`);
    }

    return project;
  }

  async update(id: number, updateProjectDto: UpdateProjectDto, userId: number) {
    await this.findOne(id); // Check exists

    const {
      startDate,
      endDate,
      status: newStatus,
      ...updateData
    } = updateProjectDto;

    const project = await this.prisma.project.update({
      where: { id },
      data: {
        ...updateData,
        ...(startDate && { startDate: new Date(startDate) }),
        ...(endDate && { endDate: new Date(endDate) }),
        ...(newStatus && { status: newStatus }),
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });

    // Create timeline event
    if (newStatus) {
      await this.createTimelineEvent(
        id,
        TimelineEventType.STATUS_CHANGED,
        `Project status changed to ${newStatus}`,
        userId,
        { newStatus },
      );
    } else {
      await this.createTimelineEvent(
        id,
        TimelineEventType.PROJECT_UPDATED,
        `Project "${project.title}" was updated`,
        userId,
      );
    }

    // Emit real-time progress update via WebSocket
    try {
      const progress = await this.getProgress(id);
      this.progressGateway.emitProjectProgress(id, progress);
    } catch (error: unknown) {
      // Log error but don't fail the update
      console.error('Failed to emit project progress update:', error);
    }

    return project;
  }

  async remove(id: number) {
    await this.findOne(id);

    await this.prisma.project.delete({
      where: { id },
    });

    return { message: `Project with ID ${id} has been deleted` };
  }

  async assignClient(projectId: number, clientId: number, userId: number) {
    await this.findOne(projectId);
    await this.validateUserRole(clientId, Role.CLIENT);

    const project = await this.prisma.project.update({
      where: { id: projectId },
      data: { clientId },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });

    await this.createTimelineEvent(
      projectId,
      TimelineEventType.CLIENT_ASSIGNED,
      `Client ${project.client?.name || project.client?.email} was assigned`,
      userId,
      { clientId },
    );

    return project;
  }

  async assignEngineer(projectId: number, engineerId: number, userId: number) {
    await this.findOne(projectId);
    await this.validateUserRole(engineerId, Role.ENGINEER);

    const project = await this.prisma.project.update({
      where: { id: projectId },
      data: { engineerId },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });

    await this.createTimelineEvent(
      projectId,
      TimelineEventType.ENGINEER_ASSIGNED,
      `Engineer ${project.engineer?.name || project.engineer?.email} was assigned`,
      userId,
      { engineerId },
    );

    return project;
  }

  async getTimeline(projectId: number) {
    await this.findOne(projectId);

    return this.prisma.timeline.findMany({
      where: { projectId },
      include: {
        user: { select: { id: true, name: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  private async validateUserRole(userId: number, expectedRole: Role) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { role: true },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${userId} not found`);
    }

    if (user.role !== expectedRole) {
      throw new BadRequestException(
        `User must have role ${expectedRole}, but has ${user.role}`,
      );
    }
  }

  private async createTimelineEvent(
    projectId: number,
    eventType: TimelineEventType,
    description: string,
    userId?: number,
    metadata?: any,
  ) {
    await this.prisma.timeline.create({
      data: {
        projectId,
        eventType,
        description,
        userId,
        metadata: metadata || null,
      },
    });
  }

  async getProgress(id: number) {
    const project = await this.prisma.project.findUnique({
      where: { id },
      include: {
        client: { 
          select: { 
            id: true, 
            name: true, 
            email: true
          } 
        },
        engineer: { 
          select: { 
            id: true, 
            name: true, 
            email: true
          } 
        },
        tasks: {
          select: {
            id: true,
            title: true,
            status: true,
            priority: true,
            createdAt: true,
            dueDate: true,
          },
        },
        files: {
          select: { id: true }
        },
        comments: {
          select: { id: true }
        }
      },
    });

    if (!project) {
      throw new NotFoundException(`Project with ID ${id} not found`);
    }

    // Calculate task completion
    const totalTasks = project.tasks.length;
    const completedTasks = project.tasks.filter(t => t.status === 'DONE').length;
    const inProgressTasks = project.tasks.filter(t => t.status === 'IN_PROGRESS').length;
    
    const overallProgress = totalTasks > 0 
      ? Math.round(((completedTasks + (inProgressTasks * 0.5)) / totalTasks) * 100)
      : 0;

    // Calculate timeline progress
    const now = new Date();
    const startDate = project.startDate || project.createdAt;
    const endDate = project.endDate || new Date(startDate.getTime() + 90 * 24 * 60 * 60 * 1000); // Default 90 days
    
    const totalDays = Math.max(1, Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)));
    const daysElapsed = Math.max(0, Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)));
    const daysRemaining = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
    const percentTimeElapsed = Math.min(100, Math.round((daysElapsed / totalDays) * 100));

    // Calculate budget (if you have budget tracking)
    const budget = project.budget ? {
      total: Number(project.budget),
      spent: Math.round(Number(project.budget) * (overallProgress / 100)),
      remaining: Math.round(Number(project.budget) * (1 - (overallProgress / 100))),
      percentUsed: overallProgress
    } : null;

    // Create milestone summary
    const milestones = [
      {
        name: 'Planning',
        progress: totalTasks > 0 ? 100 : 50,
        completed: totalTasks > 0
      },
      {
        name: 'Development',
        progress: overallProgress,
        completed: overallProgress === 100
      },
      {
        name: 'Review & Testing',
        progress: overallProgress === 100 ? 50 : 0,
        completed: false
      }
    ];

    // Count team members
    const team = {
      totalMembers: (project.clientId ? 1 : 0) + (project.engineerId ? 1 : 0),
      engineers: project.engineerId ? 1 : 0,
      clients: project.clientId ? 1 : 0,
    };

    return {
      projectId: project.id,
      name: project.title,
      description: project.description,
      status: project.status,
      overallProgress,
      completedTasks,
      totalTasks,
      inProgressTasks,
      todoTasks: totalTasks - completedTasks - inProgressTasks,
      budget,
      timeline: {
        startDate,
        endDate,
        daysElapsed,
        daysRemaining,
        totalDays,
        percentTimeElapsed,
        isOverdue: daysRemaining < 0,
      },
      milestones,
      team,
      activity: {
        totalFiles: project.files.length,
        totalComments: project.comments.length,
      },
      client: project.client,
      engineer: project.engineer,
      lastUpdate: project.updatedAt,
    };
  }

  // ==================== STRAPI SYNC METHODS ====================

  /**
   * Find project by Strapi ID
   */
  async findByStrapiId(strapiId: string) {
    return this.prisma.project.findUnique({
      where: { strapiId },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });
  }

  /**
   * Create project from Strapi sync (without userId requirement)
   */
  async createFromStrapi(data: any) {
    return this.prisma.project.create({
      data: {
        title: data.title,
        description: data.description,
        status: data.status || 'PLANNING',
        budget: data.budget,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        images: data.images || [],
        clientId: data.clientId,
        engineerId: data.engineerId,
        strapiId: data.strapiId,
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });
  }

  /**
   * Update project from Strapi sync
   */
  async updateFromStrapi(id: number, data: any) {
    return this.prisma.project.update({
      where: { id },
      data: {
        title: data.title,
        description: data.description,
        status: data.status,
        budget: data.budget,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        images: data.images,
        clientId: data.clientId,
        engineerId: data.engineerId,
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        engineer: { select: { id: true, name: true, email: true } },
      },
    });
  }

  /**
   * Delete project by ID (without userId requirement for sync)
   */
  async removeById(id: number) {
    await this.prisma.project.delete({ where: { id } });
    return { deleted: true, id };
  }
}
