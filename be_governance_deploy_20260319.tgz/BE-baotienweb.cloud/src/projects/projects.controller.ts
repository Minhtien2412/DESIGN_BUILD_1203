import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    UseGuards,
    ValidationPipe,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators';
import { JwtAuthGuard } from '../auth/guards';
import {
    AssignUserDto,
    CreateProjectDto,
    ProjectResponseDto,
    UpdateProjectDto,
} from './dto';
import { ProjectsService } from './projects.service';

@ApiTags('Projects')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'projects', version: '1' })
export class ProjectsController {
  constructor(private readonly projectsService: ProjectsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new project' })
  @ApiBody({ type: CreateProjectDto })
  @ApiResponse({
    status: 201,
    description: 'Project created successfully',
    type: ProjectResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Invalid input' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async create(
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    createProjectDto: CreateProjectDto,
    @CurrentUser() user: any,
  ) {
    return this.projectsService.create(createProjectDto, user.id);
  }

  @Get()
  @ApiOperation({ summary: 'Get all projects with optional filters' })
  @ApiQuery({
    name: 'status',
    required: false,
    description: 'Filter by status',
  })
  @ApiQuery({ name: 'clientId', required: false, type: Number })
  @ApiQuery({ name: 'engineerId', required: false, type: Number })
  @ApiResponse({
    status: 200,
    description: 'List of projects',
    type: [ProjectResponseDto],
  })
  async findAll(
    @Query('status') status?: string,
    @Query('clientId', new ParseIntPipe({ optional: true })) clientId?: number,
    @Query('engineerId', new ParseIntPipe({ optional: true }))
    engineerId?: number,
  ) {
    return this.projectsService.findAll({ status, clientId, engineerId });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a project by ID' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiResponse({
    status: 200,
    description: 'Project found',
    type: ProjectResponseDto,
  })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async findOne(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.findOne(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a project' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiBody({ type: UpdateProjectDto })
  @ApiResponse({
    status: 200,
    description: 'Project updated successfully',
    type: ProjectResponseDto,
  })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    updateProjectDto: UpdateProjectDto,
    @CurrentUser() user: any,
  ) {
    return this.projectsService.update(id, updateProjectDto, user.id);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete a project' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiResponse({ status: 200, description: 'Project deleted successfully' })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.remove(id);
  }

  @Post(':id/assign-client')
  @ApiOperation({ summary: 'Assign a client to the project' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiBody({ type: AssignUserDto })
  @ApiResponse({
    status: 200,
    description: 'Client assigned successfully',
    type: ProjectResponseDto,
  })
  @ApiResponse({ status: 404, description: 'Project or user not found' })
  @ApiResponse({ status: 400, description: 'User is not a client' })
  async assignClient(
    @Param('id', ParseIntPipe) id: number,
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    assignUserDto: AssignUserDto,
    @CurrentUser() user: any,
  ) {
    return this.projectsService.assignClient(id, assignUserDto.userId, user.id);
  }

  @Post(':id/assign-engineer')
  @ApiOperation({ summary: 'Assign an engineer to the project' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiBody({ type: AssignUserDto })
  @ApiResponse({
    status: 200,
    description: 'Engineer assigned successfully',
    type: ProjectResponseDto,
  })
  @ApiResponse({ status: 404, description: 'Project or user not found' })
  @ApiResponse({ status: 400, description: 'User is not an engineer' })
  async assignEngineer(
    @Param('id', ParseIntPipe) id: number,
    @Body(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
    assignUserDto: AssignUserDto,
    @CurrentUser() user: any,
  ) {
    return this.projectsService.assignEngineer(
      id,
      assignUserDto.userId,
      user.id,
    );
  }

  @Get(':id/timeline')
  @ApiOperation({ summary: 'Get project timeline/activity log' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiResponse({
    status: 200,
    description: 'Project timeline',
    type: [Object],
  })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async getTimeline(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.getTimeline(id);
  }

  @Get(':id/progress')
  @ApiOperation({ summary: 'Get project progress' })
  @ApiParam({ name: 'id', description: 'Project ID', type: Number })
  @ApiResponse({
    status: 200,
    description: 'Project progress retrieved successfully',
    schema: {
      example: {
        projectId: 1,
        name: 'Project name',
        status: 'IN_PROGRESS',
        overallProgress: 45,
        completedTasks: 9,
        totalTasks: 20,
        budget: {
          total: 50000,
          spent: 22500,
          remaining: 27500,
          percentUsed: 45
        },
        timeline: {
          startDate: '2025-01-01T00:00:00.000Z',
          endDate: '2025-12-31T00:00:00.000Z',
          daysElapsed: 17,
          daysRemaining: 348,
          percentTimeElapsed: 4.66
        },
        milestones: [
          { name: 'Design Phase', progress: 100, completed: true },
          { name: 'Development', progress: 60, completed: false },
          { name: 'Testing', progress: 0, completed: false }
        ],
        team: {
          totalMembers: 5,
          engineers: 3,
          clients: 2
        },
        lastUpdate: '2025-01-17T14:20:00.000Z'
      }
    }
  })
  @ApiResponse({ status: 404, description: 'Project not found' })
  async getProjectProgress(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.getProgress(id);
  }
}
