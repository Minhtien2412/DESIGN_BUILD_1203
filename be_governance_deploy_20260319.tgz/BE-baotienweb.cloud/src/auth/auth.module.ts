import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
// DISABLED: Messaging requires prisma migrate
// import { ConversationsModule } from '../conversations/conversations.module';
import { EmailModule } from '../email/email.module';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { DeviceSessionService } from './device-session.service';
import {
    AllPermissionsGuard,
    PermissionsGuard,
} from './guards/permissions.guard';
import { OtpController } from './otp.controller';
import { OtpService } from './otp.service';
import { RbacService } from './rbac.service';
import { SessionController } from './session.controller';
import { SocialAuthController } from './social-auth.controller';
import { SocialAuthService } from './social-auth.service';
import { JwtRefreshStrategy } from './strategies/jwt-refresh.strategy';
import { JwtStrategy } from './strategies/jwt.strategy';
import { Totp2faController } from './totp-2fa.controller';
import { Totp2faService } from './totp-2fa.service';

@Module({
  imports: [
    ConfigModule,
    PassportModule,
    JwtModule.register({}), // Configuration done in strategies
    EmailModule, // Provides EmailService for OTP email delivery
    // ConversationsModule, // DISABLED: Messaging requires prisma migrate
  ],
  controllers: [
    AuthController,
    SessionController,
    Totp2faController,
    SocialAuthController,
    OtpController,
  ],
  providers: [
    AuthService,
    DeviceSessionService,
    Totp2faService,
    RbacService,
    SocialAuthService,
    OtpService,
    PermissionsGuard,
    AllPermissionsGuard,
    JwtStrategy,
    JwtRefreshStrategy,
  ],
  exports: [
    AuthService,
    DeviceSessionService,
    Totp2faService,
    RbacService,
    SocialAuthService,
    OtpService,
    PermissionsGuard,
    AllPermissionsGuard,
  ],
})
export class AuthModule {}
