/**
 * OTP Authentication Service
 * Phone/Email OTP login and registration
 *
 * @module auth/otp.service
 * @created 2026-01-22
 */

import {
    BadRequestException,
    HttpException,
    HttpStatus,
    Inject,
    Injectable,
    Logger,
    Optional,
    UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Role } from '@prisma/client';
import * as crypto from 'crypto';
import { EmailService } from '../email/email.service';
import { PrismaService } from '../prisma/prisma.service';
import { DeviceInfo, DeviceSessionService } from './device-session.service';

/**
 * OTP delivery channel
 */
export enum OtpChannel {
  SMS = 'SMS',
  EMAIL = 'EMAIL',
  WHATSAPP = 'WHATSAPP',
}

/**
 * OTP purpose
 */
export enum OtpPurpose {
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
  VERIFY_PHONE = 'VERIFY_PHONE',
  VERIFY_EMAIL = 'VERIFY_EMAIL',
  RESET_PASSWORD = 'RESET_PASSWORD',
}

/**
 * OTP provider interface for future extensions
 */
export interface OtpProvider {
  name: string;
  channel: OtpChannel;
  send(to: string, otp: string, purpose: OtpPurpose): Promise<boolean>;
  isAvailable(): Promise<boolean>;
}

/**
 * OTP record - now stored in database (OtpVerification model)
 * Kept as reference for the interface shape
 */

/**
 * Rate limiting record
 */
interface RateLimitRecord {
  count: number;
  firstRequestAt: Date;
  blockedUntil?: Date;
}

@Injectable()
export class OtpService {
  private readonly logger = new Logger(OtpService.name);

  // Rate limit still in-memory (lightweight, acceptable for single instance)
  private readonly rateLimitStore = new Map<string, RateLimitRecord>();

  // Configuration
  private readonly OTP_LENGTH = 6;
  private readonly OTP_EXPIRY_MINUTES = 5;
  private readonly MAX_OTP_ATTEMPTS = 5;
  private readonly RATE_LIMIT_WINDOW_MINUTES = 15;
  private readonly MAX_REQUESTS_PER_WINDOW = 5;
  private readonly BLOCK_DURATION_MINUTES = 30;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly deviceSessionService: DeviceSessionService,
    @Optional()
    @Inject(EmailService)
    private readonly emailService: EmailService,
  ) {
    // Cleanup expired OTPs periodically (DB-based)
    setInterval(() => this.cleanupExpiredOtps(), 5 * 60 * 1000);
  }

  /**
   * Generate and send OTP
   */
  async sendOtp(
    identifier: string,
    channel: OtpChannel,
    purpose: OtpPurpose,
  ): Promise<{
    success: boolean;
    message: string;
    expiresIn: number;
    cooldownSeconds?: number;
  }> {
    // Normalize identifier
    const normalizedId = this.normalizeIdentifier(identifier, channel);
    const storeKey = `${channel}:${normalizedId}:${purpose}`;
    const rateLimitKey = `rate:${channel}:${normalizedId}`;

    // Check rate limiting
    const rateLimit = this.checkRateLimit(rateLimitKey);
    if (rateLimit.blocked) {
      const remainingSeconds = Math.ceil(
        (rateLimit.blockedUntil!.getTime() - Date.now()) / 1000,
      );
      throw new HttpException(
        {
          message: 'Too many OTP requests. Please try again later.',
          retryAfter: remainingSeconds,
        },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    // Check if existing OTP is still valid (cooldown)
    const existingOtp = await this.prisma.otpVerification.findFirst({
      where: {
        identifier: normalizedId,
        channel,
        purpose,
        verified: false,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });
    if (existingOtp) {
      const age = Date.now() - existingOtp.createdAt.getTime();
      const cooldownMs = 60 * 1000; // 1 minute cooldown between resends
      if (age < cooldownMs) {
        const cooldownSeconds = Math.ceil((cooldownMs - age) / 1000);
        return {
          success: false,
          message: 'Please wait before requesting another OTP',
          expiresIn: 0,
          cooldownSeconds,
        };
      }
    }

    // Generate OTP
    const otp = this.generateOtp();
    const hashedOtp = this.hashOtp(otp);

    // Store OTP in database
    const expiresAt = new Date(
      Date.now() + this.OTP_EXPIRY_MINUTES * 60 * 1000,
    );

    // Delete old OTPs for same identifier/channel/purpose
    await this.prisma.otpVerification.deleteMany({
      where: { identifier: normalizedId, channel, purpose },
    });

    await this.prisma.otpVerification.create({
      data: {
        identifier: normalizedId,
        hashedOtp,
        channel,
        purpose,
        attempts: 0,
        maxAttempts: this.MAX_OTP_ATTEMPTS,
        verified: false,
        expiresAt,
      },
    });

    // Update rate limit
    this.incrementRateLimit(rateLimitKey);

    // Send OTP through appropriate channel
    const sent = await this.deliverOtp(normalizedId, otp, channel, purpose);

    if (!sent) {
      this.logger.error(`Failed to send OTP via ${channel} to ${normalizedId}`);
      return {
        success: false,
        message: 'Failed to send OTP. Please try again.',
        expiresIn: 0,
      };
    }

    // Audit log
    await this.logOtpEvent(normalizedId, channel, purpose, 'SENT');

    this.logger.log(
      `OTP sent via ${channel} to ${this.maskIdentifier(normalizedId)} for ${purpose}`,
    );

    return {
      success: true,
      message: `OTP sent to your ${channel.toLowerCase()}`,
      expiresIn: this.OTP_EXPIRY_MINUTES * 60,
    };
  }

  /**
   * Verify OTP and login/register
   */
  async verifyOtp(
    identifier: string,
    otp: string,
    channel: OtpChannel,
    purpose: OtpPurpose,
    deviceInfo?: DeviceInfo,
  ): Promise<{
    success: boolean;
    message: string;
    accessToken?: string;
    refreshToken?: string;
    sessionId?: string;
    user?: {
      id: number;
      email: string;
      name: string;
      role: string;
      isNewUser: boolean;
    };
  }> {
    const normalizedId = this.normalizeIdentifier(identifier, channel);
    const storeKey = `${channel}:${normalizedId}:${purpose}`;

    // Get stored OTP from database
    const otpRecord = await this.prisma.otpVerification.findFirst({
      where: {
        identifier: normalizedId,
        channel,
        purpose,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!otpRecord) {
      throw new BadRequestException('No OTP found. Please request a new one.');
    }

    if (otpRecord.verified) {
      throw new BadRequestException(
        'OTP already used. Please request a new one.',
      );
    }

    if (otpRecord.expiresAt < new Date()) {
      await this.prisma.otpVerification.delete({ where: { id: otpRecord.id } });
      throw new BadRequestException(
        'OTP has expired. Please request a new one.',
      );
    }

    // Check attempts
    if (otpRecord.attempts >= this.MAX_OTP_ATTEMPTS) {
      await this.prisma.otpVerification.delete({ where: { id: otpRecord.id } });
      await this.logOtpEvent(
        normalizedId,
        channel,
        purpose,
        'BLOCKED_MAX_ATTEMPTS',
      );
      throw new HttpException(
        'Too many failed attempts. Please request a new OTP.',
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    // Verify OTP
    const isValid = this.verifyOtpHash(otp, otpRecord.hashedOtp);

    if (!isValid) {
      // Increment attempts in DB
      await this.prisma.otpVerification.update({
        where: { id: otpRecord.id },
        data: { attempts: { increment: 1 } },
      });
      await this.logOtpEvent(normalizedId, channel, purpose, 'FAILED_ATTEMPT');

      const remainingAttempts = this.MAX_OTP_ATTEMPTS - otpRecord.attempts - 1;
      throw new UnauthorizedException(
        `Invalid OTP. ${remainingAttempts} attempts remaining.`,
      );
    }

    // Mark as verified in DB
    await this.prisma.otpVerification.update({
      where: { id: otpRecord.id },
      data: { verified: true },
    });

    // Audit log
    await this.logOtpEvent(normalizedId, channel, purpose, 'VERIFIED');

    // Handle based on purpose
    if (purpose === OtpPurpose.LOGIN || purpose === OtpPurpose.REGISTER) {
      return this.handleOtpAuth(normalizedId, channel, purpose, deviceInfo);
    }

    // For verification purposes, just return success
    return {
      success: true,
      message: 'OTP verified successfully',
    };
  }

  /**
   * Handle OTP-based authentication (login/register)
   */
  private async handleOtpAuth(
    identifier: string,
    channel: OtpChannel,
    purpose: OtpPurpose,
    deviceInfo?: DeviceInfo,
  ) {
    const isEmail = channel === OtpChannel.EMAIL;
    const whereClause = isEmail ? { email: identifier } : { phone: identifier };

    // Check if user exists
    let user = await this.prisma.user.findUnique({
      where: whereClause,
    });

    const isNewUser = !user;

    if (!user) {
      // Auto-register new user
      const bcrypt = await import('bcrypt');
      const randomPassword = await bcrypt.hash(
        `otp_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`,
        10,
      );

      user = await this.prisma.user.create({
        data: {
          email: isEmail
            ? identifier
            : `${identifier.replace(/\+/g, '')}@otp.local`,
          phone: isEmail ? null : identifier,
          password: randomPassword,
          name: isEmail
            ? identifier.split('@')[0]
            : `User_${identifier.slice(-4)}`,
          role: Role.CLIENT,
          emailVerified: isEmail,
        },
      });

      this.logger.log(`New user registered via OTP: ${user.email}`);
    }

    // Create session
    const tokens = await this.deviceSessionService.createSession(
      user.id,
      user.email,
      user.role,
      deviceInfo,
    );

    return {
      success: true,
      message: isNewUser ? 'Account created successfully' : 'Login successful',
      ...tokens,
      user: {
        id: user.id,
        email: user.email,
        name: user.name || '',
        role: user.role,
        isNewUser,
      },
    };
  }

  // =====================
  // OTP Generation & Verification
  // =====================

  private generateOtp(): string {
    // Cryptographically secure random OTP
    const digits = '0123456789';
    let otp = '';
    const bytes = crypto.randomBytes(this.OTP_LENGTH);
    for (let i = 0; i < this.OTP_LENGTH; i++) {
      otp += digits[bytes[i] % 10];
    }
    return otp;
  }

  private hashOtp(otp: string): string {
    return crypto.createHash('sha256').update(otp).digest('hex');
  }

  private verifyOtpHash(otp: string, hashedOtp: string): boolean {
    const hash = this.hashOtp(otp);
    return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(hashedOtp));
  }

  // =====================
  // Rate Limiting
  // =====================

  private checkRateLimit(key: string): {
    blocked: boolean;
    blockedUntil?: Date;
  } {
    const record = this.rateLimitStore.get(key);

    if (!record) {
      return { blocked: false };
    }

    // Check if blocked
    if (record.blockedUntil && record.blockedUntil > new Date()) {
      return { blocked: true, blockedUntil: record.blockedUntil };
    }

    // Check if window expired
    const windowMs = this.RATE_LIMIT_WINDOW_MINUTES * 60 * 1000;
    if (Date.now() - record.firstRequestAt.getTime() > windowMs) {
      this.rateLimitStore.delete(key);
      return { blocked: false };
    }

    // Check if limit exceeded
    if (record.count >= this.MAX_REQUESTS_PER_WINDOW) {
      const blockedUntil = new Date(
        Date.now() + this.BLOCK_DURATION_MINUTES * 60 * 1000,
      );
      record.blockedUntil = blockedUntil;
      return { blocked: true, blockedUntil };
    }

    return { blocked: false };
  }

  private incrementRateLimit(key: string): void {
    const record = this.rateLimitStore.get(key);

    if (!record) {
      this.rateLimitStore.set(key, {
        count: 1,
        firstRequestAt: new Date(),
      });
    } else {
      record.count++;
    }
  }

  // =====================
  // OTP Delivery
  // =====================

  private async deliverOtp(
    to: string,
    otp: string,
    channel: OtpChannel,
    purpose: OtpPurpose,
  ): Promise<boolean> {
    const message = this.formatOtpMessage(otp, purpose);

    switch (channel) {
      case OtpChannel.SMS:
        return this.sendSms(to, message);
      case OtpChannel.EMAIL:
        return this.sendEmail(to, 'Your OTP Code', message);
      case OtpChannel.WHATSAPP:
        return this.sendWhatsApp(to, message);
      default:
        return false;
    }
  }

  private formatOtpMessage(otp: string, purpose: OtpPurpose): string {
    const appName = this.config.get('APP_NAME', 'Design Build');
    const purposeText = {
      [OtpPurpose.LOGIN]: 'login',
      [OtpPurpose.REGISTER]: 'registration',
      [OtpPurpose.VERIFY_PHONE]: 'phone verification',
      [OtpPurpose.VERIFY_EMAIL]: 'email verification',
      [OtpPurpose.RESET_PASSWORD]: 'password reset',
    }[purpose];

    return `[${appName}] Your OTP for ${purposeText} is: ${otp}. Valid for ${this.OTP_EXPIRY_MINUTES} minutes. Do not share this code.`;
  }

  /**
   * Send SMS via GetOTP API (production) or log (dev)
   */
  private async sendSms(to: string, message: string): Promise<boolean> {
    try {
      const getotpApiKey = this.config.get('GETOTP_API_KEY');

      if (getotpApiKey) {
        // Production: Use GetOTP.dev API
        const axios = (await import('axios')).default;
        const senderName = this.config.get('GETOTP_SENDER_NAME', 'DesignBuild');
        const channel = this.config.get('GETOTP_DEFAULT_CHANNEL', 'sms');
        const codeLength = parseInt(this.config.get('GETOTP_CODE_LENGTH', '6'));

        // Extract OTP from message for GetOTP API
        const otpMatch = message.match(/is: (\d{4,8})/);
        const otpCode = otpMatch ? otpMatch[1] : '';

        const response = await axios.post(
          'https://otp.dev/api/verify',
          {
            phone: to,
            channel,
            sender: senderName,
            codeLength,
          },
          {
            headers: {
              Authorization: `Bearer ${getotpApiKey}`,
              'Content-Type': 'application/json',
            },
            timeout: 10000,
          },
        );

        this.logger.log(
          `[SMS] GetOTP sent to ${this.maskIdentifier(to)}: ${response.data.success ? 'OK' : 'FAIL'}`,
        );
        return response.data.success || response.status === 200;
      }

      // Fallback: Check for eSMS
      const esmsApiKey = this.config.get('ESMS_API_KEY');
      if (esmsApiKey) {
        const axios = (await import('axios')).default;
        const response = await axios.get(
          `http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get`,
          {
            params: {
              Phone: to,
              Content: message,
              ApiKey: esmsApiKey,
              SecretKey: this.config.get('ESMS_SECRET_KEY'),
              SmsType: this.config.get('ESMS_SMS_TYPE', '2'),
              Brandname: this.config.get('ESMS_BRAND_NAME', 'DesignBuild'),
            },
            timeout: 10000,
          },
        );
        this.logger.log(
          `[SMS] eSMS sent to ${this.maskIdentifier(to)}: Code=${response.data.CodeResult}`,
        );
        return response.data.CodeResult === '100';
      }

      // Dev fallback: just log
      this.logger.warn(
        `[SMS] No SMS provider configured. OTP for ${this.maskIdentifier(to)}: ${message}`,
      );
      return true;
    } catch (error) {
      this.logger.error(`SMS send failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Send Email via EmailService (Nodemailer/SMTP)
   */
  private async sendEmail(
    to: string,
    subject: string,
    message: string,
  ): Promise<boolean> {
    try {
      if (this.emailService) {
        // Extract OTP code from message
        const otpMatch = message.match(/is: (\d{4,8})/);
        const otpCode = otpMatch ? otpMatch[1] : message;

        // Use the formatted email template
        await this.emailService.sendEmail({
          to,
          subject: `[Design Build] ${subject}`,
          html: `
            <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px; background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb;">
              <div style="text-align: center; margin-bottom: 24px;">
                <h2 style="color: #1a1a2e; margin: 0 0 8px 0; font-size: 20px;">🔐 Mã xác thực OTP</h2>
                <p style="color: #6b7280; margin: 0; font-size: 14px;">Design Build App</p>
              </div>
              <div style="text-align: center; background: #f3f4f6; border-radius: 8px; padding: 24px; margin: 16px 0;">
                <p style="color: #374151; font-size: 14px; margin: 0 0 12px 0;">Mã xác thực của bạn là:</p>
                <div style="font-size: 36px; font-weight: bold; letter-spacing: 8px; color: #1a1a2e; font-family: 'Courier New', monospace;">${otpCode}</div>
              </div>
              <p style="color: #ef4444; font-size: 13px; text-align: center; margin: 16px 0;">
                ⚠️ Tuyệt đối KHÔNG chia sẻ mã xác thực cho bất kỳ ai dưới bất kỳ hình thức nào.
              </p>
              <p style="color: #9ca3af; font-size: 12px; text-align: center; margin: 8px 0;">
                Mã có hiệu lực trong 5 phút.
              </p>
            </div>
          `,
        });
        this.logger.log(`[Email] OTP sent to ${this.maskIdentifier(to)}`);
        return true;
      }

      // Dev fallback
      this.logger.warn(
        `[Email] No EmailService available. OTP for ${this.maskIdentifier(to)}: ${message}`,
      );
      return true;
    } catch (error) {
      this.logger.error(`Email send failed: ${error.message}`);
      return false;
    }
  }

  /**
   * Send WhatsApp (integrate with WhatsApp Business API)
   */
  private async sendWhatsApp(to: string, message: string): Promise<boolean> {
    try {
      // TODO: Integrate with WhatsApp Business API
      this.logger.log(
        `[WhatsApp] To: ${this.maskIdentifier(to)}, Message: ${message}`,
      );
      return true; // Assume success in dev
    } catch (error) {
      this.logger.error(`WhatsApp send failed: ${error.message}`);
      return false;
    }
  }

  // =====================
  // Helpers
  // =====================

  private normalizeIdentifier(identifier: string, channel: OtpChannel): string {
    if (channel === OtpChannel.EMAIL) {
      return identifier.toLowerCase().trim();
    }
    // Phone: remove spaces, ensure international format
    return identifier.replace(/\s+/g, '').trim();
  }

  private maskIdentifier(identifier: string): string {
    if (identifier.includes('@')) {
      // Email
      const [local, domain] = identifier.split('@');
      return `${local.slice(0, 2)}***@${domain}`;
    }
    // Phone
    return `${identifier.slice(0, 3)}****${identifier.slice(-3)}`;
  }

  private async cleanupExpiredOtps(): Promise<void> {
    try {
      const result = await this.prisma.otpVerification.deleteMany({
        where: { expiresAt: { lt: new Date() } },
      });
      if (result.count > 0) {
        this.logger.log(
          `Cleaned up ${result.count} expired OTPs from database`,
        );
      }
    } catch (error) {
      this.logger.error(`OTP cleanup failed: ${error.message}`);
    }
  }

  /**
   * Audit logging for OTP events
   */
  private async logOtpEvent(
    identifier: string,
    channel: OtpChannel,
    purpose: OtpPurpose,
    event: 'SENT' | 'VERIFIED' | 'FAILED_ATTEMPT' | 'BLOCKED_MAX_ATTEMPTS',
  ): Promise<void> {
    this.logger.log(
      `[OTP_AUDIT] ${event} - Channel: ${channel}, Purpose: ${purpose}, Identifier: ${this.maskIdentifier(identifier)}`,
    );

    // TODO: Store in database for compliance/audit
    // await this.prisma.otpAuditLog.create({
    //   data: { identifier: this.hashOtp(identifier), channel, purpose, event, timestamp: new Date() }
    // });
  }
}
