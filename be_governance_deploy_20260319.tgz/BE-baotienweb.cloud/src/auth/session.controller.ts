import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import type { Request } from 'express';

import { CurrentUser } from './decorators';
import { DeviceSessionService } from './device-session.service';
import { JwtAuthGuard } from './guards/jwt-auth.guard';

interface RequestWithUser extends Request {
  user: { id: number; email: string; role: string };
}

@ApiTags('Sessions')
@Controller('auth/sessions')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class SessionController {
  constructor(private readonly deviceSessionService: DeviceSessionService) {}

  @Get()
  @ApiOperation({ summary: 'Get all active sessions for current user' })
  @ApiResponse({ status: 200, description: 'List of active sessions' })
  async getActiveSessions(@CurrentUser('id') userId: number) {
    const sessions = await this.deviceSessionService.getUserSessions(userId);

    return {
      success: true,
      data: sessions.map((session) => ({
        ...session,
        isCurrent: false, // Will be set by frontend based on current sessionId
      })),
      count: sessions.length,
    };
  }

  @Delete(':sessionId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Revoke a specific session (logout from device)' })
  @ApiResponse({ status: 200, description: 'Session revoked successfully' })
  async revokeSession(
    @CurrentUser('id') userId: number,
    @Param('sessionId') sessionId: string,
  ) {
    // First verify the session belongs to the user
    const sessions = await this.deviceSessionService.getUserSessions(userId);
    const session = sessions.find((s) => s.id === sessionId);

    if (!session) {
      return {
        success: false,
        message: 'Session not found or already revoked',
      };
    }

    await this.deviceSessionService.revokeSession(
      sessionId,
      'User revoked session',
    );

    return {
      success: true,
      message: 'Session revoked successfully',
    };
  }

  @Delete()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Revoke all sessions except current' })
  @ApiResponse({ status: 200, description: 'All other sessions revoked' })
  async revokeAllOtherSessions(
    @CurrentUser('id') userId: number,
    @Req() req: RequestWithUser,
    @Body() body: { currentSessionId?: string },
  ) {
    const count = await this.deviceSessionService.revokeAllUserSessions(
      userId,
      'User revoked all other sessions',
      body.currentSessionId,
    );

    return {
      success: true,
      message: `${count} session(s) revoked`,
      revokedCount: count,
    };
  }

  @Post('revoke-all')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Revoke all sessions (logout from all devices)' })
  @ApiResponse({ status: 200, description: 'All sessions revoked' })
  async revokeAllSessions(@CurrentUser('id') userId: number) {
    const count = await this.deviceSessionService.revokeAllUserSessions(
      userId,
      'User logged out from all devices',
    );

    return {
      success: true,
      message: `All ${count} session(s) revoked`,
      revokedCount: count,
    };
  }
}
