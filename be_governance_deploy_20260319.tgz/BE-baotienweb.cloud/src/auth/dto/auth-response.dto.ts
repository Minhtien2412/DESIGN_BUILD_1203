import { ApiProperty } from '@nestjs/swagger';
import { Role } from '@prisma/client';

export class TokensDto {
  @ApiProperty({
    description: 'JWT access token',
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
  })
  accessToken: string;

  @ApiProperty({
    description: 'JWT refresh token',
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
  })
  refreshToken: string;
}

export class AuthResponseDto extends TokensDto {
  @ApiProperty({
    description: 'User information',
  })
  user: {
    id: number;
    email: string;
    name: string | null;
    role: Role;
  };
}
