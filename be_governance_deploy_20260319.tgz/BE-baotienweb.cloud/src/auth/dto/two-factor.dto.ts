import { ApiProperty } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import {
    IsEmail,
    IsEnum,
    IsNotEmpty,
    IsOptional,
    IsString,
    MinLength,
} from 'class-validator';

// ===== REGISTRATION 2FA DTOs =====

/**
 * Step 1: Send registration OTP to email
 */
export class SendRegistrationOtpDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Email để đăng ký tài khoản',
  })
  @IsEmail({}, { message: 'Email không hợp lệ' })
  @IsNotEmpty({ message: 'Email không được để trống' })
  email: string;
}

/**
 * Step 2: Verify OTP and complete registration
 */
export class VerifyRegistrationOtpDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Email đăng ký',
  })
  @IsEmail({}, { message: 'Email không hợp lệ' })
  @IsNotEmpty({ message: 'Email không được để trống' })
  email: string;

  @ApiProperty({
    example: '123456',
    description: 'Mã OTP 6 số gửi qua email',
  })
  @IsString()
  @IsNotEmpty({ message: 'Mã OTP không được để trống' })
  otp: string;

  @ApiProperty({
    example: 'MyPassword123!',
    description: 'Mật khẩu (ít nhất 6 ký tự)',
  })
  @IsString()
  @MinLength(6, { message: 'Mật khẩu phải có ít nhất 6 ký tự' })
  @IsNotEmpty({ message: 'Mật khẩu không được để trống' })
  password: string;

  @ApiProperty({
    example: 'Nguyễn Văn A',
    description: 'Tên người dùng',
    required: false,
  })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiProperty({
    description: 'Vai trò người dùng',
    enum: Role,
    example: Role.CLIENT,
    required: false,
  })
  @IsEnum(Role)
  @IsOptional()
  role?: Role;
}

// ===== LOGIN 2FA DTOs =====

/**
 * Step 1: Login với email/password và yêu cầu gửi OTP
 */
export class LoginRequestOtpDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Email đăng nhập',
  })
  @IsEmail({}, { message: 'Email không hợp lệ' })
  @IsNotEmpty({ message: 'Email không được để trống' })
  email: string;

  @ApiProperty({
    example: 'MyPassword123!',
    description: 'Mật khẩu',
  })
  @IsString()
  @IsNotEmpty({ message: 'Mật khẩu không được để trống' })
  password: string;
}

/**
 * Step 2: Verify login OTP
 */
export class VerifyLoginOtpDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Email đăng nhập',
  })
  @IsEmail({}, { message: 'Email không hợp lệ' })
  @IsNotEmpty({ message: 'Email không được để trống' })
  email: string;

  @ApiProperty({
    example: '123456',
    description: 'Mã OTP 6 số gửi qua email',
  })
  @IsString()
  @IsNotEmpty({ message: 'Mã OTP không được để trống' })
  otp: string;

  @ApiProperty({
    example: 'temp_token_from_step1',
    description: 'Token tạm thời từ bước xác thực mật khẩu',
  })
  @IsString()
  @IsNotEmpty({ message: 'Token không được để trống' })
  tempToken: string;
}

// ===== RESPONSE DTOs =====

export class OtpSentResponseDto {
  @ApiProperty({ example: true })
  success: boolean;

  @ApiProperty({ example: 'Mã OTP đã được gửi đến email của bạn' })
  message: string;

  @ApiProperty({
    example: 'temp_token_for_verification',
    required: false,
    description: 'Token tạm thời (chỉ cho login 2FA)',
  })
  tempToken?: string;
}

export class TwoFactorAuthResponseDto {
  @ApiProperty({ example: true })
  success: boolean;

  @ApiProperty({ example: 'Đăng ký thành công' })
  message: string;

  @ApiProperty({ example: 'eyJhbGciOiJIUzI1...' })
  accessToken: string;

  @ApiProperty({ example: 'eyJhbGciOiJIUzI1...' })
  refreshToken: string;

  @ApiProperty({
    example: {
      id: 1,
      email: 'user@example.com',
      name: 'Nguyễn Văn A',
      role: 'CLIENT',
    },
  })
  user: {
    id: number;
    email: string;
    name: string | null;
    role: string;
  };
}
