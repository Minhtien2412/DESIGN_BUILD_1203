/**
 * Social Authentication Controller
 * REST API endpoints for social login and account linking
 *
 * @module auth/social-auth.controller
 * @created 2026-01-22
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    Headers,
    HttpCode,
    HttpStatus,
    Param,
    Post,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiParam,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import {
    SocialAuthService,
    SocialProvider
} from './social-auth.service';

// =====================
// DTOs
// =====================

class SocialLoginDto {
  /**
   * OAuth provider
   * @example 'GOOGLE'
   */
  provider: SocialProvider;

  /**
   * OAuth access/ID token from provider
   * @example 'eyJhbGciOiJSUzI1NiIsInR5cCI6...'
   */
  token: string;
}

class LinkProviderDto {
  /**
   * OAuth access/ID token from provider
   * @example 'eyJhbGciOiJSUzI1NiIsInR5cCI6...'
   */
  token: string;
}

// =====================
// Controller
// =====================

@ApiTags('Social Auth')
@Controller('auth/social')
export class SocialAuthController {
  constructor(private readonly socialAuthService: SocialAuthService) {}

  /**
   * Login or register with social provider
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Social Login',
    description:
      'Authenticate using Google, Facebook, or Zalo. Creates account if first time.',
  })
  @ApiBody({ type: SocialLoginDto })
  @ApiResponse({
    status: 200,
    description: 'Login successful',
    schema: {
      type: 'object',
      properties: {
        accessToken: { type: 'string' },
        refreshToken: { type: 'string' },
        sessionId: { type: 'string' },
        expiresIn: { type: 'number' },
        user: {
          type: 'object',
          properties: {
            id: { type: 'number' },
            email: { type: 'string' },
            name: { type: 'string' },
            role: { type: 'string' },
            picture: { type: 'string' },
            linkedProviders: {
              type: 'array',
              items: { type: 'string' },
            },
            isNewUser: { type: 'boolean' },
          },
        },
      },
    },
  })
  @ApiResponse({ status: 401, description: 'Invalid token' })
  async socialLogin(
    @Body() body: SocialLoginDto,
    @Headers('user-agent') userAgent: string,
    @Headers('x-forwarded-for') forwardedFor: string,
    @Req() req: any,
  ) {
    // Verify token with provider
    const profile = await this.socialAuthService.verifyProviderToken(
      body.provider,
      body.token,
    );

    // Device info for session tracking
    const deviceInfo = {
      userAgent,
      ipAddress: forwardedFor || req.ip,
      deviceName: this.parseDeviceName(userAgent),
    };

    // Authenticate (login or create account)
    return this.socialAuthService.authenticateWithProvider(profile, deviceInfo);
  }

  /**
   * Link a social provider to existing account
   */
  @Post('link/:provider')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Link Social Provider',
    description: 'Link Google/Facebook/Zalo to existing account',
  })
  @ApiParam({
    name: 'provider',
    enum: SocialProvider,
    description: 'Provider to link',
  })
  @ApiBody({ type: LinkProviderDto })
  @ApiResponse({
    status: 200,
    description: 'Provider linked successfully',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean' },
        linkedProviders: {
          type: 'array',
          items: { type: 'string' },
        },
        message: { type: 'string' },
      },
    },
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 409, description: 'Provider already linked' })
  async linkProvider(
    @Param('provider') provider: SocialProvider,
    @Body() body: LinkProviderDto,
    @Req() req: any,
  ) {
    const userId = req.user.id;

    // Verify token with provider
    const profile = await this.socialAuthService.verifyProviderToken(
      provider,
      body.token,
    );

    // Link to user account
    return this.socialAuthService.linkProviderToUser(userId, profile);
  }

  /**
   * Unlink a social provider from account
   */
  @Delete('link/:provider')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Unlink Social Provider',
    description: 'Remove linked Google/Facebook/Zalo from account',
  })
  @ApiParam({
    name: 'provider',
    enum: SocialProvider,
    description: 'Provider to unlink',
  })
  @ApiResponse({
    status: 200,
    description: 'Provider unlinked successfully',
  })
  @ApiResponse({
    status: 400,
    description: 'Cannot unlink only auth method',
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 404, description: 'Provider not linked' })
  async unlinkProvider(
    @Param('provider') provider: SocialProvider,
    @Req() req: any,
  ) {
    const userId = req.user.id;
    return this.socialAuthService.unlinkProvider(userId, provider);
  }

  /**
   * Get linked social accounts
   */
  @Get('accounts')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Get Linked Accounts',
    description: 'List all social providers linked to account',
  })
  @ApiResponse({
    status: 200,
    description: 'List of linked accounts',
    schema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          provider: { type: 'string' },
          email: { type: 'string' },
          name: { type: 'string' },
          picture: { type: 'string' },
          linkedAt: { type: 'string', format: 'date-time' },
          lastUsedAt: { type: 'string', format: 'date-time' },
        },
      },
    },
  })
  async getLinkedAccounts(@Req() req: any) {
    const userId = req.user.id;
    return this.socialAuthService.getLinkedAccounts(userId);
  }

  // =====================
  // Helper Methods
  // =====================

  private parseDeviceName(userAgent?: string): string {
    if (!userAgent) return 'Unknown Device';

    if (userAgent.includes('iPhone')) return 'iPhone';
    if (userAgent.includes('iPad')) return 'iPad';
    if (userAgent.includes('Android')) return 'Android Device';
    if (userAgent.includes('Windows')) return 'Windows PC';
    if (userAgent.includes('Macintosh')) return 'Mac';
    if (userAgent.includes('Linux')) return 'Linux PC';

    return 'Unknown Device';
  }
}
