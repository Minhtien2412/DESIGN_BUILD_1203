/**
 * TOTP 2FA Service
 * Provides Two-Factor Authentication using Time-based One-Time Passwords (TOTP)
 *
 * Features:
 * - TOTP secret generation with QR code
 * - Enable/disable 2FA with verification
 * - TOTP verification during login
 * - Backup/recovery codes
 * - Rate limiting for verification attempts
 */

import {
    BadRequestException,
    ConflictException,
    Injectable,
    Logger,
    UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import * as qrcode from 'qrcode';
import * as speakeasy from 'speakeasy';

import { PrismaService } from '../prisma/prisma.service';

export interface TotpSetupResponse {
  secret: string;
  otpAuthUrl: string;
  qrCodeDataUrl: string;
  backupCodes: string[];
}

export interface TotpVerifyResponse {
  success: boolean;
  message: string;
  remainingAttempts?: number;
}

export interface TotpStatusResponse {
  enabled: boolean;
  enabledAt?: Date;
  backupCodesRemaining?: number;
}

// Rate limiting for verification attempts
const VERIFICATION_ATTEMPTS: Map<
  number,
  { count: number; lastAttempt: Date; lockedUntil?: Date }
> = new Map();
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const ATTEMPT_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

@Injectable()
export class Totp2faService {
  private readonly logger = new Logger(Totp2faService.name);
  private readonly appName: string;
  private readonly issuer: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.appName = this.config.get('APP_NAME') || 'BaoTienApp';
    this.issuer = this.config.get('TOTP_ISSUER') || 'BaoTienWeb';
  }

  /**
   * Generate a new TOTP secret and QR code for setup
   * This doesn't enable 2FA yet - user must verify first
   */
  async generateSecret(userId: number): Promise<TotpSetupResponse> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { email: true, twoFactorSecret: true, twoFactorEnabled: true },
    });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    if (user.twoFactorEnabled) {
      throw new ConflictException(
        '2FA is already enabled. Disable it first to regenerate.',
      );
    }

    // Generate secret
    const secret = speakeasy.generateSecret({
      length: 20,
      name: `${this.appName}:${user.email}`,
      issuer: this.issuer,
    });

    // Generate backup codes
    const backupCodes = this.generateBackupCodes(8);

    // Store pending secret (not enabled yet)
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFactorSecret: this.encrypt(secret.base32),
        twoFactorBackupCodes: backupCodes.map((code) =>
          this.hashBackupCode(code),
        ),
        twoFactorEnabled: false,
      },
    });

    // Generate QR code
    const qrCodeDataUrl = await qrcode.toDataURL(secret.otpauth_url!);

    this.logger.log(`Generated new TOTP secret for user ${userId}`);

    return {
      secret: secret.base32,
      otpAuthUrl: secret.otpauth_url!,
      qrCodeDataUrl,
      backupCodes, // Return plain codes only once during setup
    };
  }

  /**
   * Verify TOTP code and enable 2FA
   */
  async enableTotp(userId: number, code: string): Promise<TotpVerifyResponse> {
    // Check rate limiting
    this.checkRateLimiting(userId);

    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { twoFactorSecret: true, twoFactorEnabled: true },
    });

    if (!user || !user.twoFactorSecret) {
      throw new BadRequestException(
        'TOTP not set up. Call generateSecret first.',
      );
    }

    if (user.twoFactorEnabled) {
      throw new ConflictException('2FA is already enabled');
    }

    const decryptedSecret = this.decrypt(user.twoFactorSecret);

    // Verify the code
    const verified = speakeasy.totp.verify({
      secret: decryptedSecret,
      encoding: 'base32',
      token: code,
      window: 1, // Allow 1 period before/after for clock drift
    });

    if (!verified) {
      this.recordFailedAttempt(userId);
      const remaining = this.getRemainingAttempts(userId);

      return {
        success: false,
        message: 'Invalid verification code',
        remainingAttempts: remaining,
      };
    }

    // Enable 2FA
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFactorEnabled: true,
      },
    });

    // Clear rate limiting on success
    VERIFICATION_ATTEMPTS.delete(userId);

    this.logger.log(`2FA enabled for user ${userId}`);

    return {
      success: true,
      message: '2FA has been enabled successfully',
    };
  }

  /**
   * Verify TOTP code during login
   */
  async verifyTotp(userId: number, code: string): Promise<TotpVerifyResponse> {
    // Check rate limiting
    this.checkRateLimiting(userId);

    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        twoFactorSecret: true,
        twoFactorEnabled: true,
        twoFactorBackupCodes: true,
      },
    });

    if (!user || !user.twoFactorEnabled || !user.twoFactorSecret) {
      throw new BadRequestException('2FA is not enabled for this user');
    }

    const decryptedSecret = this.decrypt(user.twoFactorSecret);

    // First try TOTP code
    const verified = speakeasy.totp.verify({
      secret: decryptedSecret,
      encoding: 'base32',
      token: code,
      window: 1,
    });

    if (verified) {
      VERIFICATION_ATTEMPTS.delete(userId);
      return {
        success: true,
        message: 'Verification successful',
      };
    }

    // Try backup code
    const backupCodes = (user.twoFactorBackupCodes as string[]) || [];
    const hashedInput = this.hashBackupCode(code.toUpperCase());
    const backupCodeIndex = backupCodes.findIndex((bc) => bc === hashedInput);

    if (backupCodeIndex !== -1) {
      // Remove used backup code
      const updatedCodes = [...backupCodes];
      updatedCodes.splice(backupCodeIndex, 1);

      await this.prisma.user.update({
        where: { id: userId },
        data: { twoFactorBackupCodes: updatedCodes },
      });

      VERIFICATION_ATTEMPTS.delete(userId);

      this.logger.warn(
        `Backup code used for user ${userId}. ${updatedCodes.length} codes remaining.`,
      );

      return {
        success: true,
        message: `Backup code accepted. ${updatedCodes.length} backup codes remaining.`,
      };
    }

    // Failed attempt
    this.recordFailedAttempt(userId);
    const remaining = this.getRemainingAttempts(userId);

    return {
      success: false,
      message: 'Invalid verification code',
      remainingAttempts: remaining,
    };
  }

  /**
   * Disable 2FA (requires current TOTP code or password verification)
   */
  async disableTotp(
    userId: number,
    code: string,
  ): Promise<{ success: boolean; message: string }> {
    // First verify the code
    const verifyResult = await this.verifyTotp(userId, code);

    if (!verifyResult.success) {
      throw new UnauthorizedException(
        'Invalid verification code. Cannot disable 2FA.',
      );
    }

    // Disable 2FA
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFactorSecret: null,
        twoFactorEnabled: false,
        twoFactorBackupCodes: [],
      },
    });

    this.logger.log(`2FA disabled for user ${userId}`);

    return {
      success: true,
      message: '2FA has been disabled',
    };
  }

  /**
   * Get 2FA status for a user
   */
  async getStatus(userId: number): Promise<TotpStatusResponse> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        twoFactorEnabled: true,
        twoFactorBackupCodes: true,
      },
    });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    const backupCodes = (user.twoFactorBackupCodes as string[]) || [];

    return {
      enabled: user.twoFactorEnabled,
      backupCodesRemaining: user.twoFactorEnabled
        ? backupCodes.length
        : undefined,
    };
  }

  /**
   * Regenerate backup codes (requires current TOTP code)
   */
  async regenerateBackupCodes(
    userId: number,
    code: string,
  ): Promise<{ success: boolean; backupCodes?: string[] }> {
    // Verify current code
    const verifyResult = await this.verifyTotp(userId, code);

    if (!verifyResult.success) {
      throw new UnauthorizedException('Invalid verification code');
    }

    // Generate new backup codes
    const backupCodes = this.generateBackupCodes(8);

    await this.prisma.user.update({
      where: { id: userId },
      data: {
        twoFactorBackupCodes: backupCodes.map((code) =>
          this.hashBackupCode(code),
        ),
      },
    });

    this.logger.log(`Regenerated backup codes for user ${userId}`);

    return {
      success: true,
      backupCodes,
    };
  }

  /**
   * Check if 2FA is enabled for user
   */
  async is2faEnabled(userId: number): Promise<boolean> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { twoFactorEnabled: true },
    });

    return user?.twoFactorEnabled || false;
  }

  // ============= Private Helper Methods =============

  private generateBackupCodes(count: number): string[] {
    const codes: string[] = [];
    for (let i = 0; i < count; i++) {
      // Generate 8-character alphanumeric code
      const code = crypto
        .randomBytes(4)
        .toString('hex')
        .toUpperCase()
        .replace(/(.{4})/g, '$1-')
        .slice(0, 9); // Format: XXXX-XXXX
      codes.push(code);
    }
    return codes;
  }

  private hashBackupCode(code: string): string {
    return crypto
      .createHash('sha256')
      .update(code.replace(/-/g, '').toUpperCase())
      .digest('hex');
  }

  private encrypt(text: string): string {
    const algorithm = 'aes-256-gcm';
    const key = this.getEncryptionKey();
    const iv = crypto.randomBytes(16);

    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    const authTag = cipher.getAuthTag();

    // Return iv:authTag:encrypted
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }

  private decrypt(encryptedText: string): string {
    const algorithm = 'aes-256-gcm';
    const key = this.getEncryptionKey();

    const parts = encryptedText.split(':');
    if (parts.length !== 3) {
      throw new Error('Invalid encrypted text format');
    }

    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];

    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  }

  private getEncryptionKey(): Buffer {
    const secret =
      this.config.get<string>('TOTP_ENCRYPTION_KEY') ||
      this.config.get<string>('JWT_SECRET') ||
      'default-encryption-key-change-me';

    // Derive a 32-byte key from the secret
    return crypto.scryptSync(secret, 'totp-salt', 32);
  }

  private checkRateLimiting(userId: number): void {
    const attempts = VERIFICATION_ATTEMPTS.get(userId);

    if (attempts?.lockedUntil) {
      if (new Date() < attempts.lockedUntil) {
        const remainingSeconds = Math.ceil(
          (attempts.lockedUntil.getTime() - Date.now()) / 1000,
        );
        throw new UnauthorizedException(
          `Too many failed attempts. Try again in ${Math.ceil(remainingSeconds / 60)} minutes.`,
        );
      } else {
        // Lockout expired
        VERIFICATION_ATTEMPTS.delete(userId);
      }
    }
  }

  private recordFailedAttempt(userId: number): void {
    const now = new Date();
    const attempts = VERIFICATION_ATTEMPTS.get(userId);

    if (attempts) {
      // Reset if window expired
      if (now.getTime() - attempts.lastAttempt.getTime() > ATTEMPT_WINDOW_MS) {
        VERIFICATION_ATTEMPTS.set(userId, { count: 1, lastAttempt: now });
      } else {
        attempts.count++;
        attempts.lastAttempt = now;

        if (attempts.count >= MAX_ATTEMPTS) {
          attempts.lockedUntil = new Date(now.getTime() + LOCKOUT_DURATION_MS);
          this.logger.warn(
            `User ${userId} locked out from 2FA verification due to too many failed attempts`,
          );
        }
      }
    } else {
      VERIFICATION_ATTEMPTS.set(userId, { count: 1, lastAttempt: now });
    }
  }

  private getRemainingAttempts(userId: number): number {
    const attempts = VERIFICATION_ATTEMPTS.get(userId);
    return attempts ? MAX_ATTEMPTS - attempts.count : MAX_ATTEMPTS;
  }
}
