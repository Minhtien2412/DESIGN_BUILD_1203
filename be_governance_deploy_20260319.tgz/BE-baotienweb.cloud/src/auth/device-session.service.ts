import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';

import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

export interface DeviceInfo {
  deviceName?: string;
  deviceType?: string; // mobile, tablet, desktop, web
  platform?: string; // ios, android, windows, macos, linux, web
  browser?: string;
  userAgent?: string;
  ipAddress?: string;
  location?: string;
}

export interface TokenPayload {
  sub: number;
  email: string;
  role: string;
  tokenFamily?: string;
  sessionId?: string;
}

export interface TokensResponse {
  accessToken: string;
  refreshToken: string;
  sessionId?: string;
}

@Injectable()
export class DeviceSessionService {
  private readonly logger = new Logger(DeviceSessionService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
  ) {}

  /**
   * Parse user agent to extract device info
   */
  parseUserAgent(userAgent?: string): Partial<DeviceInfo> {
    if (!userAgent) return {};

    const info: Partial<DeviceInfo> = { userAgent };

    // Detect device type
    if (/mobile/i.test(userAgent)) {
      info.deviceType = 'mobile';
    } else if (/tablet|ipad/i.test(userAgent)) {
      info.deviceType = 'tablet';
    } else {
      info.deviceType = 'desktop';
    }

    // Detect platform
    if (/android/i.test(userAgent)) {
      info.platform = 'android';
    } else if (/iphone|ipad|ipod/i.test(userAgent)) {
      info.platform = 'ios';
    } else if (/windows/i.test(userAgent)) {
      info.platform = 'windows';
    } else if (/macintosh|mac os/i.test(userAgent)) {
      info.platform = 'macos';
    } else if (/linux/i.test(userAgent)) {
      info.platform = 'linux';
    } else {
      info.platform = 'web';
    }

    // Detect browser
    if (/chrome/i.test(userAgent) && !/edge/i.test(userAgent)) {
      info.browser = 'chrome';
    } else if (/firefox/i.test(userAgent)) {
      info.browser = 'firefox';
    } else if (/safari/i.test(userAgent) && !/chrome/i.test(userAgent)) {
      info.browser = 'safari';
    } else if (/edge/i.test(userAgent)) {
      info.browser = 'edge';
    } else if (/opera|opr/i.test(userAgent)) {
      info.browser = 'opera';
    }

    return info;
  }

  /**
   * Create a new device session and generate tokens
   */
  async createSession(
    userId: number,
    email: string,
    role: Role,
    deviceInfo: DeviceInfo = {},
  ): Promise<TokensResponse & { sessionId: string }> {
    // Generate a unique token family for this session
    const tokenFamily = crypto.randomUUID();

    // Calculate expiry (30 days by default)
    const refreshExpiresIn =
      this.config.get<string>('JWT_REFRESH_EXPIRES_IN') || '30d';
    const expiresAt = this.calculateExpiry(refreshExpiresIn);

    // Create the device session
    const session = await this.prisma.deviceSession.create({
      data: {
        userId,
        tokenFamily,
        deviceName: deviceInfo.deviceName,
        deviceType: deviceInfo.deviceType,
        platform: deviceInfo.platform,
        browser: deviceInfo.browser,
        userAgent: deviceInfo.userAgent,
        ipAddress: deviceInfo.ipAddress,
        location: deviceInfo.location,
        expiresAt,
        lastUsedAt: new Date(),
      },
    });

    // Generate tokens with session info
    const tokens = await this.generateTokensWithFamily(
      userId,
      email,
      role,
      tokenFamily,
      session.id,
    );

    // Store hashed refresh token
    await this.prisma.deviceSession.update({
      where: { id: session.id },
      data: { refreshTokenHash: await this.hash(tokens.refreshToken) },
    });

    this.logger.log(
      `Created new session for user ${userId}, session: ${session.id}`,
    );

    return { ...tokens, sessionId: session.id };
  }

  /**
   * Refresh tokens with rotation (invalidates old token, issues new one)
   */
  async refreshWithRotation(
    refreshToken: string,
    deviceInfo?: DeviceInfo,
  ): Promise<TokensResponse> {
    // Decode the refresh token to get the token family
    let payload: TokenPayload;
    try {
      payload = await this.jwtService.verifyAsync(refreshToken, {
        secret:
          this.config.get<string>('JWT_REFRESH_SECRET') ||
          this.config.get<string>('JWT_SECRET'),
      });
    } catch (error) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    const { sub: userId, tokenFamily, sessionId } = payload;

    // If no token family (legacy token), throw to use fallback
    if (!tokenFamily) {
      throw new UnauthorizedException('Legacy token - use fallback refresh');
    }

    // Find the session by token family
    const session = await this.prisma.deviceSession.findFirst({
      where: {
        tokenFamily,
        userId,
        isActive: true,
      },
      include: { user: true },
    });

    if (!session) {
      // Token family not found - possible token reuse attack
      this.logger.warn(
        `Token reuse detected for user ${userId}, family: ${tokenFamily}`,
      );

      // Revoke all sessions for this user as a security measure
      await this.revokeAllUserSessions(userId, 'Token reuse detected');

      throw new UnauthorizedException('Refresh token has been revoked');
    }

    // Verify the refresh token hash matches
    if (session.refreshTokenHash) {
      const isValid = await this.compare(
        refreshToken,
        session.refreshTokenHash,
      );
      if (!isValid) {
        // Token reuse attack - someone is using an old token
        this.logger.warn(
          `Token reuse attack detected for session ${session.id}`,
        );

        // Revoke the entire token family
        await this.revokeSession(session.id, 'Token reuse attack detected');

        throw new UnauthorizedException('Refresh token has been revoked');
      }
    }

    // Check if session is expired
    if (session.expiresAt && session.expiresAt < new Date()) {
      await this.revokeSession(session.id, 'Session expired');
      throw new UnauthorizedException('Session has expired');
    }

    // Generate new tokens (rotation)
    const tokens = await this.generateTokensWithFamily(
      userId,
      session.user.email,
      session.user.role,
      tokenFamily,
      session.id,
    );

    // Update session with new token hash and last used timestamp
    await this.prisma.deviceSession.update({
      where: { id: session.id },
      data: {
        refreshTokenHash: await this.hash(tokens.refreshToken),
        lastUsedAt: new Date(),
        ipAddress: deviceInfo?.ipAddress || session.ipAddress,
      },
    });

    this.logger.log(`Token rotated for session ${session.id}`);

    return { ...tokens, sessionId: session.id };
  }

  /**
   * Revoke a specific session
   */
  async revokeSession(sessionId: string, reason?: string): Promise<void> {
    await this.prisma.deviceSession.update({
      where: { id: sessionId },
      data: {
        isActive: false,
        revokedAt: new Date(),
        revokedReason: reason || 'User logout',
        refreshTokenHash: null,
      },
    });

    this.logger.log(`Session ${sessionId} revoked: ${reason}`);
  }

  /**
   * Revoke all sessions for a user (except current one optionally)
   */
  async revokeAllUserSessions(
    userId: number,
    reason?: string,
    exceptSessionId?: string,
  ): Promise<number> {
    const result = await this.prisma.deviceSession.updateMany({
      where: {
        userId,
        isActive: true,
        ...(exceptSessionId ? { id: { not: exceptSessionId } } : {}),
      },
      data: {
        isActive: false,
        revokedAt: new Date(),
        revokedReason: reason || 'User revoked all sessions',
        refreshTokenHash: null,
      },
    });

    this.logger.log(`Revoked ${result.count} sessions for user ${userId}`);

    return result.count;
  }

  /**
   * Get all active sessions for a user
   */
  async getUserSessions(userId: number) {
    return this.prisma.deviceSession.findMany({
      where: {
        userId,
        isActive: true,
      },
      select: {
        id: true,
        deviceName: true,
        deviceType: true,
        platform: true,
        browser: true,
        ipAddress: true,
        location: true,
        lastUsedAt: true,
        createdAt: true,
      },
      orderBy: { lastUsedAt: 'desc' },
    });
  }

  /**
   * Cleanup expired sessions (can be run as a cron job)
   */
  async cleanupExpiredSessions(): Promise<number> {
    const result = await this.prisma.deviceSession.updateMany({
      where: {
        isActive: true,
        expiresAt: { lt: new Date() },
      },
      data: {
        isActive: false,
        revokedAt: new Date(),
        revokedReason: 'Session expired',
      },
    });

    if (result.count > 0) {
      this.logger.log(`Cleaned up ${result.count} expired sessions`);
    }

    return result.count;
  }

  /**
   * Delete old revoked sessions (retention: 90 days)
   */
  async purgeOldSessions(): Promise<number> {
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    const result = await this.prisma.deviceSession.deleteMany({
      where: {
        isActive: false,
        revokedAt: { lt: ninetyDaysAgo },
      },
    });

    if (result.count > 0) {
      this.logger.log(`Purged ${result.count} old sessions`);
    }

    return result.count;
  }

  /* ========================
     Private Helper Methods
  ========================== */

  private async generateTokensWithFamily(
    userId: number,
    email: string,
    role: Role,
    tokenFamily: string,
    sessionId: string,
  ): Promise<TokensResponse> {
    const payload: TokenPayload = {
      sub: userId,
      email,
      role: role.toString(),
      tokenFamily,
      sessionId,
    };

    const accessToken = await this.jwtService.signAsync(payload, {
      secret: this.config.get<string>('JWT_SECRET'),
      expiresIn: this.config.get<string>('JWT_EXPIRES_IN') || '7d',
    } as any);

    const refreshToken = await this.jwtService.signAsync(payload, {
      secret:
        this.config.get<string>('JWT_REFRESH_SECRET') ||
        this.config.get<string>('JWT_SECRET'),
      expiresIn: this.config.get<string>('JWT_REFRESH_EXPIRES_IN') || '30d',
    } as any);

    return { accessToken, refreshToken };
  }

  private calculateExpiry(expiresIn: string): Date {
    const now = new Date();
    const match = expiresIn.match(/^(\d+)([dhms])$/);

    if (match) {
      const value = parseInt(match[1], 10);
      const unit = match[2];

      switch (unit) {
        case 'd':
          now.setDate(now.getDate() + value);
          break;
        case 'h':
          now.setHours(now.getHours() + value);
          break;
        case 'm':
          now.setMinutes(now.getMinutes() + value);
          break;
        case 's':
          now.setSeconds(now.getSeconds() + value);
          break;
      }
    } else {
      // Default: 30 days
      now.setDate(now.getDate() + 30);
    }

    return now;
  }

  private hash(data: string): Promise<string> {
    return bcrypt.hash(data, 10);
  }

  private compare(data: string, hashed: string): Promise<boolean> {
    return bcrypt.compare(data, hashed);
  }
}
