/**
 * TOTP 2FA Controller
 * REST API endpoints for Two-Factor Authentication
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Post,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiBody,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { IsNotEmpty, IsString, Length, Matches } from 'class-validator';

import { CurrentUser } from './decorators';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { Totp2faService } from './totp-2fa.service';

// ============= DTOs =============

class VerifyTotpDto {
  @IsString()
  @IsNotEmpty()
  @Length(6, 10) // 6 digits for TOTP or 9 chars for backup code (XXXX-XXXX)
  @Matches(/^[\dA-Z-]+$/i, {
    message: 'Code must contain only digits, letters, or hyphens',
  })
  code: string;
}

// ============= Controller =============

@ApiTags('2FA / TOTP')
@Controller('auth/2fa')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class Totp2faController {
  constructor(private readonly totp2faService: Totp2faService) {}

  @Get('status')
  @ApiOperation({ summary: 'Get 2FA status for current user' })
  @ApiResponse({
    status: 200,
    description: '2FA status',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        data: {
          type: 'object',
          properties: {
            enabled: { type: 'boolean', example: true },
            enabledAt: { type: 'string', format: 'date-time' },
            backupCodesRemaining: { type: 'number', example: 6 },
          },
        },
      },
    },
  })
  async getStatus(@CurrentUser('id') userId: number) {
    const status = await this.totp2faService.getStatus(userId);

    return {
      success: true,
      data: status,
    };
  }

  @Post('setup')
  @ApiOperation({
    summary: 'Generate TOTP secret and QR code for 2FA setup',
    description:
      'Returns a secret key, QR code, and backup codes. User must verify with a code from their authenticator app to complete setup.',
  })
  @ApiResponse({
    status: 200,
    description: 'TOTP setup data',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        data: {
          type: 'object',
          properties: {
            secret: { type: 'string', description: 'Base32 encoded secret' },
            otpAuthUrl: {
              type: 'string',
              description: 'OTP Auth URL for apps',
            },
            qrCodeDataUrl: {
              type: 'string',
              description: 'QR code as data URL',
            },
            backupCodes: {
              type: 'array',
              items: { type: 'string' },
              description: 'Recovery codes - store securely!',
            },
          },
        },
        message: { type: 'string' },
      },
    },
  })
  @ApiResponse({
    status: 409,
    description: '2FA is already enabled',
  })
  async setupTotp(@CurrentUser('id') userId: number) {
    const setupData = await this.totp2faService.generateSecret(userId);

    return {
      success: true,
      data: setupData,
      message:
        'Scan the QR code with your authenticator app (Google Authenticator, Authy, etc.) and verify with a code to enable 2FA. Store your backup codes securely!',
    };
  }

  @Post('enable')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Enable 2FA by verifying a code from authenticator app',
    description: 'Completes 2FA setup by verifying the first TOTP code',
  })
  @ApiBody({ type: VerifyTotpDto })
  @ApiResponse({
    status: 200,
    description: '2FA enabled successfully',
  })
  @ApiResponse({
    status: 400,
    description: 'Invalid code or 2FA not set up',
  })
  async enableTotp(
    @CurrentUser('id') userId: number,
    @Body() dto: VerifyTotpDto,
  ) {
    const result = await this.totp2faService.enableTotp(userId, dto.code);

    return {
      success: result.success,
      message: result.message,
      ...(result.remainingAttempts !== undefined && {
        remainingAttempts: result.remainingAttempts,
      }),
    };
  }

  @Post('verify')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Verify a TOTP code (for login or sensitive operations)',
    description: 'Verify either a 6-digit TOTP code or a backup code',
  })
  @ApiBody({ type: VerifyTotpDto })
  @ApiResponse({
    status: 200,
    description: 'Verification result',
  })
  async verifyTotp(
    @CurrentUser('id') userId: number,
    @Body() dto: VerifyTotpDto,
  ) {
    const result = await this.totp2faService.verifyTotp(userId, dto.code);

    return {
      success: result.success,
      message: result.message,
      ...(result.remainingAttempts !== undefined && {
        remainingAttempts: result.remainingAttempts,
      }),
    };
  }

  @Delete('disable')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Disable 2FA (requires current TOTP code)',
  })
  @ApiBody({ type: VerifyTotpDto })
  @ApiResponse({
    status: 200,
    description: '2FA disabled successfully',
  })
  @ApiResponse({
    status: 401,
    description: 'Invalid verification code',
  })
  async disableTotp(
    @CurrentUser('id') userId: number,
    @Body() dto: VerifyTotpDto,
  ) {
    const result = await this.totp2faService.disableTotp(userId, dto.code);

    return {
      success: result.success,
      message: result.message,
    };
  }

  @Post('backup-codes/regenerate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Regenerate backup codes (requires current TOTP code)',
    description:
      'Generates new backup codes and invalidates old ones. Store the new codes securely!',
  })
  @ApiBody({ type: VerifyTotpDto })
  @ApiResponse({
    status: 200,
    description: 'New backup codes generated',
    schema: {
      type: 'object',
      properties: {
        success: { type: 'boolean', example: true },
        backupCodes: {
          type: 'array',
          items: { type: 'string' },
          example: ['ABCD-1234', 'EFGH-5678'],
        },
        message: { type: 'string' },
      },
    },
  })
  async regenerateBackupCodes(
    @CurrentUser('id') userId: number,
    @Body() dto: VerifyTotpDto,
  ) {
    const result = await this.totp2faService.regenerateBackupCodes(
      userId,
      dto.code,
    );

    return {
      success: result.success,
      backupCodes: result.backupCodes,
      message:
        'New backup codes generated. Your old codes are now invalid. Store these securely!',
    };
  }
}
