/**
 * Social Authentication Service
 * Unified service for Google, Facebook, Zalo OAuth with account linking
 *
 * @module auth/social-auth.service
 * @created 2026-01-22
 */

import {
    BadRequestException,
    ConflictException,
    Injectable,
    Logger,
    NotFoundException,
    UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { DeviceInfo, DeviceSessionService } from './device-session.service';

/**
 * Supported OAuth providers
 */
export enum SocialProvider {
  GOOGLE = 'GOOGLE',
  FACEBOOK = 'FACEBOOK',
  ZALO = 'ZALO',
  APPLE = 'APPLE', // Future support
}

/**
 * OAuth user profile from provider
 */
export interface SocialProfile {
  provider: SocialProvider;
  providerId: string; // Unique ID from provider
  email?: string;
  name?: string;
  picture?: string;
  phone?: string; // Zalo may provide phone
  locale?: string;
  verified?: boolean;
  raw?: Record<string, any>; // Original provider data
}

/**
 * Result of social authentication
 */
export interface SocialAuthResult {
  accessToken: string;
  refreshToken: string;
  sessionId?: string;
  expiresIn: number;
  user: {
    id: number;
    email: string;
    name: string;
    role: string;
    picture?: string;
    linkedProviders: SocialProvider[];
    isNewUser: boolean;
  };
}

/**
 * Account linking result
 */
export interface AccountLinkResult {
  success: boolean;
  linkedProviders: SocialProvider[];
  message: string;
}

@Injectable()
export class SocialAuthService {
  private readonly logger = new Logger(SocialAuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly deviceSessionService: DeviceSessionService,
  ) {}

  /**
   * Main social authentication method
   * Handles login or auto-registration with provider
   */
  async authenticateWithProvider(
    profile: SocialProfile,
    deviceInfo?: DeviceInfo,
  ): Promise<SocialAuthResult> {
    const { provider, providerId, email, name, picture } = profile;

    this.logger.log(
      `Social auth attempt: ${provider}, providerId: ${providerId?.slice(0, 8)}...`,
    );

    // 1. Check if this social account is already linked to a user
    // Using user_oauth_providers table
    const existingSocialAccount =
      await this.prisma.user_oauth_providers.findUnique({
        where: {
          provider_providerId: {
            provider,
            providerId,
          },
        },
        include: {
          users: true,
        },
      });

    if (existingSocialAccount) {
      // Existing linked account - login
      return this.loginWithExistingAccount(
        existingSocialAccount.users,
        profile,
        deviceInfo,
      );
    }

    // 2. Check if user exists with this email (to prevent duplicate accounts)
    if (email) {
      const existingUser = await this.prisma.user.findUnique({
        where: { email },
        include: {
          user_oauth_providers: true,
        },
      });

      if (existingUser) {
        // User exists but hasn't linked this provider - auto-link and login
        await this.linkProviderToUser(existingUser.id, profile);
        return this.loginWithExistingAccount(existingUser, profile, deviceInfo);
      }
    }

    // 3. Create new user with social account
    return this.createUserWithSocialAccount(profile, deviceInfo);
  }

  /**
   * Login with existing linked account
   */
  private async loginWithExistingAccount(
    user: any,
    profile: SocialProfile,
    deviceInfo?: DeviceInfo,
  ): Promise<SocialAuthResult> {
    // Update social account with latest profile info
    await this.prisma.user_oauth_providers.update({
      where: {
        provider_providerId: {
          provider: profile.provider,
          providerId: profile.providerId,
        },
      },
      data: {
        email: profile.email || undefined,
        updatedAt: new Date(),
      },
    });

    // Create session
    const tokens = await this.deviceSessionService.createSession(
      user.id,
      user.email,
      user.role,
      deviceInfo,
    );

    // Get all linked providers
    const oauthAccounts = await this.prisma.user_oauth_providers.findMany({
      where: { userId: user.id },
      select: { provider: true },
    });

    this.logger.log(
      `Social login successful: ${user.email} via ${profile.provider}`,
    );

    return {
      ...tokens,
      expiresIn: 7 * 24 * 60 * 60, // 7 days in seconds
      user: {
        id: user.id,
        email: user.email,
        name: user.name || '',
        role: user.role,
        picture: profile.picture || user.avatar,
        linkedProviders: oauthAccounts.map((a) => a.provider as SocialProvider),
        isNewUser: false,
      },
    };
  }

  /**
   * Create new user with social account
   */
  private async createUserWithSocialAccount(
    profile: SocialProfile,
    deviceInfo?: DeviceInfo,
  ): Promise<SocialAuthResult> {
    const { provider, providerId, email, name, picture, phone } = profile;

    // Generate email if not provided (some providers like Zalo may not provide email)
    const userEmail =
      email || `${provider.toLowerCase()}_${providerId}@social.local`;

    // Generate a random secure password (user can set one later if needed)
    const randomPassword = this.generateSecurePassword();
    const bcrypt = await import('bcrypt');
    const hashedPassword = await bcrypt.hash(randomPassword, 10);

    // Transaction to create user and social account atomically
    const result = await this.prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email: userEmail,
          name: name || `User_${providerId.slice(0, 8)}`,
          password: hashedPassword,
          role: Role.CLIENT,
          phone: phone || null,
          avatar: picture || null,
        },
      });

      // Create social account link using user_oauth_providers
      await tx.user_oauth_providers.create({
        data: {
          provider,
          providerId,
          userId: user.id,
          email: email || null,
          linkedAt: new Date(),
          updatedAt: new Date(),
        },
      });

      return user;
    });

    // Create session
    const tokens = await this.deviceSessionService.createSession(
      result.id,
      result.email,
      result.role,
      deviceInfo,
    );

    this.logger.log(
      `New user created via ${provider}: ${result.email}, id: ${result.id}`,
    );

    return {
      ...tokens,
      expiresIn: 7 * 24 * 60 * 60, // 7 days in seconds
      user: {
        id: result.id,
        email: result.email,
        name: result.name || '',
        role: result.role,
        picture: picture,
        linkedProviders: [provider],
        isNewUser: true,
      },
    };
  }

  /**
   * Link a social provider to existing user account
   * Used when user manually wants to link another provider
   */
  async linkProviderToUser(
    userId: number,
    profile: SocialProfile,
  ): Promise<AccountLinkResult> {
    const { provider, providerId, email } = profile;

    // Check if this social account is already linked to another user
    const existing = await this.prisma.user_oauth_providers.findUnique({
      where: {
        provider_providerId: {
          provider,
          providerId,
        },
      },
    });

    if (existing) {
      if (existing.userId === userId) {
        throw new ConflictException(
          `${provider} is already linked to your account`,
        );
      }
      throw new ConflictException(
        `This ${provider} account is already linked to another user`,
      );
    }

    // Check if user already has this provider linked (different account)
    const userHasProvider = await this.prisma.user_oauth_providers.findFirst({
      where: {
        userId,
        provider,
      },
    });

    if (userHasProvider) {
      throw new ConflictException(
        `You already have a ${provider} account linked. Unlink it first to link a different one.`,
      );
    }

    // Create the link
    await this.prisma.user_oauth_providers.create({
      data: {
        provider,
        providerId,
        userId,
        email: email || null,
        linkedAt: new Date(),
        updatedAt: new Date(),
      },
    });

    // Get all linked providers
    const oauthAccounts = await this.prisma.user_oauth_providers.findMany({
      where: { userId },
      select: { provider: true },
    });

    this.logger.log(`Provider ${provider} linked to user ${userId}`);

    return {
      success: true,
      linkedProviders: oauthAccounts.map((a) => a.provider as SocialProvider),
      message: `${provider} account linked successfully`,
    };
  }

  /**
   * Unlink a social provider from user account
   */
  async unlinkProvider(
    userId: number,
    provider: SocialProvider,
  ): Promise<AccountLinkResult> {
    // Check if user has this provider linked
    const oauthAccount = await this.prisma.user_oauth_providers.findFirst({
      where: {
        userId,
        provider,
      },
    });

    if (!oauthAccount) {
      throw new NotFoundException(`${provider} is not linked to your account`);
    }

    // Count total linked accounts + password
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        user_oauth_providers: true,
      },
    });

    const hasPassword = user?.password && !user.password.startsWith('$social_');
    const linkedCount = user?.user_oauth_providers?.length || 0;

    // Must have at least one auth method (password or social)
    if (linkedCount <= 1 && !hasPassword) {
      throw new BadRequestException(
        'Cannot unlink the only authentication method. Set a password first or link another provider.',
      );
    }

    // Delete the link
    await this.prisma.user_oauth_providers.delete({
      where: { id: oauthAccount.id },
    });

    // Get remaining linked providers
    const remaining = await this.prisma.user_oauth_providers.findMany({
      where: { userId },
      select: { provider: true },
    });

    this.logger.log(`Provider ${provider} unlinked from user ${userId}`);

    return {
      success: true,
      linkedProviders: remaining.map((a) => a.provider as SocialProvider),
      message: `${provider} account unlinked successfully`,
    };
  }

  /**
   * Get user's linked social accounts
   */
  async getLinkedAccounts(userId: number): Promise<
    Array<{
      provider: SocialProvider;
      email?: string;
      linkedAt: Date;
    }>
  > {
    const accounts = await this.prisma.user_oauth_providers.findMany({
      where: { userId },
      select: {
        provider: true,
        email: true,
        linkedAt: true,
      },
      orderBy: { linkedAt: 'desc' },
    });

    return accounts.map((a) => ({
      provider: a.provider as SocialProvider,
      email: a.email || undefined,
      linkedAt: a.linkedAt,
    }));
  }

  // =====================
  // Provider Token Verification
  // =====================

  /**
   * Verify Google ID token and extract profile
   */
  async verifyGoogleToken(idToken: string): Promise<SocialProfile> {
    try {
      const { OAuth2Client } = await import('google-auth-library');
      const clientId = this.config.get<string>('GOOGLE_CLIENT_ID');
      const client = new OAuth2Client(clientId);

      const ticket = await client.verifyIdToken({
        idToken,
        audience: clientId,
      });

      const payload = ticket.getPayload();
      if (!payload) {
        throw new UnauthorizedException('Invalid Google token');
      }

      return {
        provider: SocialProvider.GOOGLE,
        providerId: payload.sub,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
        locale: payload.locale,
        verified: payload.email_verified,
        raw: payload as any,
      };
    } catch (error) {
      this.logger.error(`Google token verification failed: ${error.message}`);
      throw new UnauthorizedException('Invalid or expired Google token');
    }
  }

  /**
   * Verify Facebook access token and extract profile
   */
  async verifyFacebookToken(accessToken: string): Promise<SocialProfile> {
    try {
      const appId = this.config.get<string>('FACEBOOK_APP_ID');
      const appSecret = this.config.get<string>('FACEBOOK_APP_SECRET');

      // Verify token with Facebook
      const verifyUrl = `https://graph.facebook.com/debug_token?input_token=${accessToken}&access_token=${appId}|${appSecret}`;
      const verifyResponse = await fetch(verifyUrl);
      const verifyData = await verifyResponse.json();

      if (!verifyData.data?.is_valid) {
        throw new UnauthorizedException('Invalid Facebook token');
      }

      // Get user profile
      const profileUrl = `https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`;
      const profileResponse = await fetch(profileUrl);
      const profile = await profileResponse.json();

      return {
        provider: SocialProvider.FACEBOOK,
        providerId: profile.id,
        email: profile.email,
        name: profile.name,
        picture: profile.picture?.data?.url,
        raw: profile,
      };
    } catch (error) {
      this.logger.error(`Facebook token verification failed: ${error.message}`);
      throw new UnauthorizedException('Invalid or expired Facebook token');
    }
  }

  /**
   * Verify Zalo access token and extract profile
   */
  async verifyZaloToken(accessToken: string): Promise<SocialProfile> {
    try {
      // Get Zalo user profile
      const profileUrl = 'https://graph.zalo.me/v2.0/me?fields=id,name,picture';

      const profileResponse = await fetch(profileUrl, {
        headers: {
          access_token: accessToken,
        },
      });

      const profile = await profileResponse.json();

      if (profile.error) {
        throw new UnauthorizedException(
          profile.message || 'Invalid Zalo token',
        );
      }

      return {
        provider: SocialProvider.ZALO,
        providerId: profile.id,
        name: profile.name,
        picture: profile.picture?.data?.url,
        raw: profile,
      };
    } catch (error) {
      this.logger.error(`Zalo token verification failed: ${error.message}`);
      throw new UnauthorizedException('Invalid or expired Zalo token');
    }
  }

  /**
   * Generic token verification dispatcher
   */
  async verifyProviderToken(
    provider: SocialProvider,
    token: string,
  ): Promise<SocialProfile> {
    switch (provider) {
      case SocialProvider.GOOGLE:
        return this.verifyGoogleToken(token);
      case SocialProvider.FACEBOOK:
        return this.verifyFacebookToken(token);
      case SocialProvider.ZALO:
        return this.verifyZaloToken(token);
      default:
        throw new BadRequestException(`Unsupported provider: ${provider}`);
    }
  }

  // =====================
  // Helper Methods
  // =====================

  private generateSecurePassword(): string {
    const chars =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 32; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `$social_${password}`;
  }
}
