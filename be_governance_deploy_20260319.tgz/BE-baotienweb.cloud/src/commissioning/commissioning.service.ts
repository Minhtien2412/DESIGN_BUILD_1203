import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    AddPhotosDto,
    CreateCommissioningPlanDto,
    CreateCommissioningSystemDto,
    CreateCommissioningTestDto,
    CreateDeficiencyDto,
    CreateReportDto,
    CreateSignOffDto,
    UpdateCommissioningPlanDto,
    UpdateCommissioningSystemDto,
    UpdateCommissioningTestDto,
    UpdateDeficiencyDto,
} from './dto';

@Injectable()
export class CommissioningService {
  constructor(private prisma: PrismaService) {}

  // ==================== Plans ====================

  async createPlan(data: CreateCommissioningPlanDto, userId: number) {
    return this.prisma.commissioningPlan.create({
      data: {
        name: data.name,
        description: data.description,
        projectId: data.projectId,
        startDate: data.startDate ? new Date(data.startDate) : undefined,
        endDate: data.endDate ? new Date(data.endDate) : undefined,
        createdById: userId,
      },
      include: { systems: true, project: true },
    });
  }

  async getPlans(projectId?: number, status?: string) {
    return this.prisma.commissioningPlan.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(status ? { status: status as any } : {}),
      },
      include: {
        systems: { include: { _count: { select: { tests: true } } } },
        project: { select: { id: true, title: true } },
        createdBy: { select: { id: true, name: true, avatar: true } },
        _count: { select: { systems: true, reports: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getPlanById(id: number) {
    const plan = await this.prisma.commissioningPlan.findUnique({
      where: { id },
      include: {
        systems: {
          include: {
            tests: {
              include: {
                _count: {
                  select: { steps: true, deficiencies: true, signOffs: true },
                },
              },
            },
            _count: { select: { tests: true, deficiencies: true } },
          },
          orderBy: { order: 'asc' },
        },
        reports: { orderBy: { generatedAt: 'desc' } },
        project: { select: { id: true, title: true } },
        createdBy: { select: { id: true, name: true, avatar: true } },
      },
    });
    if (!plan) throw new NotFoundException('Commissioning plan not found');
    return plan;
  }

  async updatePlan(id: number, data: UpdateCommissioningPlanDto) {
    return this.prisma.commissioningPlan.update({
      where: { id },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.startDate ? { startDate: new Date(data.startDate) } : {}),
        ...(data.endDate ? { endDate: new Date(data.endDate) } : {}),
      },
      include: { systems: true },
    });
  }

  async deletePlan(id: number) {
    return this.prisma.commissioningPlan.delete({ where: { id } });
  }

  // ==================== Systems ====================

  async createSystem(planId: number, data: CreateCommissioningSystemDto) {
    return this.prisma.commissioningSystem.create({
      data: {
        name: data.name,
        type: data.type,
        category: data.category,
        description: data.description,
        location: data.location,
        building: data.building,
        floor: data.floor,
        manufacturer: data.manufacturer,
        model: data.model,
        capacity: data.capacity,
        order: data.order ?? 0,
        planId,
      },
      include: { tests: true },
    });
  }

  async getSystems(planId: number) {
    return this.prisma.commissioningSystem.findMany({
      where: { planId },
      include: {
        tests: {
          include: { _count: { select: { steps: true, deficiencies: true } } },
        },
        _count: { select: { tests: true, deficiencies: true } },
      },
      orderBy: { order: 'asc' },
    });
  }

  async getSystemById(planId: number, systemId: number) {
    const system = await this.prisma.commissioningSystem.findFirst({
      where: { id: systemId, planId },
      include: {
        tests: {
          include: {
            steps: { orderBy: { stepNumber: 'asc' } },
            signOffs: {
              include: { signedBy: { select: { id: true, name: true } } },
            },
            photos: true,
            _count: { select: { deficiencies: true } },
          },
        },
        deficiencies: true,
      },
    });
    if (!system) throw new NotFoundException('System not found');
    return system;
  }

  async updateSystem(
    planId: number,
    systemId: number,
    data: UpdateCommissioningSystemDto,
  ) {
    return this.prisma.commissioningSystem.update({
      where: { id: systemId },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.type !== undefined ? { type: data.type } : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.location !== undefined ? { location: data.location } : {}),
        ...(data.building !== undefined ? { building: data.building } : {}),
        ...(data.floor !== undefined ? { floor: data.floor } : {}),
        ...(data.manufacturer !== undefined
          ? { manufacturer: data.manufacturer }
          : {}),
        ...(data.model !== undefined ? { model: data.model } : {}),
        ...(data.capacity !== undefined ? { capacity: data.capacity } : {}),
        ...(data.handoverStatus !== undefined
          ? { handoverStatus: data.handoverStatus }
          : {}),
        ...(data.handoverNotes !== undefined
          ? { handoverNotes: data.handoverNotes }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.order !== undefined ? { order: data.order } : {}),
      },
    });
  }

  async deleteSystem(planId: number, systemId: number) {
    return this.prisma.commissioningSystem.delete({ where: { id: systemId } });
  }

  // ==================== Tests ====================

  async createTest(systemId: number, data: CreateCommissioningTestDto) {
    const test = await this.prisma.commissioningTest.create({
      data: {
        name: data.name,
        testType: data.testType,
        category: data.category,
        procedure: data.procedure,
        acceptanceCriteria: data.acceptanceCriteria ?? [],
        scheduledDate: data.scheduledDate
          ? new Date(data.scheduledDate)
          : undefined,
        systemId,
      },
      include: { steps: true },
    });

    if (data.steps?.length) {
      await this.prisma.commissioningTestStep.createMany({
        data: data.steps.map((s) => ({
          testId: test.id,
          stepNumber: s.stepNumber,
          description: s.description,
        })),
      });
    }

    return this.prisma.commissioningTest.findUnique({
      where: { id: test.id },
      include: { steps: { orderBy: { stepNumber: 'asc' } } },
    });
  }

  async getTests(systemId: number) {
    return this.prisma.commissioningTest.findMany({
      where: { systemId },
      include: {
        steps: { orderBy: { stepNumber: 'asc' } },
        signOffs: true,
        _count: { select: { deficiencies: true, photos: true } },
        executedBy: { select: { id: true, name: true, avatar: true } },
      },
      orderBy: { createdAt: 'asc' },
    });
  }

  async getTestById(systemId: number, testId: number) {
    const test = await this.prisma.commissioningTest.findFirst({
      where: { id: testId, systemId },
      include: {
        steps: { orderBy: { stepNumber: 'asc' } },
        deficiencies: true,
        signOffs: {
          include: { signedBy: { select: { id: true, name: true } } },
        },
        photos: true,
        executedBy: { select: { id: true, name: true, avatar: true } },
      },
    });
    if (!test) throw new NotFoundException('Test not found');
    return test;
  }

  async updateTest(
    systemId: number,
    testId: number,
    data: UpdateCommissioningTestDto,
  ) {
    return this.prisma.commissioningTest.update({
      where: { id: testId },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.testType !== undefined ? { testType: data.testType } : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.procedure !== undefined ? { procedure: data.procedure } : {}),
        ...(data.acceptanceCriteria !== undefined
          ? { acceptanceCriteria: data.acceptanceCriteria }
          : {}),
        ...(data.notes !== undefined ? { notes: data.notes } : {}),
      },
    });
  }

  async deleteTest(systemId: number, testId: number) {
    return this.prisma.commissioningTest.delete({ where: { id: testId } });
  }

  async startTest(systemId: number, testId: number, userId: number) {
    return this.prisma.commissioningTest.update({
      where: { id: testId },
      data: {
        status: 'IN_PROGRESS',
        startedAt: new Date(),
        executedById: userId,
      },
    });
  }

  async completeTestStep(
    systemId: number,
    testId: number,
    stepId: number,
    notes?: string,
  ) {
    return this.prisma.commissioningTestStep.update({
      where: { id: stepId },
      data: { status: 'PASSED', completedAt: new Date(), notes },
    });
  }

  async completeTest(systemId: number, testId: number, passed: boolean) {
    return this.prisma.commissioningTest.update({
      where: { id: testId },
      data: {
        status: passed ? 'PASSED' : 'FAILED',
        completedAt: new Date(),
      },
    });
  }

  async retestTest(systemId: number, testId: number) {
    await this.prisma.commissioningTestStep.updateMany({
      where: { testId },
      data: { status: 'PENDING', completedAt: null, notes: null },
    });
    return this.prisma.commissioningTest.update({
      where: { id: testId },
      data: { status: 'RETEST', startedAt: null, completedAt: null },
    });
  }

  // ==================== Deficiencies ====================

  async getDeficiencies(
    projectId?: number,
    status?: string,
    severity?: string,
  ) {
    return this.prisma.commissioningDeficiency.findMany({
      where: {
        ...(status ? { status: status as any } : {}),
        ...(severity ? { severity: severity as any } : {}),
        ...(projectId ? { system: { plan: { projectId } } } : {}),
      },
      include: {
        test: { select: { id: true, name: true } },
        system: {
          select: {
            id: true,
            name: true,
            plan: { select: { id: true, name: true } },
          },
        },
        resolvedBy: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async createDeficiency(
    systemId: number,
    testId: number,
    data: CreateDeficiencyDto,
  ) {
    return this.prisma.commissioningDeficiency.create({
      data: {
        description: data.description,
        severity: (data.severity as any) ?? 'MEDIUM',
        category: data.category,
        responsibleParty: data.responsibleParty,
        assignedToId: data.assignedToId,
        dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
        systemId: data.systemId || systemId,
        testId,
        images: data.images ?? [],
      },
    });
  }

  async updateDeficiency(deficiencyId: number, data: UpdateDeficiencyDto) {
    return this.prisma.commissioningDeficiency.update({
      where: { id: deficiencyId },
      data: {
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.severity !== undefined
          ? { severity: data.severity as any }
          : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.responsibleParty !== undefined
          ? { responsibleParty: data.responsibleParty }
          : {}),
        ...(data.assignedToId !== undefined
          ? { assignedToId: data.assignedToId }
          : {}),
        ...(data.dueDate !== undefined
          ? { dueDate: data.dueDate ? new Date(data.dueDate) : null }
          : {}),
        ...(data.resolution !== undefined
          ? { resolution: data.resolution }
          : {}),
        ...(data.correctiveAction !== undefined
          ? { correctiveAction: data.correctiveAction }
          : {}),
        ...(data.rootCause !== undefined ? { rootCause: data.rootCause } : {}),
        ...(data.images !== undefined ? { images: data.images } : {}),
      },
    });
  }

  async resolveDeficiency(deficiencyId: number, userId: number) {
    return this.prisma.commissioningDeficiency.update({
      where: { id: deficiencyId },
      data: {
        status: 'RESOLVED',
        resolvedById: userId,
        resolvedAt: new Date(),
      },
    });
  }

  async verifyDeficiency(deficiencyId: number, userId: number) {
    return this.prisma.commissioningDeficiency.update({
      where: { id: deficiencyId },
      data: {
        status: 'VERIFIED',
        verifiedById: userId,
        verifiedAt: new Date(),
      },
    });
  }

  // ==================== Sign-Offs ====================

  async createSignOff(
    systemId: number,
    testId: number,
    signOffType: string,
    userId: number,
    data: CreateSignOffDto,
  ) {
    return this.prisma.commissioningSignOff.create({
      data: {
        testId,
        type: signOffType as any,
        signedById: userId,
        signature: data.signature,
        comments: data.comments,
      },
      include: { signedBy: { select: { id: true, name: true } } },
    });
  }

  // ==================== Photos ====================

  async addPhotos(
    systemId: number,
    testId: number,
    data: AddPhotosDto,
    userId: number,
  ) {
    const created = await this.prisma.commissioningPhoto.createMany({
      data: data.photos.map((p) => ({
        testId,
        url: p.url,
        caption: p.caption,
        uploadedById: userId,
      })),
    });
    return { count: created.count };
  }

  // ==================== Reports ====================

  async getReports(planId: number) {
    return this.prisma.commissioningReport.findMany({
      where: { planId },
      include: { generatedBy: { select: { id: true, name: true } } },
      orderBy: { generatedAt: 'desc' },
    });
  }

  async createReport(planId: number, data: CreateReportDto, userId: number) {
    const plan = await this.getPlanById(planId);

    const systemsCount = plan.systems.length;
    const testsCount = plan.systems.reduce(
      (acc, s) => acc + (s.tests?.length || 0),
      0,
    );
    const passedTests = plan.systems.reduce(
      (acc, s) =>
        acc + (s.tests?.filter((t) => t.status === 'PASSED').length || 0),
      0,
    );

    return this.prisma.commissioningReport.create({
      data: {
        planId,
        type: data.type,
        title: data.title,
        content: {
          systemsCount,
          testsCount,
          passedTests,
          completionRate: testsCount ? (passedTests / testsCount) * 100 : 0,
        },
        generatedById: userId,
      },
    });
  }

  // ==================== Summary & Analytics ====================

  async getSummary(projectId?: number) {
    const where = projectId ? { system: { plan: { projectId } } } : {};
    const [
      totalTests,
      passedTests,
      failedTests,
      totalDeficiencies,
      openDeficiencies,
    ] = await Promise.all([
      this.prisma.commissioningTest.count({ where }),
      this.prisma.commissioningTest.count({
        where: { ...where, status: 'PASSED' },
      }),
      this.prisma.commissioningTest.count({
        where: { ...where, status: 'FAILED' },
      }),
      this.prisma.commissioningDeficiency.count({
        where: projectId ? { system: { plan: { projectId } } } : {},
      }),
      this.prisma.commissioningDeficiency.count({
        where: {
          ...(projectId ? { system: { plan: { projectId } } } : {}),
          status: 'OPEN',
        },
      }),
    ]);

    return {
      totalTests,
      passedTests,
      failedTests,
      pendingTests: totalTests - passedTests - failedTests,
      completionRate: totalTests ? (passedTests / totalTests) * 100 : 0,
      totalDeficiencies,
      openDeficiencies,
    };
  }

  async getAnalytics(projectId?: number) {
    const summary = await this.getSummary(projectId);
    const plans = await this.prisma.commissioningPlan.findMany({
      where: projectId ? { projectId } : {},
      include: { _count: { select: { systems: true } } },
    });

    return {
      ...summary,
      totalPlans: plans.length,
      plansByStatus: {
        draft: plans.filter((p) => p.status === 'DRAFT').length,
        inProgress: plans.filter((p) => p.status === 'IN_PROGRESS').length,
        completed: plans.filter((p) => p.status === 'COMPLETED').length,
      },
    };
  }

  // ==================== Export ====================

  async exportPlan(planId: number) {
    return this.getPlanById(planId);
  }

  async exportReport(reportId: number) {
    const report = await this.prisma.commissioningReport.findUnique({
      where: { id: reportId },
      include: {
        plan: { include: { project: true } },
        generatedBy: { select: { id: true, name: true } },
      },
    });
    if (!report) throw new NotFoundException('Report not found');
    return report;
  }

  async exportTests(systemId: number) {
    return this.getTests(systemId);
  }
}
