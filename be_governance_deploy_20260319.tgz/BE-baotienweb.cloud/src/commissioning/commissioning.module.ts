import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    CommissioningAnalyticsController,
    CommissioningDeficiencyController,
    CommissioningPlanController,
    CommissioningReportController,
    CommissioningSystemController,
} from './commissioning.controller';
import { CommissioningService } from './commissioning.service';

@Module({
  controllers: [
    CommissioningPlanController,
    CommissioningSystemController,
    CommissioningDeficiencyController,
    CommissioningAnalyticsController,
    CommissioningReportController,
  ],
  providers: [CommissioningService, PrismaService],
  exports: [CommissioningService],
})
export class CommissioningModule {}
