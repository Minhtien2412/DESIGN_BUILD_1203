import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CommissioningService } from './commissioning.service';
import {
    AddPhotosDto,
    CreateCommissioningPlanDto,
    CreateCommissioningSystemDto,
    CreateCommissioningTestDto,
    CreateDeficiencyDto,
    CreateReportDto,
    CreateSignOffDto,
    UpdateCommissioningPlanDto,
    UpdateCommissioningSystemDto,
    UpdateCommissioningTestDto,
    UpdateDeficiencyDto,
} from './dto';

// ==================== Plans Controller ====================
@ApiTags('Commissioning Plans')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'commissioning-plans', version: '1' })
export class CommissioningPlanController {
  constructor(private readonly service: CommissioningService) {}

  @Get()
  @ApiOperation({ summary: 'List commissioning plans' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'search', required: false })
  findAll(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
  ) {
    return this.service.getPlans(projectId ? +projectId : undefined, status);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get commissioning plan by ID' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.getPlanById(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create commissioning plan' })
  create(@Body() dto: CreateCommissioningPlanDto, @Req() req: any) {
    return this.service.createPlan(dto, req.user?.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update commissioning plan' })
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateCommissioningPlanDto,
  ) {
    return this.service.updatePlan(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete commissioning plan' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.deletePlan(id);
  }

  // --- Nested Systems under Plan ---
  @Get(':planId/systems')
  @ApiOperation({ summary: 'List systems for a plan' })
  getSystems(@Param('planId', ParseIntPipe) planId: number) {
    return this.service.getSystems(planId);
  }

  @Get(':planId/systems/:systemId')
  @ApiOperation({ summary: 'Get system by ID' })
  getSystem(
    @Param('planId', ParseIntPipe) planId: number,
    @Param('systemId', ParseIntPipe) systemId: number,
  ) {
    return this.service.getSystemById(planId, systemId);
  }

  @Post(':planId/systems')
  @ApiOperation({ summary: 'Add system to plan' })
  addSystem(
    @Param('planId', ParseIntPipe) planId: number,
    @Body() dto: CreateCommissioningSystemDto,
  ) {
    return this.service.createSystem(planId, dto);
  }

  @Put(':planId/systems/:systemId')
  @ApiOperation({ summary: 'Update system' })
  updateSystem(
    @Param('planId', ParseIntPipe) planId: number,
    @Param('systemId', ParseIntPipe) systemId: number,
    @Body() dto: UpdateCommissioningSystemDto,
  ) {
    return this.service.updateSystem(planId, systemId, dto);
  }

  @Delete(':planId/systems/:systemId')
  @ApiOperation({ summary: 'Remove system from plan' })
  removeSystem(
    @Param('planId', ParseIntPipe) planId: number,
    @Param('systemId', ParseIntPipe) systemId: number,
  ) {
    return this.service.deleteSystem(planId, systemId);
  }

  // --- Reports nested under Plan ---
  @Get(':planId/reports')
  @ApiOperation({ summary: 'List reports for a plan' })
  getReports(@Param('planId', ParseIntPipe) planId: number) {
    return this.service.getReports(planId);
  }

  @Post(':planId/reports')
  @ApiOperation({ summary: 'Generate a report for a plan' })
  createReport(
    @Param('planId', ParseIntPipe) planId: number,
    @Body() dto: CreateReportDto,
    @Req() req: any,
  ) {
    return this.service.createReport(planId, dto, req.user?.id);
  }

  // --- Export ---
  @Post(':id/export')
  @ApiOperation({ summary: 'Export commissioning plan' })
  exportPlan(@Param('id', ParseIntPipe) id: number) {
    return this.service.exportPlan(id);
  }
}

// ==================== Systems Controller ====================
@ApiTags('Commissioning Systems')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'commissioning-systems', version: '1' })
export class CommissioningSystemController {
  constructor(private readonly service: CommissioningService) {}

  // --- Tests ---
  @Get(':systemId/tests')
  @ApiOperation({ summary: 'List tests for a system' })
  @ApiQuery({ name: 'testType', required: false })
  @ApiQuery({ name: 'status', required: false })
  getTests(@Param('systemId', ParseIntPipe) systemId: number) {
    return this.service.getTests(systemId);
  }

  @Get(':systemId/tests/:testId')
  @ApiOperation({ summary: 'Get test by ID' })
  getTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
  ) {
    return this.service.getTestById(systemId, testId);
  }

  @Post(':systemId/tests')
  @ApiOperation({ summary: 'Create a test' })
  createTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Body() dto: CreateCommissioningTestDto,
  ) {
    return this.service.createTest(systemId, dto);
  }

  @Put(':systemId/tests/:testId')
  @ApiOperation({ summary: 'Update a test' })
  updateTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Body() dto: UpdateCommissioningTestDto,
  ) {
    return this.service.updateTest(systemId, testId, dto);
  }

  @Delete(':systemId/tests/:testId')
  @ApiOperation({ summary: 'Delete a test' })
  deleteTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
  ) {
    return this.service.deleteTest(systemId, testId);
  }

  // --- Test Execution ---
  @Post(':systemId/tests/:testId/start')
  @ApiOperation({ summary: 'Start test execution' })
  startTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Req() req: any,
  ) {
    return this.service.startTest(systemId, testId, req.user?.id);
  }

  @Post(':systemId/tests/:testId/steps/:stepId/complete')
  @ApiOperation({ summary: 'Complete a test step' })
  completeStep(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Param('stepId', ParseIntPipe) stepId: number,
    @Body() body: { notes?: string },
  ) {
    return this.service.completeTestStep(systemId, testId, stepId, body.notes);
  }

  @Post(':systemId/tests/:testId/complete')
  @ApiOperation({ summary: 'Mark test as complete' })
  completeTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Body() body: { passCriteria: boolean },
  ) {
    return this.service.completeTest(systemId, testId, body.passCriteria);
  }

  @Post(':systemId/tests/:testId/retest')
  @ApiOperation({ summary: 'Request retest' })
  retestTest(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
  ) {
    return this.service.retestTest(systemId, testId);
  }

  // --- Deficiencies nested under test ---
  @Post(':systemId/tests/:testId/deficiencies')
  @ApiOperation({ summary: 'Report a deficiency' })
  addDeficiency(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Body() dto: CreateDeficiencyDto,
  ) {
    return this.service.createDeficiency(systemId, testId, dto);
  }

  // --- Sign-offs ---
  @Post(':systemId/tests/:testId/sign-off/:type')
  @ApiOperation({ summary: 'Sign off on a test' })
  signOff(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Param('type') signOffType: string,
    @Req() req: any,
    @Body() dto: CreateSignOffDto,
  ) {
    return this.service.createSignOff(
      systemId,
      testId,
      signOffType.toUpperCase(),
      req.user?.id,
      dto,
    );
  }

  // --- Photos ---
  @Post(':systemId/tests/:testId/photos')
  @ApiOperation({ summary: 'Upload test photos' })
  addPhotos(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Body() dto: AddPhotosDto,
    @Req() req: any,
  ) {
    return this.service.addPhotos(systemId, testId, dto, req.user?.id);
  }

  // --- Attachments ---
  @Post(':systemId/tests/:testId/attachments')
  @ApiOperation({ summary: 'Upload test attachment' })
  addAttachment(
    @Param('systemId', ParseIntPipe) systemId: number,
    @Param('testId', ParseIntPipe) testId: number,
    @Body() body: { category?: string },
  ) {
    return {
      message: 'Attachment upload endpoint — integrate file storage provider',
      systemId,
      testId,
      ...body,
    };
  }

  // --- Export ---
  @Get(':systemId/export-tests')
  @ApiOperation({ summary: 'Export tests for a system' })
  exportTests(@Param('systemId', ParseIntPipe) systemId: number) {
    return this.service.exportTests(systemId);
  }
}

// ==================== Deficiencies Controller ====================
@ApiTags('Commissioning Deficiencies')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'commissioning-deficiencies', version: '1' })
export class CommissioningDeficiencyController {
  constructor(private readonly service: CommissioningService) {}

  @Get()
  @ApiOperation({ summary: 'List all deficiencies' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'severity', required: false })
  findAll(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
    @Query('severity') severity?: string,
  ) {
    return this.service.getDeficiencies(
      projectId ? +projectId : undefined,
      status,
      severity,
    );
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update deficiency' })
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateDeficiencyDto,
  ) {
    return this.service.updateDeficiency(id, dto);
  }

  @Post(':id/resolve')
  @ApiOperation({ summary: 'Resolve deficiency' })
  resolve(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    return this.service.resolveDeficiency(id, req.user?.id);
  }

  @Post(':id/verify')
  @ApiOperation({ summary: 'Verify deficiency resolution' })
  verify(@Param('id', ParseIntPipe) id: number, @Req() req: any) {
    return this.service.verifyDeficiency(id, req.user?.id);
  }
}

// ==================== Summary & Analytics Controller ====================
@ApiTags('Commissioning Analytics')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'commissioning', version: '1' })
export class CommissioningAnalyticsController {
  constructor(private readonly service: CommissioningService) {}

  @Get('summary')
  @ApiOperation({ summary: 'Get commissioning summary' })
  @ApiQuery({ name: 'projectId', required: false })
  getSummary(@Query('projectId') projectId?: string) {
    return this.service.getSummary(projectId ? +projectId : undefined);
  }

  @Get('analytics')
  @ApiOperation({ summary: 'Get commissioning analytics' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'period', required: false })
  getAnalytics(@Query('projectId') projectId?: string) {
    return this.service.getAnalytics(projectId ? +projectId : undefined);
  }
}

// ==================== Reports Controller ====================
@ApiTags('Commissioning Reports')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'commissioning-reports', version: '1' })
export class CommissioningReportController {
  constructor(private readonly service: CommissioningService) {}

  @Get(':id/export')
  @ApiOperation({ summary: 'Export a report' })
  export(@Param('id', ParseIntPipe) id: number) {
    return this.service.exportReport(id);
  }
}
