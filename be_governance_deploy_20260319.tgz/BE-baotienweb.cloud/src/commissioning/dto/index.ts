import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsDateString,
    IsEnum,
    IsInt,
    IsOptional,
    IsString,
} from 'class-validator';

// ==================== Enums ====================

export enum CommissioningPlanStatusDto {
  DRAFT = 'DRAFT',
  PLANNED = 'PLANNED',
  IN_PROGRESS = 'IN_PROGRESS',
  TESTING = 'TESTING',
  COMPLETED = 'COMPLETED',
  ON_HOLD = 'ON_HOLD',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

export enum CommissioningTestStatusDto {
  NOT_STARTED = 'NOT_STARTED',
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  PASSED = 'PASSED',
  FAILED = 'FAILED',
  CONDITIONAL_PASS = 'CONDITIONAL_PASS',
  RETEST = 'RETEST',
  RETEST_REQUIRED = 'RETEST_REQUIRED',
  WAIVED = 'WAIVED',
  SKIPPED = 'SKIPPED',
}

export enum DeficiencySeverityDto {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

export enum DeficiencyStatusDto {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  VERIFIED = 'VERIFIED',
  CLOSED = 'CLOSED',
}

export enum SignOffTypeDto {
  WITNESS = 'WITNESS',
  CONTRACTOR = 'CONTRACTOR',
  ENGINEER = 'ENGINEER',
  CLIENT = 'CLIENT',
  INSPECTOR = 'INSPECTOR',
}

// ==================== Plan DTOs ====================

export class CreateCommissioningPlanDto {
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiProperty() @IsInt() projectId: number;
  @ApiPropertyOptional() @IsOptional() @IsDateString() startDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() endDate?: string;
}

export class UpdateCommissioningPlanDto {
  @ApiPropertyOptional() @IsOptional() @IsString() name?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(CommissioningPlanStatusDto)
  status?: CommissioningPlanStatusDto;
  @ApiPropertyOptional() @IsOptional() @IsDateString() startDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() endDate?: string;
}

// ==================== System DTOs ====================

export class CreateCommissioningSystemDto {
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() location?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() building?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() floor?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() manufacturer?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() model?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() capacity?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() order?: number;
}

export class UpdateCommissioningSystemDto {
  @ApiPropertyOptional() @IsOptional() @IsString() name?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() location?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() building?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() floor?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() manufacturer?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() model?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() capacity?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() handoverStatus?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() handoverNotes?: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(CommissioningTestStatusDto)
  status?: CommissioningTestStatusDto;
  @ApiPropertyOptional() @IsOptional() @IsInt() order?: number;
}

// ==================== Test DTOs ====================

export class CreateCommissioningTestDto {
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() testType?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() procedure?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() acceptanceCriteria?: string[];
  @ApiPropertyOptional() @IsOptional() @IsDateString() scheduledDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() steps?: {
    stepNumber: number;
    description: string;
  }[];
}

export class UpdateCommissioningTestDto {
  @ApiPropertyOptional() @IsOptional() @IsString() name?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() testType?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() procedure?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() acceptanceCriteria?: string[];
  @ApiPropertyOptional() @IsOptional() @IsString() notes?: string;
}

// ==================== Deficiency DTOs ====================

export class CreateDeficiencyDto {
  @ApiProperty() @IsString() description: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(DeficiencySeverityDto)
  severity?: DeficiencySeverityDto;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() responsibleParty?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() assignedToId?: number;
  @ApiPropertyOptional() @IsOptional() @IsDateString() dueDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() images?: string[];
  @ApiProperty() @IsInt() systemId: number;
}

export class UpdateDeficiencyDto {
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(DeficiencySeverityDto)
  severity?: DeficiencySeverityDto;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() responsibleParty?: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() assignedToId?: number;
  @ApiPropertyOptional() @IsOptional() @IsDateString() dueDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() resolution?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() correctiveAction?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() rootCause?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() images?: string[];
}

// ==================== Sign-Off DTOs ====================

export class CreateSignOffDto {
  @ApiPropertyOptional() @IsOptional() @IsString() signature?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() comments?: string;
}

// ==================== Report DTOs ====================

export class CreateReportDto {
  @ApiProperty() @IsString() type: string;
  @ApiPropertyOptional() @IsOptional() @IsString() title?: string;
}

// ==================== Photo/Attachment DTOs ====================

export class AddPhotosDto {
  @ApiProperty() @IsArray() photos: { url: string; caption?: string }[];
}

export class AddAttachmentsDto {
  @ApiProperty() @IsArray() attachments: { url: string; filename?: string }[];
}
