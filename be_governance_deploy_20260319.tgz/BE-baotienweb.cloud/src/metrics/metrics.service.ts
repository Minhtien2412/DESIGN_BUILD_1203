import { Injectable, OnModuleInit } from '@nestjs/common';

interface MetricData {
  value: number;
  timestamp: number;
  labels?: Record<string, string>;
}

interface HistogramBucket {
  le: number;
  count: number;
}

@Injectable()
export class MetricsService implements OnModuleInit {
  // Counters
  private httpRequestsTotal = new Map<string, number>();
  private httpRequestErrorsTotal = new Map<string, number>();
  private wsConnectionsTotal = 0;
  private wsDisconnectsTotal = 0;
  private wsMessagesTotal = new Map<string, number>();

  // Gauges
  private activeWsConnections = new Map<string, number>();
  private activeUsers = 0;

  // Histograms (simplified - track sum and count for avg)
  private httpRequestDuration: {
    sum: Map<string, number>;
    count: Map<string, number>;
    buckets: Map<string, HistogramBucket[]>;
  } = {
    sum: new Map(),
    count: new Map(),
    buckets: new Map(),
  };

  // Application metrics
  private uploadSizeTotal = 0;
  private uploadCount = 0;
  private cacheHits = 0;
  private cacheMisses = 0;

  // Start time for uptime calculation
  private startTime = Date.now();

  // Histogram bucket boundaries (in seconds)
  private readonly bucketBoundaries = [
    0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10,
  ];

  onModuleInit() {
    // Initialize default namespaces
    ['chat', 'call', 'progress'].forEach((ns) => {
      this.activeWsConnections.set(ns, 0);
      this.wsMessagesTotal.set(ns, 0);
    });
  }

  // ==================== HTTP Metrics ====================

  recordHttpRequest(
    method: string,
    path: string,
    statusCode: number,
    durationMs: number,
  ) {
    const key = `${method}:${this.normalizePath(path)}:${statusCode}`;
    const durationSec = durationMs / 1000;

    // Increment request counter
    this.httpRequestsTotal.set(key, (this.httpRequestsTotal.get(key) || 0) + 1);

    // Track errors (4xx, 5xx)
    if (statusCode >= 400) {
      const errorKey = `${method}:${this.normalizePath(path)}:${Math.floor(statusCode / 100)}xx`;
      this.httpRequestErrorsTotal.set(
        errorKey,
        (this.httpRequestErrorsTotal.get(errorKey) || 0) + 1,
      );
    }

    // Update histogram
    const histKey = `${method}:${this.normalizePath(path)}`;
    this.httpRequestDuration.sum.set(
      histKey,
      (this.httpRequestDuration.sum.get(histKey) || 0) + durationSec,
    );
    this.httpRequestDuration.count.set(
      histKey,
      (this.httpRequestDuration.count.get(histKey) || 0) + 1,
    );

    // Update buckets
    if (!this.httpRequestDuration.buckets.has(histKey)) {
      this.httpRequestDuration.buckets.set(
        histKey,
        this.bucketBoundaries.map((le) => ({ le, count: 0 })),
      );
    }
    const buckets = this.httpRequestDuration.buckets.get(histKey)!;
    for (const bucket of buckets) {
      if (durationSec <= bucket.le) {
        bucket.count++;
      }
    }
  }

  // ==================== WebSocket Metrics ====================

  recordWsConnect(namespace: string) {
    this.wsConnectionsTotal++;
    this.activeWsConnections.set(
      namespace,
      (this.activeWsConnections.get(namespace) || 0) + 1,
    );
  }

  recordWsDisconnect(namespace: string) {
    this.wsDisconnectsTotal++;
    const current = this.activeWsConnections.get(namespace) || 0;
    this.activeWsConnections.set(namespace, Math.max(0, current - 1));
  }

  recordWsMessage(namespace: string, event: string) {
    const key = `${namespace}:${event}`;
    this.wsMessagesTotal.set(key, (this.wsMessagesTotal.get(key) || 0) + 1);
  }

  // ==================== Application Metrics ====================

  recordUpload(sizeBytes: number) {
    this.uploadSizeTotal += sizeBytes;
    this.uploadCount++;
  }

  recordCacheHit() {
    this.cacheHits++;
  }

  recordCacheMiss() {
    this.cacheMisses++;
  }

  setActiveUsers(count: number) {
    this.activeUsers = count;
  }

  // ==================== Prometheus Output ====================

  getPrometheusMetrics(): string {
    const lines: string[] = [];
    const now = Date.now();

    // Helper to add metric with type
    const addMetric = (
      name: string,
      type: string,
      help: string,
      values: { labels?: Record<string, string>; value: number }[],
    ) => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} ${type}`);
      for (const v of values) {
        const labelStr = v.labels
          ? `{${Object.entries(v.labels)
              .map(([k, val]) => `${k}="${val}"`)
              .join(',')}}`
          : '';
        lines.push(`${name}${labelStr} ${v.value}`);
      }
    };

    // Process info
    addMetric('process_uptime_seconds', 'gauge', 'Process uptime in seconds', [
      { value: (now - this.startTime) / 1000 },
    ]);

    // Memory metrics
    const mem = process.memoryUsage();
    addMetric(
      'nodejs_heap_size_total_bytes',
      'gauge',
      'Process heap size total',
      [{ value: mem.heapTotal }],
    );
    addMetric(
      'nodejs_heap_size_used_bytes',
      'gauge',
      'Process heap size used',
      [{ value: mem.heapUsed }],
    );
    addMetric(
      'nodejs_external_memory_bytes',
      'gauge',
      'Node.js external memory',
      [{ value: mem.external }],
    );

    // HTTP requests total
    const httpValues: { labels: Record<string, string>; value: number }[] = [];
    this.httpRequestsTotal.forEach((count, key) => {
      const [method, path, status] = key.split(':');
      httpValues.push({
        labels: { method, path, status },
        value: count,
      });
    });
    if (httpValues.length > 0) {
      addMetric(
        'http_requests_total',
        'counter',
        'Total HTTP requests',
        httpValues,
      );
    }

    // HTTP request errors
    const errorValues: { labels: Record<string, string>; value: number }[] = [];
    this.httpRequestErrorsTotal.forEach((count, key) => {
      const [method, path, status] = key.split(':');
      errorValues.push({
        labels: { method, path, status },
        value: count,
      });
    });
    if (errorValues.length > 0) {
      addMetric(
        'http_request_errors_total',
        'counter',
        'Total HTTP errors',
        errorValues,
      );
    }

    // HTTP request duration histogram
    lines.push(
      '# HELP http_request_duration_seconds Request duration histogram',
    );
    lines.push('# TYPE http_request_duration_seconds histogram');
    this.httpRequestDuration.buckets.forEach((buckets, key) => {
      const [method, path] = key.split(':');
      for (const bucket of buckets) {
        lines.push(
          `http_request_duration_seconds_bucket{method="${method}",path="${path}",le="${bucket.le}"} ${bucket.count}`,
        );
      }
      lines.push(
        `http_request_duration_seconds_bucket{method="${method}",path="${path}",le="+Inf"} ${this.httpRequestDuration.count.get(key) || 0}`,
      );
      lines.push(
        `http_request_duration_seconds_sum{method="${method}",path="${path}"} ${this.httpRequestDuration.sum.get(key) || 0}`,
      );
      lines.push(
        `http_request_duration_seconds_count{method="${method}",path="${path}"} ${this.httpRequestDuration.count.get(key) || 0}`,
      );
    });

    // WebSocket metrics
    addMetric(
      'websocket_connections_total',
      'counter',
      'Total WebSocket connections',
      [{ value: this.wsConnectionsTotal }],
    );
    addMetric(
      'websocket_disconnections_total',
      'counter',
      'Total WebSocket disconnections',
      [{ value: this.wsDisconnectsTotal }],
    );

    const wsActiveValues: { labels: Record<string, string>; value: number }[] =
      [];
    this.activeWsConnections.forEach((count, namespace) => {
      wsActiveValues.push({
        labels: { namespace },
        value: count,
      });
    });
    addMetric(
      'websocket_active_connections',
      'gauge',
      'Active WebSocket connections by namespace',
      wsActiveValues,
    );

    const wsMessageValues: {
      labels: Record<string, string>;
      value: number;
    }[] = [];
    this.wsMessagesTotal.forEach((count, key) => {
      const [namespace, event] = key.split(':');
      wsMessageValues.push({
        labels: { namespace, event: event || 'unknown' },
        value: count,
      });
    });
    if (wsMessageValues.length > 0) {
      addMetric(
        'websocket_messages_total',
        'counter',
        'Total WebSocket messages',
        wsMessageValues,
      );
    }

    // Application metrics
    addMetric('uploads_total', 'counter', 'Total file uploads', [
      { value: this.uploadCount },
    ]);
    addMetric('uploads_bytes_total', 'counter', 'Total bytes uploaded', [
      { value: this.uploadSizeTotal },
    ]);
    addMetric('cache_hits_total', 'counter', 'Total cache hits', [
      { value: this.cacheHits },
    ]);
    addMetric('cache_misses_total', 'counter', 'Total cache misses', [
      { value: this.cacheMisses },
    ]);
    addMetric('active_users', 'gauge', 'Number of active users', [
      { value: this.activeUsers },
    ]);

    return lines.join('\n');
  }

  // ==================== JSON Output ====================

  getMetricsJson() {
    const mem = process.memoryUsage();
    const cpu = process.cpuUsage();

    return {
      timestamp: new Date().toISOString(),
      uptime: (Date.now() - this.startTime) / 1000,
      process: {
        memory: {
          heapTotal: mem.heapTotal,
          heapUsed: mem.heapUsed,
          external: mem.external,
          rss: mem.rss,
        },
        cpu: {
          user: cpu.user,
          system: cpu.system,
        },
      },
      http: {
        requestsTotal: Object.fromEntries(this.httpRequestsTotal),
        errorsTotal: Object.fromEntries(this.httpRequestErrorsTotal),
        avgDuration: this.calculateAvgDurations(),
      },
      websocket: {
        connectionsTotal: this.wsConnectionsTotal,
        disconnectsTotal: this.wsDisconnectsTotal,
        activeConnections: Object.fromEntries(this.activeWsConnections),
        messagesTotal: Object.fromEntries(this.wsMessagesTotal),
      },
      application: {
        uploads: {
          count: this.uploadCount,
          totalBytes: this.uploadSizeTotal,
        },
        cache: {
          hits: this.cacheHits,
          misses: this.cacheMisses,
          hitRate:
            this.cacheHits + this.cacheMisses > 0
              ? this.cacheHits / (this.cacheHits + this.cacheMisses)
              : 0,
        },
        activeUsers: this.activeUsers,
      },
    };
  }

  private calculateAvgDurations(): Record<string, number> {
    const result: Record<string, number> = {};
    this.httpRequestDuration.sum.forEach((sum, key) => {
      const count = this.httpRequestDuration.count.get(key) || 1;
      result[key] = sum / count;
    });
    return result;
  }

  private normalizePath(path: string): string {
    // Normalize paths to reduce cardinality
    // Replace UUIDs and numeric IDs with placeholders
    return path
      .replace(
        /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi,
        ':id',
      )
      .replace(/\/\d+/g, '/:id')
      .replace(/\?.*/g, ''); // Remove query strings
  }
}
