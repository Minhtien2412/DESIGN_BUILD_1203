import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RedisCacheService } from './redis-cache.service';

@ApiTags('cache')
@Controller({
  path: 'cache',
  version: '1',
})
export class CacheController {
  constructor(private readonly cacheService: RedisCacheService) {}

  @Get('health')
  @ApiOperation({ summary: 'Check cache health' })
  @ApiResponse({ status: 200, description: 'Cache health status' })
  async healthCheck() {
    const isHealthy = await this.cacheService.isHealthy();
    return {
      status: isHealthy ? 'healthy' : 'degraded',
      timestamp: new Date().toISOString(),
      type: 'redis',
    };
  }

  @Get('test')
  @ApiOperation({ summary: 'Test cache operations' })
  @ApiQuery({ name: 'key', required: false })
  @ApiQuery({ name: 'value', required: false })
  async testCache(@Query('key') key?: string, @Query('value') value?: string) {
    const testKey = key || 'test:key';
    const testValue = value || `test-value-${Date.now()}`;

    // Set value
    const startSet = Date.now();
    await this.cacheService.set(testKey, testValue, 60);
    const setTime = Date.now() - startSet;

    // Get value
    const startGet = Date.now();
    const retrieved = await this.cacheService.get<string>(testKey);
    const getTime = Date.now() - startGet;

    // Delete value
    const startDel = Date.now();
    await this.cacheService.del(testKey);
    const delTime = Date.now() - startDel;

    return {
      success: retrieved === testValue,
      key: testKey,
      value: testValue,
      retrieved,
      timing: {
        set: `${setTime}ms`,
        get: `${getTime}ms`,
        del: `${delTime}ms`,
        total: `${setTime + getTime + delTime}ms`,
      },
    };
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get cache statistics' })
  async getStats() {
    try {
      const store = (this.cacheService as any).cacheManager?.store;
      if (store?.client?.info) {
        const info = await store.client.info('stats');
        return {
          raw: info,
          parsed: this.parseRedisInfo(info),
        };
      }
      return { message: 'Stats not available for current cache store' };
    } catch (error) {
      return { error: error.message };
    }
  }

  private parseRedisInfo(info: string): Record<string, string> {
    const result: Record<string, string> = {};
    info.split('\r\n').forEach((line) => {
      const [key, value] = line.split(':');
      if (key && value) {
        result[key] = value;
      }
    });
    return result;
  }
}
