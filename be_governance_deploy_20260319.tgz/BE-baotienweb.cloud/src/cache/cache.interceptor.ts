import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
    SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable, of, tap } from 'rxjs';
import { RedisCacheService } from './redis-cache.service';

export const CACHE_KEY = 'cache_key';
export const CACHE_TTL = 'cache_ttl';

/**
 * Decorator to cache endpoint responses
 * @param key - Cache key template (supports :param placeholders)
 * @param ttl - TTL in seconds (default: 300)
 */
export function CacheResponse(key: string, ttl: number = 300) {
  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor,
  ) {
    SetMetadata(CACHE_KEY, key)(target, propertyKey, descriptor);
    SetMetadata(CACHE_TTL, ttl)(target, propertyKey, descriptor);
    return descriptor;
  };
}

/**
 * Interceptor that handles caching based on @CacheResponse decorator
 */
@Injectable()
export class CacheInterceptor implements NestInterceptor {
  constructor(
    private reflector: Reflector,
    private cacheService: RedisCacheService,
  ) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const cacheKey = this.reflector.get<string>(
      CACHE_KEY,
      context.getHandler(),
    );
    const cacheTtl = this.reflector.get<number>(
      CACHE_TTL,
      context.getHandler(),
    );

    // No cache decorator, proceed normally
    if (!cacheKey) {
      return next.handle();
    }

    const request = context.switchToHttp().getRequest();

    // Build actual cache key by replacing placeholders
    let actualKey = cacheKey;
    Object.keys(request.params || {}).forEach((param) => {
      actualKey = actualKey.replace(`:${param}`, request.params[param]);
    });

    // Add query params to key if present
    if (Object.keys(request.query || {}).length > 0) {
      actualKey += `:${JSON.stringify(request.query)}`;
    }

    // Try to get from cache
    const cached = await this.cacheService.get(actualKey);
    if (cached !== undefined) {
      return of(cached);
    }

    // Execute handler and cache result
    return next.handle().pipe(
      tap(async (data) => {
        await this.cacheService.set(actualKey, data, cacheTtl);
      }),
    );
  }
}

/**
 * Decorator to invalidate cache on mutation
 * @param patterns - Cache key patterns to invalidate
 */
export function InvalidateCache(...patterns: string[]) {
  return SetMetadata('invalidate_cache', patterns);
}

/**
 * Interceptor that invalidates cache based on @InvalidateCache decorator
 */
@Injectable()
export class CacheInvalidationInterceptor implements NestInterceptor {
  constructor(
    private reflector: Reflector,
    private cacheService: RedisCacheService,
  ) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const patterns = this.reflector.get<string[]>(
      'invalidate_cache',
      context.getHandler(),
    );

    if (!patterns || patterns.length === 0) {
      return next.handle();
    }

    return next.handle().pipe(
      tap(async () => {
        const request = context.switchToHttp().getRequest();

        for (const pattern of patterns) {
          let actualPattern = pattern;
          Object.keys(request.params || {}).forEach((param) => {
            actualPattern = actualPattern.replace(
              `:${param}`,
              request.params[param],
            );
          });
          await this.cacheService.delByPattern(actualPattern);
        }
      }),
    );
  }
}
