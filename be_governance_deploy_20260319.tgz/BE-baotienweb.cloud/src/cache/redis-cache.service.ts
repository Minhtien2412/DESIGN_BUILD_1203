import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import type { Cache } from 'cache-manager';

/**
 * Redis Cache Service
 * Provides typed methods for caching with automatic serialization
 */
@Injectable()
export class RedisCacheService {
  constructor(@Inject(CACHE_MANAGER) private cacheManager: Cache) {}

  /**
   * Get a cached value
   */
  async get<T>(key: string): Promise<T | undefined> {
    try {
      const value = await this.cacheManager.get<T>(key);
      return value;
    } catch (error) {
      console.warn(`[Cache] Get error for key ${key}:`, error);
      return undefined;
    }
  }

  /**
   * Set a cached value with optional TTL
   */
  async set<T>(key: string, value: T, ttl?: number): Promise<void> {
    try {
      await this.cacheManager.set(key, value, ttl);
    } catch (error) {
      console.warn(`[Cache] Set error for key ${key}:`, error);
    }
  }

  /**
   * Delete a cached value
   */
  async del(key: string): Promise<void> {
    try {
      await this.cacheManager.del(key);
    } catch (error) {
      console.warn(`[Cache] Delete error for key ${key}:`, error);
    }
  }

  /**
   * Get or set pattern - fetch from cache or compute and cache
   */
  async getOrSet<T>(
    key: string,
    factory: () => Promise<T>,
    ttl?: number,
  ): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== undefined) {
      return cached;
    }

    const value = await factory();
    await this.set(key, value, ttl);
    return value;
  }

  /**
   * Delete keys matching a pattern (prefix)
   * Uses Redis SCAN for pattern matching
   */
  async delByPattern(pattern: string): Promise<void> {
    try {
      // Access underlying Redis client if available
      const store = (this.cacheManager as any).store;
      if (store?.client?.scan) {
        const client = store.client;
        let cursor = 0;
        const keysToDelete: string[] = [];

        do {
          const [newCursor, keys] = await client.scan(
            cursor,
            'MATCH',
            `${pattern}*`,
            'COUNT',
            100,
          );
          cursor = parseInt(newCursor, 10);
          keysToDelete.push(...keys);
        } while (cursor !== 0);

        if (keysToDelete.length > 0) {
          await Promise.all(keysToDelete.map((key) => this.del(key)));
        }
      } else {
        // Fallback to single delete
        await this.del(pattern);
      }
    } catch (error) {
      console.warn(`[Cache] Pattern delete error for ${pattern}:`, error);
    }
  }

  /**
   * Reset entire cache (use with caution)
   * Note: cache-manager v5 doesn't have reset, using store.reset if available
   */
  async reset(): Promise<void> {
    try {
      const store = (this.cacheManager as any).store;
      if (store?.reset) {
        await store.reset();
      } else if (store?.client?.flushDb) {
        await store.client.flushDb();
      }
    } catch (error) {
      console.warn('[Cache] Reset error:', error);
    }
  }

  /**
   * Check if cache is healthy
   */
  async isHealthy(): Promise<boolean> {
    try {
      const testKey = 'health:check';
      await this.set(testKey, 'ok', 5);
      const result = await this.get(testKey);
      return result === 'ok';
    } catch {
      return false;
    }
  }

  /**
   * Cache key generators for common patterns
   */
  static keys = {
    // User-related keys
    user: (id: number) => `user:${id}`,
    userProfile: (id: number) => `user:${id}:profile`,
    userSessions: (id: number) => `user:${id}:sessions`,

    // OTP keys
    otp: (phone: string, purpose: string) => `otp:${phone}:${purpose}`,
    otpAttempts: (phone: string) => `otp:attempts:${phone}`,

    // Product/catalog keys
    products: (page: number, limit: number) => `products:${page}:${limit}`,
    product: (id: number) => `product:${id}`,
    productSearch: (query: string) => `product:search:${query}`,

    // Project keys
    projects: (userId: number) => `projects:user:${userId}`,
    project: (id: number) => `project:${id}`,
    projectTasks: (projectId: number) => `project:${projectId}:tasks`,

    // Chat keys
    chatMessages: (roomId: number, page: number) =>
      `chat:${roomId}:messages:${page}`,
    chatRooms: (userId: number) => `chat:rooms:${userId}`,

    // Video/Reels keys
    reels: (page: number) => `reels:${page}`,
    videoMetadata: (id: string) => `video:${id}:metadata`,

    // API response cache
    apiResponse: (endpoint: string, params: string) =>
      `api:${endpoint}:${params}`,
  };

  /**
   * TTL constants (in seconds)
   */
  static TTL = {
    SHORT: 60, // 1 minute
    MEDIUM: 300, // 5 minutes
    LONG: 3600, // 1 hour
    DAY: 86400, // 24 hours
    OTP: 300, // 5 minutes for OTP
    SESSION: 604800, // 7 days for sessions
  };
}
