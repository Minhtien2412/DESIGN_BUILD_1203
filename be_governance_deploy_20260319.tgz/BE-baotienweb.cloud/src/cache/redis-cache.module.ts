import { CacheModule } from '@nestjs/cache-manager';
import { Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { redisStore } from 'cache-manager-redis-store';
import { CacheController } from './cache.controller';
import { RedisCacheService } from './redis-cache.service';

@Global()
@Module({
  imports: [
    CacheModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => {
        const redisHost = configService.get<string>('REDIS_HOST', '127.0.0.1');
        const redisPort = configService.get<number>('REDIS_PORT', 6379);
        const redisPassword = configService.get<string>('REDIS_PASSWORD', '');

        // Check if Redis is available, fallback to memory cache if not
        const useRedis =
          configService.get<string>('USE_REDIS', 'true') === 'true';

        if (useRedis) {
          try {
            const store = await redisStore({
              socket: {
                host: redisHost,
                port: redisPort,
              },
              password: redisPassword || undefined,
              ttl: 300, // Default 5 minutes
            });

            console.log(`[Cache] Redis connected at ${redisHost}:${redisPort}`);

            return {
              store: store as any,
              ttl: 300,
            };
          } catch (error) {
            console.warn(
              '[Cache] Redis connection failed, using memory cache:',
              error,
            );
            return {
              ttl: 300,
              max: 1000, // Max items in memory cache
            };
          }
        }

        console.log('[Cache] Using in-memory cache');
        return {
          ttl: 300,
          max: 1000,
        };
      },
    }),
  ],
  controllers: [CacheController],
  providers: [RedisCacheService],
  exports: [CacheModule, RedisCacheService],
})
export class RedisCacheModule {}
