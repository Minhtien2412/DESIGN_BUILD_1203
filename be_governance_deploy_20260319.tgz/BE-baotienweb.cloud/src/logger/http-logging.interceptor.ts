/**
 * HTTP Logging Interceptor (OBS-001)
 * ====================================
 *
 * Logs HTTP requests/responses with:
 * - Request ID tracking
 * - Duration measurement
 * - Status code logging
 * - Error capture
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor,
} from '@nestjs/common';
import type { Request, Response } from 'express';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { StructuredLoggerService } from './structured-logger.service';

@Injectable()
export class HttpLoggingInterceptor implements NestInterceptor {
  private readonly logger = new StructuredLoggerService();

  constructor() {
    this.logger.setContext('HTTP');
  }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    if (context.getType() !== 'http') {
      return next.handle();
    }

    const request = context.switchToHttp().getRequest<Request>();
    const response = context.switchToHttp().getResponse<Response>();
    const startTime = request.requestStartTime || Date.now();

    // Set request context for all logs in this request
    this.logger.setRequestContext({
      requestId: request.requestId,
      correlationId: request.correlationId,
      method: request.method,
      path: request.url,
      userAgent: request.headers['user-agent'],
      ip:
        (request.headers['x-forwarded-for'] as string) ||
        request.socket?.remoteAddress,
    });

    // Log incoming request (debug level)
    this.logger.debug(`→ ${request.method} ${request.url}`, {
      body: this.sanitizeBody(request.body),
      query: request.query,
      params: request.params,
    });

    return next.handle().pipe(
      tap((data) => {
        const duration = Date.now() - startTime;
        const statusCode = response.statusCode;

        // Log successful response
        this.logger.logHttpRequest(
          request.method,
          request.url,
          statusCode,
          duration,
          {
            requestId: request.requestId,
            correlationId: request.correlationId,
            userId: (request as any).user?.id,
          },
        );
      }),
      catchError((error) => {
        const duration = Date.now() - startTime;
        const statusCode = error.status || error.statusCode || 500;

        // Log error response
        this.logger.error(
          `${request.method} ${request.url} ${statusCode} ${duration}ms - ${error.message}`,
          error.stack,
          {
            requestId: request.requestId,
            correlationId: request.correlationId,
            userId: (request as any).user?.id,
            error: {
              name: error.name,
              message: error.message,
              code: error.code,
            },
          },
        );

        return throwError(() => error);
      }),
    );
  }

  private sanitizeBody(body: any): any {
    if (!body) return undefined;

    // Create a shallow copy
    const sanitized = { ...body };

    // Remove sensitive fields
    const sensitiveFields = [
      'password',
      'currentPassword',
      'newPassword',
      'confirmPassword',
      'token',
      'accessToken',
      'refreshToken',
      'apiKey',
      'secret',
      'otp',
      'totpCode',
      'code',
    ];

    for (const field of sensitiveFields) {
      if (sanitized[field]) {
        sanitized[field] = '[REDACTED]';
      }
    }

    return sanitized;
  }
}
