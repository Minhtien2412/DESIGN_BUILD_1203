/**
 * Structured Logger Service (OBS-001)
 * =====================================
 *
 * Provides structured JSON logging with:
 * - Request ID / Correlation ID tracking
 * - Sensitive data masking
 * - Log levels configuration
 * - Context propagation
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import { Injectable, LoggerService, Scope } from '@nestjs/common';
import * as winston from 'winston';

// ============================================================================
// TYPES
// ============================================================================

export interface LogContext {
  requestId?: string;
  correlationId?: string;
  userId?: number;
  sessionId?: string;
  service?: string;
  method?: string;
  path?: string;
  duration?: number;
  [key: string]: any;
}

export interface StructuredLog {
  timestamp: string;
  level: string;
  message: string;
  service: string;
  requestId?: string;
  correlationId?: string;
  userId?: number;
  context?: LogContext;
  error?: {
    name: string;
    message: string;
    stack?: string;
    code?: string;
  };
  metadata?: Record<string, any>;
}

// ============================================================================
// SENSITIVE DATA PATTERNS
// ============================================================================

const SENSITIVE_PATTERNS: Array<{ pattern: RegExp; replacement: string }> = [
  // Passwords
  {
    pattern: /"password"\s*:\s*"[^"]*"/gi,
    replacement: '"password":"[REDACTED]"',
  },
  {
    pattern: /"currentPassword"\s*:\s*"[^"]*"/gi,
    replacement: '"currentPassword":"[REDACTED]"',
  },
  {
    pattern: /"newPassword"\s*:\s*"[^"]*"/gi,
    replacement: '"newPassword":"[REDACTED]"',
  },

  // Tokens
  {
    pattern: /"accessToken"\s*:\s*"[^"]*"/gi,
    replacement: '"accessToken":"[REDACTED]"',
  },
  {
    pattern: /"refreshToken"\s*:\s*"[^"]*"/gi,
    replacement: '"refreshToken":"[REDACTED]"',
  },
  { pattern: /"token"\s*:\s*"[^"]*"/gi, replacement: '"token":"[REDACTED]"' },
  { pattern: /Bearer\s+[A-Za-z0-9\-_\.]+/gi, replacement: 'Bearer [REDACTED]' },

  // API Keys
  { pattern: /"apiKey"\s*:\s*"[^"]*"/gi, replacement: '"apiKey":"[REDACTED]"' },
  {
    pattern: /"api_key"\s*:\s*"[^"]*"/gi,
    replacement: '"api_key":"[REDACTED]"',
  },
  { pattern: /"secret"\s*:\s*"[^"]*"/gi, replacement: '"secret":"[REDACTED]"' },

  // Credit Card Numbers (basic pattern)
  {
    pattern: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
    replacement: '[CARD REDACTED]',
  },

  // SSN patterns
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/g, replacement: '[SSN REDACTED]' },

  // Email in certain contexts (optional - comment out if not needed)
  // { pattern: /"email"\s*:\s*"[^"]*@[^"]*"/gi, replacement: '"email":"[EMAIL REDACTED]"' },

  // OTP/2FA codes
  { pattern: /"otp"\s*:\s*"\d+"/gi, replacement: '"otp":"[REDACTED]"' },
  { pattern: /"code"\s*:\s*"\d{6}"/gi, replacement: '"code":"[REDACTED]"' },
  {
    pattern: /"totpCode"\s*:\s*"\d+"/gi,
    replacement: '"totpCode":"[REDACTED]"',
  },
];

// ============================================================================
// SERVICE
// ============================================================================

@Injectable({ scope: Scope.TRANSIENT })
export class StructuredLoggerService implements LoggerService {
  private context: string = 'Application';
  private requestContext: LogContext = {};
  private logger: winston.Logger;

  constructor() {
    this.logger = winston.createLogger({
      level:
        process.env.LOG_LEVEL ||
        (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DDTHH:mm:ss.SSSZ' }),
        winston.format.errors({ stack: true }),
        winston.format.json(),
      ),
      defaultMeta: {
        service: process.env.SERVICE_NAME || 'baotienweb-api',
        environment: process.env.NODE_ENV || 'development',
      },
      transports: [
        // JSON output for production (for log aggregators like ELK/Loki)
        new winston.transports.Console({
          format:
            process.env.NODE_ENV === 'production'
              ? winston.format.json()
              : winston.format.combine(
                  winston.format.colorize(),
                  winston.format.printf(
                    ({ timestamp, level, message, ...meta }) => {
                      const reqId = meta.requestId
                        ? `[${String(meta.requestId).slice(0, 12)}]`
                        : '';
                      const ctx = meta.context || this.context;
                      return `${timestamp} ${level} ${reqId} [${ctx}] ${message}`;
                    },
                  ),
                ),
        }),
        // Error log file
        new winston.transports.File({
          filename: 'logs/error.log',
          level: 'error',
          maxsize: 10 * 1024 * 1024, // 10MB
          maxFiles: 5,
          tailable: true,
        }),
        // Combined log file
        new winston.transports.File({
          filename: 'logs/combined.log',
          maxsize: 10 * 1024 * 1024, // 10MB
          maxFiles: 10,
          tailable: true,
        }),
      ],
    });
  }

  // ============================================
  // CONTEXT MANAGEMENT
  // ============================================

  setContext(context: string): this {
    this.context = context;
    return this;
  }

  setRequestContext(context: LogContext): this {
    this.requestContext = { ...this.requestContext, ...context };
    return this;
  }

  clearRequestContext(): this {
    this.requestContext = {};
    return this;
  }

  // ============================================
  // LOGGING METHODS
  // ============================================

  log(message: any, context?: string | LogContext): void {
    this.writeLog('info', message, context);
  }

  error(message: any, trace?: string, context?: string | LogContext): void {
    const errorMeta: any = {};

    if (message instanceof Error) {
      errorMeta.error = {
        name: message.name,
        message: message.message,
        stack: message.stack,
        code: (message as any).code,
      };
      message = message.message;
    } else if (trace) {
      errorMeta.error = { stack: trace };
    }

    this.writeLog('error', message, context, errorMeta);
  }

  warn(message: any, context?: string | LogContext): void {
    this.writeLog('warn', message, context);
  }

  debug(message: any, context?: string | LogContext): void {
    this.writeLog('debug', message, context);
  }

  verbose(message: any, context?: string | LogContext): void {
    this.writeLog('verbose', message, context);
  }

  // ============================================
  // HTTP REQUEST LOGGING
  // ============================================

  logHttpRequest(
    method: string,
    path: string,
    statusCode: number,
    duration: number,
    context?: LogContext,
  ): void {
    const level =
      statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'info';

    this.writeLog(level, `${method} ${path} ${statusCode} ${duration}ms`, {
      ...context,
      http: {
        method,
        path,
        statusCode,
        duration,
      },
    });
  }

  // ============================================
  // AUDIT LOGGING
  // ============================================

  logAudit(
    action: string,
    resource: string,
    userId?: number,
    details?: Record<string, any>,
  ): void {
    this.writeLog('info', `AUDIT: ${action} on ${resource}`, {
      audit: {
        action,
        resource,
        userId,
        details: details
          ? this.maskSensitiveData(JSON.stringify(details))
          : undefined,
      },
    });
  }

  // ============================================
  // SECURITY LOGGING
  // ============================================

  logSecurity(
    event: string,
    severity: 'low' | 'medium' | 'high' | 'critical',
    details?: Record<string, any>,
  ): void {
    const level =
      severity === 'critical' || severity === 'high' ? 'error' : 'warn';

    this.writeLog(level, `SECURITY: ${event}`, {
      security: {
        event,
        severity,
        details,
      },
    });
  }

  // ============================================
  // PRIVATE METHODS
  // ============================================

  private writeLog(
    level: string,
    message: any,
    context?: string | LogContext,
    additionalMeta?: Record<string, any>,
  ): void {
    const logContext = typeof context === 'string' ? { context } : context;

    // Build metadata
    const meta: Record<string, any> = {
      context: typeof context === 'string' ? context : this.context,
      ...this.requestContext,
      ...logContext,
      ...additionalMeta,
    };

    // Mask sensitive data in message
    const maskedMessage =
      typeof message === 'string' ? this.maskSensitiveData(message) : message;

    // Write log
    this.logger.log(level, maskedMessage, meta);
  }

  private maskSensitiveData(data: string): string {
    let masked = data;

    for (const { pattern, replacement } of SENSITIVE_PATTERNS) {
      masked = masked.replace(pattern, replacement);
    }

    return masked;
  }
}

// ============================================================================
// FACTORY FOR NestJS
// ============================================================================

export function createStructuredLogger(
  context?: string,
): StructuredLoggerService {
  const logger = new StructuredLoggerService();
  if (context) {
    logger.setContext(context);
  }
  return logger;
}
