/**
 * Logger Module (OBS-001)
 * ========================
 *
 * Provides structured logging across the application
 *
 * @author BaoTienWeb Team
 * @created 2026-01-22
 */

import { Global, Module } from '@nestjs/common';
import { HttpLoggingInterceptor } from './http-logging.interceptor';
import { StructuredLoggerService } from './structured-logger.service';

@Global()
@Module({
  providers: [StructuredLoggerService, HttpLoggingInterceptor],
  exports: [StructuredLoggerService, HttpLoggingInterceptor],
})
export class LoggerModule {}
