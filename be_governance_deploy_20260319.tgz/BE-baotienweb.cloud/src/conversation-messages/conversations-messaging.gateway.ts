/**
 * Conversations Messaging Gateway
 * ================================
 *
 * WebSocket Gateway cho realtime messaging trong conversations
 *
 * Events:
 * - Client → Server:
 *   - conversation.join    : Join conversation room
 *   - conversation.leave   : Leave conversation room
 *   - message.send         : Gửi tin nhắn
 *   - message.read         : Đánh dấu đã đọc
 *   - typing.start         : Bắt đầu typing
 *   - typing.stop          : Dừng typing
 *
 * - Server → Client:
 *   - message.new          : Tin nhắn mới
 *   - message.updated      : Tin nhắn đã chỉnh sửa
 *   - message.deleted      : Tin nhắn đã xóa
 *   - message.ack          : Xác nhận gửi thành công
 *   - read.receipt         : Đã đọc notification
 *   - typing               : Typing indicator
 *   - presence             : User online/offline
 *
 * @author ThietKeResort Team
 * @created 2026-01-22
 */

import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import {
    ConnectedSocket,
    MessageBody,
    OnGatewayConnection,
    OnGatewayDisconnect,
    OnGatewayInit,
    SubscribeMessage,
    WebSocketGateway,
    WebSocketServer,
    WsException,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { PrismaService } from '../prisma/prisma.service';
import { SendMessageDto } from './dto';

// ============================================================================
// Types
// ============================================================================

interface AuthenticatedSocket extends Socket {
  data: {
    userId: number;
    name?: string;
  };
}

interface JoinConversationPayload {
  conversationId: string;
}

interface TypingPayload {
  conversationId: string;
  isTyping: boolean;
}

interface ReadPayload {
  conversationId: string;
  messageId?: string;
}

interface SendMessagePayload extends SendMessageDto {
  conversationId: string;
}

// ============================================================================
// Gateway
// ============================================================================

@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/conversations',
  transports: ['websocket', 'polling'],
})
export class ConversationsMessagingGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(ConversationsMessagingGateway.name);

  // Track user sockets: Map<userId, Set<socketId>>
  private userSockets: Map<number, Set<string>> = new Map();
  // Reverse lookup: Map<socketId, userId>
  private socketUsers: Map<string, number> = new Map();
  // Typing users per conversation: Map<conversationId, Set<userId>>
  private typingUsers: Map<string, Set<number>> = new Map();

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  // ============================================================================
  // Lifecycle Hooks
  // ============================================================================

  afterInit(server: Server) {
    this.logger.log('Conversations Messaging Gateway initialized');
  }

  async handleConnection(client: AuthenticatedSocket) {
    try {
      const userId = await this.authenticateSocket(client);
      if (!userId) {
        client.disconnect();
        return;
      }

      // Store mapping
      this.addUserSocket(userId, client.id);
      client.data.userId = userId;

      this.logger.log(`User ${userId} connected via socket ${client.id}`);

      // Auto-join user's conversations
      await this.autoJoinConversations(client, userId);

      // Broadcast presence
      this.broadcastPresence(userId, true);
    } catch (error: any) {
      this.logger.error(`Connection error: ${error.message}`);
      client.disconnect();
    }
  }

  handleDisconnect(client: AuthenticatedSocket) {
    const userId = this.socketUsers.get(client.id);
    if (userId) {
      this.removeUserSocket(userId, client.id);
      this.logger.log(`User ${userId} socket ${client.id} disconnected`);

      // If no more sockets, broadcast offline
      const remaining = this.userSockets.get(userId);
      if (!remaining || remaining.size === 0) {
        this.broadcastPresence(userId, false);
      }
    }
  }

  // ============================================================================
  // Client Events
  // ============================================================================

  /**
   * Join conversation room
   */
  @SubscribeMessage('conversation.join')
  async handleJoinConversation(
    @MessageBody() payload: JoinConversationPayload,
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    const userId = client.data.userId;
    const { conversationId } = payload;

    // Validate membership
    const participant = await this.prisma.conversationParticipant.findUnique({
      where: {
        conversationId_userId: { conversationId, userId },
      },
    });

    if (!participant || participant.leftAt || participant.removedAt) {
      throw new WsException('Không phải thành viên của conversation này');
    }

    const roomName = `conv:${conversationId}`;
    client.join(roomName);
    this.logger.debug(`User ${userId} joined room ${roomName}`);

    return { success: true, conversationId };
  }

  /**
   * Leave conversation room
   */
  @SubscribeMessage('conversation.leave')
  handleLeaveConversation(
    @MessageBody() payload: JoinConversationPayload,
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    const { conversationId } = payload;
    const roomName = `conv:${conversationId}`;
    client.leave(roomName);

    // Clear typing if user was typing
    this.clearTyping(conversationId, client.data.userId);

    return { success: true };
  }

  /**
   * Send message via WebSocket
   * Note: Client should use REST API to send messages, this just handles the ack
   * The service will emit message.new via gateway
   */
  @SubscribeMessage('message.send')
  async handleSendMessage(
    @MessageBody() payload: SendMessagePayload,
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    // For WebSocket send, client should call REST API instead
    // This event is kept for backwards compatibility / future direct WS send
    throw new WsException('Vui lòng sử dụng REST API để gửi tin nhắn');
  }

  /**
   * Mark messages as read
   */
  @SubscribeMessage('message.read')
  async handleMarkRead(
    @MessageBody() payload: ReadPayload,
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    const userId = client.data.userId;
    const { conversationId, messageId } = payload;

    try {
      // Update read status in DB
      const participant = await this.prisma.conversationParticipant.findUnique({
        where: {
          conversationId_userId: { conversationId, userId },
        },
      });

      if (!participant) {
        throw new WsException('Không phải thành viên');
      }

      // Get message seq if messageId provided
      let lastReadSeq = participant.lastReadSeq || 0;
      if (messageId) {
        const message = await this.prisma.conversationMessage.findUnique({
          where: { id: messageId },
          select: { seq: true },
        });
        if (message) {
          lastReadSeq = Math.max(lastReadSeq, message.seq);
        }
      } else {
        // Mark all as read - get latest seq
        const latestMsg = await this.prisma.conversationMessage.findFirst({
          where: { conversationId },
          orderBy: { seq: 'desc' },
          select: { seq: true },
        });
        if (latestMsg) {
          lastReadSeq = latestMsg.seq;
        }
      }

      // Update participant
      await this.prisma.conversationParticipant.update({
        where: {
          conversationId_userId: { conversationId, userId },
        },
        data: {
          lastReadSeq,
          unreadCount: 0,
        },
      });

      // Broadcast read receipt
      const roomName = `conv:${conversationId}`;
      this.server.to(roomName).emit('read.receipt', {
        conversationId,
        userId,
        lastReadSeq,
        readAt: new Date().toISOString(),
      });

      return { success: true, lastReadSeq };
    } catch (error: any) {
      this.logger.error(`Mark read error: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  /**
   * Typing indicator
   */
  @SubscribeMessage('typing')
  handleTyping(
    @MessageBody() payload: TypingPayload,
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    const userId = client.data.userId;
    const { conversationId, isTyping } = payload;

    if (isTyping) {
      this.setTyping(conversationId, userId);
    } else {
      this.clearTyping(conversationId, userId);
    }

    // Broadcast to others in room
    const roomName = `conv:${conversationId}`;
    client.to(roomName).emit('typing', {
      conversationId,
      userId,
      isTyping,
    });

    return { success: true };
  }

  // ============================================================================
  // Public Methods (called from MessagesService)
  // ============================================================================

  /**
   * Broadcast new message to conversation participants
   */
  emitNewMessage(conversationId: string, message: any) {
    const roomName = `conv:${conversationId}`;
    this.server.to(roomName).emit('message.new', {
      conversationId,
      message,
    });
  }

  /**
   * Broadcast message update
   */
  emitMessageUpdated(conversationId: string, message: any) {
    const roomName = `conv:${conversationId}`;
    this.server.to(roomName).emit('message.updated', {
      conversationId,
      message,
    });
  }

  /**
   * Broadcast message deleted
   */
  emitMessageDeleted(conversationId: string, messageId: string) {
    const roomName = `conv:${conversationId}`;
    this.server.to(roomName).emit('message.deleted', {
      conversationId,
      messageId,
    });
  }

  /**
   * Broadcast read receipt
   */
  emitReadReceipt(
    conversationId: string,
    receipt: {
      userId: number;
      userName: string;
      avatar?: string | null;
      lastReadSeq: number;
      readAt: Date;
    },
  ) {
    const roomName = `conv:${conversationId}`;
    this.server.to(roomName).emit('read.receipt', {
      conversationId,
      ...receipt,
    });
  }

  /**
   * Broadcast reaction
   */
  emitReaction(
    conversationId: string,
    data: {
      messageId: string;
      userId: number;
      emoji: string;
      action: 'add' | 'remove';
    },
  ) {
    const roomName = `conv:${conversationId}`;
    this.server.to(roomName).emit('message.reaction', {
      conversationId,
      ...data,
    });
  }

  /**
   * Send to specific user (all their sockets)
   */
  emitToUser(userId: number, event: string, data: any) {
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      sockets.forEach((socketId) => {
        this.server.to(socketId).emit(event, data);
      });
    }
  }

  // ============================================================================
  // Private Helpers
  // ============================================================================

  private async authenticateSocket(client: Socket): Promise<number | null> {
    try {
      const token =
        client.handshake.auth?.token ||
        client.handshake.headers?.authorization?.replace('Bearer ', '') ||
        (client.handshake.query?.token as string);

      if (!token) {
        this.logger.warn('No token provided');
        return null;
      }

      const payload = this.jwtService.verify(token);
      return payload.sub || payload.userId;
    } catch (error: any) {
      this.logger.warn(`Auth failed: ${error.message}`);
      return null;
    }
  }

  private addUserSocket(userId: number, socketId: string) {
    if (!this.userSockets.has(userId)) {
      this.userSockets.set(userId, new Set());
    }
    this.userSockets.get(userId)!.add(socketId);
    this.socketUsers.set(socketId, userId);
  }

  private removeUserSocket(userId: number, socketId: string) {
    this.userSockets.get(userId)?.delete(socketId);
    this.socketUsers.delete(socketId);
    if (this.userSockets.get(userId)?.size === 0) {
      this.userSockets.delete(userId);
    }
  }

  private async autoJoinConversations(client: Socket, userId: number) {
    try {
      const participants = await this.prisma.conversationParticipant.findMany({
        where: {
          userId,
          leftAt: null,
          removedAt: null,
        },
        select: { conversationId: true },
      });

      participants.forEach((p) => {
        client.join(`conv:${p.conversationId}`);
      });

      this.logger.debug(
        `User ${userId} auto-joined ${participants.length} conversations`,
      );
    } catch (error: any) {
      this.logger.error(`Auto-join error: ${error.message}`);
    }
  }

  private broadcastPresence(userId: number, isOnline: boolean) {
    this.server.emit('presence', {
      userId,
      isOnline,
      timestamp: new Date().toISOString(),
    });
  }

  private setTyping(conversationId: string, userId: number) {
    if (!this.typingUsers.has(conversationId)) {
      this.typingUsers.set(conversationId, new Set());
    }
    this.typingUsers.get(conversationId)!.add(userId);

    // Auto-clear after 10 seconds
    setTimeout(() => this.clearTyping(conversationId, userId), 10000);
  }

  private clearTyping(conversationId: string, userId: number) {
    this.typingUsers.get(conversationId)?.delete(userId);
  }
}
