/**
 * Global Search Controller
 * ========================
 *
 * Global search endpoints across all user's conversations
 *
 * Endpoints:
 * - GET /messages/search - Search messages globally
 * - GET /messages/unread-counts - Get unread counts
 */

import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { GlobalSearchQueryDto, GlobalSearchResponseDto } from './dto';
import { MessagesService } from './messages.service';

@ApiTags('Message Search')
@ApiBearerAuth()
@Controller({ path: 'messages', version: '1' })
@UseGuards(JwtAuthGuard)
export class SearchController {
  constructor(private readonly messagesService: MessagesService) {}

  /**
   * Global search tin nhắn trong tất cả conversations của user
   *
   * GET /messages/search
   *
   * Query params:
   * - q: Search query (required)
   * - limit: Max results (default 20)
   * - conversationId: Filter by specific conversation
   * - type: Filter by message type (TEXT, IMAGE, etc.)
   * - fromDate: Filter from date (ISO string)
   * - toDate: Filter to date (ISO string)
   * - senderId: Filter by sender
   */
  @Get('search')
  @ApiOperation({ summary: 'Global search across all conversations' })
  async globalSearch(
    @Query() query: GlobalSearchQueryDto,
    @CurrentUser('id') userId: number,
  ): Promise<GlobalSearchResponseDto> {
    return this.messagesService.globalSearchMessages(userId, query);
  }

  /**
   * Get unread counts for all conversations
   *
   * GET /messages/unread-counts
   */
  @Get('unread-counts')
  @ApiOperation({ summary: 'Get unread message counts per conversation' })
  async getUnreadCounts(
    @CurrentUser('id') userId: number,
  ): Promise<{ conversationId: string; unreadCount: number }[]> {
    return this.messagesService.getUnreadCounts(userId);
  }
}
