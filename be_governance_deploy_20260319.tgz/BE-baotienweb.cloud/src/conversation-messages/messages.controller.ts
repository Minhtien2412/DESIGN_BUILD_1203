/**
 * Messages Controller
 * ===================
 *
 * REST API endpoints cho messages
 *
 * Endpoints:
 * - POST   /conversations/:id/messages       - Gửi tin nhắn
 * - GET    /conversations/:id/messages       - Lấy danh sách tin nhắn
 * - GET    /conversations/:id/messages/:msgId - Lấy tin nhắn cụ thể
 * - PATCH  /conversations/:id/messages/:msgId - Sửa tin nhắn
 * - DELETE /conversations/:id/messages/:msgId - Xóa tin nhắn
 * - POST   /conversations/:id/messages/:msgId/reactions - Thêm reaction
 * - DELETE /conversations/:id/messages/:msgId/reactions/:emoji - Xóa reaction
 * - GET    /conversations/:id/messages/search - Tìm kiếm tin nhắn
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import {
    AddReactionDto,
    DeleteMessageDto,
    GetMessagesQueryDto,
    MarkAsReadDto,
    MessageListResponseDto,
    MessageResponseDto,
    ReadReceiptsResponseDto,
    SearchMessagesQueryDto,
    SendMessageDto,
    UpdateMessageDto,
} from './dto';
import { MessagesService } from './messages.service';

import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Conversation Messages')
@ApiBearerAuth()
@Controller({ path: 'conversations/:conversationId/messages', version: '1' })
@UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  // ============================================
  // SEND MESSAGE
  // ============================================

  /**
   * Gửi tin nhắn qua REST API
   *
   * POST /conversations/:conversationId/messages
   *
   * Body:
   * {
   *   "clientMessageId": "uuid-v4", // Required for idempotency
   *   "type": "TEXT",
   *   "content": "Hello world",
   *   "attachments": [...],
   *   "replyToMessageId": "msg-id"
   * }
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Send a message in a conversation' })
  async sendMessage(
    @Param('conversationId') conversationId: string,
    @Body() dto: SendMessageDto,
    @CurrentUser('id') userId: number,
  ): Promise<MessageResponseDto> {
    return this.messagesService.sendMessage(conversationId, userId, dto);
  }

  // ============================================
  // GET MESSAGES
  // ============================================

  /**
   * Lấy danh sách tin nhắn với cursor-based pagination
   *
   * GET /conversations/:conversationId/messages
   *
   * Query params:
   * - cursor: messageId để load từ đó
   * - direction: 'before' (older) hoặc 'after' (newer)
   * - limit: số lượng (default 50, max 100)
   * - aroundSeq: load messages xung quanh seq number
   */
  @Get()
  @ApiOperation({ summary: 'Get messages with cursor-based pagination' })
  async getMessages(
    @Param('conversationId') conversationId: string,
    @Query() query: GetMessagesQueryDto,
    @CurrentUser('id') userId: number,
  ): Promise<MessageListResponseDto> {
    return this.messagesService.getMessages(conversationId, userId, query);
  }

  // ============================================
  // GET SINGLE MESSAGE
  // ============================================

  /**
   * Lấy chi tiết một tin nhắn
   *
   * GET /conversations/:conversationId/messages/:messageId
   */
  @Get(':messageId')
  @ApiOperation({ summary: 'Get a single message by ID' })
  async getMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @CurrentUser('id') userId: number,
  ): Promise<MessageResponseDto> {
    return this.messagesService.getMessage(conversationId, messageId, userId);
  }

  // ============================================
  // UPDATE MESSAGE
  // ============================================

  /**
   * Sửa nội dung tin nhắn (chỉ sender, trong 15 phút)
   *
   * PATCH /conversations/:conversationId/messages/:messageId
   *
   * Body:
   * {
   *   "content": "Updated message"
   * }
   */
  @Patch(':messageId')
  @ApiOperation({ summary: 'Edit a message (sender only, within 15 min)' })
  async updateMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Body() dto: UpdateMessageDto,
    @CurrentUser('id') userId: number,
  ): Promise<MessageResponseDto> {
    return this.messagesService.updateMessage(
      conversationId,
      messageId,
      userId,
      dto,
    );
  }

  // ============================================
  // DELETE MESSAGE
  // ============================================

  /**
   * Xóa tin nhắn
   *
   * DELETE /conversations/:conversationId/messages/:messageId
   *
   * Query:
   * - deleteForAll: true để xóa cho tất cả (chỉ sender)
   */
  @Delete(':messageId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete a message' })
  async deleteMessage(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Query() query: DeleteMessageDto,
    @CurrentUser('id') userId: number,
  ): Promise<{ success: boolean }> {
    return this.messagesService.deleteMessage(
      conversationId,
      messageId,
      userId,
      query.deleteForAll,
    );
  }

  // ============================================
  // REACTIONS
  // ============================================

  /**
   * Thêm reaction vào tin nhắn
   *
   * POST /conversations/:conversationId/messages/:messageId/reactions
   *
   * Body:
   * {
   *   "emoji": "👍"
   * }
   */
  @Post(':messageId/reactions')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Add a reaction to a message' })
  async addReaction(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Body() dto: AddReactionDto,
    @CurrentUser('id') userId: number,
  ): Promise<{ success: boolean }> {
    return this.messagesService.addReaction(
      conversationId,
      messageId,
      userId,
      dto.emoji,
    );
  }

  /**
   * Xóa reaction khỏi tin nhắn
   *
   * DELETE /conversations/:conversationId/messages/:messageId/reactions/:emoji
   */
  @Delete(':messageId/reactions/:emoji')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Remove a reaction from a message' })
  async removeReaction(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @Param('emoji') emoji: string,
    @CurrentUser('id') userId: number,
  ): Promise<{ success: boolean }> {
    return this.messagesService.removeReaction(
      conversationId,
      messageId,
      userId,
      emoji,
    );
  }

  // ============================================
  // SEARCH
  // ============================================

  /**
   * Tìm kiếm tin nhắn trong conversation
   *
   * GET /conversations/:conversationId/messages/search?q=keyword
   */
  @Get('search')
  @ApiOperation({ summary: 'Search messages in a conversation' })
  async searchMessages(
    @Param('conversationId') conversationId: string,
    @Query() query: SearchMessagesQueryDto,
    @CurrentUser('id') userId: number,
  ): Promise<MessageListResponseDto> {
    return this.messagesService.searchMessages(
      conversationId,
      userId,
      query.q,
      query.limit,
    );
  }

  // ============================================
  // READ RECEIPTS (MSG-004)
  // ============================================

  /**
   * Đánh dấu đã đọc tin nhắn
   *
   * POST /conversations/:conversationId/messages/read
   *
   * Body:
   * {
   *   "messageId": "optional-msg-id" // Nếu không có, mark all as read
   * }
   */
  @Post('read')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Mark messages as read' })
  async markAsRead(
    @Param('conversationId') conversationId: string,
    @Body() dto: MarkAsReadDto,
    @CurrentUser('id') userId: number,
  ): Promise<ReadReceiptsResponseDto> {
    return this.messagesService.markAsRead(conversationId, userId, dto);
  }

  /**
   * Lấy danh sách người đã đọc tin nhắn
   *
   * GET /conversations/:conversationId/messages/:messageId/read-receipts
   */
  @Get(':messageId/read-receipts')
  @ApiOperation({ summary: 'Get read receipts for a message' })
  async getReadReceipts(
    @Param('conversationId') conversationId: string,
    @Param('messageId') messageId: string,
    @CurrentUser('id') userId: number,
  ): Promise<ReadReceiptsResponseDto> {
    return this.messagesService.getReadReceipts(
      conversationId,
      messageId,
      userId,
    );
  }
}
