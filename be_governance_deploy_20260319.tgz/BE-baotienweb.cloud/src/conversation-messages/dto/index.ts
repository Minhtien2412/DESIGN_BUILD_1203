/**
 * Messages DTOs
 * =============
 *
 * DTOs cho Messages REST API
 */

import { Transform, Type } from 'class-transformer';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    Max,
    MaxLength,
    Min,
    ValidateNested,
} from 'class-validator';

// ============================================
// ENUMS
// ============================================

export enum MessageType {
  TEXT = 'TEXT',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  FILE = 'FILE',
  AUDIO = 'AUDIO',
  VOICE = 'VOICE',
  STICKER = 'STICKER',
  LOCATION = 'LOCATION',
  CALL = 'CALL',
  SYSTEM = 'SYSTEM',
}

// ============================================
// ATTACHMENT
// ============================================

export class AttachmentDto {
  @IsString()
  type: string;

  @IsString()
  url: string;

  @IsOptional()
  @IsString()
  filename?: string;

  @IsOptional()
  @IsNumber()
  size?: number;

  @IsOptional()
  @IsNumber()
  width?: number;

  @IsOptional()
  @IsNumber()
  height?: number;

  @IsOptional()
  @IsNumber()
  duration?: number;

  @IsOptional()
  @IsString()
  thumbnail?: string;

  @IsOptional()
  @IsString()
  mimeType?: string;
}

// ============================================
// SEND MESSAGE
// ============================================

export class SendMessageDto {
  @IsString()
  @MaxLength(64)
  clientMessageId: string;

  @IsOptional()
  @IsEnum(MessageType)
  type?: MessageType;

  @IsOptional()
  @IsString()
  @MaxLength(10000)
  content?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => AttachmentDto)
  attachments?: AttachmentDto[];

  @IsOptional()
  @IsString()
  replyToMessageId?: string;
}

// ============================================
// UPDATE MESSAGE
// ============================================

export class UpdateMessageDto {
  @IsString()
  @MaxLength(10000)
  content: string;
}

// ============================================
// QUERY MESSAGES
// ============================================

export class GetMessagesQueryDto {
  @IsOptional()
  @IsString()
  cursor?: string;

  @IsOptional()
  @IsEnum(['before', 'after'])
  direction?: 'before' | 'after';

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(100)
  limit?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  aroundSeq?: number;

  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  @IsBoolean()
  includeDeleted?: boolean;
}

// ============================================
// ADD REACTION
// ============================================

export class AddReactionDto {
  @IsString()
  @MaxLength(10)
  emoji: string;
}

// ============================================
// SEARCH MESSAGES
// ============================================

export class SearchMessagesQueryDto {
  @IsString()
  @MaxLength(200)
  q: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(50)
  limit?: number;
}

// ============================================
// RESPONSE DTOs
// ============================================

export interface ReplyToDto {
  id: string;
  content?: string;
  type: string;
  senderName?: string;
}

export interface ReactionDto {
  emoji: string;
  userId: number;
  userName?: string;
}

export interface SenderDto {
  id: number;
  name: string;
  avatar?: string | null;
}

export interface MessageResponseDto {
  id: string;
  conversationId: string;
  seq: number;
  clientMessageId: string;
  sender: SenderDto;
  type: string;
  content?: string | null;
  attachments?: AttachmentDto[];
  replyTo?: ReplyToDto;
  reactions?: ReactionDto[];
  readBy?: ReadReceiptDto[]; // Added for read receipts
  editedAt?: Date | null;
  deletedAt?: Date | null;
  createdAt: Date;
}

export interface MessageListResponseDto {
  messages: MessageResponseDto[];
  hasMore: boolean;
  hasNewer?: boolean;
  cursor?: string;
}

// ============================================
// DELETE MESSAGE
// ============================================

export class DeleteMessageDto {
  @IsOptional()
  @IsBoolean()
  deleteForAll?: boolean;
}

// ============================================
// READ RECEIPTS (MSG-004)
// ============================================

export class MarkAsReadDto {
  @IsOptional()
  @IsString()
  messageId?: string; // Mark specific message, or all if omitted
}

export interface ReadReceiptDto {
  userId: number;
  userName?: string;
  avatar?: string | null;
  readAt: Date;
}

export interface ReadReceiptsResponseDto {
  conversationId: string;
  messageId?: string;
  lastReadSeq: number;
  receipts: ReadReceiptDto[];
}

// ============================================
// SEARCH MESSAGES (MSG-006 Enhanced)
// ============================================

export class GlobalSearchQueryDto {
  @IsString()
  @MaxLength(200)
  q: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(50)
  limit?: number;

  @IsOptional()
  @IsString()
  conversationId?: string; // Filter by specific conversation

  @IsOptional()
  @IsEnum(MessageType)
  type?: MessageType; // Filter by message type

  @IsOptional()
  @IsString()
  fromDate?: string; // ISO date

  @IsOptional()
  @IsString()
  toDate?: string; // ISO date

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  senderId?: number; // Filter by sender
}

export interface SearchResultDto {
  message: MessageResponseDto;
  highlight?: string; // Highlighted snippet
  conversationName?: string;
}

export interface GlobalSearchResponseDto {
  results: SearchResultDto[];
  total: number;
  hasMore: boolean;
}
