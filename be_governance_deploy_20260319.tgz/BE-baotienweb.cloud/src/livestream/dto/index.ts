import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    MaxLength,
    Min,
} from 'class-validator';

export enum StreamStatus {
  PENDING = 'pending',
  LIVE = 'live',
  ENDED = 'ended',
  ERROR = 'error',
}

export enum StreamQuality {
  AUTO = 'auto',
  SD = '720p',
  HD = '1080p',
  UHD = '4k',
}

export class CreateLiveStreamDto {
  @ApiProperty({ description: 'Stream title' })
  @IsString()
  @MaxLength(200)
  title: string;

  @ApiPropertyOptional({ description: 'Stream description' })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;

  @ApiPropertyOptional({ description: 'Project ID to associate stream' })
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ description: 'Stream quality setting' })
  @IsOptional()
  @IsEnum(StreamQuality)
  quality?: StreamQuality;

  @ApiPropertyOptional({ description: 'Enable live chat', default: true })
  @IsOptional()
  @IsBoolean()
  enableChat?: boolean;

  @ApiPropertyOptional({ description: 'Enable reactions', default: true })
  @IsOptional()
  @IsBoolean()
  enableReactions?: boolean;

  @ApiPropertyOptional({ description: 'Private stream', default: false })
  @IsOptional()
  @IsBoolean()
  isPrivate?: boolean;

  @ApiPropertyOptional({ description: 'Enable recording', default: false })
  @IsOptional()
  @IsBoolean()
  enableRecording?: boolean;

  @ApiPropertyOptional({ description: 'Maximum viewers allowed' })
  @IsOptional()
  @IsNumber()
  @Min(1)
  maxViewers?: number;

  @ApiPropertyOptional({ description: 'Allowed viewer IDs for private streams' })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  allowedViewerIds?: number[];
}

export class UpdateLiveStreamDto {
  @ApiPropertyOptional({ description: 'Stream title' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @ApiPropertyOptional({ description: 'Stream description' })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;

  @ApiPropertyOptional({ description: 'Stream quality setting' })
  @IsOptional()
  @IsEnum(StreamQuality)
  quality?: StreamQuality;

  @ApiPropertyOptional({ description: 'Enable live chat' })
  @IsOptional()
  @IsBoolean()
  enableChat?: boolean;

  @ApiPropertyOptional({ description: 'Enable reactions' })
  @IsOptional()
  @IsBoolean()
  enableReactions?: boolean;
}

export class StreamCommentDto {
  @ApiProperty({ description: 'Comment text' })
  @IsString()
  @MaxLength(500)
  text: string;
}

export class StreamReactionDto {
  @ApiProperty({ description: 'Reaction type', enum: ['like', 'love', 'wow', 'clap', 'fire'] })
  @IsEnum(['like', 'love', 'wow', 'clap', 'fire'])
  type: 'like' | 'love' | 'wow' | 'clap' | 'fire';
}

export class LiveStreamResponseDto {
  @ApiProperty() id: number;
  @ApiProperty() title: string;
  @ApiPropertyOptional() description?: string;
  @ApiProperty() streamUrl: string;
  @ApiProperty() playbackUrl: string;
  @ApiProperty() streamKey: string;
  @ApiProperty({ enum: StreamStatus }) status: StreamStatus;
  @ApiProperty() viewerCount: number;
  @ApiPropertyOptional() startedAt?: Date;
  @ApiPropertyOptional() endedAt?: Date;
  @ApiPropertyOptional() duration?: number;
  @ApiPropertyOptional() projectId?: number;
  @ApiProperty() hostId: number;
  @ApiProperty() hostName: string;
  @ApiPropertyOptional() hostAvatar?: string;
  @ApiPropertyOptional() thumbnailUrl?: string;
  @ApiPropertyOptional() recordingUrl?: string;
  @ApiProperty() isRecording: boolean;
  @ApiProperty() createdAt: Date;
  @ApiProperty() updatedAt: Date;
}

export class JoinStreamResponseDto {
  @ApiProperty() playbackUrl: string;
  @ApiPropertyOptional() token?: string;
  @ApiProperty() viewerCount: number;
}

export class StreamQueryDto {
  @ApiPropertyOptional({ description: 'Filter by status' })
  @IsOptional()
  @IsEnum(StreamStatus)
  status?: StreamStatus;

  @ApiPropertyOptional({ description: 'Filter by project ID' })
  @IsOptional()
  @IsNumber()
  projectId?: number;

  @ApiPropertyOptional({ description: 'Filter by host ID' })
  @IsOptional()
  @IsNumber()
  hostId?: number;

  @ApiPropertyOptional({ description: 'Limit results', default: 20 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiPropertyOptional({ description: 'Offset for pagination', default: 0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  offset?: number;
}
