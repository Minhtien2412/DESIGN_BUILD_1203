import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiParam,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreateLiveStreamDto,
    JoinStreamResponseDto,
    LiveStreamResponseDto,
    StreamCommentDto,
    StreamQueryDto,
    StreamReactionDto,
    StreamStatus,
    UpdateLiveStreamDto,
} from './dto';
import { LivestreamService } from './livestream.service';

@ApiTags('Live Streams')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'live-streams', version: '1' })
export class LivestreamController {
  constructor(private readonly livestreamService: LivestreamService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new live stream' })
  @ApiResponse({ status: 201, description: 'Stream created', type: LiveStreamResponseDto })
  async createStream(
    @Body() dto: CreateLiveStreamDto,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.createStream(dto, userId);
  }

  @Get()
  @ApiOperation({ summary: 'Get all streams with filters' })
  @ApiResponse({ status: 200, description: 'List of streams' })
  @ApiQuery({ name: 'status', required: false, enum: StreamStatus })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({ name: 'hostId', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'offset', required: false, type: Number })
  async getStreams(@Query() query: StreamQueryDto) {
    return this.livestreamService.getStreams(query);
  }

  @Get('live')
  @ApiOperation({ summary: 'Get currently live streams' })
  @ApiResponse({ status: 200, description: 'List of live streams' })
  async getLiveStreams() {
    return this.livestreamService.getLiveStreams();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get stream by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stream details', type: LiveStreamResponseDto })
  async getStream(@Param('id', ParseIntPipe) id: number) {
    return this.livestreamService.getStream(id);
  }

  @Post(':id/start')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Start streaming (go live)' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stream started' })
  async startStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.startStream(id, userId);
  }

  @Post(':id/end')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'End the stream' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stream ended' })
  async endStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.endStream(id, userId);
  }

  @Post(':id/join')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Join stream as viewer' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Joined stream', type: JoinStreamResponseDto })
  async joinStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.joinStream(id, userId);
  }

  @Post(':id/leave')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Leave stream' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Left stream' })
  async leaveStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.leaveStream(id, userId);
  }

  @Post(':id/comments')
  @ApiOperation({ summary: 'Add comment to stream' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 201, description: 'Comment added' })
  async addComment(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
    @Body() dto: StreamCommentDto,
  ) {
    return this.livestreamService.addComment(id, userId, dto);
  }

  @Get(':id/comments')
  @ApiOperation({ summary: 'Get stream comments' })
  @ApiParam({ name: 'id', type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'List of comments' })
  async getComments(
    @Param('id', ParseIntPipe) id: number,
    @Query('limit', ParseIntPipe) limit?: number,
  ) {
    return this.livestreamService.getComments(id, limit);
  }

  @Post(':id/reactions')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Add reaction to stream' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Reaction added' })
  async addReaction(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
    @Body() dto: StreamReactionDto,
  ) {
    return this.livestreamService.addReaction(id, userId, dto);
  }

  @Get(':id/reactions')
  @ApiOperation({ summary: 'Get stream reaction counts' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Reaction counts' })
  async getReactions(@Param('id', ParseIntPipe) id: number) {
    return this.livestreamService.getReactionCounts(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update stream settings' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Stream updated', type: LiveStreamResponseDto })
  async updateStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
    @Body() dto: UpdateLiveStreamDto,
  ) {
    return this.livestreamService.updateStream(id, userId, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete stream' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 204, description: 'Stream deleted' })
  async deleteStream(
    @Param('id', ParseIntPipe) id: number,
    @CurrentUser('id') userId: number,
  ) {
    return this.livestreamService.deleteStream(id, userId);
  }
}
