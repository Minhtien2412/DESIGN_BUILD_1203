import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { randomBytes } from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateLiveStreamDto,
    StreamCommentDto,
    StreamQueryDto,
    StreamReactionDto,
    StreamStatus,
    UpdateLiveStreamDto,
} from './dto';

@Injectable()
export class LivestreamService {
  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {}

  /**
   * Create a new live stream
   */
  async createStream(dto: CreateLiveStreamDto, hostId: number) {
    const streamKey = this.generateStreamKey();
    const baseUrl = this.configService.get('STREAM_BASE_URL', 'https://stream.example.com');

    // Verify project if provided
    if (dto.projectId) {
      const project = await this.prisma.project.findUnique({
        where: { id: dto.projectId },
      });
      if (!project) {
        throw new NotFoundException(`Project ${dto.projectId} not found`);
      }
    }

    const stream = await this.prisma.liveStream.create({
      data: {
        title: dto.title,
        description: dto.description,
        streamKey,
        streamUrl: `rtmp://${baseUrl}/live/${streamKey}`,
        playbackUrl: `${baseUrl}/hls/${streamKey}/index.m3u8`,
        hostId,
        projectId: dto.projectId,
        status: StreamStatus.PENDING,
        viewerCount: 0,
        isRecording: dto.enableRecording || false,
        settings: {
          quality: dto.quality || 'auto',
          enableChat: dto.enableChat ?? true,
          enableReactions: dto.enableReactions ?? true,
          isPrivate: dto.isPrivate || false,
          maxViewers: dto.maxViewers,
          allowedViewerIds: dto.allowedViewerIds,
        },
      },
      include: {
        host: {
          select: { id: true, name: true, email: true },
        },
        project: {
          select: { id: true, title: true },
        },
      },
    });

    return this.formatStreamResponse(stream);
  }

  /**
   * Get all streams with filters
   */
  async getStreams(query: StreamQueryDto) {
    const { status, projectId, hostId, limit = 20, offset = 0 } = query;

    const where: any = {};
    if (status) where.status = status;
    if (projectId) where.projectId = projectId;
    if (hostId) where.hostId = hostId;

    const [streams, total] = await Promise.all([
      this.prisma.liveStream.findMany({
        where,
        include: {
          host: { select: { id: true, name: true, email: true } },
          project: { select: { id: true, title: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      this.prisma.liveStream.count({ where }),
    ]);

    return {
      streams: streams.map(this.formatStreamResponse),
      total,
      limit,
      offset,
    };
  }

  /**
   * Get live streams only
   */
  async getLiveStreams() {
    const streams = await this.prisma.liveStream.findMany({
      where: { status: StreamStatus.LIVE },
      include: {
        host: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
      orderBy: { viewerCount: 'desc' },
    });

    return streams.map(this.formatStreamResponse);
  }

  /**
   * Get stream by ID
   */
  async getStream(id: number) {
    const stream = await this.prisma.liveStream.findUnique({
      where: { id },
      include: {
        host: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    if (!stream) {
      throw new NotFoundException(`Stream ${id} not found`);
    }

    return this.formatStreamResponse(stream);
  }

  /**
   * Start a stream (go live)
   */
  async startStream(id: number, userId: number) {
    const stream = await this.findStreamOrFail(id);

    if (stream.hostId !== userId) {
      throw new ForbiddenException('Only the host can start the stream');
    }

    if (stream.status === StreamStatus.LIVE) {
      throw new BadRequestException('Stream is already live');
    }

    const updated = await this.prisma.liveStream.update({
      where: { id },
      data: {
        status: StreamStatus.LIVE,
        startedAt: new Date(),
      },
      include: {
        host: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    return this.formatStreamResponse(updated);
  }

  /**
   * End a stream
   */
  async endStream(id: number, userId: number) {
    const stream = await this.findStreamOrFail(id);

    if (stream.hostId !== userId) {
      throw new ForbiddenException('Only the host can end the stream');
    }

    const now = new Date();
    const duration = stream.startedAt
      ? Math.floor((now.getTime() - stream.startedAt.getTime()) / 1000)
      : 0;

    const updated = await this.prisma.liveStream.update({
      where: { id },
      data: {
        status: StreamStatus.ENDED,
        endedAt: now,
        duration,
      },
      include: {
        host: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    return this.formatStreamResponse(updated);
  }

  /**
   * Join stream as viewer
   */
  async joinStream(id: number, userId: number) {
    const stream = await this.findStreamOrFail(id);

    // Check if stream is joinable
    if (stream.status !== StreamStatus.LIVE && stream.status !== StreamStatus.PENDING) {
      throw new BadRequestException('Stream is not available for viewing');
    }

    // Check private stream access
    const settings = stream.settings as any;
    if (settings?.isPrivate) {
      const allowedIds = settings.allowedViewerIds || [];
      if (!allowedIds.includes(userId) && stream.hostId !== userId) {
        throw new ForbiddenException('This is a private stream');
      }
    }

    // Check max viewers
    if (settings?.maxViewers && stream.viewerCount >= settings.maxViewers) {
      throw new BadRequestException('Stream has reached maximum viewers');
    }

    // Increment viewer count
    const updated = await this.prisma.liveStream.update({
      where: { id },
      data: {
        viewerCount: { increment: 1 },
      },
    });

    // Record viewer join
    await this.prisma.streamViewer.upsert({
      where: {
        streamId_userId: { streamId: id, userId },
      },
      create: {
        streamId: id,
        userId,
        joinedAt: new Date(),
      },
      update: {
        joinedAt: new Date(),
        leftAt: null,
      },
    });

    return {
      playbackUrl: stream.playbackUrl,
      token: this.generateViewerToken(id, userId),
      viewerCount: updated.viewerCount,
    };
  }

  /**
   * Leave stream
   */
  async leaveStream(id: number, userId: number) {
    const stream = await this.findStreamOrFail(id);

    // Decrement viewer count (ensure not negative)
    await this.prisma.liveStream.update({
      where: { id },
      data: {
        viewerCount: stream.viewerCount > 0 ? { decrement: 1 } : 0,
      },
    });

    // Record viewer leave
    await this.prisma.streamViewer.updateMany({
      where: { streamId: id, userId },
      data: { leftAt: new Date() },
    });

    return { success: true };
  }

  /**
   * Add comment to stream
   */
  async addComment(streamId: number, userId: number, dto: StreamCommentDto) {
    const stream = await this.findStreamOrFail(streamId);
    const settings = stream.settings as any;

    if (!settings?.enableChat) {
      throw new BadRequestException('Chat is disabled for this stream');
    }

    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true },
    });

    const comment = await this.prisma.streamComment.create({
      data: {
        streamId,
        userId,
        text: dto.text,
      },
      include: {
        user: { select: { id: true, name: true } },
      },
    });

    return {
      id: comment.id.toString(),
      text: comment.text,
      userId: comment.userId.toString(),
      userName: comment.user.name || 'Anonymous',
      createdAt: comment.createdAt.toISOString(),
    };
  }

  /**
   * Get stream comments
   */
  async getComments(streamId: number, limit = 50) {
    await this.findStreamOrFail(streamId);

    const comments = await this.prisma.streamComment.findMany({
      where: { streamId },
      include: {
        user: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return comments.map((c) => ({
      id: c.id.toString(),
      text: c.text,
      userId: c.userId.toString(),
      userName: c.user.name || 'Anonymous',
      createdAt: c.createdAt.toISOString(),
    }));
  }

  /**
   * Add reaction to stream
   */
  async addReaction(streamId: number, userId: number, dto: StreamReactionDto) {
    await this.findStreamOrFail(streamId);

    await this.prisma.streamReaction.create({
      data: {
        streamId,
        userId,
        type: dto.type,
      },
    });

    // Get reaction counts
    const counts = await this.getReactionCounts(streamId);

    return { success: true, counts };
  }

  /**
   * Get reaction counts
   */
  async getReactionCounts(streamId: number) {
    const reactions = await this.prisma.streamReaction.groupBy({
      by: ['type'],
      where: { streamId },
      _count: true,
    });

    const counts: Record<string, number> = {};
    reactions.forEach((r) => {
      counts[r.type] = r._count;
    });

    return counts;
  }

  /**
   * Update stream settings
   */
  async updateStream(id: number, userId: number, dto: UpdateLiveStreamDto) {
    const stream = await this.findStreamOrFail(id);

    if (stream.hostId !== userId) {
      throw new ForbiddenException('Only the host can update the stream');
    }

    const updateData: any = {};
    if (dto.title) updateData.title = dto.title;
    if (dto.description !== undefined) updateData.description = dto.description;

    if (dto.quality || dto.enableChat !== undefined || dto.enableReactions !== undefined) {
      const currentSettings = stream.settings as any || {};
      updateData.settings = {
        ...currentSettings,
        ...(dto.quality && { quality: dto.quality }),
        ...(dto.enableChat !== undefined && { enableChat: dto.enableChat }),
        ...(dto.enableReactions !== undefined && { enableReactions: dto.enableReactions }),
      };
    }

    const updated = await this.prisma.liveStream.update({
      where: { id },
      data: updateData,
      include: {
        host: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, title: true } },
      },
    });

    return this.formatStreamResponse(updated);
  }

  /**
   * Delete stream
   */
  async deleteStream(id: number, userId: number) {
    const stream = await this.findStreamOrFail(id);

    if (stream.hostId !== userId) {
      throw new ForbiddenException('Only the host can delete the stream');
    }

    await this.prisma.liveStream.delete({ where: { id } });

    return { success: true };
  }

  // === Private helpers ===

  private async findStreamOrFail(id: number) {
    const stream = await this.prisma.liveStream.findUnique({
      where: { id },
    });

    if (!stream) {
      throw new NotFoundException(`Stream ${id} not found`);
    }

    return stream;
  }

  private formatStreamResponse(stream: any) {
    const settings = stream.settings as any || {};
    
    return {
      id: stream.id.toString(),
      title: stream.title,
      description: stream.description,
      streamUrl: stream.streamUrl,
      playbackUrl: stream.playbackUrl,
      streamKey: stream.streamKey,
      status: stream.status,
      viewerCount: stream.viewerCount,
      startedAt: stream.startedAt?.toISOString(),
      endedAt: stream.endedAt?.toISOString(),
      duration: stream.duration,
      projectId: stream.projectId?.toString(),
      hostId: stream.hostId.toString(),
      hostName: stream.host?.name || 'Unknown',
      hostAvatar: undefined,
      thumbnailUrl: stream.thumbnailUrl,
      recordingUrl: stream.recordingUrl,
      isRecording: stream.isRecording,
      settings: {
        quality: settings.quality || 'auto',
        enableChat: settings.enableChat ?? true,
        enableReactions: settings.enableReactions ?? true,
        isPrivate: settings.isPrivate || false,
        maxViewers: settings.maxViewers,
        allowedViewerIds: settings.allowedViewerIds,
      },
      createdAt: stream.createdAt.toISOString(),
      updatedAt: stream.updatedAt.toISOString(),
    };
  }

  private generateStreamKey(): string {
    return randomBytes(16).toString('hex');
  }

  private generateViewerToken(streamId: number, userId: number): string {
    // Simple token generation - in production use JWT
    return Buffer.from(`${streamId}:${userId}:${Date.now()}`).toString('base64');
  }
}
