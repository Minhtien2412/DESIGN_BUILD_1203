import { BadRequestException, Injectable } from '@nestjs/common';
import { getErrorMessage } from '../utils/error-helpers';

import * as crypto from 'crypto';
import { ContractService } from './contract.service';
import { ContractPaymentDto } from './dto/payment-gateway.dto';

@Injectable()
export class PaymentGatewayService {
  constructor(private contractService: ContractService) {}

  /**
   * Khởi tạo thanh toán qua gateway
   */
  async initiatePayment(dto: ContractPaymentDto) {
    const schedule = await this.contractService[
      'prisma'
    ].paymentSchedule.findUnique({
      where: { id: dto.scheduleId },
      include: {
        contract: {
          include: {
            client: true,
            project: true,
          },
        },
      },
    });

    if (!schedule) {
      throw new BadRequestException('Payment schedule not found');
    }

    if (schedule.status === 'PAID') {
      throw new BadRequestException('Payment already completed');
    }

    const amount = dto.amount || Number(schedule.amount);

    switch (dto.gateway) {
      case 'MOMO':
        return this.initiateMomoPayment(
          schedule,
          amount,
          dto.returnUrl || '',
          dto.notifyUrl || '',
        );
      case 'VNPAY':
        return this.initiateVNPayPayment(
          schedule,
          amount,
          dto.returnUrl || '',
          dto.notifyUrl || '',
        );
      case 'STRIPE':
        return this.initiateStripePayment(
          schedule,
          amount,
          dto.returnUrl || '',
        );
      case 'ACB':
        return this.initiateAcbPayment(
          schedule,
          amount,
          dto.returnUrl || '',
          dto.notifyUrl || '',
        );
      default:
        throw new BadRequestException('Invalid payment gateway');
    }
  }

  /**
   * Tích hợp Momo Payment
   * Docs: https://developers.momo.vn/
   */
  private async initiateMomoPayment(
    schedule: any,
    amount: number,
    returnUrl: string,
    notifyUrl: string,
  ) {
    const accessKey = process.env.MOMO_ACCESS_KEY;
    const secretKey = process.env.MOMO_SECRET_KEY;
    const partnerCode = process.env.MOMO_PARTNER_CODE;
    const apiUrl =
      process.env.MOMO_API_URL ||
      'https://test-payment.momo.vn/v2/gateway/api/create';

    if (!accessKey || !secretKey || !partnerCode) {
      // Fallback to mock if credentials not configured
      return {
        gateway: 'MOMO',
        paymentUrl: 'https://test-payment.momo.vn/pay?token=mock_token',
        orderId: `MOMO-${schedule.id}-${Date.now()}`,
        amount,
        message:
          'Mock: Momo credentials not configured. Redirect to Momo for payment',
      };
    }

    const orderId = `${schedule.contractId}-${schedule.id}-${Date.now()}`;
    const requestId = orderId;
    const orderInfo = `Thanh toán ${schedule.phaseName} - ${schedule.contract.title}`;
    const redirectUrl = returnUrl;
    const ipnUrl = notifyUrl;
    const requestType = 'captureWallet';
    const extraData = '';

    const rawSignature = `accessKey=${accessKey}&amount=${amount}&extraData=${extraData}&ipnUrl=${ipnUrl}&orderId=${orderId}&orderInfo=${orderInfo}&partnerCode=${partnerCode}&redirectUrl=${redirectUrl}&requestId=${requestId}&requestType=${requestType}`;
    const signature = crypto
      .createHmac('sha256', secretKey)
      .update(rawSignature)
      .digest('hex');

    const requestBody = {
      partnerCode,
      partnerName: 'BaoTienWeb',
      storeId: 'MomoStore',
      requestId,
      amount,
      orderId,
      orderInfo,
      redirectUrl,
      ipnUrl,
      requestType,
      extraData,
      lang: 'vi',
      signature,
      autoCapture: true,
    };

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      const result = await response.json();

      if (result.resultCode === 0) {
        return {
          gateway: 'MOMO',
          paymentUrl: result.payUrl,
          orderId,
          amount,
          deeplink: result.deeplink,
          qrCodeUrl: result.qrCodeUrl,
          message: 'Redirect to Momo for payment',
        };
      } else {
        throw new BadRequestException(`Momo payment failed: ${result.message}`);
      }
    } catch (error: unknown) {
      throw new BadRequestException(
        `Momo API error: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Tích hợp VNPay Payment
   * Docs: https://sandbox.vnpayment.vn/apis/docs/huong-dan-tich-hop/
   */
  private async initiateVNPayPayment(
    schedule: any,
    amount: number,
    returnUrl: string,
    notifyUrl: string,
  ) {
    const vnp_TmnCode = process.env.VNPAY_TMN_CODE;
    const vnp_HashSecret = process.env.VNPAY_HASH_SECRET;
    const vnp_Url =
      process.env.VNPAY_URL ||
      'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html';

    if (!vnp_TmnCode || !vnp_HashSecret) {
      // Fallback to mock if credentials not configured
      return {
        gateway: 'VNPAY',
        paymentUrl:
          'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?token=mock_token',
        orderId: `VNPAY-${schedule.id}-${Date.now()}`,
        amount,
        message:
          'Mock: VNPay credentials not configured. Redirect to VNPay for payment',
      };
    }

    const vnp_ReturnUrl = returnUrl;

    const date = new Date();
    const createDate = date
      .toISOString()
      .replace(/[^0-9]/g, '')
      .slice(0, 14);
    const orderId = `${schedule.contractId}-${schedule.id}-${Date.now()}`;

    let vnp_Params: any = {
      vnp_Version: '2.1.0',
      vnp_Command: 'pay',
      vnp_TmnCode,
      vnp_Locale: 'vn',
      vnp_CurrCode: 'VND',
      vnp_TxnRef: orderId,
      vnp_OrderInfo: `Thanh toán ${schedule.phaseName}`,
      vnp_OrderType: 'other',
      vnp_Amount: amount * 100, // VNPay yêu cầu amount * 100
      vnp_ReturnUrl,
      vnp_IpAddr: '127.0.0.1',
      vnp_CreateDate: createDate,
    };

    vnp_Params = this.sortObject(vnp_Params);
    const signData = new URLSearchParams(vnp_Params).toString();
    const hmac = crypto.createHmac('sha512', vnp_HashSecret);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');
    vnp_Params['vnp_SecureHash'] = signed;

    const paymentUrl =
      vnp_Url + '?' + new URLSearchParams(vnp_Params).toString();

    return {
      gateway: 'VNPAY',
      paymentUrl,
      orderId,
      amount,
      message: 'Redirect to VNPay for payment',
    };
  }

  /**
   * Tích hợp Stripe Payment (for overseas Vietnamese)
   */
  private async initiateStripePayment(
    schedule: any,
    amount: number,
    returnUrl: string,
  ) {
    const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

    if (!stripeSecretKey || stripeSecretKey.startsWith('sk_test_your')) {
      // Fallback to mock if Stripe not configured
      return {
        gateway: 'STRIPE',
        paymentUrl: 'https://checkout.stripe.com/pay/mock_session',
        sessionId: `STRIPE-${schedule.id}-${Date.now()}`,
        amount,
        message: 'Mock: Stripe not configured. Redirect to Stripe for payment',
      };
    }

    try {
      const Stripe = require('stripe');
      const stripe = new Stripe(stripeSecretKey);

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'vnd',
              product_data: {
                name: `${schedule.phaseName} - ${schedule.contract.title}`,
                description: schedule.contract.project.title,
              },
              unit_amount: amount,
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${returnUrl}?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: returnUrl,
        metadata: {
          scheduleId: schedule.id,
          contractId: schedule.contractId,
        },
      });

      return {
        gateway: 'STRIPE',
        paymentUrl: session.url,
        sessionId: session.id,
        amount,
        message: 'Redirect to Stripe for payment',
      };
    } catch (error: unknown) {
      throw new BadRequestException(
        `Stripe API error: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Tích hợp ACB ONE Connect Payment
   * Docs: https://developer.acb.com.vn/
   */
  private async initiateAcbPayment(
    schedule: any,
    amount: number,
    returnUrl: string,
    notifyUrl: string,
  ) {
    const clientId = process.env.ACB_CLIENT_ID;
    const clientSecret = process.env.ACB_CLIENT_SECRET;
    const acbApiUrl =
      process.env.ACB_API_URL || 'https://apiconnect.acb.com.vn';
    const merchantId = process.env.ACB_MERCHANT_ID;

    const orderId = `ACB-${schedule.contractId}-${schedule.id}-${Date.now()}`;

    if (!clientId || !clientSecret || !merchantId) {
      // Fallback to mock if credentials not configured
      return {
        gateway: 'ACB',
        paymentUrl: `https://developer.acb.com.vn/sandbox/pay?txn=${orderId}`,
        qrCodeUrl: `https://img.vietqr.io/image/970416-0000000000-compact2.jpg?amount=${amount}&addInfo=${encodeURIComponent(schedule.phaseName)}`,
        orderId,
        amount,
        message: 'Mock: ACB credentials not configured. Using sandbox mode.',
      };
    }

    try {
      // Get OAuth2 token
      const tokenResponse = await fetch(`${acbApiUrl}/oauth/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
        },
        body: new URLSearchParams({
          grant_type: 'client_credentials',
          scope: 'payment',
        }).toString(),
      });

      if (!tokenResponse.ok) {
        throw new BadRequestException(
          'Failed to authenticate with ACB ONE Connect',
        );
      }

      const tokenData = await tokenResponse.json();

      // Create payment request
      const requestId = `${orderId}-${crypto.randomUUID().slice(0, 8)}`;
      const paymentBody = {
        requestId,
        merchantId,
        transactionId: orderId,
        amount,
        currency: 'VND',
        description: `Thanh toán ${schedule.phaseName} - ${schedule.contract.title}`,
        returnUrl,
        notifyUrl,
        orderInfo: orderId,
      };

      const signatureData = Object.entries(paymentBody)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([k, v]) => `${k}=${v}`)
        .join('&');
      const signature = crypto
        .createHmac('sha256', clientSecret)
        .update(signatureData)
        .digest('hex');

      const response = await fetch(`${acbApiUrl}/api/v1/payments/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${tokenData.access_token}`,
          'X-Request-Id': requestId,
          'X-Signature': signature,
        },
        body: JSON.stringify(paymentBody),
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new BadRequestException(`ACB payment failed: ${errorData}`);
      }

      const result = await response.json();

      return {
        gateway: 'ACB',
        paymentUrl: result.paymentUrl || result.payUrl,
        qrCodeUrl: result.qrCodeUrl || result.qrUrl,
        orderId,
        amount,
        message: 'Redirect to ACB for payment',
      };
    } catch (error: unknown) {
      throw new BadRequestException(`ACB API error: ${getErrorMessage(error)}`);
    }
  }

  /**
   * Xử lý callback từ payment gateway
   */
  async handlePaymentCallback(gateway: string, data: any) {
    let scheduleId: number;
    let status: string;
    let paymentRef: string;
    let paidAmount: number;

    switch (gateway.toUpperCase()) {
      case 'MOMO':
        // Verify Momo signature
        if (!this.verifyMomoSignature(data)) {
          throw new BadRequestException('Invalid Momo signature');
        }
        scheduleId = this.extractScheduleIdFromOrderId(data.orderId);
        status = data.resultCode === 0 ? 'PAID' : 'PENDING';
        paymentRef = data.transId;
        paidAmount = data.amount;
        break;

      case 'VNPAY':
        // Verify VNPay signature
        if (!this.verifyVNPaySignature(data)) {
          throw new BadRequestException('Invalid VNPay signature');
        }
        scheduleId = this.extractScheduleIdFromOrderId(data.vnp_TxnRef);
        status = data.vnp_ResponseCode === '00' ? 'PAID' : 'PENDING';
        paymentRef = data.vnp_TransactionNo;
        paidAmount = data.vnp_Amount / 100;
        break;

      case 'STRIPE':
        // Verify Stripe webhook signature (should be done in controller with raw body)
        scheduleId = data.metadata?.scheduleId;
        status = data.payment_status === 'paid' ? 'PAID' : 'PENDING';
        paymentRef = data.id;
        paidAmount = data.amount_total / 100;
        break;

      case 'ACB':
        scheduleId = this.extractScheduleIdFromOrderId(
          data.transactionId || data.orderId,
        );
        status =
          data.status === 'SUCCESS' || data.status === '00'
            ? 'PAID'
            : 'PENDING';
        paymentRef = data.transactionId;
        paidAmount = data.amount;
        break;

      default:
        throw new BadRequestException('Invalid gateway');
    }

    // Update payment schedule
    await this.contractService.updatePaymentStatus(
      scheduleId,
      status,
      paidAmount,
      gateway.toUpperCase(),
      paymentRef,
    );

    return {
      success: true,
      scheduleId,
      status,
      paymentRef,
    };
  }

  /**
   * Helper: Extract schedule ID from order ID
   */
  private extractScheduleIdFromOrderId(orderId: string): number {
    // Format: GATEWAY-{scheduleId}-{timestamp} hoặc {contractId}-{scheduleId}-{timestamp}
    const parts = orderId.split('-');
    return parseInt(parts[1]);
  }

  /**
   * Helper: Sort object keys (for VNPay signature)
   */
  private sortObject(obj: any) {
    const sorted = {};
    const keys = Object.keys(obj).sort();
    keys.forEach((key) => {
      sorted[key] = obj[key];
    });
    return sorted;
  }

  /**
   * Verify Momo signature
   */
  private verifyMomoSignature(data: any): boolean {
    const secretKey = process.env.MOMO_SECRET_KEY;
    if (!secretKey) {
      if (process.env.NODE_ENV === 'production') {
        console.error(
          '[SECURITY] MOMO_SECRET_KEY not set in production — rejecting callback',
        );
        return false;
      }
      console.warn(
        'Momo secret key not configured, skipping signature verification',
      );
      return true;
    }

    const {
      partnerCode,
      orderId,
      requestId,
      amount,
      orderInfo,
      orderType,
      transId,
      resultCode,
      message,
      payType,
      responseTime,
      extraData,
      signature,
    } = data;

    const rawSignature = `accessKey=${process.env.MOMO_ACCESS_KEY}&amount=${amount}&extraData=${extraData}&message=${message}&orderId=${orderId}&orderInfo=${orderInfo}&orderType=${orderType}&partnerCode=${partnerCode}&payType=${payType}&requestId=${requestId}&responseTime=${responseTime}&resultCode=${resultCode}&transId=${transId}`;

    const expectedSignature = crypto
      .createHmac('sha256', secretKey)
      .update(rawSignature)
      .digest('hex');

    return signature === expectedSignature;
  }

  /**
   * Verify VNPay signature
   */
  private verifyVNPaySignature(data: any): boolean {
    const vnp_HashSecret = process.env.VNPAY_HASH_SECRET;
    if (!vnp_HashSecret) {
      if (process.env.NODE_ENV === 'production') {
        console.error(
          '[SECURITY] VNPAY_HASH_SECRET not set in production — rejecting callback',
        );
        return false;
      }
      console.warn(
        'VNPay hash secret not configured, skipping signature verification',
      );
      return true;
    }

    const vnp_SecureHash = data.vnp_SecureHash;
    delete data.vnp_SecureHash;
    delete data.vnp_SecureHashType;

    const sortedParams = this.sortObject(data);
    const signData = new URLSearchParams(sortedParams).toString();
    const hmac = crypto.createHmac('sha512', vnp_HashSecret);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    return vnp_SecureHash === signed;
  }
}
