import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ContractController } from './contract.controller';
import { ContractService } from './contract.service';
import { MaterialService } from './material.service';
import { PaymentGatewayService } from './payment-gateway.service';

@Module({
  controllers: [ContractController],
  providers: [
    ContractService,
    MaterialService,
    PaymentGatewayService,
    PrismaService,
  ],
  exports: [ContractService, MaterialService, PaymentGatewayService],
})
export class ContractModule {}
