import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateMaterialDto, UpdateMaterialDto } from './dto';

@Injectable()
export class MaterialService {
  constructor(private prisma: PrismaService) {}

  /**
   * Tạo vật tư mới trong catalog
   */
  async createMaterial(dto: CreateMaterialDto) {
    return this.prisma.material.create({
      data: {
        name: dto.name,
        category: dto.category,
        unit: dto.unit,
        unitPrice: dto.unitPrice,
        supplier: dto.supplier,
        description: dto.description,
        imageUrl: dto.imageUrl,
        isActive: dto.isActive !== undefined ? dto.isActive : true,
      },
    });
  }

  /**
   * Lấy danh sách vật tư
   */
  async getMaterials(category?: string, isActive?: boolean) {
    return this.prisma.material.findMany({
      where: {
        ...(category && { category }),
        ...(isActive !== undefined && { isActive }),
      },
      orderBy: { name: 'asc' },
    });
  }

  /**
   * Lấy chi tiết vật tư
   */
  async getMaterialById(id: number) {
    return this.prisma.material.findUnique({
      where: { id },
    });
  }

  /**
   * Cập nhật vật tư
   */
  async updateMaterial(id: number, dto: UpdateMaterialDto) {
    return this.prisma.material.update({
      where: { id },
      data: dto,
    });
  }

  /**
   * Xóa (hoặc deactivate) vật tư
   */
  async deleteMaterial(id: number) {
    // Soft delete: chỉ deactivate
    return this.prisma.material.update({
      where: { id },
      data: { isActive: false },
    });
  }

  /**
   * Lấy danh mục vật tư (unique categories)
   */
  async getCategories() {
    const materials = await this.prisma.material.findMany({
      select: { category: true },
      distinct: ['category'],
    });

    return materials.map((m) => m.category);
  }
}
