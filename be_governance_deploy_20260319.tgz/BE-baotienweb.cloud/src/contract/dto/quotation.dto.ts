import {
  IsString,
  IsNumber,
  IsInt,
  IsOptional,
  IsArray,
  ValidateNested,
  Min,
  IsDateString,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class QuotationItemDto {
  @ApiPropertyOptional({ description: 'ID vật tư (nếu có)' })
  @IsInt()
  @IsOptional()
  materialId?: number;

  @ApiProperty({ description: 'Số lượng', example: 50 })
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty({ description: 'Đơn giá', example: 250000 })
  @IsNumber()
  @Min(0)
  unitPrice: number;

  @ApiPropertyOptional({
    description: 'Mô tả chi tiết',
    example: 'Gạch granite 60x60 cao cấp',
  })
  @IsString()
  @IsOptional()
  description?: string;
}

export class CreateQuotationDto {
  @ApiProperty({
    description: 'Tiêu đề báo giá',
    example: 'Báo giá thi công nội thất phòng khách',
  })
  @IsString()
  title: string;

  @ApiProperty({ description: 'ID dự án' })
  @IsInt()
  projectId: number;

  @ApiProperty({ description: 'Danh sách vật tư', type: [QuotationItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuotationItemDto)
  items: QuotationItemDto[];

  @ApiPropertyOptional({
    description: 'Thuế VAT (%)',
    example: 10,
    default: 10,
  })
  @IsNumber()
  @IsOptional()
  taxRate?: number;

  @ApiPropertyOptional({
    description: 'Giảm giá',
    example: 5000000,
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  discount?: number;

  @ApiPropertyOptional({ description: 'Ghi chú' })
  @IsString()
  @IsOptional()
  notes?: string;

  @ApiPropertyOptional({
    description: 'Hiệu lực đến ngày',
    example: '2024-12-31',
  })
  @IsDateString()
  @IsOptional()
  validUntil?: string;
}

export class UpdateQuotationDto {
  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  title?: string;

  @ApiPropertyOptional({ type: [QuotationItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuotationItemDto)
  @IsOptional()
  items?: QuotationItemDto[];

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  taxRate?: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  discount?: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  notes?: string;

  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  validUntil?: string;
}

export class ApproveQuotationDto {
  @ApiPropertyOptional({ description: 'Ghi chú phê duyệt' })
  @IsString()
  @IsOptional()
  notes?: string;
}
