import {
  IsString,
  IsInt,
  IsOptional,
  IsDateString,
  IsArray,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class PaymentScheduleItemDto {
  @ApiProperty({ description: 'Tên đợt thanh toán', example: 'Đợt cọc' })
  @IsString()
  phaseName: string;

  @ApiProperty({ description: 'Phần trăm thanh toán', example: 30 })
  percentage: number;

  @ApiPropertyOptional({ description: 'Ngày đến hạn', example: '2024-12-01' })
  @IsDateString()
  @IsOptional()
  dueDate?: string;

  @ApiPropertyOptional({ description: 'Ghi chú' })
  @IsString()
  @IsOptional()
  notes?: string;
}

export class CreateContractDto {
  @ApiProperty({
    description: 'Tiêu đề hợp đồng',
    example: 'Hợp đồng thi công nội thất',
  })
  @IsString()
  title: string;

  @ApiProperty({ description: 'ID dự án' })
  @IsInt()
  projectId: number;

  @ApiProperty({ description: 'ID khách hàng' })
  @IsInt()
  clientId: number;

  @ApiPropertyOptional({ description: 'ID báo giá (nếu có)' })
  @IsInt()
  @IsOptional()
  quotationId?: number;

  @ApiProperty({ description: 'Nội dung hợp đồng' })
  @IsString()
  content: string;

  @ApiProperty({ description: 'Giá trị hợp đồng', example: 500000000 })
  contractValue: number;

  @ApiProperty({ description: 'Ngày bắt đầu', example: '2024-12-01' })
  @IsDateString()
  startDate: string;

  @ApiProperty({ description: 'Ngày kết thúc', example: '2025-06-30' })
  @IsDateString()
  endDate: string;

  @ApiPropertyOptional({ description: 'Điều khoản hợp đồng (JSON)' })
  @IsOptional()
  terms?: any;

  @ApiPropertyOptional({ description: 'Ghi chú' })
  @IsString()
  @IsOptional()
  notes?: string;

  @ApiPropertyOptional({
    description: 'Lịch thanh toán',
    type: [PaymentScheduleItemDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PaymentScheduleItemDto)
  @IsOptional()
  paymentSchedules?: PaymentScheduleItemDto[];
}

export class SignContractDto {
  @ApiProperty({
    description: 'Chữ ký (base64)',
    example: 'data:image/png;base64,iVBORw0KGgo...',
  })
  @IsString()
  signature: string;

  @ApiPropertyOptional({ description: 'Ghi chú' })
  @IsString()
  @IsOptional()
  notes?: string;
}

export class GeneratePdfDto {
  @ApiProperty({ description: 'ID hợp đồng' })
  @IsInt()
  contractId: number;
}
