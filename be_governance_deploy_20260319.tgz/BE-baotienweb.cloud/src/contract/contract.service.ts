import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  CreateQuotationDto,
  UpdateQuotationDto,
  CreateContractDto,
  SignContractDto,
} from './dto';

@Injectable()
export class ContractService {
  constructor(private prisma: PrismaService) {}

  /**
   * Tạo báo giá tự động từ bảng vật tư
   */
  async createQuotation(userId: number, dto: CreateQuotationDto) {
    // Tính toán tổng tiền
    let subtotal = 0;
    const itemsData: Array<{
      quantity: number;
      unitPrice: number;
      amount: number;
      description?: string;
      materialId?: number;
    }> = [];

    for (const item of dto.items) {
      const amount = item.quantity * item.unitPrice;
      subtotal += amount;

      itemsData.push({
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        amount,
        description: item.description,
        materialId: item.materialId,
      });
    }

    const taxRate = dto.taxRate || 10;
    const taxAmount = (subtotal * taxRate) / 100;
    const discount = dto.discount || 0;
    const total = subtotal + taxAmount - discount;

    // Generate quotation number
    const count = await this.prisma.quotation.count();
    const quotationNo = `QT-${new Date().getFullYear()}-${String(count + 1).padStart(3, '0')}`;

    const quotation = await this.prisma.quotation.create({
      data: {
        quotationNo,
        title: dto.title,
        projectId: dto.projectId,
        createdById: userId,
        subtotal,
        taxRate,
        taxAmount,
        discount,
        total,
        validUntil: dto.validUntil ? new Date(dto.validUntil) : undefined,
        notes: dto.notes,
        items: {
          create: itemsData,
        },
      },
      include: {
        items: {
          include: {
            material: true,
          },
        },
        project: {
          select: { id: true, title: true },
        },
      },
    });

    return quotation;
  }

  /**
   * Lấy danh sách báo giá
   */
  async getQuotations(projectId?: number) {
    return this.prisma.quotation.findMany({
      where: projectId ? { projectId } : undefined,
      include: {
        items: {
          include: {
            material: true,
          },
        },
        project: {
          select: { id: true, title: true },
        },
        createdBy: {
          select: { id: true, name: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Lấy chi tiết báo giá
   */
  async getQuotationById(id: number) {
    const quotation = await this.prisma.quotation.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            material: true,
          },
        },
        project: true,
        createdBy: {
          select: { id: true, name: true },
        },
      },
    });

    if (!quotation) {
      throw new NotFoundException('Quotation not found');
    }

    return quotation;
  }

  /**
   * Cập nhật báo giá (lưu lịch sử thay đổi giá)
   */
  async updateQuotation(id: number, dto: UpdateQuotationDto) {
    const existing = await this.getQuotationById(id);

    if (existing.status !== 'DRAFT') {
      throw new BadRequestException('Can only update draft quotations');
    }

    // Lưu lịch sử giá cũ
    const priceHistory = (existing.priceHistory as any[]) || [];
    priceHistory.push({
      date: new Date(),
      subtotal: existing.subtotal,
      total: existing.total,
      items: existing.items.map((item) => ({
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        amount: item.amount,
      })),
    });

    // Tính toán lại nếu có items mới
    let subtotal = Number(existing.subtotal);
    let taxRate = existing.taxRate;
    let discount = Number(existing.discount);

    if (dto.items) {
      subtotal = 0;
      // Xóa items cũ
      await this.prisma.quotationItem.deleteMany({
        where: { quotationId: id },
      });

      // Tạo items mới
      const itemsData: Array<{
        quantity: number;
        unitPrice: number;
        amount: number;
        description?: string;
        materialId?: number;
        quotationId: number;
      }> = [];
      for (const item of dto.items) {
        const amount = item.quantity * item.unitPrice;
        subtotal += amount;
        itemsData.push({
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          amount,
          description: item.description,
          materialId: item.materialId,
          quotationId: id,
        });
      }

      await this.prisma.quotationItem.createMany({
        data: itemsData,
      });
    }

    if (dto.taxRate !== undefined) taxRate = dto.taxRate;
    if (dto.discount !== undefined) discount = dto.discount;

    const taxAmount = (subtotal * taxRate) / 100;
    const total = subtotal + taxAmount - discount;

    return this.prisma.quotation.update({
      where: { id },
      data: {
        title: dto.title,
        taxRate,
        discount,
        subtotal,
        taxAmount,
        total,
        validUntil: dto.validUntil ? new Date(dto.validUntil) : undefined,
        notes: dto.notes,
        priceHistory,
      },
      include: {
        items: {
          include: {
            material: true,
          },
        },
      },
    });
  }

  /**
   * Gửi báo giá cho khách hàng
   */
  async sendQuotation(id: number) {
    return this.prisma.quotation.update({
      where: { id },
      data: { status: 'SENT' },
    });
  }

  /**
   * Khách hàng phê duyệt báo giá
   */
  async approveQuotation(id: number, userId: number) {
    const quotation = await this.getQuotationById(id);

    if (quotation.status !== 'SENT') {
      throw new BadRequestException('Quotation must be sent first');
    }

    return this.prisma.quotation.update({
      where: { id },
      data: { status: 'APPROVED' },
    });
  }

  /**
   * Từ chối báo giá
   */
  async rejectQuotation(id: number) {
    return this.prisma.quotation.update({
      where: { id },
      data: { status: 'REJECTED' },
    });
  }

  /**
   * Tạo hợp đồng từ báo giá
   */
  async createContract(userId: number, dto: CreateContractDto) {
    // Generate contract number
    const count = await this.prisma.contract.count();
    const contractNo = `CT-${new Date().getFullYear()}-${String(count + 1).padStart(3, '0')}`;

    const contract = await this.prisma.contract.create({
      data: {
        contractNo,
        title: dto.title,
        projectId: dto.projectId,
        clientId: dto.clientId,
        quotationId: dto.quotationId,
        content: dto.content,
        contractValue: dto.contractValue,
        startDate: new Date(dto.startDate),
        endDate: new Date(dto.endDate),
        terms: dto.terms,
        notes: dto.notes,
      },
      include: {
        project: true,
        client: {
          select: { id: true, name: true, email: true },
        },
        quotation: true,
      },
    });

    // Tạo lịch thanh toán tự động nếu có
    if (dto.paymentSchedules && dto.paymentSchedules.length > 0) {
      const schedules = dto.paymentSchedules.map((schedule, index) => ({
        contractId: contract.id,
        phase: index + 1,
        phaseName: schedule.phaseName,
        percentage: schedule.percentage,
        amount: (dto.contractValue * schedule.percentage) / 100,
        dueDate: schedule.dueDate ? new Date(schedule.dueDate) : new Date(),
        notes: schedule.notes,
      }));

      await this.prisma.paymentSchedule.createMany({
        data: schedules,
      });
    }

    return contract;
  }

  /**
   * Lấy danh sách hợp đồng
   */
  async getContracts(projectId?: number, clientId?: number) {
    return this.prisma.contract.findMany({
      where: {
        ...(projectId && { projectId }),
        ...(clientId && { clientId }),
      },
      include: {
        project: {
          select: { id: true, title: true },
        },
        client: {
          select: { id: true, name: true, email: true },
        },
        quotation: {
          select: { id: true, quotationNo: true, total: true },
        },
        paymentSchedules: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Lấy chi tiết hợp đồng
   */
  async getContractById(id: number) {
    const contract = await this.prisma.contract.findUnique({
      where: { id },
      include: {
        project: true,
        client: {
          select: { id: true, name: true, email: true },
        },
        quotation: {
          include: {
            items: {
              include: {
                material: true,
              },
            },
          },
        },
        paymentSchedules: {
          orderBy: { phase: 'asc' },
        },
      },
    });

    if (!contract) {
      throw new NotFoundException('Contract not found');
    }

    return contract;
  }

  /**
   * Khách hàng ký hợp đồng điện tử (e-sign)
   */
  async signContract(id: number, userId: number, dto: SignContractDto) {
    const contract = await this.getContractById(id);

    if (contract.clientId !== userId) {
      throw new BadRequestException('Only contract owner can sign');
    }

    if (
      contract.status !== 'PENDING_SIGNATURE' &&
      contract.status !== 'DRAFT'
    ) {
      throw new BadRequestException(
        'Contract already signed or not ready for signature',
      );
    }

    return this.prisma.contract.update({
      where: { id },
      data: {
        clientSignature: dto.signature,
        clientSignedAt: new Date(),
        status: 'SIGNED',
      },
    });
  }

  /**
   * Công ty ký hợp đồng
   */
  async companySignContract(id: number, signature: string) {
    return this.prisma.contract.update({
      where: { id },
      data: {
        companySignature: signature,
        companySignedAt: new Date(),
        status: 'ACTIVE',
      },
    });
  }

  /**
   * Lấy lịch thanh toán của hợp đồng
   */
  async getPaymentSchedules(contractId: number) {
    return this.prisma.paymentSchedule.findMany({
      where: { contractId },
      include: {
        contract: {
          select: { id: true, contractNo: true, title: true },
        },
      },
      orderBy: { phase: 'asc' },
    });
  }

  /**
   * Cập nhật trạng thái thanh toán
   */
  async updatePaymentStatus(
    scheduleId: number,
    status: string,
    paidAmount?: number,
    paymentGateway?: string,
    paymentRef?: string,
  ) {
    return this.prisma.paymentSchedule.update({
      where: { id: scheduleId },
      data: {
        status,
        paidAmount: paidAmount || undefined,
        paidAt: status === 'PAID' ? new Date() : undefined,
        paymentGateway: paymentGateway as any,
        paymentRef,
      },
    });
  }

  /**
   * Tracking chi phí: Dự toán vs Thực tế
   */
  async trackCosts(projectId: number) {
    const costs = await this.prisma.costTracking.findMany({
      where: { projectId },
      orderBy: { date: 'desc' },
    });

    // Tính tổng
    const summary = {
      totalBudget: 0,
      totalActual: 0,
      totalVariance: 0,
      byCategory: {} as any,
    };

    costs.forEach((cost) => {
      summary.totalBudget += Number(cost.budgetCost);
      summary.totalActual += Number(cost.actualCost);
      summary.totalVariance += Number(cost.variance);

      if (!summary.byCategory[cost.category]) {
        summary.byCategory[cost.category] = {
          budget: 0,
          actual: 0,
          variance: 0,
        };
      }

      summary.byCategory[cost.category].budget += Number(cost.budgetCost);
      summary.byCategory[cost.category].actual += Number(cost.actualCost);
      summary.byCategory[cost.category].variance += Number(cost.variance);
    });

    return {
      costs,
      summary,
    };
  }

  /**
   * Thêm tracking chi phí
   */
  async addCostTracking(
    projectId: number,
    data: {
      itemName: string;
      category: string;
      budgetCost: number;
      actualCost: number;
      notes?: string;
    },
  ) {
    const variance = data.actualCost - data.budgetCost;
    const percentage =
      data.budgetCost > 0 ? (variance / data.budgetCost) * 100 : 0;

    return this.prisma.costTracking.create({
      data: {
        projectId,
        itemName: data.itemName,
        category: data.category,
        budgetCost: data.budgetCost,
        actualCost: data.actualCost,
        variance,
        percentage,
        notes: data.notes,
      },
    });
  }
}
