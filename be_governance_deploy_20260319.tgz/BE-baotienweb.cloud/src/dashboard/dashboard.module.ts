import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
// DISABLED: CRM module requires separate Prisma client (prisma-crm)
// import { CrmModule } from '../crm/crm.module';

@Module({
  imports: [PrismaModule], // Removed CrmModule temporarily
  controllers: [DashboardController],
  providers: [DashboardService],
  exports: [DashboardService],
})
export class DashboardModule {}
