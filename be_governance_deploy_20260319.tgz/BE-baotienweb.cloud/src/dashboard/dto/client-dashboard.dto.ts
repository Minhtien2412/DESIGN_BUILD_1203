import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class ProjectProgressDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  status: string;

  @ApiProperty({ description: 'Tiến độ thực tế (%)' })
  actualProgress: number;

  @ApiProperty({ description: 'Tiến độ kế hoạch (%)' })
  plannedProgress: number;

  @ApiPropertyOptional()
  startDate?: Date;

  @ApiPropertyOptional()
  endDate?: Date;

  @ApiPropertyOptional()
  engineerName?: string;

  @ApiPropertyOptional()
  budget?: number;

  @ApiPropertyOptional()
  spent?: number;

  @ApiProperty({ description: 'Hình ảnh tiến độ', type: [String] })
  images: string[];
}

export class ProjectDocumentDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  type: string; // CONTRACT, BLUEPRINT, QUOTATION, etc.

  @ApiProperty()
  fileUrl: string;

  @ApiProperty()
  fileName: string;

  @ApiPropertyOptional()
  fileSize?: number;

  @ApiPropertyOptional()
  version?: string;

  @ApiProperty()
  uploadedAt: Date;

  @ApiPropertyOptional()
  uploadedByName?: string;
}

export class MessagePreviewDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  message: string;

  @ApiProperty()
  senderName: string;

  @ApiProperty()
  sentAt: Date;

  @ApiProperty()
  isRead: boolean;

  @ApiProperty()
  roomId: number;
}

export class VideoCallStatusDto {
  @ApiProperty()
  available: boolean;

  @ApiPropertyOptional()
  engineerName?: string;

  @ApiPropertyOptional()
  engineerOnline?: boolean;

  @ApiPropertyOptional()
  lastCall?: Date;
}

export class ClientDashboardDto {
  @ApiProperty({ description: 'Tiến độ dự án', type: [ProjectProgressDto] })
  projectProgress: ProjectProgressDto[];

  @ApiProperty({
    description: 'Tài liệu dự án (bản vẽ, hợp đồng, báo giá)',
    type: [ProjectDocumentDto],
  })
  documents: ProjectDocumentDto[];

  @ApiProperty({ description: 'Tin nhắn chưa đọc', type: [MessagePreviewDto] })
  unreadMessages: MessagePreviewDto[];

  @ApiProperty({
    description: 'Trạng thái video call',
    type: VideoCallStatusDto,
  })
  videoCallStatus: VideoCallStatusDto;

  @ApiPropertyOptional({
    description: 'Báo cáo tiến độ gần đây',
    type: [Object],
  })
  recentReports?: any[];

  @ApiPropertyOptional({ description: 'Thống kê tổng quan' })
  stats?: {
    totalProjects: number;
    activeProjects: number;
    completedProjects: number;
    totalSpent: number;
    totalBudget: number;
  };
}
