import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class RevenueStatsDto {
  @ApiProperty({ description: 'Tổng doanh thu' })
  total: number;

  @ApiProperty({ description: 'Doanh thu tháng này' })
  thisMonth: number;

  @ApiProperty({ description: 'Doanh thu tháng trước' })
  lastMonth: number;

  @ApiProperty({ description: 'Tăng trưởng (%)' })
  growth: number;

  @ApiPropertyOptional({ description: 'Doanh thu theo tháng', type: [Object] })
  byMonth?: { month: string; amount: number }[];
}

export class ProjectStatsDto {
  @ApiProperty({ description: 'Tổng số dự án' })
  total: number;

  @ApiProperty({ description: 'Đang thực hiện' })
  inProgress: number;

  @ApiProperty({ description: 'Hoàn thành' })
  completed: number;

  @ApiProperty({ description: 'Kế hoạch' })
  planning: number;

  @ApiProperty({ description: 'Tạm dừng' })
  onHold: number;

  @ApiProperty({ description: 'Đã hủy' })
  cancelled: number;
}

export class ProgressStatsDto {
  @ApiProperty({ description: 'Tiến độ trung bình (%)' })
  averageProgress: number;

  @ApiProperty({ description: 'Số dự án đúng tiến độ' })
  onTrack: number;

  @ApiProperty({ description: 'Số dự án chậm tiến độ' })
  delayed: number;

  @ApiProperty({ description: 'Chi tiết tiến độ theo dự án', type: [Object] })
  projectProgress: {
    projectId: number;
    projectName: string;
    progress: number;
  }[];
}

export class IssueStatsDto {
  @ApiProperty({ description: 'Tổng số vấn đề' })
  total: number;

  @ApiProperty({ description: 'Nghiêm trọng' })
  critical: number;

  @ApiProperty({ description: 'Cần xử lý' })
  pending: number;

  @ApiProperty({ description: 'Đã giải quyết' })
  resolved: number;

  @ApiPropertyOptional({
    description: 'Danh sách vấn đề gần đây',
    type: [Object],
  })
  recentIssues?: any[];
}

export class AttendanceStatsDto {
  @ApiProperty({ description: 'Tổng nhân sự' })
  totalStaff: number;

  @ApiProperty({ description: 'Có mặt hôm nay' })
  presentToday: number;

  @ApiProperty({ description: 'Vắng mặt' })
  absent: number;

  @ApiProperty({ description: 'Đi muộn' })
  late: number;

  @ApiProperty({ description: 'Nghỉ phép' })
  onLeave: number;

  @ApiPropertyOptional({
    description: 'Chi tiết chấm công hôm nay',
    type: [Object],
  })
  todayAttendance?: any[];
}

export class AdminDashboardDto {
  @ApiProperty({ description: 'Thống kê doanh thu', type: RevenueStatsDto })
  revenue: RevenueStatsDto;

  @ApiProperty({ description: 'Thống kê dự án', type: ProjectStatsDto })
  projects: ProjectStatsDto;

  @ApiProperty({ description: 'Thống kê tiến độ', type: ProgressStatsDto })
  progress: ProgressStatsDto;

  @ApiProperty({ description: 'Thống kê lỗi/vấn đề', type: IssueStatsDto })
  issues: IssueStatsDto;

  @ApiProperty({
    description: 'Thống kê nhân sự & chấm công',
    type: AttendanceStatsDto,
  })
  attendance: AttendanceStatsDto;

  @ApiPropertyOptional({ description: 'Hoạt động gần đây', type: [Object] })
  recentActivities?: any[];
}
