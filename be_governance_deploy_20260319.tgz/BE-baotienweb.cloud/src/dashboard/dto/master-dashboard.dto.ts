import { ApiProperty } from '@nestjs/swagger';

/**
 * MASTER DASHBOARD - Tổng quan toàn bộ hệ thống
 * Quản lý tất cả modules: Users, Projects, Tasks, Products, Payments, CRM, AI, etc.
 */
export class MasterDashboardDto {
  @ApiProperty({
    description: 'Thống kê người dùng',
    example: {
      totalUsers: 150,
      admins: 5,
      engineers: 45,
      clients: 100,
      activeToday: 87,
      newThisMonth: 12,
    },
  })
  users: {
    totalUsers: number;
    admins: number;
    engineers: number;
    clients: number;
    activeToday: number;
    newThisMonth: number;
  };

  @ApiProperty({
    description: 'Thống kê dự án',
    example: {
      total: 78,
      planning: 5,
      inProgress: 23,
      completed: 45,
      onHold: 3,
      cancelled: 2,
      completionRate: 57.7,
    },
  })
  projects: {
    total: number;
    planning: number;
    inProgress: number;
    completed: number;
    onHold: number;
    cancelled: number;
    completionRate: number;
  };

  @ApiProperty({
    description: 'Thống kê công việc (tasks)',
    example: {
      total: 456,
      todo: 123,
      inProgress: 78,
      done: 255,
      urgent: 12,
      high: 34,
      completionRate: 55.9,
    },
  })
  tasks: {
    total: number;
    todo: number;
    inProgress: number;
    done: number;
    urgent: number;
    high: number;
    completionRate: number;
  };

  @ApiProperty({
    description: 'Thống kê sản phẩm',
    example: {
      totalProducts: 234,
      inStock: 198,
      outOfStock: 36,
      lowStock: 15,
      totalValue: 1250000000,
      categories: 12,
    },
  })
  products: {
    totalProducts: number;
    inStock: number;
    outOfStock: number;
    lowStock: number;
    totalValue: number;
    categories: number;
  };

  @ApiProperty({
    description: 'Thống kê thanh toán',
    example: {
      totalRevenue: 5600000000,
      thisMonth: 450000000,
      lastMonth: 380000000,
      growth: 18.4,
      pending: 125000000,
      completed: 5475000000,
      failed: 0,
    },
  })
  payments: {
    totalRevenue: number;
    thisMonth: number;
    lastMonth: number;
    growth: number;
    pending: number;
    completed: number;
    failed: number;
  };

  @ApiProperty({
    description: 'Thống kê CRM (Perfex CRM)',
    example: {
      totalClients: 89,
      activeClients: 67,
      totalProjects: 56,
      activeProjects: 23,
      totalInvoices: 178,
      paidInvoices: 145,
      unpaidInvoices: 33,
      totalTickets: 234,
      openTickets: 45,
      resolvedTickets: 189,
    },
  })
  crm: {
    totalClients: number;
    activeClients: number;
    totalProjects: number;
    activeProjects: number;
    totalInvoices: number;
    paidInvoices: number;
    unpaidInvoices: number;
    totalTickets: number;
    openTickets: number;
    resolvedTickets: number;
  };

  @ApiProperty({
    description: 'Thống kê AI',
    example: {
      totalRequests: 1234,
      thisMonth: 456,
      avgResponseTime: 2.3,
      successRate: 98.5,
      topFeatures: [
        { feature: 'Construction Analysis', count: 567 },
        { feature: 'Material Calculation', count: 345 },
        { feature: 'Cost Estimation', count: 234 },
      ],
    },
  })
  ai: {
    totalRequests: number;
    thisMonth: number;
    avgResponseTime: number;
    successRate: number;
    topFeatures: Array<{ feature: string; count: number }>;
  };

  @ApiProperty({
    description: 'Thống kê chat',
    example: {
      totalRooms: 67,
      activeRooms: 23,
      totalMessages: 12345,
      todayMessages: 234,
      unreadMessages: 45,
    },
  })
  chat: {
    totalRooms: number;
    activeRooms: number;
    totalMessages: number;
    todayMessages: number;
    unreadMessages: number;
  };

  @ApiProperty({
    description: 'Thống kê video call',
    example: {
      totalCalls: 456,
      thisMonth: 67,
      avgDuration: 23.5,
      totalMinutes: 10890,
    },
  })
  video: {
    totalCalls: number;
    thisMonth: number;
    avgDuration: number;
    totalMinutes: number;
  };

  @ApiProperty({
    description: 'Thống kê tài liệu upload',
    example: {
      totalFiles: 3456,
      totalSize: 15360000000,
      thisMonth: 234,
      byType: {
        images: 2134,
        videos: 456,
        documents: 678,
        others: 188,
      },
    },
  })
  uploads: {
    totalFiles: number;
    totalSize: number;
    thisMonth: number;
    byType: {
      images: number;
      videos: number;
      documents: number;
      others: number;
    };
  };

  @ApiProperty({
    description: 'Thống kê chấm công',
    example: {
      totalStaff: 50,
      presentToday: 47,
      absent: 2,
      late: 1,
      onLeave: 0,
      avgAttendanceRate: 94.5,
    },
  })
  attendance: {
    totalStaff: number;
    presentToday: number;
    absent: number;
    late: number;
    onLeave: number;
    avgAttendanceRate: number;
  };

  @ApiProperty({
    description: 'Thống kê hợp đồng',
    example: {
      total: 123,
      draft: 5,
      active: 78,
      expired: 34,
      totalValue: 12500000000,
      expiringThisMonth: 8,
    },
  })
  contracts: {
    total: number;
    draft: number;
    active: number;
    expired: number;
    totalValue: number;
    expiringThisMonth: number;
  };

  @ApiProperty({
    description: 'Thống kê timeline & tiến độ',
    example: {
      totalEvents: 1234,
      thisWeek: 67,
      todayActivities: 23,
      upcomingMilestones: 12,
    },
  })
  timeline: {
    totalEvents: number;
    thisWeek: number;
    todayActivities: number;
    upcomingMilestones: number;
  };

  @ApiProperty({
    description: 'Thống kê QC (Quality Control)',
    example: {
      totalInspections: 456,
      passed: 389,
      failed: 67,
      pending: 34,
      passRate: 85.3,
    },
  })
  qc: {
    totalInspections: number;
    passed: number;
    failed: number;
    pending: number;
    passRate: number;
  };

  @ApiProperty({
    description: 'Hoạt động gần đây (tất cả modules)',
    example: [
      {
        id: 1,
        module: 'CRM',
        event: 'New Client Registered',
        description: 'nguyenvana@test.com registered',
        createdAt: '2025-01-20T10:30:00Z',
      },
      {
        id: 2,
        module: 'Projects',
        event: 'Project Completed',
        description: 'Project "Villa Thao Dien" completed',
        createdAt: '2025-01-20T09:15:00Z',
      },
    ],
  })
  recentActivities: Array<{
    id: number;
    module: string;
    event: string;
    description: string;
    createdAt: Date;
  }>;

  @ApiProperty({
    description: 'Cảnh báo hệ thống',
    example: [
      {
        type: 'warning',
        module: 'Products',
        message: '15 products have low stock',
        severity: 'medium',
      },
      {
        type: 'error',
        module: 'Payments',
        message: '3 payments failed this week',
        severity: 'high',
      },
    ],
  })
  systemAlerts: Array<{
    type: 'info' | 'warning' | 'error';
    module: string;
    message: string;
    severity: 'low' | 'medium' | 'high';
  }>;

  @ApiProperty({
    description: 'Tổng quan dữ liệu tháng',
    example: [
      { month: '2024-07', revenue: 350000000, projects: 8, newClients: 5 },
      { month: '2024-08', revenue: 420000000, projects: 12, newClients: 7 },
      { month: '2024-09', revenue: 380000000, projects: 9, newClients: 6 },
      { month: '2024-10', revenue: 460000000, projects: 14, newClients: 9 },
      { month: '2024-11', revenue: 510000000, projects: 16, newClients: 11 },
      { month: '2024-12', revenue: 450000000, projects: 13, newClients: 8 },
    ],
  })
  monthlyOverview: Array<{
    month: string;
    revenue: number;
    projects: number;
    newClients: number;
  }>;
}
