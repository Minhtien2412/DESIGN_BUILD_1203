import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class AssignedProjectDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  progress: number;

  @ApiPropertyOptional()
  dueDate?: Date;

  @ApiProperty()
  tasksTotal: number;

  @ApiProperty()
  tasksCompleted: number;

  @ApiPropertyOptional()
  clientName?: string;
}

export class DailyTaskDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  priority: string;

  @ApiPropertyOptional()
  dueDate?: Date;

  @ApiProperty()
  projectName: string;

  @ApiPropertyOptional()
  estimatedHours?: number;
}

export class ChecklistItemDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  completed: boolean;

  @ApiProperty()
  priority: string;

  @ApiPropertyOptional()
  dueDate?: Date;
}

export class DailyReportSummaryDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  date: Date;

  @ApiProperty()
  projectName: string;

  @ApiProperty()
  imageCount: number;

  @ApiProperty()
  videoCount: number;
}

export class EngineerDashboardDto {
  @ApiProperty({
    description: 'Dự án được phân công',
    type: [AssignedProjectDto],
  })
  assignedProjects: AssignedProjectDto[];

  @ApiProperty({ description: 'Task hôm nay', type: [DailyTaskDto] })
  todayTasks: DailyTaskDto[];

  @ApiProperty({ description: 'Checklist công việc', type: [ChecklistItemDto] })
  checklist: ChecklistItemDto[];

  @ApiProperty({
    description: 'Báo cáo gần đây',
    type: [DailyReportSummaryDto],
  })
  recentReports: DailyReportSummaryDto[];

  @ApiPropertyOptional({ description: 'Thống kê công việc' })
  stats?: {
    totalTasks: number;
    completedTasks: number;
    pendingTasks: number;
    todayCheckIns: number;
  };
}
