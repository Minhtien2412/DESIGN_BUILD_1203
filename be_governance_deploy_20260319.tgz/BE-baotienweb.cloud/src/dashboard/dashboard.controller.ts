import { Controller, Get, Request, UseGuards } from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { Roles } from '../auth/decorators/roles.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { DashboardService } from './dashboard.service';
import {
    AdminDashboardDto,
    ClientDashboardDto,
    EngineerDashboardDto,
    MasterDashboardDto,
} from './dto';

@ApiTags('Dashboard')
@Controller({ path: 'dashboard', version: '1' })
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Get()
  @ApiOperation({
    summary: 'Dashboard Overview - Tự động theo role của user',
    description:
      'Trả về dashboard tương ứng với role của user (ADMIN/ENGINEER/CLIENT)',
  })
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getDashboardByRole(@Request() req) {
    const role = req.user.role;
    switch (role) {
      case 'ADMIN':
        return this.dashboardService.getAdminDashboard(req.user.id);
      case 'ENGINEER':
        return this.dashboardService.getEngineerDashboard(req.user.id);
      case 'CLIENT':
        return this.dashboardService.getClientDashboard(req.user.id);
      default:
        return this.dashboardService.getClientDashboard(req.user.id);
    }
  }

  @Get('stats')
  @ApiOperation({
    summary: 'Dashboard Stats - Thống kê nhanh (public)',
    description: 'Thống kê cơ bản không cần authentication',
  })
  async getPublicStats() {
    return this.dashboardService.getPublicStats();
  }

  @Get('admin')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({
    summary:
      'Dashboard Admin - Tổng quan doanh thu, dự án, tiến độ, lỗi, nhân sự',
    description:
      'Chỉ ADMIN mới truy cập được. Hiển thị toàn bộ thống kê hệ thống.',
  })
  @ApiResponse({ status: 200, type: AdminDashboardDto })
  async getAdminDashboard(@Request() req): Promise<AdminDashboardDto> {
    return this.dashboardService.getAdminDashboard(req.user.id);
  }

  @Get('engineer')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Dashboard Kỹ sư - Dự án, Task hôm nay, Checklist, Báo cáo',
    description:
      'Chỉ ENGINEER truy cập. Quản lý công việc và gửi báo cáo hàng ngày.',
  })
  @ApiResponse({ status: 200, type: EngineerDashboardDto })
  async getEngineerDashboard(@Request() req): Promise<EngineerDashboardDto> {
    return this.dashboardService.getEngineerDashboard(req.user.id);
  }

  @Get('client')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Dashboard Khách hàng - Tiến độ, Tài liệu, Chat, Video call',
    description:
      'Chỉ CLIENT truy cập. Xem tiến độ thực tế, bản vẽ, hợp đồng, nhắn tin kỹ sư.',
  })
  @ApiResponse({ status: 200, type: ClientDashboardDto })
  async getClientDashboard(@Request() req): Promise<ClientDashboardDto> {
    return this.dashboardService.getClientDashboard(req.user.id);
  }

  @Get('master')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Master Dashboard - Tổng quan TOÀN BỘ hệ thống (All modules)',
    description:
      'Chỉ ADMIN truy cập. Quản lý dashboard tổng thể: Users, Projects, Tasks, Products, Payments, CRM, AI, Chat, Video, Uploads, Attendance, Contracts, Timeline, QC và các hoạt động gần đây.',
  })
  @ApiResponse({ status: 200, type: MasterDashboardDto })
  async getMasterDashboard(@Request() req): Promise<MasterDashboardDto> {
    return this.dashboardService.getMasterDashboard(req.user.id);
  }
}
