import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    ApproveChangeOrderDto,
    AssessImpactDto,
    CreateChangeOrderDto,
    CreateChangeRequestDto,
    CreateCMChangeOrderDto,
    CreateRevisionDto,
    ImplementChangeOrderDto,
    UpdateChangeOrderDto,
    UpdateChangeRequestDto,
    UpdateCMChangeOrderDto,
} from './dto';

@Injectable()
export class ChangeManagementService {
  constructor(private prisma: PrismaService) {}

  // ==================== Change Requests ====================

  async getRequests(
    projectId?: number,
    status?: string,
    _category?: string,
    priority?: string,
  ) {
    return this.prisma.changeRequest.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(status ? { status: status as any } : {}),
        ...(priority ? { priority: priority as any } : {}),
      },
      include: {
        project: { select: { id: true, title: true } },
        requestedBy: { select: { id: true, name: true, avatar: true } },
        orders: { select: { id: true, title: true, status: true } },
        _count: { select: { orders: true, attachments: true, logs: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getRequestById(id: number) {
    const request = await this.prisma.changeRequest.findUnique({
      where: { id },
      include: {
        project: { select: { id: true, title: true } },
        requestedBy: { select: { id: true, name: true, avatar: true } },
        reviewedBy: { select: { id: true, name: true } },
        orders: true,
        attachments: true,
        logs: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!request) throw new NotFoundException('Change request not found');
    return request;
  }

  async createRequest(data: CreateChangeRequestDto, userId: number) {
    return this.prisma.changeRequest.create({
      data: {
        title: data.title,
        description: data.description,
        projectId: data.projectId,
        priority: (data.priority as any) ?? 'MEDIUM',
        category: data.category,
        reason: data.origin,
        justification: data.justification,
        currentSituation: data.currentSituation,
        proposedSolution: data.proposedSolution,
        impact: data.impact,
        affectedAreas: data.affectedAreas ?? [],
        costImpact: data.costImpact,
        scheduleImpact: data.scheduleImpact,
        requestedById: userId,
      },
    });
  }

  async updateRequest(id: number, data: UpdateChangeRequestDto) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: {
        ...(data.title !== undefined ? { title: data.title } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.priority !== undefined
          ? { priority: data.priority as any }
          : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.justification !== undefined
          ? { justification: data.justification }
          : {}),
        ...(data.currentSituation !== undefined
          ? { currentSituation: data.currentSituation }
          : {}),
        ...(data.proposedSolution !== undefined
          ? { proposedSolution: data.proposedSolution }
          : {}),
        ...(data.impact !== undefined ? { impact: data.impact } : {}),
        ...(data.affectedAreas !== undefined
          ? { affectedAreas: data.affectedAreas }
          : {}),
        ...(data.costImpact !== undefined
          ? { costImpact: data.costImpact }
          : {}),
        ...(data.scheduleImpact !== undefined
          ? { scheduleImpact: data.scheduleImpact }
          : {}),
      },
    });
  }

  async deleteRequest(id: number) {
    return this.prisma.changeRequest.delete({ where: { id } });
  }

  async submitRequest(id: number) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: { status: 'SUBMITTED' },
    });
  }

  async assessImpact(id: number, data: AssessImpactDto) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: {
        status: 'UNDER_REVIEW',
        impact: data.impactAssessment,
        ...(data.costImpact !== undefined
          ? { costImpact: data.costImpact }
          : {}),
        ...(data.scheduleImpact !== undefined
          ? { scheduleImpact: data.scheduleImpact }
          : {}),
      },
    });
  }

  async approveRequest(id: number, userId: number, comments?: string) {
    const req = await this.prisma.changeRequest.update({
      where: { id },
      data: {
        status: 'APPROVED',
        reviewedById: userId,
        reviewedAt: new Date(),
      },
    });
    await this.addLog(
      id,
      'APPROVED',
      `Request approved${comments ? ': ' + comments : ''}`,
      userId,
    );
    return req;
  }

  async rejectRequest(id: number, userId: number, reason: string) {
    const req = await this.prisma.changeRequest.update({
      where: { id },
      data: {
        status: 'REJECTED',
        reviewedById: userId,
        reviewedAt: new Date(),
      },
    });
    await this.addLog(id, 'REJECTED', reason, userId);
    return req;
  }

  async holdRequest(id: number, reason: string) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: { status: 'ON_HOLD' },
    });
  }

  async implementRequest(id: number) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: { status: 'IMPLEMENTING' },
    });
  }

  async cancelRequest(id: number, reason: string) {
    return this.prisma.changeRequest.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });
  }

  async selectAlternative(requestId: number, alternativeId: string) {
    const existing = await this.prisma.changeRequest.findUnique({
      where: { id: requestId },
    });
    if (!existing) throw new NotFoundException('Change request not found');
    const alts = (existing.alternatives as any[]) ?? [];
    return this.prisma.changeRequest.update({
      where: { id: requestId },
      data: { alternatives: { selected: alternativeId, options: alts } as any },
    });
  }

  // ==================== CM Change Orders (/change-management/orders) ====================

  async getCMOrders(projectId?: number, status?: string) {
    return this.prisma.changeOrder.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(status ? { status: status as any } : {}),
      },
      include: {
        project: { select: { id: true, title: true } },
        request: { select: { id: true, title: true } },
        _count: { select: { attachments: true, logs: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getCMOrderById(id: number) {
    const order = await this.prisma.changeOrder.findUnique({
      where: { id },
      include: {
        project: true,
        request: true,
        createdBy: { select: { id: true, name: true } },
        attachments: true,
        logs: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!order) throw new NotFoundException('Change order not found');
    return order;
  }

  async createCMOrder(data: CreateCMChangeOrderDto, userId: number) {
    return this.prisma.changeOrder.create({
      data: {
        title: data.title,
        description: data.description,
        projectId: data.projectId,
        requestId: data.changeRequestId,
        orderNumber: data.orderNumber,
        type: data.type,
        priority: data.priority ? (data.priority as any) : undefined,
        estimatedCost: data.costImpact,
        costBreakdown: data.costBreakdown,
        scopeOfWork: data.scopeOfWork,
        specifications: data.specifications,
        scheduleExtension: data.scheduleExtension,
        createdById: userId,
      },
    });
  }

  async updateCMOrder(id: number, data: UpdateCMChangeOrderDto) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: {
        ...(data.title !== undefined ? { title: data.title } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.type !== undefined ? { type: data.type } : {}),
        ...(data.priority !== undefined
          ? { priority: data.priority as any }
          : {}),
        ...(data.costImpact !== undefined
          ? { estimatedCost: data.costImpact }
          : {}),
        ...(data.costBreakdown !== undefined
          ? { costBreakdown: data.costBreakdown }
          : {}),
        ...(data.scopeOfWork !== undefined
          ? { scopeOfWork: data.scopeOfWork }
          : {}),
        ...(data.specifications !== undefined
          ? { specifications: data.specifications }
          : {}),
        ...(data.scheduleExtension !== undefined
          ? { scheduleExtension: data.scheduleExtension }
          : {}),
      },
    });
  }

  async deleteCMOrder(id: number) {
    return this.prisma.changeOrder.delete({ where: { id } });
  }

  async issueCMOrder(id: number) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'ISSUED' },
    });
  }

  async acceptCMOrder(id: number, comments?: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'ACCEPTED' },
    });
  }

  async rejectCMOrder(id: number, reason: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'REJECTED' },
    });
  }

  async startExecution(id: number, startDate: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'IN_PROGRESS', startDate: new Date(startDate) },
    });
  }

  async updateExecutionProgress(id: number, progress: number) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { progress },
    });
  }

  async completeExecution(id: number, completionDate: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'COMPLETED', endDate: new Date(completionDate) },
    });
  }

  async closeCMOrder(id: number) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'CLOSED' },
    });
  }

  async exportCMOrder(id: number) {
    return this.getCMOrderById(id);
  }

  // ==================== Logs ====================

  async getRequestLogs(requestId: number) {
    return this.prisma.changeLog.findMany({
      where: { changeRequestId: requestId },
      include: { performedBy: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getOrderLogs(orderId: number) {
    return this.prisma.changeLog.findMany({
      where: { changeOrderId: orderId },
      include: { performedBy: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  private async addLog(
    changeRequestId: number,
    action: string,
    details: string,
    userId: number,
  ) {
    return this.prisma.changeLog.create({
      data: { changeRequestId, action, details, performedById: userId },
    });
  }

  // ==================== Analytics ====================

  async getAnalytics(projectId?: number) {
    const where = projectId ? { projectId } : {};
    const [totalRequests, pendingRequests, approvedRequests, totalOrders] =
      await Promise.all([
        this.prisma.changeRequest.count({ where }),
        this.prisma.changeRequest.count({
          where: { ...where, status: 'SUBMITTED' },
        }),
        this.prisma.changeRequest.count({
          where: { ...where, status: 'APPROVED' },
        }),
        this.prisma.changeOrder.count({ where }),
      ]);

    return { totalRequests, pendingRequests, approvedRequests, totalOrders };
  }

  async getProjectImpact(projectId: number) {
    const orders = await this.prisma.changeOrder.findMany({
      where: { projectId },
      select: { estimatedCost: true, status: true },
    });

    const totalCostImpact = orders.reduce(
      (sum, o) => sum + Number(o.estimatedCost ?? 0),
      0,
    );

    return {
      totalCostImpact,
      changesByStatus: Object.entries(
        orders.reduce(
          (acc, o) => ({ ...acc, [o.status]: (acc[o.status] || 0) + 1 }),
          {} as Record<string, number>,
        ),
      ).map(([status, count]) => ({ status, count })),
    };
  }

  async exportRegister(projectId: number) {
    const requests = await this.getRequests(projectId);
    const orders = await this.getCMOrders(projectId);
    return { requests, orders };
  }

  async compareAlternatives(requestId: number) {
    return { alternatives: [], recommendation: null };
  }

  async getForecast(projectId: number) {
    return {
      forecastedChanges: 0,
      forecastedCost: 0,
      forecastedDelay: 0,
      confidence: 0,
    };
  }

  // ==================== Standalone Change Orders (/change-orders) ====================

  async getStandaloneOrders(
    projectId?: number,
    type?: string,
    status?: string,
    priority?: string,
    search?: string,
  ) {
    return this.prisma.changeOrder.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(status ? { status: status as any } : {}),
        ...(search
          ? { title: { contains: search, mode: 'insensitive' as const } }
          : {}),
      },
      include: {
        project: { select: { id: true, title: true } },
        request: { select: { id: true, title: true } },
        createdBy: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getStandaloneOrderById(id: number) {
    return this.getCMOrderById(id);
  }

  async createStandaloneOrder(data: CreateChangeOrderDto, userId: number) {
    return this.prisma.changeOrder.create({
      data: {
        title: data.title,
        description: data.description,
        projectId: data.projectId,
        orderNumber: data.orderNumber,
        type: data.type,
        priority: data.priority ? (data.priority as any) : undefined,
        estimatedCost: data.costImpact,
        costBreakdown: data.costBreakdown,
        scopeOfWork: data.scopeOfWork,
        specifications: data.specifications,
        scheduleExtension: data.scheduleExtension,
        createdById: userId,
      },
    });
  }

  async updateStandaloneOrder(id: number, data: UpdateChangeOrderDto) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: {
        ...(data.title !== undefined ? { title: data.title } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.status !== undefined ? { status: data.status as any } : {}),
        ...(data.type !== undefined ? { type: data.type } : {}),
        ...(data.priority !== undefined
          ? { priority: data.priority as any }
          : {}),
        ...(data.costImpact !== undefined
          ? { estimatedCost: data.costImpact }
          : {}),
        ...(data.costBreakdown !== undefined
          ? { costBreakdown: data.costBreakdown }
          : {}),
        ...(data.scopeOfWork !== undefined
          ? { scopeOfWork: data.scopeOfWork }
          : {}),
        ...(data.specifications !== undefined
          ? { specifications: data.specifications }
          : {}),
        ...(data.scheduleExtension !== undefined
          ? { scheduleExtension: data.scheduleExtension }
          : {}),
      },
    });
  }

  async deleteStandaloneOrder(id: number) {
    return this.prisma.changeOrder.delete({ where: { id } });
  }

  async submitOrder(id: number, notes?: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'ISSUED' },
    });
  }

  async reviewOrder(id: number, comments: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'ISSUED' },
    });
  }

  async approveOrder(id: number, data: ApproveChangeOrderDto) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'ACCEPTED' },
    });
  }

  async rejectOrder(id: number, reason: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'REJECTED' },
    });
  }

  async implementOrder(id: number, data: ImplementChangeOrderDto) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: {
        status: 'IN_PROGRESS',
        startDate: data.startDate ? new Date(data.startDate) : new Date(),
      },
    });
  }

  async completeOrder(id: number, notes?: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'COMPLETED', endDate: new Date() },
    });
  }

  async cancelOrder(id: number, reason: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { status: 'CLOSED' },
    });
  }

  async createRevision(id: number, data: CreateRevisionDto) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { description: `Revision ${data.revisionNumber}: ${data.changes}` },
    });
  }

  async delegateApproval(id: number, approvalId: string, delegateToId: string) {
    return { message: 'Approval delegated' };
  }

  async updateImplProgress(id: number, progress: number, description: string) {
    return this.prisma.changeOrder.update({
      where: { id },
      data: { progress },
    });
  }

  async getTemplates(type?: string) {
    return [];
  }

  async getTemplate(id: number) {
    return null;
  }

  async createFromTemplate(templateId: number, body: any) {
    return null;
  }

  async getOrderSummary(projectId: number) {
    const orders = await this.prisma.changeOrder.findMany({
      where: { projectId },
    });
    return {
      total: orders.length,
      totalCostImpact: orders.reduce(
        (s, o) => s + Number(o.estimatedCost ?? 0),
        0,
      ),
    };
  }

  async getStandaloneOrderLogs(id: number) {
    return this.getOrderLogs(id);
  }

  async getProjectOrderLogs(projectId: number) {
    return this.prisma.changeLog.findMany({
      where: { changeOrder: { projectId } },
      include: { performedBy: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getOrderAnalytics(projectId: number) {
    return this.getAnalytics(projectId);
  }

  async getCostAnalysis(projectId?: number) {
    const where = projectId ? { projectId } : {};
    const orders = await this.prisma.changeOrder.findMany({
      where,
      select: { estimatedCost: true },
    });
    const totalIncrease = orders
      .filter((o) => Number(o.estimatedCost ?? 0) > 0)
      .reduce((s, o) => s + Number(o.estimatedCost ?? 0), 0);
    const totalDecrease = Math.abs(
      orders
        .filter((o) => Number(o.estimatedCost ?? 0) < 0)
        .reduce((s, o) => s + Number(o.estimatedCost ?? 0), 0),
    );
    return {
      totalIncrease,
      totalDecrease,
      netChange: totalIncrease - totalDecrease,
    };
  }

  async getScheduleAnalysis(projectId?: number) {
    const where = projectId ? { projectId } : {};
    const orders = await this.prisma.changeOrder.findMany({
      where,
      select: { startDate: true, endDate: true },
    });
    const totalDelay = 0;
    return { totalDelay, totalAcceleration: 0, netChange: totalDelay };
  }

  async exportOrderRegister(projectId: number) {
    return this.getStandaloneOrders(projectId);
  }

  async exportOrderPackage(id: number) {
    return this.getStandaloneOrderById(id);
  }
}
