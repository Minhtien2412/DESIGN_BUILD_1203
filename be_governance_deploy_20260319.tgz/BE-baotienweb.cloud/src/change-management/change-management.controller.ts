import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Post,
    Put,
    Query,
    Req,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ChangeManagementService } from './change-management.service';
import {
    ActionWithReasonDto,
    ApproveChangeOrderDto,
    AssessImpactDto,
    CreateChangeOrderDto,
    CreateChangeRequestDto,
    CreateCMChangeOrderDto,
    CreateRevisionDto,
    DelegateApprovalDto,
    ImplementChangeOrderDto,
    UpdateChangeOrderDto,
    UpdateChangeRequestDto,
    UpdateCMChangeOrderDto,
    UpdateProgressDto,
} from './dto';

// ==================== /change-management/* Controller ====================
@ApiTags('Change Management')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'change-management', version: '1' })
export class ChangeManagementController {
  constructor(private readonly service: ChangeManagementService) {}

  // --- Requests ---
  @Get('requests')
  @ApiOperation({ summary: 'List change requests' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'category', required: false })
  @ApiQuery({ name: 'priority', required: false })
  getRequests(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
    @Query('category') category?: string,
    @Query('priority') priority?: string,
  ) {
    return this.service.getRequests(
      projectId ? +projectId : undefined,
      status,
      category,
      priority,
    );
  }

  @Get('requests/:id')
  @ApiOperation({ summary: 'Get change request by ID' })
  getRequest(@Param('id', ParseIntPipe) id: number) {
    return this.service.getRequestById(id);
  }

  @Post('requests')
  @ApiOperation({ summary: 'Create change request' })
  createRequest(@Body() dto: CreateChangeRequestDto, @Req() req: any) {
    return this.service.createRequest(dto, req.user?.id);
  }

  @Put('requests/:id')
  @ApiOperation({ summary: 'Update change request' })
  updateRequest(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateChangeRequestDto,
  ) {
    return this.service.updateRequest(id, dto);
  }

  @Delete('requests/:id')
  @ApiOperation({ summary: 'Delete change request' })
  deleteRequest(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteRequest(id);
  }

  @Post('requests/:id/submit')
  @ApiOperation({ summary: 'Submit change request for review' })
  submitRequest(@Param('id', ParseIntPipe) id: number) {
    return this.service.submitRequest(id);
  }

  @Post('requests/:id/assess')
  @ApiOperation({ summary: 'Assess change impact' })
  assessImpact(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: AssessImpactDto,
  ) {
    return this.service.assessImpact(id, dto);
  }

  @Post('requests/:id/approve')
  @ApiOperation({ summary: 'Approve change request' })
  approveRequest(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.approveRequest(id, req.user?.id, body.comments);
  }

  @Post('requests/:id/reject')
  @ApiOperation({ summary: 'Reject change request' })
  rejectRequest(
    @Param('id', ParseIntPipe) id: number,
    @Req() req: any,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.rejectRequest(id, req.user?.id, body.reason ?? '');
  }

  @Post('requests/:id/hold')
  @ApiOperation({ summary: 'Put change request on hold' })
  holdRequest(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.holdRequest(id, body.reason ?? '');
  }

  @Post('requests/:id/implement')
  @ApiOperation({ summary: 'Mark change request as implementing' })
  implementRequest(@Param('id', ParseIntPipe) id: number) {
    return this.service.implementRequest(id);
  }

  @Post('requests/:id/cancel')
  @ApiOperation({ summary: 'Cancel change request' })
  cancelRequest(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.cancelRequest(id, body.reason ?? '');
  }

  @Post('requests/:id/select-alternative')
  @ApiOperation({ summary: 'Select an alternative for change request' })
  selectAlternative(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { alternativeId: string },
  ) {
    return this.service.selectAlternative(id, body.alternativeId);
  }

  @Get('requests/:id/logs')
  @ApiOperation({ summary: 'Get change request logs' })
  getRequestLogs(@Param('id', ParseIntPipe) id: number) {
    return this.service.getRequestLogs(id);
  }

  @Get('requests/:id/compare-alternatives')
  @ApiOperation({ summary: 'Compare alternatives for change request' })
  compareAlternatives(@Param('id', ParseIntPipe) id: number) {
    return this.service.compareAlternatives(id);
  }

  // --- Orders ---
  @Get('orders')
  @ApiOperation({ summary: 'List change orders' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'status', required: false })
  getOrders(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
  ) {
    return this.service.getCMOrders(projectId ? +projectId : undefined, status);
  }

  @Get('orders/:id')
  @ApiOperation({ summary: 'Get change order by ID' })
  getOrder(@Param('id', ParseIntPipe) id: number) {
    return this.service.getCMOrderById(id);
  }

  @Post('orders')
  @ApiOperation({ summary: 'Create change order' })
  createOrder(@Body() dto: CreateCMChangeOrderDto, @Req() req: any) {
    return this.service.createCMOrder(dto, req.user?.id);
  }

  @Put('orders/:id')
  @ApiOperation({ summary: 'Update change order' })
  updateOrder(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateCMChangeOrderDto,
  ) {
    return this.service.updateCMOrder(id, dto);
  }

  @Delete('orders/:id')
  @ApiOperation({ summary: 'Delete change order' })
  deleteOrder(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteCMOrder(id);
  }

  @Post('orders/:id/issue')
  @ApiOperation({ summary: 'Issue change order' })
  issueOrder(@Param('id', ParseIntPipe) id: number) {
    return this.service.issueCMOrder(id);
  }

  @Post('orders/:id/accept')
  @ApiOperation({ summary: 'Accept change order' })
  acceptOrder(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.acceptCMOrder(id, body.comments);
  }

  @Post('orders/:id/reject')
  @ApiOperation({ summary: 'Reject change order' })
  rejectOrder(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: ActionWithReasonDto,
  ) {
    return this.service.rejectCMOrder(id, body.reason ?? '');
  }

  @Post('orders/:id/start')
  @ApiOperation({ summary: 'Start order execution' })
  startExecution(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { startDate: string },
  ) {
    return this.service.startExecution(id, body.startDate);
  }

  @Put('orders/:id/progress')
  @ApiOperation({ summary: 'Update execution progress' })
  updateProgress(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { progress: number },
  ) {
    return this.service.updateExecutionProgress(id, body.progress);
  }

  @Post('orders/:id/complete')
  @ApiOperation({ summary: 'Complete order execution' })
  completeExecution(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { completionDate: string },
  ) {
    return this.service.completeExecution(id, body.completionDate);
  }

  @Post('orders/:id/close')
  @ApiOperation({ summary: 'Close change order' })
  closeOrder(@Param('id', ParseIntPipe) id: number) {
    return this.service.closeCMOrder(id);
  }

  @Get('orders/:id/export')
  @ApiOperation({ summary: 'Export change order' })
  exportOrder(@Param('id', ParseIntPipe) id: number) {
    return this.service.exportCMOrder(id);
  }

  @Get('orders/:id/logs')
  @ApiOperation({ summary: 'Get change order logs' })
  getOrderLogs(@Param('id', ParseIntPipe) id: number) {
    return this.service.getOrderLogs(id);
  }

  // --- Analytics ---
  @Get('analytics')
  @ApiOperation({ summary: 'Get change management analytics' })
  @ApiQuery({ name: 'projectId', required: false })
  getAnalytics(@Query('projectId') projectId?: string) {
    return this.service.getAnalytics(projectId ? +projectId : undefined);
  }

  @Get('projects/:projectId/impact')
  @ApiOperation({ summary: 'Get project change impact' })
  getProjectImpact(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getProjectImpact(projectId);
  }

  @Get('projects/:projectId/forecast')
  @ApiOperation({ summary: 'Get change forecast for project' })
  getForecast(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.getForecast(projectId);
  }

  @Get('projects/:projectId/register/export')
  @ApiOperation({ summary: 'Export change register' })
  exportRegister(@Param('projectId', ParseIntPipe) projectId: number) {
    return this.service.exportRegister(projectId);
  }

  @Post('attachments/upload')
  @ApiOperation({ summary: 'Upload change management attachment' })
  uploadAttachment(
    @Body()
    body: {
      changeRequestId?: number;
      changeOrderId?: number;
      category?: string;
    },
  ) {
    return {
      message: 'Attachment upload endpoint — integrate file storage provider',
      ...body,
    };
  }
}

// ==================== /change-orders/* Controller ====================
@ApiTags('Change Orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'change-orders', version: '1' })
export class ChangeOrderController {
  constructor(private readonly service: ChangeManagementService) {}

  @Get()
  @ApiOperation({ summary: 'List change orders' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'type', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'priority', required: false })
  @ApiQuery({ name: 'search', required: false })
  findAll(
    @Query('projectId') projectId?: string,
    @Query('type') type?: string,
    @Query('status') status?: string,
    @Query('priority') priority?: string,
    @Query('search') search?: string,
  ) {
    return this.service.getStandaloneOrders(
      projectId ? +projectId : undefined,
      type,
      status,
      priority,
      search,
    );
  }

  @Get('templates')
  @ApiOperation({ summary: 'List change order templates' })
  @ApiQuery({ name: 'type', required: false })
  getTemplates(@Query('type') type?: string) {
    return this.service.getTemplates(type);
  }

  @Get('templates/:id')
  @ApiOperation({ summary: 'Get change order template' })
  getTemplate(@Param('id', ParseIntPipe) id: number) {
    return this.service.getTemplate(id);
  }

  @Post('templates/:id/create')
  @ApiOperation({ summary: 'Create change order from template' })
  createFromTemplate(@Param('id', ParseIntPipe) id: number, @Body() body: any) {
    return this.service.createFromTemplate(id, body);
  }

  @Get('summary')
  @ApiOperation({ summary: 'Get change order summary' })
  @ApiQuery({ name: 'projectId', required: true })
  getSummary(@Query('projectId') projectId: string) {
    return this.service.getOrderSummary(+projectId);
  }

  @Get('logs')
  @ApiOperation({ summary: 'Get project change order logs' })
  @ApiQuery({ name: 'projectId', required: true })
  getProjectLogs(@Query('projectId') projectId: string) {
    return this.service.getProjectOrderLogs(+projectId);
  }

  @Get('analytics')
  @ApiOperation({ summary: 'Get change order analytics' })
  @ApiQuery({ name: 'projectId', required: true })
  getAnalytics(@Query('projectId') projectId: string) {
    return this.service.getOrderAnalytics(+projectId);
  }

  @Get('analytics/cost')
  @ApiOperation({ summary: 'Get cost analysis' })
  @ApiQuery({ name: 'projectId', required: false })
  getCostAnalysis(@Query('projectId') projectId?: string) {
    return this.service.getCostAnalysis(projectId ? +projectId : undefined);
  }

  @Get('analytics/schedule')
  @ApiOperation({ summary: 'Get schedule analysis' })
  @ApiQuery({ name: 'projectId', required: false })
  getScheduleAnalysis(@Query('projectId') projectId?: string) {
    return this.service.getScheduleAnalysis(projectId ? +projectId : undefined);
  }

  @Get('reports/register')
  @ApiOperation({ summary: 'Export change order register' })
  @ApiQuery({ name: 'projectId', required: true })
  exportRegister(@Query('projectId') projectId: string) {
    return this.service.exportOrderRegister(+projectId);
  }

  @Get('reports/log')
  @ApiOperation({ summary: 'Export change order log report' })
  @ApiQuery({ name: 'projectId', required: true })
  @ApiQuery({ name: 'format', required: false })
  exportLogReport(@Query('projectId') projectId: string) {
    return this.service.getProjectOrderLogs(+projectId);
  }

  @Get('reports/cost-summary')
  @ApiOperation({ summary: 'Export cost summary report' })
  @ApiQuery({ name: 'projectId', required: false })
  @ApiQuery({ name: 'format', required: false })
  exportCostSummaryReport(@Query('projectId') projectId?: string) {
    return this.service.getCostAnalysis(projectId ? +projectId : undefined);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get change order by ID' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.getStandaloneOrderById(id);
  }

  @Post()
  @ApiOperation({ summary: 'Create change order' })
  create(@Body() dto: CreateChangeOrderDto, @Req() req: any) {
    return this.service.createStandaloneOrder(dto, req.user?.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update change order' })
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateChangeOrderDto,
  ) {
    return this.service.updateStandaloneOrder(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete change order' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.deleteStandaloneOrder(id);
  }

  @Post(':id/submit')
  @ApiOperation({ summary: 'Submit change order' })
  submit(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { notes?: string },
  ) {
    return this.service.submitOrder(id, body.notes);
  }

  @Post(':id/review')
  @ApiOperation({ summary: 'Review change order' })
  review(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { comments: string },
  ) {
    return this.service.reviewOrder(id, body.comments);
  }

  @Post(':id/approve')
  @ApiOperation({ summary: 'Approve change order' })
  approve(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ApproveChangeOrderDto,
  ) {
    return this.service.approveOrder(id, dto);
  }

  @Post(':id/reject')
  @ApiOperation({ summary: 'Reject change order' })
  reject(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { reason: string },
  ) {
    return this.service.rejectOrder(id, body.reason);
  }

  @Post(':id/implement')
  @ApiOperation({ summary: 'Start implementation' })
  implement(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ImplementChangeOrderDto,
  ) {
    return this.service.implementOrder(id, dto);
  }

  @Post(':id/complete')
  @ApiOperation({ summary: 'Complete change order' })
  complete(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { completionNotes?: string },
  ) {
    return this.service.completeOrder(id, body.completionNotes);
  }

  @Post(':id/cancel')
  @ApiOperation({ summary: 'Cancel change order' })
  cancel(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { reason: string },
  ) {
    return this.service.cancelOrder(id, body.reason);
  }

  @Post(':id/revisions')
  @ApiOperation({ summary: 'Create revision' })
  createRevision(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CreateRevisionDto,
  ) {
    return this.service.createRevision(id, dto);
  }

  @Post(':id/approvals/:approvalId/delegate')
  @ApiOperation({ summary: 'Delegate approval' })
  delegateApproval(
    @Param('id', ParseIntPipe) id: number,
    @Param('approvalId') approvalId: string,
    @Body() dto: DelegateApprovalDto,
  ) {
    return this.service.delegateApproval(id, approvalId, dto.delegateToId);
  }

  @Put(':id/implementation/progress')
  @ApiOperation({ summary: 'Update implementation progress' })
  updateProgress(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateProgressDto,
  ) {
    return this.service.updateImplProgress(
      id,
      dto.progress,
      dto.description ?? '',
    );
  }

  @Get(':id/logs')
  @ApiOperation({ summary: 'Get change order logs' })
  getLogs(@Param('id', ParseIntPipe) id: number) {
    return this.service.getStandaloneOrderLogs(id);
  }

  @Get(':id/export')
  @ApiOperation({ summary: 'Export change order package' })
  exportPackage(@Param('id', ParseIntPipe) id: number) {
    return this.service.exportOrderPackage(id);
  }

  @Post(':id/attachments')
  @ApiOperation({ summary: 'Upload change order attachment' })
  uploadAttachment(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { category?: string; description?: string },
  ) {
    return {
      message: 'Attachment upload endpoint — integrate file storage provider',
      changeOrderId: id,
      ...body,
    };
  }

  @Delete(':id/attachments/:attachmentId')
  @ApiOperation({ summary: 'Delete change order attachment' })
  deleteAttachment(
    @Param('id', ParseIntPipe) id: number,
    @Param('attachmentId') attachmentId: string,
  ) {
    return { message: 'Attachment deleted', changeOrderId: id, attachmentId };
  }

  @Put('summary/:changeOrderNumber')
  @ApiOperation({ summary: 'Update change order summary' })
  updateSummary(@Param('changeOrderNumber') num: string) {
    return { message: 'Summary updated' };
  }
}
