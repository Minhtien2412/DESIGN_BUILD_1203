import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    ChangeManagementController,
    ChangeOrderController,
} from './change-management.controller';
import { ChangeManagementService } from './change-management.service';

@Module({
  controllers: [ChangeManagementController, ChangeOrderController],
  providers: [ChangeManagementService, PrismaService],
  exports: [ChangeManagementService],
})
export class ChangeManagementModule {}
