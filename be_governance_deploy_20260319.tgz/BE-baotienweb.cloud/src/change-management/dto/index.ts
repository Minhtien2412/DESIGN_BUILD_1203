import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsDateString,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

// ==================== Change Request DTOs ====================

export class CreateChangeRequestDto {
  @ApiProperty() @IsString() title: string;
  @ApiProperty() @IsString() description: string;
  @ApiProperty() @IsNumber() projectId: number;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() origin?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() justification?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() currentSituation?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() proposedSolution?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleImpact?: number;
  @ApiPropertyOptional() @IsOptional() impact?: any;
  @ApiPropertyOptional() @IsOptional() @IsArray() affectedAreas?: string[];
  @ApiPropertyOptional() @IsOptional() @IsArray() attachments?: string[];
}

export class UpdateChangeRequestDto {
  @ApiPropertyOptional() @IsOptional() @IsString() title?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() category?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() justification?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() currentSituation?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() proposedSolution?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleImpact?: number;
  @ApiPropertyOptional() @IsOptional() impact?: any;
  @ApiPropertyOptional() @IsOptional() @IsArray() affectedAreas?: string[];
}

export class AssessImpactDto {
  @ApiProperty() @IsString() impactAssessment: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() riskAssessment?: string;
}

export class ActionWithReasonDto {
  @ApiPropertyOptional() @IsOptional() @IsString() reason?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() comments?: string;
}

// ==================== Change Order DTOs (change-management/orders) ====================

export class CreateCMChangeOrderDto {
  @ApiProperty() @IsString() title: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() changeRequestId?: number;
  @ApiProperty() @IsNumber() projectId: number;
  @ApiPropertyOptional() @IsOptional() @IsString() orderNumber?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleImpact?: number;
  @ApiPropertyOptional() @IsOptional() costBreakdown?: any;
  @ApiPropertyOptional() @IsOptional() @IsString() scopeOfWork?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() specifications?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleExtension?: number;
}

export class UpdateCMChangeOrderDto {
  @ApiPropertyOptional() @IsOptional() @IsString() title?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleImpact?: number;
  @ApiPropertyOptional() @IsOptional() costBreakdown?: any;
  @ApiPropertyOptional() @IsOptional() @IsString() scopeOfWork?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() specifications?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleExtension?: number;
}

// ==================== Change Order DTOs (standalone /change-orders) ====================

export class CreateChangeOrderDto {
  @ApiProperty() @IsString() title: string;
  @ApiProperty() @IsString() description: string;
  @ApiProperty() @IsNumber() projectId: number;
  @ApiPropertyOptional() @IsOptional() @IsString() orderNumber?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() costBreakdown?: any;
  @ApiPropertyOptional() @IsOptional() @IsString() scopeOfWork?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() specifications?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleExtension?: number;
  @ApiPropertyOptional() @IsOptional() @IsDateString() requiredDate?: string;
}

export class UpdateChangeOrderDto {
  @ApiPropertyOptional() @IsOptional() @IsString() title?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() status?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() type?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() priority?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() costImpact?: number;
  @ApiPropertyOptional() @IsOptional() costBreakdown?: any;
  @ApiPropertyOptional() @IsOptional() @IsString() scopeOfWork?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() specifications?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() scheduleExtension?: number;
}

export class ApproveChangeOrderDto {
  @ApiPropertyOptional() @IsOptional() @IsString() comments?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() conditions?: string;
}

export class ImplementChangeOrderDto {
  @ApiPropertyOptional() @IsOptional() @IsString() implementationPlan?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() startDate?: string;
}

export class CreateRevisionDto {
  @ApiProperty() @IsString() revisionNumber: string;
  @ApiProperty() @IsString() changes: string;
  @ApiPropertyOptional() @IsOptional() @IsString() notes?: string;
}

export class DelegateApprovalDto {
  @ApiProperty() @IsString() delegateToId: string;
  @ApiPropertyOptional() @IsOptional() @IsString() reason?: string;
}

export class UpdateProgressDto {
  @ApiProperty() @IsNumber() progress: number;
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
}
