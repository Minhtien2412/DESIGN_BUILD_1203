import {
    BadRequestException,
    ForbiddenException,
    Injectable,
    NotFoundException,
    UnprocessableEntityException,
} from '@nestjs/common';
import { MarketplaceGovernanceService } from '../marketplace-governance/governance.service';
import { GovernancePersistenceService } from '../marketplace-governance/services/governance-persistence.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateMessageDto } from './dto/create-message.dto';
import { MessageQueryDto } from './dto/message-query.dto';

@Injectable()
export class MessagesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly marketplaceGovernanceService: MarketplaceGovernanceService,
    private readonly governancePersistenceService: GovernancePersistenceService,
  ) {}

  async getConversations(userId: number) {
    // Get all chat rooms where user is a member
    const memberships = await this.prisma.chatRoomMember.findMany({
      where: { userId },
      include: {
        room: {
          include: {
            members: {
              where: { userId: { not: userId } },
              include: {
                user: {
                  select: { id: true, name: true, email: true },
                },
              },
              take: 1,
            },
            messages: {
              orderBy: { createdAt: 'desc' },
              take: 1,
              select: {
                id: true,
                content: true,
                createdAt: true,
                senderId: true,
              },
            },
          },
        },
      },
      orderBy: { joinedAt: 'desc' },
    });

    // Transform to conversation format
    const conversations = await Promise.all(
      memberships.map(async (membership) => {
        const room = membership.room;
        const otherMember = room.members[0];
        const lastMessage = room.messages[0] || null;

        // Count unread messages
        const unreadCount = await this.prisma.chatMessage.count({
          where: {
            roomId: room.id,
            senderId: { not: userId },
            readStatus: {
              none: { userId },
            },
          },
        });

        return {
          id: room.id,
          otherUser: otherMember?.user || null,
          lastMessage: lastMessage
            ? {
                id: lastMessage.id,
                content: lastMessage.content,
                createdAt: lastMessage.createdAt,
                senderId: lastMessage.senderId,
              }
            : null,
          unreadCount,
          createdAt: room.createdAt,
          updatedAt: room.updatedAt,
        };
      }),
    );

    return conversations;
  }

  async getMessages(
    conversationId: number,
    userId: number,
    query: MessageQueryDto,
  ) {
    // Verify user is member of this room
    const membership = await this.prisma.chatRoomMember.findFirst({
      where: {
        roomId: conversationId,
        userId,
      },
    });

    if (!membership) {
      throw new NotFoundException(`Conversation not found or access denied`);
    }

    const { page = 1, limit = 50 } = query;
    const skip = (page - 1) * limit;

    const [messages, total] = await Promise.all([
      this.prisma.chatMessage.findMany({
        where: { roomId: conversationId },
        include: {
          sender: {
            select: { id: true, name: true, email: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.chatMessage.count({ where: { roomId: conversationId } }),
    ]);

    return {
      data: messages.reverse(), // Return oldest first
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async sendMessage(senderId: number, dto: CreateMessageDto) {
    const { receiverId, content, type = 'TEXT' } = dto;

    if (senderId === receiverId) {
      throw new BadRequestException('Cannot send message to yourself');
    }

    // Verify receiver exists
    const receiver = await this.prisma.user.findUnique({
      where: { id: receiverId },
    });

    if (!receiver) {
      throw new NotFoundException(`User with ID ${receiverId} not found`);
    }

    // Find existing chat room between these users
    const existingMemberships = await this.prisma.chatRoomMember.findMany({
      where: { userId: { in: [senderId, receiverId] } },
      include: { room: { include: { members: true } } },
    });

    let room = existingMemberships.find(
      (m) =>
        m.room.members.length === 2 &&
        m.room.members.some((mem) => mem.userId === senderId) &&
        m.room.members.some((mem) => mem.userId === receiverId),
    )?.room;

    // Create room if doesn't exist
    if (!room) {
      // Use existing first project or fall back to any project
      const anyProject = await this.prisma.project.findFirst({
        orderBy: { id: 'asc' },
      });

      if (!anyProject) {
        throw new BadRequestException(
          'No project found for creating chat room',
        );
      }

      room = await this.prisma.chatRoom.create({
        data: {
          name: `Chat_${Math.min(senderId, receiverId)}_${Math.max(senderId, receiverId)}`,
          projectId: anyProject.id,
          members: {
            create: [{ userId: senderId }, { userId: receiverId }],
          },
        },
        include: { members: true },
      });
    }

    const recentMessages = await this.prisma.chatMessage.findMany({
      where: {
        roomId: room.id,
        senderId,
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { content: true },
    });

    const moderationResponse =
      await this.marketplaceGovernanceService.moderateMessage({
        senderId,
        message: content,
        recentMessages: recentMessages.map((message) => message.content),
      });

    const moderationLog =
      await this.governancePersistenceService.createMessageModerationLog({
        conversationId: `messages-room-${room.id}`,
        senderId,
        message: content,
        moderation: moderationResponse.moderation,
      });

    if (moderationResponse.reviewQueue.length > 0) {
      await this.governancePersistenceService.createModerationReviewQueueItems({
        moderationLogId: moderationLog.id,
        reviewQueue: moderationResponse.reviewQueue,
      });
    }

    if (!moderationResponse.allowSend) {
      throw new UnprocessableEntityException({
        message: 'Message cannot be sent under the current marketplace policy',
        decision: moderationResponse.moderation.decision,
        moderation: moderationResponse.moderation,
        reviewQueue: moderationResponse.reviewQueue,
        moderationLogId: moderationLog.id,
      });
    }

    // Create message
    const message = await this.prisma.chatMessage.create({
      data: {
        roomId: room.id,
        senderId,
        content,
        attachments: [],
      },
      include: {
        sender: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    // Update room's updatedAt
    await this.prisma.chatRoom.update({
      where: { id: room.id },
      data: { updatedAt: new Date() },
    });

    return message;
  }

  async markAsRead(id: number, userId: number) {
    const message = await this.prisma.chatMessage.findFirst({
      where: { id },
      include: { room: { include: { members: true } } },
    });

    if (!message) {
      throw new NotFoundException(`Message not found`);
    }

    // Verify user is member of the room
    const isMember = message.room.members.some((m) => m.userId === userId);
    if (!isMember) {
      throw new ForbiddenException('Access denied');
    }

    // Don't mark own messages as read
    if (message.senderId === userId) {
      return message;
    }

    // Create or update read status
    await this.prisma.messageReadStatus.upsert({
      where: {
        messageId_userId: {
          messageId: id,
          userId,
        },
      },
      update: { readAt: new Date() },
      create: {
        messageId: id,
        userId,
        readAt: new Date(),
      },
    });

    return message;
  }

  async markAllAsRead(conversationId: number, userId: number) {
    // Verify user is member
    const membership = await this.prisma.chatRoomMember.findFirst({
      where: {
        roomId: conversationId,
        userId,
      },
    });

    if (!membership) {
      throw new NotFoundException(`Conversation not found or access denied`);
    }

    // Get all unread messages from others
    const messages = await this.prisma.chatMessage.findMany({
      where: {
        roomId: conversationId,
        senderId: { not: userId },
        readStatus: {
          none: { userId },
        },
      },
      select: { id: true },
    });

    // Create read status for each
    await this.prisma.messageReadStatus.createMany({
      data: messages.map((m) => ({
        messageId: m.id,
        userId,
        readAt: new Date(),
      })),
      skipDuplicates: true,
    });

    return { updatedCount: messages.length };
  }

  async getUnreadCount(userId: number) {
    // Get all rooms user is in
    const memberships = await this.prisma.chatRoomMember.findMany({
      where: { userId },
      select: { roomId: true },
    });

    const roomIds = memberships.map((m) => m.roomId);

    // Count unread messages from others
    const count = await this.prisma.chatMessage.count({
      where: {
        roomId: { in: roomIds },
        senderId: { not: userId },
        readStatus: {
          none: { userId },
        },
      },
    });

    return { count };
  }
}
