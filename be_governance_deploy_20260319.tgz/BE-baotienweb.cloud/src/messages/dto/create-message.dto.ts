import { IsNotEmpty, IsInt, IsString, IsEnum, IsOptional } from 'class-validator';

export class CreateMessageDto {
  @IsInt()
  @IsNotEmpty()
  receiverId: number;

  @IsString()
  @IsNotEmpty()
  content: string;

  @IsOptional()
  @IsEnum(['TEXT', 'IMAGE', 'VIDEO', 'FILE', 'SYSTEM'])
  type?: string;
}
