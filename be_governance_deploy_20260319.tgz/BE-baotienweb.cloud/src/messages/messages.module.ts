import { Module } from '@nestjs/common';
import { MarketplaceGovernanceModule } from '../marketplace-governance/marketplace-governance.module';
import { PrismaModule } from '../prisma/prisma.module';
import { MessagesController } from './messages.controller';
import { MessagesService } from './messages.service';

@Module({
  imports: [PrismaModule, MarketplaceGovernanceModule],
  controllers: [MessagesController],
  providers: [MessagesService],
  exports: [MessagesService],
})
export class MessagesModule {}
