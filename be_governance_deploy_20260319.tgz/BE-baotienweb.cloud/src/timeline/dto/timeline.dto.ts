import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsArray,
    IsBoolean,
    IsDateString,
    IsInt,
    IsNumber,
    IsOptional,
    IsString,
    Max,
    Min,
    ValidateNested,
} from 'class-validator';

// ==================== PHASE TASK DTOs ====================

export class PhaseTaskDto {
  @ApiProperty({ example: 'Đổ bê tông móng' })
  @IsString()
  name: string;

  @ApiPropertyOptional({ example: 'Đổ bê tông móng M200, dày 30cm' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ example: false })
  @IsBoolean()
  @IsOptional()
  isCompleted?: boolean;

  @ApiPropertyOptional({ example: 1 })
  @IsInt()
  @IsOptional()
  order?: number;

  @ApiPropertyOptional({ example: '2024-12-15' })
  @IsDateString()
  @IsOptional()
  dueDate?: string;

  @ApiPropertyOptional({ example: 'Nguyễn Văn A' })
  @IsString()
  @IsOptional()
  assignee?: string;

  @ApiPropertyOptional({ example: 'Cần kiểm tra độ sụt bê tông' })
  @IsString()
  @IsOptional()
  notes?: string;
}

// ==================== TIMELINE PHASE DTOs ====================

export class CreatePhaseDto {
  @ApiProperty({ example: 'Giai đoạn thô' })
  @IsString()
  name: string;

  @ApiPropertyOptional({ example: 'Xây thô, đổ bê tông, xây tường' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: 1 })
  @IsInt()
  projectId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  order: number;

  @ApiProperty({ example: '2024-12-01' })
  @IsDateString()
  startDate: string;

  @ApiProperty({ example: '2024-12-31' })
  @IsDateString()
  endDate: string;

  @ApiPropertyOptional({ example: '#3B82F6' })
  @IsString()
  @IsOptional()
  color?: string;

  @ApiPropertyOptional({ example: '🏗️' })
  @IsString()
  @IsOptional()
  icon?: string;

  @ApiPropertyOptional({ example: 'Giai đoạn quan trọng nhất' })
  @IsString()
  @IsOptional()
  notes?: string;

  @ApiPropertyOptional({ type: [PhaseTaskDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PhaseTaskDto)
  @IsOptional()
  tasks?: PhaseTaskDto[];
}

export class UpdatePhaseDto {
  @ApiPropertyOptional({ example: 'Giai đoạn thô - Updated' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ example: 'Xây thô, đổ bê tông, xây tường - Updated' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ example: 'IN_PROGRESS' })
  @IsString()
  @IsOptional()
  status?: string;

  @ApiPropertyOptional({ example: 1 })
  @IsInt()
  @IsOptional()
  order?: number;

  @ApiPropertyOptional({ example: '2024-12-01' })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiPropertyOptional({ example: '2024-12-31' })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiPropertyOptional({ example: '2024-12-01' })
  @IsDateString()
  @IsOptional()
  actualStartDate?: string;

  @ApiPropertyOptional({ example: '2024-12-31' })
  @IsDateString()
  @IsOptional()
  actualEndDate?: string;

  @ApiPropertyOptional({ example: 45.5 })
  @IsNumber()
  @Min(0)
  @Max(100)
  @IsOptional()
  progress?: number;

  @ApiPropertyOptional({ example: '#EF4444' })
  @IsString()
  @IsOptional()
  color?: string;

  @ApiPropertyOptional({ example: '⚡' })
  @IsString()
  @IsOptional()
  icon?: string;

  @ApiPropertyOptional({ example: 'Cập nhật tiến độ mới' })
  @IsString()
  @IsOptional()
  notes?: string;
}

// ==================== REORDER DTOs ====================

export class ReorderPhaseDto {
  @ApiProperty({ example: 1 })
  @IsInt()
  phaseId: number;

  @ApiProperty({ example: 3 })
  @IsInt()
  newOrder: number;
}

export class ReorderPhasesDto {
  @ApiProperty({ type: [ReorderPhaseDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ReorderPhaseDto)
  phases: ReorderPhaseDto[];
}

// ==================== PROGRESS UPDATE DTOs ====================

export class UpdateProgressDto {
  @ApiProperty({ example: 75 })
  @IsNumber()
  @Min(0)
  @Max(100)
  newProgress: number;

  @ApiPropertyOptional({ example: 'Đã hoàn thành 75% công việc xây thô' })
  @IsString()
  @IsOptional()
  notes?: string;

  @ApiPropertyOptional({
    example: [
      'https://example.com/image1.jpg',
      'https://example.com/image2.jpg',
    ],
  })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  imageUrls?: string[];

  @ApiPropertyOptional({
    example: ['https://example.com/video1.mp4'],
  })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  videoUrls?: string[];

  @ApiPropertyOptional({ example: 'Nguyễn Văn A' })
  @IsString()
  @IsOptional()
  updatedBy?: string;

  @ApiPropertyOptional({
    example: true,
    description: 'Send notification to client',
  })
  @IsBoolean()
  @IsOptional()
  sendNotification?: boolean;
}

// ==================== TASK UPDATE DTOs ====================

export class TimelineUpdateTaskDto {
  @ApiPropertyOptional({ example: 'Đổ bê tông móng - Updated' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ example: 'Đổ bê tông móng M200, dày 30cm - Updated' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ example: true })
  @IsBoolean()
  @IsOptional()
  isCompleted?: boolean;

  @ApiPropertyOptional({ example: 2 })
  @IsInt()
  @IsOptional()
  order?: number;

  @ApiPropertyOptional({ example: '2024-12-20' })
  @IsDateString()
  @IsOptional()
  dueDate?: string;

  @ApiPropertyOptional({ example: 'Nguyễn Văn B' })
  @IsString()
  @IsOptional()
  assignee?: string;

  @ApiPropertyOptional({ example: 'Đã kiểm tra độ sụt bê tông' })
  @IsString()
  @IsOptional()
  notes?: string;
}

// ==================== NOTIFICATION DTOs ====================

export class MarkNotificationReadDto {
  @ApiProperty({ example: [1, 2, 3] })
  @IsArray()
  @IsInt({ each: true })
  notificationIds: number[];
}
