import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreatePhaseDto,
    MarkNotificationReadDto,
    PhaseTaskDto,
    ReorderPhasesDto,
    TimelineUpdateTaskDto,
    UpdatePhaseDto,
    UpdateProgressDto,
} from './dto';
import { TimelineService } from './timeline.service';

@ApiTags('Timeline Builder (Gantt Chart)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'timeline', version: '1' })
export class TimelineController {
  constructor(private readonly timelineService: TimelineService) {}

  // ==================== PROJECT TIMELINE (Gantt Chart) ====================

  @Get('projects/:projectId')
  @ApiOperation({ summary: 'Lấy timeline Gantt Chart của project' })
  async getProjectTimeline(
    @Param('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.timelineService.getProjectTimeline(projectId);
  }

  @Get('projects/:projectId/check-delayed')
  @ApiOperation({ summary: 'Kiểm tra các phase bị trễ hạn' })
  async checkDelayedPhases(
    @Param('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.timelineService.checkDelayedPhases(projectId);
  }

  // ==================== PHASES ====================

  @Get('phases')
  @ApiOperation({ summary: 'Lấy danh sách tất cả phases (có filter)' })
  async getAllPhases(
    @Query('projectId') projectId?: string,
    @Query('status') status?: string,
  ) {
    return this.timelineService.getAllPhases(
      projectId ? parseInt(projectId) : undefined,
      status,
    );
  }

  @Post('phases')
  @ApiOperation({ summary: 'Tạo phase mới cho timeline' })
  // @ApiBearerAuth()
  async createPhase(@Body() dto: CreatePhaseDto) {
    return this.timelineService.createPhase(dto);
  }

  @Get('phases/:id')
  @ApiOperation({ summary: 'Lấy chi tiết phase' })
  async getPhaseById(@Param('id', ParseIntPipe) id: number) {
    return this.timelineService.getPhaseById(id);
  }

  @Patch('phases/:id')
  @ApiOperation({
    summary: 'Cập nhật phase (name, status, dates, color, icon)',
  })
  // @ApiBearerAuth()
  async updatePhase(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdatePhaseDto,
  ) {
    return this.timelineService.updatePhase(id, dto);
  }

  @Delete('phases/:id')
  @ApiOperation({ summary: 'Xóa phase' })
  // @ApiBearerAuth()
  async deletePhase(@Param('id', ParseIntPipe) id: number) {
    return this.timelineService.deletePhase(id);
  }

  // ==================== DRAG & DROP REORDER ====================

  @Patch('phases/reorder')
  @ApiOperation({ summary: 'Drag & Drop: Sắp xếp lại thứ tự phases' })
  // @ApiBearerAuth()
  async reorderPhases(
    @Body() dto: ReorderPhasesDto,
    @Query('projectId', ParseIntPipe) projectId: number,
  ) {
    return this.timelineService.reorderPhases(projectId, dto);
  }

  // ==================== PROGRESS UPDATE ====================

  @Patch('phases/:id/progress')
  @ApiOperation({
    summary: 'Cập nhật tiến độ phase (realtime progress)',
    description: 'Auto-send notification to client when progress changes',
  })
  // @ApiBearerAuth()
  async updateProgress(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateProgressDto,
  ) {
    return this.timelineService.updateProgress(id, dto);
  }

  // ==================== PHASE TASKS ====================

  @Post('phases/:id/tasks')
  @ApiOperation({ summary: 'Tạo task cho phase' })
  // @ApiBearerAuth()
  async createPhaseTask(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: PhaseTaskDto,
  ) {
    return this.timelineService.createPhaseTask(id, dto);
  }

  @Patch('tasks/:id')
  @ApiOperation({ summary: 'Cập nhật task (auto-recalculate phase progress)' })
  // @ApiBearerAuth()
  async updatePhaseTask(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: TimelineUpdateTaskDto,
  ) {
    return this.timelineService.updatePhaseTask(id, dto);
  }

  @Delete('tasks/:id')
  @ApiOperation({ summary: 'Xóa task' })
  // @ApiBearerAuth()
  async deletePhaseTask(@Param('id', ParseIntPipe) id: number) {
    return this.timelineService.deletePhaseTask(id);
  }

  // ==================== NOTIFICATIONS ====================

  @Get('projects/:projectId/notifications')
  @ApiOperation({ summary: 'Lấy notifications của project' })
  async getProjectNotifications(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Query('unreadOnly') unreadOnly?: string,
  ) {
    return this.timelineService.getProjectNotifications(
      projectId,
      unreadOnly === 'true',
    );
  }

  @Patch('notifications/mark-read')
  @ApiOperation({ summary: 'Đánh dấu notifications đã đọc' })
  // @ApiBearerAuth()
  async markNotificationsAsRead(@Body() dto: MarkNotificationReadDto) {
    return this.timelineService.markNotificationsAsRead(dto.notificationIds);
  }
}
