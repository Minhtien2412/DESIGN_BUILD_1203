import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsEnum,
    IsNumber,
    IsOptional,
    IsString,
    Min
} from 'class-validator';

export enum BookingStatusDto {
  SEARCHING = 'SEARCHING',
  PENDING = 'PENDING',
  ACCEPTED = 'ACCEPTED',
  ARRIVING = 'ARRIVING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

export class CreateWorkerBookingDto {
  @ApiProperty({ description: 'Worker ID to book' })
  @Type(() => Number)
  @IsNumber()
  workerId: number;

  @ApiProperty({ description: 'Service category (e.g., tho_dien, tho_nuoc)' })
  @IsString()
  serviceCategory: string;

  @ApiProperty({ description: 'Customer latitude' })
  @Type(() => Number)
  @IsNumber()
  customerLatitude: number;

  @ApiProperty({ description: 'Customer longitude' })
  @Type(() => Number)
  @IsNumber()
  customerLongitude: number;

  @ApiProperty({ description: 'Customer address' })
  @IsString()
  customerAddress: string;

  @ApiProperty({ description: 'Scheduled date (ISO string)' })
  @IsString()
  scheduledDate: string;

  @ApiPropertyOptional({ description: 'Scheduled time (e.g., "08:00")' })
  @IsOptional()
  @IsString()
  scheduledTime?: string;

  @ApiProperty({ description: 'Estimated price (VND)' })
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  estimatedPrice: number;

  @ApiPropertyOptional({ description: 'Notes for the worker' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    description: 'Payment method',
    default: 'cash',
    enum: ['cash', 'transfer', 'momo', 'zalopay'],
  })
  @IsOptional()
  @IsString()
  paymentMethod?: string;

  @ApiPropertyOptional({ description: 'Distance from worker in km' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  distanceKm?: number;
}

export class UpdateBookingStatusDto {
  @ApiProperty({ enum: BookingStatusDto, description: 'New booking status' })
  @IsEnum(BookingStatusDto)
  status: BookingStatusDto;

  @ApiPropertyOptional({
    description: 'Cancel reason (required if cancelling)',
  })
  @IsOptional()
  @IsString()
  cancelReason?: string;

  @ApiPropertyOptional({ description: 'Final price (when completing)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  finalPrice?: number;
}

export class BookingQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  page?: number;

  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  limit?: number;

  @ApiPropertyOptional({
    enum: BookingStatusDto,
    description: 'Filter by status',
  })
  @IsOptional()
  @IsEnum(BookingStatusDto)
  status?: BookingStatusDto;
}
