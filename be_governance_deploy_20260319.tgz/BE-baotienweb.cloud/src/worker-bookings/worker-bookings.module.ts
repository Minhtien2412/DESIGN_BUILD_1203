import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { WorkerBookingsController } from './worker-bookings.controller';
import { WorkerBookingsService } from './worker-bookings.service';

@Module({
  imports: [PrismaModule],
  controllers: [WorkerBookingsController],
  providers: [WorkerBookingsService],
  exports: [WorkerBookingsService],
})
export class WorkerBookingsModule {}
