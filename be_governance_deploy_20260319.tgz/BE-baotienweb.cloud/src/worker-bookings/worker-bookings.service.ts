import {
    BadRequestException,
    Injectable,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { WorkerBookingStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import {
    BookingQueryDto,
    BookingStatusDto,
    CreateWorkerBookingDto,
    UpdateBookingStatusDto,
} from './dto/worker-booking.dto';

@Injectable()
export class WorkerBookingsService {
  private readonly logger = new Logger(WorkerBookingsService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Create a new worker booking (Grab-style request)
   */
  async createBooking(userId: number, dto: CreateWorkerBookingDto) {
    try {
      // Verify worker exists and is available
      const worker = await this.prisma.worker.findUnique({
        where: { id: dto.workerId },
      });

      if (!worker) {
        throw new NotFoundException(
          `Không tìm thấy thợ với ID ${dto.workerId}`,
        );
      }

      if (worker.availability !== 'available') {
        throw new BadRequestException('Thợ hiện không có sẵn');
      }

      // Create booking
      const booking = await this.prisma.workerBooking.create({
        data: {
          workerId: dto.workerId,
          userId,
          serviceCategory: dto.serviceCategory,
          customerLatitude: dto.customerLatitude,
          customerLongitude: dto.customerLongitude,
          customerAddress: dto.customerAddress,
          scheduledDate: new Date(dto.scheduledDate),
          scheduledTime: dto.scheduledTime || null,
          estimatedPrice: dto.estimatedPrice,
          status: WorkerBookingStatus.PENDING,
          notes: dto.notes || null,
          paymentMethod: dto.paymentMethod || 'cash',
          distanceKm: dto.distanceKm || null,
        },
        include: {
          worker: {
            select: {
              id: true,
              name: true,
              phone: true,
              avatar: true,
              workerType: true,
              rating: true,
              totalReviews: true,
              experienceYears: true,
              dailyRate: true,
              latitude: true,
              longitude: true,
            },
          },
        },
      });

      return {
        success: true,
        message: 'Đã gửi yêu cầu đặt thợ thành công',
        data: this.formatBooking(booking),
      };
    } catch (error) {
      if (
        error instanceof NotFoundException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }
      this.logger.error('Error creating worker booking:', error);
      throw new BadRequestException('Không thể tạo booking: ' + error.message);
    }
  }

  /**
   * Get current user's bookings
   */
  async getMyBookings(userId: number, query: BookingQueryDto) {
    const { page = 1, limit = 20, status } = query;
    const skip = (page - 1) * limit;

    try {
      const where: any = { userId };

      if (status) {
        where.status = status as WorkerBookingStatus;
      }

      const [bookings, total] = await Promise.all([
        this.prisma.workerBooking.findMany({
          where,
          include: {
            worker: {
              select: {
                id: true,
                name: true,
                phone: true,
                avatar: true,
                workerType: true,
                rating: true,
                totalReviews: true,
                experienceYears: true,
                dailyRate: true,
                latitude: true,
                longitude: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
        }),
        this.prisma.workerBooking.count({ where }),
      ]);

      return {
        success: true,
        data: bookings.map((b) => this.formatBooking(b)),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    } catch (error) {
      this.logger.error('Error getting my bookings:', error);
      throw new BadRequestException('Không thể lấy danh sách booking');
    }
  }

  /**
   * Get single booking detail
   */
  async getBookingDetail(id: number, userId: number) {
    try {
      const booking = await this.prisma.workerBooking.findFirst({
        where: { id, userId },
        include: {
          worker: {
            select: {
              id: true,
              name: true,
              phone: true,
              avatar: true,
              workerType: true,
              rating: true,
              totalReviews: true,
              experienceYears: true,
              dailyRate: true,
              hourlyRate: true,
              latitude: true,
              longitude: true,
              location: true,
              district: true,
              description: true,
              completedJobs: true,
              certifications: true,
              portfolioImages: true,
            },
          },
        },
      });

      if (!booking) {
        throw new NotFoundException(`Không tìm thấy booking #${id}`);
      }

      return {
        success: true,
        data: this.formatBooking(booking),
      };
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error('Error getting booking detail:', error);
      throw new BadRequestException('Không thể lấy chi tiết booking');
    }
  }

  /**
   * Update booking status (accept, start, complete, cancel)
   */
  async updateBookingStatus(
    id: number,
    userId: number,
    dto: UpdateBookingStatusDto,
  ) {
    try {
      const booking = await this.prisma.workerBooking.findFirst({
        where: { id, userId },
      });

      if (!booking) {
        throw new NotFoundException(`Không tìm thấy booking #${id}`);
      }

      // Validate status transitions
      this.validateStatusTransition(
        booking.status,
        dto.status as unknown as WorkerBookingStatus,
      );

      const updateData: any = {
        status: dto.status as unknown as WorkerBookingStatus,
      };

      if (dto.status === BookingStatusDto.CANCELLED) {
        updateData.cancelReason = dto.cancelReason || 'Hủy bởi khách hàng';
      }

      if (dto.status === BookingStatusDto.IN_PROGRESS) {
        updateData.startedAt = new Date();
      }

      if (dto.status === BookingStatusDto.COMPLETED) {
        updateData.completedAt = new Date();
        if (dto.finalPrice) {
          updateData.finalPrice = dto.finalPrice;
        }
      }

      const updated = await this.prisma.workerBooking.update({
        where: { id },
        data: updateData,
        include: {
          worker: {
            select: {
              id: true,
              name: true,
              phone: true,
              avatar: true,
              workerType: true,
              rating: true,
            },
          },
        },
      });

      return {
        success: true,
        message: this.getStatusMessage(dto.status),
        data: this.formatBooking(updated),
      };
    } catch (error) {
      if (
        error instanceof NotFoundException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }
      this.logger.error('Error updating booking status:', error);
      throw new BadRequestException('Không thể cập nhật trạng thái booking');
    }
  }

  /**
   * Cancel a booking
   */
  async cancelBooking(id: number, userId: number, reason?: string) {
    return this.updateBookingStatus(id, userId, {
      status: BookingStatusDto.CANCELLED,
      cancelReason: reason || 'Hủy bởi khách hàng',
    });
  }

  /**
   * Get booking tracking info (worker location simulation)
   */
  async getBookingTracking(id: number, userId: number) {
    try {
      const booking = await this.prisma.workerBooking.findFirst({
        where: { id, userId },
        include: {
          worker: {
            select: {
              id: true,
              name: true,
              phone: true,
              avatar: true,
              latitude: true,
              longitude: true,
            },
          },
        },
      });

      if (!booking) {
        throw new NotFoundException(`Không tìm thấy booking #${id}`);
      }

      // Return worker's current location and booking status
      const workerLat = booking.worker.latitude || booking.customerLatitude;
      const workerLng = booking.worker.longitude || booking.customerLongitude;

      // Simulate progress based on status
      let progress = 0;
      switch (booking.status) {
        case 'PENDING':
          progress = 0;
          break;
        case 'ACCEPTED':
          progress = 20;
          break;
        case 'ARRIVING':
          progress = 50;
          break;
        case 'IN_PROGRESS':
          progress = 75;
          break;
        case 'COMPLETED':
          progress = 100;
          break;
      }

      return {
        success: true,
        data: {
          bookingId: booking.id,
          status: booking.status,
          progress,
          worker: {
            id: booking.worker.id,
            name: booking.worker.name,
            phone: booking.worker.phone,
            avatar: booking.worker.avatar,
            currentLatitude: workerLat,
            currentLongitude: workerLng,
          },
          customer: {
            latitude: booking.customerLatitude,
            longitude: booking.customerLongitude,
            address: booking.customerAddress,
          },
          estimatedArrival: booking.status === 'ARRIVING' ? '10-15 phút' : null,
        },
      };
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error('Error getting booking tracking:', error);
      throw new BadRequestException('Không thể lấy thông tin theo dõi');
    }
  }

  // ==================== PRIVATE HELPERS ====================

  private validateStatusTransition(
    current: WorkerBookingStatus,
    next: WorkerBookingStatus,
  ) {
    const validTransitions: Partial<
      Record<WorkerBookingStatus, WorkerBookingStatus[]>
    > = {
      SEARCHING: [WorkerBookingStatus.PENDING, WorkerBookingStatus.CANCELLED],
      PENDING: [WorkerBookingStatus.ACCEPTED, WorkerBookingStatus.CANCELLED],
      ACCEPTED: [WorkerBookingStatus.ARRIVING, WorkerBookingStatus.CANCELLED],
      ARRIVING: [
        WorkerBookingStatus.IN_PROGRESS,
        WorkerBookingStatus.CANCELLED,
      ],
      IN_PROGRESS: [
        WorkerBookingStatus.COMPLETED,
        WorkerBookingStatus.CANCELLED,
      ],
    };

    const allowed = validTransitions[current];
    if (!allowed || !allowed.includes(next)) {
      throw new BadRequestException(
        `Không thể chuyển trạng thái từ ${current} sang ${next}`,
      );
    }
  }

  private getStatusMessage(status: BookingStatusDto): string {
    const messages: Record<BookingStatusDto, string> = {
      [BookingStatusDto.SEARCHING]: 'Đang tìm thợ...',
      [BookingStatusDto.PENDING]: 'Đang chờ thợ xác nhận',
      [BookingStatusDto.ACCEPTED]: 'Thợ đã chấp nhận',
      [BookingStatusDto.ARRIVING]: 'Thợ đang trên đường đến',
      [BookingStatusDto.IN_PROGRESS]: 'Thợ đang làm việc',
      [BookingStatusDto.COMPLETED]: 'Công việc đã hoàn thành',
      [BookingStatusDto.CANCELLED]: 'Đã hủy booking',
    };
    return messages[status] || 'Đã cập nhật trạng thái';
  }

  private formatBooking(booking: any) {
    return {
      id: booking.id,
      workerId: booking.workerId,
      userId: booking.userId,
      serviceCategory: booking.serviceCategory,
      customerLocation: {
        latitude: booking.customerLatitude,
        longitude: booking.customerLongitude,
        address: booking.customerAddress,
      },
      scheduledDate: booking.scheduledDate,
      scheduledTime: booking.scheduledTime,
      estimatedPrice: Number(booking.estimatedPrice),
      finalPrice: booking.finalPrice ? Number(booking.finalPrice) : null,
      status: booking.status,
      notes: booking.notes,
      paymentMethod: booking.paymentMethod,
      cancelReason: booking.cancelReason,
      distanceKm: booking.distanceKm,
      startedAt: booking.startedAt,
      completedAt: booking.completedAt,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
      worker: booking.worker
        ? {
            id: booking.worker.id,
            name: booking.worker.name,
            phone: booking.worker.phone,
            avatar: booking.worker.avatar,
            workerType: booking.worker.workerType,
            rating: Number(booking.worker.rating) || 0,
            reviewCount: booking.worker.reviewCount || 0,
            experience: booking.worker.experience || 0,
            dailyRate: booking.worker.dailyRate
              ? Number(booking.worker.dailyRate)
              : null,
            latitude: booking.worker.latitude,
            longitude: booking.worker.longitude,
          }
        : null,
    };
  }
}
