import {
    Body,
    Controller,
    Get,
    Param,
    Patch,
    Post,
    Query,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import {
    BookingQueryDto,
    CreateWorkerBookingDto,
    UpdateBookingStatusDto,
} from './dto/worker-booking.dto';
import { WorkerBookingsService } from './worker-bookings.service';

@ApiTags('Worker Bookings - Đặt thợ kiểu Grab')
@Controller('bookings')
@UseGuards(ApiKeyGuard)
export class WorkerBookingsController {
  constructor(private readonly bookingsService: WorkerBookingsService) {}

  // ==================== AUTHENTICATED ENDPOINTS ====================

  @Post('worker-request')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Đặt thợ mới (Grab-style booking request)' })
  @ApiResponse({ status: 201, description: 'Yêu cầu đặt thợ thành công' })
  async createBooking(
    @Body() dto: CreateWorkerBookingDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.createBooking(user.id, dto);
  }

  @Get('my-worker-bookings')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Lấy danh sách booking của tôi' })
  @ApiResponse({ status: 200, description: 'Danh sách booking' })
  async getMyBookings(
    @Query() query: BookingQueryDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.getMyBookings(user.id, query);
  }

  @Get('worker-request/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Chi tiết booking' })
  @ApiResponse({ status: 200, description: 'Chi tiết booking' })
  async getBookingDetail(@Param('id') id: string, @CurrentUser() user: any) {
    return this.bookingsService.getBookingDetail(parseInt(id, 10), user.id);
  }

  @Get('worker-request/:id/tracking')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Theo dõi thợ đang đến (live tracking)' })
  @ApiResponse({ status: 200, description: 'Thông tin tracking' })
  async getBookingTracking(@Param('id') id: string, @CurrentUser() user: any) {
    return this.bookingsService.getBookingTracking(parseInt(id, 10), user.id);
  }

  @Patch('worker-request/:id/status')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Cập nhật trạng thái booking' })
  @ApiResponse({ status: 200, description: 'Trạng thái đã cập nhật' })
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateBookingStatusDto,
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.updateBookingStatus(
      parseInt(id, 10),
      user.id,
      dto,
    );
  }

  @Patch('worker-request/:id/cancel')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Hủy booking' })
  @ApiResponse({ status: 200, description: 'Đã hủy booking' })
  async cancelBooking(
    @Param('id') id: string,
    @Body() body: { reason?: string },
    @CurrentUser() user: any,
  ) {
    return this.bookingsService.cancelBooking(
      parseInt(id, 10),
      user.id,
      body.reason,
    );
  }
}
