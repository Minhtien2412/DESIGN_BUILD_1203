import { ApiProperty } from '@nestjs/swagger';
import { TaskPriority, TaskStatus } from '@prisma/client';
import { Transform } from 'class-transformer';
import {
    IsDateString,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
} from 'class-validator';

// Map FE status aliases to canonical BE enum values
const STATUS_ALIASES: Record<string, TaskStatus> = {
  DOING: TaskStatus.IN_PROGRESS,
  IN_REVIEW: TaskStatus.REVIEW,
  COMPLETED: TaskStatus.DONE,
  NOT_STARTED: TaskStatus.TODO,
  BLOCKED: TaskStatus.CANCELLED,
};

export function normalizeTaskStatus(value: string): TaskStatus | string {
  if (!value) return value;
  const upper = value.toUpperCase().replace(/-/g, '_');
  return STATUS_ALIASES[upper] || upper;
}

export class CreateTaskDto {
  @ApiProperty({
    description: 'Task title',
    example: 'Design homepage mockup',
  })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({
    description: 'Task description',
    example: 'Create wireframes and mockups for the homepage',
    required: false,
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({
    description: 'Project ID',
    example: 1,
  })
  @IsNumber()
  @IsNotEmpty()
  projectId: number;

  @ApiProperty({
    description: 'Task status',
    enum: TaskStatus,
    required: false,
  })
  @Transform(({ value }) => normalizeTaskStatus(value))
  @IsEnum(TaskStatus)
  @IsOptional()
  status?: TaskStatus;

  @ApiProperty({
    description: 'Task priority',
    enum: TaskPriority,
    required: false,
  })
  @IsEnum(TaskPriority)
  @IsOptional()
  priority?: TaskPriority;

  @ApiProperty({
    description: 'Assignee user ID',
    required: false,
  })
  @Transform(({ value, obj }) => value ?? obj.assignedToId)
  @IsNumber()
  @IsOptional()
  assigneeId?: number;

  // FE alias: some callers send assignedToId instead of assigneeId
  @IsNumber()
  @IsOptional()
  assignedToId?: number;

  @ApiProperty({
    description: 'Due date',
    example: '2025-12-31',
    required: false,
  })
  @IsDateString()
  @IsOptional()
  dueDate?: string;
}
