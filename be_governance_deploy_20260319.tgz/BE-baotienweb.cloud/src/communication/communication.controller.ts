import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    Post,
    Put,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiQuery,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ApiKeyGuard } from '../common/guards/api-key.guard';
import { CommunicationService } from './communication.service';
import {
    AnnouncementQueryDto,
    CreateAnnouncementDto,
    CreateChannelDto,
    UpdateAnnouncementDto,
} from './dto/communication.dto';

@ApiTags('Communication')
@Controller('communication')
@UseGuards(ApiKeyGuard)
export class CommunicationController {
  constructor(private readonly communicationService: CommunicationService) {}

  // ==================== ANNOUNCEMENTS ====================

  @Get('announcements')
  @ApiOperation({ summary: 'Get all announcements' })
  @ApiResponse({
    status: 200,
    description: 'Announcements returned successfully',
  })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  @ApiQuery({
    name: 'priority',
    required: false,
    enum: ['LOW', 'NORMAL', 'HIGH', 'URGENT'],
  })
  @ApiQuery({ name: 'includeExpired', required: false, type: Boolean })
  async getAnnouncements(@Query() query: AnnouncementQueryDto) {
    return this.communicationService.getAnnouncements(query);
  }

  @Get('announcements/:id')
  @ApiOperation({ summary: 'Get announcement by ID' })
  @ApiResponse({ status: 200, description: 'Announcement returned' })
  async getAnnouncement(@Param('id') id: string) {
    return this.communicationService.getAnnouncement(+id);
  }

  @Post('announcements')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create new announcement' })
  @ApiResponse({ status: 201, description: 'Announcement created' })
  async createAnnouncement(
    @Body() dto: CreateAnnouncementDto,
    @Request() req: any,
  ) {
    return this.communicationService.createAnnouncement(dto, req.user?.id);
  }

  @Put('announcements/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update announcement' })
  @ApiResponse({ status: 200, description: 'Announcement updated' })
  async updateAnnouncement(
    @Param('id') id: string,
    @Body() dto: UpdateAnnouncementDto,
  ) {
    return this.communicationService.updateAnnouncement(+id, dto);
  }

  @Delete('announcements/:id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete announcement' })
  @ApiResponse({ status: 200, description: 'Announcement deleted' })
  async deleteAnnouncement(@Param('id') id: string) {
    return this.communicationService.deleteAnnouncement(+id);
  }

  // ==================== CHANNELS ====================

  @Get('channels')
  @ApiOperation({ summary: 'Get communication channels' })
  @ApiResponse({ status: 200, description: 'Channels returned successfully' })
  @ApiQuery({ name: 'projectId', required: false, type: Number })
  async getChannels(@Query('projectId') projectId?: number) {
    return this.communicationService.getChannels(projectId);
  }

  @Get('channels/:id')
  @ApiOperation({ summary: 'Get channel by ID' })
  @ApiResponse({ status: 200, description: 'Channel returned' })
  async getChannel(@Param('id') id: string) {
    return this.communicationService.getChannel(+id);
  }

  @Post('channels')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create communication channel' })
  @ApiResponse({ status: 201, description: 'Channel created' })
  async createChannel(@Body() dto: CreateChannelDto, @Request() req: any) {
    return this.communicationService.createChannel(dto, req.user?.id);
  }

  // ==================== STATS ====================

  @Get('stats')
  @ApiOperation({ summary: 'Get communication statistics' })
  @ApiResponse({ status: 200, description: 'Stats returned' })
  async getStats(@Query('projectId') projectId?: number) {
    return this.communicationService.getStats(projectId);
  }
}
