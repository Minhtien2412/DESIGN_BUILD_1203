import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
    AnnouncementQueryDto,
    CreateAnnouncementDto,
    CreateChannelDto,
    UpdateAnnouncementDto
} from './dto/communication.dto';

@Injectable()
export class CommunicationService {
  private readonly logger = new Logger(CommunicationService.name);

  // In-memory storage for now (replace with Prisma when tables are ready)
  private announcements: any[] = [];
  private channels: any[] = [];
  private idCounter = 1;

  constructor(private readonly prisma: PrismaService) {
    // Initialize with mock data
    this.initializeMockData();
  }

  private initializeMockData() {
    this.announcements = [
      {
        id: 1,
        title: 'Thông báo bảo trì hệ thống',
        content:
          'Hệ thống sẽ được bảo trì vào cuối tuần này từ 22:00 - 06:00. Vui lòng lưu ý.',
        priority: 'HIGH',
        projectId: null,
        publishedBy: 1,
        publishedByName: 'Admin',
        viewCount: 150,
        isPinned: true,
        expiresAt: null,
        attachments: [],
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: 2,
        title: 'Cập nhật tính năng mới',
        content:
          'Chúng tôi vừa ra mắt tính năng chat real-time và theo dõi tiến độ dự án.',
        priority: 'NORMAL',
        projectId: null,
        publishedBy: 1,
        publishedByName: 'Product Team',
        viewCount: 89,
        isPinned: false,
        expiresAt: null,
        attachments: [],
        createdAt: new Date(Date.now() - 172800000).toISOString(),
        updatedAt: new Date(Date.now() - 172800000).toISOString(),
      },
      {
        id: 3,
        title: 'Hướng dẫn sử dụng app mới',
        content:
          'Xem hướng dẫn chi tiết cách sử dụng các tính năng mới của ứng dụng.',
        priority: 'LOW',
        projectId: null,
        publishedBy: 1,
        publishedByName: 'Support',
        viewCount: 45,
        isPinned: false,
        expiresAt: null,
        attachments: [
          {
            id: 1,
            fileName: 'guide.pdf',
            fileUrl: '/uploads/guide.pdf',
            fileType: 'application/pdf',
          },
        ],
        createdAt: new Date(Date.now() - 259200000).toISOString(),
        updatedAt: new Date(Date.now() - 259200000).toISOString(),
      },
    ];

    this.channels = [
      {
        id: 1,
        name: 'Thông báo chung',
        description: 'Kênh thông báo chung cho toàn bộ hệ thống',
        type: 'ANNOUNCEMENT',
        projectId: null,
        memberCount: 100,
        createdBy: 1,
        createdAt: new Date(Date.now() - 604800000).toISOString(),
        updatedAt: new Date(Date.now() - 604800000).toISOString(),
      },
      {
        id: 2,
        name: 'Hỗ trợ kỹ thuật',
        description: 'Kênh hỗ trợ và giải đáp thắc mắc',
        type: 'SUPPORT',
        projectId: null,
        memberCount: 50,
        createdBy: 1,
        createdAt: new Date(Date.now() - 604800000).toISOString(),
        updatedAt: new Date(Date.now() - 604800000).toISOString(),
      },
    ];

    this.idCounter = 4;
  }

  // ==================== ANNOUNCEMENTS ====================

  async getAnnouncements(query: AnnouncementQueryDto) {
    let filtered = [...this.announcements];

    if (query.projectId) {
      filtered = filtered.filter(
        (a) => a.projectId === query.projectId || a.projectId === null,
      );
    }

    if (query.priority) {
      filtered = filtered.filter((a) => a.priority === query.priority);
    }

    if (!query.includeExpired) {
      const now = new Date();
      filtered = filtered.filter(
        (a) => !a.expiresAt || new Date(a.expiresAt) > now,
      );
    }

    // Sort by pinned first, then by date
    filtered.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return {
      success: true,
      data: filtered,
      total: filtered.length,
    };
  }

  async getAnnouncement(id: number) {
    const announcement = this.announcements.find((a) => a.id === id);
    if (!announcement) {
      throw new NotFoundException(`Announcement ${id} not found`);
    }

    // Increment view count
    announcement.viewCount++;

    return {
      success: true,
      data: announcement,
    };
  }

  async createAnnouncement(dto: CreateAnnouncementDto, userId?: number) {
    const newAnnouncement = {
      id: this.idCounter++,
      ...dto,
      publishedBy: userId || 1,
      publishedByName: 'User',
      viewCount: 0,
      isPinned: dto.isPinned || false,
      attachments: dto.attachments || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.announcements.unshift(newAnnouncement);
    this.logger.log(`Created announcement: ${newAnnouncement.title}`);

    return {
      success: true,
      data: newAnnouncement,
    };
  }

  async updateAnnouncement(id: number, dto: UpdateAnnouncementDto) {
    const index = this.announcements.findIndex((a) => a.id === id);
    if (index === -1) {
      throw new NotFoundException(`Announcement ${id} not found`);
    }

    this.announcements[index] = {
      ...this.announcements[index],
      ...dto,
      updatedAt: new Date().toISOString(),
    };

    return {
      success: true,
      data: this.announcements[index],
    };
  }

  async deleteAnnouncement(id: number) {
    const index = this.announcements.findIndex((a) => a.id === id);
    if (index === -1) {
      throw new NotFoundException(`Announcement ${id} not found`);
    }

    this.announcements.splice(index, 1);

    return {
      success: true,
      message: 'Announcement deleted',
    };
  }

  // ==================== CHANNELS ====================

  async getChannels(projectId?: number) {
    let filtered = [...this.channels];

    if (projectId) {
      filtered = filtered.filter(
        (c) => c.projectId === projectId || c.projectId === null,
      );
    }

    return {
      success: true,
      data: filtered,
      total: filtered.length,
    };
  }

  async getChannel(id: number) {
    const channel = this.channels.find((c) => c.id === id);
    if (!channel) {
      throw new NotFoundException(`Channel ${id} not found`);
    }

    return {
      success: true,
      data: channel,
    };
  }

  async createChannel(dto: CreateChannelDto, userId?: number) {
    const newChannel = {
      id: this.idCounter++,
      ...dto,
      memberCount: 1,
      createdBy: userId || 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.channels.push(newChannel);
    this.logger.log(`Created channel: ${newChannel.name}`);

    return {
      success: true,
      data: newChannel,
    };
  }

  // ==================== STATS ====================

  async getStats(projectId?: number) {
    const announcements = projectId
      ? this.announcements.filter(
          (a) => a.projectId === projectId || !a.projectId,
        )
      : this.announcements;

    const channels = projectId
      ? this.channels.filter((c) => c.projectId === projectId || !c.projectId)
      : this.channels;

    return {
      success: true,
      data: {
        totalAnnouncements: announcements.length,
        totalChannels: channels.length,
        unreadAnnouncements: announcements.length, // Simplified - would track per user
        pinnedAnnouncements: announcements.filter((a) => a.isPinned).length,
        urgentAnnouncements: announcements.filter(
          (a) => a.priority === 'URGENT',
        ).length,
      },
    };
  }
}
