/**
 * Estimates Service - Business logic for estimates
 */

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateEstimateDto, UpdateEstimateDto } from './estimates.dto';

@Injectable()
export class EstimatesService {
  constructor(private prisma: PrismaService) {}

  async create(userId: string, dto: CreateEstimateDto) {
    return this.prisma.estimate.create({
      data: {
        userId,
        type: dto.type,
        name: dto.name,
        description: dto.description,
        data: dto.data as any,
        results: dto.results as any,
        status: dto.status || 'draft',
        tags: dto.tags,
        projectName: dto.projectName,
        location: dto.location,
        localId: dto.localId,
      },
    });
  }

  async findAll(userId: string, options?: { type?: string; status?: string }) {
    const where: any = { userId };
    if (options?.type) where.type = options.type;
    if (options?.status) where.status = options.status;

    return this.prisma.estimate.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
    });
  }

  async findOne(id: string, userId: string) {
    return this.prisma.estimate.findFirst({
      where: { id, userId },
    });
  }

  async update(id: string, userId: string, dto: UpdateEstimateDto) {
    // Verify ownership
    const existing = await this.findOne(id, userId);
    if (!existing) return null;

    return this.prisma.estimate.update({
      where: { id },
      data: {
        name: dto.name,
        description: dto.description,
        data: dto.data as any,
        results: dto.results as any,
        status: dto.status,
        tags: dto.tags,
        projectName: dto.projectName,
        location: dto.location,
      },
    });
  }

  async remove(id: string, userId: string) {
    // Verify ownership
    const existing = await this.findOne(id, userId);
    if (!existing) return null;

    return this.prisma.estimate.delete({
      where: { id },
    });
  }

  async getStats(userId: string) {
    const estimates = await this.prisma.estimate.findMany({
      where: { userId },
      select: {
        type: true,
        status: true,
        results: true,
      },
    });

    const stats = {
      total: estimates.length,
      draft: 0,
      completed: 0,
      archived: 0,
      totalValue: 0,
      byType: {} as Record<string, number>,
    };

    estimates.forEach((e) => {
      // Count by status
      if (e.status === 'draft') stats.draft++;
      else if (e.status === 'completed') stats.completed++;
      else if (e.status === 'archived') stats.archived++;

      // Count by type
      stats.byType[e.type] = (stats.byType[e.type] || 0) + 1;

      // Sum total value
      const results = e.results as any;
      if (results?.totalCost) {
        stats.totalValue += results.totalCost;
      }
    });

    return stats;
  }
}
