/**
 * Estimates Module - Quản lý bản dự toán xây dựng
 * CRUD operations for construction estimates
 */

import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EstimatesController } from './estimates.controller';
import { EstimatesService } from './estimates.service';

@Module({
  controllers: [EstimatesController],
  providers: [EstimatesService, PrismaService],
  exports: [EstimatesService],
})
export class EstimatesModule {}
