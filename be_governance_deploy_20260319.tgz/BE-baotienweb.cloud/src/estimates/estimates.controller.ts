/**
 * Estimates Controller - REST API endpoints
 */

import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    Post,
    Put,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreateEstimateDto,
    EstimateQueryDto,
    UpdateEstimateDto,
} from './estimates.dto';
import { EstimatesService } from './estimates.service';

@ApiTags('Estimates')
@Controller('api/estimates')
@UseGuards(JwtAuthGuard)
export class EstimatesController {
  constructor(private readonly estimatesService: EstimatesService) {}

  @Post()
  async create(@Request() req, @Body() dto: CreateEstimateDto) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const estimate = await this.estimatesService.create(userId, dto);
    return { success: true, data: estimate };
  }

  @Get()
  async findAll(@Request() req, @Query() query: EstimateQueryDto) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const estimates = await this.estimatesService.findAll(userId, query);
    return { success: true, data: estimates };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const stats = await this.estimatesService.getStats(userId);
    return { success: true, data: stats };
  }

  @Get(':id')
  async findOne(@Request() req, @Param('id') id: string) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const estimate = await this.estimatesService.findOne(id, userId);

    if (!estimate) {
      return { success: false, message: 'Estimate not found' };
    }

    return { success: true, data: estimate };
  }

  @Put(':id')
  async update(
    @Request() req,
    @Param('id') id: string,
    @Body() dto: UpdateEstimateDto,
  ) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const estimate = await this.estimatesService.update(id, userId, dto);

    if (!estimate) {
      return {
        success: false,
        message: 'Estimate not found or not authorized',
      };
    }

    return { success: true, data: estimate };
  }

  @Delete(':id')
  async remove(@Request() req, @Param('id') id: string) {
    const userId = req.user?.id || req.user?.sub || 'anonymous';
    const result = await this.estimatesService.remove(id, userId);

    if (!result) {
      return {
        success: false,
        message: 'Estimate not found or not authorized',
      };
    }

    return { success: true, message: 'Estimate deleted successfully' };
  }
}
