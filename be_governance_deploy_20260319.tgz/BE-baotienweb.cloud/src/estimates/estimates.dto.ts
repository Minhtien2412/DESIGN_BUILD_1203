/**
 * Estimates DTOs - Data Transfer Objects
 */

import {
    IsArray,
    IsNumber,
    IsObject,
    IsOptional,
    IsString
} from 'class-validator';

export type EstimateType =
  | 'total'
  | 'structure'
  | 'materials'
  | 'finishing'
  | 'mep'
  | 'interior'
  | 'concrete'
  | 'steel'
  | 'paint';

export type EstimateStatus = 'draft' | 'completed' | 'archived';

export class CreateEstimateDto {
  @IsString()
  type: EstimateType;

  @IsString()
  name: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsObject()
  data: Record<string, any>;

  @IsObject()
  results: {
    totalCost: number;
    breakdown?: Record<string, number>;
    unit?: string;
    quantity?: number;
  };

  @IsOptional()
  @IsString()
  status?: EstimateStatus;

  @IsOptional()
  @IsArray()
  tags?: string[];

  @IsOptional()
  @IsString()
  projectName?: string;

  @IsOptional()
  @IsString()
  location?: string;

  @IsOptional()
  @IsNumber()
  localId?: number;
}

export class UpdateEstimateDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsObject()
  data?: Record<string, any>;

  @IsOptional()
  @IsObject()
  results?: {
    totalCost: number;
    breakdown?: Record<string, number>;
    unit?: string;
    quantity?: number;
  };

  @IsOptional()
  @IsString()
  status?: EstimateStatus;

  @IsOptional()
  @IsArray()
  tags?: string[];

  @IsOptional()
  @IsString()
  projectName?: string;

  @IsOptional()
  @IsString()
  location?: string;
}

export class EstimateQueryDto {
  @IsOptional()
  @IsString()
  type?: string;

  @IsOptional()
  @IsString()
  status?: string;
}
