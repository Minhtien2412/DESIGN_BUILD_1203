import { Injectable, NotFoundException } from '@nestjs/common';
import { Decimal } from '@prisma/client/runtime/library';
import { PrismaService } from '../prisma/prisma.service';
import {
    CreateMaterialDto,
    MaterialCategory,
    MaterialQueryDto,
    UpdateMaterialDto,
} from './materials.dto';

@Injectable()
export class MaterialsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Public endpoint - Get all materials without auth
   */
  async findAllPublic(query: MaterialQueryDto) {
    const { category, search, page = 1, limit = 50 } = query;
    const skip = (page - 1) * limit;

    const where: any = {
      isActive: true,
    };

    if (category) {
      where.category = category;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [materials, total] = await Promise.all([
      this.prisma.material.findMany({
        where,
        orderBy: { updatedAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.material.count({ where }),
    ]);

    return {
      data: materials,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async create(userId: string, dto: CreateMaterialDto) {
    return this.prisma.material.create({
      data: {
        userId,
        category: dto.category,
        name: dto.name,
        description: dto.description,
        unit: dto.unit,
        unitPrice: new Decimal(dto.pricePerUnit),
        specs: dto.specs ? JSON.parse(JSON.stringify(dto.specs)) : undefined,
        tags: dto.tags || [],
        localId: dto.localId,
        isDefault: dto.isDefault || false,
        isActive: true,
      },
    });
  }

  async findAll(userId: string, query: MaterialQueryDto) {
    const {
      category,
      search,
      isActive,
      isDefault,
      page = 1,
      limit = 50,
    } = query;
    const skip = (page - 1) * limit;

    const where: any = {
      OR: [{ userId }, { isDefault: true }],
    };

    if (category) {
      where.category = category;
    }

    if (typeof isActive === 'boolean') {
      where.isActive = isActive;
    }

    if (typeof isDefault === 'boolean') {
      where.isDefault = isDefault;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [materials, total] = await Promise.all([
      this.prisma.material.findMany({
        where,
        orderBy: { updatedAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.material.count({ where }),
    ]);

    return {
      data: materials,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: number, userId: string) {
    const material = await this.prisma.material.findFirst({
      where: {
        id,
        OR: [{ userId }, { isDefault: true }],
      },
    });

    if (!material) {
      throw new NotFoundException('Material not found');
    }

    return material;
  }

  async update(id: number, userId: string, dto: UpdateMaterialDto) {
    const existing = await this.findOne(id, userId);

    // Only allow updating own materials or default materials
    if (existing.userId !== userId && !existing.isDefault) {
      throw new NotFoundException('Cannot update this material');
    }

    return this.prisma.material.update({
      where: { id: existing.id },
      data: {
        name: dto.name,
        description: dto.description,
        unit: dto.unit,
        unitPrice: dto.pricePerUnit ? new Decimal(dto.pricePerUnit) : undefined,
        specs: dto.specs
          ? { ...(existing.specs as object), ...dto.specs }
          : undefined,
        tags: dto.tags,
        isActive: dto.isActive,
      },
    });
  }

  async remove(id: number, userId: string) {
    const material = await this.findOne(id, userId);

    // Don't allow deleting other users' materials
    if (material.userId !== userId) {
      throw new NotFoundException('Cannot delete this material');
    }

    // Soft delete
    return this.prisma.material.update({
      where: { id },
      data: { isActive: false },
    });
  }

  async restore(id: number, userId: string) {
    const material = await this.prisma.material.findFirst({
      where: { id, userId },
    });

    if (!material) {
      throw new NotFoundException('Material not found');
    }

    return this.prisma.material.update({
      where: { id: material.id },
      data: { isActive: true },
    });
  }

  async duplicate(id: number, userId: string) {
    const material = await this.findOne(id, userId);

    return this.prisma.material.create({
      data: {
        userId,
        category: material.category,
        name: `${material.name} (Copy)`,
        description: material.description,
        unit: material.unit,
        unitPrice: material.unitPrice,
        specs: material.specs || {},
        tags: (material.tags as string[]) || [],
        isDefault: false,
        isActive: true,
      },
    });
  }

  async getStats(userId: string | null) {
    // Build query condition - public stats if no userId
    const whereCondition = userId
      ? {
          isActive: true,
          OR: [{ userId }, { isDefault: true }],
        }
      : {
          isActive: true,
        };

    const materials = await this.prisma.material.findMany({
      where: whereCondition,
      select: { category: true, isDefault: true, userId: true },
    });

    const byCategory: Record<string, number> = {};
    for (const cat of Object.values(MaterialCategory)) {
      byCategory[cat] = materials.filter((m) => m.category === cat).length;
    }

    return {
      total: materials.length,
      byCategory,
      customCount: userId
        ? materials.filter((m) => m.userId === userId && !m.isDefault).length
        : 0,
      defaultCount: materials.filter((m) => m.isDefault).length,
    };
  }

  async bulkCreate(userId: string, materials: CreateMaterialDto[]) {
    const created: Awaited<ReturnType<typeof this.create>>[] = [];
    for (const dto of materials) {
      const material = await this.create(userId, dto);
      created.push(material);
    }
    return created;
  }
}
