import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { MaterialsController } from './materials.controller';
import { MaterialsService } from './materials.service';

@Module({
  controllers: [MaterialsController],
  providers: [MaterialsService, PrismaService],
  exports: [MaterialsService],
})
export class MaterialsModule {}
