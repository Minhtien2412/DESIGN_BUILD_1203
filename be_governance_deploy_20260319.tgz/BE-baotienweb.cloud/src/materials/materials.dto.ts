import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    Min,
} from 'class-validator';

export enum MaterialCategory {
  BRICK = 'brick',
  CEMENT = 'cement',
  SAND = 'sand',
  STEEL = 'steel',
  STONE = 'stone',
  WOOD = 'wood',
  PAINT = 'paint',
  TILE = 'tile',
  ELECTRICAL = 'electrical',
  PLUMBING = 'plumbing',
  OTHER = 'other',
}

export class MaterialSpecsDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  qtyPerM2?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  qtyPerM3?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  kgPerM?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  kgPerM2?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  kgPerM3?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  wastage?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  coverage?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  size?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  brand?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  origin?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  standard?: string;
}

export class CreateMaterialDto {
  @ApiProperty({ enum: MaterialCategory })
  @IsEnum(MaterialCategory)
  category: MaterialCategory;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty()
  @IsString()
  unit: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  pricePerUnit: number;

  @ApiPropertyOptional({ type: MaterialSpecsDto })
  @IsOptional()
  @IsObject()
  specs?: MaterialSpecsDto;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  localId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isDefault?: boolean;
}

export class UpdateMaterialDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  unit?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  pricePerUnit?: number;

  @ApiPropertyOptional({ type: MaterialSpecsDto })
  @IsOptional()
  @IsObject()
  specs?: MaterialSpecsDto;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class MaterialQueryDto {
  @ApiPropertyOptional({ enum: MaterialCategory })
  @IsOptional()
  @IsEnum(MaterialCategory)
  category?: MaterialCategory;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isDefault?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  page?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  limit?: number;
}
