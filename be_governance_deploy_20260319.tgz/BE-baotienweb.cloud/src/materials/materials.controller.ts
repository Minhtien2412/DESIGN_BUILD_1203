import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    Post,
    Put,
    Query,
    Request,
    UseGuards,
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiOperation,
    ApiResponse,
    ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
    CreateMaterialDto,
    MaterialQueryDto,
    UpdateMaterialDto,
} from './materials.dto';
import { MaterialsService } from './materials.service';

@ApiTags('Materials')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller({ path: 'materials', version: '1' })
export class MaterialsController {
  constructor(private readonly materialsService: MaterialsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new material' })
  @ApiResponse({ status: 201, description: 'Material created successfully' })
  async create(@Request() req, @Body() dto: CreateMaterialDto) {
    return this.materialsService.create(req.user.id.toString(), dto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all materials (public)' })
  @ApiResponse({ status: 200, description: 'List of materials' })
  async findAll(@Query() query: MaterialQueryDto) {
    return this.materialsService.findAllPublic(query);
  }

  @Get('my')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get my materials' })
  @ApiResponse({ status: 200, description: 'List of user materials' })
  async findMyMaterials(@Request() req, @Query() query: MaterialQueryDto) {
    return this.materialsService.findAll(req.user.id.toString(), query);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get material statistics' })
  @ApiResponse({ status: 200, description: 'Material statistics' })
  async getStats(@Request() req) {
    // If no user authenticated, return public stats
    const userId = req?.user?.id?.toString() || null;
    return this.materialsService.getStats(userId);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a material by ID' })
  @ApiResponse({ status: 200, description: 'Material details' })
  @ApiResponse({ status: 404, description: 'Material not found' })
  async findOne(@Request() req, @Param('id') id: string) {
    return this.materialsService.findOne(parseInt(id), req.user.id.toString());
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a material' })
  @ApiResponse({ status: 200, description: 'Material updated successfully' })
  @ApiResponse({ status: 404, description: 'Material not found' })
  async update(
    @Request() req,
    @Param('id') id: string,
    @Body() dto: UpdateMaterialDto,
  ) {
    return this.materialsService.update(
      parseInt(id),
      req.user.id.toString(),
      dto,
    );
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a material' })
  @ApiResponse({ status: 200, description: 'Material deleted successfully' })
  @ApiResponse({ status: 404, description: 'Material not found' })
  async remove(@Request() req, @Param('id') id: string) {
    return this.materialsService.remove(parseInt(id), req.user.id.toString());
  }

  @Post(':id/restore')
  @ApiOperation({ summary: 'Restore a deleted material' })
  @ApiResponse({ status: 200, description: 'Material restored successfully' })
  async restore(@Request() req, @Param('id') id: string) {
    return this.materialsService.restore(parseInt(id), req.user.id.toString());
  }

  @Post(':id/duplicate')
  @ApiOperation({ summary: 'Duplicate a material' })
  @ApiResponse({ status: 201, description: 'Material duplicated successfully' })
  async duplicate(@Request() req, @Param('id') id: string) {
    return this.materialsService.duplicate(
      parseInt(id),
      req.user.id.toString(),
    );
  }

  @Post('bulk')
  @ApiOperation({ summary: 'Bulk create materials' })
  @ApiResponse({ status: 201, description: 'Materials created successfully' })
  async bulkCreate(@Request() req, @Body() materials: CreateMaterialDto[]) {
    return this.materialsService.bulkCreate(req.user.id.toString(), materials);
  }
}
